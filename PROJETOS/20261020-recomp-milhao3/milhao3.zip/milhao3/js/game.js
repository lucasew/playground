/* Show do Milhão 3 — web port of the Softmed VB6 game.
   Scoring matches regra_2: parar keeps the previous prize;
   errar pays half of that prize; the million question
   (arrisca tudo) pays nothing and stays off the placar. */
(function () {
  const PRIZES = [
    1000, 2000, 3000, 4000, 5000,
    10000, 20000, 30000, 40000, 50000,
    100000, 200000, 300000, 400000, 500000,
    1000000
  ];
  const TIER_OF = [
    "A", "A", "A", "A", "A",
    "B", "B", "B", "B", "B",
    "C", "C", "C", "C", "C",
    "C"
  ];
  const ROUND_WAV = { 0: "Rodada1.wav", 5: "Rodada2.wav", 10: "Rodada3.wav" };
  const RULES = ["regra_0.jpg", "regra_1.jpg", "regra_2.jpg", "Regra_3.JPG", "Regra_4.JPG"];
  const CARDS = [
    { src: "assets/img/rei.jpg", drop: 1, name: "REI" },
    { src: "assets/img/as.jpg", drop: 1, name: "ÁS" },
    { src: "assets/img/dois.jpg", drop: 2, name: "DOIS" },
    { src: "assets/img/tres.jpg", drop: 3, name: "TRÊS" }
  ];
  const LIMIT = 40;

  const $ = (id) => document.getElementById(id);
  const voice = new Audio();
  const bed = new Audio();
  bed.loop = true;
  bed.volume = 0.28;
  const ui = new Audio();

  const state = {
    nome: "",
    assunto: "todos",
    deck: [],
    index: 0,
    locked: false,
    clock: null,
    left: LIMIT,
    ajuda: { cartas: false, placas: false, conv: false },
    pulos: 3,
    regra: 0,
    removed: new Set()
  };

  function shuffle(list) {
    const a = list.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function money(n) {
    return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
  }

  function prizeFile(n) {
    return "assets/img/p" + n + ".jpg";
  }

  function click() {
    ui.src = "assets/sons/clique1.wav";
    ui.play().catch(() => {});
  }

  function say(file) {
    voice.src = file.startsWith("assets/") ? file : "assets/audios/" + file;
    voice.play().catch(() => {});
  }

  let bedFile = "";
  function bedPlay(file) {
    const src = "assets/audios/" + file;
    if (bedFile !== src) {
      bedFile = src;
      bed.src = src;
    }
    bed.volume = 0.8;
    const pending = bed.play();
    if (pending) pending.catch(() => {});
    return pending;
  }

  function bedStop() {
    bed.pause();
  }

  function show(id) {
    document.querySelectorAll(".screen").forEach((el) => el.classList.toggle("on", el.id === id));
    if (id === "screen-menu") {
      bedPlay("Tema.wav");
    } else if (id !== "screen-jogo") {
      bedStop();
    }
  }

  function secured() {
    return state.index <= 0 ? 0 : PRIZES[state.index - 1];
  }

  function wrongPay() {
    if (state.index === PRIZES.length - 1) return 0;
    return Math.floor(secured() / 2);
  }

  function deal(assunto) {
    const all = window.MILHAO_QUESTIONS;
    const mine = assunto === "todos" ? all : all.filter((q) => q.s === assunto);
    const geral = all.filter((q) => q.s === "ger" && !mine.includes(q));
    const ordered = assunto === "todos" ? shuffle(all) : shuffle(mine).concat(shuffle(geral));
    const used = new Set();
    const take = (tier, n) => {
      const out = [];
      for (const q of ordered) {
        if (out.length >= n) break;
        if (used.has(q) || q.t !== tier) continue;
        used.add(q);
        out.push(q);
      }
      for (const q of ordered) {
        if (out.length >= n) break;
        if (used.has(q)) continue;
        used.add(q);
        out.push(q);
      }
      return out;
    };
    const deck = take("A", 5).concat(take("B", 5), take("C", 6));
    return deck.slice(0, PRIZES.length);
  }

  function ajudaOn(on) {
    const million = state.index === PRIZES.length - 1;
    document.querySelectorAll(".helps button").forEach((btn) => {
      const kind = btn.dataset.help;
      let used = false;
      if (kind === "cartas") used = state.ajuda.cartas;
      else if (kind === "placas") used = state.ajuda.placas;
      else if (kind === "conv") used = state.ajuda.conv;
      else used = btn.classList.contains("gasto");
      const blocked = million || used || !on;
      btn.disabled = blocked;
      btn.classList.toggle("usado", used || million);
    });
    $("btn-parar").disabled = !on;
  }

  function paintAnswers(q) {
    document.querySelectorAll(".resposta").forEach((btn) => {
      const i = Number(btn.dataset.i);
      const text = q.a[i];
      btn.hidden = text == null;
      btn.disabled = text == null || state.removed.has(i);
      btn.textContent = state.removed.has(i) ? "" : (text || "");
      btn.classList.remove("chosen", "certa", "errada");
    });
  }

  const TEMPO_PX = 132;

  function paintTime() {
    const k = Math.max(0, state.left / LIMIT);
    $("tempo-fill").style.width = Math.round(TEMPO_PX * k) + "px";
    $("tempo-num").textContent = String(Math.max(0, Math.ceil(state.left)));
  }

  function stopClock() {
    if (state.clock) {
      clearInterval(state.clock);
      state.clock = null;
    }
  }

  function tickClock() {
    state.left -= 0.1;
    paintTime();
    if (state.left <= 0) {
      stopClock();
      state.locked = true;
      say("Tempo.wav");
      finish(false, "FIM DO TEMPO");
    }
  }

  function startClock() {
    stopClock();
    state.left = LIMIT;
    paintTime();
    state.clock = setInterval(tickClock, 100);
  }

  function showQuestion() {
    const q = state.deck[state.index];
    if (!q) {
      finish(true, "ACABARAM AS PERGUNTAS DESTE ASSUNTO");
      return;
    }
    state.locked = false;
    state.removed = new Set();
    $("valor").textContent = "VALENDO " + money(PRIZES[state.index]);
    $("ouro").src = "assets/img/ouro" + (state.index + 1) + ".jpg";
    $("pergunta").textContent = q.q;
    paintAnswers(q);
    closeOverlay();
    $("btn-entendeu").hidden = true;
    ajudaOn(true);
    const round = ROUND_WAV[state.index];
    if (round) say(round);
    else say("Entendeu.wav");
    const suspense = "Susp" + ((state.index % 6) + 1) + ".wav";
    bedPlay(suspense);
    startClock();
  }

  function beginRound() {
    state.deck = deal(state.assunto);
    state.index = 0;
    state.ajuda = { cartas: false, placas: false, conv: false };
    state.pulos = 3;
    document.querySelectorAll(".pula").forEach((b) => b.classList.remove("gasto"));
    show("screen-jogo");
    say("Comeco.wav");
    setTimeout(showQuestion, 700);
  }

  function openOverlay(html) {
    $("dialog").innerHTML = html;
    $("overlay").classList.add("on");
  }

  function closeOverlay() {
    $("overlay").classList.remove("on");
    $("dialog").innerHTML = "";
  }

  function resumeClock() {
    if (state.left <= 0 || state.clock) return;
    state.clock = setInterval(tickClock, 100);
  }

  function choose(i) {
    if (state.locked) return;
    const q = state.deck[state.index];
    if (q.a[i] == null || state.removed.has(i)) return;
    click();
    document.querySelectorAll(".resposta").forEach((b) => b.classList.toggle("chosen", Number(b.dataset.i) === i));
    const certeza = "Certeza" + (1 + (i % 3)) + ".wav";
    say(certeza);
    openOverlay(
      "<h2>CERTEZA?</h2><p>" + q.a[i] + "</p>" +
      "<div class='simnao'><button type='button' id='sim'>SIM</button><button type='button' id='nao'>NÃO</button></div>"
    );
    $("sim").onclick = () => {
      closeOverlay();
      judge(i);
    };
    $("nao").onclick = () => {
      click();
      document.querySelectorAll(".resposta").forEach((b) => b.classList.remove("chosen"));
      closeOverlay();
      resumeClock();
    };
  }

  function judge(i) {
    if (state.locked) return;
    state.locked = true;
    stopClock();
    ajudaOn(false);
    const q = state.deck[state.index];
    const ok = i === q.c;
    document.querySelectorAll(".resposta").forEach((b) => {
      const n = Number(b.dataset.i);
      if (n === q.c) b.classList.add("certa");
      else if (n === i) b.classList.add("errada");
    });
    if (ok) {
      say(state.index === PRIZES.length - 1 ? "Ganhou.wav" : "Correta.wav");
      if (state.index === PRIZES.length - 1) {
        setTimeout(() => finish(true, "UM MILHÃO!"), 1600);
      } else {
        setTimeout(() => {
          state.index += 1;
          const wav = PRIZES[state.index] + ".wav";
          say(wav);
          showQuestion();
        }, 1400);
      }
    } else {
      say("Errada.wav");
      setTimeout(() => finish(false, "RESPOSTA ERRADA"), 1200);
    }
  }

  const PLACAR_Y = [252, 293, 333, 373, 413];
  let premioNext = null;

  function renderPlacar() {
    const root = $("placar");
    root.replaceChildren();
    loadBoard().slice(0, 5).forEach((row, i) => {
      const nome = document.createElement("div");
      nome.className = "placa-nome";
      nome.style.top = PLACAR_Y[i] + "px";
      nome.textContent = row.nome;
      const pontos = document.createElement("div");
      pontos.className = "placa-pontos";
      pontos.style.top = PLACAR_Y[i] + "px";
      pontos.textContent = money(row.pontos);
      root.append(nome, pontos);
    });
  }

  function openPremio(file, next) {
    premioNext = next;
    $("screen-premio").style.backgroundImage = "url('" + file + "')";
    const vid = $("encerra");
    vid.classList.remove("on");
    show("screen-premio");
  }

  function finish(wonMillion, reason) {
    stopClock();
    bedStop();
    closeOverlay();
    let score;
    let save = true;
    if (reason.indexOf("MILHÃO") >= 0) {
      score = 1000000;
    } else if (wonMillion) {
      score = state.index > 0 ? PRIZES[state.index - 1] : 0;
    } else if (reason === "PARAR") {
      score = secured();
      say("Entregar.wav");
    } else {
      score = wrongPay();
      save = state.index !== PRIZES.length - 1;
      if (!save) say("faltapeito.wav");
    }
    const board = loadBoard();
    if (save && score > 0) {
      board.push({ nome: state.nome, pontos: score });
      board.sort((a, b) => b.pontos - a.pontos);
      board.splice(5);
      localStorage.setItem("milhao3.placar", JSON.stringify(board));
    }
    openPremio(prizeFile(score), () => {
      renderPlacar();
      show("screen-fim");
    });
    if (score === 1000000) {
      const vid = $("encerra");
      vid.classList.add("on");
      vid.currentTime = 0;
      vid.play().catch(() => vid.classList.remove("on"));
      vid.onended = () => vid.classList.remove("on");
    }
  }

  function loadBoard() {
    try {
      const raw = JSON.parse(localStorage.getItem("milhao3.placar") || "[]");
      return Array.isArray(raw) ? raw.filter((r) => r && r.nome && r.pontos > 0) : [];
    } catch (e) {
      return [];
    }
  }

  function askStop() {
    if ($("btn-parar").disabled) return;
    click();
    const have = secured();
    const million = state.index === PRIZES.length - 1;
    openOverlay(
      "<h2>ENTREGAR O OURO?</h2><p>" +
      (have ? "SE PARAR, VOCÊ LEVA " + money(have) + "." : "VOCÊ AINDA NÃO GARANTIU NADA.") +
      (million ? " NA PERGUNTA DO MILHÃO NÃO HÁ AJUDA." : "") +
      "</p><div class='simnao'><button type='button' id='ouro-sim'>SIM</button><button type='button' id='ouro-nao'>NÃO</button></div>"
    );
    say("Ouro.wav");
    $("ouro-sim").onclick = () => {
      closeOverlay();
      finish(false, "PARAR");
    };
    $("ouro-nao").onclick = () => {
      click();
      closeOverlay();
      resumeClock();
    };
  }

  function useCartas() {
    if (state.ajuda.cartas || state.index === PRIZES.length - 1) return;
    state.ajuda.cartas = true;
    click();
    say("Carta.wav");
    const faces = shuffle(CARDS);
    openOverlay("<h2>CARTAS</h2><p>ESCOLHA UMA CARTA</p><div class='cartas' id='carta-row'></div>");
    const row = $("carta-row");
    faces.forEach((card) => {
      const b = document.createElement("button");
      b.type = "button";
      const img = document.createElement("img");
      img.src = "assets/img/4cartas.jpg";
      img.alt = "Carta virada";
      b.appendChild(img);
      b.onclick = () => {
        faces.forEach((c, n) => {
          row.children[n].querySelector("img").src = c.src;
          row.children[n].disabled = true;
        });
        say(card.drop === 3 ? "Tiratres.wav" : "Carta.wav");
        const q = state.deck[state.index];
        const wrong = q.a.map((_, i) => i).filter((i) => i !== q.c && q.a[i] != null && !state.removed.has(i));
        shuffle(wrong).slice(0, card.drop).forEach((i) => state.removed.add(i));
        setTimeout(() => {
          closeOverlay();
          paintAnswers(q);
          ajudaOn(true);
          resumeClock();
        }, 1100);
      };
      row.appendChild(b);
    });
    ajudaOn(false);
  }

  function percents(n, correct) {
    const w = Array.from({ length: n }, () => 0.25 + Math.random());
    w[correct] += 1.1 + Math.random();
    const sum = w.reduce((a, b) => a + b, 0);
    const p = w.map((x) => Math.max(1, Math.round((100 * x) / sum)));
    p[correct] = Math.max(1, p[correct] + (100 - p.reduce((a, b) => a + b, 0)));
    return p;
  }

  function usePlacas() {
    if (state.ajuda.placas || state.index === PRIZES.length - 1) return;
    state.ajuda.placas = true;
    click();
    say("assets/sons/placas.wav");
    const q = state.deck[state.index];
    const alive = q.a.map((t, i) => (t != null && !state.removed.has(i) ? i : -1)).filter((i) => i >= 0);
    const localCorrect = alive.indexOf(q.c);
    const p = percents(alive.length, Math.max(0, localCorrect));
    const rows = alive.map((i, k) =>
      "<div class='bar'><b>" + (i + 1) + "</b><i style='width:" + p[k] + "%'></i><span>" + p[k] + "%</span></div>"
    ).join("");
    openOverlay("<h2>PLACAS</h2><div class='placas-row'>" + rows + "</div><div class='simnao'><button type='button' id='fechar-ajuda'>VOLTAR</button></div>");
    $("fechar-ajuda").onclick = () => {
      closeOverlay();
      ajudaOn(true);
      resumeClock();
    };
  }

  function useConv() {
    if (state.ajuda.conv || state.index === PRIZES.length - 1) return;
    state.ajuda.conv = true;
    click();
    say("Convida.wav");
    const q = state.deck[state.index];
    const alive = q.a.map((t, i) => (t != null && !state.removed.has(i) ? i : -1)).filter((i) => i >= 0);
    const names = ["CONVIDADO 1", "CONVIDADO 2", "CONVIDADO 3"];
    const votes = names.map(() => alive[Math.random() < 0.62 ? alive.indexOf(q.c) : Math.floor(Math.random() * alive.length)]);
    const lines = names.map((name, k) => "<p>" + name + " — ALTERNATIVA " + (votes[k] + 1) + "</p>").join("");
    openOverlay("<h2>CONVIDADOS</h2>" + lines + "<div class='simnao'><button type='button' id='fechar-ajuda'>VOLTAR</button></div>");
    $("fechar-ajuda").onclick = () => {
      closeOverlay();
      ajudaOn(true);
      resumeClock();
    };
  }

  function usePula(btn) {
    if (btn.classList.contains("gasto") || state.pulos <= 0 || state.index === PRIZES.length - 1) return;
    btn.classList.add("gasto");
    state.pulos -= 1;
    click();
    say("assets/sons/pular.wav");
    const tier = TIER_OF[state.index];
    const pool = window.MILHAO_QUESTIONS.filter((q) => q.t === tier && state.deck.indexOf(q) === -1);
    const next = pool.length ? pool[Math.floor(Math.random() * pool.length)] : null;
    if (next) state.deck[state.index] = next;
    showQuestion();
  }

  function regra(n) {
    state.regra = (n + RULES.length) % RULES.length;
    $("screen-regras").style.backgroundImage = "url('assets/img/" + RULES[state.regra] + "')";
  }

  function fitBoard() {
    const s = Math.min(window.innerWidth / 640, window.innerHeight / 480);
    $("stage").style.transform = "scale(" + s + ")";
    $("fit").style.width = Math.floor(640 * s) + "px";
    $("fit").style.height = Math.floor(480 * s) + "px";
  }

  function bind() {
    fitBoard();
    window.addEventListener("resize", fitBoard);
    voice.addEventListener("play", () => { bed.volume = 0.2; });
    voice.addEventListener("ended", () => { bed.volume = 0.8; });

    const abertura = $("abertura");
    const ouvir = $("ouvir-abertura");
    function playIntro() {
      abertura.muted = false;
      abertura.volume = 1;
      const pending = abertura.play();
      if (!pending) {
        ouvir.hidden = false;
        return;
      }
      pending.then(() => { ouvir.hidden = true; }).catch(() => { ouvir.hidden = false; });
    }
    abertura.addEventListener("ended", () => show("screen-menu"));
    abertura.addEventListener("error", () => show("screen-menu"));
    ouvir.onclick = () => {
      abertura.currentTime = 0;
      playIntro();
    };
    $("pular-abertura").onclick = () => {
      abertura.pause();
      show("screen-menu");
    };
    playIntro();

    document.querySelectorAll("[data-go]").forEach((btn) => {
      btn.addEventListener("click", () => {
        click();
        const go = btn.dataset.go;
        if (go === "regras") {
          regra(0);
          show("screen-regras");
        } else if (go === "nome") {
          show("screen-nome");
          say("Nome.wav");
          $("nome").focus();
        } else if (go === "menu") {
          show("screen-menu");
        }
      });
    });

    $("btn-sair").onclick = () => {
      say("tchau.wav");
      openPremio("assets/img/CRED.jpg", () => show("screen-menu"));
    };
    $("btn-sair-nome").onclick = () => $("btn-sair").click();

    $("btn-entrar").onclick = () => {
      const nome = $("nome").value.trim().toUpperCase();
      if (!nome) {
        $("nome").focus();
        return;
      }
      state.nome = nome.slice(0, 16);
      click();
      say("boasorte.wav");
      show("screen-assunto");
    };
    $("nome").addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") $("btn-entrar").click();
    });

    document.querySelectorAll("[data-assunto]").forEach((btn) => {
      btn.addEventListener("click", () => {
        click();
        state.assunto = btn.dataset.assunto;
        say("Tema_2.wav");
        beginRound();
      });
    });

    $("regra-prox").onclick = () => { click(); regra(state.regra + 1); };
    $("regra-ant").onclick = () => { click(); regra(state.regra - 1); };

    document.querySelectorAll(".resposta").forEach((btn) => {
      btn.addEventListener("click", () => choose(Number(btn.dataset.i)));
    });
    document.addEventListener("keydown", (ev) => {
      if (!$("screen-jogo").classList.contains("on")) return;
      if (ev.key >= "1" && ev.key <= "4") choose(Number(ev.key) - 1);
    });

    $("btn-entendeu").onclick = () => {
      $("btn-entendeu").hidden = true;
      click();
      const wav = PRIZES[state.index];
      say(wav + ".wav");
      ajudaOn(true);
      state.left = LIMIT;
      startClock();
    };

    $("btn-parar").onclick = askStop;
    $("help-cartas").onclick = useCartas;
    $("help-placas").onclick = usePlacas;
    $("help-conv").onclick = useConv;
    document.querySelectorAll(".pula").forEach((btn) => {
      btn.addEventListener("click", () => usePula(btn));
    });

    $("premio-ok").onclick = () => {
      click();
      const vid = $("encerra");
      vid.pause();
      vid.classList.remove("on");
      if (premioNext) premioNext();
    };
    $("fim-zera").onclick = () => {
      click();
      localStorage.removeItem("milhao3.placar");
      renderPlacar();
    };
    $("fim-entrar").onclick = () => {
      click();
      show("screen-menu");
    };
  }

  bind();
})();
