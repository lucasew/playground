/* requested 004b06e0 entry 004b06e0 name FUN_004b06e0 size 1744 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b06e0(void)

{
  int iVar1;
  short sVar2;
  short sVar3;
  short *psVar4;
  short sVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  short sVar9;
  uint uVar10;
  bool bVar11;
  ushort in_FPUStatusWord;
  float10 fVar12;
  int iStack_24;
  float fStack_20;
  
  DAT_0050b260._0_2_ = 0;
  DAT_0050b260._2_2_ = 0;
  if (DAT_0050b000 != 0) {
    adj_fdiv_m64((double)(int)DAT_0050b2c6);
  }
  if (((in_FPUStatusWord & 0xd) == 0) && (__vbaFPInt(), (in_FPUStatusWord & 0xd) == 0)) {
    sVar2 = __vbaFpI2();
    sVar3 = DAT_0050b20a;
    sVar5 = DAT_0050b25e % DAT_0050b2c6;
    sVar9 = 1;
    psVar4 = DAT_0050b1f8;
    if (0 < DAT_0050b20a) {
      do {
        if ((psVar4 == (short *)0x0) || (*psVar4 != 1)) {
          iVar6 = __vbaGenerateBoundsError();
          psVar4 = DAT_0050b1f8;
        }
        else {
          iVar6 = *(int *)(psVar4 + 10);
          if (*(uint *)(psVar4 + 8) <= (uint)(sVar9 - iVar6)) {
            __vbaGenerateBoundsError();
            psVar4 = DAT_0050b1f8;
          }
          iVar6 = (sVar9 - iVar6) * 2;
        }
        if (*(short *)(*(int *)(psVar4 + 6) + iVar6) < 0) {
          if ((psVar4 == (short *)0x0) || (*psVar4 != 1)) {
            iVar6 = __vbaGenerateBoundsError();
            psVar4 = DAT_0050b1f8;
          }
          else {
            iVar6 = *(int *)(psVar4 + 10);
            if (*(uint *)(psVar4 + 8) <= (uint)(sVar9 - iVar6)) {
              __vbaGenerateBoundsError();
              psVar4 = DAT_0050b1f8;
            }
            iVar6 = (sVar9 - iVar6) * 2;
          }
          *(undefined2 *)(*(int *)(psVar4 + 6) + iVar6) = 0;
          psVar4 = DAT_0050b1f8;
        }
        bVar11 = SCARRY2(sVar9,1);
        sVar9 = sVar9 + 1;
        if (bVar11) goto LAB_004b0da8;
      } while (sVar9 <= sVar3);
    }
    sVar9 = 1;
    sVar3 = (short)_DAT_0050b20c;
    if (0 < sVar3) {
      do {
        if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          iVar6 = *(int *)(DAT_0050b0c4 + 0xe);
          if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(sVar9 - iVar6)) {
            __vbaGenerateBoundsError();
          }
          iVar7 = *(int *)(DAT_0050b0c4 + 10);
          if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(sVar2 - iVar7)) {
            __vbaGenerateBoundsError();
          }
          iVar6 = (*(int *)(DAT_0050b0c4 + 0xc) * (sVar2 - iVar7) + (sVar9 - iVar6)) * 8;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar7 = __vbaGenerateBoundsError();
        }
        else {
          iVar7 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar9 - iVar7)) {
            __vbaGenerateBoundsError();
          }
          iVar7 = (sVar9 - iVar7) * 8;
        }
        iVar8 = *(int *)(DAT_0050b0c4 + 6);
        iVar1 = *(int *)(DAT_0050b0fc + 6);
        *(undefined4 *)(iVar1 + iVar7) = *(undefined4 *)(iVar8 + iVar6);
        *(undefined4 *)(iVar1 + 4 + iVar7) = *(undefined4 *)(iVar8 + 4 + iVar6);
        if (0 < sVar5) {
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iStack_24 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar9 - iVar6)) {
              __vbaGenerateBoundsError();
            }
            iStack_24 = (sVar9 - iVar6) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(sVar9 - iVar6)) {
              __vbaGenerateBoundsError();
            }
            if (SCARRY2(DAT_0050b2c4,sVar5)) {
LAB_004b0da8:
              __vbaErrorOverflow();
              FUN_004b0dd0(&DAT_0050b25e,0x50b262);
              FUN_00435420();
              return;
            }
            uVar10 = (int)(short)(DAT_0050b2c4 + sVar5) - *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= uVar10) {
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar10 + (sVar9 - iVar6)) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar7 = __vbaGenerateBoundsError();
          }
          else {
            iVar7 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar9 - iVar7)) {
              __vbaGenerateBoundsError();
            }
            iVar7 = (sVar9 - iVar7) * 8;
          }
          *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar7) =
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + iVar6) +
               *(double *)(*(int *)(DAT_0050b0fc + 6) + iStack_24);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          iVar6 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar9 - iVar6)) {
            __vbaGenerateBoundsError();
          }
          iVar6 = (sVar9 - iVar6) * 8;
        }
        if (*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar6) != _DAT_00401490) {
          if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              iVar6 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(sVar9 - iVar6)) {
                __vbaGenerateBoundsError();
              }
              iVar6 = (sVar9 - iVar6) * 2;
            }
            uVar10 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar6) -
                     *(int *)(DAT_0050b1f8 + 10);
            if (*(uint *)(DAT_0050b1f8 + 8) <= uVar10) {
              __vbaGenerateBoundsError();
            }
            iVar6 = uVar10 * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar6) = 0xffff;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          iVar6 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar9 - iVar6)) {
            __vbaGenerateBoundsError();
          }
          iVar6 = (sVar9 - iVar6) * 8;
        }
        in_FPUStatusWord = 0;
        if (_DAT_0050b12c < *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar6)) {
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(sVar9 - iVar6)) {
              __vbaGenerateBoundsError();
            }
            iVar6 = (sVar9 - iVar6) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar7 = __vbaGenerateBoundsError();
          }
          else {
            iVar7 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar9 - iVar7)) {
              __vbaGenerateBoundsError();
            }
            iVar7 = (sVar9 - iVar7) * 8;
          }
          if (DAT_0050b000 == 0) {
            fVar12 = (float10)*(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar6) /
                     (float10)*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar7);
          }
          else {
            fVar12 = (float10)adj_fdiv_m64();
          }
          _DAT_0050b124 = (double)fVar12;
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
          fVar12 = (float10)__vbaFpR4();
          in_FPUStatusWord = 0;
          if (fVar12 < (float10)fStack_20) {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              iVar6 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(sVar9 - iVar6)) {
                __vbaGenerateBoundsError();
              }
              iVar6 = (sVar9 - iVar6) * 2;
            }
            fStack_20 = (float)_DAT_0050b124;
            DAT_0050b260._0_2_ = *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar6);
            DAT_0050b260._2_2_ = sVar9;
          }
        }
        bVar11 = SCARRY2(sVar9,1);
        sVar9 = sVar9 + 1;
        if (bVar11) goto LAB_004b0da8;
        psVar4 = DAT_0050b1f8;
      } while (sVar9 <= sVar3);
    }
    if ((psVar4 == (short *)0x0) || (*psVar4 != 1)) {
      iVar6 = __vbaGenerateBoundsError();
      psVar4 = DAT_0050b1f8;
    }
    else {
      iVar7 = (int)(short)DAT_0050b260;
      iVar6 = *(int *)(psVar4 + 10);
      if (*(uint *)(psVar4 + 8) <= (uint)(iVar7 - iVar6)) {
        __vbaGenerateBoundsError();
        psVar4 = DAT_0050b1f8;
      }
      iVar6 = (iVar7 - iVar6) * 2;
    }
    *(short *)(*(int *)(psVar4 + 6) + iVar6) = (short)DAT_0050b260;
    if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
      iVar6 = __vbaGenerateBoundsError();
    }
    else {
      iVar7 = (int)DAT_0050b260._2_2_;
      iVar6 = *(int *)(DAT_0050b1f0 + 10);
      if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar7 - iVar6)) {
        __vbaGenerateBoundsError();
      }
      iVar6 = (iVar7 - iVar6) * 2;
    }
    *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar6) = DAT_0050b25e;
    if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
      iVar6 = __vbaGenerateBoundsError();
    }
    else {
      iVar7 = (int)DAT_0050b25e;
      iVar6 = *(int *)(DAT_0050b0e8 + 10);
      if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar7 - iVar6)) {
        __vbaGenerateBoundsError();
      }
      iVar6 = (iVar7 - iVar6) * 8;
    }
    if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
      iVar7 = __vbaGenerateBoundsError();
    }
    else {
      iVar8 = (int)DAT_0050b260._2_2_;
      iVar7 = *(int *)(DAT_0050b0d8 + 10);
      if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(iVar8 - iVar7)) {
        __vbaGenerateBoundsError();
      }
      iVar7 = (iVar8 - iVar7) * 8;
    }
    iVar8 = *(int *)(DAT_0050b0d8 + 6);
    iVar1 = *(int *)(DAT_0050b0e8 + 6);
    *(undefined4 *)(iVar8 + iVar7) = *(undefined4 *)(iVar1 + iVar6);
    *(undefined4 *)(iVar8 + 4 + iVar7) = *(undefined4 *)(iVar1 + 4 + iVar6);
    return;
  }
LAB_004b0da3:
  __vbaFPException();
  return;
}


