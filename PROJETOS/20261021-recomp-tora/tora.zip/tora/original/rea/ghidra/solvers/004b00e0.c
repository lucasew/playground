/* requested 004b00e0 entry 004b00e0 name FUN_004b00e0 size 1536 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b00e0(void)

{
  int iVar1;
  short sVar2;
  short sVar3;
  short sVar4;
  short *psVar5;
  short sVar6;
  ushort uVar7;
  uint uVar8;
  int iVar9;
  uint unaff_ESI;
  int iVar10;
  code *pcVar11;
  int iVar12;
  bool bVar13;
  ushort in_FPUStatusWord;
  float10 fVar14;
  int iStack_58;
  float fStack_54;
  uint uStack_3c;
  uint local_28;
  int iStack_24;
  uint local_20;
  uint uStack_14;
  uint local_10;
  undefined4 local_c;
  
  sVar2 = (short)_DAT_0050b20c;
  local_28 = 1;
  pcVar11 = __vbaGenerateBoundsError_exref;
  if (0 < sVar2) {
    do {
      if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
        uStack_3c = 0x4b0140;
        iVar9 = (*pcVar11)();
      }
      else {
        unaff_ESI = (int)(short)local_28 - *(int *)(DAT_0050b0dc + 10);
        if (*(uint *)(DAT_0050b0dc + 8) <= unaff_ESI) {
          uStack_3c = 0x4b012f;
          (*pcVar11)();
        }
        iVar9 = unaff_ESI * 8;
      }
      iVar10 = *(int *)(DAT_0050b0dc + 6);
      uVar8 = 1;
      *(undefined4 *)(iVar10 + iVar9) = 0;
      *(undefined4 *)(iVar10 + 4 + iVar9) = 0;
      sVar4 = (short)_DAT_0050b20c;
      if (0 < sVar4) {
        do {
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            uStack_3c = 0x4b019e;
            iStack_24 = (*pcVar11)();
          }
          else {
            iVar9 = *(int *)(DAT_0050b0dc + 10);
            if (*(uint *)(DAT_0050b0dc + 8) <= (uint)((short)local_28 - iVar9)) {
              uStack_3c = 0x4b018f;
              (*pcVar11)();
            }
            iStack_24 = ((short)local_28 - iVar9) * 8;
          }
          sVar3 = (short)uVar8;
          if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
            uStack_3c = 0x4b01cd;
            iVar9 = (*pcVar11)();
          }
          else {
            iVar9 = *(int *)(DAT_0050b0d8 + 10);
            if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(sVar3 - iVar9)) {
              uStack_3c = 0x4b01c2;
              (*pcVar11)();
            }
            iVar9 = (sVar3 - iVar9) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            uStack_3c = 0x4b0221;
            unaff_ESI = (*pcVar11)();
          }
          else {
            iVar10 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(sVar3 - iVar10)) {
              uStack_3c = 0x4b01f1;
              (*pcVar11)();
            }
            iVar12 = *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)((short)local_28 - iVar12)) {
              uStack_3c = 0x4b020d;
              __vbaGenerateBoundsError();
            }
            unaff_ESI = (*(int *)(DAT_0050b0c4 + 0xc) * ((short)local_28 - iVar12) +
                        (sVar3 - iVar10)) * 8;
          }
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            uStack_3c = 0x4b0263;
            iVar10 = __vbaGenerateBoundsError();
          }
          else {
            iVar10 = *(int *)(DAT_0050b0dc + 10);
            if (*(uint *)(DAT_0050b0dc + 8) <= (uint)((short)local_28 - iVar10)) {
              uStack_3c = 0x4b024f;
              __vbaGenerateBoundsError();
            }
            iVar10 = ((short)local_28 - iVar10) * 8;
          }
          pcVar11 = __vbaGenerateBoundsError_exref;
          *(double *)(*(int *)(DAT_0050b0dc + 6) + iVar10) =
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + unaff_ESI) *
               *(double *)(*(int *)(DAT_0050b0d8 + 6) + iVar9) +
               *(double *)(*(int *)(DAT_0050b0dc + 6) + iStack_24);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
          uVar8 = (uint)(ushort)(sVar3 + 1U);
          if (SCARRY2(sVar3,1)) goto LAB_004b06ce;
        } while ((short)(sVar3 + 1U) <= sVar4);
      }
      bVar13 = SCARRY2((short)local_28,1);
      uVar7 = (short)local_28 + 1;
      local_28 = (uint)uVar7;
      if (bVar13) goto LAB_004b06ce;
    } while ((short)uVar7 <= sVar2);
  }
  sVar2 = DAT_0050b20a;
  DAT_0050b25e = 0;
  local_10 = 0;
  local_c = 0;
  local_20 = 1;
  if (0 < DAT_0050b20a) {
    do {
      uVar8 = 0;
      sVar4 = (short)local_20;
      if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
        uStack_3c = 0x4b0339;
        iVar9 = (*pcVar11)();
      }
      else {
        unaff_ESI = (int)sVar4 - *(int *)(DAT_0050b0f0 + 10);
        if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
          uStack_3c = 0x4b0328;
          (*pcVar11)();
        }
        iVar9 = unaff_ESI * 8;
      }
      iVar10 = *(int *)(DAT_0050b0f0 + 6);
      *(undefined4 *)(iVar10 + iVar9) = 0;
      *(undefined4 *)(iVar10 + 4 + iVar9) = 0;
      if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
        uStack_3c = 0x4b0377;
        iVar9 = (*pcVar11)();
      }
      else {
        unaff_ESI = (int)sVar4 - *(int *)(DAT_0050b1f8 + 10);
        if (*(uint *)(DAT_0050b1f8 + 8) <= unaff_ESI) {
          uStack_3c = 0x4b036a;
          (*pcVar11)();
        }
        iVar9 = unaff_ESI * 2;
      }
      if (0 < *(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar9)) {
        iVar9 = (int)sVar4;
        uStack_14 = (uint)((ulonglong)(double)(int)DAT_0050b2c6 >> 0x20);
        if (DAT_0050b000 != 0) {
          uStack_3c = uStack_14;
          adj_fdiv_m64();
        }
        if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004b06c9:
          __vbaFPException();
          return;
        }
        uStack_3c = 0x4b03e2;
        __vbaFPInt();
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        uStack_3c = 0x4b03f8;
        sVar3 = __vbaFpI2();
        sVar6 = sVar4 % DAT_0050b2c6;
        if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
          uStack_3c = 0x4b0435;
          uVar8 = (*pcVar11)();
        }
        else {
          iVar10 = *(int *)(DAT_0050b0dc + 10);
          if (*(uint *)(DAT_0050b0dc + 8) <= (uint)(sVar3 - iVar10)) {
            uStack_3c = 0x4b042a;
            (*pcVar11)();
          }
          uVar8 = (sVar3 - iVar10) * 8;
        }
        if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
          uStack_3c = 0x4b0463;
          iVar10 = (*pcVar11)();
        }
        else {
          iVar10 = *(int *)(DAT_0050b0e8 + 10);
          if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar9 - iVar10)) {
            uStack_3c = 0x4b0458;
            (*pcVar11)();
          }
          iVar10 = (iVar9 - iVar10) * 8;
        }
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          uStack_3c = 0x4b0496;
          iVar12 = (*pcVar11)();
        }
        else {
          iVar12 = *(int *)(DAT_0050b0f0 + 10);
          if (*(uint *)(DAT_0050b0f0 + 8) <= (uint)(iVar9 - iVar12)) {
            uStack_3c = 0x4b0485;
            (*pcVar11)();
          }
          iVar12 = (iVar9 - iVar12) * 8;
        }
        unaff_ESI = *(uint *)(DAT_0050b0e8 + 6);
        *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar12) =
             *(double *)(*(int *)(DAT_0050b0dc + 6) + uVar8) - *(double *)(unaff_ESI + iVar10);
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        if (0 < sVar6) {
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            uStack_3c = 0x4b0507;
            uVar8 = (*pcVar11)();
          }
          else {
            unaff_ESI = iVar9 - *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
              uStack_3c = 0x4b04f7;
              (*pcVar11)();
            }
            uVar8 = unaff_ESI * 8;
          }
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            uStack_3c = 0x4b054f;
            iVar10 = (*pcVar11)();
          }
          else {
            local_28 = *(uint *)(DAT_0050b0dc + 10);
            if (SCARRY2(DAT_0050b2c4,sVar6)) goto LAB_004b06ce;
            unaff_ESI = (int)(short)(DAT_0050b2c4 + sVar6) - local_28;
            if (*(uint *)(DAT_0050b0dc + 8) <= unaff_ESI) {
              uStack_3c = 0x4b053f;
              (*pcVar11)();
            }
            iVar10 = unaff_ESI * 8;
          }
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            uStack_3c = 0x4b0582;
            iVar12 = (*pcVar11)();
          }
          else {
            unaff_ESI = iVar9 - *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
              uStack_3c = 0x4b0572;
              (*pcVar11)();
            }
            iVar12 = unaff_ESI * 8;
          }
          *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar12) =
               *(double *)(*(int *)(DAT_0050b0dc + 6) + iVar10) +
               *(double *)(*(int *)(DAT_0050b0f0 + 6) + uVar8);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        }
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          uStack_3c = 0x4b05dc;
          iVar10 = (*pcVar11)();
        }
        else {
          unaff_ESI = iVar9 - *(int *)(DAT_0050b0f0 + 10);
          if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
            uStack_3c = 0x4b05cb;
            (*pcVar11)();
          }
          iVar10 = unaff_ESI * 8;
        }
        in_FPUStatusWord = 0;
        if ((double)CONCAT44(local_c,local_10) < *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar10)) {
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            uStack_3c = 0x4b061e;
            iVar9 = (*pcVar11)();
          }
          else {
            iVar10 = *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= (uint)(iVar9 - iVar10)) {
              uStack_3c = 0x4b060d;
              (*pcVar11)();
            }
            iVar9 = (iVar9 - iVar10) * 8;
          }
          unaff_ESI = *(uint *)(*(int *)(DAT_0050b0f0 + 6) + iVar9);
          local_c = *(undefined4 *)(*(int *)(DAT_0050b0f0 + 6) + 4 + iVar9);
          DAT_0050b25e = sVar4;
          local_10 = unaff_ESI;
        }
      }
      local_28 = (uint)(ushort)(sVar4 + 1U);
      if (SCARRY2(sVar4,1)) goto LAB_004b06ce;
      local_20 = local_28;
    } while ((short)(sVar4 + 1U) <= sVar2);
    if (0 < DAT_0050b25e) {
      if ((DAT_0050b1f8 != (short *)0x0) && (*DAT_0050b1f8 == 1)) {
        iVar9 = *(int *)(DAT_0050b1f8 + 10);
        iVar10 = (int)DAT_0050b25e;
        if (*(uint *)(DAT_0050b1f8 + 8) <= (uint)(iVar10 - iVar9)) {
          uStack_3c = 0x4b0696;
          (*pcVar11)();
        }
        *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + (iVar10 - iVar9) * 2) = 0;
        return;
      }
      uStack_3c = 0x4b06b2;
      iVar9 = (*pcVar11)();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar9) = 0;
    }
  }
  return;
LAB_004b06ce:
  uStack_3c = 0x4b06d4;
  __vbaErrorOverflow();
  DAT_0050b260._0_2_ = 0;
  DAT_0050b260._2_2_ = 0;
  uStack_3c = uVar8;
  if (DAT_0050b000 != 0) {
    adj_fdiv_m64((double)(int)DAT_0050b2c6,pcVar11,unaff_ESI,&uStack_3c,local_28);
  }
  if (((in_FPUStatusWord & 0xd) == 0) && (__vbaFPInt(), (in_FPUStatusWord & 0xd) == 0)) {
    sVar4 = __vbaFpI2();
    sVar2 = DAT_0050b20a;
    sVar3 = DAT_0050b25e % DAT_0050b2c6;
    sVar6 = 1;
    psVar5 = DAT_0050b1f8;
    if (0 < DAT_0050b20a) {
      do {
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          iVar9 = __vbaGenerateBoundsError();
          psVar5 = DAT_0050b1f8;
        }
        else {
          iVar9 = *(int *)(psVar5 + 10);
          if (*(uint *)(psVar5 + 8) <= (uint)(sVar6 - iVar9)) {
            __vbaGenerateBoundsError();
            psVar5 = DAT_0050b1f8;
          }
          iVar9 = (sVar6 - iVar9) * 2;
        }
        if (*(short *)(*(int *)(psVar5 + 6) + iVar9) < 0) {
          if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
            iVar9 = __vbaGenerateBoundsError();
            psVar5 = DAT_0050b1f8;
          }
          else {
            iVar9 = *(int *)(psVar5 + 10);
            if (*(uint *)(psVar5 + 8) <= (uint)(sVar6 - iVar9)) {
              __vbaGenerateBoundsError();
              psVar5 = DAT_0050b1f8;
            }
            iVar9 = (sVar6 - iVar9) * 2;
          }
          *(undefined2 *)(*(int *)(psVar5 + 6) + iVar9) = 0;
          psVar5 = DAT_0050b1f8;
        }
        bVar13 = SCARRY2(sVar6,1);
        sVar6 = sVar6 + 1;
        if (bVar13) goto LAB_004b0da8;
      } while (sVar6 <= sVar2);
    }
    sVar6 = 1;
    sVar2 = (short)_DAT_0050b20c;
    if (0 < sVar2) {
      do {
        if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
          iVar9 = __vbaGenerateBoundsError();
        }
        else {
          iVar10 = (int)sVar6;
          iVar9 = *(int *)(DAT_0050b0c4 + 0xe);
          if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar10 - iVar9)) {
            __vbaGenerateBoundsError();
          }
          iVar12 = *(int *)(DAT_0050b0c4 + 10);
          if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(sVar4 - iVar12)) {
            __vbaGenerateBoundsError();
          }
          iVar9 = (*(int *)(DAT_0050b0c4 + 0xc) * (sVar4 - iVar12) + (iVar10 - iVar9)) * 8;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          iVar12 = (int)sVar6;
          iVar10 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar12 - iVar10)) {
            __vbaGenerateBoundsError();
          }
          iVar10 = (iVar12 - iVar10) * 8;
        }
        iVar12 = *(int *)(DAT_0050b0c4 + 6);
        iVar1 = *(int *)(DAT_0050b0fc + 6);
        *(undefined4 *)(iVar1 + iVar10) = *(undefined4 *)(iVar12 + iVar9);
        *(undefined4 *)(iVar1 + 4 + iVar10) = *(undefined4 *)(iVar12 + 4 + iVar9);
        if (0 < sVar3) {
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iStack_58 = __vbaGenerateBoundsError();
          }
          else {
            iVar10 = (int)sVar6;
            iVar9 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar10 - iVar9)) {
              __vbaGenerateBoundsError();
            }
            iStack_58 = (iVar10 - iVar9) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            iVar9 = __vbaGenerateBoundsError();
          }
          else {
            iVar10 = (int)sVar6;
            iVar9 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar10 - iVar9)) {
              __vbaGenerateBoundsError();
            }
            if (SCARRY2(DAT_0050b2c4,sVar3)) {
LAB_004b0da8:
              __vbaErrorOverflow();
              FUN_004b0dd0(&DAT_0050b25e,0x50b262);
              FUN_00435420();
              return;
            }
            uVar8 = (int)(short)(DAT_0050b2c4 + sVar3) - *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= uVar8) {
              __vbaGenerateBoundsError();
            }
            iVar9 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar8 + (iVar10 - iVar9)) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar10 = __vbaGenerateBoundsError();
          }
          else {
            iVar12 = (int)sVar6;
            iVar10 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar12 - iVar10)) {
              __vbaGenerateBoundsError();
            }
            iVar10 = (iVar12 - iVar10) * 8;
          }
          *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar10) =
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + iVar9) +
               *(double *)(*(int *)(DAT_0050b0fc + 6) + iStack_58);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar9 = __vbaGenerateBoundsError();
        }
        else {
          iVar9 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar6 - iVar9)) {
            __vbaGenerateBoundsError();
          }
          iVar9 = (sVar6 - iVar9) * 8;
        }
        if (*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar9) != _DAT_00401490) {
          if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
            iVar9 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              iVar9 = __vbaGenerateBoundsError();
            }
            else {
              iVar9 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(sVar6 - iVar9)) {
                __vbaGenerateBoundsError();
              }
              iVar9 = (sVar6 - iVar9) * 2;
            }
            uVar8 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar9) -
                    *(int *)(DAT_0050b1f8 + 10);
            if (*(uint *)(DAT_0050b1f8 + 8) <= uVar8) {
              __vbaGenerateBoundsError();
            }
            iVar9 = uVar8 * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar9) = 0xffff;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar9 = __vbaGenerateBoundsError();
        }
        else {
          iVar9 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar6 - iVar9)) {
            __vbaGenerateBoundsError();
          }
          iVar9 = (sVar6 - iVar9) * 8;
        }
        in_FPUStatusWord = 0;
        if (_DAT_0050b12c < *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar9)) {
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            iVar9 = __vbaGenerateBoundsError();
          }
          else {
            iVar9 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(sVar6 - iVar9)) {
              __vbaGenerateBoundsError();
            }
            iVar9 = (sVar6 - iVar9) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar10 = __vbaGenerateBoundsError();
          }
          else {
            iVar10 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar6 - iVar10)) {
              __vbaGenerateBoundsError();
            }
            iVar10 = (sVar6 - iVar10) * 8;
          }
          if (DAT_0050b000 == 0) {
            fVar14 = (float10)*(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar9) /
                     (float10)*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar10);
          }
          else {
            fVar14 = (float10)adj_fdiv_m64();
          }
          _DAT_0050b124 = (double)fVar14;
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
          fVar14 = (float10)__vbaFpR4();
          in_FPUStatusWord = 0;
          if (fVar14 < (float10)fStack_54) {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              iVar9 = __vbaGenerateBoundsError();
            }
            else {
              iVar9 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(sVar6 - iVar9)) {
                __vbaGenerateBoundsError();
              }
              iVar9 = (sVar6 - iVar9) * 2;
            }
            fStack_54 = (float)_DAT_0050b124;
            DAT_0050b260._0_2_ = *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar9);
            DAT_0050b260._2_2_ = sVar6;
          }
        }
        bVar13 = SCARRY2(sVar6,1);
        sVar6 = sVar6 + 1;
        if (bVar13) goto LAB_004b0da8;
        psVar5 = DAT_0050b1f8;
      } while (sVar6 <= sVar2);
    }
    if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
      iVar9 = __vbaGenerateBoundsError();
      psVar5 = DAT_0050b1f8;
    }
    else {
      iVar10 = (int)(short)DAT_0050b260;
      iVar9 = *(int *)(psVar5 + 10);
      if (*(uint *)(psVar5 + 8) <= (uint)(iVar10 - iVar9)) {
        __vbaGenerateBoundsError();
        psVar5 = DAT_0050b1f8;
      }
      iVar9 = (iVar10 - iVar9) * 2;
    }
    *(short *)(*(int *)(psVar5 + 6) + iVar9) = (short)DAT_0050b260;
    if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
      iVar9 = __vbaGenerateBoundsError();
    }
    else {
      iVar10 = (int)DAT_0050b260._2_2_;
      iVar9 = *(int *)(DAT_0050b1f0 + 10);
      if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar10 - iVar9)) {
        __vbaGenerateBoundsError();
      }
      iVar9 = (iVar10 - iVar9) * 2;
    }
    *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar9) = DAT_0050b25e;
    if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
      iVar9 = __vbaGenerateBoundsError();
    }
    else {
      iVar10 = (int)DAT_0050b25e;
      iVar9 = *(int *)(DAT_0050b0e8 + 10);
      if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar10 - iVar9)) {
        __vbaGenerateBoundsError();
      }
      iVar9 = (iVar10 - iVar9) * 8;
    }
    if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
      iVar10 = __vbaGenerateBoundsError();
    }
    else {
      iVar12 = (int)DAT_0050b260._2_2_;
      iVar10 = *(int *)(DAT_0050b0d8 + 10);
      if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(iVar12 - iVar10)) {
        __vbaGenerateBoundsError();
      }
      iVar10 = (iVar12 - iVar10) * 8;
    }
    iVar12 = *(int *)(DAT_0050b0d8 + 6);
    iVar1 = *(int *)(DAT_0050b0e8 + 6);
    *(undefined4 *)(iVar12 + iVar10) = *(undefined4 *)(iVar1 + iVar9);
    *(undefined4 *)(iVar12 + 4 + iVar10) = *(undefined4 *)(iVar1 + 4 + iVar9);
    return;
  }
LAB_004b0da3:
  __vbaFPException();
  return;
}


