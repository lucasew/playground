/* requested 00435420 entry 00435420 name FUN_00435420 size 8060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00435420(void)

{
  double dVar1;
  undefined2 uVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int extraout_ECX;
  undefined2 extraout_DX;
  code *pcVar10;
  uint uVar11;
  ushort in_FPUStatusWord;
  float10 fVar12;
  undefined4 *puVar13;
  undefined4 local_2f8 [4];
  undefined4 local_2e8 [4];
  undefined4 local_2d8 [4];
  undefined4 local_2c8 [4];
  undefined4 local_2b8 [4];
  undefined4 local_2a8 [4];
  undefined4 local_298 [4];
  undefined4 local_288 [4];
  undefined4 local_278 [4];
  undefined4 local_268 [4];
  undefined4 local_258 [4];
  undefined4 local_248 [4];
  undefined4 local_238 [4];
  undefined4 local_228 [4];
  undefined4 local_218 [4];
  undefined4 local_208 [4];
  undefined4 local_1f8 [4];
  undefined4 local_1e8 [4];
  undefined4 local_1d8 [4];
  undefined4 local_1c8 [4];
  undefined4 local_1b8 [4];
  undefined4 local_1a8 [4];
  undefined4 local_198 [4];
  undefined4 local_188 [4];
  undefined4 local_178 [4];
  undefined4 local_168 [4];
  undefined4 local_158 [4];
  undefined4 local_148 [4];
  undefined4 local_138 [4];
  undefined4 local_128 [4];
  undefined4 local_118 [4];
  undefined4 local_108 [4];
  undefined4 local_f8 [4];
  undefined4 local_e8 [9];
  undefined4 local_c4 [2];
  undefined4 local_bc;
  undefined4 local_b4 [2];
  undefined4 local_ac;
  undefined4 local_a4 [2];
  undefined4 local_9c;
  undefined4 local_94 [4];
  undefined4 local_84 [4];
  undefined4 local_74 [4];
  undefined4 local_64 [4];
  undefined4 local_54 [4];
  undefined4 local_44 [4];
  undefined4 local_34 [4];
  undefined4 local_24 [4];
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffcb8;
  local_8 = &DAT_00401a88;
  DAT_0050b202 = DAT_0050b20c;
  local_ac = CONCAT22(local_ac._2_2_,DAT_0050b20c);
  local_24[0] = 0;
  local_34[0] = 0;
  local_44[0] = 0;
  local_54[0] = 0;
  local_64[0] = 0;
  local_74[0] = 0;
  local_84[0] = 0;
  local_94[0] = 0;
  local_e8[0] = 0;
  local_f8[0] = 0;
  local_108[0] = 0;
  local_118[0] = 0;
  local_128[0] = 0;
  local_138[0] = 0;
  local_148[0] = 0;
  local_158[0] = 0;
  local_168[0] = 0;
  local_178[0] = 0;
  local_188[0] = 0;
  local_198[0] = 0;
  local_1a8[0] = 0;
  local_1b8[0] = 0;
  local_1c8[0] = 0;
  local_1d8[0] = 0;
  local_1e8[0] = 0;
  local_1f8[0] = 0;
  local_208[0] = 0;
  local_218[0] = 0;
  local_228[0] = 0;
  local_238[0] = 0;
  local_248[0] = 0;
  local_258[0] = 0;
  local_268[0] = 0;
  local_278[0] = 0;
  local_288[0] = 0;
  local_298[0] = 0;
  local_2a8[0] = 0;
  local_2b8[0] = 0;
  local_2c8[0] = 0;
  local_2d8[0] = 0;
  local_2e8[0] = 0;
  local_2f8[0] = 0;
  _DAT_0050b144 = 1.0;
  local_9c = 1;
  local_a4[0] = 2;
  local_b4[0] = 2;
  local_bc = 1;
  local_c4[0] = 2;
  ExceptionList = &pvStack_14;
  iVar4 = __vbaVarForInit(local_24,local_e8,local_f8,local_c4,local_b4,local_a4);
  pcVar10 = __vbaGenerateBoundsError_exref;
  while (iVar4 != 0) {
    if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
      iVar4 = __vbaGenerateBoundsError();
    }
    else {
      iVar5 = __vbaI4Var(local_24);
      iVar4 = *(int *)(DAT_0050b1dc + 10);
      if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar5 - iVar4)) {
        __vbaGenerateBoundsError();
      }
      iVar4 = (iVar5 - iVar4) * 2;
    }
    uVar2 = __vbaI2Var(local_24);
    *(undefined2 *)(*(int *)(DAT_0050b1dc + 6) + iVar4) = uVar2;
    local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
    DAT_0050b104 = 0;
    DAT_0050b108 = 0;
    local_a4[0] = 2;
    local_b4[0] = 2;
    local_c4[0] = 2;
    local_9c = 1;
    local_bc = 1;
    iVar4 = __vbaVarForInit(local_34,local_108,local_118,local_c4,local_b4,local_a4);
    while (iVar4 != 0) {
      if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
        iVar4 = __vbaGenerateBoundsError();
      }
      else {
        iVar5 = __vbaI4Var(local_24);
        iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
        if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
          __vbaGenerateBoundsError();
        }
        iVar6 = __vbaI4Var(local_34);
        iVar8 = *(int *)(DAT_0050b0c0 + 10);
        if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
          __vbaGenerateBoundsError();
        }
        iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
      }
      _DAT_0050b13c = ABS(*(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4));
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
      in_FPUStatusWord = 0;
      dVar1 = (double)CONCAT44(DAT_0050b108,DAT_0050b104);
      if ((double)CONCAT44(DAT_0050b108,DAT_0050b104) < _DAT_0050b13c) {
        dVar1 = _DAT_0050b13c;
      }
      DAT_0050b108 = (undefined4)((ulonglong)dVar1 >> 0x20);
      DAT_0050b104 = SUB84(dVar1,0);
      iVar4 = __vbaVarForNext(local_34,local_108,local_118);
    }
    in_FPUStatusWord = 0;
    if ((double)CONCAT44(DAT_0050b108,DAT_0050b104) == _DAT_00401490) {
      _DAT_0050b144 = 0.0;
      goto LAB_0043727e;
    }
    if ((DAT_0050b0d0 == (short *)0x0) || (*DAT_0050b0d0 != 1)) {
      iVar4 = __vbaGenerateBoundsError();
    }
    else {
      iVar5 = __vbaI4Var(local_24);
      iVar4 = *(int *)(DAT_0050b0d0 + 10);
      if (*(uint *)(DAT_0050b0d0 + 8) <= (uint)(iVar5 - iVar4)) {
        __vbaGenerateBoundsError();
      }
      iVar4 = (iVar5 - iVar4) * 8;
    }
    if (DAT_0050b000 == 0) {
      fVar12 = (float10)_DAT_00401880 / (float10)(double)CONCAT44(DAT_0050b108,DAT_0050b104);
    }
    else {
      fVar12 = (float10)adj_fdiv_m64();
      iVar4 = extraout_ECX;
    }
    *(double *)(*(int *)(DAT_0050b0d0 + 6) + iVar4) = (double)fVar12;
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
    iVar4 = __vbaVarForNext(local_24,local_e8,local_f8);
  }
  local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
  local_9c = 1;
  local_a4[0] = 2;
  local_b4[0] = 2;
  local_bc = 1;
  local_c4[0] = 2;
  iVar4 = __vbaVarForInit(local_34,local_128,local_138,local_c4,local_b4,local_a4);
  do {
    local_9c = 1;
    if (iVar4 == 0) {
      local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
      local_a4[0] = 2;
      local_b4[0] = 2;
      local_bc = 1;
      local_c4[0] = 2;
      iVar4 = __vbaVarForInit(local_24,local_218,local_228,local_c4,local_b4,local_a4);
      while (iVar4 != 0) {
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_24);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar6 = __vbaI4Var(local_24);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            (*pcVar10)();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        _DAT_0050b144 = _DAT_0050b144 * *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
        if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004373b5:
          __vbaFPException();
          return;
        }
        iVar4 = __vbaVarForNext(local_24,local_218,local_228);
      }
      local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
      local_9c = 1;
      local_a4[0] = 2;
      local_b4[0] = 2;
      local_bc = 1;
      local_c4[0] = 2;
      iVar4 = __vbaVarForInit(local_54,local_238,local_248,local_c4,local_b4,local_a4);
      while (iVar4 != 0) {
        local_9c = 0;
        local_a4[0] = 2;
        __vbaVarMove();
        local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
        puVar13 = local_b4;
        local_9c = 1;
        local_a4[0] = 2;
        local_b4[0] = 2;
        local_bc = 1;
        local_c4[0] = 2;
        iVar4 = __vbaVarForInit(local_64,local_258,local_268,local_c4,puVar13,local_a4);
        while (iVar4 != 0) {
          if ((DAT_0050b0c8 == (short *)0x0) || (*DAT_0050b0c8 != 1)) {
            iVar4 = (*pcVar10)();
          }
          else {
            iVar5 = __vbaI4Var(local_64);
            iVar4 = *(int *)(DAT_0050b0c8 + 10);
            if (*(uint *)(DAT_0050b0c8 + 8) <= (uint)(iVar5 - iVar4)) {
              (*pcVar10)();
            }
            iVar4 = (iVar5 - iVar4) * 8;
          }
          iVar5 = *(int *)(DAT_0050b0c8 + 6);
          *(undefined4 *)(iVar5 + iVar4) = 0;
          *(undefined4 *)(iVar5 + 4 + iVar4) = 0;
          iVar4 = __vbaVarForNext(local_64,local_258,local_268);
        }
        if ((DAT_0050b0c8 == (short *)0x0) || (*DAT_0050b0c8 != 1)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_54);
          iVar4 = *(int *)(DAT_0050b0c8 + 10);
          if (*(uint *)(DAT_0050b0c8 + 8) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar4 = (iVar5 - iVar4) * 8;
        }
        iVar5 = *(int *)(DAT_0050b0c8 + 6);
        *(undefined4 *)(iVar5 + iVar4) = 0;
        *(undefined4 *)(iVar5 + 4 + iVar4) = 0x3ff00000;
        local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
        local_9c = 1;
        local_a4[0] = 2;
        local_b4[0] = 2;
        local_bc = 1;
        local_c4[0] = 2;
        iVar4 = __vbaVarForInit(local_24,local_278,local_288,local_c4,local_b4,local_a4);
        while (iVar4 != 0) {
          if ((DAT_0050b0c8 == (short *)0x0) || (*DAT_0050b0c8 != 1)) {
            iVar4 = (*pcVar10)();
          }
          else {
            iVar5 = __vbaI4Var(local_24);
            iVar4 = *(int *)(DAT_0050b0c8 + 10);
            if (*(uint *)(DAT_0050b0c8 + 8) <= (uint)(iVar5 - iVar4)) {
              (*pcVar10)();
            }
            iVar4 = (iVar5 - iVar4) * 8;
          }
          _DAT_0050b114 =
               (double)CONCAT44(*(undefined4 *)(*(int *)(DAT_0050b0c8 + 6) + 4 + iVar4),
                                *(undefined4 *)(*(int *)(DAT_0050b0c8 + 6) + iVar4));
          local_9c = 0;
          local_a4[0] = 0x8002;
          sVar3 = __vbaVarTstGt(local_a4,local_74);
          if (sVar3 == 0) {
            in_FPUStatusWord = 0;
            if (_DAT_0050b114 != _DAT_00401490) {
              __vbaVarCopy();
            }
          }
          else {
            local_ac = 1;
            local_b4[0] = 2;
            local_9c = 1;
            local_a4[0] = 2;
            uVar7 = __vbaVarSub(local_94,local_a4,local_24,local_b4);
            iVar4 = __vbaVarForInit(local_34,local_298,local_2a8,local_74,uVar7);
            while (iVar4 != 0) {
              if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
                iVar4 = __vbaGenerateBoundsError();
              }
              else {
                iVar5 = __vbaI4Var(local_24);
                iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
                if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
                  __vbaGenerateBoundsError();
                }
                iVar6 = __vbaI4Var(local_34);
                iVar8 = *(int *)(DAT_0050b0c0 + 10);
                if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
                  __vbaGenerateBoundsError();
                }
                iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
              }
              if ((DAT_0050b0c8 == (short *)0x0) || (*DAT_0050b0c8 != 1)) {
                iVar5 = __vbaGenerateBoundsError();
              }
              else {
                iVar8 = __vbaI4Var(local_34);
                iVar5 = *(int *)(DAT_0050b0c8 + 10);
                if (*(uint *)(DAT_0050b0c8 + 8) <= (uint)(iVar8 - iVar5)) {
                  __vbaGenerateBoundsError();
                }
                iVar5 = (iVar8 - iVar5) * 8;
              }
              _DAT_0050b114 =
                   _DAT_0050b114 -
                   *(double *)(*(int *)(DAT_0050b0c8 + 6) + iVar5) *
                   *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
              if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
              iVar4 = __vbaVarForNext(local_34,local_298,local_2a8);
              pcVar10 = __vbaGenerateBoundsError_exref;
            }
          }
          if ((DAT_0050b0c8 == (short *)0x0) || (*DAT_0050b0c8 != 1)) {
            iVar4 = (*pcVar10)();
          }
          else {
            iVar5 = __vbaI4Var(local_24);
            iVar4 = *(int *)(DAT_0050b0c8 + 10);
            if (*(uint *)(DAT_0050b0c8 + 8) <= (uint)(iVar5 - iVar4)) {
              (*pcVar10)();
            }
            iVar4 = (iVar5 - iVar4) * 8;
          }
          iVar5 = *(int *)(DAT_0050b0c8 + 6);
          *(undefined4 *)(iVar5 + iVar4) = DAT_0050b114;
          *(undefined4 *)(iVar5 + 4 + iVar4) = DAT_0050b118;
          iVar4 = __vbaVarForNext(local_24,local_278,local_288);
        }
        local_bc = CONCAT22(local_bc._2_2_,DAT_0050b202);
        local_9c = 0xffffffff;
        local_a4[0] = 2;
        local_ac = 1;
        local_b4[0] = 2;
        local_c4[0] = 2;
        iVar4 = __vbaVarForInit(local_24,local_2b8,local_2c8,local_c4,local_b4,local_a4);
        while (iVar4 != 0) {
          if ((DAT_0050b0c8 == (short *)0x0) || (*DAT_0050b0c8 != 1)) {
            iVar4 = (*pcVar10)();
          }
          else {
            iVar5 = __vbaI4Var(local_24);
            iVar4 = *(int *)(DAT_0050b0c8 + 10);
            if (*(uint *)(DAT_0050b0c8 + 8) <= (uint)(iVar5 - iVar4)) {
              (*pcVar10)();
            }
            iVar4 = (iVar5 - iVar4) * 8;
          }
          _DAT_0050b114 =
               (double)CONCAT44(*(undefined4 *)(*(int *)(DAT_0050b0c8 + 6) + 4 + iVar4),
                                *(undefined4 *)(*(int *)(DAT_0050b0c8 + 6) + iVar4));
          local_9c = CONCAT22(local_9c._2_2_,DAT_0050b202);
          local_a4[0] = 0x8002;
          sVar3 = __vbaVarTstLt(local_a4,local_24);
          if (sVar3 != 0) {
            local_bc = CONCAT22(local_bc._2_2_,DAT_0050b202);
            local_ac = 1;
            local_b4[0] = 2;
            local_c4[0] = 2;
            local_9c = 1;
            local_a4[0] = 2;
            __vbaVarAdd(local_94,local_a4,local_24);
            __vbaVarMove();
            iVar4 = __vbaVarForInit(local_34,local_2e8,local_2f8,local_2d8,local_c4,local_b4);
            while (iVar4 != 0) {
              if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
                iVar4 = (*pcVar10)();
              }
              else {
                iVar5 = __vbaI4Var(local_24);
                iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
                if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
                  __vbaGenerateBoundsError();
                }
                iVar6 = __vbaI4Var(local_34);
                iVar8 = *(int *)(DAT_0050b0c0 + 10);
                if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
                  __vbaGenerateBoundsError();
                }
                iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
              }
              if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
                iVar5 = __vbaGenerateBoundsError();
              }
              else {
                iVar8 = __vbaI4Var(local_34);
                iVar5 = *(int *)(DAT_0050b0c4 + 0xe);
                if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar8 - iVar5)) {
                  __vbaGenerateBoundsError();
                }
                if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
                  iVar6 = __vbaGenerateBoundsError();
                }
                else {
                  iVar9 = __vbaI4Var(local_54);
                  iVar6 = *(int *)(DAT_0050b1dc + 10);
                  if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar9 - iVar6)) {
                    __vbaGenerateBoundsError();
                  }
                  iVar6 = (iVar9 - iVar6) * 2;
                }
                uVar11 = (int)*(short *)(*(int *)(DAT_0050b1dc + 6) + iVar6) -
                         *(int *)(DAT_0050b0c4 + 10);
                if (*(uint *)(DAT_0050b0c4 + 8) <= uVar11) {
                  __vbaGenerateBoundsError();
                }
                iVar5 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar11 + (iVar8 - iVar5)) * 8;
              }
              puVar13 = local_2f8;
              _DAT_0050b114 =
                   _DAT_0050b114 -
                   *(double *)(*(int *)(DAT_0050b0c4 + 6) + iVar5) *
                   *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
              if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
              iVar4 = __vbaVarForNext(local_34,local_2e8);
              pcVar10 = __vbaGenerateBoundsError_exref;
            }
          }
          if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
            iVar4 = (*pcVar10)();
          }
          else {
            iVar5 = __vbaI4Var(local_24);
            iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
            if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
              (*pcVar10)();
            }
            iVar6 = __vbaI4Var(local_24);
            iVar8 = *(int *)(DAT_0050b0c0 + 10);
            if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
              (*pcVar10)();
            }
            iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
          }
          if (DAT_0050b000 == 0) {
            fVar12 = (float10)_DAT_0050b114 /
                     (float10)*(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
          }
          else {
            puVar13 = *(undefined4 **)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
            fVar12 = (float10)adj_fdiv_m64();
          }
          _DAT_0050b10c = (double)fVar12;
          if (((in_FPUStatusWord & 0xd) != 0) || ((in_FPUStatusWord & 0xd) != 0)) goto LAB_004373b5;
          fVar12 = (float10)__vbaFpR8(puVar13);
          in_FPUStatusWord = 0;
          if ((float10)_DAT_0050b12c < fVar12) {
            if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
              iVar4 = (*pcVar10)();
            }
            else {
              iVar5 = __vbaI4Var(local_24);
              iVar4 = *(int *)(DAT_0050b0c4 + 0xe);
              if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar5 - iVar4)) {
                (*pcVar10)();
              }
              if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
                iVar8 = (*pcVar10)();
              }
              else {
                iVar6 = __vbaI4Var(local_54);
                iVar8 = *(int *)(DAT_0050b1dc + 10);
                if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar6 - iVar8)) {
                  (*pcVar10)();
                }
                iVar8 = (iVar6 - iVar8) * 2;
              }
              uVar11 = (int)*(short *)(*(int *)(DAT_0050b1dc + 6) + iVar8) -
                       *(int *)(DAT_0050b0c4 + 10);
              if (*(uint *)(DAT_0050b0c4 + 8) <= uVar11) {
                (*pcVar10)();
              }
              iVar4 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar11 + (iVar5 - iVar4)) * 8;
            }
            iVar5 = *(int *)(DAT_0050b0c4 + 6);
            *(undefined4 *)(iVar5 + iVar4) = DAT_0050b10c;
            *(undefined4 *)(iVar5 + 4 + iVar4) = DAT_0050b110;
          }
          else {
            if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
              iVar4 = (*pcVar10)();
            }
            else {
              iVar5 = __vbaI4Var(local_24);
              iVar4 = *(int *)(DAT_0050b0c4 + 0xe);
              if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar5 - iVar4)) {
                (*pcVar10)();
              }
              if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
                iVar8 = (*pcVar10)();
              }
              else {
                iVar6 = __vbaI4Var(local_54);
                iVar8 = *(int *)(DAT_0050b1dc + 10);
                if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar6 - iVar8)) {
                  (*pcVar10)();
                }
                iVar8 = (iVar6 - iVar8) * 2;
              }
              uVar11 = (int)*(short *)(*(int *)(DAT_0050b1dc + 6) + iVar8) -
                       *(int *)(DAT_0050b0c4 + 10);
              if (*(uint *)(DAT_0050b0c4 + 8) <= uVar11) {
                (*pcVar10)();
              }
              iVar4 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar11 + (iVar5 - iVar4)) * 8;
            }
            iVar5 = *(int *)(DAT_0050b0c4 + 6);
            *(undefined4 *)(iVar5 + iVar4) = 0;
            *(undefined4 *)(iVar5 + 4 + iVar4) = 0;
          }
          iVar4 = __vbaVarForNext(local_24,local_2b8,local_2c8);
        }
        iVar4 = __vbaVarForNext(local_54,local_238,local_248);
      }
LAB_0043727e:
      __vbaFreeVarList(0x22,local_e8,local_f8,local_108,local_118,local_128,local_138,local_148,
                       local_158,local_168,local_178,local_188,local_198,local_1a8,local_1b8,
                       local_1c8,local_1d8,local_1e8,local_1f8,local_208,local_218,local_228,
                       local_238,local_248,local_258,local_268,local_278,local_288,local_298,
                       local_2a8,local_2b8,local_2c8,local_2d8,local_2e8,local_2f8,&LAB_004373a4);
      __vbaFreeVar();
      __vbaFreeVar();
      __vbaFreeVar();
      __vbaFreeVar();
      __vbaFreeVar();
      __vbaFreeVar();
      __vbaFreeVar();
      return;
    }
    local_a4[0] = 0x8002;
    sVar3 = __vbaVarTstGt(local_a4,local_34);
    if (sVar3 != 0) {
      local_ac = 1;
      local_b4[0] = 2;
      local_9c = 1;
      local_a4[0] = 2;
      local_bc = 1;
      local_c4[0] = 2;
      uVar7 = __vbaVarSub(local_94,local_a4,local_34,local_b4);
      iVar4 = __vbaVarForInit(local_24,local_148,local_158,local_c4,uVar7);
      while (iVar4 != 0) {
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_24);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar6 = __vbaI4Var(local_34);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            (*pcVar10)();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        _DAT_0050b114 =
             (double)CONCAT44(*(undefined4 *)(*(int *)(DAT_0050b0c0 + 6) + 4 + iVar4),
                              *(undefined4 *)(*(int *)(DAT_0050b0c0 + 6) + iVar4));
        local_9c = 1;
        local_a4[0] = 0x8002;
        sVar3 = __vbaVarTstGt(local_a4,local_24);
        if (sVar3 != 0) {
          local_ac = 1;
          local_b4[0] = 2;
          local_9c = 1;
          local_a4[0] = 2;
          local_bc = 1;
          local_c4[0] = 2;
          uVar7 = __vbaVarSub(local_94,local_a4,local_24,local_b4);
          iVar4 = __vbaVarForInit(local_44,local_168,local_178,local_c4,uVar7);
          while (iVar4 != 0) {
            if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
              iVar4 = __vbaGenerateBoundsError();
            }
            else {
              iVar5 = __vbaI4Var(local_24);
              iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
              if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
                (*pcVar10)();
              }
              iVar6 = __vbaI4Var(local_44);
              iVar8 = *(int *)(DAT_0050b0c0 + 10);
              if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
                (*pcVar10)();
              }
              iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
            }
            if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
              iVar5 = __vbaGenerateBoundsError();
            }
            else {
              iVar8 = __vbaI4Var(local_44);
              iVar5 = *(int *)(DAT_0050b0c0 + 0xe);
              if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar8 - iVar5)) {
                __vbaGenerateBoundsError();
              }
              iVar9 = __vbaI4Var(local_34);
              iVar6 = *(int *)(DAT_0050b0c0 + 10);
              if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar9 - iVar6)) {
                __vbaGenerateBoundsError();
              }
              iVar5 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar9 - iVar6) + (iVar8 - iVar5)) * 8;
            }
            _DAT_0050b114 =
                 _DAT_0050b114 -
                 *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar5) *
                 *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
            if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
            iVar4 = __vbaVarForNext(local_44,local_168,local_178);
            pcVar10 = __vbaGenerateBoundsError_exref;
          }
        }
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_24);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar6 = __vbaI4Var(local_34);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            (*pcVar10)();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        iVar5 = *(int *)(DAT_0050b0c0 + 6);
        *(undefined4 *)(iVar5 + iVar4) = DAT_0050b114;
        *(undefined4 *)(iVar5 + 4 + iVar4) = DAT_0050b118;
        iVar4 = __vbaVarForNext(local_24,local_148,local_158);
      }
    }
    DAT_0050b104 = 0;
    DAT_0050b108 = 0;
    local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
    local_9c = 1;
    local_a4[0] = 2;
    local_b4[0] = 2;
    iVar4 = __vbaVarForInit(local_24,local_188,local_198,local_34,local_b4,local_a4);
    while (iVar4 != 0) {
      if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_24);
        iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
        if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar6 = __vbaI4Var(local_34);
        iVar8 = *(int *)(DAT_0050b0c0 + 10);
        if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
          (*pcVar10)();
        }
        iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
      }
      _DAT_0050b114 =
           (double)CONCAT44(*(undefined4 *)(*(int *)(DAT_0050b0c0 + 6) + 4 + iVar4),
                            *(undefined4 *)(*(int *)(DAT_0050b0c0 + 6) + iVar4));
      local_9c = 1;
      local_a4[0] = 0x8002;
      sVar3 = __vbaVarTstGt(local_a4,local_34);
      if (sVar3 != 0) {
        local_ac = 1;
        local_b4[0] = 2;
        local_9c = 1;
        local_a4[0] = 2;
        local_bc = 1;
        local_c4[0] = 2;
        uVar7 = __vbaVarSub(local_94,local_a4,local_34,local_b4);
        iVar4 = __vbaVarForInit(local_44,local_1a8,local_1b8,local_c4,uVar7);
        while (iVar4 != 0) {
          if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
            iVar4 = __vbaGenerateBoundsError();
          }
          else {
            iVar5 = __vbaI4Var(local_24);
            iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
            if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
              __vbaGenerateBoundsError();
            }
            iVar6 = __vbaI4Var(local_44);
            iVar8 = *(int *)(DAT_0050b0c0 + 10);
            if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
              __vbaGenerateBoundsError();
            }
            iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
          }
          if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
            iVar5 = __vbaGenerateBoundsError();
          }
          else {
            iVar8 = __vbaI4Var(local_44);
            iVar5 = *(int *)(DAT_0050b0c0 + 0xe);
            if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar8 - iVar5)) {
              __vbaGenerateBoundsError();
            }
            iVar9 = __vbaI4Var(local_34);
            iVar6 = *(int *)(DAT_0050b0c0 + 10);
            if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar9 - iVar6)) {
              __vbaGenerateBoundsError();
            }
            iVar5 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar9 - iVar6) + (iVar8 - iVar5)) * 8;
          }
          _DAT_0050b114 =
               _DAT_0050b114 -
               *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar5) *
               *(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
          iVar4 = __vbaVarForNext(local_44,local_1a8,local_1b8);
          pcVar10 = __vbaGenerateBoundsError_exref;
        }
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_24);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar6 = __vbaI4Var(local_34);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            (*pcVar10)();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        iVar5 = *(int *)(DAT_0050b0c0 + 6);
        *(undefined4 *)(iVar5 + iVar4) = DAT_0050b114;
        *(undefined4 *)(iVar5 + 4 + iVar4) = DAT_0050b118;
      }
      if ((DAT_0050b0d0 == (short *)0x0) || (*DAT_0050b0d0 != 1)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_24);
        iVar4 = *(int *)(DAT_0050b0d0 + 10);
        if (*(uint *)(DAT_0050b0d0 + 8) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar4 = (iVar5 - iVar4) * 8;
      }
      dVar1 = ABS(_DAT_0050b114) * *(double *)(*(int *)(DAT_0050b0d0 + 6) + iVar4);
      _DAT_0050b10c = dVar1;
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
      in_FPUStatusWord = 0;
      if ((double)CONCAT44(DAT_0050b108,DAT_0050b104) <= dVar1) {
        DAT_0050b110 = (undefined4)((ulonglong)dVar1 >> 0x20);
        DAT_0050b10c = SUB84(dVar1,0);
        DAT_0050b108 = DAT_0050b110;
        DAT_0050b104 = DAT_0050b10c;
        __vbaVarCopy();
      }
      iVar4 = __vbaVarForNext(local_24,local_188,local_198);
    }
    sVar3 = __vbaVarTstNe(local_84,local_34);
    if (sVar3 != 0) {
      local_ac = CONCAT22(local_ac._2_2_,DAT_0050b202);
      local_9c = 1;
      local_a4[0] = 2;
      local_b4[0] = 2;
      local_bc = 1;
      local_c4[0] = 2;
      iVar4 = __vbaVarForInit(local_44,local_1c8,local_1d8,local_c4,local_b4,local_a4);
      while (iVar4 != 0) {
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_84);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar6 = __vbaI4Var(local_44);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            (*pcVar10)();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        _DAT_0050b10c =
             (double)CONCAT44(*(undefined4 *)(*(int *)(DAT_0050b0c0 + 6) + 4 + iVar4),
                              *(undefined4 *)(*(int *)(DAT_0050b0c0 + 6) + iVar4));
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = __vbaGenerateBoundsError();
        }
        else {
          iVar5 = __vbaI4Var(local_34);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            (*pcVar10)();
          }
          iVar6 = __vbaI4Var(local_44);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            (*pcVar10)();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          iVar8 = __vbaI4Var(local_84);
          iVar5 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar8 - iVar5)) {
            __vbaGenerateBoundsError();
          }
          iVar9 = __vbaI4Var(local_44);
          iVar6 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar9 - iVar6)) {
            __vbaGenerateBoundsError();
          }
          iVar5 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar9 - iVar6) + (iVar8 - iVar5)) * 8;
        }
        iVar8 = *(int *)(DAT_0050b0c0 + 6);
        *(undefined4 *)(iVar8 + iVar5) = *(undefined4 *)(iVar8 + iVar4);
        *(undefined4 *)(iVar8 + 4 + iVar5) = *(undefined4 *)(iVar8 + 4 + iVar4);
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = __vbaGenerateBoundsError();
        }
        else {
          iVar5 = __vbaI4Var(local_34);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            __vbaGenerateBoundsError();
          }
          iVar6 = __vbaI4Var(local_44);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            __vbaGenerateBoundsError();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        iVar5 = *(int *)(DAT_0050b0c0 + 6);
        *(undefined4 *)(iVar5 + iVar4) = DAT_0050b10c;
        *(undefined4 *)(iVar5 + 4 + iVar4) = DAT_0050b110;
        iVar4 = __vbaVarForNext(local_44,local_1c8,local_1d8);
        pcVar10 = __vbaGenerateBoundsError_exref;
      }
      _DAT_0050b144 = -_DAT_0050b144;
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
      if ((DAT_0050b0d0 == (short *)0x0) || (*DAT_0050b0d0 != 1)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_34);
        iVar4 = *(int *)(DAT_0050b0d0 + 10);
        if (*(uint *)(DAT_0050b0d0 + 8) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar4 = (iVar5 - iVar4) * 8;
      }
      if ((DAT_0050b0d0 == (short *)0x0) || (*DAT_0050b0d0 != 1)) {
        iVar5 = (*pcVar10)();
      }
      else {
        iVar8 = __vbaI4Var(local_84);
        iVar5 = *(int *)(DAT_0050b0d0 + 10);
        if (*(uint *)(DAT_0050b0d0 + 8) <= (uint)(iVar8 - iVar5)) {
          (*pcVar10)();
        }
        iVar5 = (iVar8 - iVar5) * 8;
      }
      iVar8 = *(int *)(DAT_0050b0d0 + 6);
      *(undefined4 *)(iVar8 + iVar5) = *(undefined4 *)(iVar8 + iVar4);
      *(undefined4 *)(iVar8 + 4 + iVar5) = *(undefined4 *)(iVar8 + 4 + iVar4);
      if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_34);
        iVar4 = *(int *)(DAT_0050b1dc + 10);
        if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar4 = (iVar5 - iVar4) * 2;
      }
      local_9c = CONCAT22(local_9c._2_2_,*(undefined2 *)(*(int *)(DAT_0050b1dc + 6) + iVar4));
      local_a4[0] = 2;
      __vbaVarMove();
      if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_84);
        iVar4 = *(int *)(DAT_0050b1dc + 10);
        if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar4 = (iVar5 - iVar4) * 2;
      }
      if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
        iVar5 = (*pcVar10)();
      }
      else {
        iVar8 = __vbaI4Var(local_34);
        iVar5 = *(int *)(DAT_0050b1dc + 10);
        if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar8 - iVar5)) {
          (*pcVar10)();
        }
        iVar5 = (iVar8 - iVar5) * 2;
      }
      *(undefined2 *)(iVar5 + *(int *)(DAT_0050b1dc + 6)) =
           *(undefined2 *)(iVar4 + *(int *)(DAT_0050b1dc + 6));
      if ((DAT_0050b1dc == (short *)0x0) || (*DAT_0050b1dc != 1)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_84);
        iVar4 = *(int *)(DAT_0050b1dc + 10);
        if (*(uint *)(DAT_0050b1dc + 8) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar4 = (iVar5 - iVar4) * 2;
      }
      uVar2 = __vbaI2Var(local_54);
      *(undefined2 *)(*(int *)(DAT_0050b1dc + 6) + iVar4) = uVar2;
    }
    if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
      (*pcVar10)();
    }
    else {
      iVar4 = __vbaI4Var(local_34);
      if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar4 - *(int *)(DAT_0050b0c0 + 0xe))) {
        (*pcVar10)();
      }
      iVar4 = __vbaI4Var(local_34);
      if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar4 - *(int *)(DAT_0050b0c0 + 10))) {
        (*pcVar10)();
      }
    }
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
    fVar12 = (float10)__vbaFpR8();
    in_FPUStatusWord = 0;
    if (fVar12 <= (float10)_DAT_00401a80) {
      _DAT_0050b144 = 0.0;
      goto LAB_0043727e;
    }
    puVar13 = local_a4;
    local_9c = CONCAT22(local_9c._2_2_,DAT_0050b202);
    local_a4[0] = 0x8002;
    sVar3 = __vbaVarTstNe(puVar13,local_34);
    if (sVar3 != 0) {
      if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
        iVar4 = (*pcVar10)();
      }
      else {
        iVar5 = __vbaI4Var(local_34);
        iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
        if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
          (*pcVar10)();
        }
        iVar6 = __vbaI4Var(local_34);
        iVar8 = *(int *)(DAT_0050b0c0 + 10);
        if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
          (*pcVar10)();
        }
        iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
      }
      if (DAT_0050b000 == 0) {
        fVar12 = (float10)_DAT_00401880 / (float10)*(double *)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
        uVar2 = DAT_0050b202;
      }
      else {
        puVar13 = *(undefined4 **)(*(int *)(DAT_0050b0c0 + 6) + iVar4);
        fVar12 = (float10)adj_fdiv_m64();
        uVar2 = extraout_DX;
      }
      local_bc = CONCAT22(local_bc._2_2_,uVar2);
      local_ac = 1;
      local_b4[0] = 2;
      local_c4[0] = 2;
      local_9c = 1;
      local_a4[0] = 2;
      _DAT_0050b10c = (double)fVar12;
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
      __vbaVarAdd(local_94,local_a4,local_34,puVar13);
      __vbaVarMove();
      iVar4 = __vbaVarForInit(local_24,local_1f8,local_208,local_1e8,local_c4,local_b4);
      while (iVar4 != 0) {
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar4 = (*pcVar10)();
        }
        else {
          iVar5 = __vbaI4Var(local_24);
          iVar4 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar5 - iVar4)) {
            __vbaGenerateBoundsError();
          }
          iVar6 = __vbaI4Var(local_34);
          iVar8 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar6 - iVar8)) {
            __vbaGenerateBoundsError();
          }
          iVar4 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar6 - iVar8) + (iVar5 - iVar4)) * 8;
        }
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          iVar8 = __vbaI4Var(local_24);
          iVar5 = *(int *)(DAT_0050b0c0 + 0xe);
          if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar8 - iVar5)) {
            __vbaGenerateBoundsError();
          }
          iVar9 = __vbaI4Var(local_34);
          iVar6 = *(int *)(DAT_0050b0c0 + 10);
          if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)(iVar9 - iVar6)) {
            __vbaGenerateBoundsError();
          }
          iVar5 = (*(int *)(DAT_0050b0c0 + 0xc) * (iVar9 - iVar6) + (iVar8 - iVar5)) * 8;
        }
        *(double *)(iVar5 + *(int *)(DAT_0050b0c0 + 6)) =
             _DAT_0050b10c * *(double *)(iVar4 + *(int *)(DAT_0050b0c0 + 6));
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004373b5;
        iVar4 = __vbaVarForNext(local_24,local_1f8,local_208);
        pcVar10 = __vbaGenerateBoundsError_exref;
      }
    }
    iVar4 = __vbaVarForNext(local_34,local_128,local_138);
  } while( true );
}


