/* requested 004afc50 entry 004afc50 name FUN_004afc50 size 1168 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004afc50(void)

{
  int iVar1;
  double dVar2;
  code **ppcVar3;
  short sVar4;
  short *psVar5;
  short sVar6;
  undefined2 extraout_var;
  ushort uVar7;
  short sVar8;
  code *pcVar9;
  undefined2 uVar12;
  uint uVar10;
  int iVar11;
  uint unaff_ESI;
  uint uVar13;
  short sVar14;
  int iVar15;
  int iVar16;
  code *pcVar17;
  bool bVar18;
  ushort in_FPUStatusWord;
  float10 fVar19;
  int iStack_7c;
  float fStack_78;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined1 *puStack_54;
  code *pcStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_30;
  code *pcStack_2c;
  uint local_14;
  code *local_10;
  
  pcVar9 = (code *)&stack0xfffffffc;
  _DAT_0050b14c = 0.0;
  sVar8 = DAT_0050b20c;
  local_10 = (code *)&DAT_00000001;
  if (0 < DAT_0050b20c) {
    do {
      pcVar9 = __vbaGenerateBoundsError_exref;
      if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
        pcStack_2c = (code *)0x4afcc1;
        iVar11 = __vbaGenerateBoundsError();
        pcVar9 = __vbaGenerateBoundsError_exref;
      }
      else {
        unaff_ESI = (int)(short)local_10 - *(int *)(DAT_0050b0f4 + 10);
        if (*(uint *)(DAT_0050b0f4 + 8) <= unaff_ESI) {
          pcStack_2c = (code *)0x4afcb2;
          __vbaGenerateBoundsError();
        }
        iVar11 = unaff_ESI * 8;
      }
      sVar4 = 1;
      iVar16 = *(int *)(DAT_0050b0f4 + 6);
      *(undefined4 *)(iVar16 + iVar11) = 0;
      *(undefined4 *)(iVar16 + 4 + iVar11) = 0;
      sVar6 = DAT_0050b20c;
      if (0 < DAT_0050b20c) {
        do {
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            pcStack_2c = (code *)0x4afd27;
            iVar11 = (*pcVar9)();
          }
          else {
            iVar11 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)((short)local_10 - iVar11)) {
              pcStack_2c = (code *)0x4afd1c;
              (*pcVar9)();
            }
            iVar11 = ((short)local_10 - iVar11) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            pcStack_2c = (code *)0x4afd77;
            local_14 = (*pcVar9)();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)((short)local_10 - iVar16)) {
              pcStack_2c = (code *)0x4afd4b;
              (*pcVar9)();
            }
            iVar15 = *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(sVar4 - iVar15)) {
              pcStack_2c = (code *)0x4afd63;
              (*pcVar9)();
            }
            local_14 = (*(int *)(DAT_0050b0c4 + 0xc) * (sVar4 - iVar15) + ((short)local_10 - iVar16)
                       ) * 8;
          }
          if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
            pcStack_2c = (code *)0x4afdcc;
            unaff_ESI = (*pcVar9)();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0c0 + 0xe);
            if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(sVar4 - iVar16)) {
              pcStack_2c = (code *)0x4afd9b;
              (*pcVar9)();
            }
            iVar15 = *(int *)(DAT_0050b0c0 + 10);
            if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)-iVar15) {
              pcStack_2c = (code *)0x4afdb2;
              __vbaGenerateBoundsError();
            }
            unaff_ESI = (*(int *)(DAT_0050b0c0 + 0xc) * -iVar15 + (sVar4 - iVar16)) * 8;
            pcVar9 = __vbaGenerateBoundsError_exref;
          }
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            pcStack_2c = (code *)0x4afe06;
            iVar16 = (*pcVar9)();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)((short)local_10 - iVar16)) {
              pcStack_2c = (code *)0x4afdf6;
              (*pcVar9)();
            }
            iVar16 = ((short)local_10 - iVar16) * 8;
          }
          *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar16) =
               *(double *)(*(int *)(DAT_0050b0c0 + 6) + unaff_ESI) *
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + local_14) +
               *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar11);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b00c9;
          bVar18 = SCARRY2(sVar4,1);
          sVar4 = sVar4 + 1;
          if (bVar18) goto LAB_004b00ce;
        } while (sVar4 <= sVar6);
      }
      if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
        pcStack_2c = (code *)0x4afe89;
        local_14 = (*pcVar9)();
      }
      else {
        unaff_ESI = (int)(short)local_10 - *(int *)(DAT_0050b0d8 + 10);
        if (*(uint *)(DAT_0050b0d8 + 8) <= unaff_ESI) {
          pcStack_2c = (code *)0x4afe7e;
          (*pcVar9)();
        }
        local_14 = unaff_ESI * 8;
      }
      if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
        pcStack_2c = (code *)0x4afeb6;
        iVar11 = (*pcVar9)();
      }
      else {
        unaff_ESI = (int)(short)local_10 - *(int *)(DAT_0050b0f4 + 10);
        if (*(uint *)(DAT_0050b0f4 + 8) <= unaff_ESI) {
          pcStack_2c = (code *)0x4afeab;
          (*pcVar9)();
        }
        iVar11 = unaff_ESI * 8;
      }
      _DAT_0050b14c =
           *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar11) *
           *(double *)(*(int *)(DAT_0050b0d8 + 6) + local_14) + _DAT_0050b14c;
      if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004b00c9:
        __vbaFPException();
        return;
      }
      bVar18 = SCARRY2((short)local_10,1);
      uVar7 = (short)local_10 + 1;
      local_10 = (code *)(uint)uVar7;
      if (bVar18) goto LAB_004b00ce;
    } while ((short)uVar7 <= sVar8);
  }
  sVar8 = DAT_0050b20a;
  pcVar9 = (code *)CONCAT22((short)((uint)pcVar9 >> 0x10),DAT_0050b20a);
  local_14 = 1;
  if (0 < DAT_0050b20a) {
    do {
      local_10 = __vbaGenerateBoundsError_exref;
      sVar4 = (short)local_14;
      if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
        pcStack_2c = (code *)0x4aff5b;
        iVar11 = __vbaGenerateBoundsError();
        local_10 = __vbaGenerateBoundsError_exref;
      }
      else {
        unaff_ESI = (int)sVar4 - *(int *)(DAT_0050b1f8 + 10);
        if (*(uint *)(DAT_0050b1f8 + 8) <= unaff_ESI) {
          pcStack_2c = (code *)0x4aff4a;
          __vbaGenerateBoundsError();
        }
        iVar11 = unaff_ESI * 2;
      }
      if (*(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar11) < 1) {
        uVar12 = (undefined2)((uint)pcVar9 >> 0x10);
        sVar6 = DAT_0050b20c;
        pcVar9 = (code *)CONCAT22(uVar12,DAT_0050b20c);
        local_14 = 1;
        uVar7 = 1;
        psVar5 = DAT_0050b1f0;
        if (0 < DAT_0050b20c) {
          do {
            uVar7 = (ushort)local_14;
            if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
              pcStack_2c = (code *)0x4affff;
              iVar11 = (*local_10)();
              psVar5 = DAT_0050b1f0;
            }
            else {
              unaff_ESI = (int)(short)uVar7 - *(int *)(psVar5 + 10);
              if (*(uint *)(psVar5 + 8) <= unaff_ESI) {
                pcStack_2c = (code *)0x4afff2;
                (*local_10)();
                psVar5 = DAT_0050b1f0;
              }
              iVar11 = unaff_ESI * 2;
            }
            unaff_ESI = CONCAT22((short)(unaff_ESI >> 0x10),sVar4);
            if (sVar4 == *(short *)(*(int *)(psVar5 + 6) + iVar11)) break;
            bVar18 = SCARRY2(uVar7,1);
            uVar7 = uVar7 + 1;
            local_14 = (uint)uVar7;
            if (bVar18) goto LAB_004b00ce;
          } while ((short)uVar7 <= sVar6);
        }
        if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
          pcStack_2c = (code *)0x4b004d;
          iVar11 = (*local_10)();
        }
        else {
          iVar11 = *(int *)(DAT_0050b0f4 + 10);
          if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)((short)uVar7 - iVar11)) {
            pcStack_2c = (code *)0x4b0042;
            (*local_10)();
          }
          iVar11 = ((short)uVar7 - iVar11) * 8;
        }
        if ((DAT_0050b0ec == (short *)0x0) || (*DAT_0050b0ec != 1)) {
          pcStack_2c = (code *)0x4b0083;
          iVar16 = (*local_10)();
        }
        else {
          iVar16 = *(int *)(DAT_0050b0ec + 10);
          if (*(uint *)(DAT_0050b0ec + 8) <= (uint)(sVar4 - iVar16)) {
            pcStack_2c = (code *)0x4b0072;
            (*local_10)();
          }
          iVar16 = (sVar4 - iVar16) * 8;
        }
        iVar15 = *(int *)(DAT_0050b0ec + 6);
        pcVar9 = (code *)CONCAT22(uVar12,sVar8);
        iVar1 = *(int *)(DAT_0050b0f4 + 6);
        unaff_ESI = *(uint *)(iVar1 + iVar11);
        *(uint *)(iVar15 + iVar16) = unaff_ESI;
        *(undefined4 *)(iVar15 + 4 + iVar16) = *(undefined4 *)(iVar1 + 4 + iVar11);
      }
      else {
        if ((DAT_0050b0ec == (short *)0x0) || (*DAT_0050b0ec != 1)) {
          pcStack_2c = (code *)0x4affa3;
          iVar11 = (*local_10)();
        }
        else {
          unaff_ESI = (int)sVar4 - *(int *)(DAT_0050b0ec + 10);
          if (*(uint *)(DAT_0050b0ec + 8) <= unaff_ESI) {
            pcStack_2c = (code *)0x4aff92;
            (*local_10)();
          }
          iVar11 = unaff_ESI * 8;
        }
        iVar16 = *(int *)(DAT_0050b0ec + 6);
        *(undefined4 *)(iVar16 + iVar11) = 0;
        *(undefined4 *)(iVar16 + 4 + iVar11) = 0;
      }
      local_14 = (uint)(ushort)(sVar4 + 1U);
      if (SCARRY2(sVar4,1)) goto LAB_004b00ce;
    } while ((short)(sVar4 + 1U) <= (short)pcVar9);
  }
  return;
LAB_004b00ce:
  pcStack_2c = (code *)0x4b00d4;
  __vbaErrorOverflow();
  puStack_54 = (undefined1 *)&pcStack_2c;
  uStack_3c = (double)CONCAT44(uStack_3c._4_4_,_DAT_0050b20c);
  iStack_4c = 1;
  pcVar17 = __vbaGenerateBoundsError_exref;
  uStack_5c = local_14;
  uStack_58 = unaff_ESI;
  ppcVar3 = &pcStack_2c;
  pcStack_50 = local_10;
  pcStack_2c = pcVar9;
  if (0 < (short)_DAT_0050b20c) {
    do {
      iVar11 = iStack_4c;
      if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
        uStack_60 = 0x4b0140;
        iVar16 = (*pcVar17)();
      }
      else {
        unaff_ESI = (int)(short)iStack_4c - *(int *)(DAT_0050b0dc + 10);
        if (*(uint *)(DAT_0050b0dc + 8) <= unaff_ESI) {
          uStack_60 = 0x4b012f;
          (*pcVar17)();
        }
        iVar16 = unaff_ESI * 8;
      }
      iVar15 = *(int *)(DAT_0050b0dc + 6);
      uVar10 = 1;
      *(undefined4 *)(iVar15 + iVar16) = 0;
      *(undefined4 *)(iVar15 + 4 + iVar16) = 0;
      uStack_40 = _DAT_0050b20c;
      if (0 < (short)_DAT_0050b20c) {
        do {
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            uStack_60 = 0x4b019e;
            iStack_48 = (*pcVar17)();
          }
          else {
            uVar13 = (int)(short)iVar11 - *(int *)(DAT_0050b0dc + 10);
            if (*(uint *)(DAT_0050b0dc + 8) <= uVar13) {
              uStack_60 = 0x4b018f;
              (*pcVar17)();
            }
            iStack_48 = uVar13 * 8;
          }
          sVar8 = (short)uVar10;
          if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
            uStack_60 = 0x4b01cd;
            iStack_44 = (*pcVar17)();
          }
          else {
            iVar11 = *(int *)(DAT_0050b0d8 + 10);
            if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(sVar8 - iVar11)) {
              uStack_60 = 0x4b01c2;
              (*pcVar17)();
            }
            iStack_44 = (sVar8 - iVar11) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            uStack_60 = 0x4b0221;
            unaff_ESI = (*pcVar17)();
          }
          else {
            iVar11 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(sVar8 - iVar11)) {
              uStack_60 = 0x4b01f1;
              (*pcVar17)();
            }
            iVar15 = (int)(short)iStack_4c;
            iVar16 = *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(iVar15 - iVar16)) {
              uStack_60 = 0x4b020d;
              __vbaGenerateBoundsError();
            }
            unaff_ESI = (*(int *)(DAT_0050b0c4 + 0xc) * (iVar15 - iVar16) + (sVar8 - iVar11)) * 8;
          }
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            uStack_60 = 0x4b0263;
            iVar11 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = (int)(short)iStack_4c;
            iVar11 = *(int *)(DAT_0050b0dc + 10);
            if (*(uint *)(DAT_0050b0dc + 8) <= (uint)(iVar16 - iVar11)) {
              uStack_60 = 0x4b024f;
              __vbaGenerateBoundsError();
            }
            iVar11 = (iVar16 - iVar11) * 8;
          }
          pcVar17 = __vbaGenerateBoundsError_exref;
          *(double *)(*(int *)(DAT_0050b0dc + 6) + iVar11) =
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + unaff_ESI) *
               *(double *)(*(int *)(DAT_0050b0d8 + 6) + iStack_44) +
               *(double *)(*(int *)(DAT_0050b0dc + 6) + iStack_48);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
          uVar10 = (uint)(ushort)(sVar8 + 1U);
          iVar16 = iStack_4c;
          if (SCARRY2(sVar8,1)) goto LAB_004b06ce;
          iVar11 = iStack_4c;
        } while ((short)(sVar8 + 1U) <= (short)uStack_40);
      }
      sVar8 = (short)iVar11 + 1;
      iVar16 = CONCAT22((short)((uint)iVar11 >> 0x10),sVar8);
      if (SCARRY2((short)iVar11,1)) goto LAB_004b06ce;
      ppcVar3 = (code **)puStack_54;
      iStack_4c = iVar16;
    } while (sVar8 <= (short)uStack_3c);
  }
  puStack_54 = (undefined1 *)ppcVar3;
  DAT_0050b25e = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  iStack_4c = CONCAT22(iStack_4c._2_2_,DAT_0050b20a);
  iStack_44 = 1;
  if (0 < DAT_0050b20a) {
    do {
      iVar11 = iStack_44;
      uVar10 = 0;
      sVar8 = (short)iStack_44;
      if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
        uStack_60 = 0x4b0339;
        iVar16 = (*pcVar17)();
      }
      else {
        unaff_ESI = (int)sVar8 - *(int *)(DAT_0050b0f0 + 10);
        if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
          uStack_60 = 0x4b0328;
          (*pcVar17)();
        }
        iVar16 = unaff_ESI * 8;
      }
      iVar15 = *(int *)(DAT_0050b0f0 + 6);
      *(undefined4 *)(iVar15 + iVar16) = 0;
      *(undefined4 *)(iVar15 + 4 + iVar16) = 0;
      if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
        uStack_60 = 0x4b0377;
        iVar16 = (*pcVar17)();
      }
      else {
        unaff_ESI = (int)sVar8 - *(int *)(DAT_0050b1f8 + 10);
        if (*(uint *)(DAT_0050b1f8 + 8) <= unaff_ESI) {
          uStack_60 = 0x4b036a;
          (*pcVar17)();
        }
        iVar16 = unaff_ESI * 2;
      }
      if (0 < *(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar16)) {
        iVar11 = (int)sVar8;
        dVar2 = (double)(int)DAT_0050b2c6;
        iStack_48 = iVar11;
        uStack_3c = dVar2;
        if (DAT_0050b000 != 0) {
          uStack_3c._4_4_ = (uint)((ulonglong)dVar2 >> 0x20);
          uStack_60 = uStack_3c._4_4_;
          adj_fdiv_m64();
        }
        if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004b06c9:
          __vbaFPException();
          return;
        }
        uStack_60 = 0x4b03e2;
        __vbaFPInt();
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        uStack_60 = 0x4b03f8;
        sVar4 = __vbaFpI2();
        uStack_3c = (double)CONCAT44(uStack_3c._4_4_,CONCAT22(extraout_var,sVar8 % DAT_0050b2c6));
        if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
          uStack_60 = 0x4b0435;
          uStack_40 = (*pcVar17)();
        }
        else {
          iVar16 = *(int *)(DAT_0050b0dc + 10);
          if (*(uint *)(DAT_0050b0dc + 8) <= (uint)(sVar4 - iVar16)) {
            uStack_60 = 0x4b042a;
            (*pcVar17)();
          }
          uStack_40 = (sVar4 - iVar16) * 8;
        }
        if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
          uStack_60 = 0x4b0463;
          iVar16 = (*pcVar17)();
        }
        else {
          iVar16 = *(int *)(DAT_0050b0e8 + 10);
          if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar11 - iVar16)) {
            uStack_60 = 0x4b0458;
            (*pcVar17)();
          }
          iVar16 = (iVar11 - iVar16) * 8;
        }
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          uStack_60 = 0x4b0496;
          iVar11 = (*pcVar17)();
        }
        else {
          iVar15 = *(int *)(DAT_0050b0f0 + 10);
          if (*(uint *)(DAT_0050b0f0 + 8) <= (uint)(iVar11 - iVar15)) {
            uStack_60 = 0x4b0485;
            (*pcVar17)();
          }
          iVar11 = (iVar11 - iVar15) * 8;
        }
        unaff_ESI = *(uint *)(DAT_0050b0e8 + 6);
        *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar11) =
             *(double *)(*(int *)(DAT_0050b0dc + 6) + uStack_40) - *(double *)(unaff_ESI + iVar16);
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        sVar8 = SUB82(uStack_3c,0);
        uVar10 = uStack_40;
        if (0 < sVar8) {
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            uStack_60 = 0x4b0507;
            uVar10 = (*pcVar17)();
          }
          else {
            unaff_ESI = iStack_48 - *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
              uStack_60 = 0x4b04f7;
              (*pcVar17)();
            }
            uVar10 = unaff_ESI * 8;
          }
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            uStack_60 = 0x4b054f;
            iVar11 = (*pcVar17)();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0dc + 10);
            if (SCARRY2(DAT_0050b2c4,sVar8)) goto LAB_004b06ce;
            unaff_ESI = (short)(DAT_0050b2c4 + sVar8) - iVar16;
            if (*(uint *)(DAT_0050b0dc + 8) <= unaff_ESI) {
              uStack_60 = 0x4b053f;
              (*pcVar17)();
            }
            iVar11 = unaff_ESI * 8;
          }
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            uStack_60 = 0x4b0582;
            iVar16 = (*pcVar17)();
          }
          else {
            unaff_ESI = iStack_48 - *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
              uStack_60 = 0x4b0572;
              (*pcVar17)();
            }
            iVar16 = unaff_ESI * 8;
          }
          *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar16) =
               *(double *)(*(int *)(DAT_0050b0dc + 6) + iVar11) +
               *(double *)(*(int *)(DAT_0050b0f0 + 6) + uVar10);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        }
        iVar16 = iStack_48;
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          uStack_60 = 0x4b05dc;
          iVar15 = (*pcVar17)();
        }
        else {
          unaff_ESI = iStack_48 - *(int *)(DAT_0050b0f0 + 10);
          if (*(uint *)(DAT_0050b0f0 + 8) <= unaff_ESI) {
            uStack_60 = 0x4b05cb;
            (*pcVar17)();
          }
          iVar15 = unaff_ESI * 8;
        }
        in_FPUStatusWord = 0;
        iVar11 = iStack_44;
        if ((double)CONCAT44(uStack_30,uStack_34) < *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar15)
           ) {
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            uStack_60 = 0x4b061e;
            iVar11 = (*pcVar17)();
          }
          else {
            iVar11 = *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= (uint)(iVar16 - iVar11)) {
              uStack_60 = 0x4b060d;
              (*pcVar17)();
            }
            iVar11 = (iVar16 - iVar11) * 8;
          }
          unaff_ESI = *(uint *)(*(int *)(DAT_0050b0f0 + 6) + iVar11);
          uStack_30 = *(undefined4 *)(*(int *)(DAT_0050b0f0 + 6) + 4 + iVar11);
          DAT_0050b25e = (short)iStack_44;
          iVar11 = iStack_44;
          uStack_34 = unaff_ESI;
        }
      }
      sVar8 = (short)iVar11 + 1;
      iVar16 = CONCAT22((short)((uint)iVar11 >> 0x10),sVar8);
      if (SCARRY2((short)iVar11,1)) goto LAB_004b06ce;
      iStack_44 = iVar16;
    } while (sVar8 <= (short)iStack_4c);
    if (0 < DAT_0050b25e) {
      if ((DAT_0050b1f8 != (short *)0x0) && (*DAT_0050b1f8 == 1)) {
        iVar11 = *(int *)(DAT_0050b1f8 + 10);
        iVar16 = (int)DAT_0050b25e;
        if (*(uint *)(DAT_0050b1f8 + 8) <= (uint)(iVar16 - iVar11)) {
          uStack_60 = 0x4b0696;
          (*pcVar17)();
        }
        *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + (iVar16 - iVar11) * 2) = 0;
        return;
      }
      uStack_60 = 0x4b06b2;
      iVar11 = (*pcVar17)();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar11) = 0;
    }
  }
  return;
LAB_004b06ce:
  uStack_60 = 0x4b06d4;
  __vbaErrorOverflow();
  DAT_0050b260._0_2_ = 0;
  DAT_0050b260._2_2_ = 0;
  uStack_60 = uVar10;
  if (DAT_0050b000 != 0) {
    adj_fdiv_m64((double)(int)DAT_0050b2c6,pcVar17,unaff_ESI,&uStack_60,iVar16);
  }
  if (((in_FPUStatusWord & 0xd) == 0) && (__vbaFPInt(), (in_FPUStatusWord & 0xd) == 0)) {
    sVar4 = __vbaFpI2();
    sVar8 = DAT_0050b20a;
    sVar6 = DAT_0050b25e % DAT_0050b2c6;
    sVar14 = 1;
    psVar5 = DAT_0050b1f8;
    if (0 < DAT_0050b20a) {
      do {
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          iVar11 = __vbaGenerateBoundsError();
          psVar5 = DAT_0050b1f8;
        }
        else {
          iVar11 = *(int *)(psVar5 + 10);
          if (*(uint *)(psVar5 + 8) <= (uint)(sVar14 - iVar11)) {
            __vbaGenerateBoundsError();
            psVar5 = DAT_0050b1f8;
          }
          iVar11 = (sVar14 - iVar11) * 2;
        }
        if (*(short *)(*(int *)(psVar5 + 6) + iVar11) < 0) {
          if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
            iVar11 = __vbaGenerateBoundsError();
            psVar5 = DAT_0050b1f8;
          }
          else {
            iVar11 = *(int *)(psVar5 + 10);
            if (*(uint *)(psVar5 + 8) <= (uint)(sVar14 - iVar11)) {
              __vbaGenerateBoundsError();
              psVar5 = DAT_0050b1f8;
            }
            iVar11 = (sVar14 - iVar11) * 2;
          }
          *(undefined2 *)(*(int *)(psVar5 + 6) + iVar11) = 0;
          psVar5 = DAT_0050b1f8;
        }
        bVar18 = SCARRY2(sVar14,1);
        sVar14 = sVar14 + 1;
        if (bVar18) goto LAB_004b0da8;
      } while (sVar14 <= sVar8);
    }
    sVar14 = 1;
    sVar8 = (short)_DAT_0050b20c;
    if (0 < sVar8) {
      do {
        if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          iVar16 = (int)sVar14;
          iVar11 = *(int *)(DAT_0050b0c4 + 0xe);
          if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar16 - iVar11)) {
            __vbaGenerateBoundsError();
          }
          iVar15 = *(int *)(DAT_0050b0c4 + 10);
          if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(sVar4 - iVar15)) {
            __vbaGenerateBoundsError();
          }
          iVar11 = (*(int *)(DAT_0050b0c4 + 0xc) * (sVar4 - iVar15) + (iVar16 - iVar11)) * 8;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar16 = __vbaGenerateBoundsError();
        }
        else {
          iVar15 = (int)sVar14;
          iVar16 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar15 - iVar16)) {
            __vbaGenerateBoundsError();
          }
          iVar16 = (iVar15 - iVar16) * 8;
        }
        iVar15 = *(int *)(DAT_0050b0c4 + 6);
        iVar1 = *(int *)(DAT_0050b0fc + 6);
        *(undefined4 *)(iVar1 + iVar16) = *(undefined4 *)(iVar15 + iVar11);
        *(undefined4 *)(iVar1 + 4 + iVar16) = *(undefined4 *)(iVar15 + 4 + iVar11);
        if (0 < sVar6) {
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iStack_7c = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = (int)sVar14;
            iVar11 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar16 - iVar11)) {
              __vbaGenerateBoundsError();
            }
            iStack_7c = (iVar16 - iVar11) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            iVar11 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = (int)sVar14;
            iVar11 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar16 - iVar11)) {
              __vbaGenerateBoundsError();
            }
            if (SCARRY2(DAT_0050b2c4,sVar6)) {
LAB_004b0da8:
              __vbaErrorOverflow();
              FUN_004b0dd0(&DAT_0050b25e,0x50b262);
              FUN_00435420();
              return;
            }
            uVar10 = (int)(short)(DAT_0050b2c4 + sVar6) - *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= uVar10) {
              __vbaGenerateBoundsError();
            }
            iVar11 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar10 + (iVar16 - iVar11)) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar16 = __vbaGenerateBoundsError();
          }
          else {
            iVar15 = (int)sVar14;
            iVar16 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar15 - iVar16)) {
              __vbaGenerateBoundsError();
            }
            iVar16 = (iVar15 - iVar16) * 8;
          }
          *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar16) =
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + iVar11) +
               *(double *)(*(int *)(DAT_0050b0fc + 6) + iStack_7c);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          iVar11 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar14 - iVar11)) {
            __vbaGenerateBoundsError();
          }
          iVar11 = (sVar14 - iVar11) * 8;
        }
        if (*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar11) != _DAT_00401490) {
          if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
            iVar11 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              iVar11 = __vbaGenerateBoundsError();
            }
            else {
              iVar11 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(sVar14 - iVar11)) {
                __vbaGenerateBoundsError();
              }
              iVar11 = (sVar14 - iVar11) * 2;
            }
            uVar10 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar11) -
                     *(int *)(DAT_0050b1f8 + 10);
            if (*(uint *)(DAT_0050b1f8 + 8) <= uVar10) {
              __vbaGenerateBoundsError();
            }
            iVar11 = uVar10 * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar11) = 0xffff;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          iVar11 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar14 - iVar11)) {
            __vbaGenerateBoundsError();
          }
          iVar11 = (sVar14 - iVar11) * 8;
        }
        in_FPUStatusWord = 0;
        if (_DAT_0050b12c < *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar11)) {
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            iVar11 = __vbaGenerateBoundsError();
          }
          else {
            iVar11 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(sVar14 - iVar11)) {
              __vbaGenerateBoundsError();
            }
            iVar11 = (sVar14 - iVar11) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar16 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar14 - iVar16)) {
              __vbaGenerateBoundsError();
            }
            iVar16 = (sVar14 - iVar16) * 8;
          }
          if (DAT_0050b000 == 0) {
            fVar19 = (float10)*(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar11) /
                     (float10)*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar16);
          }
          else {
            fVar19 = (float10)adj_fdiv_m64();
          }
          _DAT_0050b124 = (double)fVar19;
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
          fVar19 = (float10)__vbaFpR4();
          in_FPUStatusWord = 0;
          if (fVar19 < (float10)fStack_78) {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              iVar11 = __vbaGenerateBoundsError();
            }
            else {
              iVar11 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(sVar14 - iVar11)) {
                __vbaGenerateBoundsError();
              }
              iVar11 = (sVar14 - iVar11) * 2;
            }
            fStack_78 = (float)_DAT_0050b124;
            DAT_0050b260._0_2_ = *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar11);
            DAT_0050b260._2_2_ = sVar14;
          }
        }
        bVar18 = SCARRY2(sVar14,1);
        sVar14 = sVar14 + 1;
        if (bVar18) goto LAB_004b0da8;
        psVar5 = DAT_0050b1f8;
      } while (sVar14 <= sVar8);
    }
    if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
      iVar11 = __vbaGenerateBoundsError();
      psVar5 = DAT_0050b1f8;
    }
    else {
      iVar16 = (int)(short)DAT_0050b260;
      iVar11 = *(int *)(psVar5 + 10);
      if (*(uint *)(psVar5 + 8) <= (uint)(iVar16 - iVar11)) {
        __vbaGenerateBoundsError();
        psVar5 = DAT_0050b1f8;
      }
      iVar11 = (iVar16 - iVar11) * 2;
    }
    *(short *)(*(int *)(psVar5 + 6) + iVar11) = (short)DAT_0050b260;
    if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
      iVar11 = __vbaGenerateBoundsError();
    }
    else {
      iVar16 = (int)DAT_0050b260._2_2_;
      iVar11 = *(int *)(DAT_0050b1f0 + 10);
      if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar16 - iVar11)) {
        __vbaGenerateBoundsError();
      }
      iVar11 = (iVar16 - iVar11) * 2;
    }
    *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar11) = DAT_0050b25e;
    if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
      iVar11 = __vbaGenerateBoundsError();
    }
    else {
      iVar16 = (int)DAT_0050b25e;
      iVar11 = *(int *)(DAT_0050b0e8 + 10);
      if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar16 - iVar11)) {
        __vbaGenerateBoundsError();
      }
      iVar11 = (iVar16 - iVar11) * 8;
    }
    if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
      iVar16 = __vbaGenerateBoundsError();
    }
    else {
      iVar15 = (int)DAT_0050b260._2_2_;
      iVar16 = *(int *)(DAT_0050b0d8 + 10);
      if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(iVar15 - iVar16)) {
        __vbaGenerateBoundsError();
      }
      iVar16 = (iVar15 - iVar16) * 8;
    }
    iVar15 = *(int *)(DAT_0050b0d8 + 6);
    iVar1 = *(int *)(DAT_0050b0e8 + 6);
    *(undefined4 *)(iVar15 + iVar16) = *(undefined4 *)(iVar1 + iVar11);
    *(undefined4 *)(iVar15 + 4 + iVar16) = *(undefined4 *)(iVar1 + 4 + iVar11);
    return;
  }
LAB_004b0da3:
  __vbaFPException();
  return;
}


