/* requested 004b8b70 entry 004b8b70 name FUN_004b8b70 size 15240 */

/* WARNING: Removing unreachable block (ram,0x004bf99c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b8b70(void)

{
  float fVar1;
  wchar_t *pwVar2;
  float ****ppppfVar3;
  uint uVar4;
  uint uVar5;
  undefined1 *puVar6;
  uint uVar7;
  undefined2 uVar8;
  float ******ppppppfVar9;
  undefined2 extraout_var;
  float ******ppppppfVar10;
  code *pcVar11;
  float *****pppppfVar12;
  undefined4 uVar13;
  int *piVar14;
  undefined4 extraout_ECX;
  undefined4 extraout_ECX_00;
  short *psVar15;
  float ******ppppppfVar16;
  float ******extraout_ECX_01;
  float ******extraout_ECX_02;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  undefined2 extraout_var_02;
  undefined2 extraout_var_03;
  undefined2 extraout_var_04;
  undefined4 extraout_EDX;
  undefined2 extraout_var_05;
  float *****unaff_EBX;
  code *pcVar17;
  short sVar18;
  short sVar19;
  float ******unaff_ESI;
  int iVar20;
  float *****pppppfVar21;
  float ******ppppppfVar22;
  int iVar23;
  float ******ppppppfVar24;
  int iVar25;
  float ******ppppppfVar26;
  uint uVar27;
  bool bVar28;
  ushort in_FPUStatusWord;
  ushort uVar29;
  float10 fVar30;
  undefined4 *puVar31;
  float *****pppppfStack_7bc;
  float *****pppppfStack_7b8;
  float *****pppppfStack_7b4;
  float *****pppppfStack_7b0;
  float ****ppppfStack_7ac;
  undefined **ppuStack_7a8;
  float *****pppppfStack_7a4;
  float *****pppppfStack_7a0;
  float *****pppppfStack_79c;
  float *****pppppfStack_798;
  float *****pppppfStack_794;
  float *****pppppfStack_790;
  float *****pppppfStack_78c;
  float *****pppppfStack_788;
  float *****pppppfStack_784;
  float ****ppppfStack_780;
  float ****ppppfStack_77c;
  float ****ppppfStack_778;
  float *****pppppfStack_774;
  float ****ppppfStack_770;
  float *****pppppfStack_76c;
  float *****pppppfStack_768;
  undefined *puStack_764;
  wchar_t *pwStack_760;
  float *****pppppfStack_75c;
  float *****pppppfStack_758;
  float *****pppppfStack_754;
  float ****ppppfStack_750;
  float ****ppppfStack_74c;
  float *****pppppfStack_748;
  float *****pppppfStack_744;
  wchar_t *pwStack_740;
  float *****pppppfStack_73c;
  float *****pppppfStack_738;
  float ****ppppfStack_734;
  float ****ppppfStack_730;
  float *****pppppfStack_72c;
  float ****ppppfStack_728;
  float *****pppppfStack_724;
  float *****pppppfStack_720;
  float ****ppppfStack_71c;
  float *****pppppfStack_718;
  float *****pppppfStack_714;
  float *****pppppfStack_710;
  float *****pppppfStack_70c;
  float fStack_708;
  float fStack_704;
  short sStack_6ec;
  short sStack_6e4;
  float *****pppppfStack_6dc;
  float ****ppppfStack_6d8;
  uint uStack_6d4;
  uint uStack_6d0;
  undefined4 uStack_6ac;
  float ****ppppfStack_6a8;
  float fStack_6a0;
  float ***apppfStack_69c [2];
  float *****pppppfStack_694;
  float ****ppppfStack_68c;
  float *****pppppfStack_688;
  float ****ppppfStack_684;
  float *****pppppfStack_680;
  float ****appppfStack_67c [2];
  float *****pppppfStack_674;
  float ****ppppfStack_66c;
  float *****pppppfStack_668;
  wchar_t *pwStack_664;
  float *****pppppfStack_660;
  float ***apppfStack_65c [4];
  float ****ppppfStack_64c;
  undefined *puStack_648;
  wchar_t *pwStack_644;
  undefined4 uStack_640;
  float ****appppfStack_63c [2];
  undefined4 uStack_634;
  float ****appppfStack_62c [2];
  undefined4 uStack_624;
  float ****ppppfStack_61c;
  undefined4 uStack_618;
  float ****ppppfStack_614;
  undefined4 uStack_610;
  float ***pppfStack_60c;
  undefined4 uStack_608;
  undefined4 uStack_604;
  float *****pppppfStack_600;
  float *****pppppfStack_5fc;
  float ****ppppfStack_5f8;
  float *****pppppfStack_5f4;
  undefined4 uStack_5f0;
  undefined4 uStack_5ec;
  undefined *puStack_5e8;
  float ****ppppfStack_5e4;
  float *****pppppfStack_5e0;
  float *****pppppfStack_5dc;
  float *****pppppfStack_5d8;
  float *****pppppfStack_5d4;
  float ****ppppfStack_5d0;
  float *****pppppfStack_5cc;
  float *****pppppfStack_5c8;
  float ****ppppfStack_5c4;
  float *****pppppfStack_5c0;
  float *****pppppfStack_5bc;
  float *****pppppfStack_5b8;
  float *****pppppfStack_5b4;
  float *****pppppfStack_5b0;
  float *****pppppfStack_5ac;
  float *****pppppfStack_5a8;
  float *****pppppfStack_5a4;
  float *****pppppfStack_5a0;
  float *****pppppfStack_59c;
  float *****pppppfStack_598;
  undefined4 uStack_594;
  undefined4 uStack_590;
  float *****pppppfStack_58c;
  wchar_t *pwStack_588;
  float *****pppppfStack_584;
  float *****pppppfStack_580;
  float *****pppppfStack_57c;
  float *****pppppfStack_578;
  float *****pppppfStack_574;
  float *****pppppfStack_570;
  float *****pppppfStack_56c;
  float *****pppppfStack_568;
  float *****pppppfStack_564;
  float *****pppppfStack_560;
  float *****pppppfStack_55c;
  float *****pppppfStack_558;
  float *****pppppfStack_554;
  float *****pppppfStack_550;
  float *****pppppfStack_54c;
  float *****pppppfStack_548;
  float *****pppppfStack_544;
  float *****pppppfStack_540;
  float *****pppppfStack_53c;
  float *****pppppfStack_538;
  float *****pppppfStack_534;
  float *****pppppfStack_530;
  float *****pppppfStack_52c;
  float *****pppppfStack_528;
  float *****pppppfStack_524;
  float *****pppppfStack_520;
  float *****pppppfStack_51c;
  float *****pppppfStack_518;
  float *****pppppfStack_514;
  float *****pppppfStack_510;
  float *****pppppfStack_50c;
  float *****pppppfStack_508;
  float *****pppppfStack_504;
  float *****pppppfStack_500;
  float *****pppppfStack_4fc;
  float *****pppppfStack_4f8;
  undefined4 *puStack_4f4;
  float *****pppppfStack_4f0;
  undefined4 uStack_4ec;
  int iStack_4e8;
  float *****pppppfStack_4e4;
  undefined *puStack_4e0;
  float *****pppppfStack_4dc;
  float *****pppppfStack_4d8;
  float *****pppppfStack_4d4;
  int **ppiStack_4d0;
  undefined4 uStack_4cc;
  int *piStack_4c8;
  undefined4 uStack_4c4;
  float *****pppppfStack_4c0;
  undefined4 uStack_4bc;
  int *piStack_4b8;
  float *****pppppfStack_4b4;
  undefined4 uStack_4b0;
  int iStack_4ac;
  float *****pppppfStack_4a8;
  undefined *puStack_4a4;
  float *****pppppfStack_4a0;
  int *piStack_49c;
  float *****pppppfStack_498;
  undefined4 *puStack_494;
  undefined4 uStack_490;
  float *****pppppfStack_48c;
  undefined *puStack_488;
  float *****pppppfStack_484;
  float *****pppppfStack_480;
  float *****pppppfStack_47c;
  int *piStack_478;
  undefined4 uStack_474;
  float *****pppppfStack_470;
  undefined4 uStack_46c;
  int iStack_468;
  float *****pppppfStack_464;
  undefined *puStack_460;
  float *****pppppfStack_45c;
  int *piStack_458;
  float *****pppppfStack_454;
  float *****pppppfStack_450;
  undefined4 uStack_44c;
  int iStack_448;
  float *****pppppfStack_444;
  wchar_t *pwStack_440;
  float *****pppppfStack_43c;
  int *piStack_438;
  float *****pppppfStack_434;
  int **ppiStack_430;
  float *****pppppfStack_42c;
  undefined4 *puStack_428;
  float *****pppppfStack_424;
  float *****pppppfStack_420;
  code *pcStack_41c;
  float ****ppppfStack_414;
  float *****pppppfStack_410;
  float fStack_408;
  int iStack_400;
  float *****pppppfStack_3fc;
  float fStack_3f8;
  float fStack_3f4;
  float *****pppppfStack_3f0;
  int iStack_3ec;
  float fStack_3e8;
  float fStack_3e4;
  short sStack_3dc;
  float *****pppppfStack_3d4;
  int *apiStack_3d0 [2];
  float *****pppppfStack_3c8;
  float *****pppppfStack_3c0;
  float *****pppppfStack_3b8;
  float *****pppppfStack_3b0;
  float *****pppppfStack_3a8;
  float *****pppppfStack_3a4;
  float ****ppppfStack_3a0;
  float *****pppppfStack_39c;
  undefined4 auStack_398 [6];
  float ****ppppfStack_380;
  float *****pppppfStack_378;
  undefined4 uStack_364;
  float *****pppppfStack_360;
  undefined4 uStack_35c;
  float *****pppppfStack_358;
  float *****pppppfStack_340;
  float *****pppppfStack_33c;
  float *****pppppfStack_338;
  float ****appppfStack_334 [3];
  undefined4 uStack_328;
  float *****pppppfStack_324;
  float *****pppppfStack_320;
  float *****pppppfStack_31c;
  float **ppfStack_318;
  float ****ppppfStack_314;
  float *****pppppfStack_310;
  float *****pppppfStack_30c;
  float *****pppppfStack_308;
  float *****pppppfStack_304;
  float *****pppppfStack_300;
  float *****pppppfStack_2fc;
  float *****pppppfStack_2f8;
  float ****ppppfStack_2f4;
  float *****pppppfStack_2f0;
  float *****pppppfStack_2ec;
  int *piStack_2e8;
  float *****pppppfStack_2e4;
  float *****pppppfStack_2e0;
  float *****pppppfStack_2dc;
  float *****pppppfStack_2d8;
  float *****pppppfStack_2d4;
  float *****pppppfStack_2d0;
  float *****pppppfStack_2cc;
  float *****pppppfStack_2c8;
  float ****ppppfStack_2c4;
  float *****pppppfStack_2c0;
  float *****pppppfStack_2bc;
  float *****pppppfStack_2b8;
  float *****pppppfStack_2b4;
  float *****pppppfStack_2b0;
  float *****pppppfStack_2ac;
  float *****pppppfStack_2a8;
  float *****pppppfStack_2a4;
  float *****pppppfStack_2a0;
  float *****pppppfStack_29c;
  float *****pppppfStack_298;
  float *****pppppfStack_294;
  float *****pppppfStack_290;
  float *****pppppfStack_28c;
  float *****pppppfStack_288;
  float *****pppppfStack_284;
  float *****pppppfStack_280;
  float *****pppppfStack_27c;
  float *****pppppfStack_278;
  float *****pppppfStack_274;
  float *****pppppfStack_270;
  float *****pppppfStack_26c;
  float *****pppppfStack_268;
  float *****pppppfStack_264;
  float *****pppppfStack_260;
  float *****pppppfStack_25c;
  float *****pppppfStack_258;
  float *****pppppfStack_254;
  float *****pppppfStack_250;
  float *****pppppfStack_24c;
  float *****pppppfStack_248;
  float *****pppppfStack_244;
  float *****pppppfStack_240;
  float *****pppppfStack_23c;
  float *****pppppfStack_238;
  float *****pppppfStack_234;
  float *****pppppfStack_230;
  float *****pppppfStack_22c;
  float *****pppppfStack_228;
  float *****pppppfStack_1e4;
  int local_1d0;
  int local_1cc;
  int local_1c4;
  int local_1c0;
  float *****pppppfStack_1b8;
  short local_178;
  short local_144;
  short local_13c;
  short local_134;
  short local_12c;
  float *****local_124;
  uint local_120;
  uint local_11c;
  uint local_118;
  float ***local_114;
  undefined4 local_100;
  float *****local_fc;
  float *****local_f4;
  float *****local_f0;
  undefined4 local_ec;
  int local_e8;
  float ****local_e4;
  float *****local_e0;
  float *****local_dc;
  float *****local_d8;
  float *****local_d4;
  float ****local_d0;
  undefined4 local_cc;
  undefined4 *local_c8;
  float ****local_c4;
  float *****local_c0;
  float *****local_bc;
  float *****local_b8;
  float *****local_b4;
  float ****local_b0;
  float *****local_ac;
  float *****local_a8;
  float *****local_a4;
  float ****local_a0;
  float *****local_9c;
  undefined4 local_98;
  undefined4 local_94;
  float ****local_90;
  float *****local_8c;
  float *****local_88;
  float *****local_84;
  float ****local_80;
  float *****local_7c;
  float *****local_78;
  float *****local_74;
  float ****local_70;
  float *****local_6c;
  float *****local_68;
  float *****local_64;
  float *****local_60;
  float ****local_5c;
  float ***local_58;
  float ****local_54;
  float ****local_50;
  float *****local_4c;
  float *****local_48;
  float ****local_44;
  float local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  uint local_2c;
  undefined4 local_28;
  uint local_24;
  undefined4 local_20;
  undefined4 local_1c;
  float *****local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  pcVar17 = __vbaGenerateBoundsError_exref;
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffddc;
  local_8 = &DAT_004022e8;
  ppppppfVar24 = (float ******)0x0;
  local_1c = 0;
  local_20 = 0;
  local_28 = 0;
  local_44 = (float ****)0x0;
  local_48 = (float *****)0x0;
  local_4c = (float *****)0x0;
  local_50 = (float ****)0x0;
  local_54 = (float ****)0x0;
  local_58 = (float ***)0x0;
  local_5c = (float ****)0x0;
  local_60 = (float *****)0x0;
  local_70 = (float ****)0x0;
  local_80 = (float ****)0x0;
  local_90 = (float ****)0x0;
  local_a0 = (float ****)0x0;
  local_b0 = (float ****)0x0;
  local_c0 = (float *****)0x0;
  local_d0 = (float ****)0x0;
  local_e0 = (float *****)0x0;
  local_f0 = (float *****)0x0;
  local_100 = 0;
  local_124 = (float *****)0x0;
  if (DAT_0050b2ca < 1) {
    ExceptionList = &pvStack_14;
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = &stack0xfffffddc;
    if (!SCARRY2(DAT_0050b20c,1)) {
      pppppfVar12 = (float *****)__vbaGenerateBoundsError_exref;
      ExceptionList = &pvStack_14;
      puVar6 = &stack0xfffffddc;
      if (DAT_0050b2cc < (short)(DAT_0050b20c + 1)) {
        if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
          pppppfStack_228 = (float *****)0x4b8ebd;
          ExceptionList = &pvStack_14;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          unaff_EBX = DAT_0050b0dc[5];
          ExceptionList = &pvStack_14;
          puVar6 = &stack0xfffffddc;
          if (SCARRY2(DAT_0050b2cc,(short)_DAT_0050b2c4)) goto LAB_004bc751;
          pppppfVar12 = (float *****)
                        ((int)(short)(DAT_0050b2cc + (short)_DAT_0050b2c4) - (int)unaff_EBX);
          ExceptionList = &pvStack_14;
          local_c = &stack0xfffffddc;
          if (DAT_0050b0dc[4] <= pppppfVar12) {
            pppppfStack_228 = (float *****)0x4b8ea2;
            ExceptionList = &pvStack_14;
            local_c = &stack0xfffffddc;
            __vbaGenerateBoundsError();
          }
          iVar20 = (int)pppppfVar12 * 8;
        }
        ppppppfVar10 = _DAT_0050b2c4;
        local_40 = (float)*(double *)((int)DAT_0050b0dc[3] + iVar20);
        ppppppfVar9 = (float ******)&DAT_00000001;
        do {
          unaff_ESI = ppppppfVar9;
          uVar13 = _DAT_0050b20c;
          ppppppfVar24 = (float ******)0x0;
          local_13c = (short)ppppppfVar10;
          sVar18 = (short)unaff_ESI;
          if (local_13c < sVar18) {
            ppppppfVar10 = (float ******)
                           CONCAT22((short)((uint)_DAT_0050b2c4 >> 0x10),(short)_DAT_0050b2c4 + 1);
            ppppppfVar26 = (float ******)pppppfStack_23c;
            ppppppfVar22 = (float ******)pppppfStack_230;
            uVar27 = local_2c;
            uVar5 = local_24;
            puVar6 = local_c;
            if (!SCARRY2((short)_DAT_0050b2c4,1)) goto LAB_004b8fb2;
            break;
          }
          if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
            pppppfStack_228 = (float *****)0x4b8f1e;
            unaff_EBX = (float *****)__vbaGenerateBoundsError();
          }
          else {
            ppppppfVar24 = (float ******)((int)sVar18 - (int)DAT_0050b0dc[5]);
            if (DAT_0050b0dc[4] <= ppppppfVar24) {
              pppppfStack_228 = (float *****)0x4b8f09;
              __vbaGenerateBoundsError();
            }
            unaff_EBX = (float *****)((int)ppppppfVar24 * 8);
          }
          if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
            pppppfStack_228 = (float *****)0x4b8f5a;
            iVar20 = __vbaGenerateBoundsError();
          }
          else {
            ppppppfVar24 = (float ******)((int)sVar18 - (int)DAT_0050b0dc[5]);
            if (DAT_0050b0dc[4] <= ppppppfVar24) {
              pppppfStack_228 = (float *****)0x4b8f45;
              __vbaGenerateBoundsError();
            }
            iVar20 = (int)ppppppfVar24 * 8;
          }
          *(double *)((int)DAT_0050b0dc[3] + iVar20) =
               (double)(local_40 + (float)*(double *)((int)unaff_EBX + (int)DAT_0050b0dc[3]));
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
          ppppppfVar9 = (float ******)(uint)(ushort)(sVar18 + 1);
          ppppppfVar26 = (float ******)pppppfStack_23c;
          ppppppfVar22 = (float ******)pppppfStack_230;
          uVar27 = local_2c;
          uVar5 = local_24;
          puVar6 = local_c;
        } while (!SCARRY2(sVar18,1));
      }
      else {
LAB_004b90c8:
        local_c = puVar6;
        unaff_EBX = pppppfVar12;
        ppppppfVar24 = (float ******)0x0;
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_228 = (float *****)&DAT_0050b420;
          pppppfStack_22c = (float *****)&DAT_00408c88;
          pppppfStack_230 = (float *****)0x4b90e1;
          __vbaNew2();
        }
        pppppfStack_228 = (float *****)DAT_0050b420;
        pppppfStack_22c = (float *****)0x4b90ef;
        pppppfStack_22c = (float *****)(*(code *)(*DAT_0050b420)[0xea])();
        pppppfStack_230 = (float *****)&local_124;
        pppppfStack_234 = (float *****)0x4b90fd;
        __vbaObjSet();
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          pppppfStack_228 = (float *****)0x4b9148;
          iVar20 = (*(code *)unaff_EBX)();
        }
        else {
          iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar20) {
            pppppfStack_228 = (float *****)0x4b9120;
            (*(code *)unaff_EBX)();
          }
          ppppppfVar24 = (float ******)-*(int *)(DAT_0050b1a4 + 10);
          if (*(float *******)(DAT_0050b1a4 + 8) <= ppppppfVar24) {
            pppppfStack_228 = (float *****)0x4b9134;
            (*(code *)unaff_EBX)();
          }
          iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)ppppppfVar24 + (1U - iVar20)) * 2;
        }
        unaff_ESI = (float ******)__vbaLateIdSt_exref;
        if (*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20) < 3) {
LAB_004b93f2:
          pppppfStack_228 = (float *****)0x0;
          pppppfStack_22c = (float *****)0x4;
          pppppfStack_234 = &local_70;
          pppppfStack_230 = local_124;
          pppppfStack_238 = (float *****)0x4b9407;
          pppppfStack_228 = (float *****)__vbaLateIdCallLd();
          pppppfStack_22c = (float *****)0x4b9411;
          iVar20 = __vbaI4Var();
          ppppppfVar26 = (float ******)pppppfStack_23c;
          ppppppfVar22 = (float ******)pppppfStack_230;
          uVar27 = local_2c;
          uVar5 = local_24;
          puVar6 = local_c;
          if (!SBORROW4(iVar20,1)) {
            pppppfStack_228 = (float *****)0x4b9422;
            sVar18 = __vbaI2I4();
            ppppppfVar10 = _DAT_0050b298;
            unaff_EBX = (float *****)&DAT_00000001;
            pppppfStack_228 = (float *****)0x4b943c;
            __vbaFreeVar();
            do {
              ppppppfVar24 = ppppppfVar10;
              sVar19 = (short)ppppppfVar24;
              if (sVar18 < sVar19) {
                pppppfStack_228 = (float *****)0x0;
                pppppfStack_22c = (float *****)0x5;
                pppppfStack_234 = &local_70;
                pppppfStack_230 = local_124;
                pppppfStack_238 = (float *****)0x4b9651;
                pppppfStack_228 = (float *****)__vbaLateIdCallLd();
                pppppfStack_22c = (float *****)0x4b965b;
                iVar20 = __vbaI4Var();
                ppppppfVar26 = (float ******)pppppfStack_23c;
                ppppppfVar22 = (float ******)pppppfStack_230;
                uVar27 = local_2c;
                uVar5 = local_24;
                puVar6 = local_c;
                if (!SBORROW4(iVar20,1)) {
                  pppppfStack_228 = (float *****)0x4b966c;
                  sVar18 = __vbaI2I4();
                  unaff_EBX = (float *****)&DAT_00000001;
                  pppppfStack_228 = (float *****)0x4b9682;
                  __vbaFreeVar();
                  uVar13 = extraout_ECX;
                  ppppppfVar10 = (float ******)&DAT_00000001;
                  goto LAB_004b9682;
                }
                break;
              }
              local_c0 = (float *****)0x3;
              pppppfStack_22c = (float *****)(int)sVar19;
              pppppfStack_234 = (float *****)0x3;
              pppppfStack_238 = (float *****)0xa;
              pppppfStack_230 = local_bc;
              pppppfStack_23c = local_124;
              pppppfStack_228 = local_b4;
              pppppfStack_240 = (float *****)0x4b9484;
              local_b8 = pppppfStack_22c;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0x3;
              pppppfStack_250 = (float *****)0xb;
              pppppfStack_24c = (float *****)0x3;
              local_b8 = (float *****)0x0;
              pppppfStack_248 = local_bc;
              pppppfStack_254 = local_124;
              pppppfStack_244 = (float *****)0x0;
              pppppfStack_240 = local_b4;
              pppppfStack_258 = (float *****)0x4b94be;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0x3;
              pppppfStack_268 = (float *****)0x26;
              pppppfStack_264 = (float *****)0x3;
              local_b8 = (float *****)0xffff00;
              pppppfStack_260 = local_bc;
              pppppfStack_26c = local_124;
              pppppfStack_25c = (float *****)0xffff00;
              pppppfStack_258 = local_b4;
              pppppfStack_270 = (float *****)0x4b94fb;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0x3;
              pppppfStack_280 = (float *****)0x27;
              pppppfStack_27c = (float *****)0x3;
              local_b8 = (float *****)0xff0000;
              pppppfStack_278 = local_bc;
              pppppfStack_284 = local_124;
              pppppfStack_274 = (float *****)0xff0000;
              pppppfStack_270 = local_b4;
              pppppfStack_288 = (float *****)0x4b9538;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0x3;
              pppppfStack_298 = (float *****)0xb;
              pppppfStack_294 = (float *****)0x3;
              local_b8 = (float *****)0x2;
              pppppfStack_290 = local_bc;
              pppppfStack_29c = local_124;
              pppppfStack_28c = (float *****)0x2;
              pppppfStack_288 = local_b4;
              pppppfStack_2a0 = (float *****)0x4b9575;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0x2;
              local_b8 = (float *****)0x1;
              pppppfStack_2b0 = (float *****)0x28;
              pppppfStack_2ac = (float *****)0x2;
              pppppfStack_2a8 = local_bc;
              pppppfStack_2b4 = local_124;
              pppppfStack_2a4 = (float *****)&DAT_00000001;
              pppppfStack_2a0 = local_b4;
              pppppfStack_2b8 = (float *****)0x4b95b2;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0x3;
              pppppfStack_2c8 = (float *****)0x27;
              ppppfStack_2c4 = (float ****)0x3;
              local_b8 = (float *****)0xffff00;
              pppppfStack_2c0 = local_bc;
              pppppfStack_2cc = local_124;
              pppppfStack_2bc = (float *****)0xffff00;
              pppppfStack_2b8 = local_b4;
              pppppfStack_2d0 = (float *****)0x4b95ef;
              (*(code *)unaff_ESI)();
              local_c0 = (float *****)0xb;
              pppppfStack_2e0 = (float *****)0x4f;
              pppppfStack_2dc = (float *****)0xb;
              local_b8 = (float *****)0x0;
              pppppfStack_2d8 = local_bc;
              pppppfStack_2e4 = local_124;
              pppppfStack_2d4 = (float *****)0x0;
              pppppfStack_2d0 = local_b4;
              piStack_2e8 = (int *)0x4b9629;
              (*(code *)unaff_ESI)();
              ppppppfVar10 = (float ******)CONCAT22(extraout_var_00,sVar19 + 1);
              ppppppfVar26 = (float ******)pppppfStack_23c;
              ppppppfVar22 = (float ******)pppppfStack_230;
              uVar27 = local_2c;
              uVar5 = local_24;
              puVar6 = local_c;
            } while (!SCARRY2(sVar19,1));
          }
        }
        else {
          if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
            pppppfStack_228 = (float *****)0x4b91a1;
            iVar20 = (*(code *)unaff_EBX)();
          }
          else {
            iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
            if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar20) {
              pppppfStack_228 = (float *****)0x4b9179;
              (*(code *)unaff_EBX)();
            }
            iVar23 = *(int *)(DAT_0050b1a4 + 10);
            if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)-iVar23) {
              pppppfStack_228 = (float *****)0x4b918d;
              (*(code *)unaff_EBX)();
            }
            iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * -iVar23 + (1U - iVar20)) * 2;
          }
          unaff_ESI = (float ******)__vbaLateIdSt_exref;
          sVar18 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20);
          local_18 = (float *****)&DAT_00000001;
          ppppppfVar10 = (float ******)local_18;
          do {
            local_18 = (float *****)ppppppfVar10;
            ppppppfVar24 = (float ******)local_18;
            if (sVar18 < (short)local_18) {
              if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
                pppppfStack_228 = (float *****)0x4b93db;
                iVar20 = (*(code *)unaff_EBX)();
                *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar20) = 2;
              }
              else {
                ppppppfVar24 = (float ******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
                if (*(float *******)(DAT_0050b1a4 + 0xc) <= ppppppfVar24) {
                  pppppfStack_228 = (float *****)0x4b93a6;
                  (*(code *)unaff_EBX)();
                }
                unaff_EBX = (float *****)-*(int *)(DAT_0050b1a4 + 10);
                if (*(float ******)(DAT_0050b1a4 + 8) <= unaff_EBX) {
                  pppppfStack_228 = (float *****)0x4b93be;
                  __vbaGenerateBoundsError();
                }
                *(undefined2 *)
                 (*(int *)(DAT_0050b1a4 + 6) +
                 (int)(*(int *)(DAT_0050b1a4 + 0xc) * (int)unaff_EBX + (int)ppppppfVar24) * 2) = 2;
              }
              goto LAB_004b93f2;
            }
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              pppppfStack_228 = (float *****)0x4b922a;
              iVar20 = (*(code *)unaff_EBX)();
            }
            else {
              iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar20) {
                pppppfStack_228 = (float *****)0x4b91f1;
                __vbaGenerateBoundsError();
              }
              iVar25 = (int)(short)local_18;
              iVar23 = *(int *)(DAT_0050b1a4 + 10);
              if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(iVar25 - iVar23)) {
                pppppfStack_228 = (float *****)0x4b920d;
                __vbaGenerateBoundsError();
              }
              iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (iVar25 - iVar23) + (1U - iVar20)) * 2;
              unaff_EBX = (float *****)__vbaGenerateBoundsError_exref;
              ppppppfVar24 = (float ******)local_18;
            }
            pppppfStack_22c = (float *****)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20);
            local_c0 = (float *****)0x3;
            pppppfStack_234 = (float *****)0x3;
            pppppfStack_238 = (float *****)0xa;
            pppppfStack_230 = local_bc;
            pppppfStack_23c = local_124;
            pppppfStack_228 = local_b4;
            pppppfStack_240 = (float *****)0x4b926f;
            local_b8 = pppppfStack_22c;
            __vbaLateIdSt();
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              pppppfStack_240 = (float *****)0x4b92cf;
              iVar20 = (*(code *)unaff_EBX)();
            }
            else {
              iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= 2U - iVar20) {
                pppppfStack_240 = (float *****)0x4b9296;
                __vbaGenerateBoundsError();
              }
              iVar25 = (int)(short)local_18;
              iVar23 = *(int *)(DAT_0050b1a4 + 10);
              if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(iVar25 - iVar23)) {
                pppppfStack_240 = (float *****)0x4b92b2;
                __vbaGenerateBoundsError();
              }
              iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (iVar25 - iVar23) + (2U - iVar20)) * 2;
              unaff_EBX = (float *****)__vbaGenerateBoundsError_exref;
              ppppppfVar24 = (float ******)local_18;
            }
            pppppfStack_244 = (float *****)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20);
            local_c0 = (float *****)0x3;
            pppppfStack_250 = (float *****)0xb;
            pppppfStack_24c = (float *****)0x3;
            pppppfStack_248 = local_bc;
            pppppfStack_254 = local_124;
            pppppfStack_240 = local_b4;
            pppppfStack_258 = (float *****)0x4b9314;
            local_b8 = pppppfStack_244;
            __vbaLateIdSt();
            sVar19 = (short)ppppppfVar24;
            if (sVar19 == 1) {
              pppppfStack_25c = (float *****)0xff00;
            }
            else if (sVar19 == 2) {
              pppppfStack_25c = (float *****)0xff;
            }
            else {
              pppppfStack_258 = (float *****)0x8;
              pppppfStack_25c = (float *****)0x4b9325;
              pppppfStack_25c = (float *****)Ordinal_589();
            }
            local_c0 = (float *****)0x3;
            pppppfStack_268 = (float *****)0x26;
            pppppfStack_264 = (float *****)0x3;
            pppppfStack_260 = local_bc;
            pppppfStack_26c = local_124;
            pppppfStack_258 = local_b4;
            pppppfStack_270 = (float *****)0x4b936b;
            local_b8 = pppppfStack_25c;
            __vbaLateIdSt();
            ppppppfVar26 = (float ******)pppppfStack_23c;
            ppppppfVar22 = (float ******)pppppfStack_230;
            uVar27 = local_2c;
            uVar5 = local_24;
            ppppppfVar10 = (float ******)(uint)(ushort)(sVar19 + 1);
            puVar6 = local_c;
          } while (!SCARRY2(sVar19,1));
        }
      }
    }
  }
  else {
    if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
      pppppfStack_228 = (float *****)0x4b8c46;
      ExceptionList = &pvStack_14;
      local_c = &stack0xfffffddc;
      iVar20 = __vbaGenerateBoundsError();
      unaff_EBX = (float *****)__vbaGenerateBoundsError_exref;
    }
    else {
      pppppfVar12 = DAT_0050b0dc[5];
      iVar20 = (int)DAT_0050b2ca;
      ExceptionList = &pvStack_14;
      local_c = &stack0xfffffddc;
      if (DAT_0050b0dc[4] <= (float *****)(iVar20 - (int)pppppfVar12)) {
        pppppfStack_228 = (float *****)0x4b8c31;
        ExceptionList = &pvStack_14;
        local_c = &stack0xfffffddc;
        __vbaGenerateBoundsError();
      }
      iVar20 = (iVar20 - (int)pppppfVar12) * 8;
      unaff_EBX = (float *****)pcVar17;
    }
    ppppppfVar10 = _DAT_0050b2c4;
    local_40 = (float)*(double *)((int)DAT_0050b0dc[3] + iVar20);
    ppppppfVar9 = (float ******)&DAT_00000001;
    do {
      unaff_ESI = ppppppfVar9;
      uVar13 = _DAT_0050b20c;
      ppppppfVar24 = (float ******)0x0;
      local_12c = (short)ppppppfVar10;
      sVar18 = (short)unaff_ESI;
      if (local_12c < sVar18) {
        ppppppfVar10 = (float ******)
                       CONCAT22((short)((uint)_DAT_0050b2c4 >> 0x10),(short)_DAT_0050b2c4 + 1);
        ppppppfVar26 = (float ******)pppppfStack_23c;
        ppppppfVar22 = (float ******)pppppfStack_230;
        uVar27 = local_2c;
        uVar5 = local_24;
        puVar6 = local_c;
        if (!SCARRY2((short)_DAT_0050b2c4,1)) goto LAB_004b8d3e;
        break;
      }
      if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
        pppppfStack_228 = (float *****)0x4b8ca8;
        iVar20 = __vbaGenerateBoundsError();
      }
      else {
        pppppfVar12 = DAT_0050b0dc[5];
        if (DAT_0050b0dc[4] <= (float *****)((int)sVar18 - (int)pppppfVar12)) {
          pppppfStack_228 = (float *****)0x4b8c93;
          (*(code *)unaff_EBX)();
        }
        iVar20 = ((int)sVar18 - (int)pppppfVar12) * 8;
      }
      if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
        pppppfStack_228 = (float *****)0x4b8ce0;
        ppppppfVar24 = (float ******)__vbaGenerateBoundsError();
      }
      else {
        pppppfVar12 = DAT_0050b0dc[5];
        if (DAT_0050b0dc[4] <= (float *****)((int)sVar18 - (int)pppppfVar12)) {
          pppppfStack_228 = (float *****)0x4b8ccf;
          __vbaGenerateBoundsError();
        }
        ppppppfVar24 = (float ******)(((int)sVar18 - (int)pppppfVar12) * 8);
      }
      unaff_EBX = (float *****)__vbaGenerateBoundsError_exref;
      *(double *)((int)DAT_0050b0dc[3] + (int)ppppppfVar24) =
           (double)((float)*(double *)((int)DAT_0050b0dc[3] + iVar20) - local_40);
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
      ppppppfVar9 = (float ******)(uint)(ushort)(sVar18 + 1);
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
    } while (!SCARRY2(sVar18,1));
  }
  goto LAB_004bc751;
  while( true ) {
    if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
      pppppfStack_228 = (float *****)0x4b8ff3;
      unaff_EBX = (float *****)__vbaGenerateBoundsError();
    }
    else {
      pppppfVar12 = DAT_0050b0dc[5];
      if (DAT_0050b0dc[4] <= (float *****)((int)sVar18 - (int)pppppfVar12)) {
        pppppfStack_228 = (float *****)0x4b8fde;
        __vbaGenerateBoundsError();
      }
      unaff_EBX = (float *****)(((int)sVar18 - (int)pppppfVar12) * 8);
    }
    if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
      pppppfStack_228 = (float *****)0x4b902b;
      ppppppfVar24 = (float ******)__vbaGenerateBoundsError();
    }
    else {
      pppppfVar12 = DAT_0050b0dc[5];
      if (DAT_0050b0dc[4] <= (float *****)((int)sVar18 - (int)pppppfVar12)) {
        pppppfStack_228 = (float *****)0x4b901a;
        __vbaGenerateBoundsError();
      }
      ppppppfVar24 = (float ******)(((int)sVar18 - (int)pppppfVar12) * 8);
    }
    *(double *)((int)DAT_0050b0dc[3] + (int)ppppppfVar24) =
         (double)((float)*(double *)((int)unaff_EBX + (int)DAT_0050b0dc[3]) - local_40);
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
    ppppppfVar10 = (float ******)(uint)(ushort)(sVar18 + 1);
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2(sVar18,1)) break;
LAB_004b8fb2:
    unaff_ESI = ppppppfVar10;
    ppppppfVar24 = (float ******)0x0;
    local_144 = (short)uVar13;
    sVar18 = (short)unaff_ESI;
    if (local_144 < sVar18) {
      if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
        pppppfStack_228 = (float *****)0x4b90a5;
        iVar20 = __vbaGenerateBoundsError();
      }
      else {
        ppppppfVar26 = (float ******)pppppfStack_23c;
        ppppppfVar22 = (float ******)pppppfStack_230;
        uVar27 = local_2c;
        uVar5 = local_24;
        puVar6 = local_c;
        if (SCARRY2((short)_DAT_0050b20c,1)) break;
        pppppfVar12 = (float *****)((int)(short)((short)_DAT_0050b20c + 1) - (int)DAT_0050b0dc[5]);
        if (DAT_0050b0dc[4] <= pppppfVar12) {
          pppppfStack_228 = (float *****)0x4b9094;
          __vbaGenerateBoundsError();
        }
        iVar20 = (int)pppppfVar12 * 8;
      }
      *(double *)((int)DAT_0050b0dc[3] + iVar20) = (double)-local_40;
      pppppfVar12 = (float *****)__vbaGenerateBoundsError_exref;
      puVar6 = local_c;
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
      goto LAB_004b90c8;
    }
  }
  goto LAB_004bc751;
  while( true ) {
    if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
      pppppfStack_228 = (float *****)0x4b8d7b;
      iVar20 = __vbaGenerateBoundsError();
    }
    else {
      pppppfVar12 = DAT_0050b0dc[5];
      if (DAT_0050b0dc[4] <= (float *****)((int)sVar18 - (int)pppppfVar12)) {
        pppppfStack_228 = (float *****)0x4b8d66;
        (*(code *)unaff_EBX)();
      }
      iVar20 = ((int)sVar18 - (int)pppppfVar12) * 8;
    }
    if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
      pppppfStack_228 = (float *****)0x4b8db3;
      ppppppfVar24 = (float ******)__vbaGenerateBoundsError();
    }
    else {
      pppppfVar12 = DAT_0050b0dc[5];
      if (DAT_0050b0dc[4] <= (float *****)((int)sVar18 - (int)pppppfVar12)) {
        pppppfStack_228 = (float *****)0x4b8da2;
        __vbaGenerateBoundsError();
      }
      ppppppfVar24 = (float ******)(((int)sVar18 - (int)pppppfVar12) * 8);
    }
    unaff_EBX = (float *****)__vbaGenerateBoundsError_exref;
    *(double *)((int)DAT_0050b0dc[3] + (int)ppppppfVar24) =
         (double)(local_40 + (float)*(double *)((int)DAT_0050b0dc[3] + iVar20));
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
    ppppppfVar10 = (float ******)(uint)(ushort)(sVar18 + 1);
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2(sVar18,1)) break;
LAB_004b8d3e:
    unaff_ESI = ppppppfVar10;
    ppppppfVar24 = (float ******)0x0;
    local_134 = (short)uVar13;
    sVar18 = (short)unaff_ESI;
    if (local_134 < sVar18) {
      pppppfVar12 = unaff_EBX;
      if ((DAT_0050b0dc == (float ******)0x0) || (*(short *)DAT_0050b0dc != 1)) {
        pppppfStack_228 = (float *****)0x4b8e3a;
        iVar20 = (*(code *)unaff_EBX)();
        *(double *)((int)DAT_0050b0dc[3] + iVar20) = (double)local_40;
        puVar6 = local_c;
        goto LAB_004b90c8;
      }
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (!SCARRY2((short)_DAT_0050b20c,1)) {
        pppppfVar21 = (float *****)((int)(short)((short)_DAT_0050b20c + 1) - (int)DAT_0050b0dc[5]);
        if (DAT_0050b0dc[4] <= pppppfVar21) {
          pppppfStack_228 = (float *****)0x4b8e1d;
          (*(code *)unaff_EBX)();
        }
        *(double *)(DAT_0050b0dc[3] + (int)pppppfVar21 * 2) = (double)local_40;
        puVar6 = local_c;
        goto LAB_004b90c8;
      }
      break;
    }
  }
  goto LAB_004bc751;
  while( true ) {
    local_c0 = (float *****)0x3;
    pppppfStack_228 = (float *****)(int)sVar19;
    pppppfStack_230 = (float *****)0x3;
    pppppfStack_234 = (float *****)0xb;
    pppppfStack_22c = local_bc;
    pppppfStack_238 = local_124;
    pppppfStack_23c = (float *****)0x4b96ca;
    local_b8 = pppppfStack_228;
    (*(code *)unaff_ESI)();
    pppppfStack_240 = (float *****)(int)DAT_0050b298;
    local_c0 = (float *****)0x3;
    pppppfStack_24c = (float *****)0xa;
    pppppfStack_248 = (float *****)0x3;
    pppppfStack_244 = local_bc;
    pppppfStack_250 = local_124;
    pppppfStack_23c = local_b4;
    pppppfStack_254 = (float *****)0x4b9709;
    local_b8 = pppppfStack_240;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_264 = (float *****)0x26;
    pppppfStack_260 = (float *****)0x3;
    local_b8 = (float *****)0xffff00;
    pppppfStack_25c = local_bc;
    pppppfStack_268 = local_124;
    pppppfStack_258 = (float *****)0xffff00;
    pppppfStack_254 = local_b4;
    pppppfStack_26c = (float *****)0x4b9746;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_27c = (float *****)0x27;
    pppppfStack_278 = (float *****)0x3;
    local_b8 = (float *****)0xff0000;
    pppppfStack_274 = local_bc;
    pppppfStack_280 = local_124;
    pppppfStack_270 = (float *****)0xff0000;
    pppppfStack_26c = local_b4;
    pppppfStack_284 = (float *****)0x4b9783;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2(DAT_0050b298,2)) break;
    pppppfStack_22c = (float *****)(int)(short)(DAT_0050b298 + 2);
    pppppfStack_238 = (float *****)0xa;
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_230 = local_bc;
    pppppfStack_228 = local_b4;
    pppppfStack_23c = local_124;
    pppppfStack_240 = (float *****)0x4b97cf;
    local_b8 = pppppfStack_22c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x2;
    pppppfStack_250 = (float *****)0x28;
    pppppfStack_24c = (float *****)0x2;
    local_b8 = (float *****)0x1;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)&DAT_00000001;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4b980c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_268 = (float *****)0x27;
    pppppfStack_264 = (float *****)0x3;
    local_b8 = (float *****)0xffff00;
    pppppfStack_260 = local_bc;
    pppppfStack_26c = local_124;
    pppppfStack_25c = (float *****)0xffff00;
    pppppfStack_258 = local_b4;
    pppppfStack_270 = (float *****)0x4b9849;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0xb;
    pppppfStack_280 = (float *****)0x4f;
    pppppfStack_27c = (float *****)0xb;
    local_b8 = (float *****)0x0;
    pppppfStack_278 = local_bc;
    pppppfStack_284 = local_124;
    pppppfStack_274 = (float *****)0x0;
    pppppfStack_270 = local_b4;
    pppppfStack_288 = (float *****)0x4b9883;
    (*(code *)unaff_ESI)();
    uVar13 = extraout_ECX_00;
    ppppppfVar10 = (float ******)CONCAT22(extraout_var_01,sVar19 + 1);
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2(sVar19,1)) break;
LAB_004b9682:
    ppppppfVar24 = ppppppfVar10;
    sVar19 = (short)ppppppfVar24;
    if (sVar18 < sVar19) {
      local_b8 = (float *****)(int)DAT_0050b298;
      pppppfStack_228 = (float *****)CONCAT22((short)((uint)uVar13 >> 0x10),DAT_0050b244 + 1);
      local_c0 = (float *****)0x3;
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (!SCARRY2(DAT_0050b244,1)) {
        local_d8 = (float *****)0x0;
        local_e0 = (float *****)0x3;
        pppppfStack_22c = (float *****)0x4b98db;
        __vbaStrI2();
        ppppppfVar24 = (float ******)__vbaStrMove_exref;
        pppppfStack_22c = (float *****)0x4b98e8;
        pppppfStack_22c = (float *****)__vbaStrMove();
        pppppfStack_230 = (float *****)0x4b98ef;
        pppppfStack_254 = (float *****)__vbaStrCat();
        unaff_EBX = (float *****)__vbaLateIdCallSt_exref;
        pppppfStack_23c = local_c0;
        local_70 = (float ****)0x8;
        pppppfStack_238 = local_bc;
        pppppfStack_234 = local_b8;
        pppppfStack_230 = local_b4;
        pppppfStack_24c = local_e0;
        pppppfStack_248 = local_dc;
        pppppfStack_244 = local_d8;
        pppppfStack_240 = local_d4;
        pppppfStack_260 = (float *****)0x2;
        pppppfStack_25c = (float *****)0x8;
        pppppfStack_264 = (float *****)0x41;
        pppppfStack_258 = local_6c;
        pppppfStack_268 = local_124;
        pppppfStack_250 = local_64;
        pppppfStack_26c = (float *****)0x4b9973;
        local_68 = pppppfStack_254;
        __vbaLateIdCallSt();
        pppppfStack_230 = (float *****)0x4b997f;
        __vbaFreeStr();
        pppppfStack_230 = (float *****)0x4b9988;
        __vbaFreeVar();
        local_c0 = (float *****)0x3;
        ppppppfVar26 = (float ******)pppppfStack_23c;
        ppppppfVar22 = (float ******)pppppfStack_230;
        uVar27 = local_2c;
        uVar5 = local_24;
        puVar6 = local_c;
        if (!SCARRY2(DAT_0050b298,1)) {
          local_e0 = (float *****)0x3;
          pppppfStack_22c = (float *****)(int)(short)(DAT_0050b298 + 1);
          local_d8 = (float *****)&DAT_00000001;
          pppppfStack_234 = (float *****)0x3;
          pppppfStack_230 = local_bc;
          pppppfStack_228 = local_b4;
          pppppfStack_244 = (float *****)0x3;
          pppppfStack_240 = local_dc;
          pppppfStack_23c = (float *****)&DAT_00000001;
          pppppfStack_238 = local_d4;
          pppppfStack_258 = (float *****)0x2;
          pppppfStack_254 = (float *****)0x8;
          pppppfStack_25c = (float *****)0x41;
          pppppfStack_250 = local_fc;
          pppppfStack_24c = (float *****)0x411c88;
          pppppfStack_248 = local_f4;
          pppppfStack_260 = local_124;
          pppppfStack_264 = (float *****)0x4b9a34;
          local_b8 = pppppfStack_22c;
          __vbaLateIdCallSt();
          local_b8 = (float *****)(int)DAT_0050b298;
          pppppfStack_264 = (float *****)0x0;
          pppppfStack_268 = (float *****)0x5;
          pppppfStack_270 = &local_70;
          pppppfStack_26c = local_124;
          local_c0 = (float *****)0x3;
          pppppfStack_274 = (float *****)0x4b9a60;
          pppppfStack_228 = (float *****)__vbaLateIdCallLd();
          pppppfStack_22c = (float *****)0x4b9a6a;
          iVar20 = __vbaI4Var();
          ppppppfVar26 = (float ******)pppppfStack_23c;
          ppppppfVar22 = (float ******)pppppfStack_230;
          uVar27 = local_2c;
          uVar5 = local_24;
          puVar6 = local_c;
          if (!SBORROW4(iVar20,1)) {
            local_e0 = (float *****)0x3;
            pppppfStack_234 = local_c0;
            pppppfStack_230 = local_bc;
            pppppfStack_22c = local_b8;
            pppppfStack_228 = local_b4;
            pppppfStack_244 = (float *****)0x3;
            pppppfStack_240 = local_dc;
            pppppfStack_258 = (float *****)0x2;
            pppppfStack_25c = (float *****)0x41;
            pppppfStack_238 = local_d4;
            pppppfStack_254 = (float *****)0x8;
            pppppfStack_250 = local_fc;
            pppppfStack_24c = (float *****)0x40f0b4;
            pppppfStack_248 = local_f4;
            pppppfStack_260 = local_124;
            pppppfStack_264 = (float *****)0x4b9b00;
            pppppfStack_23c = (float *****)(iVar20 + -1);
            local_d8 = (float *****)(iVar20 + -1);
            __vbaLateIdCallSt();
            pppppfStack_228 = (float *****)0x4b9b0c;
            __vbaFreeVar();
            pppppfStack_228 = (float *****)0x0;
            pppppfStack_22c = (float *****)0x4;
            pppppfStack_234 = &local_70;
            pppppfStack_230 = local_124;
            pppppfStack_238 = (float *****)0x4b9b21;
            pppppfStack_228 = (float *****)__vbaLateIdCallLd();
            pppppfStack_22c = (float *****)0x4b9b2b;
            iVar20 = __vbaI4Var();
            ppppppfVar26 = (float ******)pppppfStack_23c;
            ppppppfVar22 = (float ******)pppppfStack_230;
            uVar27 = local_2c;
            uVar5 = local_24;
            puVar6 = local_c;
            if (!SBORROW4(iVar20,1)) {
              local_c0 = (float *****)0x3;
              local_e0 = (float *****)0x3;
              pppppfStack_234 = (float *****)0x3;
              local_d8 = (float *****)&DAT_00000001;
              pppppfStack_230 = local_bc;
              pppppfStack_228 = local_b4;
              pppppfStack_244 = (float *****)0x3;
              pppppfStack_240 = local_dc;
              pppppfStack_23c = (float *****)&DAT_00000001;
              pppppfStack_238 = local_d4;
              pppppfStack_258 = (float *****)0x2;
              pppppfStack_254 = (float *****)0x8;
              pppppfStack_25c = (float *****)0x41;
              pppppfStack_250 = local_fc;
              pppppfStack_24c = (float *****)0x40f18c;
              pppppfStack_248 = local_f4;
              pppppfStack_260 = local_124;
              pppppfStack_264 = (float *****)0x4b9bcc;
              pppppfStack_22c = (float *****)(iVar20 + -1);
              local_b8 = (float *****)(iVar20 + -1);
              __vbaLateIdCallSt();
              pppppfStack_228 = (float *****)0x4b9bd8;
              __vbaFreeVar();
              sVar18 = DAT_0050b20a;
              local_24 = 1;
              goto LAB_004b9bed;
            }
          }
        }
      }
      break;
    }
  }
  goto LAB_004bc751;
  while( true ) {
    iVar20 = (int)(short)local_24;
    if (DAT_0050b000 != 0) {
      pppppfStack_1b8 = (float *****)((ulonglong)(double)(int)DAT_0050b2c6 >> 0x20);
      pppppfStack_228 = pppppfStack_1b8;
      pppppfStack_230 = (float *****)0x4b9c5b;
      adj_fdiv_m64();
    }
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
    pppppfStack_228 = (float *****)0x4b9c6b;
    __vbaFPInt();
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
    pppppfStack_228 = (float *****)0x4b9c87;
    local_3c = __vbaFpI2();
    local_20 = CONCAT22(extraout_var_02,(short)local_24 % DAT_0050b2c6);
    local_c8 = &local_20;
    local_e0 = (float *****)0x4002;
    local_d0 = (float ****)0x4002;
    pppppfStack_228 = (float *****)&local_e0;
    local_d8 = (float *****)&DAT_0050b2c6;
    pppppfStack_234 = &local_70;
    local_c0 = (float *****)0xb;
    local_b8 = (float *****)CONCAT22(local_b8._2_2_,-(ushort)(0 < (short)local_24 % DAT_0050b2c6));
    pppppfStack_22c = &local_d0;
    pppppfStack_230 = (float *****)&local_c0;
    pppppfStack_238 = (float *****)0x4b9cf8;
    Ordinal_681();
    pppppfStack_238 = &local_70;
    local_e8 = 2;
    local_f0 = (float *****)0x2;
    pppppfStack_23c = (float *****)&local_f0;
    pppppfStack_240 = &local_80;
    pppppfStack_244 = (float *****)0x4b9d1e;
    pppppfStack_244 = (float *****)__vbaVarAdd();
    pppppfStack_248 = (float *****)0x4b9d25;
    local_20 = __vbaI2Var();
    pppppfStack_248 = &local_80;
    pppppfStack_24c = &local_70;
    pppppfStack_250 = (float *****)&local_c0;
    pppppfStack_254 = (float *****)0x3;
    pppppfStack_258 = (float *****)0x4b9d3f;
    __vbaFreeVarList();
    pppppfStack_24c = (float *****)(int)(short)local_20;
    local_c0 = (float *****)0x3;
    pppppfStack_254 = (float *****)0x3;
    pppppfStack_258 = (float *****)0xb;
    pppppfStack_250 = local_bc;
    pppppfStack_248 = local_b4;
    pppppfStack_25c = local_124;
    pppppfStack_260 = (float *****)0x4b9d78;
    local_b8 = pppppfStack_24c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2(DAT_0050b298,(short)local_3c)) break;
    pppppfStack_22c = (float *****)(int)(short)(DAT_0050b298 + (short)local_3c);
    pppppfStack_238 = (float *****)0xa;
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_230 = local_bc;
    pppppfStack_23c = local_124;
    pppppfStack_228 = local_b4;
    pppppfStack_240 = (float *****)0x4b9dc4;
    local_b8 = pppppfStack_22c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0xb;
    pppppfStack_250 = (float *****)0x4f;
    pppppfStack_24c = (float *****)0xb;
    local_b8 = (float *****)0x0;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)0x0;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4b9dfe;
    (*(code *)unaff_ESI)();
    pppppfStack_258 = (float *****)0x4b9e03;
    FUN_0044fdc0();
    pppppfStack_258 = (float *****)0x4b9e0a;
    __vbaStrMove();
    pppppfStack_258 = (float *****)0x0;
    pppppfStack_25c = (float *****)0xa;
    pppppfStack_264 = &local_90;
    pppppfStack_260 = local_124;
    pppppfStack_268 = (float *****)0x4b9e22;
    pppppfStack_258 = (float *****)__vbaLateIdCallLd();
    pppppfStack_25c = (float *****)0x4b9e2c;
    local_c8 = (undefined4 *)__vbaI4Var();
    pppppfStack_25c = (float *****)0x0;
    pppppfStack_260 = (float *****)0xb;
    pppppfStack_268 = &local_a0;
    pppppfStack_264 = local_124;
    local_d0 = (float ****)0x3;
    pppppfStack_26c = (float *****)0x4b9e54;
    pppppfStack_25c = (float *****)__vbaLateIdCallLd();
    pppppfStack_260 = (float *****)0x4b9e5e;
    local_e8 = __vbaI4Var();
    local_68 = local_48;
    pppppfStack_264 = &local_44;
    pppppfStack_260 = (float *****)DAT_0050b0e8;
    local_f0 = (float *****)0x3;
    local_48 = (float *****)0x0;
    local_70 = (float ****)0x8;
    pppppfStack_268 = (float *****)0x4b9e92;
    __vbaAryLock();
    if (((float *****)local_44 == (float *****)0x0) || (*(short *)local_44 != 1)) {
      pppppfStack_268 = (float *****)0x4b9ed1;
      iVar23 = __vbaGenerateBoundsError();
    }
    else {
      local_114 = (float ***)(iVar20 - (int)local_44[5]);
      if (local_44[4] <= local_114) {
        pppppfStack_268 = (float *****)0x4b9ebd;
        __vbaGenerateBoundsError();
      }
      iVar23 = (int)local_114 << 3;
    }
    pppppfStack_268 = (float *****)&DAT_00000001;
    local_b8 = (float *****)((int)local_44[3] + iVar23);
    pppppfStack_270 = &local_70;
    pppppfStack_26c = (float *****)&DAT_00000001;
    pppppfStack_274 = (float *****)&local_c0;
    pppppfStack_278 = &local_80;
    local_c0 = (float *****)0x4005;
    pppppfStack_27c = (float *****)0x4b9f02;
    Ordinal_660();
    pppppfStack_27c = &local_44;
    pppppfStack_280 = (float *****)0x4b9f0c;
    __vbaAryUnlock();
    pppppfStack_280 = &local_80;
    pppppfStack_284 = (float *****)0x4b9f16;
    pppppfStack_2a8 = (float *****)__vbaStrVarMove();
    local_b0 = (float ****)0x8;
    pppppfStack_290 = (float *****)local_d0;
    pppppfStack_28c = (float *****)local_cc;
    pppppfStack_288 = (float *****)local_c8;
    pppppfStack_284 = (float *****)local_c4;
    pppppfStack_2a0 = local_f0;
    pppppfStack_29c = (float *****)local_ec;
    pppppfStack_298 = (float *****)local_e8;
    pppppfStack_294 = (float *****)local_e4;
    pppppfStack_2b4 = (float *****)0x2;
    pppppfStack_2b8 = (float *****)0x41;
    pppppfStack_2b0 = (float *****)0x8;
    pppppfStack_2ac = local_ac;
    pppppfStack_2bc = local_124;
    pppppfStack_2a4 = local_a4;
    pppppfStack_2c0 = (float *****)0x4b9fa5;
    local_a8 = pppppfStack_2a8;
    __vbaLateIdCallSt();
    pppppfStack_284 = (float *****)0x4b9fb1;
    __vbaFreeStr();
    pppppfStack_284 = &local_b0;
    pppppfStack_288 = &local_80;
    pppppfStack_28c = &local_a0;
    pppppfStack_290 = &local_90;
    pppppfStack_294 = &local_70;
    pppppfStack_298 = (float *****)0x5;
    pppppfStack_29c = (float *****)0x4b9fd6;
    __vbaFreeVarList();
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2((short)local_3c,1)) break;
    if (SCARRY2((short)local_3c + 1,DAT_0050b298)) break;
    local_b8 = (float *****)(int)(short)((short)local_3c + 1 + DAT_0050b298);
    local_c0 = (float *****)0x3;
    pppppfStack_228 = (float *****)0x4ba02c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x2;
    pppppfStack_238 = (float *****)0x28;
    pppppfStack_234 = (float *****)0x2;
    local_b8 = (float *****)0x4;
    pppppfStack_230 = local_bc;
    pppppfStack_23c = local_124;
    pppppfStack_22c = (float *****)0x4;
    pppppfStack_228 = local_b4;
    pppppfStack_240 = (float *****)0x4ba069;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x4;
    pppppfStack_250 = (float *****)0x4e;
    pppppfStack_24c = (float *****)0x4;
    local_b8 = (float *****)0x41600000;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)0x41600000;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4ba0a6;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0xb;
    pppppfStack_268 = (float *****)0x4f;
    pppppfStack_264 = (float *****)0xb;
    local_b8 = (float *****)0xffffffff;
    pppppfStack_260 = local_bc;
    pppppfStack_26c = local_124;
    pppppfStack_25c = (float *****)0xffffffff;
    pppppfStack_258 = local_b4;
    pppppfStack_270 = (float *****)0x4ba0e1;
    (*(code *)unaff_ESI)();
    if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
      pppppfStack_228 = (float *****)0x4ba125;
      iVar23 = __vbaGenerateBoundsError();
    }
    else {
      local_114 = (float ***)(iVar20 - *(int *)(DAT_0050b1f8 + 10));
      if (*(float *****)(DAT_0050b1f8 + 8) <= local_114) {
        pppppfStack_228 = (float *****)0x4ba10f;
        __vbaGenerateBoundsError();
      }
      iVar23 = (int)local_114 * 2;
    }
    if ((*(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar23) < 0) && (0 < DAT_0050b25e)) {
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        pppppfStack_228 = (float *****)0x4ba1ba;
        local_1c0 = __vbaGenerateBoundsError();
      }
      else {
        local_120 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_120) {
          pppppfStack_228 = (float *****)0x4ba174;
          __vbaGenerateBoundsError();
        }
        local_11c = -*(int *)(DAT_0050b1a4 + 10);
        if (*(uint *)(DAT_0050b1a4 + 8) <= local_11c) {
          pppppfStack_228 = (float *****)0x4ba192;
          __vbaGenerateBoundsError();
        }
        local_1c0 = (*(int *)(DAT_0050b1a4 + 0xc) * local_11c + local_120) * 2;
      }
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        pppppfStack_228 = (float *****)0x4ba22d;
        iVar23 = __vbaGenerateBoundsError();
      }
      else {
        local_118 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_118) {
          pppppfStack_228 = (float *****)0x4ba1ed;
          __vbaGenerateBoundsError();
        }
        local_114 = (float ***)-*(int *)(DAT_0050b1a4 + 10);
        if (*(float *****)(DAT_0050b1a4 + 8) <= local_114) {
          pppppfStack_228 = (float *****)0x4ba20b;
          __vbaGenerateBoundsError();
        }
        iVar23 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)local_114 + local_118) * 2;
      }
      sVar19 = *(short *)(local_1c0 + *(int *)(DAT_0050b1a4 + 6));
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (SCARRY2(sVar19,1)) break;
      *(short *)(iVar23 + *(int *)(DAT_0050b1a4 + 6)) = sVar19 + 1;
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        pppppfStack_228 = (float *****)0x4ba2bb;
        iVar23 = __vbaGenerateBoundsError();
      }
      else {
        local_118 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_118) {
          pppppfStack_228 = (float *****)0x4ba27b;
          __vbaGenerateBoundsError();
        }
        local_114 = (float ***)-*(int *)(DAT_0050b1a4 + 10);
        if (*(float *****)(DAT_0050b1a4 + 8) <= local_114) {
          pppppfStack_228 = (float *****)0x4ba299;
          __vbaGenerateBoundsError();
        }
        iVar23 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)local_114 + local_118) * 2;
      }
      local_18 = (float *****)
                 CONCAT22(local_18._2_2_,*(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar23));
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        pppppfStack_228 = (float *****)0x4ba341;
        local_1c4 = __vbaGenerateBoundsError();
      }
      else {
        local_118 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_118) {
          pppppfStack_228 = (float *****)0x4ba2f3;
          __vbaGenerateBoundsError();
        }
        local_114 = (float ***)((int)(short)local_18 - *(int *)(DAT_0050b1a4 + 10));
        if (*(float *****)(DAT_0050b1a4 + 8) <= local_114) {
          pppppfStack_228 = (float *****)0x4ba317;
          __vbaGenerateBoundsError();
        }
        local_1c4 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)local_114 + local_118) * 2;
      }
      pppppfStack_228 = (float *****)0x0;
      pppppfStack_22c = (float *****)0xa;
      pppppfStack_234 = &local_70;
      pppppfStack_230 = local_124;
      pppppfStack_238 = (float *****)0x4ba35c;
      pppppfStack_228 = (float *****)__vbaLateIdCallLd();
      pppppfStack_22c = (float *****)0x4ba366;
      __vbaI4Var();
      pppppfStack_22c = (float *****)0x4ba36e;
      uVar8 = __vbaI2I4();
      *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + local_1c4) = uVar8;
      pppppfStack_22c = (float *****)0x4ba38a;
      __vbaFreeVar();
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        pppppfStack_22c = (float *****)0x4ba3fc;
        iVar23 = __vbaGenerateBoundsError();
      }
      else {
        local_118 = 2 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_118) {
          pppppfStack_22c = (float *****)0x4ba3b6;
          __vbaGenerateBoundsError();
        }
        local_114 = (float ***)((int)(short)local_18 - *(int *)(DAT_0050b1a4 + 10));
        if (*(float *****)(DAT_0050b1a4 + 8) <= local_114) {
          pppppfStack_22c = (float *****)0x4ba3d9;
          __vbaGenerateBoundsError();
        }
        iVar23 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)local_114 + local_118) * 2;
      }
      pppppfStack_22c = (float *****)0x0;
      pppppfStack_230 = (float *****)0xb;
      pppppfStack_238 = &local_70;
      pppppfStack_234 = local_124;
      pppppfStack_23c = (float *****)0x4ba417;
      pppppfStack_22c = (float *****)__vbaLateIdCallLd();
      pppppfStack_230 = (float *****)0x4ba421;
      __vbaI4Var();
      pppppfStack_230 = (float *****)0x4ba429;
      uVar8 = __vbaI2I4();
      *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar23) = uVar8;
      pppppfStack_230 = (float *****)0x4ba445;
      __vbaFreeVar();
    }
    if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
      pppppfStack_228 = (float *****)0x4ba489;
      iVar23 = __vbaGenerateBoundsError();
    }
    else {
      local_114 = (float ***)(iVar20 - *(int *)(DAT_0050b1f8 + 10));
      if (*(float *****)(DAT_0050b1f8 + 8) <= local_114) {
        pppppfStack_228 = (float *****)0x4ba473;
        __vbaGenerateBoundsError();
      }
      iVar23 = (int)local_114 * 2;
    }
    if (*(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar23) < 1) {
      pppppfStack_228 = (float *****)0x0;
      pppppfStack_22c = (float *****)0xa;
      pppppfStack_234 = &local_70;
      pppppfStack_230 = local_124;
      pppppfStack_238 = (float *****)0x4ba4b2;
      pppppfStack_228 = (float *****)__vbaLateIdCallLd();
      pppppfStack_22c = (float *****)0x4ba4bc;
      local_b8 = (float *****)__vbaI4Var();
      pppppfStack_22c = (float *****)0x0;
      pppppfStack_230 = (float *****)0xb;
      pppppfStack_238 = &local_80;
      pppppfStack_234 = local_124;
      local_c0 = (float *****)0x3;
      pppppfStack_23c = (float *****)0x4ba4e1;
      pppppfStack_22c = (float *****)__vbaLateIdCallLd();
      pppppfStack_230 = (float *****)0x4ba4eb;
      local_d8 = (float *****)__vbaI4Var();
      local_e0 = (float *****)0x3;
      if ((DAT_0050b0ec == (short *)0x0) || (*DAT_0050b0ec != 1)) {
        pppppfStack_230 = (float *****)0x4ba540;
        iVar23 = __vbaGenerateBoundsError();
      }
      else {
        local_114 = (float ***)(iVar20 - *(int *)(DAT_0050b0ec + 10));
        if (*(float *****)(DAT_0050b0ec + 8) <= local_114) {
          pppppfStack_230 = (float *****)0x4ba529;
          __vbaGenerateBoundsError();
        }
        iVar23 = (int)local_114 << 3;
      }
      pppppfStack_230 = *(float ******)(*(int *)(DAT_0050b0ec + 6) + 4 + iVar23);
      pppppfStack_234 = *(float ******)(*(int *)(DAT_0050b0ec + 6) + iVar23);
      pppppfStack_238 = (float *****)0x4ba558;
      pppppfStack_25c = (float *****)__vbaStrR8();
      local_90 = (float ****)0x8;
      pppppfStack_244 = local_c0;
      pppppfStack_240 = local_bc;
      pppppfStack_23c = local_b8;
      pppppfStack_238 = local_b4;
      pppppfStack_254 = local_e0;
      pppppfStack_250 = local_dc;
      pppppfStack_24c = local_d8;
      pppppfStack_248 = local_d4;
      pppppfStack_268 = (float *****)0x2;
      pppppfStack_26c = (float *****)0x41;
      pppppfStack_264 = (float *****)0x8;
      pppppfStack_260 = local_8c;
      pppppfStack_258 = local_84;
      pppppfStack_270 = local_124;
      pppppfStack_274 = (float *****)0x4ba5e4;
      local_88 = pppppfStack_25c;
      __vbaLateIdCallSt();
      pppppfStack_274 = &local_90;
      pppppfStack_278 = &local_80;
      pppppfStack_27c = &local_70;
      pppppfStack_280 = (float *****)0x3;
      pppppfStack_284 = (float *****)0x4ba5fb;
      __vbaFreeVarList();
    }
    sVar19 = (short)local_3c + 2;
    local_c0 = (float *****)0x3;
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SCARRY2((short)local_3c,2)) break;
    if (SCARRY2(sVar19,DAT_0050b298)) break;
    pppppfStack_22c = (float *****)(int)(short)(sVar19 + DAT_0050b298);
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_238 = (float *****)0xa;
    pppppfStack_230 = local_bc;
    pppppfStack_23c = local_124;
    pppppfStack_228 = local_b4;
    pppppfStack_240 = (float *****)0x4ba653;
    local_b8 = pppppfStack_22c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0xb;
    pppppfStack_250 = (float *****)0x4f;
    pppppfStack_24c = (float *****)0xb;
    local_b8 = (float *****)0x0;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)0x0;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4ba68d;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_268 = (float *****)0x27;
    pppppfStack_264 = (float *****)0x3;
    local_b8 = (float *****)0xffff00;
    pppppfStack_260 = local_bc;
    pppppfStack_26c = local_124;
    pppppfStack_25c = (float *****)0xffff00;
    pppppfStack_258 = local_b4;
    pppppfStack_270 = (float *****)0x4ba6ca;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x2;
    pppppfStack_280 = (float *****)0x28;
    pppppfStack_27c = (float *****)0x2;
    local_b8 = (float *****)0x1;
    pppppfStack_278 = local_bc;
    pppppfStack_284 = local_124;
    pppppfStack_274 = (float *****)&DAT_00000001;
    pppppfStack_270 = local_b4;
    pppppfStack_288 = (float *****)0x4ba707;
    (*(code *)unaff_ESI)();
    pppppfStack_288 = (float *****)0x4ba70c;
    FUN_0044fdc0();
    pppppfStack_288 = (float *****)0x4ba713;
    __vbaStrMove();
    pppppfStack_288 = (float *****)0x0;
    pppppfStack_28c = (float *****)0xa;
    pppppfStack_294 = &local_90;
    pppppfStack_290 = local_124;
    pppppfStack_298 = (float *****)0x4ba72b;
    pppppfStack_288 = (float *****)__vbaLateIdCallLd();
    pppppfStack_28c = (float *****)0x4ba735;
    local_c8 = (undefined4 *)__vbaI4Var();
    pppppfStack_28c = (float *****)0x0;
    pppppfStack_290 = (float *****)0xb;
    pppppfStack_298 = &local_a0;
    pppppfStack_294 = local_124;
    local_d0 = (float ****)0x3;
    pppppfStack_29c = (float *****)0x4ba75d;
    pppppfStack_28c = (float *****)__vbaLateIdCallLd();
    pppppfStack_290 = (float *****)0x4ba767;
    local_e8 = __vbaI4Var();
    local_68 = local_48;
    pppppfStack_294 = &local_44;
    pppppfStack_290 = (float *****)DAT_0050b0f0;
    local_f0 = (float *****)0x3;
    local_48 = (float *****)0x0;
    local_70 = (float ****)0x8;
    pppppfStack_298 = (float *****)0x4ba79b;
    __vbaAryLock();
    if (((float *****)local_44 == (float *****)0x0) || (*(short *)local_44 != 1)) {
      pppppfStack_298 = (float *****)0x4ba7da;
      iVar20 = __vbaGenerateBoundsError();
    }
    else {
      local_114 = (float ***)(iVar20 - (int)local_44[5]);
      if (local_44[4] <= local_114) {
        pppppfStack_298 = (float *****)0x4ba7c6;
        __vbaGenerateBoundsError();
      }
      iVar20 = (int)local_114 << 3;
    }
    pppppfStack_298 = (float *****)&DAT_00000001;
    local_b8 = (float *****)((int)local_44[3] + iVar20);
    pppppfStack_2a0 = &local_70;
    pppppfStack_29c = (float *****)&DAT_00000001;
    pppppfStack_2a4 = (float *****)&local_c0;
    pppppfStack_2a8 = &local_80;
    local_c0 = (float *****)0x4005;
    pppppfStack_2ac = (float *****)0x4ba80b;
    Ordinal_660();
    pppppfStack_2ac = &local_44;
    pppppfStack_2b0 = (float *****)0x4ba815;
    __vbaAryUnlock();
    pppppfStack_2b0 = &local_80;
    pppppfStack_2b4 = (float *****)0x4ba81f;
    pppppfStack_2d8 = (float *****)__vbaStrVarMove();
    local_b0 = (float ****)0x8;
    pppppfStack_2c0 = (float *****)local_d0;
    pppppfStack_2bc = (float *****)local_cc;
    pppppfStack_2b8 = (float *****)local_c8;
    pppppfStack_2b4 = (float *****)local_c4;
    pppppfStack_2d0 = local_f0;
    pppppfStack_2cc = (float *****)local_ec;
    pppppfStack_2c8 = (float *****)local_e8;
    ppppfStack_2c4 = local_e4;
    pppppfStack_2e4 = (float *****)0x2;
    piStack_2e8 = (int *)0x41;
    pppppfStack_2e0 = (float *****)0x8;
    pppppfStack_2dc = local_ac;
    pppppfStack_2ec = local_124;
    pppppfStack_2d4 = local_a4;
    pppppfStack_2f0 = (float *****)0x4ba8ae;
    local_a8 = pppppfStack_2d8;
    __vbaLateIdCallSt();
    pppppfStack_2b4 = (float *****)0x4ba8ba;
    __vbaFreeStr();
    pppppfStack_2b4 = &local_b0;
    pppppfStack_2b8 = &local_80;
    pppppfStack_2bc = &local_a0;
    pppppfStack_2c0 = &local_90;
    ppppfStack_2c4 = (float ****)&local_70;
    pppppfStack_2c8 = (float *****)0x5;
    pppppfStack_2cc = (float *****)0x4ba8df;
    __vbaFreeVarList();
    bVar28 = SCARRY2((short)local_24,1);
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    local_24 = (uint)(ushort)((short)local_24 + 1);
    puVar6 = local_c;
    if (bVar28) break;
LAB_004b9bed:
    if (sVar18 < (short)local_24) {
      sVar18 = DAT_0050b2c4 + -1;
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (!SBORROW2(DAT_0050b2c4,1)) {
        local_34 = 0;
        local_18 = (float *****)&DAT_00000001;
        psVar15 = DAT_0050b0c0;
        ppppppfVar10 = (float ******)local_18;
        goto LAB_004ba924;
      }
      break;
    }
  }
  goto LAB_004bc751;
LAB_004baa7d:
  pppppfStack_230 = (float *****)ppppppfVar22;
  pppppfStack_23c = (float *****)ppppppfVar26;
  local_178 = (short)ppppppfVar10;
  sVar18 = (short)ppppppfVar16;
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  local_18 = (float *****)ppppppfVar16;
  puVar6 = local_c;
  if (local_178 < sVar18) {
    local_24 = 3;
    sVar18 = DAT_0050b2c6 + 2;
    uVar27 = local_2c;
    uVar4 = local_24;
    uVar5 = local_24;
    if (!SCARRY2(DAT_0050b2c6,2)) goto LAB_004bb3c8;
    goto LAB_004bc751;
  }
  local_2c = 2;
  uVar27 = local_2c;
  uVar5 = local_24;
  if ((SBORROW2(sVar18,1)) ||
     (iVar20 = (short)(sVar18 + -1) * 3, sVar18 = (short)iVar20, sVar18 != iVar20))
  goto LAB_004bc751;
  uVar4 = CONCAT22((short)((uint)ppppppfVar9 >> 0x10),sVar18 + 1);
  uVar7 = local_2c;
  pppppfStack_23c = local_124;
  pppppfStack_230 = local_bc;
  while( true ) {
    local_2c = uVar7;
    local_24 = uVar4;
    local_124 = pppppfStack_23c;
    puVar6 = local_c;
    if (SCARRY2(sVar18,1)) goto LAB_004bc751;
    local_bc = pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    if (4 < (short)local_2c) break;
    if (SCARRY2((short)local_2c,(short)local_24)) goto LAB_004bc751;
    if (SCARRY2((short)local_2c + (short)local_24,DAT_0050b298)) goto LAB_004bc751;
    pppppfStack_22c = (float *****)(int)(short)((short)local_2c + (short)local_24 + DAT_0050b298);
    local_c0 = (float *****)0x3;
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_238 = (float *****)0xa;
    pppppfStack_240 = (float *****)0x4bab1d;
    local_b8 = pppppfStack_22c;
    (*(code *)unaff_ESI)();
    pppppfStack_240 = (float *****)0x0;
    pppppfStack_244 = (float *****)0xa;
    pppppfStack_24c = &local_70;
    pppppfStack_248 = local_124;
    pppppfStack_250 = (float *****)0x4bab32;
    pppppfStack_240 = (float *****)__vbaLateIdCallLd();
    pppppfStack_244 = (float *****)0x4bab3c;
    local_b8 = (float *****)__vbaI4Var();
    pppppfStack_244 = (float *****)&DAT_0040f1a0;
    pppppfStack_248 = local_18;
    local_c0 = (float *****)0x3;
    local_d8 = (float *****)0x0;
    local_e0 = (float *****)0x3;
    pppppfStack_24c = (float *****)0x4bab6c;
    __vbaStrI2();
    pppppfStack_24c = (float *****)0x4bab73;
    pppppfStack_24c = (float *****)__vbaStrMove();
    pppppfStack_250 = (float *****)0x4bab7a;
    Ordinal_519();
    pppppfStack_250 = (float *****)0x4bab81;
    pppppfStack_250 = (float *****)__vbaStrMove();
    pppppfStack_254 = (float *****)0x4bab88;
    pppppfStack_278 = (float *****)__vbaStrCat();
    local_80 = (float ****)0x8;
    pppppfStack_260 = local_c0;
    pppppfStack_25c = local_bc;
    pppppfStack_258 = local_b8;
    pppppfStack_254 = local_b4;
    pppppfStack_270 = local_e0;
    pppppfStack_26c = local_dc;
    pppppfStack_268 = local_d8;
    pppppfStack_264 = local_d4;
    pppppfStack_280 = (float *****)0x8;
    pppppfStack_27c = local_7c;
    pppppfStack_274 = local_74;
    pppppfStack_284 = (float *****)0x2;
    pppppfStack_288 = (float *****)0x41;
    pppppfStack_28c = local_124;
    pppppfStack_290 = (float *****)0x4bac08;
    local_78 = pppppfStack_278;
    __vbaLateIdCallSt();
    pppppfStack_290 = (float *****)&local_4c;
    pppppfStack_294 = (float *****)&local_48;
    pppppfStack_298 = (float *****)0x2;
    pppppfStack_29c = (float *****)0x4bac18;
    __vbaFreeStrList();
    pppppfStack_254 = &local_80;
    pppppfStack_258 = &local_70;
    pppppfStack_25c = (float *****)0x2;
    pppppfStack_260 = (float *****)0x4bac2b;
    __vbaFreeVarList();
    pppppfStack_260 = (float *****)0x0;
    pppppfStack_264 = (float *****)0xa;
    pppppfStack_26c = &local_70;
    pppppfStack_268 = local_124;
    pppppfStack_270 = (float *****)0x4bac40;
    pppppfStack_254 = (float *****)__vbaLateIdCallLd();
    pppppfStack_258 = (float *****)0x4bac4a;
    local_b8 = (float *****)__vbaI4Var();
    pppppfStack_258 = (float *****)DAT_0050b18c;
    local_c0 = (float *****)0x3;
    local_e0 = (float *****)0x3;
    pppppfStack_25c = &local_44;
    local_d8 = (float *****)&DAT_00000001;
    pppppfStack_260 = (float *****)0x4bac7c;
    __vbaAryLock();
    if (((float *****)local_44 == (float *****)0x0) || (*(short *)local_44 != 1)) {
      pppppfStack_260 = (float *****)0x4bacb9;
      iVar20 = __vbaGenerateBoundsError();
    }
    else {
      local_114 = (float ***)((int)(short)local_18 - (int)local_44[5]);
      if (local_44[4] <= local_114) {
        pppppfStack_260 = (float *****)0x4baca5;
        __vbaGenerateBoundsError();
      }
      iVar20 = (int)local_114 << 2;
    }
    pppppfStack_284 = (float *****)((int)local_44[3] + iVar20);
    pppppfStack_26c = local_c0;
    pppppfStack_268 = local_bc;
    pppppfStack_264 = local_b8;
    pppppfStack_260 = local_b4;
    pppppfStack_27c = local_e0;
    pppppfStack_278 = local_dc;
    pppppfStack_274 = local_d8;
    pppppfStack_270 = local_d4;
    pppppfStack_290 = (float *****)0x2;
    pppppfStack_28c = (float *****)0x4008;
    pppppfStack_294 = (float *****)0x41;
    pppppfStack_288 = local_fc;
    pppppfStack_280 = local_f4;
    pppppfStack_298 = local_124;
    pppppfStack_29c = (float *****)0x4bad3f;
    __vbaLateIdCallSt();
    pppppfStack_260 = &local_44;
    pppppfStack_264 = (float *****)0x4bad4c;
    __vbaAryUnlock();
    pppppfStack_264 = (float *****)0x4bad55;
    __vbaFreeVar();
    if ((short)local_18 == DAT_0050b2ca) {
      local_c0 = (float *****)0x3;
      pppppfStack_274 = (float *****)0xb;
      pppppfStack_270 = (float *****)0x3;
      local_b8 = (float *****)0x2;
      pppppfStack_26c = local_bc;
      pppppfStack_278 = local_124;
      pppppfStack_268 = (float *****)0x2;
      pppppfStack_264 = local_b4;
      pppppfStack_27c = (float *****)0x4bad9f;
      (*(code *)unaff_ESI)();
      local_c0 = (float *****)0x3;
      pppppfStack_28c = (float *****)0x27;
      pppppfStack_288 = (float *****)0x3;
      local_b8 = (float *****)0xff;
      pppppfStack_284 = local_bc;
      pppppfStack_290 = local_124;
      pppppfStack_280 = (float *****)0xff;
      pppppfStack_27c = local_b4;
      pppppfStack_294 = (float *****)0x4baddc;
      (*(code *)unaff_ESI)();
    }
    pppppfStack_264 = (float *****)0x4bade1;
    FUN_0044fdc0();
    pppppfStack_264 = (float *****)0x4bade8;
    __vbaStrMove();
    pppppfStack_264 = (float *****)0x0;
    pppppfStack_268 = (float *****)0xa;
    pppppfStack_270 = &local_90;
    pppppfStack_26c = local_124;
    pppppfStack_274 = (float *****)0x4bae00;
    pppppfStack_264 = (float *****)__vbaLateIdCallLd();
    pppppfStack_268 = (float *****)0x4bae0a;
    local_c8 = (undefined4 *)__vbaI4Var();
    local_68 = local_60;
    pppppfStack_26c = &local_44;
    local_d0 = (float ****)0x3;
    local_f0 = (float *****)0x3;
    pppppfStack_268 = (float *****)DAT_0050b0dc;
    local_e8 = 2;
    local_60 = (float *****)0x0;
    local_70 = (float ****)0x8;
    pppppfStack_270 = (float *****)0x4bae50;
    __vbaAryLock();
    if (((float *****)local_44 == (float *****)0x0) || (*(short *)local_44 != 1)) {
      pppppfStack_270 = (float *****)0x4bae8d;
      iVar20 = __vbaGenerateBoundsError();
    }
    else {
      local_114 = (float ***)((int)(short)local_18 - (int)local_44[5]);
      if (local_44[4] <= local_114) {
        pppppfStack_270 = (float *****)0x4bae79;
        __vbaGenerateBoundsError();
      }
      iVar20 = (int)local_114 << 3;
    }
    pppppfStack_270 = (float *****)&DAT_00000001;
    local_b8 = (float *****)((int)local_44[3] + iVar20);
    pppppfStack_278 = &local_70;
    pppppfStack_274 = (float *****)&DAT_00000001;
    pppppfStack_27c = (float *****)&local_c0;
    pppppfStack_280 = &local_80;
    local_c0 = (float *****)0x4005;
    pppppfStack_284 = (float *****)0x4baebe;
    Ordinal_660();
    pppppfStack_284 = &local_44;
    pppppfStack_288 = (float *****)0x4baec8;
    __vbaAryUnlock();
    pppppfStack_288 = (float *****)&DAT_0040dea8;
    pppppfStack_28c = local_18;
    pppppfStack_290 = (float *****)0x4baed7;
    __vbaStrI2();
    pppppfStack_290 = (float *****)0x4baede;
    pppppfStack_290 = (float *****)__vbaStrMove();
    pppppfStack_294 = (float *****)0x4baee5;
    Ordinal_519();
    pppppfStack_294 = (float *****)0x4baeec;
    pppppfStack_294 = (float *****)__vbaStrMove();
    pppppfStack_298 = (float *****)0x4baef3;
    __vbaStrCat();
    pppppfStack_298 = (float *****)0x4baefa;
    pppppfStack_298 = (float *****)__vbaStrMove();
    pppppfStack_29c = (float *****)&DAT_0040cb48;
    pppppfStack_2a0 = (float *****)0x4baf06;
    __vbaStrCat();
    pppppfStack_2a0 = (float *****)0x4baf0d;
    pppppfStack_2a0 = (float *****)__vbaStrMove();
    pppppfStack_2a4 = &local_80;
    pppppfStack_2a8 = &local_54;
    pppppfStack_2ac = (float *****)0x4baf1c;
    pppppfStack_2ac = (float *****)__vbaStrVarVal();
    pppppfStack_2b0 = (float *****)0x4baf23;
    Ordinal_519();
    pppppfStack_2b0 = (float *****)0x4baf2a;
    pppppfStack_2b0 = (float *****)__vbaStrMove();
    pppppfStack_2b4 = (float *****)0x4baf31;
    pppppfStack_2d8 = (float *****)__vbaStrCat();
    local_a0 = (float ****)0x8;
    pppppfStack_2c0 = (float *****)local_d0;
    pppppfStack_2bc = (float *****)local_cc;
    pppppfStack_2b8 = (float *****)local_c8;
    pppppfStack_2b4 = (float *****)local_c4;
    pppppfStack_2d0 = local_f0;
    pppppfStack_2cc = (float *****)local_ec;
    pppppfStack_2c8 = (float *****)local_e8;
    ppppfStack_2c4 = local_e4;
    pppppfStack_2e0 = (float *****)0x8;
    pppppfStack_2dc = local_9c;
    pppppfStack_2e4 = (float *****)0x2;
    pppppfStack_2d4 = (float *****)local_94;
    piStack_2e8 = (int *)0x41;
    pppppfStack_2ec = local_124;
    pppppfStack_2f0 = (float *****)0x4bafc0;
    local_98 = pppppfStack_2d8;
    __vbaLateIdCallSt();
    pppppfStack_2f0 = (float *****)&local_60;
    ppppfStack_2f4 = (float ****)&local_5c;
    pppppfStack_2f8 = (float *****)&local_58;
    pppppfStack_2fc = &local_54;
    pppppfStack_300 = &local_50;
    pppppfStack_304 = (float *****)&local_4c;
    pppppfStack_308 = (float *****)&local_48;
    pppppfStack_30c = (float *****)0x7;
    pppppfStack_310 = (float *****)0x4bafe4;
    __vbaFreeStrList();
    pppppfStack_2b4 = &local_a0;
    pppppfStack_2b8 = &local_90;
    pppppfStack_2bc = &local_80;
    pppppfStack_2c0 = &local_70;
    ppppfStack_2c4 = (float ****)0x4;
    pppppfStack_2c8 = (float *****)0x4bb005;
    __vbaFreeVarList();
    pppppfStack_2c8 = (float *****)0x0;
    pppppfStack_2cc = (float *****)0x5;
    pppppfStack_2d4 = &local_70;
    pppppfStack_2d0 = local_124;
    pppppfStack_2d8 = (float *****)0x4bb01a;
    pppppfStack_2b4 = (float *****)__vbaLateIdCallLd();
    pppppfStack_2b8 = (float *****)0x4bb024;
    iVar20 = __vbaI4Var();
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SBORROW4(iVar20,1)) goto LAB_004bc751;
    local_c0 = (float *****)0x3;
    pppppfStack_238 = (float *****)0xb;
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_230 = local_bc;
    pppppfStack_23c = local_124;
    pppppfStack_228 = local_b4;
    pppppfStack_240 = (float *****)0x4bb065;
    pppppfStack_22c = (float *****)(iVar20 + -1);
    local_b8 = (float *****)(iVar20 + -1);
    (*(code *)unaff_ESI)();
    pppppfStack_240 = (float *****)0x4bb06e;
    __vbaFreeVar();
    local_c0 = (float *****)0x4;
    pppppfStack_250 = (float *****)0x4e;
    pppppfStack_24c = (float *****)0x4;
    local_b8 = (float *****)0x41600000;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)0x41600000;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4bb0ab;
    (*(code *)unaff_ESI)();
    local_b8 = (float *****)0xffffffff;
    local_c0 = (float *****)0xb;
    pppppfStack_268 = (float *****)0x4f;
    pppppfStack_264 = (float *****)0xb;
    pppppfStack_260 = local_bc;
    pppppfStack_26c = local_124;
    pppppfStack_25c = (float *****)0xffffffff;
    pppppfStack_258 = local_b4;
    pppppfStack_270 = (float *****)0x4bb0e6;
    (*(code *)unaff_ESI)();
    if ((short)local_34 == 0) {
      pppppfStack_228 = (float *****)0x0;
      pppppfStack_22c = (float *****)0xa;
      pppppfStack_234 = &local_70;
      pppppfStack_230 = local_124;
      pppppfStack_238 = (float *****)0x4bb1fb;
      pppppfStack_228 = (float *****)__vbaLateIdCallLd();
      pppppfStack_22c = (float *****)0x4bb205;
      local_b8 = (float *****)__vbaI4Var();
      pppppfStack_22c = (float *****)0x0;
      pppppfStack_230 = (float *****)0x5;
      pppppfStack_238 = &local_80;
      pppppfStack_234 = local_124;
      local_c0 = (float *****)0x3;
      pppppfStack_23c = (float *****)0x4bb22a;
      pppppfStack_22c = (float *****)__vbaLateIdCallLd();
      pppppfStack_230 = (float *****)0x4bb234;
      iVar20 = __vbaI4Var();
      ppppppfVar9 = (float ******)(iVar20 + -1);
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (SBORROW4(iVar20,1)) goto LAB_004bc751;
      local_e0 = (float *****)0x3;
      local_d8 = (float *****)ppppppfVar9;
      if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
LAB_004bb2b8:
        local_e0 = (float *****)0x3;
        pppppfStack_228 = (float *****)0x4bb2be;
        iVar20 = __vbaGenerateBoundsError();
      }
      else {
        local_118 = (int)(short)local_18 - *(int *)(DAT_0050b0c0 + 0xe);
        if (*(uint *)(DAT_0050b0c0 + 0xc) <= local_118) {
          pppppfStack_228 = (float *****)0x4bb279;
          __vbaGenerateBoundsError();
        }
        local_114 = (float ***)-*(int *)(DAT_0050b0c0 + 10);
        if (*(float *****)(DAT_0050b0c0 + 8) <= local_114) {
          pppppfStack_228 = (float *****)0x4bb29b;
          __vbaGenerateBoundsError();
        }
LAB_004bb2a7:
        iVar20 = (*(int *)(DAT_0050b0c0 + 0xc) * (int)local_114 + local_118) * 8;
      }
LAB_004bb2c4:
      pppppfStack_228 = *(float ******)(*(int *)(DAT_0050b0c0 + 6) + 4 + iVar20);
      pppppfStack_22c = *(float ******)(*(int *)(DAT_0050b0c0 + 6) + iVar20);
      pppppfStack_230 = (float *****)0x4bb2d6;
      pppppfStack_254 = (float *****)__vbaStrR8();
      local_90 = (float ****)0x8;
      pppppfStack_23c = local_c0;
      pppppfStack_238 = local_bc;
      pppppfStack_234 = local_b8;
      pppppfStack_230 = local_b4;
      pppppfStack_24c = local_e0;
      pppppfStack_248 = local_dc;
      pppppfStack_244 = local_d8;
      pppppfStack_240 = local_d4;
      pppppfStack_260 = (float *****)0x2;
      pppppfStack_264 = (float *****)0x41;
      pppppfStack_25c = (float *****)0x8;
      pppppfStack_258 = local_8c;
      pppppfStack_250 = local_84;
      pppppfStack_268 = local_124;
      pppppfStack_26c = (float *****)0x4bb362;
      local_88 = pppppfStack_254;
      __vbaLateIdCallSt();
      pppppfStack_26c = &local_90;
      pppppfStack_270 = &local_80;
      pppppfStack_274 = &local_70;
      pppppfStack_278 = (float *****)0x3;
      pppppfStack_27c = (float *****)0x4bb379;
      __vbaFreeVarList();
    }
    else if (((short)local_34 == 1) && ((short)local_2c == 3)) {
      pppppfStack_228 = (float *****)0x0;
      pppppfStack_22c = (float *****)0xa;
      pppppfStack_234 = &local_70;
      pppppfStack_230 = local_124;
      pppppfStack_238 = (float *****)0x4bb11a;
      pppppfStack_228 = (float *****)__vbaLateIdCallLd();
      pppppfStack_22c = (float *****)0x4bb124;
      local_b8 = (float *****)__vbaI4Var();
      pppppfStack_22c = (float *****)0x0;
      pppppfStack_230 = (float *****)0x5;
      pppppfStack_238 = &local_80;
      pppppfStack_234 = local_124;
      local_c0 = (float *****)0x3;
      pppppfStack_23c = (float *****)0x4bb149;
      pppppfStack_22c = (float *****)__vbaLateIdCallLd();
      pppppfStack_230 = (float *****)0x4bb153;
      iVar20 = __vbaI4Var();
      ppppppfVar9 = (float ******)(iVar20 + -1);
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (!SBORROW4(iVar20,1)) {
        local_e0 = (float *****)0x3;
        local_d8 = (float *****)ppppppfVar9;
        if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) goto LAB_004bb2b8;
        local_118 = (int)(short)local_18 - *(int *)(DAT_0050b0c0 + 0xe);
        if (*(uint *)(DAT_0050b0c0 + 0xc) <= local_118) {
          pppppfStack_228 = (float *****)0x4bb1a0;
          __vbaGenerateBoundsError();
        }
        local_114 = (float ***)-*(int *)(DAT_0050b0c0 + 10);
        if (local_114 < *(float *****)(DAT_0050b0c0 + 8)) goto LAB_004bb2a7;
        pppppfStack_228 = (float *****)0x4bb1c6;
        __vbaGenerateBoundsError();
        iVar20 = (*(int *)(DAT_0050b0c0 + 0xc) * (int)local_114 + local_118) * 8;
        goto LAB_004bb2c4;
      }
      goto LAB_004bc751;
    }
    uVar4 = local_24;
    uVar7 = (uint)(ushort)((short)local_2c + 1);
    uVar27 = local_2c;
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    pppppfStack_23c = local_124;
    pppppfStack_230 = local_bc;
    uVar5 = local_24;
    sVar18 = (short)local_2c;
  }
  ppppppfVar9 = (float ******)(uint)(ushort)((short)local_18 + 1);
  ppppppfVar16 = ppppppfVar9;
  if (SCARRY2((short)local_18,1)) goto LAB_004bc751;
  goto LAB_004baa7d;
LAB_004bb3c8:
  local_24 = uVar4;
  if (sVar18 < (short)local_24) {
    pppppfStack_22c = (float *****)(int)DAT_0050b298;
    local_c0 = (float *****)0x3;
    pppppfStack_238 = (float *****)0xa;
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_230 = local_bc;
    pppppfStack_23c = local_124;
    pppppfStack_228 = local_b4;
    pppppfStack_240 = (float *****)0x4bbbfd;
    local_b8 = pppppfStack_22c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_250 = (float *****)0xb;
    pppppfStack_24c = (float *****)0x3;
    local_b8 = (float *****)0x2;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)0x2;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4bbc3a;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0xb;
    pppppfStack_268 = (float *****)0x4f;
    pppppfStack_264 = (float *****)0xb;
    local_b8 = (float *****)0xffffffff;
    pppppfStack_260 = local_bc;
    pppppfStack_26c = local_124;
    pppppfStack_25c = (float *****)0xffffffff;
    pppppfStack_258 = local_b4;
    pppppfStack_270 = (float *****)0x4bbc75;
    (*(code *)unaff_ESI)();
    pppppfStack_274 = (float *****)(int)DAT_0050b298;
    local_c0 = (float *****)0x3;
    local_e0 = (float *****)0x3;
    pppppfStack_27c = (float *****)0x3;
    local_d8 = (float *****)0x1;
    pppppfStack_278 = local_bc;
    pppppfStack_270 = local_b4;
    pppppfStack_28c = (float *****)0x3;
    pppppfStack_288 = local_dc;
    pppppfStack_284 = (float *****)0x1;
    pppppfStack_280 = local_d4;
    pppppfStack_29c = (float *****)0x8;
    pppppfStack_298 = local_fc;
    pppppfStack_294 = (float *****)0x412a8c;
    pppppfStack_290 = local_f4;
    pppppfStack_2a0 = (float *****)0x2;
    pppppfStack_2a4 = (float *****)0x41;
    pppppfStack_2a8 = local_124;
    pppppfStack_2ac = (float *****)0x4bbd14;
    local_b8 = pppppfStack_274;
    __vbaLateIdCallSt();
    pppppfStack_270 = (float *****)0x4bbd1c;
    FUN_0044fdc0();
    pppppfStack_270 = (float *****)0x4bbd23;
    __vbaStrMove();
    local_c8 = (undefined4 *)(int)DAT_0050b298;
    pppppfStack_270 = (float *****)&DAT_00000001;
    local_d0 = (float ****)0x3;
    local_f0 = (float *****)0x3;
    local_68 = local_4c;
    pppppfStack_278 = &local_70;
    pppppfStack_274 = (float *****)&DAT_00000001;
    pppppfStack_27c = (float *****)&local_c0;
    pppppfStack_280 = &local_80;
    local_e8 = 2;
    local_4c = (float *****)0x0;
    local_70 = (float ****)0x8;
    local_b8 = (float *****)&DAT_0050b14c;
    local_c0 = (float *****)0x4005;
    pppppfStack_284 = (float *****)0x4bbd8c;
    Ordinal_660();
    pppppfStack_284 = &local_80;
    pppppfStack_288 = (float *****)&local_48;
    pppppfStack_28c = (float *****)0x4bbd9a;
    pppppfStack_28c = (float *****)__vbaStrVarVal();
    pppppfStack_290 = (float *****)0x4bbda1;
    pppppfStack_2b4 = (float *****)Ordinal_519();
    pppppfStack_29c = (float *****)local_d0;
    local_90 = (float ****)0x8;
    pppppfStack_298 = (float *****)local_cc;
    pppppfStack_294 = (float *****)local_c8;
    pppppfStack_290 = (float *****)local_c4;
    pppppfStack_2ac = local_f0;
    pppppfStack_2a8 = (float *****)local_ec;
    pppppfStack_2a4 = (float *****)local_e8;
    pppppfStack_2a0 = (float *****)local_e4;
    pppppfStack_2c0 = (float *****)0x2;
    ppppfStack_2c4 = (float ****)0x41;
    pppppfStack_2bc = (float *****)0x8;
    pppppfStack_2b8 = local_8c;
    pppppfStack_2c8 = local_124;
    pppppfStack_2b0 = local_84;
    pppppfStack_2cc = (float *****)0x4bbe28;
    local_88 = pppppfStack_2b4;
    __vbaLateIdCallSt();
    pppppfStack_2cc = (float *****)&local_4c;
    pppppfStack_2d0 = (float *****)&local_48;
    pppppfStack_2d4 = (float *****)0x2;
    pppppfStack_2d8 = (float *****)0x4bbe38;
    __vbaFreeStrList();
    pppppfStack_290 = &local_90;
    pppppfStack_294 = &local_80;
    pppppfStack_298 = &local_70;
    pppppfStack_29c = (float *****)0x3;
    pppppfStack_2a0 = (float *****)0x4bbe52;
    __vbaFreeVarList();
    local_b8 = (float *****)0x3;
    local_c0 = (float *****)0x3;
    pppppfStack_29c = (float *****)0x3;
    pppppfStack_2a0 = (float *****)0x30;
    pppppfStack_298 = local_bc;
    pppppfStack_2a4 = local_124;
    pppppfStack_294 = (float *****)0x3;
    pppppfStack_290 = local_b4;
    pppppfStack_2a8 = (float *****)0x4bbe89;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_2b4 = (float *****)0x3;
    local_b8 = (float *****)0x0;
    local_e0 = (float *****)0xb;
    pppppfStack_2b0 = local_bc;
    pppppfStack_2c8 = (float *****)0x1;
    pppppfStack_2ac = (float *****)0x0;
    local_d8 = (float *****)0xffffffff;
    pppppfStack_2cc = (float *****)0x3c;
    pppppfStack_2a8 = local_b4;
    ppppfStack_2c4 = (float ****)0xb;
    pppppfStack_2c0 = local_dc;
    pppppfStack_2d0 = local_124;
    pppppfStack_2bc = (float *****)0xffffffff;
    pppppfStack_2b8 = local_d4;
    pppppfStack_2d4 = (float *****)0x4bbefa;
    __vbaLateIdCallSt();
    local_c0 = (float *****)0x3;
    pppppfStack_2b4 = (float *****)0x3;
    local_b8 = (float *****)0x1;
    pppppfStack_2b0 = local_bc;
    local_e0 = (float *****)0xb;
    local_d8 = (float *****)0xffffffff;
    pppppfStack_2ac = (float *****)0x1;
    pppppfStack_2c8 = (float *****)0x1;
    pppppfStack_2cc = (float *****)0x3c;
    pppppfStack_2a8 = local_b4;
    ppppfStack_2c4 = (float ****)0xb;
    pppppfStack_2c0 = local_dc;
    pppppfStack_2d0 = local_124;
    pppppfStack_2bc = (float *****)0xffffffff;
    pppppfStack_2b8 = local_d4;
    pppppfStack_2d4 = (float *****)0x4bbf6e;
    __vbaLateIdCallSt();
    ppppppfVar24 = &pppppfStack_2b4;
    local_c0 = (float *****)0x3;
    pppppfStack_2b4 = (float *****)0x3;
    local_b8 = (float *****)0x2;
    local_e0 = (float *****)0xb;
    pppppfStack_2b0 = local_bc;
    pppppfStack_2c8 = (float *****)&DAT_00000001;
    pppppfStack_2ac = (float *****)0x2;
    local_d8 = (float *****)0xffffffff;
    pppppfStack_2cc = (float *****)0x3c;
    pppppfStack_2a8 = local_b4;
    ppppfStack_2c4 = (float ****)0xb;
    pppppfStack_2c0 = local_dc;
    pppppfStack_2d0 = local_124;
    pppppfStack_2bc = (float *****)0xffffffff;
    pppppfStack_2b8 = local_d4;
    pppppfStack_2d4 = (float *****)0x4bbfe2;
    __vbaLateIdCallSt();
    pppppfStack_2d4 = (float *****)0x0;
    pppppfStack_2d8 = (float *****)0x5;
    pppppfStack_2e0 = &local_70;
    pppppfStack_2dc = local_124;
    pppppfStack_2e4 = (float *****)0x4bbff7;
    pppppfStack_2a8 = (float *****)__vbaLateIdCallLd();
    pppppfStack_2ac = (float *****)0x4bc001;
    iVar20 = __vbaI4Var();
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (!SBORROW4(iVar20,1)) {
      local_c0 = (float *****)0x3;
      local_e0 = (float *****)0xb;
      pppppfStack_234 = (float *****)0x3;
      pppppfStack_230 = local_bc;
      local_d8 = (float *****)0xffffffff;
      pppppfStack_248 = (float *****)&DAT_00000001;
      pppppfStack_24c = (float *****)0x3c;
      pppppfStack_228 = local_b4;
      pppppfStack_244 = (float *****)0xb;
      pppppfStack_240 = local_dc;
      pppppfStack_250 = local_124;
      pppppfStack_23c = (float *****)0xffffffff;
      pppppfStack_238 = local_d4;
      pppppfStack_254 = (float *****)0x4bc079;
      pppppfStack_22c = (float *****)(iVar20 + -1);
      local_b8 = (float *****)(iVar20 + -1);
      __vbaLateIdCallSt();
      pppppfStack_228 = (float *****)0x4bc085;
      __vbaFreeVar();
      if (DAT_0050b25e != 0) {
        if (DAT_0050b000 != 0) {
          pppppfStack_1e4 = (float *****)((ulonglong)(double)(int)DAT_0050b2c6 >> 0x20);
          pppppfStack_228 = pppppfStack_1e4;
          pppppfStack_230 = (float *****)0x4bc0f0;
          adj_fdiv_m64();
        }
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
        pppppfStack_228 = (float *****)0x4bc100;
        __vbaFPInt();
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
        pppppfStack_228 = (float *****)0x4bc13d;
        local_30 = __vbaFpI2();
        local_1c = CONCAT22(extraout_var_03,DAT_0050b25e % DAT_0050b2c6);
        local_c8 = &local_1c;
        local_e0 = (float *****)0x4002;
        local_d0 = (float ****)0x4002;
        pppppfStack_228 = (float *****)&local_e0;
        local_d8 = (float *****)&DAT_0050b2c6;
        pppppfStack_234 = &local_70;
        local_c0 = (float *****)0xb;
        local_b8 = (float *****)CONCAT22(local_b8._2_2_,-(ushort)(0 < DAT_0050b25e % DAT_0050b2c6));
        pppppfStack_22c = &local_d0;
        pppppfStack_230 = (float *****)&local_c0;
        pppppfStack_238 = (float *****)0x4bc1b0;
        Ordinal_681();
        pppppfStack_238 = &local_70;
        local_e8 = 2;
        local_f0 = (float *****)0x2;
        pppppfStack_23c = (float *****)&local_f0;
        pppppfStack_240 = &local_80;
        pppppfStack_244 = (float *****)0x4bc1d6;
        pppppfStack_244 = (float *****)__vbaVarAdd();
        pppppfStack_248 = (float *****)0x4bc1df;
        local_1c = __vbaI2Var();
        pppppfStack_248 = &local_80;
        pppppfStack_24c = &local_70;
        pppppfStack_250 = (float *****)&local_c0;
        pppppfStack_254 = (float *****)0x3;
        pppppfStack_258 = (float *****)0x4bc1f9;
        __vbaFreeVarList();
        if (DAT_0050b000 != 0) {
          pppppfStack_228 = (float *****)0x4bc25c;
          adj_fdiv_m64();
        }
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004bc74c;
        pppppfStack_228 = (float *****)0x4bc26c;
        __vbaFPInt();
        if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004bc74c:
          __vbaFPException();
          return;
        }
        pppppfStack_228 = (float *****)0x4bc2a3;
        local_38 = __vbaFpI2();
        local_28 = CONCAT22(extraout_var_04,(short)DAT_0050b260 % DAT_0050b2c6);
        local_c8 = &local_28;
        local_e0 = (float *****)0x4002;
        local_d0 = (float ****)0x4002;
        pppppfStack_228 = (float *****)&local_e0;
        local_d8 = (float *****)&DAT_0050b2c6;
        pppppfStack_234 = &local_70;
        local_c0 = (float *****)0xb;
        local_b8 = (float *****)
                   CONCAT22(local_b8._2_2_,-(ushort)(0 < (short)DAT_0050b260 % DAT_0050b2c6));
        pppppfStack_22c = &local_d0;
        pppppfStack_230 = (float *****)&local_c0;
        pppppfStack_238 = (float *****)0x4bc316;
        Ordinal_681();
        pppppfStack_238 = &local_70;
        local_e8 = 2;
        local_f0 = (float *****)0x2;
        pppppfStack_23c = (float *****)&local_f0;
        pppppfStack_240 = &local_80;
        pppppfStack_244 = (float *****)0x4bc33c;
        pppppfStack_244 = (float *****)__vbaVarAdd();
        pppppfStack_248 = (float *****)0x4bc33f;
        local_28 = __vbaI2Var();
        pppppfStack_248 = &local_80;
        pppppfStack_24c = &local_70;
        pppppfStack_250 = (float *****)&local_c0;
        pppppfStack_254 = (float *****)0x3;
        pppppfStack_258 = (float *****)0x4bc359;
        __vbaFreeVarList();
        pppppfStack_24c = (float *****)(int)(short)local_30;
        local_c0 = (float *****)0x3;
        pppppfStack_254 = (float *****)0x3;
        pppppfStack_250 = local_bc;
        pppppfStack_248 = local_b4;
        pppppfStack_258 = (float *****)0xa;
        pppppfStack_25c = local_124;
        pppppfStack_260 = (float *****)0x4bc392;
        local_b8 = pppppfStack_24c;
        (*(code *)unaff_ESI)();
        pppppfStack_264 = (float *****)(int)(short)local_1c;
        local_c0 = (float *****)0x3;
        pppppfStack_270 = (float *****)0xb;
        pppppfStack_26c = (float *****)0x3;
        pppppfStack_268 = local_bc;
        pppppfStack_274 = local_124;
        pppppfStack_260 = local_b4;
        pppppfStack_278 = (float *****)0x4bc3ce;
        local_b8 = pppppfStack_264;
        (*(code *)unaff_ESI)();
        local_c0 = (float *****)0x8;
        pppppfStack_288 = (float *****)0x0;
        pppppfStack_284 = (float *****)0x8;
        local_b8 = (float *****)&DAT_0040ca6c;
        pppppfStack_280 = local_bc;
        pppppfStack_28c = local_124;
        pppppfStack_27c = (float *****)&DAT_0040ca6c;
        pppppfStack_278 = local_b4;
        pppppfStack_290 = (float *****)0x4bc40b;
        (*(code *)unaff_ESI)();
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          pppppfStack_290 = (float *****)0x4bc467;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar20) {
            pppppfStack_290 = (float *****)0x4bc432;
            __vbaGenerateBoundsError();
          }
          iVar23 = *(int *)(DAT_0050b1a4 + 10);
          if (*(uint *)(DAT_0050b1a4 + 8) <= 1U - iVar23) {
            pppppfStack_290 = (float *****)0x4bc44f;
            __vbaGenerateBoundsError();
          }
          iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (1U - iVar23) + (1U - iVar20)) * 2;
        }
        *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20) = (short)local_30;
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          pppppfStack_290 = (float *****)0x4bc4d4;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 2U - iVar20) {
            pppppfStack_290 = (float *****)0x4bc49f;
            __vbaGenerateBoundsError();
          }
          iVar23 = *(int *)(DAT_0050b1a4 + 10);
          if (*(uint *)(DAT_0050b1a4 + 8) <= 1U - iVar23) {
            pppppfStack_290 = (float *****)0x4bc4bc;
            __vbaGenerateBoundsError();
          }
          iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (1U - iVar23) + (2U - iVar20)) * 2;
        }
        *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20) = (short)local_1c;
        pppppfStack_2a0 = (float *****)0xa;
        local_c0 = (float *****)0x3;
        pppppfStack_29c = (float *****)0x3;
        sVar18 = (short)local_38;
        pppppfStack_294 = (float *****)(int)sVar18;
        pppppfStack_298 = local_bc;
        pppppfStack_2a4 = local_124;
        pppppfStack_290 = local_b4;
        pppppfStack_2a8 = (float *****)0x4bc523;
        local_b8 = pppppfStack_294;
        (*(code *)unaff_ESI)();
        pppppfStack_2ac = (float *****)(int)(short)local_28;
        local_c0 = (float *****)0x3;
        pppppfStack_2b8 = (float *****)0xb;
        pppppfStack_2b4 = (float *****)0x3;
        pppppfStack_2b0 = local_bc;
        pppppfStack_2bc = local_124;
        pppppfStack_2a8 = local_b4;
        pppppfStack_2c0 = (float *****)0x4bc55f;
        local_b8 = pppppfStack_2ac;
        (*(code *)unaff_ESI)();
        if ((DAT_0050b0ec == (short *)0x0) || (*DAT_0050b0ec != 1)) {
          pppppfStack_2c0 = (float *****)0x4bc59d;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          iVar23 = (int)(short)DAT_0050b260;
          iVar20 = *(int *)(DAT_0050b0ec + 10);
          if (*(uint *)(DAT_0050b0ec + 8) <= (uint)(iVar23 - iVar20)) {
            pppppfStack_2c0 = (float *****)0x4bc588;
            __vbaGenerateBoundsError();
          }
          iVar20 = (iVar23 - iVar20) * 8;
        }
        pppppfStack_2c0 = *(float ******)(*(int *)(DAT_0050b0ec + 6) + 4 + iVar20);
        ppppfStack_2c4 = *(float *****)(*(int *)(DAT_0050b0ec + 6) + iVar20);
        pppppfStack_2c8 = (float *****)0x4bc5b5;
        pppppfStack_2cc = (float *****)__vbaStrR8();
        local_70 = (float ****)0x8;
        pppppfStack_2d8 = (float *****)0x0;
        pppppfStack_2d4 = (float *****)0x8;
        pppppfStack_2d0 = local_6c;
        pppppfStack_2dc = local_124;
        pppppfStack_2c8 = local_64;
        pppppfStack_2e0 = (float *****)0x4bc5e1;
        local_68 = pppppfStack_2cc;
        (*(code *)unaff_ESI)();
        pppppfStack_2e0 = (float *****)0x4bc5ea;
        __vbaFreeVar();
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          pppppfStack_228 = (float *****)0x4bc646;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar20) {
            pppppfStack_228 = (float *****)0x4bc611;
            __vbaGenerateBoundsError();
          }
          iVar23 = *(int *)(DAT_0050b1a4 + 10);
          if (*(uint *)(DAT_0050b1a4 + 8) <= 2U - iVar23) {
            pppppfStack_228 = (float *****)0x4bc62e;
            __vbaGenerateBoundsError();
          }
          iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (2U - iVar23) + (1U - iVar20)) * 2;
        }
        *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20) = sVar18;
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          pppppfStack_228 = (float *****)0x4bc6af;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          iVar20 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 2U - iVar20) {
            pppppfStack_228 = (float *****)0x4bc67a;
            __vbaGenerateBoundsError();
          }
          iVar23 = *(int *)(DAT_0050b1a4 + 10);
          if (*(uint *)(DAT_0050b1a4 + 8) <= 2U - iVar23) {
            pppppfStack_228 = (float *****)0x4bc697;
            __vbaGenerateBoundsError();
          }
          iVar20 = (*(int *)(DAT_0050b1a4 + 0xc) * (2U - iVar23) + (2U - iVar20)) * 2;
        }
        *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar20) = (short)local_28;
      }
      pppppfStack_22c = (float *****)&local_124;
      pppppfStack_228 = (float *****)0x0;
      pppppfStack_230 = (float *****)0x4bc6cf;
      __vbaObjSetAddref();
      pppppfStack_230 = (float *****)&LAB_004bc73b;
      pppppfStack_234 = (float *****)0x4bc73a;
      __vbaFreeObj();
      return;
    }
    goto LAB_004bc751;
  }
  pppppfStack_22c = (float *****)(int)(short)local_24;
  local_c0 = (float *****)0x3;
  pppppfStack_238 = (float *****)0xb;
  pppppfStack_234 = (float *****)0x3;
  pppppfStack_230 = local_bc;
  pppppfStack_23c = local_124;
  pppppfStack_228 = local_b4;
  pppppfStack_240 = (float *****)0x4bb40e;
  local_b8 = pppppfStack_22c;
  (*(code *)unaff_ESI)();
  local_d8 = (float *****)(int)(short)local_24;
  local_b8 = (float *****)(int)DAT_0050b298;
  pppppfStack_228 = (float *****)CONCAT22((short)local_24 >> 0xf,(short)local_24 + -2);
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SBORROW2((short)local_24,2)) goto LAB_004bc751;
  local_c0 = (float *****)0x3;
  local_e0 = (float *****)0x3;
  pppppfStack_22c = (float *****)0x4bb450;
  __vbaStrI2();
  pppppfStack_22c = (float *****)0x4bb457;
  pppppfStack_22c = (float *****)__vbaStrMove();
  pppppfStack_230 = (float *****)0x4bb45e;
  Ordinal_519();
  pppppfStack_230 = (float *****)0x4bb465;
  pppppfStack_230 = (float *****)__vbaStrMove();
  pppppfStack_234 = (float *****)0x4bb46c;
  pppppfStack_258 = (float *****)__vbaStrCat();
  local_70 = (float ****)0x8;
  pppppfStack_240 = local_c0;
  pppppfStack_23c = local_bc;
  pppppfStack_238 = local_b8;
  pppppfStack_234 = local_b4;
  pppppfStack_250 = local_e0;
  pppppfStack_24c = local_dc;
  pppppfStack_248 = local_d8;
  pppppfStack_244 = local_d4;
  pppppfStack_264 = (float *****)0x2;
  pppppfStack_268 = (float *****)0x41;
  pppppfStack_260 = (float *****)0x8;
  pppppfStack_25c = local_6c;
  pppppfStack_254 = local_64;
  pppppfStack_26c = local_124;
  pppppfStack_270 = (float *****)0x4bb4ec;
  local_68 = pppppfStack_258;
  __vbaLateIdCallSt();
  pppppfStack_270 = (float *****)&local_4c;
  pppppfStack_274 = (float *****)&local_48;
  pppppfStack_278 = (float *****)0x2;
  pppppfStack_27c = (float *****)0x4bb4fc;
  __vbaFreeStrList();
  pppppfStack_234 = (float *****)0x4bb508;
  __vbaFreeVar();
  local_d8 = (float *****)(int)(short)local_24;
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SCARRY2(DAT_0050b298,1)) goto LAB_004bc751;
  local_b8 = (float *****)(int)(short)(DAT_0050b298 + 1);
  pppppfStack_228 = DAT_0050b190;
  local_c0 = (float *****)0x3;
  local_e0 = (float *****)0x3;
  pppppfStack_22c = &local_44;
  pppppfStack_230 = (float *****)0x4bb54d;
  __vbaAryLock();
  if (((float *****)local_44 == (float *****)0x0) || (*(short *)local_44 != 1)) {
    pppppfStack_228 = (float *****)0x4bb597;
    iVar20 = __vbaGenerateBoundsError();
  }
  else {
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SBORROW2((short)local_24,2)) goto LAB_004bc751;
    local_114 = (float ***)((int)(short)((short)local_24 + -2) - (int)local_44[5]);
    if (local_44[4] <= local_114) {
      pppppfStack_228 = (float *****)0x4bb583;
      __vbaGenerateBoundsError();
    }
    iVar20 = (int)local_114 << 2;
  }
  pppppfStack_24c = (float *****)((int)local_44[3] + iVar20);
  pppppfStack_234 = local_c0;
  pppppfStack_230 = local_bc;
  pppppfStack_22c = local_b8;
  pppppfStack_228 = local_b4;
  pppppfStack_244 = local_e0;
  pppppfStack_240 = local_dc;
  pppppfStack_23c = local_d8;
  pppppfStack_238 = local_d4;
  pppppfStack_258 = (float *****)0x2;
  pppppfStack_254 = (float *****)0x4008;
  pppppfStack_25c = (float *****)0x41;
  pppppfStack_250 = local_fc;
  pppppfStack_248 = local_f4;
  pppppfStack_260 = local_124;
  pppppfStack_264 = (float *****)0x4bb61d;
  __vbaLateIdCallSt();
  pppppfStack_228 = &local_44;
  pppppfStack_22c = (float *****)0x4bb62a;
  __vbaAryUnlock();
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SBORROW2((short)local_24,2)) goto LAB_004bc751;
  if ((short)((short)local_24 + -2) == DAT_0050b2cc) {
    local_c0 = (float *****)0x3;
    if (SCARRY2(DAT_0050b298,2)) goto LAB_004bc751;
    pppppfStack_22c = (float *****)(int)(short)(DAT_0050b298 + 2);
    pppppfStack_238 = (float *****)0xa;
    pppppfStack_234 = (float *****)0x3;
    pppppfStack_230 = local_bc;
    pppppfStack_23c = local_124;
    pppppfStack_228 = local_b4;
    pppppfStack_240 = (float *****)0x4bb691;
    local_b8 = pppppfStack_22c;
    (*(code *)unaff_ESI)();
    local_c0 = (float *****)0x3;
    pppppfStack_250 = (float *****)0x27;
    pppppfStack_24c = (float *****)0x3;
    local_b8 = (float *****)0xff;
    pppppfStack_248 = local_bc;
    pppppfStack_254 = local_124;
    pppppfStack_244 = (float *****)0xff;
    pppppfStack_240 = local_b4;
    pppppfStack_258 = (float *****)0x4bb6ce;
    (*(code *)unaff_ESI)();
  }
  pppppfStack_228 = (float *****)0x4bb6d3;
  FUN_0044fdc0();
  pppppfStack_228 = (float *****)0x4bb6da;
  __vbaStrMove();
  pppppfVar12 = local_60;
  local_d0 = (float ****)0x3;
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SCARRY2(DAT_0050b298,2)) goto LAB_004bc751;
  local_c8 = (undefined4 *)(int)(short)(DAT_0050b298 + 2);
  local_f0 = (float *****)0x3;
  local_e8 = (int)(short)local_24;
  pppppfStack_22c = &local_44;
  pppppfStack_228 = (float *****)DAT_0050b0dc;
  local_60 = (float *****)0x0;
  local_68 = pppppfVar12;
  local_70 = (float ****)0x8;
  pppppfStack_230 = (float *****)0x4bb734;
  __vbaAryLock();
  if (((float *****)local_44 == (float *****)0x0) || (*(short *)local_44 != 1)) {
    pppppfStack_228 = (float *****)0x4bb78b;
    iVar20 = __vbaGenerateBoundsError();
  }
  else {
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    puVar6 = local_c;
    if (SBORROW2((short)local_24,2)) goto LAB_004bc751;
    if (SCARRY2((short)local_24 + -2,DAT_0050b2c4)) goto LAB_004bc751;
    local_114 = (float ***)((int)(short)((short)local_24 + -2 + DAT_0050b2c4) - (int)local_44[5]);
    if (local_44[4] <= local_114) {
      pppppfStack_228 = (float *****)0x4bb777;
      __vbaGenerateBoundsError();
    }
    iVar20 = (int)local_114 << 3;
  }
  pppppfStack_228 = (float *****)0x1;
  local_b8 = (float *****)((int)local_44[3] + iVar20);
  pppppfStack_230 = &local_70;
  pppppfStack_22c = (float *****)&DAT_00000001;
  pppppfStack_234 = (float *****)&local_c0;
  pppppfStack_238 = &local_80;
  local_c0 = (float *****)0x4005;
  pppppfStack_23c = (float *****)0x4bb7bc;
  Ordinal_660();
  pppppfStack_23c = &local_44;
  pppppfStack_240 = (float *****)0x4bb7c6;
  __vbaAryUnlock();
  pppppfStack_228 = (float *****)CONCAT22(extraout_var,(short)local_24 + -2);
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SBORROW2((short)local_24,2)) goto LAB_004bc751;
  pppppfStack_22c = (float *****)0x4bb7e0;
  __vbaStrI2();
  pppppfStack_22c = (float *****)0x4bb7e7;
  pppppfStack_22c = (float *****)__vbaStrMove();
  pppppfStack_230 = (float *****)0x4bb7ee;
  Ordinal_519();
  pppppfStack_230 = (float *****)0x4bb7f5;
  pppppfStack_230 = (float *****)__vbaStrMove();
  pppppfStack_234 = (float *****)0x4bb7fc;
  __vbaStrCat();
  pppppfStack_234 = (float *****)0x4bb803;
  pppppfStack_234 = (float *****)__vbaStrMove();
  pppppfStack_238 = (float *****)&DAT_0040cb48;
  pppppfStack_23c = (float *****)0x4bb80f;
  __vbaStrCat();
  pppppfStack_23c = (float *****)0x4bb816;
  pppppfStack_23c = (float *****)__vbaStrMove();
  pppppfStack_240 = &local_80;
  pppppfStack_244 = &local_54;
  pppppfStack_248 = (float *****)0x4bb825;
  pppppfStack_248 = (float *****)__vbaStrVarVal();
  pppppfStack_24c = (float *****)0x4bb82c;
  Ordinal_519();
  pppppfStack_24c = (float *****)0x4bb833;
  pppppfStack_24c = (float *****)__vbaStrMove();
  pppppfStack_250 = (float *****)0x4bb83a;
  pppppfStack_274 = (float *****)__vbaStrCat();
  local_90 = (float ****)0x8;
  pppppfStack_25c = (float *****)local_d0;
  pppppfStack_258 = (float *****)local_cc;
  pppppfStack_254 = (float *****)local_c8;
  pppppfStack_250 = (float *****)local_c4;
  pppppfStack_26c = local_f0;
  pppppfStack_268 = (float *****)local_ec;
  pppppfStack_264 = (float *****)local_e8;
  pppppfStack_260 = (float *****)local_e4;
  pppppfStack_27c = (float *****)0x8;
  pppppfStack_278 = local_8c;
  pppppfStack_280 = (float *****)0x2;
  pppppfStack_284 = (float *****)0x41;
  pppppfStack_270 = local_84;
  pppppfStack_288 = local_124;
  pppppfStack_28c = (float *****)0x4bb8c6;
  local_88 = pppppfStack_274;
  __vbaLateIdCallSt();
  pppppfStack_28c = (float *****)&local_60;
  pppppfStack_290 = &local_5c;
  pppppfStack_294 = (float *****)&local_58;
  pppppfStack_298 = &local_54;
  pppppfStack_29c = &local_50;
  pppppfStack_2a0 = (float *****)&local_4c;
  pppppfStack_2a4 = (float *****)&local_48;
  pppppfStack_2a8 = (float *****)0x7;
  pppppfStack_2ac = (float *****)0x4bb8ea;
  __vbaFreeStrList();
  pppppfStack_250 = &local_90;
  pppppfStack_254 = &local_80;
  pppppfStack_258 = &local_70;
  pppppfStack_25c = (float *****)0x3;
  pppppfStack_260 = (float *****)0x4bb904;
  __vbaFreeVarList();
  pppppfStack_260 = (float *****)0x0;
  pppppfStack_264 = (float *****)0x4;
  pppppfStack_26c = &local_70;
  pppppfStack_268 = local_124;
  pppppfStack_270 = (float *****)0x4bb919;
  pppppfStack_250 = (float *****)__vbaLateIdCallLd();
  pppppfStack_254 = (float *****)0x4bb923;
  iVar20 = __vbaI4Var();
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SBORROW4(iVar20,1)) goto LAB_004bc751;
  local_c0 = (float *****)0x3;
  pppppfStack_238 = (float *****)0xa;
  pppppfStack_234 = (float *****)0x3;
  pppppfStack_230 = local_bc;
  pppppfStack_23c = local_124;
  pppppfStack_228 = local_b4;
  pppppfStack_240 = (float *****)0x4bb964;
  pppppfStack_22c = (float *****)(iVar20 + -1);
  local_b8 = (float *****)(iVar20 + -1);
  (*(code *)unaff_ESI)();
  pppppfStack_240 = (float *****)0x4bb96d;
  __vbaFreeVar();
  local_c0 = (float *****)0x2;
  pppppfStack_250 = (float *****)0x28;
  pppppfStack_24c = (float *****)0x2;
  local_b8 = (float *****)0x4;
  pppppfStack_248 = local_bc;
  pppppfStack_254 = local_124;
  pppppfStack_244 = (float *****)0x4;
  pppppfStack_240 = local_b4;
  pppppfStack_258 = (float *****)0x4bb9aa;
  (*(code *)unaff_ESI)();
  local_b8 = (float *****)0x41600000;
  local_c0 = (float *****)0x4;
  pppppfStack_268 = (float *****)0x4e;
  pppppfStack_264 = (float *****)0x4;
  pppppfStack_260 = local_bc;
  pppppfStack_26c = local_124;
  pppppfStack_25c = (float *****)0x41600000;
  pppppfStack_258 = local_b4;
  pppppfStack_270 = (float *****)0x4bb9e7;
  (*(code *)unaff_ESI)();
  local_c0 = (float *****)0xb;
  pppppfStack_280 = (float *****)0x4f;
  pppppfStack_27c = (float *****)0xb;
  local_b8 = (float *****)0xffffffff;
  pppppfStack_278 = local_bc;
  pppppfStack_284 = local_124;
  pppppfStack_274 = (float *****)0xffffffff;
  pppppfStack_270 = local_b4;
  pppppfStack_288 = (float *****)0x4bba22;
  (*(code *)unaff_ESI)();
  pppppfStack_288 = (float *****)0x0;
  pppppfStack_28c = (float *****)0x4;
  pppppfStack_294 = &local_70;
  pppppfStack_290 = local_124;
  pppppfStack_298 = (float *****)0x4bba37;
  pppppfStack_288 = (float *****)__vbaLateIdCallLd();
  pppppfStack_28c = (float *****)0x4bba41;
  iVar20 = __vbaI4Var();
  ppppppfVar10 = (float ******)(iVar20 + -1);
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar5 = local_24;
  puVar6 = local_c;
  if (SBORROW4(iVar20,1)) goto LAB_004bc751;
  local_c0 = (float *****)0x3;
  local_d8 = (float *****)(int)(short)local_24;
  local_e0 = (float *****)0x3;
  local_b8 = (float *****)ppppppfVar10;
  if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
    pppppfStack_228 = (float *****)0x4bbaf6;
    iVar20 = __vbaGenerateBoundsError();
  }
  else {
    if ((SCARRY2(DAT_0050b2c4,(short)local_24)) || (SBORROW2(DAT_0050b2c4 + (short)local_24,2)))
    goto LAB_004bc751;
    local_118 = (int)(short)(DAT_0050b2c4 + (short)local_24 + -2) - *(int *)(DAT_0050b0c0 + 0xe);
    if (*(uint *)(DAT_0050b0c0 + 0xc) <= local_118) {
      pppppfStack_228 = (float *****)0x4bbab1;
      __vbaGenerateBoundsError();
    }
    local_114 = (float ***)-*(int *)(DAT_0050b0c0 + 10);
    if (*(float *****)(DAT_0050b0c0 + 8) <= local_114) {
      pppppfStack_228 = (float *****)0x4bbad3;
      __vbaGenerateBoundsError();
    }
    iVar20 = (*(int *)(DAT_0050b0c0 + 0xc) * (int)local_114 + local_118) * 8;
  }
  pppppfStack_228 = *(float ******)(*(int *)(DAT_0050b0c0 + 6) + 4 + iVar20);
  pppppfStack_22c = *(float ******)(*(int *)(DAT_0050b0c0 + 6) + iVar20);
  pppppfStack_230 = (float *****)0x4bbb0e;
  pppppfStack_254 = (float *****)__vbaStrR8();
  local_80 = (float ****)0x8;
  pppppfStack_23c = local_c0;
  pppppfStack_238 = local_bc;
  pppppfStack_234 = local_b8;
  pppppfStack_230 = local_b4;
  pppppfStack_24c = local_e0;
  pppppfStack_248 = local_dc;
  pppppfStack_244 = local_d8;
  pppppfStack_240 = local_d4;
  pppppfStack_260 = (float *****)0x2;
  pppppfStack_264 = (float *****)0x41;
  pppppfStack_25c = (float *****)0x8;
  pppppfStack_258 = local_7c;
  pppppfStack_250 = local_74;
  pppppfStack_268 = local_124;
  pppppfStack_26c = (float *****)0x4bbb8e;
  local_78 = pppppfStack_254;
  __vbaLateIdCallSt();
  pppppfStack_26c = &local_80;
  pppppfStack_270 = &local_70;
  pppppfStack_274 = (float *****)0x2;
  pppppfStack_278 = (float *****)0x4bbb9e;
  __vbaFreeVarList();
  ppppppfVar26 = (float ******)pppppfStack_23c;
  ppppppfVar22 = (float ******)pppppfStack_230;
  uVar27 = local_2c;
  uVar4 = (uint)(ushort)((short)local_24 + 1);
  uVar5 = local_24;
  puVar6 = local_c;
  if (SCARRY2((short)local_24,1)) goto LAB_004bc751;
  goto LAB_004bb3c8;
LAB_004bc96f:
  pppppfStack_23c = (float *****)ppppppfVar24;
  ppppppfVar26 = (float ******)0x0;
  pppppfStack_2f8 = (float *****)0x0;
  if ((short)ppppfStack_2c4 < (short)ppppppfVar22) {
    pppppfStack_2fc = (float *****)&pppppfStack_2b4;
    pppppfStack_300 = (float *****)0x4bcd5e;
    __vbaObjSetAddref();
    pppppfStack_300 = (float *****)&LAB_004bcd92;
    pppppfStack_304 = (float *****)0x4bcd85;
    __vbaFreeStr();
    pppppfStack_304 = (float *****)0x4bcd91;
    __vbaFreeObj();
    return;
  }
  pppppfStack_2fc = (float *****)0x5;
  pppppfStack_304 = (float *****)&pppppfStack_25c;
  pppppfStack_300 = pppppfStack_2b4;
  pppppfStack_308 = (float *****)0x4bc98c;
  pppppfStack_2f8 = (float *****)(*pcVar17)();
  pppppfStack_2fc = (float *****)0x4bc996;
  iVar20 = __vbaI4Var();
  pppppfStack_420 = (float *****)ppppppfVar22;
  if (SBORROW4(iVar20,1)) goto LAB_004bcda8;
  pppppfStack_2f8 = (float *****)0x4bc9a7;
  pppppfStack_2cc = (float *****)__vbaI2I4();
  pppppfStack_240 = (float *****)0x2;
  pppppfStack_2f8 = (float *****)0x4bc9be;
  __vbaFreeVar();
  uVar13 = extraout_EDX;
  ppppppfVar24 = (float ******)0x2;
  ppppppfVar22 = (float ******)pppppfStack_240;
  while( true ) {
    pppppfStack_240 = (float *****)ppppppfVar22;
    ppppppfVar26 = ppppppfVar24;
    sVar18 = (short)pppppfStack_420;
    if ((short)pppppfStack_2cc < (short)ppppppfVar26) break;
    if (SCARRY2((short)pppppfStack_244,1)) goto LAB_004bcda8;
    ppppppfVar24 = (float ******)(int)sVar18;
    pppppfStack_304 = (float *****)0x3;
    ppppppfVar26 = (float ******)(int)(short)ppppppfVar26;
    pppppfStack_300 = pppppfStack_268;
    pppppfStack_2f8 = pppppfStack_260;
    ppfStack_318 = (float **)0x2;
    pppppfStack_31c = (float *****)0x41;
    ppppfStack_314 = (float ****)0x3;
    pppppfStack_310 = pppppfStack_288;
    pppppfStack_324 = (float *****)&pppppfStack_25c;
    pppppfStack_308 = pppppfStack_280;
    pppppfStack_320 = pppppfStack_2b4;
    uStack_328 = 0x4bca26;
    pppppfStack_30c = (float *****)ppppppfVar26;
    pppppfStack_2fc = (float *****)ppppppfVar24;
    pppppfStack_244 =
         (float *****)CONCAT22((short)((uint)uVar13 >> 0x10),(short)pppppfStack_244 + 1);
    pppppfStack_2f8 = (float *****)(*pcVar17)();
    pppppfStack_2fc = (float *****)0x4bca30;
    __vbaStrVarMove();
    pppppfStack_2fc = (float *****)0x4bca3d;
    __vbaStrMove();
    pppppfStack_2fc = (float *****)0x4bca46;
    __vbaFreeVar();
    pppppfStack_2fc = (float *****)0x4bca58;
    __vbaStrCopy();
    pppppfStack_2fc = pppppfStack_2b0;
    pppppfStack_300 = (float *****)&DAT_0040ca6c;
    pppppfStack_304 = (float *****)0x4bca6c;
    iVar20 = __vbaStrCmp();
    if (iVar20 == 0) {
      if (DAT_0050b334 == 4) {
        if ((DAT_0050b0e8 == (float ******)0x0) || (*(short *)DAT_0050b0e8 != 1)) {
          pppppfStack_2f8 = (float *****)0x4bcb0e;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfVar24 = (float ******)((int)(short)pppppfStack_244 - (int)DAT_0050b0e8[5]);
          if (DAT_0050b0e8[4] <= ppppppfVar24) {
            pppppfStack_2f8 = (float *****)0x4bcaf9;
            __vbaGenerateBoundsError();
          }
          iVar20 = (int)ppppppfVar24 * 8;
        }
        *(double *)((int)DAT_0050b0e8[3] + iVar20) = (double)-(float)pppppfStack_248;
        if ((in_FPUStatusWord & 0xd) != 0) {
          __vbaFPException();
          return;
        }
      }
      else if ((DAT_0050b0e8 == (float ******)0x0) || (*(short *)DAT_0050b0e8 != 1)) {
        pppppfStack_2f8 = (float *****)0x4bcac5;
        iVar20 = __vbaGenerateBoundsError();
        *(double *)((int)DAT_0050b0e8[3] + iVar20) = (double)(float)pppppfStack_248;
      }
      else {
        ppppppfVar24 = (float ******)((int)(short)pppppfStack_244 - (int)DAT_0050b0e8[5]);
        if (DAT_0050b0e8[4] <= ppppppfVar24) {
          pppppfStack_2f8 = (float *****)0x4bcaa4;
          __vbaGenerateBoundsError();
        }
        *(double *)(DAT_0050b0e8[3] + (int)ppppppfVar24 * 2) = (double)(float)pppppfStack_248;
      }
    }
    else {
      pppppfStack_2f8 = pppppfStack_2b0;
      pppppfStack_2fc = (float *****)0x40cc7c;
      pppppfStack_300 = (float *****)0x4bcb3e;
      iVar20 = __vbaStrCmp();
      if (iVar20 == 0) {
        if ((DAT_0050b0e8 == (float ******)0x0) || (*(short *)DAT_0050b0e8 != 1)) {
          pppppfStack_2f8 = (float *****)0x4bcb89;
          iVar20 = __vbaGenerateBoundsError();
          *(double *)((int)DAT_0050b0e8[3] + iVar20) = (double)(float)pppppfStack_248;
        }
        else {
          ppppppfVar24 = (float ******)((int)(short)pppppfStack_244 - (int)DAT_0050b0e8[5]);
          if (DAT_0050b0e8[4] <= ppppppfVar24) {
            pppppfStack_2f8 = (float *****)0x4bcb68;
            __vbaGenerateBoundsError();
          }
          *(double *)(DAT_0050b0e8[3] + (int)ppppppfVar24 * 2) = (double)(float)pppppfStack_248;
        }
      }
      else {
        if ((DAT_0050b0e8 == (float ******)0x0) || (*(short *)DAT_0050b0e8 != 1)) {
          pppppfStack_2f8 = (float *****)0x4bcbcd;
          iVar20 = __vbaGenerateBoundsError();
        }
        else {
          iVar20 = (int)(short)pppppfStack_244;
          pppppfVar12 = DAT_0050b0e8[5];
          if (DAT_0050b0e8[4] <= (float *****)(iVar20 - (int)pppppfVar12)) {
            pppppfStack_2f8 = (float *****)0x4bcbc2;
            __vbaGenerateBoundsError();
          }
          iVar20 = (iVar20 - (int)pppppfVar12) * 8;
        }
        pppppfStack_304 = (float *****)0x3;
        pppppfStack_300 = pppppfStack_268;
        pppppfStack_2f8 = pppppfStack_260;
        ppfStack_318 = (float **)0x2;
        ppppfStack_314 = (float ****)0x3;
        pppppfStack_31c = (float *****)0x41;
        pppppfStack_310 = pppppfStack_288;
        pppppfStack_324 = (float *****)&pppppfStack_25c;
        pppppfStack_308 = pppppfStack_280;
        pppppfStack_320 = pppppfStack_2b4;
        uStack_328 = 0x4bcc1a;
        pppppfStack_30c = (float *****)ppppppfVar26;
        pppppfStack_2fc = (float *****)ppppppfVar24;
        pppppfStack_2f8 = (float *****)__vbaLateIdCallLd();
        pppppfStack_2fc = (float *****)0x4bcc24;
        __vbaStrVarMove();
        pppppfStack_2fc = (float *****)0x4bcc2f;
        pppppfStack_2fc = (float *****)__vbaStrMove();
        pppppfStack_300 = (float *****)0x4bcc36;
        fVar30 = (float10)Ordinal_581();
        *(double *)((int)DAT_0050b0e8[3] + iVar20) = (double)fVar30;
        pppppfStack_300 = (float *****)0x4bcc4b;
        __vbaFreeStr();
        pppppfStack_300 = (float *****)0x4bcc54;
        __vbaFreeVar();
      }
    }
    if ((DAT_0050b0e8 == (float ******)0x0) || (*(short *)DAT_0050b0e8 != 1)) {
      pppppfStack_2f8 = (float *****)0x4bcc88;
      pcVar11 = (code *)__vbaGenerateBoundsError();
    }
    else {
      ppppppfVar24 = (float ******)((int)(short)pppppfStack_244 - (int)DAT_0050b0e8[5]);
      if (DAT_0050b0e8[4] <= ppppppfVar24) {
        pppppfStack_2f8 = (float *****)0x4bcc79;
        __vbaGenerateBoundsError();
      }
      pcVar11 = (code *)((int)ppppppfVar24 * 8);
    }
    if ((DAT_0050b3f4 == (short *)0x0) || (*DAT_0050b3f4 != 2)) {
      pppppfStack_2f8 = (float *****)0x4bccfd;
      iVar20 = __vbaGenerateBoundsError();
    }
    else {
      pcVar17 = pcVar11;
      pppppfStack_420 = (float *****)ppppppfVar24;
      if (SBORROW2((short)pppppfStack_23c,1)) goto LAB_004bcda8;
      ppppppfVar26 = (float ******)
                     ((int)(short)((short)pppppfStack_23c + -1) - *(int *)(DAT_0050b3f4 + 0xe));
      if (*(float *******)(DAT_0050b3f4 + 0xc) <= ppppppfVar26) {
        pppppfStack_2f8 = (float *****)0x4bccbd;
        __vbaGenerateBoundsError();
      }
      if (SBORROW2((short)pppppfStack_240,1)) goto LAB_004bcda8;
      uVar27 = (int)(short)((short)pppppfStack_240 + -1) - *(int *)(DAT_0050b3f4 + 10);
      if (*(uint *)(DAT_0050b3f4 + 8) <= uVar27) {
        pppppfStack_2f8 = (float *****)0x4bcce4;
        __vbaGenerateBoundsError();
      }
      iVar20 = (int)(*(int *)(DAT_0050b3f4 + 0xc) * uVar27 + (int)ppppppfVar26) * 8;
    }
    iVar23 = *(int *)(DAT_0050b3f4 + 6);
    pppppfVar12 = DAT_0050b0e8[3];
    *(undefined4 *)(iVar23 + iVar20) = *(undefined4 *)(pcVar11 + (int)pppppfVar12);
    pcVar17 = __vbaLateIdCallLd_exref;
    uVar13 = *(undefined4 *)(pcVar11 + (int)(pppppfVar12 + 1));
    *(undefined4 *)(iVar23 + 4 + iVar20) = uVar13;
    pppppfStack_420 = pppppfStack_23c;
    ppppppfVar24 = (float ******)(uint)(ushort)((short)pppppfStack_240 + 1);
    ppppppfVar22 = (float ******)(uint)(ushort)((short)pppppfStack_240 + 1);
    if (SCARRY2((short)pppppfStack_240,1)) goto LAB_004bcda8;
  }
  ppppppfVar22 = (float ******)(uint)(ushort)(sVar18 + 1);
  ppppppfVar24 = ppppppfVar22;
  if (SCARRY2(sVar18,1)) goto LAB_004bcda8;
  goto LAB_004bc96f;
  while( true ) {
    in_FPUStatusWord = 0;
    if (*(double *)(*(int *)(psVar15 + 6) + local_1cc) ==
        *(double *)(*(int *)(psVar15 + 6) + local_1d0)) {
      local_34 = 1;
      goto LAB_004baa6d;
    }
    bVar28 = SCARRY2((short)local_18,1);
    uVar29 = (short)local_18 + 1;
    ppppppfVar26 = (float ******)pppppfStack_23c;
    ppppppfVar22 = (float ******)pppppfStack_230;
    uVar27 = local_2c;
    uVar5 = local_24;
    ppppppfVar10 = (float ******)(uint)uVar29;
    puVar6 = local_c;
    if (bVar28) break;
LAB_004ba924:
    local_18 = (float *****)ppppppfVar10;
    if (sVar18 < (short)local_18) {
LAB_004baa6d:
      ppppppfVar10 = _DAT_0050b2c4;
      ppppppfVar9 = _DAT_0050b2c4;
      ppppppfVar16 = (float ******)&DAT_00000001;
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      goto LAB_004baa7d;
    }
    if ((psVar15 == (short *)0x0) || (*psVar15 != 2)) {
      pppppfStack_228 = (float *****)0x4ba999;
      local_1cc = __vbaGenerateBoundsError();
      psVar15 = DAT_0050b0c0;
    }
    else {
      local_118 = (int)(short)local_18 - *(int *)(psVar15 + 0xe);
      if (*(uint *)(psVar15 + 0xc) <= local_118) {
        pppppfStack_228 = (float *****)0x4ba952;
        __vbaGenerateBoundsError();
        psVar15 = DAT_0050b0c0;
      }
      local_114 = (float ***)-*(int *)(psVar15 + 10);
      if (*(float *****)(psVar15 + 8) <= local_114) {
        pppppfStack_228 = (float *****)0x4ba970;
        __vbaGenerateBoundsError();
        psVar15 = DAT_0050b0c0;
      }
      local_1cc = (*(int *)(psVar15 + 0xc) * (int)local_114 + local_118) * 8;
    }
    if ((psVar15 == (short *)0x0) || (*psVar15 != 2)) {
      pppppfStack_228 = (float *****)0x4baa1f;
      local_1d0 = __vbaGenerateBoundsError();
      psVar15 = DAT_0050b0c0;
    }
    else {
      bVar28 = SCARRY2((short)local_18,1);
      sVar19 = (short)local_18 + 1;
      ppppppfVar26 = (float ******)pppppfStack_23c;
      ppppppfVar22 = (float ******)pppppfStack_230;
      uVar27 = local_2c;
      uVar5 = local_24;
      puVar6 = local_c;
      if (bVar28) break;
      local_120 = (int)sVar19 - *(int *)(psVar15 + 0xe);
      if (*(uint *)(psVar15 + 0xc) <= local_120) {
        pppppfStack_228 = (float *****)0x4ba9d8;
        __vbaGenerateBoundsError();
        psVar15 = DAT_0050b0c0;
      }
      local_11c = -*(int *)(psVar15 + 10);
      if (*(uint *)(psVar15 + 8) <= local_11c) {
        pppppfStack_228 = (float *****)0x4ba9f6;
        __vbaGenerateBoundsError();
        psVar15 = DAT_0050b0c0;
      }
      local_1d0 = (*(int *)(psVar15 + 0xc) * local_11c + local_120) * 8;
    }
  }
LAB_004bc751:
  local_c = puVar6;
  local_24 = uVar5;
  local_2c = uVar27;
  pppppfStack_230 = (float *****)ppppppfVar22;
  pppppfStack_23c = (float *****)ppppppfVar26;
  pppppfStack_228 = (float *****)0x4bc757;
  __vbaErrorOverflow();
  pppppfStack_234 = (float *****)&DAT_00402706;
  pppppfStack_238 = ExceptionList;
  pppppfStack_230 = (float *****)&pppppfStack_2e0;
  pppppfStack_22c = (float *****)&DAT_004022f8;
  pppppfStack_2e4 = (float *****)&pppppfStack_2a0;
  ppppppfVar26 = (float ******)0x0;
  pppppfStack_24c = (float *****)0x0;
  pppppfStack_25c = (float *****)0x0;
  pppppfStack_26c = (float *****)0x0;
  pppppfStack_28c = (float *****)0x0;
  pppppfStack_2b0 = (float *****)0x0;
  pppppfStack_2b4 = (float *****)0x0;
  pppppfStack_2a0 = (float *****)0x7;
  piStack_2e8 = (int *)0x4bc7b6;
  ExceptionList = &pppppfStack_238;
  pppppfStack_2e0 = (float *****)ppppppfVar24;
  pppppfStack_2dc = (float *****)unaff_ESI;
  pppppfStack_2d8 = unaff_EBX;
  pppppfStack_228 = (float *****)&stack0xfffffffc;
  FUN_0042b600();
  pppppfStack_248 = (float *****)0x497423f0;
  if (DAT_0050b448 == (int *)0x0) {
    piStack_2e8 = (int *)&DAT_0050b448;
    pppppfStack_2ec = (float *****)&DAT_004057e0;
    pppppfStack_2f0 = (float *****)0x4bc7d6;
    __vbaNew2();
  }
  piStack_2e8 = DAT_0050b448;
  pppppfStack_2ec = (float *****)0x4bc7e4;
  pppppfStack_2ec = (float *****)(**(code **)(*DAT_0050b448 + 0x378))();
  pppppfStack_2f0 = (float *****)&pppppfStack_2b4;
  ppppfStack_2f4 = (float ****)0x4bc7f2;
  __vbaObjSet();
  pcVar17 = __vbaLateIdCallLd_exref;
  ppppfStack_2f4 = (float ****)0x0;
  pppppfStack_2f8 = (float *****)0x5;
  pppppfStack_300 = (float *****)&pppppfStack_25c;
  pppppfStack_2fc = pppppfStack_2b4;
  pppppfStack_304 = (float *****)0x4bc808;
  ppppfStack_2f4 = (float ****)__vbaLateIdCallLd();
  pppppfStack_2f8 = (float *****)0x4bc812;
  iVar20 = __vbaI4Var();
  pppppfStack_420 = (float *****)unaff_ESI;
  if (!SBORROW4(iVar20,1)) {
    pppppfStack_2f8 = (float *****)0x4bc823;
    pppppfStack_2bc = (float *****)__vbaI2I4();
    pppppfStack_2f8 = (float *****)0x4bc837;
    __vbaFreeVar();
    ppppppfVar24 = (float ******)0x2;
    do {
      ppppppfVar26 = (float ******)0x0;
      sVar18 = (short)ppppppfVar24;
      pppppfStack_420 = (float *****)ppppppfVar24;
      if ((short)pppppfStack_2bc < sVar18) {
        pppppfStack_2f8 = (float *****)0x0;
        pppppfStack_2fc = (float *****)0x4;
        pppppfStack_304 = (float *****)&pppppfStack_25c;
        pppppfStack_300 = pppppfStack_2b4;
        pppppfStack_244 = (float *****)0x0;
        pppppfStack_308 = (float *****)0x4bc93d;
        pppppfStack_2f8 = (float *****)__vbaLateIdCallLd();
        pppppfStack_2fc = (float *****)0x4bc947;
        iVar20 = __vbaI4Var();
        if (!SBORROW4(iVar20,1)) {
          pppppfStack_2f8 = (float *****)0x4bc958;
          ppppfStack_2c4 = (float ****)__vbaI2I4();
          ppppppfVar22 = (float ******)0x2;
          pppppfStack_23c = (float *****)0x2;
          pppppfStack_2f8 = (float *****)0x4bc96f;
          __vbaFreeVar();
          ppppppfVar24 = (float ******)pppppfStack_23c;
          goto LAB_004bc96f;
        }
        break;
      }
      pppppfStack_28c = (float *****)0x3;
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppfStack_2f8 = (float *****)0x4bc888;
        ppppppfVar26 = (float ******)__vbaGenerateBoundsError();
      }
      else {
        if (SBORROW2(sVar18,1)) break;
        uVar27 = (int)(short)(sVar18 + -1) - *(int *)(DAT_0050b394 + 10);
        if (*(uint *)(DAT_0050b394 + 8) <= uVar27) {
          pppppfStack_2f8 = (float *****)0x4bc87a;
          __vbaGenerateBoundsError();
        }
        ppppppfVar26 = (float ******)(uVar27 * 0x18);
      }
      pppppfStack_304 = (float *****)0x3;
      pppppfStack_300 = pppppfStack_268;
      pppppfStack_2fc = (float *****)0x1;
      pppppfStack_2f8 = pppppfStack_260;
      ppfStack_318 = (float **)0x2;
      pppppfStack_31c = (float *****)0x41;
      ppppfStack_314 = (float ****)pppppfStack_28c;
      pppppfStack_310 = pppppfStack_288;
      pppppfStack_30c = (float *****)(int)sVar18;
      pppppfStack_320 = pppppfStack_2b4;
      pppppfStack_308 = pppppfStack_280;
      pppppfStack_324 = (float *****)&pppppfStack_25c;
      uStack_328 = 0x4bc8d7;
      pppppfStack_2f8 = (float *****)__vbaLateIdCallLd();
      pppppfStack_2fc = (float *****)0x4bc8e1;
      __vbaStrVarMove();
      pppppfStack_2fc = (float *****)0x4bc8ec;
      pppppfStack_2fc = (float *****)__vbaStrMove();
      pppppfStack_300 = (float *****)(*(int *)(DAT_0050b394 + 6) + (int)ppppppfVar26);
      pppppfStack_304 = (float *****)0xc;
      pppppfStack_308 = (float *****)0x4bc901;
      __vbaLsetFixstr();
      pppppfStack_308 = (float *****)0x4bc90a;
      __vbaFreeStr();
      pppppfStack_308 = (float *****)0x4bc913;
      __vbaFreeVar();
      ppppppfVar24 = (float ******)(uint)(ushort)(sVar18 + 1);
    } while (!SCARRY2(sVar18,1));
  }
LAB_004bcda8:
  pppppfStack_2f8 = (float *****)0x4bcdae;
  __vbaErrorOverflow();
  pppppfStack_304 = (float *****)&DAT_00402706;
  pppppfStack_308 = ExceptionList;
  pppppfStack_300 = (float *****)&pppppfStack_424;
  pppppfStack_2fc = (float *****)&DAT_00402310;
  puStack_428 = auStack_398;
  ppppfStack_314 = (float ****)0x0;
  ppfStack_318 = (float **)0x0;
  pppppfStack_31c = (float *****)0x0;
  pppppfStack_320 = (float *****)0x0;
  pppppfStack_324 = (float *****)0x0;
  appppfStack_334[0] = (float ****)0x0;
  pppppfStack_39c = (float *****)0x0;
  ppppfStack_3a0 = (float ****)0x0;
  pppppfStack_3a4 = (float *****)0x0;
  apiStack_3d0[0] = (int *)0x0;
  pppppfStack_3d4 = (float *****)0x0;
  auStack_398[0] = 0x47;
  pppppfStack_42c = (float *****)0x4bce24;
  ExceptionList = &pppppfStack_308;
  pppppfStack_424 = (float *****)ppppppfVar26;
  pcStack_41c = pcVar17;
  pppppfStack_2f8 = (float *****)&pppppfStack_228;
  FUN_0042b600();
  DAT_0050b1fe = 2;
  DAT_0050b33a = 0;
  DAT_0050b33e = 1;
  if (DAT_0050b420 == (float ******)0x0) {
    pppppfStack_42c = (float *****)&DAT_0050b420;
    ppiStack_430 = (int **)&DAT_00408c88;
    pppppfStack_434 = (float *****)0x4bce56;
    __vbaNew2();
  }
  ppiStack_430 = apiStack_3d0;
  pppppfStack_42c = (float *****)DAT_0050b420;
  pppppfStack_434 = (float *****)0x4bce6a;
  __vbaObjSetAddref();
  pppppfStack_434 = (float *****)&pppppfStack_31c;
  piStack_438 = apiStack_3d0[0];
  pppppfStack_43c = (float *****)0x4bce87;
  iStack_448 = (**(code **)(*apiStack_3d0[0] + 0x248))();
  if (iStack_448 < 0) {
    pppppfStack_43c = (float *****)0x248;
    pwStack_440 = L"믲㢺毡䞍྽닦\xf724㶱䞙缔횱䙏䆙赘鄽쭖䉂片摩";
    pppppfStack_444 = (float *****)apiStack_3d0[0];
    uStack_44c = 0x4bcea5;
    __vbaHresultCheckObj();
  }
  ppppppfVar24 = (float ******)__vbaLateIdSt_exref;
  uStack_44c = 0;
  pppppfStack_450 = pppppfStack_31c;
  iStack_448 = 8;
  pppppfStack_444 = pppppfStack_340;
  pwStack_440 = L"arial";
  pppppfStack_43c = pppppfStack_338;
  pppppfStack_454 = (float *****)0x4bcec9;
  __vbaLateIdSt();
  pppppfStack_454 = (float *****)0x4bced2;
  __vbaFreeObj();
  pppppfStack_454 = (float *****)&pppppfStack_31c;
  piStack_458 = apiStack_3d0[0];
  pppppfStack_45c = (float *****)0x4bcee5;
  iStack_468 = (**(code **)(*apiStack_3d0[0] + 0x248))();
  if (iStack_468 < 0) {
    pppppfStack_45c = (float *****)0x248;
    puStack_460 = &DAT_0040b430;
    pppppfStack_464 = (float *****)apiStack_3d0[0];
    uStack_46c = 0x4bcf03;
    __vbaHresultCheckObj();
  }
  uStack_46c = 2;
  iStack_468 = 2;
  pppppfStack_464 = pppppfStack_340;
  puStack_460 = (undefined *)0x6;
  pppppfStack_470 = pppppfStack_31c;
  pppppfStack_45c = pppppfStack_338;
  uStack_474 = 0x4bcf25;
  __vbaLateIdSt();
  uStack_474 = 0x4bcf2e;
  __vbaFreeObj();
  uStack_474 = 0xffffff;
  piStack_478 = apiStack_3d0[0];
  pppppfStack_47c = (float *****)0x4bcf3f;
  iVar20 = (**(code **)(*apiStack_3d0[0] + 0x6c))();
  if (iVar20 < 0) {
    pppppfStack_47c = (float *****)0x6c;
    pppppfStack_480 = (float *****)&DAT_0040b430;
    pppppfStack_484 = (float *****)apiStack_3d0[0];
    pppppfStack_48c = (float *****)0x4bcf5a;
    puStack_488 = (undefined *)iVar20;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float ******)0x0) {
    pppppfStack_47c = (float *****)&DAT_0050b420;
    pppppfStack_480 = (float *****)&DAT_00408c88;
    pppppfStack_484 = (float *****)0x4bcf73;
    __vbaNew2();
  }
  pppppfStack_480 = (float *****)&pppppfStack_31c;
  pppppfStack_47c = (float *****)DAT_0050b420;
  pppppfStack_484 = (float *****)0x4bcf83;
  __vbaObjSetAddref();
  pppppfStack_484 = (float *****)&pppppfStack_31c;
  puStack_488 = (undefined *)0x4bcf8c;
  FUN_0048c990();
  puStack_488 = &DAT_0040b85c;
  pppppfStack_48c = pppppfStack_31c;
  uStack_490 = 0x4bcf9b;
  uStack_490 = __vbaCastObj();
  puStack_494 = &DAT_0050b420;
  pppppfStack_498 = (float *****)0x4bcfa7;
  __vbaObjSet();
  pppppfStack_498 = (float *****)0x4bcfb0;
  __vbaFreeObj();
  pppppfStack_498 = (float *****)&pppppfStack_31c;
  piStack_49c = apiStack_3d0[0];
  pppppfStack_4a0 = (float *****)0x4bcfc3;
  iStack_4ac = (**(code **)(*apiStack_3d0[0] + 0x248))();
  if (iStack_4ac < 0) {
    pppppfStack_4a0 = (float *****)0x248;
    puStack_4a4 = &DAT_0040b430;
    pppppfStack_4a8 = (float *****)apiStack_3d0[0];
    uStack_4b0 = 0x4bcfe1;
    __vbaHresultCheckObj();
  }
  uStack_4b0 = 3;
  iStack_4ac = 0xb;
  pppppfStack_4a8 = pppppfStack_340;
  puStack_4a4 = (undefined *)0xffffffff;
  pppppfStack_4b4 = pppppfStack_31c;
  pppppfStack_4a0 = pppppfStack_338;
  piStack_4b8 = (int *)0x4bd001;
  __vbaLateIdSt();
  piStack_4b8 = (int *)0x4bd00a;
  __vbaFreeObj();
  piStack_4b8 = apiStack_3d0[0];
  uStack_4bc = 0x4bd019;
  uStack_4bc = (**(code **)(*apiStack_3d0[0] + 0x364))();
  pppppfStack_4c0 = (float *****)&pppppfStack_31c;
  uStack_4c4 = 0x4bd024;
  piStack_4c8 = (int *)__vbaObjSet();
  uStack_4c4 = 0;
  uStack_4cc = 0x4bd035;
  pppppfStack_3a8 = (float *****)piStack_4c8;
  iVar20 = (**(code **)(*piStack_4c8 + 0x9c))();
  if (iVar20 < 0) {
    uStack_4cc = 0x9c;
    ppiStack_4d0 = (int **)&DAT_0040c3dc;
    pppppfStack_4d4 = pppppfStack_3a8;
    pppppfStack_4dc = (float *****)0x4bd053;
    pppppfStack_4d8 = (float *****)iVar20;
    __vbaHresultCheckObj();
  }
  uStack_4cc = 0x4bd05c;
  __vbaFreeObj();
  ppiStack_4d0 = apiStack_3d0;
  uStack_4cc = 0;
  pppppfStack_4d4 = (float *****)0x4bd06b;
  __vbaObjSetAddref();
  if (DAT_0050b420 == (float ******)0x0) {
    pppppfStack_4d4 = (float *****)&DAT_0050b420;
    pppppfStack_4d8 = (float *****)&DAT_00408c88;
    pppppfStack_4dc = (float *****)0x4bd084;
    __vbaNew2();
  }
  pppppfStack_4d4 = (float *****)&pppppfStack_31c;
  pppppfStack_4d8 = (float *****)DAT_0050b420;
  pppppfStack_3a8 = (float *****)DAT_0050b420;
  pppppfStack_4dc = (float *****)0x4bd09c;
  iStack_4e8 = (*(code *)(*DAT_0050b420)[0x92])();
  if (iStack_4e8 < 0) {
    pppppfStack_4dc = (float *****)0x248;
    puStack_4e0 = &DAT_0040b430;
    pppppfStack_4e4 = pppppfStack_3a8;
    uStack_4ec = 0x4bd0ba;
    __vbaHresultCheckObj();
  }
  uStack_4ec = 2;
  iStack_4e8 = 2;
  pppppfStack_4e4 = pppppfStack_340;
  puStack_4e0 = (undefined *)0xa;
  pppppfStack_4f0 = pppppfStack_31c;
  pppppfStack_4dc = pppppfStack_338;
  puStack_4f4 = (undefined4 *)0x4bd0dc;
  __vbaLateIdSt();
  puStack_4f4 = (undefined4 *)0x4bd0e5;
  __vbaFreeObj();
  if (DAT_0050b420 == (float ******)0x0) {
    puStack_4f4 = &DAT_0050b420;
    pppppfStack_4f8 = (float *****)&DAT_00408c88;
    pppppfStack_4fc = (float *****)0x4bd0fe;
    __vbaNew2();
  }
  puStack_4f4 = (undefined4 *)0x1;
  pppppfStack_4f8 = (float *****)DAT_0050b420;
  pppppfStack_3a8 = (float *****)DAT_0050b420;
  pppppfStack_4fc = (float *****)0x4bd114;
  ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x4b])();
  if ((int)ppppppfVar26 < 0) {
    pppppfStack_4fc = (float *****)0x12c;
    pppppfStack_500 = (float *****)&DAT_0040b430;
    pppppfStack_504 = pppppfStack_3a8;
    pppppfStack_50c = (float *****)0x4bd132;
    pppppfStack_508 = (float *****)ppppppfVar26;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float ******)0x0) {
    pppppfStack_4fc = (float *****)&DAT_0050b420;
    pppppfStack_500 = (float *****)&DAT_00408c88;
    pppppfStack_504 = (float *****)0x4bd14b;
    __vbaNew2();
  }
  pppppfStack_4fc = (float *****)&pppppfStack_39c;
  pppppfStack_500 = (float *****)DAT_0050b420;
  pppppfStack_3a8 = (float *****)DAT_0050b420;
  pppppfStack_504 = (float *****)0x4bd166;
  ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
  uVar29 = 0;
  if ((int)ppppppfVar26 < 0) {
    pppppfStack_504 = (float *****)0xe8;
    pppppfStack_508 = (float *****)&DAT_0040b430;
    pppppfStack_50c = pppppfStack_3a8;
    pppppfStack_514 = (float *****)0x4bd184;
    pppppfStack_510 = (float *****)ppppppfVar26;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float ******)0x0) {
    pppppfStack_504 = (float *****)&DAT_0050b420;
    pppppfStack_508 = (float *****)&DAT_00408c88;
    pppppfStack_50c = (float *****)0x4bd19d;
    __vbaNew2();
  }
  pppppfStack_504 = (float *****)DAT_0050b420;
  pppppfStack_3b0 = (float *****)DAT_0050b420;
  ppppppfVar26 = (float ******)pppppfStack_504;
  if ((uVar29 & 0xd) == 0) {
    pppppfStack_508 = (float *****)DAT_0050b420;
    pppppfStack_50c = (float *****)0x4bd1d8;
    pppppfStack_504 = (float *****)((float)pppppfStack_39c * (float)_DAT_00402308);
    fStack_3e4 = (float)pppppfStack_39c * (float)_DAT_00402308;
    ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3b])();
    if ((int)ppppppfVar26 < 0) {
      pppppfStack_50c = (float *****)0xec;
      pppppfStack_510 = (float *****)&DAT_0040b430;
      pppppfStack_514 = pppppfStack_3b0;
      pppppfStack_51c = (float *****)0x4bd1f6;
      pppppfStack_518 = (float *****)ppppppfVar26;
      __vbaHresultCheckObj();
    }
    if (DAT_0050c53c == (float ******)0x0) {
      pppppfStack_50c = (float *****)&DAT_0050c53c;
      pppppfStack_510 = (float *****)&DAT_0040b420;
      pppppfStack_514 = (float *****)0x4bd20f;
      __vbaNew2();
    }
    pppppfStack_50c = (float *****)&pppppfStack_31c;
    pppppfStack_510 = (float *****)DAT_0050c53c;
    pppppfStack_3a8 = (float *****)DAT_0050c53c;
    pppppfStack_514 = (float *****)0x4bd224;
    ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)ppppppfVar26 < 0) {
      pppppfStack_514 = (float *****)0x18;
      pppppfStack_518 = (float *****)&DAT_0040b410;
      pppppfStack_51c = pppppfStack_3a8;
      pppppfStack_524 = (float *****)0x4bd23f;
      pppppfStack_520 = (float *****)ppppppfVar26;
      __vbaHresultCheckObj();
    }
    pppppfStack_514 = (float *****)&pppppfStack_39c;
    pppppfStack_518 = pppppfStack_31c;
    pppppfStack_3b0 = pppppfStack_31c;
    pppppfStack_51c = (float *****)0x4bd258;
    ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
    if ((int)ppppppfVar26 < 0) {
      pppppfStack_51c = (float *****)0x98;
      pppppfStack_520 = (float *****)&DAT_0040bb5c;
      pppppfStack_524 = pppppfStack_3b0;
      pppppfStack_52c = (float *****)0x4bd276;
      pppppfStack_528 = (float *****)ppppppfVar26;
      __vbaHresultCheckObj();
    }
    if (DAT_0050b420 == (float ******)0x0) {
      pppppfStack_51c = (float *****)&DAT_0050b420;
      pppppfStack_520 = (float *****)&DAT_00408c88;
      pppppfStack_524 = (float *****)0x4bd28f;
      __vbaNew2();
    }
    pppppfStack_51c = &ppppfStack_3a0;
    pppppfStack_520 = (float *****)0x4123fc;
    pppppfStack_524 = (float *****)DAT_0050b420;
    pppppfStack_3b8 = (float *****)DAT_0050b420;
    pppppfStack_528 = (float *****)0x4bd2af;
    ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0xb9])();
    uVar29 = 0;
    if ((int)ppppppfVar26 < 0) {
      pppppfStack_504 = (float *****)0x2e4;
      pppppfStack_508 = (float *****)&DAT_0040b430;
      pppppfStack_50c = pppppfStack_3b8;
      pppppfStack_514 = (float *****)0x4bd2cd;
      pppppfStack_510 = (float *****)ppppppfVar26;
      __vbaHresultCheckObj();
    }
    if (DAT_0050b420 == (float ******)0x0) {
      pppppfStack_504 = (float *****)&DAT_0050b420;
      pppppfStack_508 = (float *****)&DAT_00408c88;
      pppppfStack_50c = (float *****)0x4bd2e6;
      __vbaNew2();
    }
    pppppfStack_504 = (float *****)DAT_0050b420;
    pppppfStack_3c0 = (float *****)DAT_0050b420;
    ppppppfVar26 = (float ******)pppppfStack_504;
    if ((uVar29 & 0xd) == 0) {
      fVar1 = ((float)pppppfStack_39c - (float)ppppfStack_3a0) * (float)_DAT_00401268;
      if ((uVar29 & 0xd) == 0) {
        pppppfStack_508 = (float *****)DAT_0050b420;
        pppppfStack_50c = (float *****)0x4bd331;
        pppppfStack_504 = (float *****)fVar1;
        fStack_3e8 = fVar1;
        ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x39])();
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_50c = (float *****)0xe4;
          pppppfStack_510 = (float *****)&DAT_0040b430;
          pppppfStack_514 = pppppfStack_3c0;
          pppppfStack_51c = (float *****)0x4bd34f;
          pppppfStack_518 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        pppppfStack_50c = (float *****)0x4bd358;
        __vbaFreeObj();
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_50c = (float *****)&DAT_0050b420;
          pppppfStack_510 = (float *****)&DAT_00408c88;
          pppppfStack_514 = (float *****)0x4bd371;
          __vbaNew2();
        }
        pppppfStack_50c = (float *****)&PTR_DAT_00412aa4;
        pppppfStack_510 = (float *****)DAT_0050b420;
        pppppfStack_514 = (float *****)&DAT_0040bf08;
        pppppfStack_518 = (float *****)0x4bd388;
        __vbaPrintObj();
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_50c = (float *****)&DAT_0050b420;
          pppppfStack_510 = (float *****)&DAT_00408c88;
          pppppfStack_514 = (float *****)0x4bd3a4;
          __vbaNew2();
        }
        pppppfStack_50c = (float *****)0x44960000;
        pppppfStack_510 = (float *****)DAT_0050b420;
        pppppfStack_3a8 = (float *****)DAT_0050b420;
        pppppfStack_514 = (float *****)0x4bd3bd;
        ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x39])();
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_514 = (float *****)0xe4;
          pppppfStack_518 = (float *****)&DAT_0040b430;
          pppppfStack_51c = pppppfStack_3a8;
          pppppfStack_524 = (float *****)0x4bd3db;
          pppppfStack_520 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_514 = (float *****)&DAT_0050b420;
          pppppfStack_518 = (float *****)&DAT_00408c88;
          pppppfStack_51c = (float *****)0x4bd3f4;
          __vbaNew2();
        }
        pppppfStack_514 = (float *****)0x40f6d0;
        pppppfStack_518 = *(float ******)(DAT_0050b37c + 4);
        pppppfStack_51c = (float *****)0x4bd408;
        __vbaStrCat();
        pppppfStack_51c = (float *****)0x4bd413;
        pppppfStack_51c = (float *****)__vbaStrMove();
        pppppfStack_520 = (float *****)DAT_0050b420;
        pppppfStack_524 = (float *****)&DAT_0040bf08;
        pppppfStack_528 = (float *****)0x4bd426;
        __vbaPrintObj();
        pppppfStack_51c = (float *****)0x4bd432;
        __vbaFreeStr();
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_51c = (float *****)&DAT_0050b420;
          pppppfStack_520 = (float *****)&DAT_00408c88;
          pppppfStack_524 = (float *****)0x4bd44b;
          __vbaNew2();
        }
        pppppfStack_51c = (float *****)0x44960000;
        pppppfStack_520 = (float *****)DAT_0050b420;
        pppppfStack_3a8 = (float *****)DAT_0050b420;
        pppppfStack_524 = (float *****)0x4bd464;
        ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x39])();
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_524 = (float *****)0xe4;
          pppppfStack_528 = (float *****)&DAT_0040b430;
          pppppfStack_52c = pppppfStack_3a8;
          pppppfStack_534 = (float *****)0x4bd482;
          pppppfStack_530 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_524 = (float *****)&DAT_0050b420;
          pppppfStack_528 = (float *****)&DAT_00408c88;
          pppppfStack_52c = (float *****)0x4bd49b;
          __vbaNew2();
        }
        pppppfStack_524 = (float *****)&pppppfStack_39c;
        pppppfStack_528 = (float *****)DAT_0050b420;
        pppppfStack_3a8 = (float *****)DAT_0050b420;
        pppppfStack_52c = (float *****)0x4bd4b6;
        ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_52c = (float *****)0xe8;
          pppppfStack_530 = (float *****)&DAT_0040b430;
          pppppfStack_534 = pppppfStack_3a8;
          pppppfStack_53c = (float *****)0x4bd4d4;
          pppppfStack_538 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        if (DAT_0050c53c == (float ******)0x0) {
          pppppfStack_52c = (float *****)&DAT_0050c53c;
          pppppfStack_530 = (float *****)&DAT_0040b420;
          pppppfStack_534 = (float *****)0x4bd4ed;
          __vbaNew2();
        }
        pppppfStack_52c = (float *****)&pppppfStack_31c;
        pppppfStack_530 = (float *****)DAT_0050c53c;
        pppppfStack_3b0 = (float *****)DAT_0050c53c;
        pppppfStack_534 = (float *****)0x4bd502;
        ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_534 = (float *****)0x18;
          pppppfStack_538 = (float *****)&DAT_0040b410;
          pppppfStack_53c = pppppfStack_3b0;
          pppppfStack_544 = (float *****)0x4bd51d;
          pppppfStack_540 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        pppppfStack_534 = &ppppfStack_3a0;
        pppppfStack_538 = pppppfStack_31c;
        pppppfStack_3b8 = pppppfStack_31c;
        pppppfStack_53c = (float *****)0x4bd536;
        ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_53c = (float *****)0x98;
          pppppfStack_540 = (float *****)&DAT_0040bb5c;
          pppppfStack_544 = pppppfStack_3b8;
          pppppfStack_54c = (float *****)0x4bd554;
          pppppfStack_548 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_53c = (float *****)&DAT_0050b420;
          pppppfStack_540 = (float *****)&DAT_00408c88;
          pppppfStack_544 = (float *****)0x4bd56d;
          __vbaNew2();
        }
        pppppfStack_53c = (float *****)&pppppfStack_3a4;
        pppppfStack_540 = (float *****)DAT_0050b420;
        pppppfStack_3c0 = (float *****)DAT_0050b420;
        pppppfStack_544 = (float *****)0x4bd588;
        ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
        uVar29 = 0;
        if ((int)ppppppfVar26 < 0) {
          pppppfStack_4fc = (float *****)0xe8;
          pppppfStack_500 = (float *****)&DAT_0040b430;
          pppppfStack_504 = pppppfStack_3c0;
          pppppfStack_50c = (float *****)0x4bd5a6;
          pppppfStack_508 = (float *****)ppppppfVar26;
          __vbaHresultCheckObj();
        }
        if (DAT_0050b420 == (float ******)0x0) {
          pppppfStack_4fc = (float *****)&DAT_0050b420;
          pppppfStack_500 = (float *****)&DAT_00408c88;
          pppppfStack_504 = (float *****)0x4bd5bf;
          __vbaNew2();
        }
        pppppfStack_4fc = (float *****)0x0;
        pppppfStack_500 = pppppfStack_3a4;
        pppppfStack_504 = (float *****)DAT_0050b420;
        ppppppfVar26 = (float ******)pppppfStack_504;
        if ((uVar29 & 0xd) == 0) {
          pppppfStack_3c8 = (float *****)DAT_0050b420;
          pppppfStack_508 = pppppfStack_39c;
          pppppfStack_50c = (float *****)0x44960000;
          pppppfStack_510 = (float *****)0x4;
          pppppfStack_514 = (float *****)DAT_0050b420;
          pppppfStack_518 = (float *****)0x4bd605;
          pppppfStack_504 = (float *****)((float)ppppfStack_3a0 - _DAT_004020e0);
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0xb2])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_518 = (float *****)0x2c8;
            pppppfStack_51c = (float *****)&DAT_0040b430;
            pppppfStack_520 = pppppfStack_3c8;
            pppppfStack_528 = (float *****)0x4bd623;
            pppppfStack_524 = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          pppppfStack_518 = (float *****)0x4bd62c;
          __vbaFreeObj();
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_518 = (float *****)&DAT_0050b420;
            pppppfStack_51c = (float *****)&DAT_00408c88;
            pppppfStack_520 = (float *****)0x4bd645;
            __vbaNew2();
          }
          pppppfStack_518 = (float *****)&pppppfStack_31c;
          pppppfStack_51c = (float *****)DAT_0050b420;
          pppppfStack_3a8 = (float *****)DAT_0050b420;
          pppppfStack_520 = (float *****)0x4bd65d;
          pppppfStack_52c = (float *****)(*(code *)(*DAT_0050b420)[0x92])();
          if ((int)pppppfStack_52c < 0) {
            pppppfStack_520 = (float *****)0x248;
            pppppfStack_524 = (float *****)&DAT_0040b430;
            pppppfStack_528 = pppppfStack_3a8;
            pppppfStack_530 = (float *****)0x4bd67b;
            __vbaHresultCheckObj();
          }
          pppppfStack_530 = (float *****)0x2;
          pppppfStack_534 = pppppfStack_31c;
          pppppfStack_52c = (float *****)0x2;
          pppppfStack_528 = pppppfStack_340;
          pppppfStack_524 = (float *****)0x8;
          pppppfStack_520 = pppppfStack_338;
          pppppfStack_538 = (float *****)0x4bd69d;
          __vbaLateIdSt();
          pppppfStack_538 = (float *****)0x4bd6a6;
          __vbaFreeObj();
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_538 = (float *****)&DAT_0050b420;
            pppppfStack_53c = (float *****)&DAT_00408c88;
            pppppfStack_540 = (float *****)0x4bd6bf;
            __vbaNew2();
          }
          pppppfStack_538 = (float *****)0x44960000;
          pppppfStack_53c = (float *****)DAT_0050b420;
          pppppfStack_3a8 = (float *****)DAT_0050b420;
          pppppfStack_540 = (float *****)0x4bd6d8;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x39])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_540 = (float *****)0xe4;
            pppppfStack_544 = (float *****)&DAT_0040b430;
            pppppfStack_548 = pppppfStack_3a8;
            pppppfStack_550 = (float *****)0x4bd6f6;
            pppppfStack_54c = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_540 = (float *****)&DAT_0050b420;
            pppppfStack_544 = (float *****)&DAT_00408c88;
            pppppfStack_548 = (float *****)0x4bd70f;
            __vbaNew2();
          }
          pppppfStack_3b0 = (float *****)DAT_0050b420;
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_540 = (float *****)&DAT_0050b420;
            pppppfStack_544 = (float *****)&DAT_00408c88;
            pppppfStack_548 = (float *****)0x4bd72e;
            __vbaNew2();
          }
          pppppfStack_540 = (float *****)&pppppfStack_39c;
          pppppfStack_548 = (float *****)0x4bd749;
          pppppfStack_544 = (float *****)DAT_0050b420;
          pppppfStack_3a8 = (float *****)DAT_0050b420;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_548 = (float *****)0xe8;
            pppppfStack_54c = (float *****)&DAT_0040b430;
            pppppfStack_550 = pppppfStack_3a8;
            pppppfStack_558 = (float *****)0x4bd767;
            pppppfStack_554 = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          pppppfStack_548 = pppppfStack_39c;
          pppppfStack_54c = pppppfStack_3b0;
          pppppfStack_550 = (float *****)0x4bd77d;
          ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_3b0)[0x3b])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_550 = (float *****)0xec;
            pppppfStack_554 = (float *****)&DAT_0040b430;
            pppppfStack_558 = pppppfStack_3b0;
            pppppfStack_560 = (float *****)0x4bd79b;
            pppppfStack_55c = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_550 = (float *****)&DAT_0050b420;
            pppppfStack_554 = (float *****)&DAT_00408c88;
            pppppfStack_558 = (float *****)0x4bd7b4;
            __vbaNew2();
          }
          pppppfStack_550 = (float *****)0x412af4;
          pppppfStack_554 = (float *****)DAT_0050b420;
          pppppfStack_558 = (float *****)&DAT_0040bf08;
          pppppfStack_55c = (float *****)0x4bd7ca;
          __vbaPrintObj();
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_550 = (float *****)&DAT_0050b420;
            pppppfStack_554 = (float *****)&DAT_00408c88;
            pppppfStack_558 = (float *****)0x4bd7e6;
            __vbaNew2();
          }
          iStack_3ec = 0x640;
          pppppfStack_550 = (float *****)0x44c80000;
          pppppfStack_3a8 = (float *****)DAT_0050b420;
          pppppfStack_554 = (float *****)DAT_0050b420;
          pppppfStack_558 = (float *****)0x4bd81b;
          pppppfStack_3f0 = pppppfStack_550;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x39])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_558 = (float *****)0xe4;
            pppppfStack_55c = (float *****)&DAT_0040b430;
            pppppfStack_560 = pppppfStack_3a8;
            pppppfStack_568 = (float *****)0x4bd839;
            pppppfStack_564 = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_558 = (float *****)&DAT_0050b420;
            pppppfStack_55c = (float *****)&DAT_00408c88;
            pppppfStack_560 = (float *****)0x4bd852;
            __vbaNew2();
          }
          pppppfStack_558 = (float *****)0x412b3c;
          pppppfStack_55c = (float *****)DAT_0050b420;
          pppppfStack_560 = (float *****)&DAT_0040bf08;
          pppppfStack_564 = (float *****)0x4bd868;
          __vbaPrintObj();
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_558 = (float *****)&DAT_0050b420;
            pppppfStack_55c = (float *****)&DAT_00408c88;
            pppppfStack_560 = (float *****)0x4bd884;
            __vbaNew2();
          }
          pppppfStack_558 = (float *****)(float)iStack_3ec;
          pppppfStack_3a8 = (float *****)DAT_0050b420;
          pppppfStack_55c = (float *****)DAT_0050b420;
          pppppfStack_560 = (float *****)0x4bd8ab;
          fStack_3f4 = (float)pppppfStack_558;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x39])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_560 = (float *****)0xe4;
            pppppfStack_564 = (float *****)&DAT_0040b430;
            pppppfStack_568 = pppppfStack_3a8;
            pppppfStack_570 = (float *****)0x4bd8c9;
            pppppfStack_56c = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_560 = (float *****)&DAT_0050b420;
            pppppfStack_564 = (float *****)&DAT_00408c88;
            pppppfStack_568 = (float *****)0x4bd8e2;
            __vbaNew2();
          }
          pppppfStack_560 = (float *****)0x412c0c;
          pppppfStack_564 = (float *****)DAT_0050b420;
          pppppfStack_568 = (float *****)&DAT_0040bf08;
          pppppfStack_56c = (float *****)0x4bd8f9;
          __vbaPrintObj();
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_560 = (float *****)&DAT_0050b420;
            pppppfStack_564 = (float *****)&DAT_00408c88;
            pppppfStack_568 = (float *****)0x4bd915;
            __vbaNew2();
          }
          pppppfStack_560 = (float *****)&pppppfStack_39c;
          pppppfStack_564 = (float *****)DAT_0050b420;
          pppppfStack_3a8 = (float *****)DAT_0050b420;
          pppppfStack_568 = (float *****)0x4bd930;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_568 = (float *****)0xe8;
            pppppfStack_56c = (float *****)&DAT_0040b430;
            pppppfStack_570 = pppppfStack_3a8;
            pppppfStack_578 = (float *****)0x4bd94e;
            pppppfStack_574 = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050c53c == (float ******)0x0) {
            pppppfStack_568 = (float *****)&DAT_0050c53c;
            pppppfStack_56c = (float *****)&DAT_0040b420;
            pppppfStack_570 = (float *****)0x4bd967;
            __vbaNew2();
          }
          pppppfStack_568 = (float *****)&pppppfStack_31c;
          pppppfStack_56c = (float *****)DAT_0050c53c;
          pppppfStack_3b0 = (float *****)DAT_0050c53c;
          pppppfStack_570 = (float *****)0x4bd97c;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_570 = (float *****)0x18;
            pppppfStack_574 = (float *****)&DAT_0040b410;
            pppppfStack_578 = pppppfStack_3b0;
            pppppfStack_580 = (float *****)0x4bd997;
            pppppfStack_57c = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          pppppfStack_570 = &ppppfStack_3a0;
          pppppfStack_574 = pppppfStack_31c;
          pppppfStack_3b8 = pppppfStack_31c;
          pppppfStack_578 = (float *****)0x4bd9b0;
          ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_578 = (float *****)0x98;
            pppppfStack_57c = (float *****)&DAT_0040bb5c;
            pppppfStack_580 = pppppfStack_3b8;
            pwStack_588 = 
            L"₡傴蔀痀栐될P表䂌＀鰕䀑ꄀ될P趍ｔ\xffff偑ႋ薉Ｘ\xffff鋿è";
            pppppfStack_584 = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_578 = (float *****)&DAT_0050b420;
            pppppfStack_57c = (float *****)&DAT_00408c88;
            pppppfStack_580 = (float *****)0x4bd9e7;
            __vbaNew2();
          }
          pppppfStack_578 = (float *****)&pppppfStack_3a4;
          pppppfStack_57c = (float *****)DAT_0050b420;
          pppppfStack_3c0 = (float *****)DAT_0050b420;
          pppppfStack_580 = (float *****)0x4bda02;
          ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
          uVar29 = 0;
          if ((int)ppppppfVar26 < 0) {
            pppppfStack_4fc = (float *****)0xe8;
            pppppfStack_500 = (float *****)&DAT_0040b430;
            pppppfStack_504 = pppppfStack_3c0;
            pppppfStack_50c = (float *****)0x4bda20;
            pppppfStack_508 = (float *****)ppppppfVar26;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b420 == (float ******)0x0) {
            pppppfStack_4fc = (float *****)&DAT_0050b420;
            pppppfStack_500 = (float *****)&DAT_00408c88;
            pppppfStack_504 = (float *****)0x4bda39;
            __vbaNew2();
          }
          pppppfStack_4fc = (float *****)0x0;
          pppppfStack_500 = pppppfStack_3a4;
          pppppfStack_504 = (float *****)DAT_0050b420;
          ppppppfVar26 = (float ******)pppppfStack_504;
          if ((uVar29 & 0xd) == 0) {
            pppppfStack_3c8 = (float *****)DAT_0050b420;
            pppppfStack_508 = pppppfStack_39c;
            pppppfStack_50c = (float *****)0x44960000;
            pppppfStack_510 = (float *****)0x4;
            pppppfStack_514 = (float *****)DAT_0050b420;
            pppppfStack_518 = (float *****)0x4bda7f;
            pppppfStack_504 = (float *****)((float)ppppfStack_3a0 - _DAT_004020e0);
            ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0xb2])();
            if ((int)ppppppfVar26 < 0) {
              pppppfStack_518 = (float *****)0x2c8;
              pppppfStack_51c = (float *****)&DAT_0040b430;
              pppppfStack_520 = pppppfStack_3c8;
              pppppfStack_528 = (float *****)0x4bda9d;
              pppppfStack_524 = (float *****)ppppppfVar26;
              __vbaHresultCheckObj();
            }
            pppppfStack_518 = (float *****)0x4bdaa6;
            __vbaFreeObj();
            if (DAT_0050b420 == (float ******)0x0) {
              pppppfStack_518 = (float *****)&DAT_0050b420;
              pppppfStack_51c = (float *****)&DAT_00408c88;
              pppppfStack_520 = (float *****)0x4bdabf;
              __vbaNew2();
            }
            pppppfStack_518 = (float *****)DAT_0050b420;
            pppppfStack_51c = (float *****)0x4bdacd;
            pppppfStack_51c = (float *****)(*(code *)(*DAT_0050b420)[0xea])();
            pppppfStack_520 = (float *****)&pppppfStack_3d4;
            pppppfStack_524 = (float *****)0x4bdadb;
            __vbaObjSet();
            if (DAT_0050c53c == (float ******)0x0) {
              pppppfStack_524 = (float *****)&DAT_0050c53c;
              pppppfStack_528 = (float *****)&DAT_0040b420;
              pppppfStack_52c = (float *****)0x4bdaf4;
              __vbaNew2();
            }
            pppppfStack_524 = (float *****)&pppppfStack_31c;
            pppppfStack_528 = (float *****)DAT_0050c53c;
            pppppfStack_3a8 = (float *****)DAT_0050c53c;
            pppppfStack_52c = (float *****)0x4bdb09;
            ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)ppppppfVar26 < 0) {
              pppppfStack_52c = (float *****)0x18;
              pppppfStack_530 = (float *****)&DAT_0040b410;
              pppppfStack_534 = pppppfStack_3a8;
              pppppfStack_53c = (float *****)0x4bdb24;
              pppppfStack_538 = (float *****)ppppppfVar26;
              __vbaHresultCheckObj();
            }
            pppppfStack_52c = (float *****)&pppppfStack_39c;
            pppppfStack_530 = pppppfStack_31c;
            pppppfStack_3b0 = pppppfStack_31c;
            pppppfStack_534 = (float *****)0x4bdb3a;
            ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x14])();
            uVar29 = 0;
            if ((int)ppppppfVar26 < 0) {
              pppppfStack_534 = (float *****)0x50;
              pppppfStack_538 = (float *****)&DAT_0040bb5c;
              pppppfStack_53c = pppppfStack_3b0;
              pppppfStack_544 = (float *****)0x4bdb55;
              pppppfStack_540 = (float *****)ppppppfVar26;
              __vbaHresultCheckObj();
            }
            if (DAT_0050b420 == (float ******)0x0) {
              pppppfStack_534 = (float *****)&DAT_0050b420;
              pppppfStack_538 = (float *****)&DAT_00408c88;
              pppppfStack_53c = (float *****)0x4bdb6e;
              __vbaNew2();
            }
            pppppfStack_534 = (float *****)DAT_0050b420;
            pppppfStack_538 = (float *****)0x4bdb7c;
            pppppfStack_538 = (float *****)(*(code *)(*DAT_0050b420)[0xdf])();
            pppppfStack_53c = (float *****)&pppppfStack_320;
            pppppfStack_540 = (float *****)0x4bdb87;
            pppppfStack_3b8 = (float *****)__vbaObjSet();
            pppppfStack_504 = (float *****)((float)pppppfStack_39c * (float)_DAT_00401760);
            ppppppfVar26 = (float ******)pppppfStack_3b8;
            if ((uVar29 & 0xd) == 0) {
              pppppfStack_50c = (float *****)0x4bdbbb;
              pppppfStack_508 = pppppfStack_3b8;
              fStack_3f8 = (float)pppppfStack_504;
              pppppfStack_518 = (float *****)(*(code *)(*pppppfStack_3b8)[0x1f])();
              if ((int)pppppfStack_518 < 0) {
                pppppfStack_50c = (float *****)0x7c;
                pppppfStack_510 = (float *****)&DAT_0040c3dc;
                pppppfStack_514 = pppppfStack_3b8;
                pppppfStack_51c = (float *****)0x4bdbd6;
                __vbaHresultCheckObj();
              }
              pppppfStack_50c = (float *****)&pppppfStack_320;
              pppppfStack_510 = (float *****)&pppppfStack_31c;
              pppppfStack_514 = (float *****)0x2;
              pppppfStack_518 = (float *****)0x4bdbe6;
              __vbaFreeObjList();
              if (DAT_0050c53c == (float ******)0x0) {
                pppppfStack_50c = (float *****)&DAT_0050c53c;
                pppppfStack_510 = (float *****)&DAT_0040b420;
                pppppfStack_514 = (float *****)0x4bdc02;
                __vbaNew2();
              }
              pppppfStack_50c = (float *****)&pppppfStack_31c;
              pppppfStack_510 = (float *****)DAT_0050c53c;
              pppppfStack_3a8 = (float *****)DAT_0050c53c;
              pppppfStack_514 = (float *****)0x4bdc17;
              ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
              if ((int)ppppppfVar26 < 0) {
                pppppfStack_514 = (float *****)0x18;
                pppppfStack_518 = (float *****)&DAT_0040b410;
                pppppfStack_51c = pppppfStack_3a8;
                pppppfStack_524 = (float *****)0x4bdc32;
                pppppfStack_520 = (float *****)ppppppfVar26;
                __vbaHresultCheckObj();
              }
              pppppfStack_514 = (float *****)&pppppfStack_39c;
              pppppfStack_518 = pppppfStack_31c;
              pppppfStack_3b0 = pppppfStack_31c;
              pppppfStack_51c = (float *****)0x4bdc4b;
              ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
              if ((int)ppppppfVar26 < 0) {
                pppppfStack_51c = (float *****)0x98;
                pppppfStack_520 = (float *****)&DAT_0040bb5c;
                pppppfStack_524 = pppppfStack_3b0;
                pppppfStack_52c = (float *****)0x4bdc69;
                pppppfStack_528 = (float *****)ppppppfVar26;
                __vbaHresultCheckObj();
              }
              if (DAT_0050b420 == (float ******)0x0) {
                pppppfStack_51c = (float *****)&DAT_0050b420;
                pppppfStack_520 = (float *****)&DAT_00408c88;
                pppppfStack_524 = (float *****)0x4bdc82;
                __vbaNew2();
              }
              pppppfStack_51c = (float *****)DAT_0050b420;
              pppppfStack_520 = (float *****)0x4bdc90;
              pppppfStack_520 = (float *****)(*(code *)(*DAT_0050b420)[0xdf])();
              pppppfStack_524 = (float *****)&pppppfStack_320;
              pppppfStack_528 = (float *****)0x4bdc9b;
              pppppfStack_52c = (float *****)__vbaObjSet();
              pppppfStack_528 = &ppppfStack_3a0;
              pppppfStack_530 = (float *****)0x4bdcb1;
              pppppfStack_3b8 = pppppfStack_52c;
              ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_52c)[0x20])();
              uVar29 = 0;
              if ((int)ppppppfVar26 < 0) {
                pppppfStack_530 = (float *****)0x80;
                pppppfStack_534 = (float *****)&DAT_0040c3dc;
                pppppfStack_538 = pppppfStack_3b8;
                pppppfStack_540 = (float *****)0x4bdccf;
                pppppfStack_53c = (float *****)ppppppfVar26;
                __vbaHresultCheckObj();
              }
              if (DAT_0050b420 == (float ******)0x0) {
                pppppfStack_530 = (float *****)&DAT_0050b420;
                pppppfStack_534 = (float *****)&DAT_00408c88;
                pppppfStack_538 = (float *****)0x4bdce8;
                __vbaNew2();
              }
              pppppfStack_530 = (float *****)DAT_0050b420;
              pppppfStack_534 = (float *****)0x4bdcf6;
              pppppfStack_534 = (float *****)(*(code *)(*DAT_0050b420)[0xdf])();
              pppppfStack_538 = (float *****)&pppppfStack_324;
              pppppfStack_53c = (float *****)0x4bdd01;
              pppppfStack_3c0 = (float *****)__vbaObjSet();
              ppppppfVar26 = (float ******)pppppfStack_3c0;
              if ((uVar29 & 0xd) == 0) {
                pppppfStack_504 =
                     (float *****)
                     (((float)pppppfStack_39c - (float)ppppfStack_3a0) * (float)_DAT_00401268);
                if ((uVar29 & 0xd) == 0) {
                  pppppfStack_50c = (float *****)0x4bdd45;
                  pppppfStack_508 = pppppfStack_3c0;
                  pppppfStack_3fc = pppppfStack_504;
                  pppppfStack_518 = (float *****)(*(code *)(*pppppfStack_3c0)[0x1d])();
                  if ((int)pppppfStack_518 < 0) {
                    pppppfStack_50c = (float *****)0x74;
                    pppppfStack_510 = (float *****)&DAT_0040c3dc;
                    pppppfStack_514 = pppppfStack_3c0;
                    pppppfStack_51c = (float *****)0x4bdd60;
                    __vbaHresultCheckObj();
                  }
                  pppppfStack_50c = (float *****)&pppppfStack_324;
                  pppppfStack_510 = (float *****)&pppppfStack_320;
                  pppppfStack_514 = (float *****)&pppppfStack_31c;
                  pppppfStack_518 = (float *****)0x3;
                  pppppfStack_51c = (float *****)0x4bdd74;
                  __vbaFreeObjList();
                  pppppfStack_51c = (float *****)0x5;
                  pppppfStack_518 = (float *****)0x3;
                  pppppfStack_514 = pppppfStack_340;
                  pppppfStack_510 = (float *****)&DAT_00000001;
                  pppppfStack_520 = pppppfStack_3d4;
                  pppppfStack_50c = pppppfStack_338;
                  pppppfStack_524 = (float *****)0x4bdd96;
                  __vbaLateIdSt();
                  pppppfStack_534 = (float *****)0x4;
                  pppppfStack_530 = (float *****)0x3;
                  pppppfStack_52c = pppppfStack_340;
                  pppppfStack_528 = (float *****)&DAT_00000001;
                  pppppfStack_538 = pppppfStack_3d4;
                  pppppfStack_524 = pppppfStack_338;
                  pppppfStack_53c = (float *****)0x4bddbb;
                  __vbaLateIdSt();
                  pppppfStack_54c = (float *****)0x22;
                  pppppfStack_548 = (float *****)0x3;
                  pppppfStack_544 = pppppfStack_340;
                  pppppfStack_540 = (float *****)0x0;
                  pppppfStack_550 = pppppfStack_3d4;
                  pppppfStack_53c = pppppfStack_338;
                  pppppfStack_554 = (float *****)0x4bdddd;
                  __vbaLateIdSt();
                  pppppfStack_564 = (float *****)0xfffffe0b;
                  pppppfStack_560 = (float *****)0x3;
                  pppppfStack_55c = pppppfStack_340;
                  pppppfStack_558 = (float *****)0xff0000;
                  pppppfStack_568 = pppppfStack_3d4;
                  pppppfStack_554 = pppppfStack_338;
                  pppppfStack_56c = (float *****)0x4bde05;
                  __vbaLateIdSt();
                  pppppfStack_57c = (float *****)0xfffffdff;
                  pppppfStack_578 = (float *****)0x3;
                  pppppfStack_574 = pppppfStack_340;
                  pppppfStack_570 = (float *****)0xffffff;
                  pppppfStack_580 = pppppfStack_3d4;
                  pppppfStack_56c = pppppfStack_338;
                  pppppfStack_584 = (float *****)0x4bde2d;
                  __vbaLateIdSt();
                  uStack_594 = 0;
                  pppppfStack_598 = (float *****)&DAT_0040eb6c;
                  uStack_590 = 8;
                  pppppfStack_59c = (float *****)0x0;
                  pppppfStack_5a0 = (float *****)0xfffffe00;
                  pppppfStack_58c = pppppfStack_340;
                  pwStack_588 = L"arial";
                  pppppfStack_5a4 = pppppfStack_3d4;
                  pppppfStack_584 = pppppfStack_338;
                  pppppfStack_5a8 = appppfStack_334;
                  pppppfStack_5ac = (float *****)0x4bde66;
                  pppppfStack_59c = (float *****)__vbaLateIdCallLd();
                  pppppfStack_5a0 = (float *****)0x4bde70;
                  pppppfStack_5a0 = (float *****)__vbaCastObjVar();
                  pppppfStack_5a4 = (float *****)&pppppfStack_31c;
                  pppppfStack_5a8 = (float *****)0x4bde7b;
                  pppppfStack_5a8 = (float *****)__vbaObjSet();
                  pppppfStack_5ac = (float *****)0x4bde7e;
                  __vbaLateIdSt();
                  pppppfStack_5ac = (float *****)0x4bde87;
                  __vbaFreeObj();
                  pppppfStack_5ac = (float *****)0x4bde90;
                  __vbaFreeVar();
                  pppppfStack_5bc = (float *****)0x2;
                  pppppfStack_5c0 = (float *****)&DAT_0040eb6c;
                  pppppfStack_5b8 = (float *****)0x2;
                  ppppfStack_5c4 = (float ****)0x0;
                  pppppfStack_5c8 = (float *****)0xfffffe00;
                  ppppfStack_5d0 = (float ****)appppfStack_334;
                  pppppfStack_5b4 = pppppfStack_340;
                  pppppfStack_5b0 = (float *****)0x9;
                  pppppfStack_5cc = pppppfStack_3d4;
                  pppppfStack_5ac = pppppfStack_338;
                  pppppfStack_5d4 = (float *****)0x4bdec8;
                  ppppfStack_5c4 = (float ****)__vbaLateIdCallLd();
                  pppppfStack_5c8 = (float *****)0x4bded2;
                  pppppfStack_5c8 = (float *****)__vbaCastObjVar();
                  pppppfStack_5cc = (float *****)&pppppfStack_31c;
                  ppppfStack_5d0 = (float ****)0x4bdedd;
                  ppppfStack_5d0 = (float ****)__vbaObjSet();
                  pppppfStack_5d4 = (float *****)0x4bdee0;
                  __vbaLateIdSt();
                  pppppfStack_5d4 = (float *****)0x4bdee9;
                  __vbaFreeObj();
                  pppppfStack_5d4 = (float *****)0x4bdef2;
                  __vbaFreeVar();
                  ppppfStack_5e4 = (float ****)0x3;
                  puStack_5e8 = &DAT_0040eb6c;
                  pppppfStack_5e0 = (float *****)0xb;
                  uStack_5ec = 0;
                  uStack_5f0 = 0xfffffe00;
                  ppppfStack_5f8 = (float ****)appppfStack_334;
                  pppppfStack_5dc = pppppfStack_340;
                  pppppfStack_5d8 = (float *****)0xffffffff;
                  pppppfStack_5f4 = pppppfStack_3d4;
                  pppppfStack_5d4 = pppppfStack_338;
                  pppppfStack_5fc = (float *****)0x4bdf29;
                  uStack_5ec = __vbaLateIdCallLd();
                  uStack_5f0 = 0x4bdf33;
                  uStack_5f0 = __vbaCastObjVar();
                  pppppfStack_5f4 = (float *****)&pppppfStack_31c;
                  ppppfStack_5f8 = (float ****)0x4bdf3e;
                  ppppfStack_5f8 = (float ****)__vbaObjSet();
                  pppppfStack_5fc = (float *****)0x4bdf41;
                  __vbaLateIdSt();
                  pppppfStack_5fc = (float *****)0x4bdf4a;
                  __vbaFreeObj();
                  pppppfStack_5fc = (float *****)0x4bdf53;
                  __vbaFreeVar();
                  if (DAT_0050b420 == (float ******)0x0) {
                    pppppfStack_5fc = (float *****)&DAT_0050b420;
                    pppppfStack_600 = (float *****)&DAT_00408c88;
                    uStack_604 = 0x4bdf6c;
                    __vbaNew2();
                  }
                  pppppfStack_5fc = (float *****)&pppppfStack_39c;
                  pppppfStack_600 = (float *****)DAT_0050b420;
                  pppppfStack_3a8 = (float *****)DAT_0050b420;
                  uStack_604 = 0x4bdf87;
                  ppppppfVar26 = (float ******)(*(code *)(*DAT_0050b420)[0x3a])();
                  uVar29 = 0;
                  if ((int)ppppppfVar26 < 0) {
                    pppppfStack_508 = (float *****)0xe8;
                    pppppfStack_50c = (float *****)&DAT_0040b430;
                    pppppfStack_510 = pppppfStack_3a8;
                    pppppfStack_518 = (float *****)0x4bdfa5;
                    pppppfStack_514 = (float *****)ppppppfVar26;
                    __vbaHresultCheckObj();
                  }
                  pppppfStack_33c = (float *****)((float)pppppfStack_39c * (float)_DAT_004013e8);
                  ppppppfVar26 = (float ******)pppppfStack_504;
                  if ((uVar29 & 0xd) == 0) {
                    pppppfStack_518 = (float *****)0x80010004;
                    pppppfStack_51c = pppppfStack_3d4;
                    pppppfStack_514 = (float *****)0x4;
                    pppppfStack_510 = pppppfStack_340;
                    pppppfStack_508 = pppppfStack_338;
                    pppppfStack_520 = (float *****)0x4bdfe4;
                    pppppfStack_50c = pppppfStack_33c;
                    __vbaLateIdSt();
                    if (DAT_0050c53c == (float ******)0x0) {
                      pppppfStack_520 = (float *****)&DAT_0050c53c;
                      pppppfStack_524 = (float *****)&DAT_0040b420;
                      pppppfStack_528 = (float *****)0x4bdffd;
                      __vbaNew2();
                    }
                    pppppfStack_520 = (float *****)&pppppfStack_31c;
                    pppppfStack_524 = (float *****)DAT_0050c53c;
                    pppppfStack_3a8 = (float *****)DAT_0050c53c;
                    pppppfStack_528 = (float *****)0x4be012;
                    ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
                    if ((int)ppppppfVar26 < 0) {
                      pppppfStack_528 = (float *****)0x18;
                      pppppfStack_52c = (float *****)&DAT_0040b410;
                      pppppfStack_530 = pppppfStack_3a8;
                      pppppfStack_538 = (float *****)0x4be02d;
                      pppppfStack_534 = (float *****)ppppppfVar26;
                      __vbaHresultCheckObj();
                    }
                    pppppfStack_528 = (float *****)&pppppfStack_39c;
                    pppppfStack_52c = pppppfStack_31c;
                    pppppfStack_3b0 = pppppfStack_31c;
                    pppppfStack_530 = (float *****)0x4be046;
                    ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
                    uVar29 = 0;
                    if ((int)ppppppfVar26 < 0) {
                      pppppfStack_508 = (float *****)0x98;
                      pppppfStack_50c = (float *****)&DAT_0040bb5c;
                      pppppfStack_510 = pppppfStack_3b0;
                      pppppfStack_518 = (float *****)0x4be064;
                      pppppfStack_514 = (float *****)ppppppfVar26;
                      __vbaHresultCheckObj();
                    }
                    pppppfStack_33c = (float *****)((float)pppppfStack_39c * (float)_DAT_00401370);
                    ppppppfVar26 = (float ******)pppppfStack_504;
                    if ((uVar29 & 0xd) == 0) {
                      pppppfStack_518 = (float *****)0x80010005;
                      pppppfStack_51c = pppppfStack_3d4;
                      pppppfStack_514 = (float *****)0x4;
                      pppppfStack_510 = pppppfStack_340;
                      pppppfStack_508 = pppppfStack_338;
                      pppppfStack_520 = (float *****)0x4be0a3;
                      pppppfStack_50c = pppppfStack_33c;
                      __vbaLateIdSt();
                      pppppfStack_520 = (float *****)0x4be0ac;
                      __vbaFreeObj();
                      if (DAT_0050c53c == (float ******)0x0) {
                        pppppfStack_520 = (float *****)&DAT_0050c53c;
                        pppppfStack_524 = (float *****)&DAT_0040b420;
                        pppppfStack_528 = (float *****)0x4be0c5;
                        __vbaNew2();
                      }
                      pppppfStack_520 = (float *****)&pppppfStack_31c;
                      pppppfStack_524 = (float *****)DAT_0050c53c;
                      pppppfStack_3a8 = (float *****)DAT_0050c53c;
                      pppppfStack_528 = (float *****)0x4be0da;
                      ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
                      if ((int)ppppppfVar26 < 0) {
                        pppppfStack_528 = (float *****)0x18;
                        pppppfStack_52c = (float *****)&DAT_0040b410;
                        pppppfStack_530 = pppppfStack_3a8;
                        pppppfStack_538 = (float *****)0x4be0f5;
                        pppppfStack_534 = (float *****)ppppppfVar26;
                        __vbaHresultCheckObj();
                      }
                      pppppfStack_528 = (float *****)&pppppfStack_39c;
                      pppppfStack_52c = pppppfStack_31c;
                      pppppfStack_3b0 = pppppfStack_31c;
                      pppppfStack_530 = (float *****)0x4be10e;
                      ppppppfVar26 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
                      uVar29 = 0;
                      if ((int)ppppppfVar26 < 0) {
                        pppppfStack_508 = (float *****)0x98;
                        pppppfStack_50c = (float *****)&DAT_0040bb5c;
                        pppppfStack_510 = pppppfStack_3b0;
                        pppppfStack_518 = (float *****)0x4be12c;
                        pppppfStack_514 = (float *****)ppppppfVar26;
                        __vbaHresultCheckObj();
                      }
                      pppppfStack_33c = (float *****)((float)pppppfStack_39c * (float)_DAT_00401d20)
                      ;
                      ppppppfVar26 = (float ******)pppppfStack_504;
                      if ((uVar29 & 0xd) == 0) {
                        pppppfStack_518 = (float *****)0x80010003;
                        pppppfStack_51c = pppppfStack_3d4;
                        pppppfStack_514 = (float *****)0x4;
                        pppppfStack_510 = pppppfStack_340;
                        pppppfStack_508 = pppppfStack_338;
                        pppppfStack_520 = (float *****)0x4be16b;
                        pppppfStack_50c = pppppfStack_33c;
                        __vbaLateIdSt();
                        pppppfStack_520 = (float *****)0x4be174;
                        __vbaFreeObj();
                        pppppfStack_520 = (float *****)0x4be179;
                        iStack_400 = FUN_0042b130();
                        pppppfStack_524 = (float *****)(float)iStack_400;
                        pppppfStack_530 = (float *****)0x80010006;
                        pppppfStack_52c = (float *****)0x4;
                        pppppfStack_534 = pppppfStack_3d4;
                        pppppfStack_528 = pppppfStack_340;
                        pppppfStack_520 = pppppfStack_338;
                        pppppfStack_538 = (float *****)0x4be1ae;
                        pppppfStack_33c = pppppfStack_524;
                        __vbaLateIdSt();
                        pppppfStack_538 = (float *****)0x0;
                        pppppfStack_53c = (float *****)0x80010005;
                        pppppfStack_544 = appppfStack_334;
                        pppppfStack_540 = pppppfStack_3d4;
                        pppppfStack_548 = (float *****)0x4be1c6;
                        pppppfStack_538 = (float *****)__vbaLateIdCallLd();
                        pppppfStack_53c = (float *****)0x4be1d0;
                        __vbaR4Var();
                        pppppfStack_53c = (float *****)0x4be1d6;
                        pppppfStack_550 = (float *****)__vbaFpI4();
                        pppppfStack_548 = (float *****)0x3;
                        pppppfStack_544 = pppppfStack_340;
                        pppppfStack_540 = (float *****)0x0;
                        pppppfStack_53c = pppppfStack_338;
                        pppppfStack_55c = (float *****)0x1;
                        pppppfStack_560 = (float *****)0x39;
                        pppppfStack_558 = (float *****)0x3;
                        pppppfStack_554 = pppppfStack_360;
                        pppppfStack_564 = pppppfStack_3d4;
                        pppppfStack_54c = pppppfStack_358;
                        pppppfStack_568 = (float *****)0x4be219;
                        __vbaLateIdCallSt();
                        pppppfStack_53c = (float *****)0x4be225;
                        __vbaFreeVar();
                        pppppfStack_548 = (float *****)0x3;
                        pppppfStack_544 = pppppfStack_340;
                        pppppfStack_540 = (float *****)0x0;
                        pppppfStack_53c = pppppfStack_338;
                        pppppfStack_55c = (float *****)0x1;
                        pppppfStack_558 = (float *****)0x2;
                        pppppfStack_560 = (float *****)0x38;
                        pppppfStack_554 = pppppfStack_360;
                        pppppfStack_550 = (float *****)0x1;
                        pppppfStack_54c = pppppfStack_358;
                        pppppfStack_564 = pppppfStack_3d4;
                        pppppfStack_568 = (float *****)0x4be26d;
                        __vbaLateIdCallSt();
                        _DAT_0050b14c = 0.0;
                        pppppfStack_548 = (float *****)0x3;
                        pppppfStack_54c = (float *****)0xa;
                        pppppfStack_544 = pppppfStack_340;
                        pppppfStack_540 = (float *****)0x0;
                        pppppfStack_550 = pppppfStack_3d4;
                        pppppfStack_53c = pppppfStack_338;
                        pppppfStack_554 = (float *****)0x4be299;
                        __vbaLateIdSt();
                        pppppfStack_564 = (float *****)0xb;
                        pppppfStack_560 = (float *****)0x3;
                        pppppfStack_55c = pppppfStack_340;
                        pppppfStack_558 = (float *****)0x0;
                        pppppfStack_568 = pppppfStack_3d4;
                        pppppfStack_554 = pppppfStack_338;
                        pppppfStack_56c = (float *****)0x4be2bb;
                        __vbaLateIdSt();
                        pppppfStack_57c = (float *****)0x26;
                        pppppfStack_578 = (float *****)0x3;
                        pppppfStack_574 = pppppfStack_340;
                        pppppfStack_570 = (float *****)0xffff00;
                        pppppfStack_580 = pppppfStack_3d4;
                        pppppfStack_56c = pppppfStack_338;
                        pppppfStack_584 = (float *****)0x4be2e0;
                        __vbaLateIdSt();
                        uStack_594 = 0x27;
                        uStack_590 = 3;
                        pppppfStack_58c = pppppfStack_340;
                        pwStack_588 = (wchar_t *)0xff0000;
                        pppppfStack_598 = pppppfStack_3d4;
                        pppppfStack_584 = pppppfStack_338;
                        pppppfStack_59c = (float *****)0x4be305;
                        __vbaLateIdSt();
                        uStack_35c = 0;
                        pppppfStack_5a8 = (float *****)0x3;
                        uStack_364 = 3;
                        pppppfStack_5a4 = pppppfStack_340;
                        pppppfStack_5a0 = (float *****)0x0;
                        pppppfStack_59c = pppppfStack_338;
                        pppppfStack_5b8 = (float *****)0x3;
                        pppppfStack_5b4 = pppppfStack_360;
                        pppppfStack_5b0 = (float *****)0x0;
                        pppppfStack_5ac = pppppfStack_358;
                        pppppfStack_5cc = (float *****)0x2;
                        ppppfStack_5d0 = (float ****)0x41;
                        pppppfStack_5c8 = (float *****)0x8;
                        ppppfStack_5c4 = ppppfStack_380;
                        pppppfStack_5c0 = (float *****)0x40e320;
                        pppppfStack_5bc = pppppfStack_378;
                        pppppfStack_5d4 = pppppfStack_3d4;
                        pppppfStack_5d8 = (float *****)0x4be36f;
                        __vbaLateIdCallSt();
                        pppppfStack_5d8 = (float *****)0x0;
                        pppppfStack_5dc = (float *****)0x4;
                        ppppfStack_5e4 = (float ****)appppfStack_334;
                        pppppfStack_5e0 = pppppfStack_3d4;
                        puStack_5e8 = (undefined *)0x4be384;
                        pppppfStack_59c = (float *****)__vbaLateIdCallLd();
                        pppppfStack_5a0 = (float *****)0x4be38e;
                        iVar20 = __vbaI4Var();
                        if (!SCARRY4(iVar20,1)) {
                          pppppfStack_5b0 = (float *****)0x4;
                          pppppfStack_5ac = (float *****)0x3;
                          pppppfStack_5a8 = pppppfStack_340;
                          pppppfStack_5b4 = pppppfStack_3d4;
                          pppppfStack_5a0 = pppppfStack_338;
                          pppppfStack_5b8 = (float *****)0x4be3b7;
                          pppppfStack_5a4 = (float *****)(iVar20 + 1);
                          __vbaLateIdSt();
                          pppppfStack_5b8 = (float *****)0x4be3c0;
                          __vbaFreeVar();
                          pppppfStack_5b8 = (float *****)0x0;
                          pppppfStack_5bc = (float *****)0x4;
                          ppppfStack_5c4 = (float ****)appppfStack_334;
                          pppppfStack_5c0 = pppppfStack_3d4;
                          pppppfStack_5c8 = (float *****)0x4be3d5;
                          pppppfStack_5b8 = (float *****)__vbaLateIdCallLd();
                          pppppfStack_5bc = (float *****)0x4be3df;
                          iVar20 = __vbaI4Var();
                          if (!SBORROW4(iVar20,1)) {
                            pppppfStack_5ac = (float *****)0x3;
                            pppppfStack_5a8 = pppppfStack_340;
                            pppppfStack_5a0 = pppppfStack_338;
                            pppppfStack_5bc = (float *****)0x3;
                            pppppfStack_5b8 = pppppfStack_360;
                            pppppfStack_5b4 = (float *****)0x0;
                            pppppfStack_5b0 = pppppfStack_358;
                            pppppfStack_5cc = (float *****)0x8;
                            pppppfStack_5c8 = (float *****)ppppfStack_380;
                            ppppfStack_5c4 = (float ****)0x412c88;
                            pppppfStack_5c0 = pppppfStack_378;
                            ppppfStack_5d0 = (float ****)0x2;
                            pppppfStack_5d4 = (float *****)0x41;
                            pppppfStack_5d8 = pppppfStack_3d4;
                            pppppfStack_5dc = (float *****)0x4be44e;
                            pppppfStack_5a4 = (float *****)(iVar20 + -1);
                            __vbaLateIdCallSt();
                            pppppfStack_5a0 = (float *****)0x4be45a;
                            __vbaFreeVar();
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_5a0 = (float *****)&DAT_0050b420;
                              pppppfStack_5a4 = (float *****)&DAT_00408c88;
                              pppppfStack_5a8 = (float *****)0x4be473;
                              __vbaNew2();
                            }
                            pppppfStack_5a0 = (float *****)DAT_0050b420;
                            pppppfStack_5a4 = (float *****)0x4be481;
                            pppppfStack_5a4 = (float *****)(*(code *)(*DAT_0050b420)[0xdb])();
                            pppppfStack_5a8 = (float *****)&pppppfStack_31c;
                            pppppfStack_5ac = (float *****)0x4be48c;
                            pppppfVar12 = (float *****)__vbaObjSet();
                            pppppfStack_5ac = (float *****)&pppppfStack_39c;
                            pppppfStack_5b4 = (float *****)0x4be49e;
                            pppppfStack_5b0 = pppppfVar12;
                            ppppppfVar24 = (float ******)(*(code *)(*pppppfVar12)[0x22])();
                            uVar29 = 0;
                            if ((int)ppppppfVar24 < 0) {
                              pppppfStack_5b4 = (float *****)0x88;
                              pppppfStack_5b8 = (float *****)&DAT_0040c3dc;
                              ppppfStack_5c4 = (float ****)0x4be4b6;
                              pppppfStack_5c0 = (float *****)ppppppfVar24;
                              pppppfStack_5bc = pppppfVar12;
                              __vbaHresultCheckObj();
                            }
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_5b4 = (float *****)&DAT_0050b420;
                              pppppfStack_5b8 = (float *****)&DAT_00408c88;
                              pppppfStack_5bc = (float *****)0x4be4cf;
                              __vbaNew2();
                            }
                            pppppfStack_5b4 = (float *****)DAT_0050b420;
                            pppppfStack_5b8 = (float *****)0x4be4dd;
                            pppppfStack_5b8 = (float *****)(*(code *)(*DAT_0050b420)[0xdb])();
                            pppppfStack_5bc = (float *****)&pppppfStack_320;
                            pppppfStack_5c0 = (float *****)0x4be4e8;
                            pppppfStack_3b0 = (float *****)__vbaObjSet();
                            pppppfVar12 = (float *****)*pppppfStack_3b0;
                            pppppfStack_5c0 = (float *****)0x0;
                            ppppfStack_5c4 = (float ****)0x80010004;
                            pppppfStack_5cc = appppfStack_334;
                            pppppfStack_5c8 = pppppfStack_3d4;
                            ppppfStack_5d0 = (float ****)0x4be508;
                            pppppfStack_5c0 = (float *****)__vbaLateIdCallLd();
                            ppppfStack_5c4 = (float ****)0x4be512;
                            fVar30 = (float10)__vbaR4Var();
                            pppppfVar21 = pppppfStack_3b0;
                            ppppppfVar26 = extraout_ECX_01;
                            if ((uVar29 & 0xd) != 0) goto LAB_004bea4a;
                            pppppfStack_504 =
                                 (float *****)(float)(fVar30 - (float10)(float)pppppfStack_39c);
                            pppppfStack_508 = pppppfStack_3b0;
                            pppppfStack_50c = (float *****)0x4be532;
                            pppppfStack_518 = (float *****)(*(code *)pppppfVar12[0x1f])();
                            if ((int)pppppfStack_518 < 0) {
                              pppppfStack_50c = (float *****)0x7c;
                              pppppfStack_510 = (float *****)&DAT_0040c3dc;
                              pppppfStack_514 = pppppfVar21;
                              pppppfStack_51c = (float *****)0x4be547;
                              __vbaHresultCheckObj();
                            }
                            pppppfStack_50c = (float *****)&pppppfStack_320;
                            pppppfStack_510 = (float *****)&pppppfStack_31c;
                            pppppfStack_514 = (float *****)0x2;
                            pppppfStack_518 = (float *****)0x4be557;
                            __vbaFreeObjList();
                            pppppfStack_50c = (float *****)0x4be563;
                            __vbaFreeVar();
                            if (DAT_0050c53c == (float ******)0x0) {
                              pppppfStack_50c = (float *****)&DAT_0050c53c;
                              pppppfStack_510 = (float *****)&DAT_0040b420;
                              pppppfStack_514 = (float *****)0x4be57c;
                              __vbaNew2();
                            }
                            ppppppfVar24 = DAT_0050c53c;
                            pppppfStack_50c = (float *****)&pppppfStack_31c;
                            pppppfStack_510 = (float *****)DAT_0050c53c;
                            pppppfStack_514 = (float *****)0x4be58c;
                            ppppppfVar26 = (float ******)(*(code *)(*DAT_0050c53c)[6])();
                            if ((int)ppppppfVar26 < 0) {
                              pppppfStack_514 = (float *****)0x18;
                              pppppfStack_518 = (float *****)&DAT_0040b410;
                              pppppfStack_51c = (float *****)ppppppfVar24;
                              pppppfStack_524 = (float *****)0x4be5a1;
                              pppppfStack_520 = (float *****)ppppppfVar26;
                              __vbaHresultCheckObj();
                            }
                            pppppfVar12 = pppppfStack_31c;
                            pppppfStack_514 = (float *****)&pppppfStack_39c;
                            pppppfStack_518 = pppppfStack_31c;
                            pppppfStack_51c = (float *****)0x4be5b6;
                            ppppppfVar24 = (float ******)(*(code *)(*pppppfStack_31c)[0x26])();
                            if ((int)ppppppfVar24 < 0) {
                              pppppfStack_51c = (float *****)0x98;
                              pppppfStack_520 = (float *****)&DAT_0040bb5c;
                              pppppfStack_524 = pppppfVar12;
                              pppppfStack_52c = (float *****)0x4be5ce;
                              pppppfStack_528 = (float *****)ppppppfVar24;
                              __vbaHresultCheckObj();
                            }
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_51c = (float *****)&DAT_0050b420;
                              pppppfStack_520 = (float *****)&DAT_00408c88;
                              pppppfStack_524 = (float *****)0x4be5e7;
                              __vbaNew2();
                            }
                            pppppfStack_51c = (float *****)DAT_0050b420;
                            pppppfStack_520 = (float *****)0x4be5f5;
                            pppppfStack_520 = (float *****)(*(code *)(*DAT_0050b420)[0xdb])();
                            pppppfStack_524 = (float *****)&pppppfStack_320;
                            pppppfStack_528 = (float *****)0x4be600;
                            ppppppfVar24 = (float ******)__vbaObjSet();
                            pppppfStack_528 = &ppppfStack_3a0;
                            pppppfStack_530 = (float *****)0x4be612;
                            pppppfStack_52c = (float *****)ppppppfVar24;
                            ppppppfVar26 = (float ******)(*(code *)(*ppppppfVar24)[0x20])();
                            uVar29 = 0;
                            if ((int)ppppppfVar26 < 0) {
                              pppppfStack_530 = (float *****)0x80;
                              pppppfStack_534 = (float *****)&DAT_0040c3dc;
                              pppppfStack_540 = (float *****)0x4be62a;
                              pppppfStack_53c = (float *****)ppppppfVar26;
                              pppppfStack_538 = (float *****)ppppppfVar24;
                              __vbaHresultCheckObj();
                            }
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_530 = (float *****)&DAT_0050b420;
                              pppppfStack_534 = (float *****)&DAT_00408c88;
                              pppppfStack_538 = (float *****)0x4be643;
                              __vbaNew2();
                            }
                            pppppfStack_530 = (float *****)DAT_0050b420;
                            pppppfStack_534 = (float *****)0x4be651;
                            pppppfStack_534 = (float *****)(*(code *)(*DAT_0050b420)[0xdb])();
                            pppppfStack_538 = (float *****)&pppppfStack_324;
                            pppppfStack_53c = (float *****)0x4be65c;
                            ppppppfVar24 = (float ******)__vbaObjSet();
                            ppppppfVar26 = (float ******)pppppfStack_504;
                            if ((uVar29 & 0xd) != 0) goto LAB_004bea4a;
                            pppppfStack_504 =
                                 (float *****)
                                 (((float)pppppfStack_39c - (float)ppppfStack_3a0) *
                                 (float)_DAT_00401268);
                            ppppppfVar26 = (float ******)*ppppppfVar24;
                            if ((uVar29 & 0xd) != 0) goto LAB_004bea4a;
                            pppppfStack_510 = (float *****)0x4be69a;
                            pppppfStack_50c = (float *****)ppppppfVar24;
                            fStack_408 = (float)pppppfStack_504;
                            pppppfStack_51c = (float *****)(*(code *)(*ppppppfVar24)[0x1d])();
                            if ((int)pppppfStack_51c < 0) {
                              pppppfStack_510 = (float *****)0x74;
                              pppppfStack_514 = (float *****)&DAT_0040c3dc;
                              pppppfStack_520 = (float *****)0x4be6af;
                              pppppfStack_518 = (float *****)ppppppfVar24;
                              __vbaHresultCheckObj();
                            }
                            pppppfStack_510 = (float *****)&pppppfStack_324;
                            pppppfStack_514 = (float *****)&pppppfStack_320;
                            pppppfStack_518 = (float *****)&pppppfStack_31c;
                            pppppfStack_51c = (float *****)0x3;
                            pppppfStack_520 = (float *****)0x4be6c3;
                            __vbaFreeObjList();
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_510 = (float *****)&DAT_0050b420;
                              pppppfStack_514 = (float *****)&DAT_00408c88;
                              pppppfStack_518 = (float *****)0x4be6df;
                              __vbaNew2();
                            }
                            pppppfStack_510 = (float *****)DAT_0050b420;
                            pppppfStack_514 = (float *****)0x4be6ed;
                            pppppfStack_514 = (float *****)(*(code *)(*DAT_0050b420)[0xd1])();
                            pppppfStack_518 = (float *****)&pppppfStack_31c;
                            pppppfStack_51c = (float *****)0x4be6f8;
                            pppppfStack_3a8 = (float *****)__vbaObjSet();
                            pppppfVar12 = (float *****)*pppppfStack_3a8;
                            pppppfStack_51c = (float *****)0x0;
                            pppppfStack_520 = (float *****)0x80010004;
                            pppppfStack_528 = appppfStack_334;
                            pppppfStack_524 = pppppfStack_3d4;
                            pppppfStack_52c = (float *****)0x4be718;
                            pppppfStack_51c = (float *****)__vbaLateIdCallLd();
                            pppppfStack_520 = (float *****)0x4be722;
                            fVar30 = (float10)__vbaR4Var();
                            pppppfVar21 = pppppfStack_3a8;
                            pppppfStack_520 = (float *****)(float)fVar30;
                            pppppfStack_524 = pppppfStack_3a8;
                            pppppfStack_528 = (float *****)0x4be732;
                            ppppppfVar24 = (float ******)(*(code *)pppppfVar12[0x1f])();
                            if ((int)ppppppfVar24 < 0) {
                              pppppfStack_528 = (float *****)0x7c;
                              pppppfStack_52c = (float *****)&DAT_0040c3dc;
                              pppppfStack_530 = pppppfVar21;
                              pppppfStack_538 = (float *****)0x4be747;
                              pppppfStack_534 = (float *****)ppppppfVar24;
                              __vbaHresultCheckObj();
                            }
                            pppppfStack_528 = (float *****)0x4be750;
                            __vbaFreeObj();
                            pppppfStack_528 = (float *****)0x4be759;
                            __vbaFreeVar();
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_528 = (float *****)&DAT_0050b420;
                              pppppfStack_52c = (float *****)&DAT_00408c88;
                              pppppfStack_530 = (float *****)0x4be772;
                              __vbaNew2();
                            }
                            pppppfStack_528 = (float *****)DAT_0050b420;
                            pppppfStack_52c = (float *****)0x4be780;
                            pppppfStack_52c = (float *****)(*(code *)(*DAT_0050b420)[0xd1])();
                            pppppfStack_530 = (float *****)&pppppfStack_31c;
                            pppppfStack_534 = (float *****)0x4be78b;
                            ppppppfVar24 = (float ******)__vbaObjSet();
                            pppppfStack_534 = (float *****)&pppppfStack_39c;
                            pppppfStack_53c = (float *****)0x4be79d;
                            pppppfStack_538 = (float *****)ppppppfVar24;
                            ppppppfVar26 = (float ******)(*(code *)(*ppppppfVar24)[0x20])();
                            uVar29 = 0;
                            if ((int)ppppppfVar26 < 0) {
                              pppppfStack_53c = (float *****)0x80;
                              pppppfStack_540 = (float *****)&DAT_0040c3dc;
                              pppppfStack_54c = (float *****)0x4be7b5;
                              pppppfStack_548 = (float *****)ppppppfVar26;
                              pppppfStack_544 = (float *****)ppppppfVar24;
                              __vbaHresultCheckObj();
                            }
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_53c = (float *****)&DAT_0050b420;
                              pppppfStack_540 = (float *****)&DAT_00408c88;
                              pppppfStack_544 = (float *****)0x4be7ce;
                              __vbaNew2();
                            }
                            pppppfStack_53c = (float *****)DAT_0050b420;
                            pppppfStack_540 = (float *****)0x4be7dc;
                            pppppfStack_540 = (float *****)(*(code *)(*DAT_0050b420)[0xd1])();
                            pppppfStack_544 = (float *****)&pppppfStack_320;
                            pppppfStack_548 = (float *****)0x4be7e7;
                            pppppfStack_3b0 = (float *****)__vbaObjSet();
                            pppppfVar12 = (float *****)*pppppfStack_3b0;
                            pppppfStack_548 = (float *****)0x0;
                            pppppfStack_54c = (float *****)0x80010003;
                            pppppfStack_554 = appppfStack_334;
                            pppppfStack_550 = pppppfStack_3d4;
                            pppppfStack_558 = (float *****)0x4be807;
                            pppppfStack_548 = (float *****)__vbaLateIdCallLd();
                            pppppfStack_54c = (float *****)0x4be811;
                            fVar30 = (float10)__vbaR4Var();
                            pppppfVar21 = pppppfStack_3b0;
                            ppppppfVar26 = extraout_ECX_02;
                            ppppfStack_414 = (float ****)pppppfVar12;
                            if ((uVar29 & 0xd) != 0) goto LAB_004bea4a;
                            pppppfStack_504 =
                                 (float *****)
                                 (float)(fVar30 - (float10)(float)pppppfStack_39c *
                                                  (float10)_DAT_00402038);
                            pppppfStack_508 = pppppfStack_3b0;
                            pppppfStack_50c = (float *****)0x4be84f;
                            pppppfStack_410 = pppppfStack_504;
                            pppppfStack_518 = (float *****)(*(code *)pppppfVar12[0x1d])();
                            if ((int)pppppfStack_518 < 0) {
                              pppppfStack_50c = (float *****)0x74;
                              pppppfStack_510 = (float *****)&DAT_0040c3dc;
                              pppppfStack_514 = pppppfVar21;
                              pppppfStack_51c = (float *****)0x4be864;
                              __vbaHresultCheckObj();
                            }
                            pppppfStack_50c = (float *****)&pppppfStack_320;
                            pppppfStack_510 = (float *****)&pppppfStack_31c;
                            pppppfStack_514 = (float *****)0x2;
                            pppppfStack_518 = (float *****)0x4be874;
                            __vbaFreeObjList();
                            pppppfStack_50c = (float *****)0x4be880;
                            __vbaFreeVar();
                            if (DAT_0050b420 == (float ******)0x0) {
                              pppppfStack_50c = (float *****)&DAT_0050b420;
                              pppppfStack_510 = (float *****)&DAT_00408c88;
                              pppppfStack_514 = (float *****)0x4be899;
                              __vbaNew2();
                            }
                            pppppfStack_50c = (float *****)DAT_0050b420;
                            pppppfStack_510 = (float *****)0x4be8a7;
                            pppppfStack_510 = (float *****)(*(code *)(*DAT_0050b420)[0xd1])();
                            pppppfStack_514 = (float *****)&pppppfStack_31c;
                            pppppfStack_518 = (float *****)0x4be8b2;
                            ppppppfVar24 = (float ******)__vbaObjSet();
                            pppppfStack_518 = (float *****)0xffffffff;
                            pppppfStack_520 = (float *****)0x4be8bf;
                            pppppfStack_51c = (float *****)ppppppfVar24;
                            ppppppfVar26 = (float ******)(*(code *)(*ppppppfVar24)[0x27])();
                            if ((int)ppppppfVar26 < 0) {
                              pppppfStack_520 = (float *****)0x9c;
                              pppppfStack_524 = (float *****)&DAT_0040c3dc;
                              pppppfStack_530 = (float *****)0x4be8d7;
                              pppppfStack_52c = (float *****)ppppppfVar26;
                              pppppfStack_528 = (float *****)ppppppfVar24;
                              __vbaHresultCheckObj();
                            }
                            pppppfStack_520 = (float *****)0x4be8e0;
                            __vbaFreeObj();
                            pppppfStack_524 = (float *****)&pppppfStack_3d4;
                            pppppfStack_520 = (float *****)0x0;
                            pppppfStack_528 = (float *****)0x4be8ef;
                            __vbaObjSetAddref();
                            ppppppfVar26 = (float ******)&DAT_00000001;
                            sStack_3dc = DAT_0050b332;
                            do {
                              pppppfStack_30c = (float *****)ppppppfVar26;
                              if (sStack_3dc < (short)ppppppfVar26) {
                                pppppfStack_5a0 = (float *****)&LAB_004bea39;
                                pppppfStack_5a4 = (float *****)&pppppfStack_3d4;
                                pppppfStack_5a8 = (float *****)apiStack_3d0;
                                pppppfStack_5ac = (float *****)0x2;
                                pppppfStack_5b0 = (float *****)0x4bea35;
                                __vbaFreeObjList();
                                return;
                              }
                              if (DAT_0050b420 == (float ******)0x0) {
                                pppppfStack_5a0 = (float *****)&DAT_0050b420;
                                pppppfStack_5a4 = (float *****)&DAT_00408c88;
                                pppppfStack_5a8 = (float *****)0x4be92b;
                                __vbaNew2();
                              }
                              pppppfStack_5a0 = (float *****)DAT_0050b420;
                              pppppfStack_5a4 = (float *****)0x4be939;
                              pppppfStack_5a4 = (float *****)(*(code *)(*DAT_0050b420)[0xd2])();
                              pppppfStack_5a8 = (float *****)&pppppfStack_31c;
                              pppppfStack_5ac = (float *****)0x4be944;
                              pppppfStack_3a8 = (float *****)__vbaObjSet();
                              pppppfVar12 = (float *****)*pppppfStack_3a8;
                              pppppfStack_5b8 = (float *****)0xa;
                              pppppfStack_5bc = (float *****)&DAT_0040de90;
                              pppppfStack_5b4 = pppppfStack_340;
                              pppppfStack_5b0 = (float *****)0x80020004;
                              pppppfStack_5c0 = pppppfStack_30c;
                              pppppfStack_5ac = pppppfStack_338;
                              ppppfStack_5c4 = (float ****)0x4be975;
                              __vbaStrI2();
                              ppppfStack_5c4 = (float ****)0x4be980;
                              ppppfStack_5c4 = (float ****)__vbaStrMove();
                              pppppfStack_5c8 = (float *****)0x4be987;
                              __vbaStrCat();
                              pppppfStack_5c8 = (float *****)0x4be992;
                              pppppfStack_5c8 = (float *****)__vbaStrMove();
                              ppppppfVar24 = (float ******)pppppfStack_3a8;
                              pppppfStack_5cc = pppppfStack_3a8;
                              ppppfStack_5d0 = (float ****)0x4be9a2;
                              pppppfStack_5dc = (float *****)(*(code *)pppppfVar12[0x7b])();
                              if ((int)pppppfStack_5dc < 0) {
                                ppppfStack_5d0 = (float ****)0x1ec;
                                pppppfStack_5d4 = (float *****)&DAT_0040dc58;
                                pppppfStack_5d8 = (float *****)ppppppfVar24;
                                pppppfStack_5e0 = (float *****)0x4be9ba;
                                __vbaHresultCheckObj();
                              }
                              ppppfStack_5d0 = (float ****)&ppfStack_318;
                              pppppfStack_5d4 = &ppppfStack_314;
                              pppppfStack_5d8 = (float *****)0x2;
                              pppppfStack_5dc = (float *****)0x4be9ca;
                              __vbaFreeStrList();
                              ppppfStack_5d0 = (float ****)0x4be9d6;
                              __vbaFreeObj();
                              ppppppfVar26 = (float ******)
                                             (uint)(ushort)((short)pppppfStack_30c + 1);
                            } while (!SCARRY2((short)pppppfStack_30c,1));
                          }
                        }
                        pppppfStack_5a0 = (float *****)0x4bea55;
                        __vbaErrorOverflow();
                        pppppfStack_5ac = (float *****)&DAT_00402706;
                        pppppfStack_5b0 = ExceptionList;
                        pppppfStack_710 = pppppfStack_340;
                        pppppfStack_5a8 = (float *****)&pppppfStack_714;
                        pppppfStack_714 = pppppfStack_338;
                        pppppfStack_5a4 = (float *****)&DAT_00402320;
                        pppppfStack_5c0 = (float *****)0x0;
                        pppppfStack_5cc = (float *****)0x0;
                        ppppfStack_5d0 = (float ****)0x0;
                        pppppfStack_5d4 = (float *****)0x0;
                        pppppfStack_5d8 = (float *****)0x0;
                        pppppfStack_5dc = (float *****)0x0;
                        pppppfStack_5e0 = (float *****)0x0;
                        ppppfStack_5e4 = (float ****)0x0;
                        puStack_5e8 = (undefined *)0x0;
                        uStack_5ec = 0;
                        uStack_5f0 = 0;
                        pppppfStack_5f4 = (float *****)0x0;
                        ppppfStack_5f8 = (float ****)0x0;
                        pppppfStack_5fc = (float *****)0x0;
                        pppppfStack_600 = (float *****)0x0;
                        uStack_604 = 0;
                        uStack_608 = 0;
                        pppfStack_60c = (float ***)0x0;
                        ppppfStack_61c = (float ****)0x0;
                        appppfStack_62c[0] = (float ****)0x0;
                        appppfStack_63c[0] = (float ****)0x0;
                        ppppfStack_64c = (float ****)0x0;
                        apppfStack_65c[0] = (float ***)0x0;
                        ppppfStack_66c = (float ****)0x0;
                        appppfStack_67c[0] = (float ****)0x0;
                        ppppfStack_68c = (float ****)0x0;
                        apppfStack_69c[0] = (float ***)0x0;
                        uStack_6ac = 0;
                        ppppfStack_6d8 = (float ****)0x0;
                        pppppfStack_6dc = (float *****)0x0;
                        pcVar17 = __vbaGenerateBoundsError_exref;
                        ppppppfVar26 = (float ******)pppppfStack_340;
                        pppppfVar12 = (float *****)__vbaStrMove_exref;
                        ExceptionList = &pppppfStack_5b0;
                        pppppfStack_70c = (float *****)ppppppfVar24;
                        ppppppfVar24 = &pppppfStack_714;
                        pppppfStack_5a0 = (float *****)&pppppfStack_2f8;
                        if (DAT_0050b33a == 0) {
                          ppppfStack_71c = (float ****)(int)DAT_0050b332;
                          pppppfStack_718 = (float *****)0x0;
                          pppppfStack_720 = (float *****)0x1;
                          pppppfStack_724 = (float *****)0x2;
                          ppppfStack_728 = (float ****)&DAT_0050b198;
                          pppppfStack_72c = (float *****)0x2;
                          ppppfStack_730 = (float ****)0x80;
                          ppppfStack_734 = (float ****)0x4beb39;
                          ExceptionList = &pppppfStack_5b0;
                          pppppfStack_5a0 = (float *****)&pppppfStack_2f8;
                          __vbaRedim();
                          pcVar17 = __vbaGenerateBoundsError_exref;
                          DAT_0050b33a = 1;
                          if ((DAT_0050b194 == (short *)0x0) || (*DAT_0050b194 != 1)) {
                            pppppfStack_718 = (float *****)0x4beb79;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            iVar20 = *(int *)(DAT_0050b194 + 10);
                            if (*(uint *)(DAT_0050b194 + 8) <= 1U - iVar20) {
                              pppppfStack_718 = (float *****)0x4beb66;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = (1U - iVar20) * 2;
                          }
                          *(short *)(*(int *)(DAT_0050b194 + 6) + iVar20) = DAT_0050b33e;
                          if ((DAT_0050b198 == (short *)0x0) || (*DAT_0050b198 != 1)) {
                            pppppfStack_718 = (float *****)0x4bebbf;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            iVar23 = (int)DAT_0050b33e;
                            iVar20 = *(int *)(DAT_0050b198 + 10);
                            if (*(uint *)(DAT_0050b198 + 8) <= (uint)(iVar23 - iVar20)) {
                              pppppfStack_718 = (float *****)0x4bebb2;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = (iVar23 - iVar20) * 2;
                          }
                          *(undefined2 *)(*(int *)(DAT_0050b198 + 6) + iVar20) = 1;
                          if (DAT_0050b420 == (float ******)0x0) {
                            pppppfStack_718 = (float *****)&DAT_0050b420;
                            ppppfStack_71c = (float ****)&DAT_00408c88;
                            pppppfStack_720 = (float *****)0x4bebe7;
                            __vbaNew2();
                          }
                          pppppfStack_718 = (float *****)DAT_0050b420;
                          ppppfStack_71c = (float ****)0x4bebf5;
                          ppppfStack_71c = (float ****)(*(code *)(*DAT_0050b420)[0xea])();
                          pppppfStack_720 = &ppppfStack_6d8;
                          pppppfStack_724 = (float *****)0x4bec03;
                          __vbaObjSet();
                          ppppppfVar26 = (float ******)__vbaLateIdSt_exref;
                          ppppfStack_66c = (float ****)0x3;
                          ppppfStack_730 = (float ****)0x3;
                          pwStack_664 = (wchar_t *)0x1;
                          ppppfStack_734 = (float ****)0x4;
                          pppppfStack_72c = pppppfStack_668;
                          pppppfStack_738 = (float *****)ppppfStack_6d8;
                          ppppfStack_728 = (float ****)&DAT_00000001;
                          pppppfStack_724 = pppppfStack_660;
                          pppppfStack_73c = (float *****)0x4bec46;
                          __vbaLateIdSt();
                          ppppfStack_66c = (float ****)0x3;
                          ppppfStack_74c = (float ****)0xa;
                          pppppfStack_748 = (float *****)0x3;
                          pwStack_664 = (wchar_t *)0x0;
                          pppppfStack_744 = pppppfStack_668;
                          ppppfStack_750 = ppppfStack_6d8;
                          pwStack_740 = (wchar_t *)0x0;
                          pppppfStack_73c = pppppfStack_660;
                          pppppfStack_754 = (float *****)0x4bec80;
                          __vbaLateIdSt();
                          ppppfStack_66c = (float ****)0x3;
                          puStack_764 = (undefined *)0xb;
                          pwStack_760 = (wchar_t *)0x3;
                          pwStack_664 = (wchar_t *)0x0;
                          pppppfStack_75c = pppppfStack_668;
                          pppppfStack_768 = (float *****)ppppfStack_6d8;
                          pppppfStack_758 = (float *****)0x0;
                          pppppfStack_754 = pppppfStack_660;
                          pppppfStack_76c = (float *****)0x4becba;
                          __vbaLateIdSt();
                          ppppfStack_66c = (float ****)0x3;
                          ppppfStack_77c = (float ****)0x26;
                          ppppfStack_778 = (float ****)0x3;
                          pwStack_664 = (wchar_t *)0xffff00;
                          pppppfStack_774 = pppppfStack_668;
                          ppppfStack_780 = ppppfStack_6d8;
                          ppppfStack_770 = (float ****)0xffff00;
                          pppppfStack_76c = pppppfStack_660;
                          pppppfStack_784 = (float *****)0x4becf7;
                          __vbaLateIdSt();
                          ppppfStack_66c = (float ****)0x3;
                          pppppfStack_790 = (float *****)0x3;
                          pwStack_664 = (wchar_t *)0xff0000;
                          pppppfStack_78c = pppppfStack_668;
                          pppppfStack_788 = (float *****)0xff0000;
                          pppppfStack_794 = (float *****)0x27;
                          pppppfStack_798 = (float *****)ppppfStack_6d8;
                          pppppfStack_784 = pppppfStack_660;
                          pppppfStack_79c = (float *****)0x4bed34;
                          __vbaLateIdSt();
                          ppppfStack_66c = (float ****)0x3;
                          ppppfStack_7ac = (float ****)0x4;
                          ppuStack_7a8 = (undefined **)0x3;
                          pwStack_664 = (wchar_t *)0x2;
                          pppppfStack_7a4 = pppppfStack_668;
                          pppppfStack_7b0 = (float *****)ppppfStack_6d8;
                          pppppfStack_7a0 = (float *****)0x2;
                          pppppfStack_79c = pppppfStack_660;
                          pppppfStack_7b4 = (float *****)0x4bed71;
                          __vbaLateIdSt();
                          ppppfStack_66c = (float ****)0x3;
                          pwStack_664 = (wchar_t *)0x1;
                          pppppfStack_7bc = pppppfStack_668;
                          pppppfStack_7b8 = (float *****)0x1;
                          pppppfStack_7b4 = pppppfStack_660;
                          __vbaLateIdSt(ppppfStack_6d8,10,3);
                          __vbaStrI2(CONCAT22(extraout_var_05,DAT_0050b33e),
                                     L" 0.     Start at node N");
                          pppppfVar12 = (float *****)__vbaStrMove_exref;
                          uVar13 = __vbaStrMove();
                          ppppfStack_614 = (float ****)__vbaStrCat(uVar13);
                          ppppfStack_61c = (float ****)0x8;
                          __vbaLateIdSt(ppppfStack_6d8,0,8,uStack_618,ppppfStack_614,uStack_610);
                          __vbaFreeStr();
                          __vbaFreeVar();
                          __vbaObjSetAddref(&ppppfStack_6d8,0);
                          ppppppfVar24 = (float ******)pppppfStack_5a8;
                        }
                        pppppfStack_5a8 = (float *****)ppppppfVar24;
                        pppppfStack_5d4 = (float *****)(float)_DAT_0050b134;
                        sStack_6e4 = DAT_0050b33a;
                        pppppfStack_5b4 = (float *****)0x1;
                        ppppppfVar24 = DAT_0050b0e8;
                        pppppfVar21 = pppppfStack_5b4;
                        while (pppppfStack_5b4 = pppppfVar21, (short)pppppfStack_5b4 <= sStack_6e4)
                        {
                          if ((DAT_0050b194 == (short *)0x0) || (*DAT_0050b194 != 1)) {
                            pppppfStack_718 = (float *****)0x4bee8e;
                            iVar20 = (*pcVar17)();
                            ppppppfVar24 = DAT_0050b0e8;
                          }
                          else {
                            ppppppfVar26 = (float ******)
                                           ((int)(short)pppppfStack_5b4 -
                                           *(int *)(DAT_0050b194 + 10));
                            if (*(float *******)(DAT_0050b194 + 8) <= ppppppfVar26) {
                              pppppfStack_718 = (float *****)0x4bee81;
                              (*pcVar17)();
                              ppppppfVar24 = DAT_0050b0e8;
                            }
                            iVar20 = (int)ppppppfVar26 * 2;
                          }
                          ppppfStack_5c4 =
                               (float ****)
                               CONCAT22(ppppfStack_5c4._2_2_,
                                        *(undefined2 *)(*(int *)(DAT_0050b194 + 6) + iVar20));
                          sStack_6ec = DAT_0050b332;
                          pppppfStack_5b8 = (float *****)0x1;
                          pppppfVar21 = pppppfStack_5b8;
                          while (pppppfStack_5b8 = pppppfVar21, (short)pppppfStack_5b8 <= sStack_6ec
                                ) {
                            if ((DAT_0050b198 == (short *)0x0) || (*DAT_0050b198 != 1)) {
                              pppppfStack_718 = (float *****)0x4beef6;
                              iVar20 = (*pcVar17)();
                              ppppppfVar24 = DAT_0050b0e8;
                            }
                            else {
                              ppppppfVar26 = (float ******)
                                             ((int)(short)pppppfStack_5b8 -
                                             *(int *)(DAT_0050b198 + 10));
                              if (*(float *******)(DAT_0050b198 + 8) <= ppppppfVar26) {
                                pppppfStack_718 = (float *****)0x4beee9;
                                (*pcVar17)();
                                ppppppfVar24 = DAT_0050b0e8;
                              }
                              iVar20 = (int)ppppppfVar26 * 2;
                            }
                            if (*(short *)(*(int *)(DAT_0050b198 + 6) + iVar20) == 0) {
                              uVar8 = (undefined2)((uint)ppppppfVar26 >> 0x10);
                              ppppppfVar26 = (float ******)
                                             CONCAT22(uVar8,(short)ppppfStack_5c4 + -1);
                              if (SBORROW2((short)ppppfStack_5c4,1)) goto LAB_004bf9a1;
                              iVar20 = (int)(short)((short)ppppfStack_5c4 + -1) * (int)DAT_0050b332;
                              sVar18 = (short)iVar20;
                              ppppppfVar26 = (float ******)CONCAT22(uVar8,sVar18);
                              if (sVar18 != iVar20) goto LAB_004bf9a1;
                              sVar19 = sVar18 + (short)pppppfStack_5b8;
                              ppppppfVar26 = (float ******)CONCAT22(uVar8,sVar19);
                              if (SCARRY2(sVar18,(short)pppppfStack_5b8)) goto LAB_004bf9a1;
                              if ((ppppppfVar24 == (float ******)0x0) ||
                                 (*(short *)ppppppfVar24 != 1)) {
                                pppppfStack_718 = (float *****)0x4bef6a;
                                iVar20 = __vbaGenerateBoundsError();
                                ppppppfVar24 = DAT_0050b0e8;
                              }
                              else {
                                pppppfVar21 = ppppppfVar24[5];
                                if (ppppppfVar24[4] <= (float *****)((int)sVar19 - (int)pppppfVar21)
                                   ) {
                                  pppppfStack_718 = (float *****)0x4bef55;
                                  __vbaGenerateBoundsError();
                                  ppppppfVar24 = DAT_0050b0e8;
                                }
                                iVar20 = ((int)sVar19 - (int)pppppfVar21) * 8;
                              }
                              pcVar17 = __vbaGenerateBoundsError_exref;
                              if (*(double *)((int)ppppppfVar24[3] + iVar20) != _DAT_0050b134) {
                                if ((ppppppfVar24 == (float ******)0x0) ||
                                   (*(short *)ppppppfVar24 != 1)) {
                                  pppppfStack_718 = (float *****)0x4befc3;
                                  iVar20 = __vbaGenerateBoundsError();
                                  ppppppfVar24 = DAT_0050b0e8;
                                }
                                else {
                                  pppppfVar21 = ppppppfVar24[5];
                                  if (ppppppfVar24[4] <=
                                      (float *****)((int)sVar19 - (int)pppppfVar21)) {
                                    pppppfStack_718 = (float *****)0x4befa6;
                                    __vbaGenerateBoundsError();
                                    ppppppfVar24 = DAT_0050b0e8;
                                  }
                                  iVar20 = ((int)sVar19 - (int)pppppfVar21) * 8;
                                  pcVar17 = __vbaGenerateBoundsError_exref;
                                }
                                fStack_704 = (float)*(double *)((int)ppppppfVar24[3] + iVar20);
                                pppppfStack_718 = (float *****)0x4befe1;
                                fVar30 = (float10)__vbaFpR4();
                                ppppppfVar24 = DAT_0050b0e8;
                                if (fVar30 <= (float10)(float)pppppfStack_5d4) {
                                  if ((DAT_0050b0e8 == (float ******)0x0) ||
                                     (*(short *)DAT_0050b0e8 != 1)) {
                                    pppppfStack_718 = (float *****)0x4bf01d;
                                    iVar20 = (*pcVar17)();
                                  }
                                  else {
                                    ppppppfVar26 = (float ******)
                                                   ((int)sVar19 - (int)DAT_0050b0e8[5]);
                                    if (DAT_0050b0e8[4] <= ppppppfVar26) {
                                      pppppfStack_718 = (float *****)0x4bf00c;
                                      (*pcVar17)();
                                    }
                                    iVar20 = (int)ppppppfVar26 * 8;
                                  }
                                  pppppfStack_5d4 =
                                       (float *****)
                                       (float)*(double *)((int)DAT_0050b0e8[3] + iVar20);
                                  ppppfStack_5d0 = ppppfStack_5c4;
                                  pppppfStack_5d8 = pppppfStack_5b8;
                                  ppppppfVar24 = DAT_0050b0e8;
                                }
                              }
                            }
                            pcVar17 = __vbaGenerateBoundsError_exref;
                            pppppfVar21 = (float *****)(uint)(ushort)((short)pppppfStack_5b8 + 1);
                            if (SCARRY2((short)pppppfStack_5b8,1)) goto LAB_004bf9a1;
                          }
                          pppppfVar21 = (float *****)(uint)(ushort)((short)pppppfStack_5b4 + 1);
                          if (SCARRY2((short)pppppfStack_5b4,1)) goto LAB_004bf9a1;
                        }
                        fStack_708 = (float)_DAT_0050b134;
                        pppppfStack_718 = (float *****)0x4bf086;
                        fVar30 = (float10)__vbaFpR4();
                        if (fVar30 <= (float10)(float)pppppfStack_5d4) {
                          ppppfStack_64c = (float ****)0xa;
                          appppfStack_63c[0] = (float ****)0xa;
                          pwStack_644 = (wchar_t *)0x80020004;
                          uStack_634 = 0x80020004;
                          pppppfStack_674 = (float *****)0x412e80;
                          appppfStack_67c[0] = (float ****)0x8;
                          pppppfStack_718 = (float *****)0x4bf880;
                          __vbaVarDup();
                          pwStack_664 = 
                          L"All arcs from from current node have infinite length. No spanning tree exists."
                          ;
                          ppppfStack_66c = (float ****)0x8;
                          pppppfStack_718 = (float *****)0x4bf89b;
                          __vbaVarDup();
                          pppppfStack_718 = &ppppfStack_64c;
                          ppppfStack_71c = (float ****)appppfStack_63c;
                          pppppfStack_720 = appppfStack_62c;
                          ppppfStack_728 = (float ****)&ppppfStack_61c;
                          pppppfStack_724 = (float *****)0x10;
                          pppppfStack_72c = (float *****)0x4bf8bc;
                          Ordinal_595();
                          pppppfStack_72c = &ppppfStack_64c;
                          ppppfStack_730 = (float ****)appppfStack_63c;
                          ppppfStack_734 = (float ****)appppfStack_62c;
                          pppppfStack_738 = &ppppfStack_61c;
                          pppppfStack_73c = (float *****)0x4;
                          pwStack_740 = L"쒃昔ׇ댺P";
                          __vbaFreeVarList();
                          DAT_0050b33a = 0;
LAB_004bf961:
                          pppppfStack_790 = (float *****)&LAB_004bf98b;
                          pppppfStack_794 = (float *****)&pppppfStack_6dc;
                          pppppfStack_798 = &ppppfStack_6d8;
                          pppppfStack_79c = (float *****)0x2;
                          pppppfStack_7a0 = (float *****)0x4bf977;
                          __vbaFreeObjList();
                          pppppfStack_794 = (float *****)0x4bf985;
                          __vbaFreeStr();
                          pppppfStack_794 = (float *****)0x4bf98a;
                          __vbaFreeStr();
                          return;
                        }
                        _DAT_0050b14c = (double)((float)pppppfStack_5d4 + (float)_DAT_0050b14c);
                        pppppfStack_718 = (float *****)0x4bf0b2;
                        FUN_0044fdc0();
                        pppppfStack_718 = (float *****)0x4bf0b9;
                        (*(code *)pppppfVar12)();
                        ppppfStack_614 = (float ****)pppppfStack_5dc;
                        appppfStack_67c[0] = (float ****)0x8;
                        ppppfStack_61c = (float ****)0x8;
                        pppppfStack_718 = (float *****)0x1;
                        pppppfStack_720 = &ppppfStack_61c;
                        ppppfStack_71c = (float ****)0x1;
                        pppppfStack_724 = &ppppfStack_66c;
                        ppppfStack_728 = (float ****)appppfStack_62c;
                        pcVar17 = (code *)0x3;
                        ppppfStack_684 = (float ****)0x0;
                        ppppfStack_68c = (float ****)0x3;
                        pppppfStack_674 = (float *****)0x412ce8;
                        pppppfStack_5dc = (float *****)0x0;
                        pwStack_664 = (wchar_t *)&DAT_0050b14c;
                        ppppfStack_66c = (float ****)0x4005;
                        pppppfStack_72c = (float *****)0x4bf11d;
                        Ordinal_660();
                        pppppfStack_72c = appppfStack_67c;
                        ppppfStack_730 = (float ****)appppfStack_62c;
                        ppppfStack_734 = (float ****)appppfStack_63c;
                        pppppfStack_738 = (float *****)0x4bf138;
                        pppppfStack_738 = (float *****)__vbaVarCat();
                        pppppfStack_73c = (float *****)0x4bf13f;
                        pwStack_644 = (wchar_t *)__vbaStrVarMove();
                        ppppfStack_64c = (float ****)0x8;
                        if (DAT_0050b420 == (float ******)0x0) {
                          pppppfStack_73c = (float *****)&DAT_0050b420;
                          pwStack_740 = L"\x01\aꙴ@";
                          pppppfStack_744 = (float *****)0x4bf168;
                          __vbaNew2();
                        }
                        pppppfStack_748 = (float *****)ppppfStack_68c;
                        pppppfStack_744 = pppppfStack_688;
                        pwStack_740 = (wchar_t *)ppppfStack_684;
                        pppppfStack_73c = pppppfStack_680;
                        pppppfStack_758 = (float *****)0x3;
                        pppppfStack_754 = (float *****)ppppfStack_6a8;
                        ppppfStack_750 = (float ****)0x0;
                        ppppfStack_74c = (float ****)fStack_6a0;
                        pppppfStack_76c = (float *****)0x2;
                        ppppfStack_770 = (float ****)0x41;
                        pppppfStack_774 = (float *****)DAT_0050b420;
                        pppppfStack_768 = (float *****)ppppfStack_64c;
                        puStack_764 = puStack_648;
                        pwStack_760 = pwStack_644;
                        pppppfStack_75c = (float *****)uStack_640;
                        ppppfStack_778 = (float ****)0x4bf1e6;
                        ppppfStack_778 = (float ****)(*(code *)(*DAT_0050b420)[0xea])();
                        ppppfStack_77c = &pppfStack_60c;
                        ppppfStack_780 = (float ****)0x4bf1f1;
                        ppppfStack_780 = (float ****)__vbaObjSet();
                        pppppfStack_784 = (float *****)0x4bf1f8;
                        __vbaLateIdCallSt();
                        pppppfStack_748 = (float *****)0x4bf204;
                        __vbaFreeStr();
                        pppppfStack_748 = (float *****)0x4bf20d;
                        __vbaFreeObj();
                        pppppfStack_748 = &ppppfStack_64c;
                        ppppfStack_74c = (float ****)appppfStack_63c;
                        ppppfStack_750 = (float ****)appppfStack_62c;
                        pppppfStack_754 = &ppppfStack_61c;
                        pppppfStack_758 = (float *****)0x4;
                        pppppfStack_75c = (float *****)0x4bf22e;
                        __vbaFreeVarList();
                        sVar18 = DAT_0050b33a + 1;
                        ppppppfVar26 = (float ******)0x0;
                        if (!SCARRY2(DAT_0050b33a,1)) {
                          DAT_0050b33a = sVar18;
                          if ((DAT_0050b194 == (short *)0x0) || (*DAT_0050b194 != 1)) {
                            pppppfStack_718 = (float *****)0x4bf281;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            iVar20 = *(int *)(DAT_0050b194 + 10);
                            if (*(uint *)(DAT_0050b194 + 8) <= (uint)(sVar18 - iVar20)) {
                              pppppfStack_718 = (float *****)0x4bf26e;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = (sVar18 - iVar20) * 2;
                          }
                          *(short *)(*(int *)(DAT_0050b194 + 6) + iVar20) = (short)pppppfStack_5d8;
                          if ((DAT_0050b198 == (short *)0x0) || (*DAT_0050b198 != 1)) {
                            pppppfStack_718 = (float *****)0x4bf2c1;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            iVar23 = (int)(short)pppppfStack_5d8;
                            iVar20 = *(int *)(DAT_0050b198 + 10);
                            if (*(uint *)(DAT_0050b198 + 8) <= (uint)(iVar23 - iVar20)) {
                              pppppfStack_718 = (float *****)0x4bf2b4;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = (iVar23 - iVar20) * 2;
                          }
                          *(undefined2 *)(*(int *)(DAT_0050b198 + 6) + iVar20) = 1;
                          if (DAT_0050b420 == (float ******)0x0) {
                            pppppfStack_718 = (float *****)&DAT_0050b420;
                            ppppfStack_71c = (float ****)&DAT_00408c88;
                            pppppfStack_720 = (float *****)0x4bf2e9;
                            __vbaNew2();
                          }
                          pppppfStack_718 = (float *****)DAT_0050b420;
                          ppppfStack_71c = (float ****)0x4bf2f7;
                          ppppfStack_71c = (float ****)(*(code *)(*DAT_0050b420)[0xea])();
                          pppppfStack_720 = (float *****)&pppppfStack_6dc;
                          pppppfStack_724 = (float *****)0x4bf305;
                          __vbaObjSet();
                          if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
                            pppppfStack_724 = (float *****)0x4bf337;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            iVar23 = (int)(short)pppppfStack_5d8;
                            iVar20 = *(int *)(DAT_0050b394 + 10);
                            if (*(uint *)(DAT_0050b394 + 8) <= (uint)(iVar23 - iVar20)) {
                              pppppfStack_724 = (float *****)0x4bf327;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = (iVar23 - iVar20) * 0x18;
                          }
                          pppppfStack_724 = (float *****)(*(int *)(DAT_0050b394 + 6) + iVar20);
                          ppppfStack_728 = (float ****)0xc;
                          pppppfStack_72c = (float *****)0x4bf34b;
                          __vbaStrFixstr();
                          pppppfStack_72c = (float *****)0x4bf352;
                          pppppfStack_72c = (float *****)(*(code *)pppppfVar12)();
                          pcVar17 = Ordinal_519_exref;
                          ppppfStack_730 = (float ****)0x4bf35b;
                          Ordinal_519();
                          ppppfStack_730 = (float ****)0x4bf362;
                          (*(code *)pppppfVar12)();
                          if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
                            ppppfStack_730 = (float ****)0x4bf39c;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            iVar23 = (int)(short)pppppfStack_5d8;
                            iVar20 = *(int *)(DAT_0050b394 + 10);
                            if (*(uint *)(DAT_0050b394 + 8) <= (uint)(iVar23 - iVar20)) {
                              ppppfStack_730 = (float ****)0x4bf388;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = (iVar23 - iVar20) * 0x18;
                          }
                          ppppfStack_734 = (float ****)(*(int *)(DAT_0050b394 + 6) + iVar20);
                          ppppfStack_730 = (float ****)pppppfStack_5dc;
                          pppppfStack_738 = (float *****)0xc;
                          pppppfStack_73c = (float *****)0x4bf3b4;
                          __vbaLsetFixstr();
                          pppppfStack_5e0 = (float *****)0x0;
                          pppppfStack_73c = (float *****)0x4bf3c3;
                          (*(code *)pppppfVar12)();
                          ppppppfVar26 = (float ******)__vbaFreeStr_exref;
                          pppppfStack_73c = (float *****)0x4bf3ce;
                          __vbaFreeStr();
                          pppppfStack_73c = pppppfStack_5cc;
                          pwStack_740 = L"";
                          pppppfStack_744 = (float *****)0x4bf3dd;
                          iVar20 = __vbaStrCmp();
                          if (iVar20 != 0) {
                            pppppfStack_744 = (float *****)&DAT_00412d2c;
                            pppppfStack_748 = pppppfStack_5cc;
                            ppppfStack_74c = (float ****)0x4bf3f0;
                            __vbaStrCat();
                            ppppfStack_74c = (float ****)0x4bf3f7;
                            ppppfStack_74c = (float ****)(*(code *)pppppfVar12)();
                            ppppfStack_750 = (float ****)&DAT_00412d38;
                            pppppfStack_754 = (float *****)0x4bf403;
                            __vbaStrCat();
                            pppppfStack_754 = (float *****)0x4bf40a;
                            (*(code *)pppppfVar12)();
                            pppppfStack_754 = (float *****)0x4bf40f;
                            __vbaFreeStr();
                          }
                          if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
                            pppppfStack_744 = (float *****)0x4bf455;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            uStack_6d0 = (int)(short)ppppfStack_5d0 - *(int *)(DAT_0050b394 + 10);
                            if (*(uint *)(DAT_0050b394 + 8) <= uStack_6d0) {
                              pppppfStack_744 = (float *****)0x4bf43b;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = uStack_6d0 * 0x18;
                          }
                          pppppfStack_744 = (float *****)(*(int *)(DAT_0050b394 + 6) + iVar20);
                          pppppfStack_748 = (float *****)0xc;
                          ppppfStack_74c = (float ****)0x4bf469;
                          __vbaStrFixstr();
                          ppppfStack_74c = (float ****)0x4bf470;
                          ppppfStack_74c = (float ****)(*(code *)pppppfVar12)();
                          ppppfStack_750 = (float ****)0x4bf473;
                          Ordinal_519();
                          ppppfStack_750 = (float ****)0x4bf47a;
                          (*(code *)pppppfVar12)();
                          if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
                            ppppfStack_750 = (float ****)0x4bf4c0;
                            iVar20 = __vbaGenerateBoundsError();
                          }
                          else {
                            uStack_6d4 = (int)(short)ppppfStack_5d0 - *(int *)(DAT_0050b394 + 10);
                            if (*(uint *)(DAT_0050b394 + 8) <= uStack_6d4) {
                              ppppfStack_750 = (float ****)0x4bf4a6;
                              __vbaGenerateBoundsError();
                            }
                            iVar20 = uStack_6d4 * 0x18;
                          }
                          pppppfStack_754 = (float *****)(*(int *)(DAT_0050b394 + 6) + iVar20);
                          ppppfStack_750 = (float ****)pppppfStack_5dc;
                          pppppfStack_758 = (float *****)0xc;
                          pppppfStack_75c = (float *****)0x4bf4d8;
                          __vbaLsetFixstr();
                          pppppfStack_5e0 = (float *****)0x0;
                          pppppfStack_75c = (float *****)0x4bf4e7;
                          (*(code *)pppppfVar12)();
                          pppppfStack_75c = (float *****)0x4bf4ec;
                          __vbaFreeStr();
                          pppppfStack_75c = pppppfStack_5c0;
                          pwStack_760 = L"";
                          puStack_764 = (undefined *)0x4bf4fb;
                          iVar20 = __vbaStrCmp();
                          if (iVar20 != 0) {
                            puStack_764 = &DAT_00412d2c;
                            pppppfStack_768 = pppppfStack_5c0;
                            pppppfStack_76c = (float *****)0x4bf50e;
                            __vbaStrCat();
                            pppppfStack_76c = (float *****)0x4bf515;
                            pppppfStack_76c = (float *****)(*(code *)pppppfVar12)();
                            ppppfStack_770 = (float ****)&DAT_00412d38;
                            pppppfStack_774 = (float *****)0x4bf521;
                            __vbaStrCat();
                            pppppfStack_774 = (float *****)0x4bf528;
                            (*(code *)pppppfVar12)();
                            pppppfStack_774 = (float *****)0x4bf52d;
                            __vbaFreeStr();
                          }
                          puStack_764 = (undefined *)0x0;
                          pppppfStack_768 = (float *****)0x4;
                          ppppfStack_770 = (float ****)&ppppfStack_61c;
                          pppppfStack_76c = pppppfStack_6dc;
                          pppppfStack_774 = (float *****)0x4bf542;
                          puStack_764 = (undefined *)__vbaLateIdCallLd();
                          pppppfStack_768 = (float *****)0x4bf54c;
                          iVar20 = __vbaI4Var();
                          if (!SCARRY4(iVar20,1)) {
                            ppppfStack_66c = (float ****)0x3;
                            ppppfStack_728 = (float ****)0x4;
                            pppppfStack_724 = (float *****)0x3;
                            pppppfStack_720 = pppppfStack_668;
                            pppppfStack_72c = pppppfStack_6dc;
                            pppppfStack_718 = pppppfStack_660;
                            ppppfStack_730 = (float ****)0x4bf591;
                            ppppfStack_71c = (float ****)(iVar20 + 1);
                            pwStack_664 = (wchar_t *)(iVar20 + 1);
                            __vbaLateIdSt();
                            ppppfStack_730 = (float ****)0x4bf59a;
                            __vbaFreeVar();
                            ppppfStack_730 = (float ****)0x4bf59f;
                            FUN_0044fdc0();
                            ppppfStack_730 = (float ****)0x4bf5a6;
                            (*(code *)pppppfVar12)();
                            ppppppfVar26 = (float ******)Ordinal_536_exref;
                            if (!SBORROW2(DAT_0050b33a,1)) {
                              ppppfStack_614 =
                                   (float ****)CONCAT22(ppppfStack_614._2_2_,DAT_0050b33a + -1);
                              pppppfStack_718 = &ppppfStack_61c;
                              ppppfStack_684 = (float ****)&ppppfStack_5d0;
                              ppppfStack_61c = (float ****)0x2;
                              appppfStack_67c[0] = (float ****)0x4002;
                              ppppfStack_68c = (float ****)0x4002;
                              ppppfStack_71c = (float ****)0x4bf5f1;
                              pppppfStack_674 = (float *****)&pppppfStack_5d8;
                              Ordinal_536();
                              ppppfStack_71c = (float ****)0x4bf5f8;
                              ppppfStack_71c = (float ****)(*(code *)pppppfVar12)();
                              pppppfStack_720 = (float *****)0x412d40;
                              pppppfStack_724 = (float *****)0x4bf604;
                              __vbaStrCat();
                              pppppfStack_724 = (float *****)0x4bf60b;
                              pppppfStack_724 = (float *****)(*(code *)pppppfVar12)();
                              ppppfStack_728 = (float ****)appppfStack_67c;
                              pppppfStack_72c = (float *****)0x4bf615;
                              Ordinal_536();
                              pppppfStack_72c = (float *****)0x4bf61c;
                              pppppfStack_72c = (float *****)(*(code *)pppppfVar12)();
                              ppppfStack_730 = (float ****)0x4bf61f;
                              Ordinal_519();
                              ppppfStack_730 = (float ****)0x4bf626;
                              ppppfStack_730 = (float ****)(*(code *)pppppfVar12)();
                              ppppfStack_734 = (float ****)0x4bf62d;
                              __vbaStrCat();
                              ppppfStack_734 = (float ****)0x4bf634;
                              ppppfStack_734 = (float ****)(*(code *)pppppfVar12)();
                              pppppfStack_738 = pppppfStack_5cc;
                              pppppfStack_73c = (float *****)0x4bf63f;
                              __vbaStrCat();
                              pppppfStack_73c = (float *****)0x4bf646;
                              pppppfStack_73c = (float *****)(*(code *)pppppfVar12)();
                              pwStack_740 = L"  to N";
                              pppppfStack_744 = (float *****)0x4bf652;
                              __vbaStrCat();
                              pppppfStack_744 = (float *****)0x4bf659;
                              pppppfStack_744 = (float *****)(*(code *)pppppfVar12)();
                              pppppfStack_748 = &ppppfStack_68c;
                              ppppfStack_74c = (float ****)0x4bf663;
                              Ordinal_536();
                              ppppfStack_74c = (float ****)0x4bf66a;
                              ppppfStack_74c = (float ****)(*(code *)pppppfVar12)();
                              ppppfStack_750 = (float ****)0x4bf66d;
                              Ordinal_519();
                              ppppfStack_750 = (float ****)0x4bf674;
                              ppppfStack_750 = (float ****)(*(code *)pppppfVar12)();
                              pppppfStack_754 = (float *****)0x4bf67d;
                              __vbaStrCat();
                              pppppfStack_754 = (float *****)0x4bf684;
                              pppppfStack_754 = (float *****)(*(code *)pppppfVar12)();
                              pppppfStack_758 = pppppfStack_5c0;
                              pppppfStack_75c = (float *****)0x4bf68b;
                              __vbaStrCat();
                              pppppfStack_75c = (float *****)0x4bf692;
                              pppppfStack_75c = (float *****)(*(code *)pppppfVar12)();
                              pwStack_760 = L":  Length = ";
                              puStack_764 = (undefined *)0x4bf69a;
                              pwStack_644 = (wchar_t *)__vbaStrCat();
                              ppppfStack_64c = (float ****)0x8;
                              appppfStack_62c[0] = (float ****)0x8;
                              pppppfStack_694 = (float *****)&pppppfStack_5d4;
                              uStack_624 = uStack_608;
                              puStack_764 = (undefined *)0x1;
                              pppppfStack_76c = appppfStack_62c;
                              pppppfStack_768 = (float *****)&DAT_00000001;
                              ppppfStack_770 = apppfStack_69c;
                              pppppfStack_774 = appppfStack_63c;
                              uStack_608 = 0;
                              apppfStack_69c[0] = (float ***)0x4004;
                              ppppfStack_778 = (float ****)0x4bf6f3;
                              Ordinal_660();
                              ppppfStack_778 = (float ****)&ppppfStack_64c;
                              ppppfStack_77c = (float ****)appppfStack_63c;
                              ppppfStack_780 = apppfStack_65c;
                              pppppfStack_784 = (float *****)0x4bf70e;
                              pppppfStack_784 = (float *****)__vbaVarCat();
                              pppppfStack_788 = (float *****)0x4bf715;
                              __vbaStrVarMove();
                              pppppfStack_788 = (float *****)0x4bf71e;
                              (*(code *)pppppfVar12)();
                              pppppfStack_788 = (float *****)&uStack_608;
                              pppppfStack_78c = (float *****)&uStack_604;
                              pppppfStack_790 = (float *****)&pppppfStack_600;
                              pppppfStack_794 = (float *****)&pppppfStack_5fc;
                              pppppfStack_798 = &ppppfStack_5f8;
                              pppppfStack_79c = (float *****)&pppppfStack_5f4;
                              pppppfStack_7a0 = (float *****)&uStack_5f0;
                              pppppfStack_7a4 = (float *****)&uStack_5ec;
                              ppuStack_7a8 = &puStack_5e8;
                              ppppfStack_7ac = (float ****)&ppppfStack_5e4;
                              pppppfStack_7b0 = (float *****)&pppppfStack_5e0;
                              pppppfStack_7b4 = (float *****)&pppppfStack_5dc;
                              pppppfStack_7b8 = (float *****)0xc;
                              pppppfStack_7bc = (float *****)0x4bf756;
                              __vbaFreeStrList();
                              pppppfStack_7bc = (float *****)apppfStack_65c;
                              __vbaFreeVarList(5,&ppppfStack_61c,appppfStack_62c,&ppppfStack_64c,
                                               appppfStack_63c);
                              pppppfStack_78c = (float *****)(int)DAT_0050b33a;
                              ppppfStack_66c = (float ****)0x3;
                              pppppfStack_794 = (float *****)0x3;
                              pppppfStack_790 = pppppfStack_668;
                              ppppfStack_684 = (float ****)0x0;
                              ppppfStack_68c = (float ****)0x3;
                              pppppfStack_788 = pppppfStack_660;
                              pppppfStack_7a4 = (float *****)0x3;
                              pppppfStack_7a0 = pppppfStack_688;
                              pppppfStack_79c = (float *****)0x0;
                              pppppfStack_798 = pppppfStack_680;
                              pppppfStack_7b8 = (float *****)0x2;
                              pppppfStack_7bc = (float *****)0x41;
                              pppppfStack_7b4 = (float *****)0x4008;
                              pppppfStack_7b0 = (float *****)ppppfStack_6a8;
                              ppppfStack_7ac = (float ****)&DAT_0050b34c;
                              ppuStack_7a8 = (undefined **)fStack_6a0;
                              pwStack_664 = (wchar_t *)pppppfStack_78c;
                              __vbaLateIdCallSt(pppppfStack_6dc);
                              pppppfStack_78c = (float *****)&pppppfStack_6dc;
                              pppppfStack_788 = (float *****)0x0;
                              pppppfStack_790 = (float *****)0x4bf82a;
                              __vbaObjSetAddref();
                              goto LAB_004bf961;
                            }
                          }
                        }
LAB_004bf9a1:
                        pppppfStack_718 = (float *****)0x4bf9a7;
                        __vbaErrorOverflow();
                        pppppfStack_724 = (float *****)&DAT_00402706;
                        ppppfStack_728 = ExceptionList;
                        pppppfStack_720 = (float *****)&pppppfStack_7bc;
                        ppppfStack_71c = (float ****)&DAT_00402330;
                        ppppfStack_734 = (float ****)0x0;
                        pppppfStack_738 = (float *****)0x0;
                        pppppfStack_73c = (float *****)0x0;
                        pwStack_760 = (wchar_t *)0x0;
                        puStack_764 = (undefined *)0x0;
                        pppppfStack_768 = (float *****)0x0;
                        pppppfStack_76c = (float *****)0x0;
                        pppppfStack_790 = (float *****)0x0;
                        ExceptionList = &ppppfStack_728;
                        pppppfStack_7bc = pppppfVar12;
                        pppppfStack_7b8 = (float *****)ppppppfVar26;
                        pppppfStack_7b4 = (float *****)pcVar17;
                        ppppppfVar24 = &pppppfStack_7bc;
                        pppppfStack_718 = (float *****)&pppppfStack_5a0;
                        if (DAT_0050b420 == (float ******)0x0) {
                          ExceptionList = &ppppfStack_728;
                          pppppfStack_718 = (float *****)&pppppfStack_5a0;
                          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                          ppppppfVar24 = (float ******)pppppfStack_720;
                        }
                        pppppfStack_720 = (float *****)ppppppfVar24;
                        __vbaObjSetAddref(&pppppfStack_790,DAT_0050b420);
                        uVar13 = (*(code *)(*pppppfStack_790)[0xdf])(pppppfStack_790);
                        piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                        iVar20 = (**(code **)(*piVar14 + 0x9c))(piVar14,0);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x9c);
                        }
                        __vbaFreeObj();
                        uVar13 = (*(code *)(*pppppfStack_790)[0xd9])(pppppfStack_790);
                        piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                        iVar20 = (**(code **)(*piVar14 + 0x9c))(piVar14,0xffffffff);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x9c);
                        }
                        __vbaFreeObj();
                        uVar13 = (*(code *)(*pppppfStack_790)[0xdb])(pppppfStack_790);
                        piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                        iVar20 = (**(code **)(*piVar14 + 0x9c))(piVar14,0);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x9c);
                        }
                        __vbaFreeObj();
                        uVar13 = (*(code *)(*pppppfStack_790)[0xd3])(pppppfStack_790);
                        piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                        iVar20 = (**(code **)(*piVar14 + 0x9c))(piVar14,0);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x9c);
                        }
                        __vbaFreeObj();
                        pwVar2 = pwStack_740;
                        pppppfVar12 = pppppfStack_748;
                        uVar13 = (*(code *)(*pppppfStack_790)[0xea])
                                           (pppppfStack_790,0x80010007,0xb,pppppfStack_748,0,
                                            pwStack_740);
                        uVar13 = __vbaObjSet(&ppppfStack_734,uVar13);
                        __vbaLateIdSt(uVar13);
                        __vbaFreeObj();
                        uVar13 = (*(code *)(*pppppfStack_790)[0xda])(pppppfStack_790);
                        piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                        iVar20 = (**(code **)(*piVar14 + 0xe8))(piVar14,&pwStack_760);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040dc58,0xe8);
                        }
                        bVar28 = (short)pwStack_760 == 0;
                        __vbaFreeObj();
                        if (bVar28) {
                          uVar13 = (*(code *)(*pppppfStack_790)[0xda])(pppppfStack_790);
                          piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                          iVar20 = (**(code **)(*piVar14 + 0x1ec))
                                             (piVar14,L"Shortest routes",10,pppppfVar12,0x80020004,
                                              pwVar2);
                          if (iVar20 < 0) {
                            __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040dc58,0x1ec);
                          }
                          __vbaFreeObj();
                          uVar13 = (*(code *)(*pppppfStack_790)[0xda])(pppppfStack_790);
                          piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                          pppppfStack_744 = (float *****)0x80020004;
                          iVar20 = (**(code **)(*piVar14 + 0x1ec))
                                             (piVar14,L"Iterations",10,pppppfVar12,0x80020004,pwVar2
                                             );
                          if (iVar20 < 0) {
                            __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040dc58,0x1ec);
                          }
                          __vbaFreeObj();
                        }
                        uVar13 = (*(code *)(*pppppfStack_790)[0xea])
                                           (pppppfStack_790,0x80010007,0xb,pppppfVar12,0,pwVar2);
                        uVar13 = __vbaObjSet(&ppppfStack_734,uVar13);
                        __vbaLateIdSt(uVar13);
                        __vbaFreeObj();
                        iVar20 = (*(code *)(*pppppfStack_790)[0x92])
                                           (pppppfStack_790,&ppppfStack_734);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x248);
                        }
                        __vbaLateIdSt(ppppfStack_734,0,8,pppppfVar12,L"arial",pwVar2);
                        __vbaFreeObj();
                        iVar20 = (*(code *)(*pppppfStack_790)[0x92])
                                           (pppppfStack_790,&ppppfStack_734);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x248);
                        }
                        __vbaLateIdSt(ppppfStack_734,2,2,pppppfVar12,6,pwVar2);
                        __vbaFreeObj();
                        iVar20 = (*(code *)(*pppppfStack_790)[0x1b])(pppppfStack_790,0xffffff);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x6c);
                        }
                        if (DAT_0050b420 == (float ******)0x0) {
                          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                        }
                        __vbaObjSetAddref(&ppppfStack_734,DAT_0050b420);
                        FUN_0048c990(&ppppfStack_734);
                        uVar13 = __vbaCastObj(ppppfStack_734,&DAT_0040b85c);
                        __vbaObjSet(&DAT_0050b420,uVar13);
                        __vbaFreeObj();
                        iVar20 = (*(code *)(*pppppfStack_790)[0x92])
                                           (pppppfStack_790,&ppppfStack_734);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x248);
                        }
                        __vbaLateIdSt(ppppfStack_734,3,0xb,pppppfVar12,0xffffffff,pwVar2);
                        __vbaFreeObj();
                        pppppfStack_744 = (float *****)0xa;
                        iVar20 = (*(code *)(*pppppfStack_790)[0x92])
                                           (pppppfStack_790,&ppppfStack_734);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x248);
                        }
                        __vbaLateIdSt(ppppfStack_734,2,2,pppppfVar12,pppppfStack_744,pwVar2);
                        __vbaFreeObj();
                        ppppfStack_74c = (float ****)0xb;
                        iVar20 = (*(code *)(*pppppfStack_790)[0x92])
                                           (pppppfStack_790,&ppppfStack_734);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x248);
                        }
                        __vbaLateIdSt(ppppfStack_734,3,ppppfStack_74c,pppppfVar12,0xffffffff,pwVar2)
                        ;
                        __vbaFreeObj();
                        iVar20 = (*(code *)(*pppppfStack_790)[0x4b])(pppppfStack_790,1);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,300);
                        }
                        if ((DAT_0050b334 == 2) || (DAT_0050b334 == 3)) {
                          __vbaStrCopy();
                        }
                        if (DAT_0050c53c == (float ******)0x0) {
                          __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                        }
                        ppppppfVar24 = DAT_0050c53c;
                        iVar20 = (*(code *)(*DAT_0050c53c)[6])(DAT_0050c53c,&ppppfStack_734);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,ppppppfVar24,&DAT_0040b410,0x18);
                        }
                        ppppfVar3 = ppppfStack_734;
                        iVar20 = (*(code *)(*ppppfStack_734)[0x26])(ppppfStack_734,&puStack_764);
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,ppppfVar3,&DAT_0040bb5c,0x98);
                        }
                        iVar20 = (*(code *)(*pppppfStack_790)[0xb9])
                                           (pppppfStack_790,DAT_0050b34c,&pppppfStack_768);
                        uVar29 = 0;
                        if (iVar20 < 0) {
                          __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0x2e4);
                        }
                        if ((uVar29 & 0xd) == 0) {
                          fVar1 = ((float)puStack_764 - (float)pppppfStack_768) *
                                  (float)_DAT_00401268;
                          if ((uVar29 & 0xd) == 0) {
                            pppppfStack_7a0 = (float *****)fVar1;
                            iVar20 = (*(code *)(*pppppfStack_790)[0x39])(pppppfStack_790,fVar1);
                            if (iVar20 < 0) {
                              __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0xe4);
                            }
                            __vbaFreeObj();
                            if (DAT_0050b420 == (float ******)0x0) {
                              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                            }
                            __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,DAT_0050b34c);
                            iVar20 = (*(code *)(*pppppfStack_790)[0x3a])
                                               (pppppfStack_790,&puStack_764);
                            if (iVar20 < 0) {
                              __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0xe8);
                            }
                            if (DAT_0050c53c == (float ******)0x0) {
                              __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                            }
                            ppppppfVar24 = DAT_0050c53c;
                            iVar20 = (*(code *)(*DAT_0050c53c)[6])(DAT_0050c53c,&ppppfStack_734);
                            if (iVar20 < 0) {
                              __vbaHresultCheckObj(iVar20,ppppppfVar24,&DAT_0040b410,0x18);
                            }
                            ppppfVar3 = ppppfStack_734;
                            iVar20 = (*(code *)(*ppppfStack_734)[0x26])
                                               (ppppfStack_734,&pppppfStack_768);
                            if (iVar20 < 0) {
                              __vbaHresultCheckObj(iVar20,ppppfVar3,&DAT_0040bb5c,0x98);
                            }
                            iVar20 = (*(code *)(*pppppfStack_790)[0x3a])
                                               (pppppfStack_790,&pppppfStack_76c);
                            uVar29 = 0;
                            if (iVar20 < 0) {
                              __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0xe8);
                            }
                            if (DAT_0050b420 == (float ******)0x0) {
                              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                            }
                            ppppppfVar24 = DAT_0050b420;
                            if ((uVar29 & 0xd) == 0) {
                              iVar20 = (*(code *)(*DAT_0050b420)[0xb2])
                                                 (DAT_0050b420,4,0x44960000,puStack_764,
                                                  (float)pppppfStack_768 - _DAT_004020e0,
                                                  pppppfStack_76c,0);
                              if (iVar20 < 0) {
                                __vbaHresultCheckObj(iVar20,ppppppfVar24,&DAT_0040b430,0x2c8);
                              }
                              __vbaFreeObj();
                              iVar20 = (*(code *)(*pppppfStack_790)[0x3a])
                                                 (pppppfStack_790,&puStack_764);
                              uVar29 = 0;
                              if (iVar20 < 0) {
                                __vbaHresultCheckObj(iVar20,pppppfStack_790,&DAT_0040b430,0xe8);
                              }
                              uVar13 = (*(code *)(*pppppfStack_790)[0xd9])(pppppfStack_790);
                              piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                              ppppppfVar24 = (float ******)
                                             ((float)puStack_764 * (float)_DAT_00401280);
                              if ((uVar29 & 0xd) == 0) {
                                pppppfStack_7a4 = (float *****)ppppppfVar24;
                                iVar20 = (**(code **)(*piVar14 + 0x7c))(piVar14,ppppppfVar24);
                                if (iVar20 < 0) {
                                  __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x7c);
                                }
                                __vbaFreeObj();
                                if (DAT_0050c53c == (float ******)0x0) {
                                  __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                                }
                                ppppppfVar26 = DAT_0050c53c;
                                iVar20 = (*(code *)(*DAT_0050c53c)[6])(DAT_0050c53c,&ppppfStack_734)
                                ;
                                if (iVar20 < 0) {
                                  __vbaHresultCheckObj(iVar20,ppppppfVar26,&DAT_0040b410,0x18);
                                }
                                ppppfVar3 = ppppfStack_734;
                                iVar20 = (*(code *)(*ppppfStack_734)[0x26])
                                                   (ppppfStack_734,&puStack_764);
                                if (iVar20 < 0) {
                                  __vbaHresultCheckObj(iVar20,ppppfVar3,&DAT_0040bb5c,0x98);
                                }
                                uVar13 = (*(code *)(*pppppfStack_790)[0xd9])(pppppfStack_790);
                                piVar14 = (int *)__vbaObjSet(&pppppfStack_738,uVar13);
                                iVar20 = (**(code **)(*piVar14 + 0x80))(piVar14,&pppppfStack_768);
                                uVar29 = 0;
                                if (iVar20 < 0) {
                                  __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x80);
                                }
                                uVar13 = (*(code *)(*pppppfStack_790)[0xd9])(pppppfStack_790);
                                piVar14 = (int *)__vbaObjSet(&pppppfStack_73c,uVar13);
                                if ((uVar29 & 0xd) == 0) {
                                  fVar1 = ((float)puStack_764 - (float)pppppfStack_768) *
                                          (float)_DAT_00401268;
                                  if ((uVar29 & 0xd) == 0) {
                                    ppuStack_7a8 = (undefined **)fVar1;
                                    iVar20 = (**(code **)(*piVar14 + 0x74))
                                                       (piVar14,ppppppfVar24,fVar1);
                                    if (iVar20 < 0) {
                                      __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x74);
                                    }
                                    __vbaFreeObjList(3,&ppppfStack_734,&pppppfStack_738,
                                                     &pppppfStack_73c);
                                    uVar13 = (*(code *)(*pppppfStack_790)[0xd9])(pppppfStack_790);
                                    piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                                    iVar20 = (**(code **)(*piVar14 + 0x9c))(piVar14,0xffffffff);
                                    if (iVar20 < 0) {
                                      __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x9c);
                                    }
                                    __vbaFreeObj();
                                    iVar20 = (*(code *)(*pppppfStack_790)[0x3a])
                                                       (pppppfStack_790,&puStack_764);
                                    uVar29 = 0;
                                    if (iVar20 < 0) {
                                      __vbaHresultCheckObj
                                                (iVar20,pppppfStack_790,&DAT_0040b430,0xe8);
                                    }
                                    if ((uVar29 & 0xd) == 0) {
                                      DAT_0050b32e = __vbaFpI2();
                                      if (DAT_0050c53c == (float ******)0x0) {
                                        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                                      }
                                      ppppppfVar24 = DAT_0050c53c;
                                      iVar20 = (*(code *)(*DAT_0050c53c)[6])
                                                         (DAT_0050c53c,&ppppfStack_734);
                                      if (iVar20 < 0) {
                                        __vbaHresultCheckObj(iVar20,ppppppfVar24,&DAT_0040b410,0x18)
                                        ;
                                      }
                                      ppppfVar3 = ppppfStack_734;
                                      iVar20 = (*(code *)(*ppppfStack_734)[0x14])
                                                         (ppppfStack_734,&puStack_764);
                                      uVar29 = 0;
                                      if (iVar20 < 0) {
                                        __vbaHresultCheckObj(iVar20,ppppfVar3,&DAT_0040bb5c,0x50);
                                      }
                                      if (DAT_0050b420 == (float ******)0x0) {
                                        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                                      }
                                      uVar13 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                                      piVar14 = (int *)__vbaObjSet(&pppppfStack_738,uVar13);
                                      puVar31 = (undefined4 *)
                                                ((float)puStack_764 * (float)_DAT_00401760);
                                      if ((uVar29 & 0xd) == 0) {
                                        ppppfStack_7ac = (float ****)puVar31;
                                        iVar20 = (**(code **)(*piVar14 + 0x7c))(piVar14,puVar31);
                                        if (iVar20 < 0) {
                                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x7c);
                                        }
                                        __vbaFreeObjList(2,&ppppfStack_734,&pppppfStack_738);
                                        if (DAT_0050c53c == (float ******)0x0) {
                                          __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                                        }
                                        ppppppfVar24 = DAT_0050c53c;
                                        iVar20 = (*(code *)(*DAT_0050c53c)[6])
                                                           (DAT_0050c53c,&ppppfStack_734);
                                        if (iVar20 < 0) {
                                          __vbaHresultCheckObj
                                                    (iVar20,ppppppfVar24,&DAT_0040b410,0x18);
                                        }
                                        ppppfVar3 = ppppfStack_734;
                                        iVar20 = (*(code *)(*ppppfStack_734)[0x26])
                                                           (ppppfStack_734,&puStack_764);
                                        if (iVar20 < 0) {
                                          __vbaHresultCheckObj(iVar20,ppppfVar3,&DAT_0040bb5c,0x98);
                                        }
                                        if (DAT_0050b420 == (float ******)0x0) {
                                          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                                        }
                                        uVar13 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                                        piVar14 = (int *)__vbaObjSet(&pppppfStack_738,uVar13);
                                        iVar20 = (**(code **)(*piVar14 + 0x80))
                                                           (piVar14,&pppppfStack_768);
                                        uVar29 = 0;
                                        if (iVar20 < 0) {
                                          __vbaHresultCheckObj(iVar20,piVar14,&DAT_0040c3dc,0x80);
                                        }
                                        if (DAT_0050b420 == (float ******)0x0) {
                                          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                                        }
                                        uVar13 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                                        piVar14 = (int *)__vbaObjSet(&pppppfStack_73c,uVar13);
                                        if ((uVar29 & 0xd) == 0) {
                                          fVar1 = ((float)puStack_764 - (float)pppppfStack_768) *
                                                  (float)_DAT_00401268;
                                          if ((uVar29 & 0xd) == 0) {
                                            pppppfStack_7b0 = (float *****)fVar1;
                                            iVar20 = (**(code **)(*piVar14 + 0x74))
                                                               (piVar14,puVar31,fVar1);
                                            if (iVar20 < 0) {
                                              __vbaHresultCheckObj
                                                        (iVar20,piVar14,&DAT_0040c3dc,0x74);
                                            }
                                            __vbaFreeObjList(3,&ppppfStack_734,&pppppfStack_738,
                                                             &pppppfStack_73c);
                                            if (DAT_0050b420 == (float ******)0x0) {
                                              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                                            }
                                            uVar13 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                                            piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                                            iVar20 = (**(code **)(*piVar14 + 0x9c))
                                                               (piVar14,0xffffffff);
                                            if (iVar20 < 0) {
                                              __vbaHresultCheckObj
                                                        (iVar20,piVar14,&DAT_0040c3dc,0x9c);
                                            }
                                            __vbaFreeObj();
                                            if (DAT_0050b334 == 0x17) {
                                              uVar13 = (*(code *)(*pppppfStack_790)[0xd9])
                                                                 (pppppfStack_790);
                                              piVar14 = (int *)__vbaObjSet(&ppppfStack_734,uVar13);
                                              iVar20 = (**(code **)(*piVar14 + 0x9c))(piVar14,0);
                                              if (iVar20 < 0) {
                                                __vbaHresultCheckObj
                                                          (iVar20,piVar14,&DAT_0040c3dc,0x9c);
                                              }
                                              __vbaFreeObj();
                                              DAT_0050b338 = 1;
                                              DAT_0050b334 = 3;
                                              FUN_004cd650();
                                            }
                                            __vbaObjSetAddref(&pppppfStack_790,0);
                                            __vbaFreeObj(&LAB_004c06a5);
                                            return;
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                        __vbaFPException();
                        return;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LAB_004bea4a:
  pppppfStack_504 = (float *****)ppppppfVar26;
  __vbaFPException();
  return;
}


