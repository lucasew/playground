/* requested 004ad9b0 entry 004ad9b0 name FUN_004ad9b0 size 8819 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ad9b0(void)

{
  int iVar1;
  undefined4 uVar2;
  short sVar3;
  short sVar4;
  short *psVar5;
  uint uVar6;
  undefined2 extraout_var;
  short ***pppsVar7;
  undefined2 extraout_var_00;
  code ***extraout_EDX;
  undefined2 extraout_var_01;
  code **extraout_EDX_00;
  undefined2 extraout_var_02;
  code **extraout_EDX_01;
  undefined2 extraout_var_03;
  undefined2 extraout_var_04;
  short ****ppppsVar8;
  short ****ppppsVar9;
  undefined2 uVar10;
  short sVar11;
  ushort uVar12;
  code ****ppppcVar13;
  short **ppsVar14;
  uint uVar15;
  int iVar16;
  short sVar17;
  code ****unaff_EDI;
  int iVar18;
  code **ppcVar19;
  code ****ppppcVar20;
  code ***pppcVar21;
  code ****ppppcVar22;
  code ****ppppcVar23;
  short *****pppppsVar24;
  int iVar25;
  code *pcVar26;
  bool bVar27;
  ushort in_FPUStatusWord;
  float10 fVar28;
  int iStack_1f0;
  float fStack_1ec;
  code ****ppppcStack_1d4;
  code ****ppppcStack_1d0;
  code ****ppppcStack_1cc;
  undefined1 *puStack_1c8;
  code *pcStack_1c4;
  int iStack_1c0;
  int iStack_1bc;
  int iStack_1b8;
  code ****ppppcStack_1b4;
  undefined8 uStack_1b0;
  code ****ppppcStack_1a8;
  code ***pppcStack_1a4;
  code ****ppppcStack_1a0;
  code ****ppppcStack_19c;
  code ****ppppcStack_198;
  code ****ppppcStack_194;
  code ****ppppcStack_190;
  undefined4 uStack_18c;
  short *****pppppsStack_188;
  short ****ppppsStack_184;
  code ****ppppcStack_180;
  code ***pppcStack_17c;
  code ***pppcStack_154;
  short local_134;
  short local_12c;
  short local_11c;
  short local_f4;
  short local_ec;
  short local_d4;
  code **local_ac [2];
  undefined2 *local_a4;
  short ****local_9c [2];
  short *****local_94;
  short ***local_8c [2];
  int local_84;
  short ****local_7c [4];
  code ***local_6c;
  code ***local_68;
  float local_64;
  code ****local_60;
  float local_5c;
  code ****local_58;
  float local_54;
  code ****local_50;
  code ****local_4c;
  code ****local_48;
  code ****local_44;
  code ****local_40;
  float local_3c;
  undefined4 local_38;
  uint local_34;
  code ****local_30;
  undefined4 local_2c;
  float local_28;
  code ***local_24 [2];
  code ****local_1c;
  uint local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffe88;
  local_8 = &DAT_00402258;
  ppppcVar13 = (code ****)0x0;
  local_18 = 0;
  local_24[0] = (code ***)0x0;
  local_40 = (code ****)0x0;
  local_44 = (code ****)0x0;
  local_58 = (code ****)0x0;
  local_64 = 0.0;
  local_68 = (code ***)0x0;
  local_6c = (code ***)0x0;
  local_7c[0] = (short ****)0x0;
  local_8c[0] = (short ***)0x0;
  local_9c[0] = (short ****)0x0;
  local_ac[0] = (code **)0x0;
  sVar3 = DAT_0050b2c4;
  if (DAT_0050b2c8 == 1) {
    local_60 = (code ****)0x0;
    local_30 = (code ****)&DAT_00000001;
    local_18 = 1;
    unaff_EDI = (code ****)__vbaAryLock_exref;
    ExceptionList = &pvStack_14;
    uVar15 = local_18;
    local_c = &stack0xfffffe88;
    do {
      local_18 = uVar15;
      if (sVar3 < (short)local_18) goto LAB_004afa7b;
      sVar4 = DAT_0050b2c6;
      ppppcVar22 = local_30;
      while (ppppcVar13 = ppppcVar22, local_1c = ppppcVar22, (short)ppppcVar22 <= sVar4) {
        ppppcStack_180 = &local_6c;
        pppcStack_17c = DAT_0050b188;
        ppppsStack_184 = (short ****)0x4af610;
        (*(code *)unaff_EDI)();
        if ((local_6c == (code ***)0x0) || (*(short *)local_6c != 1)) {
          ppppsStack_184 = (short ****)0x4af63c;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppcVar19 = (code **)((int)(short)ppppcVar22 - (int)local_6c[5]);
          if (local_6c[4] <= ppcVar19) {
            ppppsStack_184 = (short ****)0x4af62e;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)ppcVar19 * 4;
        }
        pppppsStack_188 = (short *****)&local_68;
        local_94 = (short *****)((int)local_6c[3] + iVar18);
        ppppsStack_184 = DAT_0050b184;
        local_9c[0] = (short ****)0x4004;
        uStack_18c = (short *****)0x4af660;
        (*(code *)unaff_EDI)();
        if ((local_68 == (code ***)0x0) || (*(short *)local_68 != 1)) {
          uStack_18c = (short *****)0x4af68d;
          local_84 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = (int)(short)local_18;
          ppcVar19 = local_68[5];
          if (local_68[4] <= (code **)(iVar18 - (int)ppcVar19)) {
            uStack_18c = (short *****)0x4af67f;
            __vbaGenerateBoundsError();
          }
          local_84 = (iVar18 - (int)ppcVar19) * 4;
        }
        ppppcStack_190 = (code ****)local_8c;
        local_84 = (int)local_68[3] + local_84;
        uStack_18c = local_9c;
        ppppcStack_194 = (code ****)local_7c;
        local_8c[0] = (short ***)0x4004;
        ppppcStack_198 = (code ****)0x4af6b9;
        FUN_0042b040();
        ppppcVar13 = (code ****)__vbaAryUnlock_exref;
        ppppcStack_198 = &local_68;
        ppppcStack_19c = (code ****)0x4af6c5;
        __vbaAryUnlock();
        ppppcStack_19c = &local_6c;
        ppppcStack_1a0 = (code ****)0x4af6cb;
        __vbaAryUnlock();
        ppppcStack_1a0 = (code ****)local_7c;
        pppcStack_1a4 = (code ***)0x4af6d5;
        fVar28 = (float10)__vbaR4Var();
        local_5c = (float)fVar28;
        pppcStack_1a4 = (code ***)0x4af6e1;
        __vbaFreeVar();
        sVar11 = (short)local_60 + 1;
        unaff_EDI = (code ****)CONCAT22((short)((uint)unaff_EDI >> 0x10),sVar11);
        if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
        local_60 = unaff_EDI;
        if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
          pppcStack_17c = (code ***)0x4af724;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)sVar11 - *(int *)(DAT_0050b0f4 + 10));
          if (*(code *****)(DAT_0050b0f4 + 8) <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af713;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)ppppcVar13 * 8;
        }
        *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar18) = (double)local_5c;
        if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
          pppcStack_17c = (code ***)0x4af761;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)sVar11 - (int)DAT_0050b1f0[5]);
          if (DAT_0050b1f0[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af754;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)ppppcVar13 * 2;
        }
        if (SBORROW2((short)local_18,1)) goto LAB_004afc3d;
        iVar16 = (int)(short)((short)local_18 + -1) * (int)DAT_0050b2c6;
        sVar17 = (short)iVar16;
        if (sVar17 != iVar16) goto LAB_004afc3d;
        if (SCARRY2(sVar17,(short)local_1c)) goto LAB_004afc3d;
        *(short *)((int)DAT_0050b1f0[3] + iVar18) = sVar17 + (short)local_1c;
        if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
          pppcStack_17c = (code ***)0x4af7f8;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
            pppcStack_17c = (code ***)0x4af7d1;
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            ppsVar14 = DAT_0050b1f0[5];
            if (DAT_0050b1f0[4] <= (short **)((int)sVar11 - (int)ppsVar14)) {
              pppcStack_17c = (code ***)0x4af7c4;
              __vbaGenerateBoundsError();
            }
            iVar18 = ((int)sVar11 - (int)ppsVar14) * 2;
          }
          uVar15 = (int)*(short *)((int)DAT_0050b1f0[3] + iVar18) - *(int *)(DAT_0050b1f8 + 10);
          if (*(uint *)(DAT_0050b1f8 + 8) <= uVar15) {
            pppcStack_17c = (code ***)0x4af7f1;
            __vbaGenerateBoundsError();
          }
          iVar18 = uVar15 * 2;
        }
        ppppcStack_180 = &local_6c;
        *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
        pppcStack_17c = DAT_0050b188;
        ppppsStack_184 = (short ****)0x4af819;
        __vbaAryLock();
        if ((local_6c == (code ***)0x0) || (*(short *)local_6c != 1)) {
          ppppsStack_184 = (short ****)0x4af846;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = (int)(short)local_1c;
          ppcVar19 = local_6c[5];
          if (local_6c[4] <= (code **)(iVar18 - (int)ppcVar19)) {
            ppppsStack_184 = (short ****)0x4af838;
            __vbaGenerateBoundsError();
          }
          iVar18 = (iVar18 - (int)ppcVar19) * 4;
        }
        pppppsStack_188 = (short *****)&local_68;
        local_94 = (short *****)((int)local_6c[3] + iVar18);
        ppppsStack_184 = DAT_0050b184;
        local_9c[0] = (short ****)0x4004;
        uStack_18c = (short *****)0x4af86a;
        __vbaAryLock();
        if ((local_68 == (code ***)0x0) || (*(short *)local_68 != 1)) {
          uStack_18c = (short *****)0x4af897;
          local_84 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = (int)(short)local_18;
          ppcVar19 = local_68[5];
          if (local_68[4] <= (code **)(iVar18 - (int)ppcVar19)) {
            uStack_18c = (short *****)0x4af889;
            __vbaGenerateBoundsError();
          }
          local_84 = (iVar18 - (int)ppcVar19) * 4;
        }
        ppppcStack_190 = (code ****)local_8c;
        local_84 = (int)local_68[3] + local_84;
        uStack_18c = local_9c;
        ppppcStack_194 = (code ****)local_7c;
        local_8c[0] = (short ***)0x4004;
        ppppcStack_198 = (code ****)0x4af8c3;
        FUN_0042b040();
        ppppcVar13 = (code ****)__vbaAryUnlock_exref;
        ppppcStack_198 = &local_68;
        ppppcStack_19c = (code ****)0x4af8cf;
        __vbaAryUnlock();
        ppppcStack_19c = &local_6c;
        ppppcStack_1a0 = (code ****)0x4af8d5;
        __vbaAryUnlock();
        ppppcStack_1a0 = (code ****)local_7c;
        pppcStack_1a4 = (code ***)0x4af8df;
        fVar28 = (float10)__vbaR4Var();
        local_5c = (float)fVar28;
        pppcStack_1a4 = (code ***)0x4af8eb;
        __vbaFreeVar();
        if ((DAT_0050b188 == (code ***)0x0) || (*(short *)DAT_0050b188 != 1)) {
          pppcStack_17c = (code ***)0x4af91c;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_1c - (int)DAT_0050b188[5]);
          if (DAT_0050b188[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af90c;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)ppppcVar13 * 4;
        }
        if ((DAT_0050b188 == (code ***)0x0) || (*(short *)DAT_0050b188 != 1)) {
          pppcStack_17c = (code ***)0x4af94f;
          iVar16 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_1c - (int)DAT_0050b188[5]);
          if (DAT_0050b188[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af93f;
            __vbaGenerateBoundsError();
          }
          iVar16 = (int)ppppcVar13 * 4;
        }
        *(float *)((int)DAT_0050b188[3] + iVar16) =
             *(float *)((int)DAT_0050b188[3] + iVar18) - local_5c;
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
        if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
          pppcStack_17c = (code ***)0x4af99d;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_18 - (int)DAT_0050b184[5]);
          if (DAT_0050b184[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af98d;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)ppppcVar13 * 4;
        }
        if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
          pppcStack_17c = (code ***)0x4af9d0;
          iVar16 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_18 - (int)DAT_0050b184[5]);
          if (DAT_0050b184[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af9c0;
            __vbaGenerateBoundsError();
          }
          iVar16 = (int)ppppcVar13 * 4;
        }
        *(float *)((int)DAT_0050b184[3] + iVar16) =
             *(float *)((int)DAT_0050b184[3] + iVar18) - local_5c;
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
        if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
          pppcStack_17c = (code ***)0x4afa20;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_18 - (int)DAT_0050b184[5]);
          if (DAT_0050b184[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4afa0f;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)ppppcVar13 * 4;
        }
        in_FPUStatusWord = 0;
        unaff_EDI = (code ****)__vbaAryLock_exref;
        if (*(float *)((int)DAT_0050b184[3] + iVar18) == _DAT_00401bc0) {
          local_30 = local_1c;
          break;
        }
        ppppcVar22 = (code ****)(uint)(ushort)((short)local_1c + 1);
        if (SCARRY2((short)local_1c,1)) goto LAB_004afc3d;
      }
      uVar15 = (uint)(ushort)((short)local_18 + 1);
    } while (!SCARRY2((short)local_18,1));
    goto LAB_004afc3d;
  }
  if (DAT_0050b2c8 == 2) {
    ppppcStack_180 = (code ****)(int)DAT_0050b2c4;
    pppcStack_17c = (code ***)0x0;
    ppppsStack_184 = (short ****)&DAT_00000001;
    uStack_18c = (short *****)&local_40;
    pppppsStack_188 = (short *****)0x2;
    ppppcStack_190 = (code ****)0x2;
    ppppcStack_194 = (code ****)0x80;
    ppppcStack_198 = (code ****)0x4aea50;
    ExceptionList = &pvStack_14;
    __vbaRedim();
    ppppcStack_19c = (code ****)(int)DAT_0050b2c6;
    ppppcStack_198 = (code ****)0x0;
    ppppcStack_1a0 = (code ****)&DAT_00000001;
    ppppcStack_1a8 = local_24;
    pppcStack_1a4 = (code ***)0x2;
    uStack_1b0 = 4.24399164517095e-314;
    ppppcStack_1b4 = (code ****)0x4aea6a;
    __vbaRedim();
    local_60 = (code ****)0x0;
    local_2c = _DAT_0050b2c4;
    local_38 = CONCAT22(local_38._2_2_,DAT_0050b2c6);
    ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
    do {
      uVar2 = _DAT_0050b2c4;
      local_28 = (float)_DAT_0050b134;
      local_34 = 0;
      local_44 = (code ****)0x0;
      local_48 = (code ****)0x0;
      local_18 = 1;
      uVar15 = local_18;
      while( true ) {
        local_18 = uVar15;
        pcVar26 = __vbaAryLock_exref;
        local_d4 = (short)uVar2;
        if (local_d4 < (short)local_18) break;
        if ((local_40 == (code ****)0x0) || (*(short *)local_40 != 1)) {
          pppcStack_17c = (code ***)0x4aeae6;
          iVar18 = (*(code *)ppppcVar23)();
        }
        else {
          unaff_EDI = (code ****)local_40[5];
          pppcVar21 = (code ***)((int)(short)local_18 - (int)unaff_EDI);
          if (local_40[4] <= pppcVar21) {
            pppcStack_17c = (code ***)0x4aeadc;
            (*(code *)ppppcVar23)();
          }
          iVar18 = (int)pppcVar21 * 2;
        }
        ppppcVar13 = (code ****)local_40[3];
        uVar6 = local_18;
        if (*(short *)((int)ppppcVar13 + iVar18) == 0) {
          sVar3 = DAT_0050b2c6;
          ppppcVar22 = (code ****)&DAT_00000001;
          while (sVar4 = (short)ppppcVar22, sVar4 <= sVar3) {
            if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
              pppcStack_17c = (code ***)0x4aeb49;
              iVar18 = __vbaGenerateBoundsError();
              uVar6 = local_18;
            }
            else {
              unaff_EDI = (code ****)local_24[0][5];
              ppppcVar13 = (code ****)((int)sVar4 - (int)unaff_EDI);
              if (local_24[0][4] <= ppppcVar13) {
                pppcStack_17c = (code ***)0x4aeb3b;
                __vbaGenerateBoundsError();
                uVar6 = local_18;
              }
              iVar18 = (int)ppppcVar13 * 2;
            }
            ppppcVar23 = ppppcVar22;
            if (*(short *)((int)local_24[0][3] + iVar18) == 0) {
              if (SBORROW2((short)uVar6,1)) goto LAB_004afc3d;
              iVar18 = (int)(short)((short)uVar6 + -1) * (int)DAT_0050b2c6;
              sVar11 = (short)iVar18;
              if (sVar11 != iVar18) goto LAB_004afc3d;
              sVar17 = sVar11 + sVar4;
              ppppcVar20 = (code ****)CONCAT22((short)(uVar6 >> 0x10),sVar17);
              if (SCARRY2(sVar11,sVar4)) goto LAB_004afc3d;
              if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
                pppcStack_17c = (code ***)0x4aebb3;
                __vbaGenerateBoundsError();
              }
              else {
                ppppcVar13 = (code ****)((int)sVar17 - *(int *)(DAT_0050b0e8 + 10));
                if (*(code *****)(DAT_0050b0e8 + 8) <= ppppcVar13) {
                  pppcStack_17c = (code ***)0x4aeba4;
                  __vbaGenerateBoundsError();
                }
              }
              pppcStack_17c = (code ***)0x4aebd1;
              fVar28 = (float10)__vbaFpR4();
              in_FPUStatusWord = 0;
              uVar6 = local_18;
              unaff_EDI = ppppcVar20;
              if (fVar28 < (float10)local_28) {
                if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
                  pppcStack_17c = (code ***)0x4aec0e;
                  iVar18 = __vbaGenerateBoundsError();
                }
                else {
                  ppppcVar13 = (code ****)((int)sVar17 - *(int *)(DAT_0050b0e8 + 10));
                  if (*(code *****)(DAT_0050b0e8 + 8) <= ppppcVar13) {
                    pppcStack_17c = (code ***)0x4aebff;
                    __vbaGenerateBoundsError();
                  }
                  iVar18 = (int)ppppcVar13 * 8;
                }
                local_34 = local_18;
                local_28 = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
                uVar6 = local_18;
                local_48 = ppppcVar20;
                local_44 = ppppcVar22;
              }
            }
            ppppcVar22 = (code ****)(uint)(ushort)(sVar4 + 1);
            if (SCARRY2(sVar4,1)) goto LAB_004afc3d;
          }
        }
        ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
        uVar15 = (uint)(ushort)((short)uVar6 + 1);
        if (SCARRY2((short)uVar6,1)) goto LAB_004afc3d;
      }
      if ((short)(ushort)local_48 < 1) break;
      ppppcStack_180 = &local_6c;
      pppcStack_17c = DAT_0050b188;
      ppppsStack_184 = (short ****)0x4aec81;
      __vbaAryLock();
      if ((local_6c == (code ***)0x0) || (*(short *)local_6c != 1)) {
        ppppsStack_184 = (short ****)0x4aecae;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        iVar18 = (int)(short)local_44;
        ppcVar19 = local_6c[5];
        if (local_6c[4] <= (code **)(iVar18 - (int)ppcVar19)) {
          ppppsStack_184 = (short ****)0x4aeca0;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (iVar18 - (int)ppcVar19) * 4;
      }
      pppppsStack_188 = (short *****)&local_68;
      local_94 = (short *****)((int)local_6c[3] + iVar18);
      ppppsStack_184 = DAT_0050b184;
      local_9c[0] = (short ****)0x4004;
      uStack_18c = (short *****)0x4aecd2;
      __vbaAryLock();
      if ((local_68 == (code ***)0x0) || (*(short *)local_68 != 1)) {
        uStack_18c = (short *****)0x4aecff;
        local_84 = (*(code *)ppppcVar23)();
      }
      else {
        iVar18 = (int)(short)local_34;
        ppcVar19 = local_68[5];
        if (local_68[4] <= (code **)(iVar18 - (int)ppcVar19)) {
          uStack_18c = (short *****)0x4aecf1;
          (*(code *)ppppcVar23)();
        }
        local_84 = (iVar18 - (int)ppcVar19) * 4;
      }
      ppppcStack_190 = (code ****)local_8c;
      local_84 = (int)local_68[3] + local_84;
      uStack_18c = local_9c;
      ppppcStack_194 = (code ****)local_7c;
      local_8c[0] = (short ***)0x4004;
      ppppcStack_198 = (code ****)0x4aed2b;
      FUN_0042b040();
      ppppcVar13 = (code ****)__vbaAryUnlock_exref;
      ppppcStack_198 = &local_68;
      ppppcStack_19c = (code ****)0x4aed37;
      __vbaAryUnlock();
      ppppcStack_19c = &local_6c;
      ppppcStack_1a0 = (code ****)0x4aed3d;
      __vbaAryUnlock();
      ppppcStack_1a0 = (code ****)local_7c;
      pppcStack_1a4 = (code ***)0x4aed47;
      fVar28 = (float10)__vbaR4Var();
      local_5c = (float)fVar28;
      pppcStack_1a4 = (code ***)0x4aed53;
      __vbaFreeVar();
      sVar3 = (short)local_60 + 1;
      unaff_EDI = (code ****)CONCAT22((short)((uint)pcVar26 >> 0x10),sVar3);
      if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
      local_60 = unaff_EDI;
      if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
        pppcStack_17c = (code ***)0x4aed96;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b0f4 + 10));
        if (*(code *****)(DAT_0050b0f4 + 8) <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aed85;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (int)ppppcVar13 * 8;
      }
      *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar18) = (double)local_5c;
      if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
        pppcStack_17c = (code ***)0x4aedd3;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - (int)DAT_0050b1f0[5]);
        if (DAT_0050b1f0[4] <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aedc6;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (int)ppppcVar13 * 2;
      }
      *(short *)((int)DAT_0050b1f0[3] + iVar18) = (short)local_48;
      if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
        pppcStack_17c = (code ***)0x4aee0f;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)local_48 - *(int *)(DAT_0050b1f8 + 10));
        if (*(code *****)(DAT_0050b1f8 + 8) <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aee02;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (int)ppppcVar13 * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
      if ((DAT_0050b188 == (code ***)0x0) || (*(short *)DAT_0050b188 != 1)) {
        pppcStack_17c = (code ***)0x4aee4f;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)local_44 - (int)DAT_0050b188[5]);
        if (DAT_0050b188[4] <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aee3f;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (int)ppppcVar13 * 4;
      }
      if ((DAT_0050b188 == (code ***)0x0) || (*(short *)DAT_0050b188 != 1)) {
        pppcStack_17c = (code ***)0x4aee82;
        iVar16 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)local_44 - (int)DAT_0050b188[5]);
        if (DAT_0050b188[4] <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aee72;
          (*(code *)ppppcVar23)();
        }
        iVar16 = (int)ppppcVar13 * 4;
      }
      *(float *)((int)DAT_0050b188[3] + iVar16) =
           *(float *)((int)DAT_0050b188[3] + iVar18) - local_5c;
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
      if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
        pppcStack_17c = (code ***)0x4aeed0;
        unaff_EDI = (code ****)(*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)local_34 - (int)DAT_0050b184[5]);
        if (DAT_0050b184[4] <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aeec0;
          (*(code *)ppppcVar23)();
        }
        unaff_EDI = (code ****)((int)ppppcVar13 * 4);
      }
      if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
        pppcStack_17c = (code ***)0x4aef03;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)local_34 - (int)DAT_0050b184[5]);
        if (DAT_0050b184[4] <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aeef3;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (int)ppppcVar13 * 4;
      }
      *(float *)((int)DAT_0050b184[3] + iVar18) =
           *(float *)((int)unaff_EDI + (int)DAT_0050b184[3]) - local_5c;
      if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
      if ((short)local_2c == 1) {
        if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
          pppcStack_17c = (code ***)0x4af04a;
          iVar18 = (*(code *)ppppcVar23)();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_44 - (int)local_24[0][5]);
          if (local_24[0][4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4af040;
            (*(code *)ppppcVar23)();
          }
          iVar18 = (int)ppppcVar13 * 2;
        }
        *(undefined2 *)((int)local_24[0][3] + iVar18) = 1;
        goto LAB_004af056;
      }
      if ((short)local_38 == 1) {
        if ((local_40 == (code ****)0x0) || (*(short *)local_40 != 1)) {
          pppcStack_17c = (code ***)0x4af316;
          iVar18 = (*(code *)ppppcVar23)();
        }
        else {
          iVar18 = (int)(short)local_34;
          pppcVar21 = local_40[5];
          if (local_40[4] <= (code ***)(iVar18 - (int)pppcVar21)) {
            pppcStack_17c = (code ***)0x4af30c;
            (*(code *)ppppcVar23)();
          }
          iVar18 = (iVar18 - (int)pppcVar21) * 2;
        }
        *(undefined2 *)((int)local_40[3] + iVar18) = 1;
        goto LAB_004af322;
      }
      if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
        pppcStack_17c = (code ***)0x4aef6b;
        iVar18 = (*(code *)ppppcVar23)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)local_34 - (int)DAT_0050b184[5]);
        if (DAT_0050b184[4] <= ppppcVar13) {
          pppcStack_17c = (code ***)0x4aef5a;
          (*(code *)ppppcVar23)();
        }
        iVar18 = (int)ppppcVar13 * 4;
      }
      in_FPUStatusWord = 0;
      if (*(float *)((int)DAT_0050b184[3] + iVar18) == _DAT_00401bc0) {
        if ((local_40 == (code ****)0x0) || (*(short *)local_40 != 1)) {
          pppcStack_17c = (code ***)0x4aefad;
          iVar18 = (*(code *)ppppcVar23)();
        }
        else {
          ppppcVar13 = (code ****)((int)(short)local_34 - (int)local_40[5]);
          if (local_40[4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4aefa3;
            (*(code *)ppppcVar23)();
          }
          iVar18 = (int)ppppcVar13 * 2;
        }
        *(undefined2 *)((int)local_40[3] + iVar18) = 1;
        uVar2 = CONCAT22((short)((uint)iVar18 >> 0x10),(short)local_2c + -1);
        if (SBORROW2((short)local_2c,1)) goto LAB_004afc3d;
      }
      else {
        if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
          pppcStack_17c = (code ***)0x4aeff5;
          iVar18 = (*(code *)ppppcVar23)();
          uVar10 = extraout_var_03;
        }
        else {
          ppcVar19 = local_24[0][5];
          ppppcVar13 = (code ****)((int)(short)local_44 - (int)ppcVar19);
          if (local_24[0][4] <= ppppcVar13) {
            pppcStack_17c = (code ***)0x4aefeb;
            (*(code *)ppppcVar23)();
            ppcVar19 = extraout_EDX_01;
          }
          uVar10 = (undefined2)((uint)ppcVar19 >> 0x10);
          iVar18 = (int)ppppcVar13 * 2;
        }
        if (SBORROW2((short)local_38,1)) goto LAB_004afc3d;
        *(undefined2 *)((int)local_24[0][3] + iVar18) = 1;
        local_38 = CONCAT22(uVar10,(short)local_38 + -1);
        uVar2 = local_2c;
      }
      local_2c = uVar2;
    } while (0 < (short)(ushort)local_48);
  }
  else {
    ExceptionList = &pvStack_14;
    local_c = &stack0xfffffe88;
    if (DAT_0050b2c8 == 3) {
      ppppcStack_180 = (code ****)(int)DAT_0050b2c4;
      pppcStack_17c = (code ***)0x0;
      ppppsStack_184 = (short ****)&DAT_00000001;
      uStack_18c = (short *****)&local_40;
      pppppsStack_188 = (short *****)0x2;
      ppppcStack_190 = (code ****)0x2;
      ppppcStack_194 = (code ****)0x80;
      ppppcStack_198 = (code ****)0x4ada49;
      ExceptionList = &pvStack_14;
      local_c = &stack0xfffffe88;
      __vbaRedim();
      ppppcStack_19c = (code ****)(int)DAT_0050b2c6;
      ppppcStack_198 = (code ****)0x0;
      ppppcStack_1a0 = (code ****)&DAT_00000001;
      ppppcStack_1a8 = local_24;
      pppcStack_1a4 = (code ***)0x2;
      uStack_1b0 = 4.24399164517095e-314;
      ppppcStack_1b4 = (code ****)0x4ada63;
      __vbaRedim();
      local_60 = (code ****)0x0;
      local_2c = _DAT_0050b2c4;
      local_38 = CONCAT22(local_38._2_2_,DAT_0050b2c6);
      do {
        uVar2 = _DAT_0050b2c4;
        local_54 = 0.0;
        local_4c = (code ****)0x0;
        local_48 = (code ****)0x0;
        psVar5 = DAT_0050b0e8;
        ppppcVar22 = local_40;
        ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
        if (1 < (short)local_38) {
          local_18 = 1;
          uVar15 = local_18;
          while( true ) {
            local_18 = uVar15;
            local_f4 = (short)uVar2;
            if (local_f4 < (short)local_18) break;
            if ((ppppcVar22 == (code ****)0x0) || (*(short *)ppppcVar22 != 1)) {
              pppcStack_17c = (code ***)0x4adaf1;
              iVar18 = (*(code *)ppppcVar23)();
              psVar5 = DAT_0050b0e8;
              ppppcVar22 = local_40;
            }
            else {
              iVar18 = (int)(short)local_18;
              pppcVar21 = ppppcVar22[5];
              if (ppppcVar22[4] <= (code ***)(iVar18 - (int)pppcVar21)) {
                pppcStack_17c = (code ***)0x4adae1;
                (*(code *)ppppcVar23)();
                psVar5 = DAT_0050b0e8;
                ppppcVar22 = local_40;
              }
              iVar18 = (iVar18 - (int)pppcVar21) * 2;
            }
            unaff_EDI = (code ****)ppppcVar22[3];
            if (*(short *)((int)unaff_EDI + iVar18) == 0) {
              local_50 = (code ****)&DAT_00000001;
              ppppcVar20 = local_50;
              while (local_50 = ppppcVar20, (short)local_50 < 3) {
                local_3c = (float)_DAT_0050b134;
                sVar3 = DAT_0050b2c6;
                ppppcVar22 = (code ****)&DAT_00000001;
                while (sVar4 = (short)ppppcVar22, sVar4 <= sVar3) {
                  if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
                    pppcStack_17c = (code ***)0x4adb7d;
                    iVar18 = __vbaGenerateBoundsError();
                    psVar5 = DAT_0050b0e8;
                  }
                  else {
                    unaff_EDI = (code ****)((int)sVar4 - (int)local_24[0][5]);
                    if (local_24[0][4] <= unaff_EDI) {
                      pppcStack_17c = (code ***)0x4adb69;
                      __vbaGenerateBoundsError();
                      psVar5 = DAT_0050b0e8;
                    }
                    iVar18 = (int)unaff_EDI * 2;
                  }
                  ppppcVar23 = ppppcVar22;
                  if (*(short *)((int)local_24[0][3] + iVar18) == 0) {
                    ppppcVar13 = (code ****)(uint)(ushort)((short)local_18 - 1U);
                    if (SBORROW2((short)local_18,1)) goto LAB_004afc3d;
                    uVar15 = (int)(short)((short)local_18 - 1U) * (int)DAT_0050b2c6;
                    sVar11 = (short)uVar15;
                    ppppcVar13 = (code ****)(uVar15 & 0xffff);
                    if ((int)sVar11 != uVar15) goto LAB_004afc3d;
                    uVar12 = sVar11 + sVar4;
                    ppppcVar13 = (code ****)(uint)uVar12;
                    if (SCARRY2(sVar11,sVar4)) goto LAB_004afc3d;
                    bVar27 = uVar12 != (ushort)local_48;
                    if (bVar27) {
                      if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
                        pppcStack_17c = (code ***)0x4adbf7;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        unaff_EDI = (code ****)((int)(short)uVar12 - *(int *)(psVar5 + 10));
                        if (*(code *****)(psVar5 + 8) <= unaff_EDI) {
                          pppcStack_17c = (code ***)0x4adbe2;
                          __vbaGenerateBoundsError();
                        }
                      }
                      pppcStack_17c = (code ***)0x4adc15;
                      fVar28 = (float10)__vbaFpR4();
                      in_FPUStatusWord = 0;
                      psVar5 = DAT_0050b0e8;
                      if (fVar28 < (float10)local_3c) {
                        if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
                          pppcStack_17c = (code ***)0x4adc59;
                          iVar18 = __vbaGenerateBoundsError();
                        }
                        else {
                          unaff_EDI = (code ****)((int)(short)uVar12 - *(int *)(DAT_0050b0e8 + 10));
                          if (*(code *****)(DAT_0050b0e8 + 8) <= unaff_EDI) {
                            pppcStack_17c = (code ***)0x4adc44;
                            __vbaGenerateBoundsError();
                          }
                          iVar18 = (int)unaff_EDI * 8;
                        }
                        local_3c = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
                        psVar5 = DAT_0050b0e8;
                        if ((short)local_50 == 1) {
                          local_48 = ppppcVar13;
                        }
                      }
                    }
                  }
                  ppppcVar22 = (code ****)(uint)(ushort)(sVar4 + 1);
                  if (SCARRY2(sVar4,1)) goto LAB_004afc3d;
                }
                sVar3 = (short)local_50;
                if (sVar3 == 1) {
                  local_64 = local_3c;
                }
                else {
                  local_64 = local_3c - local_64;
                  local_58 = ppppcVar13;
                  if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
                }
                ppppcVar22 = local_40;
                ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
                ppppcVar20 = (code ****)(uint)(ushort)(sVar3 + 1);
                if (SCARRY2(sVar3,1)) goto LAB_004afc3d;
              }
              in_FPUStatusWord = 0;
              if (local_54 < local_64) {
                local_4c = local_48;
                local_54 = local_64;
              }
            }
            uVar15 = (uint)(ushort)((short)local_18 + 1);
            if (SCARRY2((short)local_18,1)) goto LAB_004afc3d;
          }
        }
        if (1 < (short)local_2c) {
          sVar3 = DAT_0050b2c6;
          local_1c = (code ****)&DAT_00000001;
          ppppcVar20 = local_1c;
          while (local_1c = ppppcVar20, (short)local_1c <= sVar3) {
            if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
              pppcStack_17c = (code ***)0x4add5e;
              iVar18 = (*(code *)ppppcVar23)();
              psVar5 = DAT_0050b0e8;
              ppppcVar22 = local_40;
            }
            else {
              ppcVar19 = (code **)((int)(short)local_1c - (int)local_24[0][5]);
              if (local_24[0][4] <= ppcVar19) {
                pppcStack_17c = (code ***)0x4add4e;
                (*(code *)ppppcVar23)();
                psVar5 = DAT_0050b0e8;
                ppppcVar22 = local_40;
              }
              iVar18 = (int)ppcVar19 * 2;
            }
            ppppcVar20 = (code ****)local_24[0][3];
            if (*(short *)((int)ppppcVar20 + iVar18) == 0) {
              ppppcVar20 = (code ****)&DAT_00000001;
              while (uVar2 = _DAT_0050b2c4, local_50 = ppppcVar20, (short)ppppcVar20 < 3) {
                local_3c = (float)_DAT_0050b134;
                local_18 = 1;
                uVar15 = local_18;
                while( true ) {
                  local_18 = uVar15;
                  unaff_EDI = local_50;
                  local_11c = (short)uVar2;
                  if (local_11c < (short)local_18) break;
                  if ((ppppcVar22 == (code ****)0x0) || (*(short *)ppppcVar22 != 1)) {
                    pppcStack_17c = (code ***)0x4adde6;
                    iVar18 = (*(code *)ppppcVar23)();
                    psVar5 = DAT_0050b0e8;
                    ppppcVar22 = local_40;
                  }
                  else {
                    unaff_EDI = (code ****)((int)(short)local_18 - (int)ppppcVar22[5]);
                    if (ppppcVar22[4] <= unaff_EDI) {
                      pppcStack_17c = (code ***)0x4addd6;
                      (*(code *)ppppcVar23)();
                      psVar5 = DAT_0050b0e8;
                      ppppcVar22 = local_40;
                    }
                    iVar18 = (int)unaff_EDI * 2;
                  }
                  if (*(short *)((int)ppppcVar22[3] + iVar18) == 0) {
                    ppppcVar13 = (code ****)(uint)(ushort)((short)local_18 - 1U);
                    if (SBORROW2((short)local_18,1)) goto LAB_004afc3d;
                    uVar15 = (int)(short)((short)local_18 - 1U) * (int)DAT_0050b2c6;
                    sVar4 = (short)uVar15;
                    ppppcVar13 = (code ****)(uVar15 & 0xffff);
                    if ((int)sVar4 != uVar15) goto LAB_004afc3d;
                    uVar12 = sVar4 + (short)local_1c;
                    ppppcVar13 = (code ****)(uint)uVar12;
                    if (SCARRY2(sVar4,(short)local_1c)) goto LAB_004afc3d;
                    bVar27 = uVar12 != (ushort)local_48;
                    if (bVar27) {
                      if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
                        pppcStack_17c = (code ***)0x4ade59;
                        (*(code *)ppppcVar23)();
                      }
                      else if (*(uint *)(psVar5 + 8) <=
                               (uint)((int)(short)uVar12 - *(int *)(psVar5 + 10))) {
                        pppcStack_17c = (code ***)0x4ade48;
                        (*(code *)ppppcVar23)();
                      }
                      pppcStack_17c = (code ***)0x4ade77;
                      fVar28 = (float10)__vbaFpR4();
                      in_FPUStatusWord = 0;
                      psVar5 = DAT_0050b0e8;
                      if (fVar28 < (float10)local_3c) {
                        if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
                          pppcStack_17c = (code ***)0x4adeb3;
                          iVar18 = (*(code *)ppppcVar23)();
                        }
                        else {
                          iVar18 = *(int *)(DAT_0050b0e8 + 10);
                          if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)((short)uVar12 - iVar18)) {
                            pppcStack_17c = (code ***)0x4adea2;
                            (*(code *)ppppcVar23)();
                          }
                          iVar18 = ((short)uVar12 - iVar18) * 8;
                        }
                        local_3c = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
                        psVar5 = DAT_0050b0e8;
                        if ((short)local_50 == 1) {
                          local_48 = ppppcVar13;
                        }
                      }
                    }
                  }
                  ppppcVar22 = local_40;
                  unaff_EDI = local_50;
                  uVar15 = (uint)(ushort)((short)local_18 + 1);
                  if (SCARRY2((short)local_18,1)) goto LAB_004afc3d;
                }
                sVar4 = (short)local_50;
                if (sVar4 == 1) {
                  local_64 = local_3c;
                }
                else {
                  local_64 = local_3c - local_64;
                  local_58 = ppppcVar13;
                  if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
                }
                ppppcVar20 = (code ****)(uint)(ushort)(sVar4 + 1);
                if (SCARRY2(sVar4,1)) goto LAB_004afc3d;
              }
              in_FPUStatusWord = 0;
              if (local_54 < local_64) {
                local_4c = local_48;
                local_54 = local_64;
              }
            }
            unaff_EDI = ppppcVar20;
            ppppcVar20 = (code ****)(uint)(ushort)((short)local_1c + 1);
            if (SCARRY2((short)local_1c,1)) goto LAB_004afc3d;
          }
        }
        if ((short)local_4c == 0) {
          local_4c = local_58;
        }
        sVar3 = (short)local_4c;
        if (DAT_0050b000 != 0) {
          pppcStack_154 = (code ***)((ulonglong)(double)(int)DAT_0050b2c6 >> 0x20);
          pppcStack_17c = pppcStack_154;
          ppppsStack_184 = (short ****)0x4adfc0;
          adj_fdiv_m64();
        }
        if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004afc38:
          __vbaFPException();
          return;
        }
        pppcStack_17c = (code ***)0x4adfd0;
        __vbaFPInt();
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
        pppcStack_17c = (code ***)0x4adfe6;
        uVar15 = __vbaFpI2();
        sVar4 = sVar3 % DAT_0050b2c6;
        local_44 = (code ****)CONCAT22(extraout_var_00,sVar4);
        local_94 = (short *****)&local_44;
        local_ac[0] = (code **)0x4002;
        local_9c[0] = (short ****)0x4002;
        pppcStack_17c = local_ac;
        pppppsStack_188 = local_7c;
        local_a4 = &DAT_0050b2c6;
        local_8c[0] = (short ***)0xb;
        local_84 = CONCAT22(local_84._2_2_,-(ushort)(0 < sVar4));
        ppppcStack_180 = (code ****)local_9c;
        ppppsStack_184 = local_8c;
        uStack_18c = (short *****)0x4ae055;
        local_34 = uVar15;
        Ordinal_681();
        uStack_18c = local_7c;
        ppppcStack_190 = (code ****)0x4ae05f;
        local_44 = (code ****)__vbaI2Var();
        ppppcStack_190 = (code ****)local_7c;
        ppppcStack_194 = (code ****)local_8c;
        ppppcStack_198 = (code ****)0x2;
        ppppcStack_19c = (code ****)0x4ae075;
        __vbaFreeVarList();
        ppppcStack_194 = &local_6c;
        ppppcStack_190 = (code ****)DAT_0050b188;
        ppppcStack_198 = (code ****)0x4ae089;
        __vbaAryLock();
        if ((local_6c == (code ***)0x0) || (*(short *)local_6c != 1)) {
          ppppcStack_198 = (code ****)0x4ae0be;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = (int)(short)local_44;
          ppcVar19 = local_6c[5];
          if (local_6c[4] <= (code **)(iVar18 - (int)ppcVar19)) {
            ppppcStack_198 = (code ****)0x4ae0ac;
            __vbaGenerateBoundsError();
          }
          iVar18 = (iVar18 - (int)ppcVar19) * 4;
        }
        local_94 = (short *****)((int)local_6c[3] + iVar18);
        ppppcStack_19c = &local_68;
        ppppcStack_198 = (code ****)DAT_0050b184;
        local_9c[0] = (short ****)0x4004;
        ppppcStack_1a0 = (code ****)0x4ae0e7;
        __vbaAryLock();
        if ((local_68 == (code ***)0x0) || (*(short *)local_68 != 1)) {
          ppppcStack_1a0 = (code ****)0x4ae11b;
          local_84 = __vbaGenerateBoundsError();
        }
        else {
          ppcVar19 = (code **)((int)(short)uVar15 - (int)local_68[5]);
          if (local_68[4] <= ppcVar19) {
            ppppcStack_1a0 = (code ****)0x4ae109;
            __vbaGenerateBoundsError();
          }
          local_84 = (int)ppcVar19 * 4;
        }
        ppppcStack_1a0 = (code ****)local_9c;
        local_84 = (int)local_68[3] + local_84;
        pppcStack_1a4 = (code ***)local_8c;
        ppppcStack_1a8 = (code ****)local_7c;
        local_8c[0] = (short ***)0x4004;
        uStack_1b0 = (double)CONCAT44(0x4ae147,(undefined4)uStack_1b0);
        FUN_0042b040();
        unaff_EDI = (code ****)__vbaAryUnlock_exref;
        uStack_1b0._4_4_ = (short ****)&local_68;
        uStack_1b0._0_4_ = 0x4ae153;
        __vbaAryUnlock();
        uStack_1b0 = (double)CONCAT44(uStack_1b0._4_4_,&local_6c);
        ppppcStack_1b4 = (code ****)0x4ae159;
        __vbaAryUnlock();
        ppppcStack_1b4 = (code ****)local_7c;
        iStack_1b8 = 0x4ae163;
        fVar28 = (float10)__vbaR4Var();
        local_5c = (float)fVar28;
        iStack_1b8 = 0x4ae16f;
        __vbaFreeVar();
        sVar4 = (short)local_60 + 1;
        ppppcVar23 = (code ****)CONCAT22((short)(uVar15 >> 0x10),sVar4);
        if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
        local_60 = ppppcVar23;
        if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
          pppcStack_17c = (code ***)0x4ae1ba;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = *(int *)(DAT_0050b0f4 + 10);
          if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(sVar4 - iVar18)) {
            pppcStack_17c = (code ***)0x4ae1a5;
            __vbaGenerateBoundsError();
          }
          iVar18 = (sVar4 - iVar18) * 8;
        }
        *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar18) = (double)local_5c;
        if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
          pppcStack_17c = (code ***)0x4ae1ff;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          ppsVar14 = DAT_0050b1f0[5];
          if (DAT_0050b1f0[4] <= (short **)((int)sVar4 - (int)ppsVar14)) {
            pppcStack_17c = (code ***)0x4ae1ee;
            __vbaGenerateBoundsError();
          }
          iVar18 = ((int)sVar4 - (int)ppsVar14) * 2;
        }
        *(short *)((int)DAT_0050b1f0[3] + iVar18) = (short)local_4c;
        if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
          pppcStack_17c = (code ***)0x4ae249;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          uVar15 = (int)sVar3 - *(int *)(DAT_0050b1f8 + 10);
          if (*(uint *)(DAT_0050b1f8 + 8) <= uVar15) {
            pppcStack_17c = (code ***)0x4ae238;
            __vbaGenerateBoundsError();
          }
          iVar18 = uVar15 * 2;
        }
        *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
        if ((DAT_0050b188 == (code ***)0x0) || (*(short *)DAT_0050b188 != 1)) {
          pppcStack_17c = (code ***)0x4ae291;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = (int)(short)local_44;
          ppcVar19 = DAT_0050b188[5];
          if (DAT_0050b188[4] <= (code **)(iVar18 - (int)ppcVar19)) {
            pppcStack_17c = (code ***)0x4ae27d;
            __vbaGenerateBoundsError();
          }
          iVar18 = (iVar18 - (int)ppcVar19) * 4;
        }
        if ((DAT_0050b188 == (code ***)0x0) || (*(short *)DAT_0050b188 != 1)) {
          pppcStack_17c = (code ***)0x4ae2cc;
          iVar16 = __vbaGenerateBoundsError();
        }
        else {
          iVar16 = (int)(short)local_44;
          ppcVar19 = DAT_0050b188[5];
          if (DAT_0050b188[4] <= (code **)(iVar16 - (int)ppcVar19)) {
            pppcStack_17c = (code ***)0x4ae2b8;
            __vbaGenerateBoundsError();
          }
          iVar16 = (iVar16 - (int)ppcVar19) * 4;
        }
        *(float *)((int)DAT_0050b188[3] + iVar16) =
             *(float *)((int)DAT_0050b188[3] + iVar18) - local_5c;
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
        if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
          pppcStack_17c = (code ***)0x4ae322;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = (int)(short)local_34;
          pppsVar7 = DAT_0050b184[5];
          if (DAT_0050b184[4] <= (short ***)(iVar18 - (int)pppsVar7)) {
            pppcStack_17c = (code ***)0x4ae30e;
            __vbaGenerateBoundsError();
          }
          iVar18 = (iVar18 - (int)pppsVar7) * 4;
        }
        unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
        if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
          pppcStack_17c = (code ***)0x4ae365;
          iVar16 = __vbaGenerateBoundsError();
        }
        else {
          iVar16 = (int)(short)local_34;
          pppsVar7 = DAT_0050b184[5];
          if (DAT_0050b184[4] <= (short ***)(iVar16 - (int)pppsVar7)) {
            pppcStack_17c = (code ***)0x4ae349;
            __vbaGenerateBoundsError();
          }
          iVar16 = (iVar16 - (int)pppsVar7) * 4;
          unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
        }
        *(float *)((int)DAT_0050b184[3] + iVar16) =
             *(float *)((int)DAT_0050b184[3] + iVar18) - local_5c;
        ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004afc38;
        if ((short)local_2c == 1) {
          if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
            pppcStack_17c = (code ***)0x4ae4c9;
            iVar18 = (*(code *)unaff_EDI)();
          }
          else {
            ppppcVar13 = (code ****)((int)(short)local_44 - (int)local_24[0][5]);
            if (local_24[0][4] <= ppppcVar13) {
              pppcStack_17c = (code ***)0x4ae4bf;
              (*(code *)unaff_EDI)();
            }
            iVar18 = (int)ppppcVar13 * 2;
          }
          *(undefined2 *)((int)local_24[0][3] + iVar18) = 1;
          ppppcVar23 = local_60;
          goto LAB_004ae4d6;
        }
        if ((short)local_38 == 1) {
          if ((local_40 == (code ****)0x0) || (*(short *)local_40 != 1)) {
            pppcStack_17c = (code ***)0x4ae793;
            iVar18 = (*(code *)unaff_EDI)();
          }
          else {
            iVar18 = (int)(short)local_34;
            pppcVar21 = local_40[5];
            if (local_40[4] <= (code ***)(iVar18 - (int)pppcVar21)) {
              pppcStack_17c = (code ***)0x4ae789;
              (*(code *)unaff_EDI)();
            }
            iVar18 = (iVar18 - (int)pppcVar21) * 2;
          }
          *(undefined2 *)((int)local_40[3] + iVar18) = 1;
          ppppcVar22 = local_60;
          goto LAB_004ae7a0;
        }
        if ((DAT_0050b184 == (short ****)0x0) || (*(short *)DAT_0050b184 != 1)) {
          pppcStack_17c = (code ***)0x4ae3d3;
          iVar18 = (*(code *)unaff_EDI)();
          ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
        }
        else {
          unaff_EDI = (code ****)((int)(short)local_34 - (int)DAT_0050b184[5]);
          if (DAT_0050b184[4] <= unaff_EDI) {
            pppcStack_17c = (code ***)0x4ae3c2;
            __vbaGenerateBoundsError();
          }
          iVar18 = (int)unaff_EDI * 4;
        }
        in_FPUStatusWord = 0;
        if (*(float *)((int)DAT_0050b184[3] + iVar18) == _DAT_00401bc0) {
          if ((local_40 == (code ****)0x0) || (*(short *)local_40 != 1)) {
            pppcStack_17c = (code ***)0x4ae41b;
            iVar18 = (*(code *)ppppcVar23)();
            uVar10 = extraout_var_01;
          }
          else {
            pppcVar21 = local_40[5];
            unaff_EDI = (code ****)((int)(short)local_34 - (int)pppcVar21);
            if (local_40[4] <= unaff_EDI) {
              pppcStack_17c = (code ***)0x4ae411;
              (*(code *)ppppcVar23)();
              pppcVar21 = extraout_EDX;
            }
            uVar10 = (undefined2)((uint)pppcVar21 >> 0x10);
            iVar18 = (int)unaff_EDI * 2;
          }
          if (SBORROW2((short)local_2c,1)) goto LAB_004afc3d;
          *(undefined2 *)((int)local_40[3] + iVar18) = 1;
          local_2c = CONCAT22(uVar10,(short)local_2c + -1);
        }
        else {
          if ((local_24[0] == (code ***)0x0) || (*(short *)local_24[0] != 1)) {
            pppcStack_17c = (code ***)0x4ae463;
            iVar18 = (*(code *)ppppcVar23)();
            uVar10 = extraout_var_02;
          }
          else {
            ppcVar19 = local_24[0][5];
            unaff_EDI = (code ****)((int)(short)local_44 - (int)ppcVar19);
            if (local_24[0][4] <= unaff_EDI) {
              pppcStack_17c = (code ***)0x4ae459;
              (*(code *)ppppcVar23)();
              ppcVar19 = extraout_EDX_00;
            }
            uVar10 = (undefined2)((uint)ppcVar19 >> 0x10);
            iVar18 = (int)unaff_EDI * 2;
          }
          if (SBORROW2((short)local_38,1)) goto LAB_004afc3d;
          *(undefined2 *)((int)local_24[0][3] + iVar18) = 1;
          local_38 = CONCAT22(uVar10,(short)local_38 + -1);
        }
      } while ((short)local_60 < DAT_0050b20c);
    }
  }
  goto LAB_004afa7b;
LAB_004af056:
  if ((short)local_60 < DAT_0050b20c) {
    local_28 = (float)_DAT_0050b134;
    sVar3 = DAT_0050b2c6;
    psVar5 = DAT_0050b0e8;
    pppcVar21 = local_24[0];
    ppppcVar22 = (code ****)&DAT_00000001;
    unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
    while (ppppcVar23 = ppppcVar22, sVar4 = (short)ppppcVar23, sVar4 <= sVar3) {
      if ((pppcVar21 == (code ***)0x0) || (*(short *)pppcVar21 != 1)) {
        pppcStack_17c = (code ***)0x4af0c9;
        iVar18 = (*(code *)unaff_EDI)();
        psVar5 = DAT_0050b0e8;
        pppcVar21 = local_24[0];
      }
      else {
        ppcVar19 = pppcVar21[5];
        if (pppcVar21[4] <= (code **)((int)sVar4 - (int)ppcVar19)) {
          pppcStack_17c = (code ***)0x4af0b9;
          (*(code *)unaff_EDI)();
          psVar5 = DAT_0050b0e8;
          pppcVar21 = local_24[0];
        }
        iVar18 = ((int)sVar4 - (int)ppcVar19) * 2;
      }
      ppppcVar13 = (code ****)pppcVar21[3];
      if (*(short *)((int)ppppcVar13 + iVar18) == 0) {
        uVar10 = (undefined2)((uint)ppppcVar13 >> 0x10);
        ppppcVar13 = (code ****)CONCAT22(uVar10,(short)local_34 + -1);
        if (SBORROW2((short)local_34,1)) goto LAB_004afc3d;
        iVar18 = (int)(short)((short)local_34 + -1) * (int)DAT_0050b2c6;
        sVar11 = (short)iVar18;
        ppppcVar13 = (code ****)CONCAT22(uVar10,sVar11);
        if (sVar11 != iVar18) goto LAB_004afc3d;
        sVar17 = sVar11 + sVar4;
        ppppcVar13 = (code ****)CONCAT22(uVar10,sVar17);
        if (SCARRY2(sVar11,sVar4)) goto LAB_004afc3d;
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          pppcStack_17c = (code ***)0x4af13b;
          (*(code *)unaff_EDI)();
        }
        else {
          unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
          if (*(uint *)(psVar5 + 8) <= (uint)((int)sVar17 - *(int *)(psVar5 + 10))) {
            pppcStack_17c = (code ***)0x4af124;
            __vbaGenerateBoundsError();
            unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
          }
        }
        pppcStack_17c = (code ***)0x4af159;
        fVar28 = (float10)__vbaFpR4();
        in_FPUStatusWord = 0;
        psVar5 = DAT_0050b0e8;
        pppcVar21 = local_24[0];
        if (fVar28 < (float10)local_28) {
          if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
            pppcStack_17c = (code ***)0x4af19f;
            iVar18 = (*(code *)unaff_EDI)();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0e8 + 10);
            if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(sVar17 - iVar18)) {
              pppcStack_17c = (code ***)0x4af188;
              __vbaGenerateBoundsError();
            }
            iVar18 = (sVar17 - iVar18) * 8;
            unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
          }
          local_28 = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
          psVar5 = DAT_0050b0e8;
          pppcVar21 = local_24[0];
          local_48 = ppppcVar13;
          local_44 = ppppcVar23;
        }
      }
      ppppcVar22 = (code ****)(uint)(ushort)(sVar4 + 1);
      if (SCARRY2(sVar4,1)) goto LAB_004afc3d;
    }
    if ((pppcVar21 == (code ***)0x0) || (*(short *)pppcVar21 != 1)) {
      pppcStack_17c = (code ***)0x4af1fd;
      iVar18 = (*(code *)unaff_EDI)();
      pppcVar21 = local_24[0];
    }
    else {
      ppppcVar13 = (code ****)((int)(short)local_44 - (int)pppcVar21[5]);
      if (pppcVar21[4] <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4af1f3;
        (*(code *)unaff_EDI)();
        pppcVar21 = local_24[0];
      }
      iVar18 = (int)ppppcVar13 * 2;
    }
    uVar12 = (short)local_60 + 1;
    ppppcVar23 = (code ****)(uint)uVar12;
    *(undefined2 *)((int)pppcVar21[3] + iVar18) = 1;
    if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
    local_60 = ppppcVar23;
    if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
      pppcStack_17c = (code ***)0x4af24c;
      iVar18 = (*(code *)unaff_EDI)();
    }
    else {
      ppppcVar13 = (code ****)((int)(short)uVar12 - *(int *)(DAT_0050b0f4 + 10));
      if (*(code *****)(DAT_0050b0f4 + 8) <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4af23b;
        (*(code *)unaff_EDI)();
      }
      iVar18 = (int)ppppcVar13 * 8;
    }
    iVar16 = *(int *)(DAT_0050b0f4 + 6);
    *(undefined4 *)(iVar16 + iVar18) = 0;
    *(undefined4 *)(iVar16 + 4 + iVar18) = 0;
    if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
      pppcStack_17c = (code ***)0x4af292;
      iVar18 = (*(code *)unaff_EDI)();
    }
    else {
      ppppcVar13 = (code ****)((int)(short)uVar12 - (int)DAT_0050b1f0[5]);
      if (DAT_0050b1f0[4] <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4af285;
        (*(code *)unaff_EDI)();
      }
      iVar18 = (int)ppppcVar13 * 2;
    }
    *(short *)((int)DAT_0050b1f0[3] + iVar18) = (short)local_48;
    if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
      pppcStack_17c = (code ***)0x4af2da;
      iVar18 = (*(code *)unaff_EDI)();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
    }
    else {
      ppppcVar13 = (code ****)((int)(short)local_48 - *(int *)(DAT_0050b1f8 + 10));
      if (*(code *****)(DAT_0050b1f8 + 8) <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4af2c1;
        (*(code *)unaff_EDI)();
      }
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + (int)ppppcVar13 * 2) = 0;
    }
    goto LAB_004af056;
  }
  goto LAB_004afa7b;
LAB_004af322:
  uVar2 = _DAT_0050b2c4;
  if ((short)local_60 < DAT_0050b20c) {
    local_28 = (float)_DAT_0050b134;
    local_18 = 1;
    psVar5 = DAT_0050b0e8;
    ppppcVar13 = local_40;
    uVar15 = local_18;
    while( true ) {
      local_18 = uVar15;
      local_ec = (short)uVar2;
      if (local_ec < (short)local_18) break;
      if ((ppppcVar13 == (code ****)0x0) || (*(short *)ppppcVar13 != 1)) {
        pppcStack_17c = (code ***)0x4af393;
        iVar18 = (*(code *)ppppcVar23)();
        psVar5 = DAT_0050b0e8;
        ppppcVar13 = local_40;
      }
      else {
        pppcVar21 = (code ***)((int)(short)local_18 - (int)ppppcVar13[5]);
        if (ppppcVar13[4] <= pppcVar21) {
          pppcStack_17c = (code ***)0x4af380;
          (*(code *)ppppcVar23)();
          psVar5 = DAT_0050b0e8;
          ppppcVar13 = local_40;
        }
        iVar18 = (int)pppcVar21 * 2;
      }
      unaff_EDI = (code ****)ppppcVar13[3];
      if (*(short *)((int)unaff_EDI + iVar18) == 0) {
        if (SBORROW2((short)local_18,1)) goto LAB_004afc3d;
        iVar18 = (int)(short)((short)local_18 + -1) * (int)DAT_0050b2c6;
        sVar3 = (short)iVar18;
        if (sVar3 != iVar18) goto LAB_004afc3d;
        sVar4 = sVar3 + (short)local_44;
        ppppcVar22 = (code ****)CONCAT22((short)(local_18 >> 0x10),sVar4);
        if (SCARRY2(sVar3,(short)local_44)) goto LAB_004afc3d;
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          pppcStack_17c = (code ***)0x4af3fd;
          (*(code *)ppppcVar23)();
        }
        else if (*(uint *)(psVar5 + 8) <= (uint)((int)sVar4 - *(int *)(psVar5 + 10))) {
          pppcStack_17c = (code ***)0x4af3ec;
          (*(code *)ppppcVar23)();
        }
        pppcStack_17c = (code ***)0x4af41b;
        fVar28 = (float10)__vbaFpR4();
        in_FPUStatusWord = 0;
        psVar5 = DAT_0050b0e8;
        ppppcVar13 = local_40;
        unaff_EDI = ppppcVar22;
        if (fVar28 < (float10)local_28) {
          if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
            pppcStack_17c = (code ***)0x4af457;
            iVar18 = (*(code *)ppppcVar23)();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0e8 + 10);
            if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(sVar4 - iVar18)) {
              pppcStack_17c = (code ***)0x4af446;
              (*(code *)ppppcVar23)();
            }
            iVar18 = (sVar4 - iVar18) * 8;
          }
          local_28 = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
          local_34 = local_18;
          psVar5 = DAT_0050b0e8;
          ppppcVar13 = local_40;
          local_48 = ppppcVar22;
        }
      }
      uVar15 = (uint)(ushort)((short)local_18 + 1);
      if (SCARRY2((short)local_18,1)) goto LAB_004afc3d;
    }
    if ((ppppcVar13 == (code ****)0x0) || (*(short *)ppppcVar13 != 1)) {
      pppcStack_17c = (code ***)0x4af4be;
      iVar18 = (*(code *)ppppcVar23)();
      ppppcVar13 = local_40;
    }
    else {
      unaff_EDI = (code ****)((int)(short)local_34 - (int)ppppcVar13[5]);
      if (ppppcVar13[4] <= unaff_EDI) {
        pppcStack_17c = (code ***)0x4af4b4;
        (*(code *)ppppcVar23)();
        ppppcVar13 = local_40;
      }
      iVar18 = (int)unaff_EDI * 2;
    }
    *(undefined2 *)((int)ppppcVar13[3] + iVar18) = 1;
    ppppcVar22 = (code ****)CONCAT22((short)((uint)iVar18 >> 0x10),(short)local_60 + 1);
    if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
    local_60 = ppppcVar22;
    if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
      pppcStack_17c = (code ***)0x4af50d;
      iVar18 = (*(code *)ppppcVar23)();
    }
    else {
      uVar15 = (int)(short)((short)local_60 + 1) - *(int *)(DAT_0050b0f4 + 10);
      if (*(uint *)(DAT_0050b0f4 + 8) <= uVar15) {
        pppcStack_17c = (code ***)0x4af4fc;
        (*(code *)ppppcVar23)();
      }
      iVar18 = uVar15 * 8;
    }
    iVar16 = *(int *)(DAT_0050b0f4 + 6);
    *(undefined4 *)(iVar16 + iVar18) = 0;
    *(undefined4 *)(iVar16 + 4 + iVar18) = 0;
    if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
      pppcStack_17c = (code ***)0x4af554;
      iVar18 = (*(code *)ppppcVar23)();
    }
    else {
      iVar18 = (int)(short)local_60;
      ppsVar14 = DAT_0050b1f0[5];
      if (DAT_0050b1f0[4] <= (short **)(iVar18 - (int)ppsVar14)) {
        pppcStack_17c = (code ***)0x4af547;
        (*(code *)ppppcVar23)();
      }
      iVar18 = (iVar18 - (int)ppsVar14) * 2;
    }
    *(short *)((int)DAT_0050b1f0[3] + iVar18) = (short)local_48;
    if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
      pppcStack_17c = (code ***)0x4af59c;
      iVar18 = (*(code *)ppppcVar23)();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
    }
    else {
      uVar15 = (int)(short)local_48 - *(int *)(DAT_0050b1f8 + 10);
      if (*(uint *)(DAT_0050b1f8 + 8) <= uVar15) {
        pppcStack_17c = (code ***)0x4af583;
        (*(code *)ppppcVar23)();
      }
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + uVar15 * 2) = 0;
    }
    goto LAB_004af322;
  }
  goto LAB_004afa7b;
LAB_004ae4d6:
  if ((short)ppppcVar23 < DAT_0050b20c) {
    local_28 = (float)_DAT_0050b134;
    sVar3 = DAT_0050b2c6;
    psVar5 = DAT_0050b0e8;
    pppcVar21 = local_24[0];
    ppppcVar22 = (code ****)&DAT_00000001;
    unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
    while (ppppcVar23 = ppppcVar22, sVar4 = (short)ppppcVar23, sVar4 <= sVar3) {
      if ((pppcVar21 == (code ***)0x0) || (*(short *)pppcVar21 != 1)) {
        pppcStack_17c = (code ***)0x4ae546;
        iVar18 = (*(code *)unaff_EDI)();
        psVar5 = DAT_0050b0e8;
        pppcVar21 = local_24[0];
      }
      else {
        ppcVar19 = pppcVar21[5];
        if (pppcVar21[4] <= (code **)((int)sVar4 - (int)ppcVar19)) {
          pppcStack_17c = (code ***)0x4ae536;
          (*(code *)unaff_EDI)();
          psVar5 = DAT_0050b0e8;
          pppcVar21 = local_24[0];
        }
        iVar18 = ((int)sVar4 - (int)ppcVar19) * 2;
      }
      ppppcVar13 = (code ****)pppcVar21[3];
      if (*(short *)((int)ppppcVar13 + iVar18) == 0) {
        uVar10 = (undefined2)((uint)ppppcVar13 >> 0x10);
        ppppcVar13 = (code ****)CONCAT22(uVar10,(short)local_34 + -1);
        if (SBORROW2((short)local_34,1)) goto LAB_004afc3d;
        iVar18 = (int)(short)((short)local_34 + -1) * (int)DAT_0050b2c6;
        sVar11 = (short)iVar18;
        ppppcVar13 = (code ****)CONCAT22(uVar10,sVar11);
        if (sVar11 != iVar18) goto LAB_004afc3d;
        sVar17 = sVar11 + sVar4;
        ppppcVar13 = (code ****)CONCAT22(uVar10,sVar17);
        if (SCARRY2(sVar11,sVar4)) goto LAB_004afc3d;
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          pppcStack_17c = (code ***)0x4ae5b8;
          (*(code *)unaff_EDI)();
        }
        else {
          unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
          if (*(uint *)(psVar5 + 8) <= (uint)((int)sVar17 - *(int *)(psVar5 + 10))) {
            pppcStack_17c = (code ***)0x4ae5a1;
            __vbaGenerateBoundsError();
            unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
          }
        }
        pppcStack_17c = (code ***)0x4ae5d6;
        fVar28 = (float10)__vbaFpR4();
        in_FPUStatusWord = 0;
        psVar5 = DAT_0050b0e8;
        pppcVar21 = local_24[0];
        if (fVar28 < (float10)local_28) {
          if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
            pppcStack_17c = (code ***)0x4ae61c;
            iVar18 = (*(code *)unaff_EDI)();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0e8 + 10);
            if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(sVar17 - iVar18)) {
              pppcStack_17c = (code ***)0x4ae605;
              __vbaGenerateBoundsError();
            }
            iVar18 = (sVar17 - iVar18) * 8;
            unaff_EDI = (code ****)__vbaGenerateBoundsError_exref;
          }
          local_28 = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
          psVar5 = DAT_0050b0e8;
          pppcVar21 = local_24[0];
          local_4c = ppppcVar13;
          local_44 = ppppcVar23;
        }
      }
      ppppcVar22 = (code ****)(uint)(ushort)(sVar4 + 1);
      if (SCARRY2(sVar4,1)) goto LAB_004afc3d;
    }
    if ((pppcVar21 == (code ***)0x0) || (*(short *)pppcVar21 != 1)) {
      pppcStack_17c = (code ***)0x4ae67a;
      iVar18 = (*(code *)unaff_EDI)();
      pppcVar21 = local_24[0];
    }
    else {
      ppppcVar13 = (code ****)((int)(short)local_44 - (int)pppcVar21[5]);
      if (pppcVar21[4] <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4ae670;
        (*(code *)unaff_EDI)();
        pppcVar21 = local_24[0];
      }
      iVar18 = (int)ppppcVar13 * 2;
    }
    uVar12 = (short)local_60 + 1;
    ppppcVar23 = (code ****)(uint)uVar12;
    *(undefined2 *)((int)pppcVar21[3] + iVar18) = 1;
    if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
    local_60 = ppppcVar23;
    if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
      pppcStack_17c = (code ***)0x4ae6c9;
      iVar18 = (*(code *)unaff_EDI)();
    }
    else {
      ppppcVar13 = (code ****)((int)(short)uVar12 - *(int *)(DAT_0050b0f4 + 10));
      if (*(code *****)(DAT_0050b0f4 + 8) <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4ae6b8;
        (*(code *)unaff_EDI)();
      }
      iVar18 = (int)ppppcVar13 * 8;
    }
    iVar16 = *(int *)(DAT_0050b0f4 + 6);
    *(undefined4 *)(iVar16 + iVar18) = 0;
    *(undefined4 *)(iVar16 + 4 + iVar18) = 0;
    if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
      pppcStack_17c = (code ***)0x4ae70f;
      iVar18 = (*(code *)unaff_EDI)();
    }
    else {
      ppppcVar13 = (code ****)((int)(short)uVar12 - (int)DAT_0050b1f0[5]);
      if (DAT_0050b1f0[4] <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4ae702;
        (*(code *)unaff_EDI)();
      }
      iVar18 = (int)ppppcVar13 * 2;
    }
    *(short *)((int)DAT_0050b1f0[3] + iVar18) = (short)local_4c;
    if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
      pppcStack_17c = (code ***)0x4ae757;
      iVar18 = (*(code *)unaff_EDI)();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
    }
    else {
      ppppcVar13 = (code ****)((int)(short)local_4c - *(int *)(DAT_0050b1f8 + 10));
      if (*(code *****)(DAT_0050b1f8 + 8) <= ppppcVar13) {
        pppcStack_17c = (code ***)0x4ae73e;
        (*(code *)unaff_EDI)();
      }
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + (int)ppppcVar13 * 2) = 0;
    }
    goto LAB_004ae4d6;
  }
  goto LAB_004afa7b;
LAB_004b00ce:
  ppppcStack_1a0 = (code ****)0x4b00d4;
  __vbaErrorOverflow();
  puStack_1c8 = (undefined1 *)&ppppcStack_1a0;
  uStack_1b0 = (double)CONCAT44(uStack_1b0._4_4_,_DAT_0050b20c);
  iStack_1c0 = 1;
  pcVar26 = __vbaGenerateBoundsError_exref;
  ppppcStack_1d0 = ppppcVar23;
  ppppcStack_1cc = ppppcVar13;
  pppppsVar24 = (short *****)&ppppcStack_1a0;
  pcStack_1c4 = (code *)ppppsVar8;
  ppppcStack_1a0 = (code ****)ppppsVar9;
  if (0 < (short)_DAT_0050b20c) {
    do {
      iVar18 = iStack_1c0;
      if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
        ppppcStack_1d4 = (code ****)0x4b0140;
        iVar16 = (*pcVar26)();
      }
      else {
        ppppcVar13 = (code ****)((int)(short)iStack_1c0 - *(int *)(DAT_0050b0dc + 10));
        if (*(code *****)(DAT_0050b0dc + 8) <= ppppcVar13) {
          ppppcStack_1d4 = (code ****)0x4b012f;
          (*pcVar26)();
        }
        iVar16 = (int)ppppcVar13 * 8;
      }
      iVar25 = *(int *)(DAT_0050b0dc + 6);
      ppppcVar23 = (code ****)&DAT_00000001;
      *(undefined4 *)(iVar25 + iVar16) = 0;
      *(undefined4 *)(iVar25 + 4 + iVar16) = 0;
      ppppcStack_1b4 = _DAT_0050b20c;
      if (0 < (short)_DAT_0050b20c) {
        do {
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            ppppcStack_1d4 = (code ****)0x4b019e;
            iStack_1bc = (*pcVar26)();
          }
          else {
            uVar15 = (int)(short)iVar18 - *(int *)(DAT_0050b0dc + 10);
            if (*(uint *)(DAT_0050b0dc + 8) <= uVar15) {
              ppppcStack_1d4 = (code ****)0x4b018f;
              (*pcVar26)();
            }
            iStack_1bc = uVar15 * 8;
          }
          sVar3 = (short)ppppcVar23;
          if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
            ppppcStack_1d4 = (code ****)0x4b01cd;
            iStack_1b8 = (*pcVar26)();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0d8 + 10);
            if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(sVar3 - iVar18)) {
              ppppcStack_1d4 = (code ****)0x4b01c2;
              (*pcVar26)();
            }
            iStack_1b8 = (sVar3 - iVar18) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            ppppcStack_1d4 = (code ****)0x4b0221;
            ppppcVar13 = (code ****)(*pcVar26)();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(sVar3 - iVar18)) {
              ppppcStack_1d4 = (code ****)0x4b01f1;
              (*pcVar26)();
            }
            iVar25 = (int)(short)iStack_1c0;
            iVar16 = *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(iVar25 - iVar16)) {
              ppppcStack_1d4 = (code ****)0x4b020d;
              __vbaGenerateBoundsError();
            }
            ppppcVar13 = (code ****)
                         ((*(int *)(DAT_0050b0c4 + 0xc) * (iVar25 - iVar16) + (sVar3 - iVar18)) * 8)
            ;
          }
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            ppppcStack_1d4 = (code ****)0x4b0263;
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = (int)(short)iStack_1c0;
            iVar18 = *(int *)(DAT_0050b0dc + 10);
            if (*(uint *)(DAT_0050b0dc + 8) <= (uint)(iVar16 - iVar18)) {
              ppppcStack_1d4 = (code ****)0x4b024f;
              __vbaGenerateBoundsError();
            }
            iVar18 = (iVar16 - iVar18) * 8;
          }
          pcVar26 = __vbaGenerateBoundsError_exref;
          *(double *)(*(int *)(DAT_0050b0dc + 6) + iVar18) =
               *(double *)((int)ppppcVar13 + *(int *)(DAT_0050b0c4 + 6)) *
               *(double *)(*(int *)(DAT_0050b0d8 + 6) + iStack_1b8) +
               *(double *)(*(int *)(DAT_0050b0dc + 6) + iStack_1bc);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
          ppppcVar23 = (code ****)(uint)(ushort)(sVar3 + 1U);
          iVar16 = iStack_1c0;
          if (SCARRY2(sVar3,1)) goto LAB_004b06ce;
          iVar18 = iStack_1c0;
        } while ((short)(sVar3 + 1U) <= (short)ppppcStack_1b4);
      }
      sVar3 = (short)iVar18 + 1;
      iVar16 = CONCAT22((short)((uint)iVar18 >> 0x10),sVar3);
      if (SCARRY2((short)iVar18,1)) goto LAB_004b06ce;
      pppppsVar24 = (short *****)puStack_1c8;
      iStack_1c0 = iVar16;
    } while (sVar3 <= (short)uStack_1b0);
  }
  puStack_1c8 = (undefined1 *)pppppsVar24;
  DAT_0050b25e = 0;
  ppppcStack_1a8 = (code ****)0x0;
  pppcStack_1a4 = (code ***)0x0;
  iStack_1c0 = CONCAT22(iStack_1c0._2_2_,DAT_0050b20a);
  iStack_1b8 = 1;
  if (0 < DAT_0050b20a) {
    do {
      iVar18 = iStack_1b8;
      ppppcVar23 = (code ****)0x0;
      sVar3 = (short)iStack_1b8;
      if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
        ppppcStack_1d4 = (code ****)0x4b0339;
        iVar16 = (*pcVar26)();
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b0f0 + 10));
        if (*(code *****)(DAT_0050b0f0 + 8) <= ppppcVar13) {
          ppppcStack_1d4 = (code ****)0x4b0328;
          (*pcVar26)();
        }
        iVar16 = (int)ppppcVar13 * 8;
      }
      iVar25 = *(int *)(DAT_0050b0f0 + 6);
      *(undefined4 *)(iVar25 + iVar16) = 0;
      *(undefined4 *)(iVar25 + 4 + iVar16) = 0;
      if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
        ppppcStack_1d4 = (code ****)0x4b0377;
        iVar16 = (*pcVar26)();
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b1f8 + 10));
        if (*(code *****)(DAT_0050b1f8 + 8) <= ppppcVar13) {
          ppppcStack_1d4 = (code ****)0x4b036a;
          (*pcVar26)();
        }
        iVar16 = (int)ppppcVar13 * 2;
      }
      if (0 < *(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar16)) {
        iVar18 = (int)sVar3;
        uStack_1b0 = (double)(int)DAT_0050b2c6;
        iStack_1bc = iVar18;
        if (DAT_0050b000 != 0) {
          uStack_1b0._4_4_ = (short ****)((ulonglong)uStack_1b0 >> 0x20);
          ppppcStack_1d4 = (code ****)uStack_1b0._4_4_;
          adj_fdiv_m64();
        }
        if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004b06c9:
          __vbaFPException();
          return;
        }
        ppppcStack_1d4 = (code ****)0x4b03e2;
        __vbaFPInt();
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        ppppcStack_1d4 = (code ****)0x4b03f8;
        sVar4 = __vbaFpI2();
        uStack_1b0 = (double)CONCAT44(uStack_1b0._4_4_,
                                      CONCAT22(extraout_var_04,sVar3 % DAT_0050b2c6));
        if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
          ppppcStack_1d4 = (code ****)0x4b0435;
          ppppcStack_1b4 = (code ****)(*pcVar26)();
        }
        else {
          iVar16 = *(int *)(DAT_0050b0dc + 10);
          if (*(uint *)(DAT_0050b0dc + 8) <= (uint)(sVar4 - iVar16)) {
            ppppcStack_1d4 = (code ****)0x4b042a;
            (*pcVar26)();
          }
          ppppcStack_1b4 = (code ****)((sVar4 - iVar16) * 8);
        }
        if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
          ppppcStack_1d4 = (code ****)0x4b0463;
          iVar16 = (*pcVar26)();
        }
        else {
          iVar16 = *(int *)(DAT_0050b0e8 + 10);
          if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar18 - iVar16)) {
            ppppcStack_1d4 = (code ****)0x4b0458;
            (*pcVar26)();
          }
          iVar16 = (iVar18 - iVar16) * 8;
        }
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          ppppcStack_1d4 = (code ****)0x4b0496;
          iVar18 = (*pcVar26)();
        }
        else {
          iVar25 = *(int *)(DAT_0050b0f0 + 10);
          if (*(uint *)(DAT_0050b0f0 + 8) <= (uint)(iVar18 - iVar25)) {
            ppppcStack_1d4 = (code ****)0x4b0485;
            (*pcVar26)();
          }
          iVar18 = (iVar18 - iVar25) * 8;
        }
        ppppcVar13 = *(code *****)(DAT_0050b0e8 + 6);
        *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar18) =
             *(double *)(*(int *)(DAT_0050b0dc + 6) + (int)ppppcStack_1b4) -
             *(double *)((int)ppppcVar13 + iVar16);
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        sVar3 = SUB82(uStack_1b0,0);
        ppppcVar23 = ppppcStack_1b4;
        if (0 < sVar3) {
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            ppppcStack_1d4 = (code ****)0x4b0507;
            ppppcVar23 = (code ****)(*pcVar26)();
          }
          else {
            ppppcVar13 = (code ****)(iStack_1bc - *(int *)(DAT_0050b0f0 + 10));
            if (*(code *****)(DAT_0050b0f0 + 8) <= ppppcVar13) {
              ppppcStack_1d4 = (code ****)0x4b04f7;
              (*pcVar26)();
            }
            ppppcVar23 = (code ****)((int)ppppcVar13 * 8);
          }
          if ((DAT_0050b0dc == (short *)0x0) || (*DAT_0050b0dc != 1)) {
            ppppcStack_1d4 = (code ****)0x4b054f;
            iVar18 = (*pcVar26)();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0dc + 10);
            if (SCARRY2(DAT_0050b2c4,sVar3)) goto LAB_004b06ce;
            ppppcVar13 = (code ****)((short)(DAT_0050b2c4 + sVar3) - iVar16);
            if (*(code *****)(DAT_0050b0dc + 8) <= ppppcVar13) {
              ppppcStack_1d4 = (code ****)0x4b053f;
              (*pcVar26)();
            }
            iVar18 = (int)ppppcVar13 * 8;
          }
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            ppppcStack_1d4 = (code ****)0x4b0582;
            iVar16 = (*pcVar26)();
          }
          else {
            ppppcVar13 = (code ****)(iStack_1bc - *(int *)(DAT_0050b0f0 + 10));
            if (*(code *****)(DAT_0050b0f0 + 8) <= ppppcVar13) {
              ppppcStack_1d4 = (code ****)0x4b0572;
              (*pcVar26)();
            }
            iVar16 = (int)ppppcVar13 * 8;
          }
          *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar16) =
               *(double *)(*(int *)(DAT_0050b0dc + 6) + iVar18) +
               *(double *)(*(int *)(DAT_0050b0f0 + 6) + (int)ppppcVar23);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b06c9;
        }
        iVar16 = iStack_1bc;
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          ppppcStack_1d4 = (code ****)0x4b05dc;
          iVar25 = (*pcVar26)();
        }
        else {
          ppppcVar13 = (code ****)(iStack_1bc - *(int *)(DAT_0050b0f0 + 10));
          if (*(code *****)(DAT_0050b0f0 + 8) <= ppppcVar13) {
            ppppcStack_1d4 = (code ****)0x4b05cb;
            (*pcVar26)();
          }
          iVar25 = (int)ppppcVar13 * 8;
        }
        in_FPUStatusWord = 0;
        iVar18 = iStack_1b8;
        if ((double)CONCAT44(pppcStack_1a4,ppppcStack_1a8) <
            *(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar25)) {
          if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
            ppppcStack_1d4 = (code ****)0x4b061e;
            iVar18 = (*pcVar26)();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0f0 + 10);
            if (*(uint *)(DAT_0050b0f0 + 8) <= (uint)(iVar16 - iVar18)) {
              ppppcStack_1d4 = (code ****)0x4b060d;
              (*pcVar26)();
            }
            iVar18 = (iVar16 - iVar18) * 8;
          }
          ppppcVar13 = *(code *****)(*(int *)(DAT_0050b0f0 + 6) + iVar18);
          pppcStack_1a4 = *(code ****)(*(int *)(DAT_0050b0f0 + 6) + 4 + iVar18);
          DAT_0050b25e = (short)iStack_1b8;
          iVar18 = iStack_1b8;
          ppppcStack_1a8 = ppppcVar13;
        }
      }
      sVar3 = (short)iVar18 + 1;
      iVar16 = CONCAT22((short)((uint)iVar18 >> 0x10),sVar3);
      if (SCARRY2((short)iVar18,1)) goto LAB_004b06ce;
      iStack_1b8 = iVar16;
    } while (sVar3 <= (short)iStack_1c0);
    if (0 < DAT_0050b25e) {
      if ((DAT_0050b1f8 != (short *)0x0) && (*DAT_0050b1f8 == 1)) {
        iVar18 = *(int *)(DAT_0050b1f8 + 10);
        iVar16 = (int)DAT_0050b25e;
        if (*(uint *)(DAT_0050b1f8 + 8) <= (uint)(iVar16 - iVar18)) {
          ppppcStack_1d4 = (code ****)0x4b0696;
          (*pcVar26)();
        }
        *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + (iVar16 - iVar18) * 2) = 0;
        return;
      }
      ppppcStack_1d4 = (code ****)0x4b06b2;
      iVar18 = (*pcVar26)();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
    }
  }
  return;
LAB_004b06ce:
  ppppcStack_1d4 = (code ****)0x4b06d4;
  __vbaErrorOverflow();
  DAT_0050b260._0_2_ = 0;
  DAT_0050b260._2_2_ = 0;
  ppppcStack_1d4 = ppppcVar23;
  if (DAT_0050b000 != 0) {
    adj_fdiv_m64((double)(int)DAT_0050b2c6,pcVar26,ppppcVar13,&ppppcStack_1d4,iVar16);
  }
  if (((in_FPUStatusWord & 0xd) == 0) && (__vbaFPInt(), (in_FPUStatusWord & 0xd) == 0)) {
    sVar4 = __vbaFpI2();
    sVar3 = DAT_0050b20a;
    sVar11 = DAT_0050b25e % DAT_0050b2c6;
    sVar17 = 1;
    psVar5 = DAT_0050b1f8;
    if (0 < DAT_0050b20a) {
      do {
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          iVar18 = __vbaGenerateBoundsError();
          psVar5 = DAT_0050b1f8;
        }
        else {
          iVar18 = *(int *)(psVar5 + 10);
          if (*(uint *)(psVar5 + 8) <= (uint)(sVar17 - iVar18)) {
            __vbaGenerateBoundsError();
            psVar5 = DAT_0050b1f8;
          }
          iVar18 = (sVar17 - iVar18) * 2;
        }
        if (*(short *)(*(int *)(psVar5 + 6) + iVar18) < 0) {
          if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
            iVar18 = __vbaGenerateBoundsError();
            psVar5 = DAT_0050b1f8;
          }
          else {
            iVar18 = *(int *)(psVar5 + 10);
            if (*(uint *)(psVar5 + 8) <= (uint)(sVar17 - iVar18)) {
              __vbaGenerateBoundsError();
              psVar5 = DAT_0050b1f8;
            }
            iVar18 = (sVar17 - iVar18) * 2;
          }
          *(undefined2 *)(*(int *)(psVar5 + 6) + iVar18) = 0;
          psVar5 = DAT_0050b1f8;
        }
        bVar27 = SCARRY2(sVar17,1);
        sVar17 = sVar17 + 1;
        if (bVar27) goto LAB_004b0da8;
      } while (sVar17 <= sVar3);
    }
    sVar17 = 1;
    sVar3 = (short)_DAT_0050b20c;
    if (0 < sVar3) {
      do {
        if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar16 = (int)sVar17;
          iVar18 = *(int *)(DAT_0050b0c4 + 0xe);
          if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar16 - iVar18)) {
            __vbaGenerateBoundsError();
          }
          iVar25 = *(int *)(DAT_0050b0c4 + 10);
          if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(sVar4 - iVar25)) {
            __vbaGenerateBoundsError();
          }
          iVar18 = (*(int *)(DAT_0050b0c4 + 0xc) * (sVar4 - iVar25) + (iVar16 - iVar18)) * 8;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar16 = __vbaGenerateBoundsError();
        }
        else {
          iVar25 = (int)sVar17;
          iVar16 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar25 - iVar16)) {
            __vbaGenerateBoundsError();
          }
          iVar16 = (iVar25 - iVar16) * 8;
        }
        iVar25 = *(int *)(DAT_0050b0c4 + 6);
        iVar1 = *(int *)(DAT_0050b0fc + 6);
        *(undefined4 *)(iVar1 + iVar16) = *(undefined4 *)(iVar25 + iVar18);
        *(undefined4 *)(iVar1 + 4 + iVar16) = *(undefined4 *)(iVar25 + 4 + iVar18);
        if (0 < sVar11) {
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iStack_1f0 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = (int)sVar17;
            iVar18 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar16 - iVar18)) {
              __vbaGenerateBoundsError();
            }
            iStack_1f0 = (iVar16 - iVar18) * 8;
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = (int)sVar17;
            iVar18 = *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar16 - iVar18)) {
              __vbaGenerateBoundsError();
            }
            if (SCARRY2(DAT_0050b2c4,sVar11)) {
LAB_004b0da8:
              __vbaErrorOverflow();
              FUN_004b0dd0(&DAT_0050b25e,0x50b262);
              FUN_00435420();
              return;
            }
            uVar15 = (int)(short)(DAT_0050b2c4 + sVar11) - *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= uVar15) {
              __vbaGenerateBoundsError();
            }
            iVar18 = (*(int *)(DAT_0050b0c4 + 0xc) * uVar15 + (iVar16 - iVar18)) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar16 = __vbaGenerateBoundsError();
          }
          else {
            iVar25 = (int)sVar17;
            iVar16 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(iVar25 - iVar16)) {
              __vbaGenerateBoundsError();
            }
            iVar16 = (iVar25 - iVar16) * 8;
          }
          *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar16) =
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + iVar18) +
               *(double *)(*(int *)(DAT_0050b0fc + 6) + iStack_1f0);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar17 - iVar18)) {
            __vbaGenerateBoundsError();
          }
          iVar18 = (sVar17 - iVar18) * 8;
        }
        if (*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar18) != _DAT_00401490) {
          if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
              iVar18 = __vbaGenerateBoundsError();
            }
            else {
              ppsVar14 = DAT_0050b1f0[5];
              if (DAT_0050b1f0[4] <= (short **)((int)sVar17 - (int)ppsVar14)) {
                __vbaGenerateBoundsError();
              }
              iVar18 = ((int)sVar17 - (int)ppsVar14) * 2;
            }
            uVar15 = (int)*(short *)((int)DAT_0050b1f0[3] + iVar18) - *(int *)(DAT_0050b1f8 + 10);
            if (*(uint *)(DAT_0050b1f8 + 8) <= uVar15) {
              __vbaGenerateBoundsError();
            }
            iVar18 = uVar15 * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0xffff;
        }
        if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar18 = *(int *)(DAT_0050b0fc + 10);
          if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar17 - iVar18)) {
            __vbaGenerateBoundsError();
          }
          iVar18 = (sVar17 - iVar18) * 8;
        }
        in_FPUStatusWord = 0;
        if (_DAT_0050b12c < *(double *)(*(int *)(DAT_0050b0fc + 6) + iVar18)) {
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(sVar17 - iVar18)) {
              __vbaGenerateBoundsError();
            }
            iVar18 = (sVar17 - iVar18) * 8;
          }
          if ((DAT_0050b0fc == (short *)0x0) || (*DAT_0050b0fc != 1)) {
            iVar16 = __vbaGenerateBoundsError();
          }
          else {
            iVar16 = *(int *)(DAT_0050b0fc + 10);
            if (*(uint *)(DAT_0050b0fc + 8) <= (uint)(sVar17 - iVar16)) {
              __vbaGenerateBoundsError();
            }
            iVar16 = (sVar17 - iVar16) * 8;
          }
          if (DAT_0050b000 == 0) {
            fVar28 = (float10)*(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar18) /
                     (float10)*(double *)(*(int *)(DAT_0050b0fc + 6) + iVar16);
          }
          else {
            fVar28 = (float10)adj_fdiv_m64();
          }
          _DAT_0050b124 = (double)fVar28;
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b0da3;
          fVar28 = (float10)__vbaFpR4();
          in_FPUStatusWord = 0;
          if (fVar28 < (float10)fStack_1ec) {
            if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
              iVar18 = __vbaGenerateBoundsError();
            }
            else {
              ppsVar14 = DAT_0050b1f0[5];
              if (DAT_0050b1f0[4] <= (short **)((int)sVar17 - (int)ppsVar14)) {
                __vbaGenerateBoundsError();
              }
              iVar18 = ((int)sVar17 - (int)ppsVar14) * 2;
            }
            fStack_1ec = (float)_DAT_0050b124;
            DAT_0050b260._0_2_ = *(short *)((int)DAT_0050b1f0[3] + iVar18);
            DAT_0050b260._2_2_ = sVar17;
          }
        }
        bVar27 = SCARRY2(sVar17,1);
        sVar17 = sVar17 + 1;
        if (bVar27) goto LAB_004b0da8;
        psVar5 = DAT_0050b1f8;
      } while (sVar17 <= sVar3);
    }
    if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
      iVar18 = __vbaGenerateBoundsError();
      psVar5 = DAT_0050b1f8;
    }
    else {
      iVar16 = (int)(short)DAT_0050b260;
      iVar18 = *(int *)(psVar5 + 10);
      if (*(uint *)(psVar5 + 8) <= (uint)(iVar16 - iVar18)) {
        __vbaGenerateBoundsError();
        psVar5 = DAT_0050b1f8;
      }
      iVar18 = (iVar16 - iVar18) * 2;
    }
    *(short *)(*(int *)(psVar5 + 6) + iVar18) = (short)DAT_0050b260;
    if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      iVar18 = (int)DAT_0050b260._2_2_;
      ppsVar14 = DAT_0050b1f0[5];
      if (DAT_0050b1f0[4] <= (short **)(iVar18 - (int)ppsVar14)) {
        __vbaGenerateBoundsError();
      }
      iVar18 = (iVar18 - (int)ppsVar14) * 2;
    }
    *(short *)((int)DAT_0050b1f0[3] + iVar18) = DAT_0050b25e;
    if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      iVar16 = (int)DAT_0050b25e;
      iVar18 = *(int *)(DAT_0050b0e8 + 10);
      if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar16 - iVar18)) {
        __vbaGenerateBoundsError();
      }
      iVar18 = (iVar16 - iVar18) * 8;
    }
    if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
      iVar16 = __vbaGenerateBoundsError();
    }
    else {
      iVar25 = (int)DAT_0050b260._2_2_;
      iVar16 = *(int *)(DAT_0050b0d8 + 10);
      if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(iVar25 - iVar16)) {
        __vbaGenerateBoundsError();
      }
      iVar16 = (iVar25 - iVar16) * 8;
    }
    iVar25 = *(int *)(DAT_0050b0d8 + 6);
    iVar1 = *(int *)(DAT_0050b0e8 + 6);
    *(undefined4 *)(iVar25 + iVar16) = *(undefined4 *)(iVar1 + iVar18);
    *(undefined4 *)(iVar25 + 4 + iVar16) = *(undefined4 *)(iVar1 + 4 + iVar18);
    return;
  }
LAB_004b0da3:
  __vbaFPException();
  return;
LAB_004ae7a0:
  uVar2 = _DAT_0050b2c4;
  ppppcVar23 = (code ****)__vbaGenerateBoundsError_exref;
  if ((short)ppppcVar22 < DAT_0050b20c) {
    local_28 = (float)_DAT_0050b134;
    local_18 = 1;
    psVar5 = DAT_0050b0e8;
    ppppcVar13 = local_40;
    uVar15 = local_18;
    while( true ) {
      local_18 = uVar15;
      local_12c = (short)uVar2;
      if (local_12c < (short)local_18) break;
      if ((ppppcVar13 == (code ****)0x0) || (*(short *)ppppcVar13 != 1)) {
        pppcStack_17c = (code ***)0x4ae814;
        iVar18 = __vbaGenerateBoundsError();
        psVar5 = DAT_0050b0e8;
        ppppcVar13 = local_40;
      }
      else {
        pppcVar21 = (code ***)((int)(short)local_18 - (int)ppppcVar13[5]);
        if (ppppcVar13[4] <= pppcVar21) {
          pppcStack_17c = (code ***)0x4ae801;
          __vbaGenerateBoundsError();
          psVar5 = DAT_0050b0e8;
          ppppcVar13 = local_40;
        }
        iVar18 = (int)pppcVar21 * 2;
      }
      unaff_EDI = (code ****)ppppcVar13[3];
      ppppcVar22 = unaff_EDI;
      if (*(short *)((int)unaff_EDI + iVar18) == 0) {
        if (SBORROW2((short)local_18,1)) goto LAB_004afc3d;
        iVar18 = (int)(short)((short)local_18 + -1) * (int)DAT_0050b2c6;
        sVar3 = (short)iVar18;
        if (sVar3 != iVar18) goto LAB_004afc3d;
        sVar4 = sVar3 + (short)local_44;
        ppppcVar22 = (code ****)CONCAT22((short)(local_18 >> 0x10),sVar4);
        if (SCARRY2(sVar3,(short)local_44)) goto LAB_004afc3d;
        if ((psVar5 == (short *)0x0) || (*psVar5 != 1)) {
          pppcStack_17c = (code ***)0x4ae87e;
          __vbaGenerateBoundsError();
        }
        else if (*(uint *)(psVar5 + 8) <= (uint)((int)sVar4 - *(int *)(psVar5 + 10))) {
          pppcStack_17c = (code ***)0x4ae86d;
          __vbaGenerateBoundsError();
        }
        pppcStack_17c = (code ***)0x4ae89c;
        fVar28 = (float10)__vbaFpR4();
        in_FPUStatusWord = 0;
        psVar5 = DAT_0050b0e8;
        ppppcVar13 = local_40;
        if (fVar28 < (float10)local_28) {
          if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
            pppcStack_17c = (code ***)0x4ae8d8;
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            iVar18 = *(int *)(DAT_0050b0e8 + 10);
            if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(sVar4 - iVar18)) {
              pppcStack_17c = (code ***)0x4ae8c7;
              __vbaGenerateBoundsError();
            }
            iVar18 = (sVar4 - iVar18) * 8;
          }
          local_28 = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar18);
          local_34 = local_18;
          psVar5 = DAT_0050b0e8;
          ppppcVar13 = local_40;
          local_4c = ppppcVar22;
        }
      }
      unaff_EDI = ppppcVar22;
      uVar15 = (uint)(ushort)((short)local_18 + 1);
      if (SCARRY2((short)local_18,1)) goto LAB_004afc3d;
    }
    if ((ppppcVar13 == (code ****)0x0) || (*(short *)ppppcVar13 != 1)) {
      pppcStack_17c = (code ***)0x4ae93f;
      iVar18 = __vbaGenerateBoundsError();
      ppppcVar13 = local_40;
    }
    else {
      ppppcVar22 = (code ****)((int)(short)local_34 - (int)ppppcVar13[5]);
      if (ppppcVar13[4] <= ppppcVar22) {
        pppcStack_17c = (code ***)0x4ae935;
        __vbaGenerateBoundsError();
        ppppcVar13 = local_40;
      }
      iVar18 = (int)ppppcVar22 * 2;
    }
    sVar3 = (short)local_60 + 1;
    unaff_EDI = (code ****)CONCAT22((short)((uint)ppppcVar22 >> 0x10),sVar3);
    *(undefined2 *)((int)ppppcVar13[3] + iVar18) = 1;
    if (SCARRY2((short)local_60,1)) goto LAB_004afc3d;
    local_60 = unaff_EDI;
    if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
      pppcStack_17c = (code ***)0x4ae98e;
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      iVar18 = *(int *)(DAT_0050b0f4 + 10);
      if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(sVar3 - iVar18)) {
        pppcStack_17c = (code ***)0x4ae97d;
        __vbaGenerateBoundsError();
      }
      iVar18 = (sVar3 - iVar18) * 8;
    }
    iVar16 = *(int *)(DAT_0050b0f4 + 6);
    *(undefined4 *)(iVar16 + iVar18) = 0;
    *(undefined4 *)(iVar16 + 4 + iVar18) = 0;
    if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
      pppcStack_17c = (code ***)0x4ae9d4;
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      ppsVar14 = DAT_0050b1f0[5];
      if (DAT_0050b1f0[4] <= (short **)((int)sVar3 - (int)ppsVar14)) {
        pppcStack_17c = (code ***)0x4ae9c7;
        __vbaGenerateBoundsError();
      }
      iVar18 = ((int)sVar3 - (int)ppsVar14) * 2;
    }
    *(short *)((int)DAT_0050b1f0[3] + iVar18) = (short)local_4c;
    ppppcVar22 = unaff_EDI;
    if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
      pppcStack_17c = (code ***)0x4aea1c;
      iVar18 = __vbaGenerateBoundsError();
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) = 0;
    }
    else {
      uVar15 = (int)(short)local_4c - *(int *)(DAT_0050b1f8 + 10);
      if (*(uint *)(DAT_0050b1f8 + 8) <= uVar15) {
        pppcStack_17c = (code ***)0x4aea03;
        __vbaGenerateBoundsError();
      }
      *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + uVar15 * 2) = 0;
    }
    goto LAB_004ae7a0;
  }
LAB_004afa7b:
  ppppcVar22 = _DAT_0050b20c;
  uVar15 = 1;
  do {
    local_134 = (short)ppppcVar22;
    local_18 = uVar15;
    if (local_134 < (short)uVar15) {
      pppcStack_17c = (code ***)0x4afbec;
      FUN_00435420();
      pppcStack_17c = (code ***)&LAB_004afc27;
      ppppcStack_180 = local_24;
      ppppsStack_184 = (short ****)0x0;
      pppppsStack_188 = (short *****)0x4afc1e;
      __vbaAryDestruct();
      pppppsStack_188 = (short *****)&local_40;
      uStack_18c = (short *****)0x0;
      ppppcStack_190 = (code ****)0x4afc26;
      __vbaAryDestruct();
      return;
    }
    if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
      pppcStack_17c = (code ***)0x4afb1e;
      unaff_EDI = (code ****)__vbaGenerateBoundsError();
      sVar3 = (short)local_18;
    }
    else {
      if ((DAT_0050b1f0 == (short ***)0x0) || (*(short *)DAT_0050b1f0 != 1)) {
        pppcStack_17c = (code ***)0x4afae5;
        iVar18 = __vbaGenerateBoundsError();
        sVar3 = (short)local_18;
      }
      else {
        ppsVar14 = (short **)((int)(short)uVar15 - (int)DAT_0050b1f0[5]);
        if (DAT_0050b1f0[4] <= ppsVar14) {
          pppcStack_17c = (code ***)0x4afad1;
          __vbaGenerateBoundsError();
        }
        sVar3 = (short)local_18;
        iVar18 = (int)ppsVar14 * 2;
      }
      uVar15 = (int)*(short *)((int)DAT_0050b1f0[3] + iVar18) - *(int *)(DAT_0050b0e8 + 10);
      if (*(uint *)(DAT_0050b0e8 + 8) <= uVar15) {
        pppcStack_17c = (code ***)0x4afb0c;
        __vbaGenerateBoundsError();
        sVar3 = (short)local_18;
      }
      unaff_EDI = (code ****)(uVar15 * 8);
    }
    if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
      pppcStack_17c = (code ***)0x4afb5b;
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      iVar18 = *(int *)(DAT_0050b0d8 + 10);
      if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(sVar3 - iVar18)) {
        pppcStack_17c = (code ***)0x4afb46;
        __vbaGenerateBoundsError();
      }
      iVar18 = (sVar3 - iVar18) * 8;
    }
    iVar16 = *(int *)(DAT_0050b0d8 + 6);
    iVar25 = *(int *)(DAT_0050b0e8 + 6);
    ppppcVar13 = *(code *****)((int)unaff_EDI + iVar25);
    *(code *****)(iVar16 + iVar18) = ppppcVar13;
    *(undefined4 *)(iVar16 + 4 + iVar18) = *(undefined4 *)((int)unaff_EDI + iVar25 + 4);
    ppppcStack_180 = &local_68;
    pppcStack_17c = (code ***)DAT_0050b1f0;
    ppppsStack_184 = (short ****)0x4afb8c;
    __vbaAryLock();
    if ((local_68 == (code ***)0x0) || (*(short *)local_68 != 1)) {
      ppppsStack_184 = (short ****)0x4afbbd;
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      ppppcVar13 = (code ****)((int)(short)local_18 - (int)local_68[5]);
      if (local_68[4] <= ppppcVar13) {
        ppppsStack_184 = (short ****)0x4afbaf;
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)ppppcVar13 * 2;
    }
    ppppsStack_184 = (short ****)&local_18;
    pppppsStack_188 = (short *****)((int)local_68[3] + iVar18);
    uStack_18c = (short *****)0x4afbcf;
    FUN_004b0dd0();
    ppppsStack_184 = (short ****)&local_68;
    pppppsStack_188 = (short *****)0x4afbd9;
    __vbaAryUnlock();
    uVar15 = CONCAT22(extraout_var,(short)local_18 + 1);
    ppppcVar23 = (code ****)&DAT_00000001;
  } while (!SCARRY2((short)local_18,1));
LAB_004afc3d:
  pppcStack_17c = (code ***)0x4afc43;
  __vbaErrorOverflow();
  ppppcStack_194 = &pppcStack_17c;
  ppppsVar9 = (short ****)&pppcStack_17c;
  _DAT_0050b14c = 0.0;
  uStack_18c = (short *****)CONCAT22(DAT_0050b20c,(short)uStack_18c);
  ppppsStack_184 = (short ****)&DAT_00000001;
  ppppcStack_19c = unaff_EDI;
  ppppcStack_198 = ppppcVar13;
  ppppcVar22 = &pppcStack_17c;
  ppppcStack_190 = ppppcVar23;
  pppcStack_17c = (code ***)&stack0xfffffffc;
  pppcVar21 = (code ***)&stack0xfffffffc;
  if (0 < DAT_0050b20c) {
    do {
      pppcStack_17c = pppcVar21;
      ppppcStack_194 = ppppcVar22;
      ppppsVar8 = ppppsStack_184;
      ppppsVar9 = (short ****)__vbaGenerateBoundsError_exref;
      if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
        ppppcStack_1a0 = (code ****)0x4afcc1;
        iVar18 = __vbaGenerateBoundsError();
        ppppsVar9 = (short ****)__vbaGenerateBoundsError_exref;
      }
      else {
        ppppcVar13 = (code ****)((int)(short)ppppsStack_184 - *(int *)(DAT_0050b0f4 + 10));
        if (*(code *****)(DAT_0050b0f4 + 8) <= ppppcVar13) {
          ppppcStack_1a0 = (code ****)0x4afcb2;
          __vbaGenerateBoundsError();
        }
        iVar18 = (int)ppppcVar13 * 8;
      }
      pppppsStack_188 = (short *****)&DAT_00000001;
      iVar16 = *(int *)(DAT_0050b0f4 + 6);
      *(undefined4 *)(iVar16 + iVar18) = 0;
      *(undefined4 *)(iVar16 + 4 + iVar18) = 0;
      uStack_18c = (short *****)CONCAT22(uStack_18c._2_2_,DAT_0050b20c);
      if (0 < DAT_0050b20c) {
        do {
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            ppppcStack_1a0 = (code ****)0x4afd27;
            ppppcStack_180 = (code ****)(*(code *)ppppsVar9)();
          }
          else {
            uVar15 = (int)(short)ppppsVar8 - *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= uVar15) {
              ppppcStack_1a0 = (code ****)0x4afd1c;
              (*(code *)ppppsVar9)();
            }
            ppppcStack_180 = (code ****)(uVar15 * 8);
          }
          if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
            ppppcStack_1a0 = (code ****)0x4afd77;
            ppppcVar23 = (code ****)(*(code *)ppppsVar9)();
          }
          else {
            uVar15 = (int)(short)ppppsVar8 - *(int *)(DAT_0050b0c4 + 0xe);
            if (*(uint *)(DAT_0050b0c4 + 0xc) <= uVar15) {
              ppppcStack_1a0 = (code ****)0x4afd4b;
              (*(code *)ppppsVar9)();
            }
            iVar16 = (int)(short)pppppsStack_188;
            iVar18 = *(int *)(DAT_0050b0c4 + 10);
            if (*(uint *)(DAT_0050b0c4 + 8) <= (uint)(iVar16 - iVar18)) {
              ppppcStack_1a0 = (code ****)0x4afd63;
              (*(code *)ppppsVar9)();
            }
            ppppcVar23 = (code ****)
                         ((*(int *)(DAT_0050b0c4 + 0xc) * (iVar16 - iVar18) + uVar15) * 8);
          }
          if ((DAT_0050b0c0 == (short *)0x0) || (*DAT_0050b0c0 != 2)) {
            ppppcStack_1a0 = (code ****)0x4afdcc;
            ppppcVar13 = (code ****)(*(code *)ppppsVar9)();
          }
          else {
            iVar16 = (int)(short)pppppsStack_188;
            iVar18 = *(int *)(DAT_0050b0c0 + 0xe);
            if (*(uint *)(DAT_0050b0c0 + 0xc) <= (uint)(iVar16 - iVar18)) {
              ppppcStack_1a0 = (code ****)0x4afd9b;
              (*(code *)ppppsVar9)();
            }
            iVar25 = *(int *)(DAT_0050b0c0 + 10);
            if (*(uint *)(DAT_0050b0c0 + 8) <= (uint)-iVar25) {
              ppppcStack_1a0 = (code ****)0x4afdb2;
              __vbaGenerateBoundsError();
            }
            ppppcVar13 = (code ****)
                         ((*(int *)(DAT_0050b0c0 + 0xc) * -iVar25 + (iVar16 - iVar18)) * 8);
            ppppsVar9 = (short ****)__vbaGenerateBoundsError_exref;
          }
          if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
            ppppcStack_1a0 = (code ****)0x4afe06;
            iVar18 = (*(code *)ppppsVar9)();
          }
          else {
            iVar16 = (int)(short)ppppsStack_184;
            iVar18 = *(int *)(DAT_0050b0f4 + 10);
            if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)(iVar16 - iVar18)) {
              ppppcStack_1a0 = (code ****)0x4afdf6;
              (*(code *)ppppsVar9)();
            }
            iVar18 = (iVar16 - iVar18) * 8;
          }
          *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar18) =
               *(double *)((int)ppppcVar13 + *(int *)(DAT_0050b0c0 + 6)) *
               *(double *)(*(int *)(DAT_0050b0c4 + 6) + (int)ppppcVar23) +
               *(double *)(*(int *)(DAT_0050b0f4 + 6) + (int)ppppcStack_180);
          if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004b00c9;
          sVar3 = (short)pppppsStack_188 + 1;
          ppppcVar22 = (code ****)CONCAT22((short)((uint)ppppcStack_180 >> 0x10),sVar3);
          ppppsVar8 = ppppsStack_184;
          if (SCARRY2((short)pppppsStack_188,1)) goto LAB_004b00ce;
          pppppsStack_188 = (short *****)ppppcVar22;
        } while (sVar3 <= (short)uStack_18c);
      }
      sVar3 = (short)ppppsVar8;
      if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
        ppppcStack_1a0 = (code ****)0x4afe89;
        ppppcVar23 = (code ****)(*(code *)ppppsVar9)();
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b0d8 + 10));
        if (*(code *****)(DAT_0050b0d8 + 8) <= ppppcVar13) {
          ppppcStack_1a0 = (code ****)0x4afe7e;
          (*(code *)ppppsVar9)();
        }
        ppppcVar23 = (code ****)((int)ppppcVar13 * 8);
      }
      if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
        ppppcStack_1a0 = (code ****)0x4afeb6;
        iVar18 = (*(code *)ppppsVar9)();
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b0f4 + 10));
        if (*(code *****)(DAT_0050b0f4 + 8) <= ppppcVar13) {
          ppppcStack_1a0 = (code ****)0x4afeab;
          (*(code *)ppppsVar9)();
        }
        iVar18 = (int)ppppcVar13 * 8;
      }
      _DAT_0050b14c =
           *(double *)(*(int *)(DAT_0050b0f4 + 6) + iVar18) *
           *(double *)(*(int *)(DAT_0050b0d8 + 6) + (int)ppppcVar23) + _DAT_0050b14c;
      if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004b00c9:
        __vbaFPException();
        return;
      }
      ppppsVar8 = (short ****)CONCAT22((short)((uint)ppppsVar8 >> 0x10),sVar3 + 1);
      if (SCARRY2(sVar3,1)) goto LAB_004b00ce;
      ppppcVar22 = ppppcStack_194;
      ppppsStack_184 = ppppsVar8;
      pppcVar21 = pppcStack_17c;
    } while ((short)(sVar3 + 1) <= uStack_18c._2_2_);
  }
  ppppsVar9 = (short ****)CONCAT22((short)((uint)ppppsVar9 >> 0x10),DAT_0050b20a);
  uStack_18c = (short *****)CONCAT22(DAT_0050b20a,(short)uStack_18c);
  pppppsStack_188 = (short *****)&DAT_00000001;
  if (0 < DAT_0050b20a) {
    do {
      pppppsVar24 = pppppsStack_188;
      ppppsVar8 = (short ****)__vbaGenerateBoundsError_exref;
      sVar3 = (short)pppppsStack_188;
      if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
        ppppcStack_1a0 = (code ****)0x4aff5b;
        iVar18 = __vbaGenerateBoundsError();
        ppppsVar8 = (short ****)__vbaGenerateBoundsError_exref;
      }
      else {
        ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b1f8 + 10));
        if (*(code *****)(DAT_0050b1f8 + 8) <= ppppcVar13) {
          ppppcStack_1a0 = (code ****)0x4aff4a;
          __vbaGenerateBoundsError();
        }
        iVar18 = (int)ppppcVar13 * 2;
      }
      if (*(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar18) < 1) {
        uVar10 = (undefined2)((uint)ppppsVar9 >> 0x10);
        sVar3 = DAT_0050b20c;
        ppppsVar9 = (short ****)CONCAT22(uVar10,DAT_0050b20c);
        ppppcVar23 = (code ****)&DAT_00000001;
        uVar12 = 1;
        pppsVar7 = DAT_0050b1f0;
        if (0 < DAT_0050b20c) {
          do {
            uVar12 = (ushort)ppppcVar23;
            if ((pppsVar7 == (short ***)0x0) || (*(short *)pppsVar7 != 1)) {
              ppppcStack_1a0 = (code ****)0x4affff;
              iVar18 = (*(code *)ppppsVar8)();
              pppsVar7 = DAT_0050b1f0;
            }
            else {
              ppppcVar13 = (code ****)((int)(short)uVar12 - (int)pppsVar7[5]);
              if (pppsVar7[4] <= ppppcVar13) {
                ppppcStack_1a0 = (code ****)0x4afff2;
                (*(code *)ppppsVar8)();
                pppsVar7 = DAT_0050b1f0;
              }
              iVar18 = (int)ppppcVar13 * 2;
            }
            ppppcVar13 = (code ****)
                         CONCAT22((short)((uint)ppppcVar13 >> 0x10),(short)pppppsStack_188);
            if ((short)pppppsStack_188 == *(short *)((int)pppsVar7[3] + iVar18)) break;
            bVar27 = SCARRY2(uVar12,1);
            uVar12 = uVar12 + 1;
            ppppcVar23 = (code ****)(uint)uVar12;
            if (bVar27) goto LAB_004b00ce;
          } while ((short)uVar12 <= sVar3);
        }
        if ((DAT_0050b0f4 == (short *)0x0) || (*DAT_0050b0f4 != 1)) {
          ppppcStack_1a0 = (code ****)0x4b004d;
          iVar18 = (*(code *)ppppsVar8)();
        }
        else {
          iVar18 = *(int *)(DAT_0050b0f4 + 10);
          if (*(uint *)(DAT_0050b0f4 + 8) <= (uint)((short)uVar12 - iVar18)) {
            ppppcStack_1a0 = (code ****)0x4b0042;
            (*(code *)ppppsVar8)();
          }
          iVar18 = ((short)uVar12 - iVar18) * 8;
        }
        if ((DAT_0050b0ec == (short *)0x0) || (*DAT_0050b0ec != 1)) {
          ppppcStack_1a0 = (code ****)0x4b0083;
          iVar16 = (*(code *)ppppsVar8)();
        }
        else {
          iVar25 = (int)(short)pppppsStack_188;
          iVar16 = *(int *)(DAT_0050b0ec + 10);
          if (*(uint *)(DAT_0050b0ec + 8) <= (uint)(iVar25 - iVar16)) {
            ppppcStack_1a0 = (code ****)0x4b0072;
            (*(code *)ppppsVar8)();
          }
          iVar16 = (iVar25 - iVar16) * 8;
        }
        iVar25 = *(int *)(DAT_0050b0ec + 6);
        ppppsVar9 = (short ****)CONCAT22(uVar10,uStack_18c._2_2_);
        iVar1 = *(int *)(DAT_0050b0f4 + 6);
        ppppcVar13 = *(code *****)(iVar1 + iVar18);
        *(code *****)(iVar25 + iVar16) = ppppcVar13;
        *(undefined4 *)(iVar25 + 4 + iVar16) = *(undefined4 *)(iVar1 + 4 + iVar18);
        pppppsVar24 = pppppsStack_188;
      }
      else {
        if ((DAT_0050b0ec == (short *)0x0) || (*DAT_0050b0ec != 1)) {
          ppppcStack_1a0 = (code ****)0x4affa3;
          iVar18 = (*(code *)ppppsVar8)();
        }
        else {
          ppppcVar13 = (code ****)((int)sVar3 - *(int *)(DAT_0050b0ec + 10));
          if (*(code *****)(DAT_0050b0ec + 8) <= ppppcVar13) {
            ppppcStack_1a0 = (code ****)0x4aff92;
            (*(code *)ppppsVar8)();
          }
          iVar18 = (int)ppppcVar13 * 8;
        }
        iVar16 = *(int *)(DAT_0050b0ec + 6);
        *(undefined4 *)(iVar16 + iVar18) = 0;
        *(undefined4 *)(iVar16 + 4 + iVar18) = 0;
      }
      sVar3 = (short)pppppsVar24 + 1;
      ppppcVar23 = (code ****)CONCAT22((short)((uint)pppppsVar24 >> 0x10),sVar3);
      if (SCARRY2((short)pppppsVar24,1)) goto LAB_004b00ce;
      pppppsStack_188 = (short *****)ppppcVar23;
    } while (sVar3 <= (short)ppppsVar9);
  }
  return;
}


