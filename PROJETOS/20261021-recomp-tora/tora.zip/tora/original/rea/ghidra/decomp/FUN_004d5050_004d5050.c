/* entry 004d5050 name FUN_004d5050 size 1625 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d5050(void)

{
  int *****pppppiVar1;
  int ****ppppiVar2;
  int ***pppiVar3;
  undefined1 *puVar4;
  int iVar5;
  undefined4 uVar6;
  ushort uVar7;
  float10 fVar8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  int ****ppppiStack_1ec;
  int iStack_1e8;
  int iStack_1e4;
  int ****ppppiStack_1c8;
  undefined4 uStack_1b0;
  undefined4 uStack_1a8;
  undefined4 uStack_190;
  float fStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_170;
  float fStack_16c;
  undefined4 uStack_168;
  int ***pppiStack_164;
  int ****ppppiStack_160;
  undefined *puStack_15c;
  wchar_t *pwStack_158;
  int ****ppppiStack_154;
  int ****ppppiStack_150;
  int ***pppiStack_14c;
  int ****ppppiStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined *puStack_13c;
  undefined4 uStack_138;
  int iStack_134;
  int ****ppppiStack_130;
  undefined *puStack_12c;
  int ****ppppiStack_128;
  int ****ppppiStack_124;
  int ****ppppiStack_120;
  int ****ppppiStack_11c;
  int ****ppppiStack_118;
  int ****ppppiStack_114;
  int ****ppppiStack_110;
  int ****ppppiStack_10c;
  int ***pppiStack_108;
  int ****ppppiStack_104;
  int ****ppppiStack_100;
  int ****ppppiStack_fc;
  int **ppiStack_f8;
  int ****ppppiStack_f4;
  int ****ppppiStack_f0;
  int ***pppiStack_ec;
  int ****ppppiStack_e8;
  int ****ppppiStack_e4;
  int ****ppppiStack_e0;
  undefined4 uStack_dc;
  int iStack_d8;
  int ****ppppiStack_d4;
  undefined *puStack_d0;
  undefined1 *puStack_cc;
  int ****ppppiStack_c8;
  int ****ppppiStack_c4;
  int ***pppiStack_c0;
  int ****ppppiStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined *puStack_b0;
  undefined4 uStack_ac;
  int iStack_a8;
  int ****ppppiStack_a4;
  undefined *puStack_a0;
  undefined4 uStack_9c;
  int ****ppppiStack_98;
  int ****ppppiStack_94;
  int ***local_6c;
  int *local_68;
  int **local_64 [6];
  int ****local_4c;
  int ****local_48;
  int **local_44;
  int ****local_3c;
  float local_38;
  undefined4 local_34;
  int ***local_30 [4];
  int ****local_20;
  int ****local_1c;
  int ***local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff70;
  local_8 = &DAT_00402410;
  local_18 = (int ***)0x0;
  local_1c = (int ****)0x0;
  local_20 = (int ****)0x0;
  local_30[0] = (int ***)0x0;
  local_64[0] = (int **)0x0;
  local_68 = (int *)0x0;
  local_6c = (int ***)0x0;
  ExceptionList = &pvStack_14;
  puVar4 = &stack0xffffff70;
  if (DAT_0050c53c == (int *****)0x0) {
    ppppiStack_94 = (int ****)&DAT_0050c53c;
    ppppiStack_98 = (int ****)&DAT_0040b420;
    uStack_9c = 0x4d50ae;
    ExceptionList = &pvStack_14;
    __vbaNew2();
    puVar4 = local_c;
  }
  local_c = puVar4;
  pppppiVar1 = DAT_0050c53c;
  ppppiStack_94 = (int ****)&local_1c;
  ppppiStack_98 = (int ****)DAT_0050c53c;
  uStack_9c = 0x4d50be;
  iStack_a8 = (*(code *)(*DAT_0050c53c)[8])();
  uVar7 = 0;
  if (iStack_a8 < 0) {
    uStack_9c = 0x20;
    puStack_a0 = &DAT_0040b410;
    ppppiStack_a4 = (int ****)pppppiVar1;
    uStack_ac = 0x4d50d3;
    __vbaHresultCheckObj();
  }
  ppppiVar2 = local_3c;
  uStack_ac = 2;
  puStack_b0 = &DAT_0040eb6c;
  iStack_a8 = 2;
  uStack_b4 = 0;
  uStack_b8 = 0x10028;
  ppppiStack_a4 = local_3c;
  ppppiStack_bc = local_1c;
  puStack_a0 = (undefined *)0xa;
  uStack_9c = local_34;
  pppiStack_c0 = (int ***)local_30;
  ppppiStack_c4 = (int ****)0x4d5109;
  uStack_b4 = __vbaLateIdCallLd();
  uStack_b8 = 0x4d5113;
  uStack_b8 = __vbaCastObjVar();
  ppppiStack_bc = (int ****)&local_20;
  pppiStack_c0 = (int ***)0x4d511e;
  pppiStack_c0 = (int ***)__vbaObjSet();
  ppppiStack_c4 = (int ****)0x4d5125;
  __vbaLateIdSt();
  ppppiStack_c4 = (int ****)&local_20;
  ppppiStack_c8 = (int ****)&local_1c;
  puStack_cc = (undefined1 *)0x2;
  puStack_d0 = (undefined *)0x4d5135;
  __vbaFreeObjList();
  ppppiStack_c4 = (int ****)0x4d5141;
  __vbaFreeVar();
  iVar5 = (int)((longlong)DAT_0050b26c * 4);
  if (((longlong)iVar5 != (longlong)DAT_0050b26c * 4) || (SCARRY4(iVar5,1000))) {
    ppppiStack_c4 = (int ****)0x4d56d8;
    __vbaErrorOverflow();
    puStack_d0 = &DAT_00402706;
    ppppiStack_d4 = ExceptionList;
    ppppiStack_1ec = ppppiVar2;
    uStack_1f0 = 4;
    puStack_cc = (undefined1 *)&uStack_1f4;
    uStack_1f4 = 0;
    ppppiStack_c8 = (int ****)&DAT_00402428;
    if ((uVar7 & 0xd) == 0) {
      uStack_dc = 0;
      ppppiStack_e0 = (int ****)0x0;
      ppppiStack_e4 = (int ****)0x0;
      ppppiStack_f4 = (int ****)0x0;
      ppppiStack_104 = (int ****)0x0;
      ExceptionList = &ppppiStack_d4;
      puStack_cc = (undefined1 *)&uStack_1f4;
      ppppiStack_c4 = (int ****)&stack0xfffffffc;
      iStack_d8 = __vbaFpI2();
      if (DAT_0050c53c == (int *****)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      pppppiVar1 = DAT_0050c53c;
      iVar5 = (*(code *)(*DAT_0050c53c)[8])(DAT_0050c53c,&uStack_dc);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,pppppiVar1,&DAT_0040b410,0x20);
      }
      pppiVar3 = pppiStack_108;
      ppppiVar2 = ppppiStack_110;
      __vbaLateIdSt(uStack_dc,0x10013,2,ppppiStack_110,1,pppiStack_108);
      __vbaFreeObj();
      iStack_1e4 = (int)*(short *)ppppiStack_bc;
      ppppiStack_10c = (int ****)(float)iStack_1e4;
      if (DAT_0050c53c == (int *****)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      ppppiStack_1c8 = (int ****)DAT_0050c53c;
      iVar5 = (*(code *)(*DAT_0050c53c)[8])(DAT_0050c53c,&uStack_dc);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,ppppiStack_1c8,&DAT_0040b410,0x20);
      }
      __vbaLateIdSt(uStack_dc,0x1000b,4,ppppiVar2,ppppiStack_10c,pppiVar3);
      __vbaFreeObj();
      if (DAT_0050c53c == (int *****)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      pppppiVar1 = DAT_0050c53c;
      iVar5 = (*(code *)(*DAT_0050c53c)[8])(DAT_0050c53c,&uStack_dc);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,pppppiVar1,&DAT_0040b410,0x20);
      }
      uVar6 = __vbaLateIdCallLd(&ppppiStack_f4,uStack_dc,0x1000b,0);
      fVar8 = (float10)__vbaR4Var(uVar6);
      iStack_1e8 = (int)(short)iStack_d8;
      pppiStack_14c = (int ***)(float)fVar8;
      fStack_16c = (float)iStack_1e8;
      if (DAT_0050c53c == (int *****)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      pppppiVar1 = DAT_0050c53c;
      iVar5 = (*(code *)(*DAT_0050c53c)[8])(DAT_0050c53c,&ppppiStack_e0);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,pppppiVar1,&DAT_0040b410,0x20);
      }
      uVar6 = __vbaLateIdCallLd(&ppppiStack_104,ppppiStack_e0,0x1000b,0);
      fVar8 = (float10)__vbaR4Var(uVar6);
      fStack_18c = (float)fVar8;
      if (DAT_0050c53c == (int *****)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      ppppiStack_1c8 = (int ****)DAT_0050c53c;
      iVar5 = (*(code *)(*DAT_0050c53c)[8])(DAT_0050c53c,&ppppiStack_e4);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,ppppiStack_1c8,&DAT_0040b410,0x20);
      }
      __vbaLateIdCall(ppppiStack_e4,0x20004,6,3,uStack_1b0,0,uStack_1a8,4,uStack_190,fStack_18c,
                      uStack_188,4,uStack_170,fStack_16c,uStack_168,4,ppppiStack_150,pppiStack_14c,
                      ppppiStack_148,4,ppppiStack_130,0x44960000,ppppiStack_128,2,ppppiStack_110,4,
                      pppiStack_108);
      __vbaFreeObjList(3,&uStack_dc,&ppppiStack_e0,&ppppiStack_e4);
      __vbaFreeVarList(2,&ppppiStack_f4,&ppppiStack_104);
      if (DAT_0050c53c == (int *****)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      pppppiVar1 = DAT_0050c53c;
      iVar5 = (*(code *)(*DAT_0050c53c)[8])(DAT_0050c53c,&uStack_dc);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,pppppiVar1,&DAT_0040b410,0x20);
      }
      uVar6 = __vbaLateIdCallLd(&ppppiStack_f4,uStack_dc,0x1000b,0);
      __vbaR4Var(uVar6);
      DAT_0050b268 = __vbaFpI4();
      __vbaFreeObj();
      __vbaFreeVar();
      return;
    }
    ExceptionList = &ppppiStack_d4;
    ppppiStack_c4 = (int ****)&stack0xfffffffc;
    __vbaFPException();
    return;
  }
  local_38 = (float)(iVar5 + 1000);
  if (DAT_0050c53c == (int *****)0x0) {
    ppppiStack_c4 = (int ****)&DAT_0050c53c;
    ppppiStack_c8 = (int ****)&DAT_0040b420;
    puStack_cc = (undefined1 *)0x4d5181;
    __vbaNew2();
  }
  pppppiVar1 = DAT_0050c53c;
  ppppiStack_c4 = (int ****)&local_1c;
  ppppiStack_c8 = (int ****)DAT_0050c53c;
  puStack_cc = (undefined1 *)0x4d5191;
  iStack_d8 = (*(code *)(*DAT_0050c53c)[8])();
  if (iStack_d8 < 0) {
    puStack_cc = (undefined1 *)0x20;
    puStack_d0 = &DAT_0040b410;
    ppppiStack_d4 = (int ****)pppppiVar1;
    uStack_dc = 0x4d51a6;
    __vbaHresultCheckObj();
  }
  uStack_dc = 0x1000b;
  iStack_d8 = 4;
  ppppiStack_d4 = ppppiVar2;
  puStack_d0 = (undefined *)local_38;
  puStack_cc = (undefined1 *)local_34;
  ppppiStack_e0 = local_1c;
  ppppiStack_e4 = (int ****)0x4d51cb;
  __vbaLateIdSt();
  ppppiStack_e4 = (int ****)0x4d51d4;
  __vbaFreeObj();
  if (DAT_0050c53c == (int *****)0x0) {
    ppppiStack_e4 = (int ****)&DAT_0050c53c;
    ppppiStack_e8 = (int ****)&DAT_0040b420;
    pppiStack_ec = (int ***)0x4d51f2;
    __vbaNew2();
  }
  pppppiVar1 = DAT_0050c53c;
  ppppiStack_e4 = (int ****)&local_1c;
  ppppiStack_e8 = (int ****)DAT_0050c53c;
  pppiStack_ec = (int ***)0x4d5202;
  ppiStack_f8 = (int **)(*(code *)(*DAT_0050c53c)[8])();
  uVar7 = 0;
  if ((int)ppiStack_f8 < 0) {
    pppiStack_ec = (int ***)0x20;
    ppppiStack_f0 = (int ****)&DAT_0040b410;
    ppppiStack_f4 = (int ****)pppppiVar1;
    ppppiStack_fc = (int ****)0x4d5217;
    __vbaHresultCheckObj();
  }
  ppppiStack_fc = (int ****)&DAT_00000001;
  ppppiStack_100 = (int ****)0x2000a;
  ppiStack_f8 = (int **)0x4008;
  ppppiStack_104 = local_1c;
  ppppiStack_f4 = ppppiVar2;
  ppppiStack_f0 = (int ****)&DAT_0050b348;
  pppiStack_ec = (int ***)local_34;
  pppiStack_108 = (int ***)local_30;
  ppppiStack_10c = (int ****)0x4d5244;
  __vbaLateIdCallLd();
  pppiStack_ec = (int ***)local_30;
  ppppiStack_f0 = (int ****)0x4d5251;
  fVar8 = (float10)__vbaR4Var();
  local_48 = (int ****)(float)(((float10)_DAT_00402408 - fVar8) * (float10)_DAT_00401268);
  if ((uVar7 & 0xd) == 0) {
    if (DAT_0050c53c == (int *****)0x0) {
      ppppiStack_f0 = (int ****)&DAT_0050c53c;
      ppppiStack_f4 = (int ****)&DAT_0040b420;
      ppiStack_f8 = (int **)0x4d5288;
      __vbaNew2();
    }
    pppppiVar1 = DAT_0050c53c;
    ppppiStack_f0 = (int ****)&local_20;
    ppppiStack_f4 = (int ****)DAT_0050c53c;
    ppiStack_f8 = (int **)0x4d5298;
    ppppiStack_104 = (int ****)(*(code *)(*DAT_0050c53c)[8])();
    if ((int)ppppiStack_104 < 0) {
      ppiStack_f8 = (int **)0x20;
      ppppiStack_fc = (int ****)&DAT_0040b410;
      ppppiStack_100 = (int ****)pppppiVar1;
      pppiStack_108 = (int ***)0x4d52ad;
      __vbaHresultCheckObj();
    }
    pppiStack_108 = (int ***)0x1000a;
    ppppiStack_104 = (int ****)0x4;
    ppppiStack_100 = local_4c;
    ppppiStack_fc = local_48;
    ppppiStack_10c = local_20;
    ppiStack_f8 = local_44;
    ppppiStack_110 = (int ****)0x4d52d5;
    __vbaLateIdSt();
    ppppiStack_110 = (int ****)&local_20;
    ppppiStack_114 = (int ****)&local_1c;
    ppppiStack_118 = (int ****)0x2;
    ppppiStack_11c = (int ****)0x4d52e5;
    __vbaFreeObjList();
    ppppiStack_110 = (int ****)0x4d52f1;
    __vbaFreeVar();
    if (DAT_0050c53c == (int *****)0x0) {
      ppppiStack_110 = (int ****)&DAT_0050c53c;
      ppppiStack_114 = (int ****)&DAT_0040b420;
      ppppiStack_118 = (int ****)0x4d530a;
      __vbaNew2();
    }
    pppppiVar1 = DAT_0050c53c;
    ppppiStack_110 = (int ****)&local_1c;
    ppppiStack_114 = (int ****)DAT_0050c53c;
    ppppiStack_118 = (int ****)0x4d531a;
    ppppiStack_124 = (int ****)(*(code *)(*DAT_0050c53c)[8])();
    if ((int)ppppiStack_124 < 0) {
      ppppiStack_118 = (int ****)0x20;
      ppppiStack_11c = (int ****)&DAT_0040b410;
      ppppiStack_120 = (int ****)pppppiVar1;
      ppppiStack_128 = (int ****)0x4d532f;
      __vbaHresultCheckObj();
    }
    ppppiStack_118 = (int ****)DAT_0050b348;
    ppppiStack_11c = local_1c;
    ppppiStack_120 = (int ****)&DAT_0040bf08;
    ppppiStack_124 = (int ****)0x4d5346;
    __vbaPrintObj();
    ppppiStack_118 = (int ****)0x4d5354;
    __vbaFreeObj();
    if (DAT_0050c53c == (int *****)0x0) {
      ppppiStack_118 = (int ****)&DAT_0050c53c;
      ppppiStack_11c = (int ****)&DAT_0040b420;
      ppppiStack_120 = (int ****)0x4d536d;
      __vbaNew2();
    }
    pppppiVar1 = DAT_0050c53c;
    ppppiStack_118 = (int ****)&local_1c;
    ppppiStack_11c = (int ****)DAT_0050c53c;
    ppppiStack_120 = (int ****)0x4d537d;
    iVar5 = (*(code *)(*DAT_0050c53c)[8])();
    if (iVar5 < 0) {
      ppppiStack_120 = (int ****)0x20;
      ppppiStack_124 = (int ****)&DAT_0040b410;
      ppppiStack_128 = (int ****)pppppiVar1;
      ppppiStack_130 = (int ****)0x4d5392;
      puStack_12c = (undefined *)iVar5;
      __vbaHresultCheckObj();
    }
    ppppiStack_120 = local_1c;
    ppppiStack_124 = (int ****)&DAT_0040f81c;
    ppppiStack_128 = (int ****)0x4d539d;
    __vbaPrintObj();
    ppppiStack_120 = (int ****)0x4d53a5;
    __vbaFreeObj();
    if (DAT_0050c53c == (int *****)0x0) {
      ppppiStack_120 = (int ****)&DAT_0050c53c;
      ppppiStack_124 = (int ****)&DAT_0040b420;
      ppppiStack_128 = (int ****)0x4d53c8;
      __vbaNew2();
    }
    pppppiVar1 = DAT_0050c53c;
    ppppiStack_120 = (int ****)&local_1c;
    ppppiStack_124 = (int ****)DAT_0050c53c;
    ppppiStack_128 = (int ****)0x4d53d8;
    iStack_134 = (*(code *)(*DAT_0050c53c)[8])();
    if (iStack_134 < 0) {
      ppppiStack_128 = (int ****)0x20;
      puStack_12c = &DAT_0040b410;
      ppppiStack_130 = (int ****)pppppiVar1;
      uStack_138 = 0x4d53ed;
      __vbaHresultCheckObj();
    }
    uStack_138 = 2;
    puStack_13c = &DAT_0040eb6c;
    iStack_134 = 2;
    uStack_140 = 0;
    uStack_144 = 0x10028;
    ppppiStack_130 = local_3c;
    pppiStack_14c = (int ***)local_30;
    puStack_12c = (undefined *)0x9;
    ppppiStack_128 = (int ****)local_34;
    ppppiStack_148 = local_1c;
    ppppiStack_150 = (int ****)0x4d5421;
    uStack_140 = __vbaLateIdCallLd();
    uStack_144 = 0x4d542b;
    uStack_144 = __vbaCastObjVar();
    ppppiStack_148 = (int ****)&local_20;
    pppiStack_14c = (int ***)0x4d5436;
    pppiStack_14c = (int ***)__vbaObjSet();
    ppppiStack_150 = (int ****)0x4d543d;
    __vbaLateIdSt();
    ppppiStack_150 = (int ****)&local_20;
    ppppiStack_154 = (int ****)&local_1c;
    pwStack_158 = (wchar_t *)0x2;
    puStack_15c = (undefined *)0x4d544d;
    __vbaFreeObjList();
    ppppiStack_150 = (int ****)0x4d5459;
    __vbaFreeVar();
    if (DAT_0050c53c == (int *****)0x0) {
      ppppiStack_150 = (int ****)&DAT_0050c53c;
      ppppiStack_154 = (int ****)&DAT_0040b420;
      pwStack_158 = (wchar_t *)0x4d5472;
      __vbaNew2();
    }
    pppppiVar1 = DAT_0050c53c;
    ppppiStack_150 = (int ****)&local_1c;
    ppppiStack_154 = (int ****)DAT_0050c53c;
    pwStack_158 = (wchar_t *)0x4d5482;
    pppiStack_164 = (int ***)(*(code *)(*DAT_0050c53c)[8])();
    uVar7 = 0;
    if ((int)pppiStack_164 < 0) {
      pwStack_158 = (wchar_t *)0x20;
      puStack_15c = &DAT_0040b410;
      ppppiStack_160 = (int ****)pppppiVar1;
      uStack_168 = 0x4d5497;
      __vbaHresultCheckObj();
    }
    pwStack_158 = (wchar_t *)0x0;
    puStack_15c = (undefined *)0x1000b;
    pppiStack_164 = (int ***)local_30;
    ppppiStack_160 = local_1c;
    uStack_168 = 0x4d54a8;
    __vbaLateIdCallLd();
    puStack_15c = *(undefined **)(DAT_0050b37c + 4);
    pwStack_158 = L"Title: ";
    ppppiStack_160 = (int ****)0x4d54c0;
    __vbaStrCat();
    ppppiStack_160 = (int ****)0x4d54cb;
    __vbaStrMove();
    ppppiStack_160 = local_30;
    pppiStack_164 = (int ***)0x4d54d5;
    __vbaR4Var();
    if ((uVar7 & 0xd) == 0) {
      ppppiStack_f0 = (int ****)0x4d54eb;
      local_6c = (int ***)__vbaFpI4();
      ppppiStack_f0 = &local_18;
      ppppiStack_f4 = &local_6c;
      ppiStack_f8 = &local_68;
      local_68 = (int *)0x4b0;
      ppppiStack_fc = (int ****)0x4d5506;
      FUN_004d5b40();
      ppppiStack_fc = (int ****)0x4d550f;
      __vbaFreeStr();
      ppppiStack_fc = (int ****)0x4d551a;
      __vbaFreeObj();
      ppppiStack_fc = (int ****)0x4d5523;
      __vbaFreeVar();
      if (DAT_0050c53c == (int *****)0x0) {
        ppppiStack_fc = (int ****)&DAT_0050c53c;
        ppppiStack_100 = (int ****)&DAT_0040b420;
        ppppiStack_104 = (int ****)0x4d553c;
        __vbaNew2();
      }
      pppppiVar1 = DAT_0050c53c;
      ppppiStack_fc = (int ****)&local_1c;
      ppppiStack_100 = (int ****)DAT_0050c53c;
      ppppiStack_104 = (int ****)0x4d554c;
      ppppiStack_110 = (int ****)(*(code *)(*DAT_0050c53c)[8])();
      if ((int)ppppiStack_110 < 0) {
        ppppiStack_104 = (int ****)0x20;
        pppiStack_108 = (int ***)&DAT_0040b410;
        ppppiStack_10c = (int ****)pppppiVar1;
        ppppiStack_114 = (int ****)0x4d5561;
        __vbaHresultCheckObj();
      }
      ppppiStack_104 = (int ****)0x0;
      pppiStack_108 = (int ***)0x1000b;
      ppppiStack_110 = local_30;
      ppppiStack_10c = local_1c;
      ppppiStack_114 = (int ****)0x4d5572;
      ppppiStack_104 = (int ****)__vbaLateIdCallLd();
      pppiStack_108 = (int ***)0x4d557c;
      __vbaR4Var();
      pppiStack_108 = (int ***)0x4d5582;
      local_64[0] = (int **)__vbaFpI2();
      pppiStack_108 = local_64;
      ppppiStack_10c = (int ****)0x4d558e;
      FUN_004d56e0();
      ppppiStack_10c = (int ****)0x4d5593;
      __vbaFreeObj();
      ppppiStack_10c = (int ****)0x4d559e;
      __vbaFreeVar();
      if (DAT_0050c53c == (int *****)0x0) {
        ppppiStack_10c = (int ****)&DAT_0050c53c;
        ppppiStack_110 = (int ****)&DAT_0040b420;
        ppppiStack_114 = (int ****)0x4d55b7;
        __vbaNew2();
      }
      pppppiVar1 = DAT_0050c53c;
      ppppiStack_10c = (int ****)&local_1c;
      ppppiStack_110 = (int ****)DAT_0050c53c;
      ppppiStack_114 = (int ****)0x4d55c7;
      ppppiStack_120 = (int ****)(*(code *)(*DAT_0050c53c)[8])();
      uVar7 = 0;
      if ((int)ppppiStack_120 < 0) {
        ppppiStack_114 = (int ****)0x20;
        ppppiStack_118 = (int ****)&DAT_0040b410;
        ppppiStack_11c = (int ****)pppppiVar1;
        ppppiStack_124 = (int ****)0x4d55dc;
        __vbaHresultCheckObj();
      }
      ppppiStack_114 = (int ****)0x0;
      ppppiStack_118 = (int ****)0x1000b;
      ppppiStack_120 = local_30;
      ppppiStack_11c = local_1c;
      ppppiStack_124 = (int ****)0x4d55ed;
      ppppiStack_114 = (int ****)__vbaLateIdCallLd();
      ppppiStack_118 = (int ****)0x4d55f7;
      fVar8 = (float10)__vbaR4Var();
      local_38 = (float)(fVar8 + (float10)_DAT_00401e54);
      if ((uVar7 & 0xd) == 0) {
        if (DAT_0050c53c == (int *****)0x0) {
          ppppiStack_f0 = (int ****)&DAT_0050c53c;
          ppppiStack_f4 = (int ****)&DAT_0040b420;
          ppiStack_f8 = (int **)0x4d5628;
          __vbaNew2();
        }
        pppppiVar1 = DAT_0050c53c;
        ppppiStack_f0 = (int ****)&local_20;
        ppppiStack_f4 = (int ****)DAT_0050c53c;
        ppiStack_f8 = (int **)0x4d5638;
        ppppiStack_104 = (int ****)(*(code *)(*DAT_0050c53c)[8])();
        if ((int)ppppiStack_104 < 0) {
          ppiStack_f8 = (int **)0x20;
          ppppiStack_fc = (int ****)&DAT_0040b410;
          ppppiStack_100 = (int ****)pppppiVar1;
          pppiStack_108 = (int ***)0x4d564d;
          __vbaHresultCheckObj();
        }
        pppiStack_108 = (int ***)0x1000b;
        ppppiStack_104 = (int ****)0x4;
        ppppiStack_100 = local_3c;
        ppppiStack_fc = (int ****)local_38;
        ppppiStack_10c = local_20;
        ppiStack_f8 = (int **)local_34;
        ppppiStack_110 = (int ****)0x4d5675;
        __vbaLateIdSt();
        ppppiStack_110 = (int ****)&local_20;
        ppppiStack_114 = (int ****)&local_1c;
        ppppiStack_118 = (int ****)0x2;
        ppppiStack_11c = (int ****)0x4d5685;
        __vbaFreeObjList();
        ppppiStack_110 = (int ****)0x4d568d;
        __vbaFreeVar();
        return;
      }
    }
  }
  __vbaFPException();
  return;
}


