/* entry 004f5480 name FUN_004f5480 size 3665 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004f5480(void)

{
  int **ppiVar1;
  int **ppiVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  code *pcVar6;
  short ****ppppsVar7;
  code **ppcVar8;
  undefined1 *puVar9;
  undefined4 uVar10;
  code *pcVar11;
  int ***pppiVar12;
  int ***pppiVar13;
  int ***pppiVar14;
  short ***pppsVar15;
  undefined2 extraout_var;
  code *pcVar16;
  int iVar17;
  int iVar18;
  code *pcVar19;
  short sVar20;
  uint uVar21;
  int iVar22;
  code *pcVar23;
  ushort in_FPUStatusWord;
  ushort uVar24;
  short ***pppsStack_1ec;
  short ***pppsStack_1e8;
  int **ppiStack_1e4;
  int **ppiStack_1e0;
  short ***pppsStack_1dc;
  short ***pppsStack_1d8;
  short ***pppsStack_1d4;
  short ***pppsStack_1d0;
  int **ppiStack_1cc;
  short ***pppsStack_1c8;
  short ***pppsStack_1c4;
  short ***pppsStack_1c0;
  int ***pppiStack_1bc;
  int **ppiStack_1b8;
  short ***pppsStack_1b4;
  short ***pppsStack_1b0;
  short ***pppsStack_1ac;
  short ***pppsStack_1a8;
  int **ppiStack_1a4;
  int ***pppiStack_1a0;
  int *piStack_19c;
  code *pcStack_198;
  code *pcStack_194;
  code *pcStack_190;
  float fStack_18c;
  undefined *puStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined *puStack_174;
  int **ppiStack_170;
  undefined4 uStack_16c;
  short ***pppsStack_168;
  undefined4 *puStack_164;
  short ***pppsStack_160;
  int **ppiStack_15c;
  int **ppiStack_158;
  int **ppiStack_154;
  int **ppiStack_150;
  short ***pppsStack_14c;
  short ***pppsStack_148;
  int **ppiStack_144;
  short **ppsStack_140;
  int **ppiStack_13c;
  undefined4 uStack_138;
  short ***pppsStack_134;
  short ***pppsStack_130;
  void *pvStack_12c;
  undefined *puStack_128;
  int **ppiStack_124;
  int ***pppiStack_120;
  short ***pppsStack_11c;
  int ***pppiStack_118;
  undefined *puStack_114;
  int *piStack_110;
  int local_100;
  int local_fc;
  int local_f8;
  int local_f4;
  int local_f0;
  short local_d0;
  short ***local_c8 [2];
  short *local_c0;
  int *local_b8;
  short *local_b4;
  undefined4 local_a0 [2];
  int local_98;
  short **local_90;
  int **local_8c;
  float *local_88;
  short ***local_84;
  undefined4 local_80;
  undefined4 local_7c;
  int **local_78;
  short ***local_74;
  short **local_70 [4];
  short **local_60;
  undefined4 local_5c;
  code *local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  short **local_34;
  short **local_30;
  float local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  float local_1c;
  code *local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffef4;
  local_8 = &DAT_004025f8;
  local_1c = 0.0;
  local_2c = 0.0;
  local_30 = (short **)0x0;
  local_34 = (short **)0x0;
  local_38 = 0;
  local_3c = 0;
  local_40 = 0;
  local_44 = 0;
  local_48 = 0;
  local_4c = 0;
  local_50 = 0;
  local_60 = (short **)0x0;
  local_70[0] = (short **)0x0;
  local_80 = 0;
  local_90 = (short **)0x0;
  local_a0[0] = 0;
  local_c8[0] = (short ***)0x0;
  ExceptionList = &pvStack_14;
  puVar9 = &stack0xfffffef4;
  if (DAT_0050b570 == (int *)0x0) {
    piStack_110 = (int *)&DAT_0050b570;
    puStack_114 = &DAT_004048dc;
    pppiStack_118 = (int ***)0x4f5503;
    ExceptionList = &pvStack_14;
    __vbaNew2();
    puVar9 = local_c;
  }
  local_c = puVar9;
  piStack_110 = DAT_0050b570;
  puStack_114 = (undefined *)0x4f5511;
  puStack_114 = (undefined *)(**(code **)(*DAT_0050b570 + 0x35c))();
  pppiStack_118 = (int ***)local_c8;
  pppsStack_11c = (short ***)0x4f551f;
  __vbaObjSet();
  pcVar6 = DAT_0050b3c4;
  pcVar19 = __vbaLateIdSt_exref;
  local_18 = (code *)&DAT_00000001;
  pcVar11 = DAT_0050b3c4;
  pcVar16 = local_18;
  do {
    local_18 = pcVar16;
    pcVar16 = __vbaGenerateBoundsError_exref;
    local_d0 = (short)pcVar6;
    sVar20 = (short)local_18;
    if (local_d0 < sVar20) {
      pppiStack_120 = (int ***)local_c8;
      pppsStack_11c = (short ***)0x0;
      ppiStack_124 = (int **)0x4f62a4;
      __vbaObjSetAddref();
      ppiStack_124 = (int **)&LAB_004f6307;
      puStack_128 = (undefined *)0x4f6306;
      __vbaFreeObj();
      return;
    }
    uVar10 = CONCAT22((short)((uint)pcVar11 >> 0x10),sVar20 + 1);
    pcVar23 = local_18;
    if (SCARRY2(sVar20,1)) break;
    local_28 = uVar10;
    if ((DAT_0050b19c == (int ***)0x0) || (*(short *)DAT_0050b19c != 2)) {
      pppsStack_11c = (short ***)0x4f55c0;
      __vbaGenerateBoundsError();
    }
    else {
      local_b8 = (int *)((int)sVar20 - (int)DAT_0050b19c[7]);
      if (DAT_0050b19c[6] <= local_b8) {
        pppsStack_11c = (short ***)0x4f5582;
        __vbaGenerateBoundsError();
      }
      pcVar16 = __vbaGenerateBoundsError_exref;
      if (DAT_0050b19c[4] <= (int **)(1U - (int)DAT_0050b19c[5])) {
        pppsStack_11c = (short ***)0x4f559f;
        __vbaGenerateBoundsError();
        pcVar16 = __vbaGenerateBoundsError_exref;
      }
    }
    pppsStack_11c = (short ***)0x4f55d2;
    local_20 = __vbaFpI2();
    if ((DAT_0050b19c == (int ***)0x0) || (*(short *)DAT_0050b19c != 2)) {
      pppsStack_11c = (short ***)0x4f5632;
      (*pcVar16)();
    }
    else {
      if (DAT_0050b19c[6] <= (int **)((int)sVar20 - (int)DAT_0050b19c[7])) {
        pppsStack_11c = (short ***)0x4f55fa;
        __vbaGenerateBoundsError();
      }
      pcVar16 = __vbaGenerateBoundsError_exref;
      if (DAT_0050b19c[4] <= (int **)(2 - (int)DAT_0050b19c[5])) {
        pppsStack_11c = (short ***)0x4f5617;
        __vbaGenerateBoundsError();
        pcVar16 = __vbaGenerateBoundsError_exref;
      }
    }
    pppsStack_11c = (short ***)0x4f5644;
    local_24 = __vbaFpI2();
    if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
      pppsStack_11c = (short ***)0x4f5673;
      iVar18 = (*pcVar16)();
    }
    else {
      uVar21 = (int)(short)local_24 - *(int *)(DAT_0050b3d8 + 10);
      if (*(uint *)(DAT_0050b3d8 + 8) <= uVar21) {
        pppsStack_11c = (short ***)0x4f5668;
        (*pcVar16)();
      }
      iVar18 = uVar21 * 4;
    }
    if ((DAT_0050b3d4 == (short *)0x0) || (*DAT_0050b3d4 != 1)) {
      pppsStack_11c = (short ***)0x4f56b2;
      local_f0 = (*pcVar16)();
    }
    else {
      iVar22 = (int)(short)local_20;
      iVar17 = *(int *)(DAT_0050b3d4 + 10);
      if (*(uint *)(DAT_0050b3d4 + 8) <= (uint)(iVar22 - iVar17)) {
        pppsStack_11c = (short ***)0x4f569b;
        (*pcVar16)();
      }
      local_f0 = (iVar22 - iVar17) * 4;
    }
    if ((DAT_0050b3cc == (int ***)0x0) || (*(short *)DAT_0050b3cc != 2)) {
      pppsStack_11c = (short ***)0x4f5727;
      local_f4 = (*pcVar16)();
    }
    else {
      iVar17 = (int)(short)local_20;
      ppiVar1 = DAT_0050b3cc[7];
      if (DAT_0050b3cc[6] <= (int **)(iVar17 - (int)ppiVar1)) {
        pppsStack_11c = (short ***)0x4f56e4;
        __vbaGenerateBoundsError();
      }
      iVar22 = (int)(short)local_24;
      ppiVar2 = DAT_0050b3cc[5];
      if (DAT_0050b3cc[4] <= (int **)(iVar22 - (int)ppiVar2)) {
        pppsStack_11c = (short ***)0x4f5706;
        __vbaGenerateBoundsError();
      }
      local_f4 = (int)((int)DAT_0050b3cc[6] * (iVar22 - (int)ppiVar2) + (iVar17 - (int)ppiVar1)) * 4
      ;
    }
    pcVar11 = __vbaGenerateBoundsError_exref;
    local_1c = (*(float *)(*(int *)(DAT_0050b3d8 + 6) + iVar18) -
               *(float *)(*(int *)(DAT_0050b3d4 + 6) + local_f0)) -
               *(float *)((int)DAT_0050b3cc[3] + local_f4);
    if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004f6318:
      __vbaFPException();
      return;
    }
    if ((DAT_0050b3d4 == (short *)0x0) || (*DAT_0050b3d4 != 1)) {
      pppsStack_11c = (short ***)0x4f57b2;
      local_f8 = __vbaGenerateBoundsError();
      pcVar11 = __vbaGenerateBoundsError_exref;
    }
    else {
      iVar17 = (int)(short)local_24;
      iVar18 = *(int *)(DAT_0050b3d4 + 10);
      if (*(uint *)(DAT_0050b3d4 + 8) <= (uint)(iVar17 - iVar18)) {
        pppsStack_11c = (short ***)0x4f5791;
        __vbaGenerateBoundsError();
      }
      local_f8 = (iVar17 - iVar18) * 4;
    }
    if ((DAT_0050b3d4 == (short *)0x0) || (*DAT_0050b3d4 != 1)) {
      pppsStack_11c = (short ***)0x4f5803;
      local_fc = (*pcVar11)();
    }
    else {
      iVar17 = (int)(short)local_20;
      iVar18 = *(int *)(DAT_0050b3d4 + 10);
      if (*(uint *)(DAT_0050b3d4 + 8) <= (uint)(iVar17 - iVar18)) {
        pppsStack_11c = (short ***)0x4f57e6;
        (*pcVar11)();
      }
      local_fc = (iVar17 - iVar18) * 4;
    }
    if ((DAT_0050b3cc == (int ***)0x0) || (*(short *)DAT_0050b3cc != 2)) {
      pppsStack_11c = (short ***)0x4f5878;
      iVar18 = (*pcVar11)();
    }
    else {
      iVar18 = (int)(short)local_20;
      ppiVar1 = DAT_0050b3cc[7];
      if (DAT_0050b3cc[6] <= (int **)(iVar18 - (int)ppiVar1)) {
        pppsStack_11c = (short ***)0x4f5835;
        __vbaGenerateBoundsError();
      }
      iVar17 = (int)(short)local_24;
      ppiVar2 = DAT_0050b3cc[5];
      if (DAT_0050b3cc[4] <= (int **)(iVar17 - (int)ppiVar2)) {
        pppsStack_11c = (short ***)0x4f5857;
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)((int)DAT_0050b3cc[6] * (iVar17 - (int)ppiVar2) + (iVar18 - (int)ppiVar1)) * 4;
      pcVar11 = __vbaGenerateBoundsError_exref;
    }
    local_2c = (*(float *)(*(int *)(DAT_0050b3d4 + 6) + local_f8) -
               *(float *)(*(int *)(DAT_0050b3d4 + 6) + local_fc)) -
               *(float *)((int)DAT_0050b3cc[3] + iVar18);
    local_90 = (short **)0x3;
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004f6318;
    pppiStack_120 = (int ***)(int)(short)local_28;
    pvStack_12c = (void *)0xa;
    puStack_128 = (undefined *)0x3;
    ppiStack_124 = local_8c;
    pppsStack_130 = local_c8[0];
    pppsStack_11c = local_84;
    pppsStack_134 = (short ***)0x4f58e5;
    local_88 = (float *)pppiStack_120;
    __vbaLateIdSt();
    local_90 = (short **)0x3;
    ppiStack_144 = (int **)0xb;
    ppsStack_140 = (short **)0x3;
    local_88 = (float *)0x0;
    ppiStack_13c = local_8c;
    pppsStack_148 = local_c8[0];
    uStack_138 = 0;
    pppsStack_134 = local_84;
    pppsStack_14c = (short ***)0x4f591c;
    __vbaLateIdSt();
    if (local_1c == _DAT_00401bc0) {
      local_90 = (short **)0x3;
      ppiStack_15c = (int **)0x27;
      ppiStack_158 = (int **)0x3;
      local_88 = (float *)0xff;
      ppiStack_154 = local_8c;
      pppsStack_160 = local_c8[0];
      ppiStack_150 = (int **)0xff;
      pppsStack_14c = local_84;
      puStack_164 = (undefined4 *)0x4f5966;
      __vbaLateIdSt();
    }
    ppiStack_150 = (int **)&local_30;
    pppsStack_14c = (short ***)DAT_0050b19c;
    ppiStack_154 = (int **)0x4f5977;
    __vbaAryLock();
    if (((int **)local_30 == (int **)0x0) || (*(short *)local_30 != 2)) {
      ppiStack_154 = (int **)0x4f59cc;
      iVar18 = (*pcVar11)();
    }
    else {
      iVar18 = (int)(short)local_18;
      piVar3 = (int *)local_30[7];
      if (local_30[6] <= (int *)(iVar18 - (int)piVar3)) {
        ppiStack_154 = (int **)0x4f599a;
        __vbaGenerateBoundsError();
      }
      piVar4 = (int *)local_30[5];
      if (local_30[4] <= (int *)(1U - (int)piVar4)) {
        ppiStack_154 = (int **)0x4f59b4;
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)((int)local_30[6] * (int)(1U - (int)piVar4) + (iVar18 - (int)piVar3)) * 4;
      pcVar11 = __vbaGenerateBoundsError_exref;
    }
    ppiStack_154 = (int **)&local_90;
    local_88 = (float *)((int)local_30[3] + iVar18);
    local_90 = (short **)0x4004;
    ppiStack_158 = (int **)0x4f59f1;
    Ordinal_536();
    pcVar23 = __vbaStrMove_exref;
    ppiStack_158 = (int **)0x4f59fe;
    __vbaStrMove();
    ppiStack_158 = (int **)&local_30;
    ppiStack_15c = (int **)0x4f5a08;
    __vbaAryUnlock();
    pppsStack_160 = &local_34;
    ppiStack_15c = (int **)DAT_0050b19c;
    puStack_164 = (undefined4 *)0x4f5a19;
    __vbaAryLock();
    if (((int **)local_34 == (int **)0x0) || (*(short *)local_34 != 2)) {
      puStack_164 = (undefined4 *)0x4f5a76;
      local_98 = (*pcVar11)();
    }
    else {
      local_c0 = (short *)((int)(short)local_18 - (int)local_34[7]);
      if (local_34[6] <= local_c0) {
        puStack_164 = (undefined4 *)0x4f5a3e;
        (*pcVar11)();
      }
      piVar3 = (int *)local_34[5];
      if (local_34[4] <= (int *)(2U - (int)piVar3)) {
        puStack_164 = (undefined4 *)0x4f5a58;
        __vbaGenerateBoundsError();
      }
      local_98 = (int)((int)local_34[6] * (int)(2U - (int)piVar3) + (int)local_c0) * 4;
      pcVar11 = __vbaGenerateBoundsError_exref;
    }
    puStack_164 = local_a0;
    local_98 = (int)local_34[3] + local_98;
    local_a0[0] = 0x4004;
    pppsStack_168 = (short ***)0x4f5a9b;
    Ordinal_536();
    pppsStack_168 = (short ***)0x4f5aa2;
    __vbaStrMove();
    pppsStack_168 = &local_34;
    uStack_16c = 0x4f5aac;
    __vbaAryUnlock();
    if ((DAT_0050b3d0 == (short *)0x0) || (*DAT_0050b3d0 != 1)) {
      uStack_16c = 0x4f5ae2;
      local_100 = (*pcVar11)();
    }
    else {
      iVar17 = (int)(short)local_18;
      iVar18 = *(int *)(DAT_0050b3d0 + 10);
      if (*(uint *)(DAT_0050b3d0 + 8) <= (uint)(iVar17 - iVar18)) {
        uStack_16c = 0x4f5ad1;
        __vbaGenerateBoundsError();
      }
      local_100 = (iVar17 - iVar18) * 4;
    }
    uStack_16c = local_38;
    ppiStack_170 = (int **)0x4f5af2;
    Ordinal_519();
    ppiStack_170 = (int **)0x4f5af9;
    ppiStack_170 = (int **)__vbaStrMove();
    puStack_174 = &DAT_0040cc9c;
    uStack_178 = 0x4f5b07;
    __vbaStrCat();
    uStack_178 = 0x4f5b0e;
    uStack_178 = __vbaStrMove();
    uStack_17c = local_40;
    uStack_180 = 0x4f5b19;
    Ordinal_519();
    uStack_180 = 0x4f5b20;
    uStack_180 = __vbaStrMove();
    uStack_184 = 0x4f5b23;
    __vbaStrCat();
    uStack_184 = 0x4f5b2a;
    uStack_184 = __vbaStrMove();
    puStack_188 = &DAT_0040fb00;
    fStack_18c = 7.287719e-39;
    __vbaStrCat();
    fStack_18c = 7.287729e-39;
    fStack_18c = (float)__vbaStrMove();
    pcStack_190 = *(code **)(*(int *)(DAT_0050b3d0 + 6) + local_100);
    pcStack_194 = (code *)0x4f5b4f;
    pcStack_198 = (code *)__vbaStrCat();
    local_60 = (short **)0x8;
    ppiStack_1a4 = (int **)0x0;
    pppiStack_1a0 = (int ***)0x8;
    piStack_19c = (int *)local_5c;
    pppsStack_1a8 = local_c8[0];
    pcStack_194 = (code *)local_54;
    pppsStack_1ac = (short ***)0x4f5b7b;
    local_58 = pcStack_198;
    __vbaLateIdSt();
    pppsStack_1ac = (short ***)&local_50;
    pppsStack_1b0 = (short ***)&local_4c;
    pppsStack_1b4 = (short ***)&local_48;
    ppiStack_1b8 = (int **)&local_44;
    pppiStack_1bc = (int ***)&local_40;
    pppsStack_1c0 = (short ***)&local_3c;
    pppsStack_1c4 = (short ***)&local_38;
    pppsStack_1c8 = (short ***)0x7;
    ppiStack_1cc = (int **)0x4f5b9f;
    __vbaFreeStrList();
    pppsStack_1ac = (short ***)0x4f5bab;
    __vbaFreeVar();
    local_90 = (short **)0x3;
    ppiStack_1b8 = (int **)0x3;
    local_88 = (float *)0x1;
    pppsStack_1b4 = (short ***)local_8c;
    pppsStack_1b0 = (short ***)0x1;
    pppiStack_1bc = (int ***)0xb;
    pppsStack_1c0 = local_c8[0];
    pppsStack_1ac = local_84;
    pppsStack_1c4 = (short ***)0x4f5be5;
    __vbaLateIdSt();
    if (local_1c == _DAT_00401bc0) {
      local_90 = (short **)0x3;
      pppsStack_1d4 = (short ***)0x27;
      pppsStack_1d0 = (short ***)0x3;
      local_88 = (float *)0xff;
      ppiStack_1cc = local_8c;
      pppsStack_1d8 = local_c8[0];
      pppsStack_1c8 = (short ***)0xff;
      pppsStack_1c4 = local_84;
      pppsStack_1dc = (short ***)0x4f5c2f;
      __vbaLateIdSt();
    }
    pppsStack_1c4 = (short ***)0x4f5c34;
    FUN_0044fdc0();
    pppsStack_1c4 = (short ***)0x4f5c3b;
    __vbaStrMove();
    local_58 = (code *)local_38;
    pppsStack_1c8 = &local_30;
    pppsStack_1c4 = (short ***)DAT_0050b3cc;
    local_38 = 0;
    local_60 = (short **)0x8;
    ppiStack_1cc = (int **)0x4f5c60;
    __vbaAryLock();
    if (((int **)local_30 == (int **)0x0) || (*(short *)local_30 != 2)) {
      ppiStack_1cc = (int **)0x4f5cbc;
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      local_b8 = (int *)((int)(short)local_20 - (int)local_30[7]);
      if (local_30[6] <= local_b8) {
        ppiStack_1cc = (int **)0x4f5c89;
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)(short)local_24;
      piVar3 = (int *)local_30[5];
      if (local_30[4] <= (int *)(iVar18 - (int)piVar3)) {
        ppiStack_1cc = (int **)0x4f5ca2;
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)((int)local_30[6] * (iVar18 - (int)piVar3) + (int)local_b8) * 4;
    }
    ppiStack_1cc = (int **)&DAT_00000001;
    local_88 = (float *)((int)local_30[3] + iVar18);
    pppsStack_1d4 = &local_60;
    pppsStack_1d0 = (short ***)&DAT_00000001;
    pppsStack_1d8 = &local_90;
    pppsStack_1dc = local_70;
    local_90 = (short **)0x4004;
    ppiStack_1e0 = (int **)0x4f5ced;
    Ordinal_660();
    ppiStack_1e0 = (int **)&local_30;
    ppiStack_1e4 = (int **)0x4f5cf7;
    __vbaAryUnlock();
    ppiStack_1e4 = (int **)local_70;
    pppsStack_1e8 = (short ***)0x4f5d03;
    pppsStack_1ec = (short ***)__vbaStrVarMove();
    local_80 = 8;
    pppsStack_1e8 = local_74;
    local_78 = (int **)pppsStack_1ec;
    __vbaLateIdSt(local_c8[0],0,8,local_7c);
    __vbaFreeStr();
    __vbaFreeVarList(3,&local_60,local_70,&local_80);
    local_90 = (short **)0x3;
    local_88 = (float *)0x2;
    __vbaLateIdSt(local_c8[0],0xb,3,local_8c,2,local_84);
    if (local_1c == _DAT_00401bc0) {
      local_90 = (short **)0x3;
      local_88 = (float *)0xff;
      __vbaLateIdSt(local_c8[0],0x27,3,local_8c,0xff,local_84);
    }
    FUN_0044fdc0();
    __vbaStrMove();
    local_58 = (code *)local_38;
    local_38 = 0;
    local_60 = (short **)0x8;
    __vbaAryLock(&local_30,DAT_0050b3d4);
    if (((int **)local_30 == (int **)0x0) || (*(short *)local_30 != 1)) {
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      local_b4 = (short *)((int)(short)local_20 - (int)local_30[5]);
      if (local_30[4] <= local_b4) {
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)local_b4 << 2;
    }
    local_88 = (float *)((int)local_30[3] + iVar18);
    local_90 = (short **)0x4004;
    Ordinal_660(local_70,&local_90,&local_60,1,1);
    __vbaAryUnlock(&local_30);
    local_78 = (int **)__vbaStrVarMove(local_70);
    local_80 = 8;
    __vbaLateIdSt(local_c8[0],0,8,local_7c,local_78,local_74);
    __vbaFreeStr();
    __vbaFreeVarList(3,&local_60,local_70,&local_80);
    local_88 = (float *)0x3;
    local_90 = (short **)0x3;
    __vbaLateIdSt(local_c8[0],0xb,3,local_8c,3,local_84);
    if (local_1c == _DAT_00401bc0) {
      local_90 = (short **)0x3;
      local_88 = (float *)0xff;
      __vbaLateIdSt(local_c8[0],0x27,3,local_8c,0xff,local_84);
    }
    FUN_0044fdc0();
    __vbaStrMove();
    local_58 = (code *)local_38;
    local_38 = 0;
    local_60 = (short **)0x8;
    __vbaAryLock(&local_30,DAT_0050b3d8);
    if (((int **)local_30 == (int **)0x0) || (*(short *)local_30 != 1)) {
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      local_b4 = (short *)((int)(short)local_24 - (int)local_30[5]);
      if (local_30[4] <= local_b4) {
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)local_b4 << 2;
    }
    local_88 = (float *)((int)local_30[3] + iVar18);
    local_90 = (short **)0x4004;
    Ordinal_660(local_70,&local_90,&local_60,1,1);
    __vbaAryUnlock(&local_30);
    local_78 = (int **)__vbaStrVarMove(local_70);
    local_80 = 8;
    __vbaLateIdSt(local_c8[0],0,8,local_7c,local_78,local_74);
    __vbaFreeStr();
    __vbaFreeVarList(3,&local_60,local_70,&local_80);
    local_90 = (short **)0x3;
    local_88 = (float *)0x4;
    __vbaLateIdSt(local_c8[0],0xb,3,local_8c,4,local_84);
    if (local_1c == _DAT_00401bc0) {
      local_90 = (short **)0x3;
      local_88 = (float *)0xff;
      __vbaLateIdSt(local_c8[0],0x27,3,local_8c,0xff,local_84);
    }
    FUN_0044fdc0();
    __vbaStrMove();
    local_88 = &local_1c;
    local_58 = (code *)local_38;
    local_38 = 0;
    local_60 = (short **)0x8;
    local_90 = (short **)0x4004;
    Ordinal_660(local_70,&local_90,&local_60,1,1);
    local_78 = (int **)__vbaStrVarMove(local_70);
    local_80 = 8;
    __vbaLateIdSt(local_c8[0],0,8,local_7c,local_78,local_74);
    __vbaFreeStr();
    __vbaFreeVarList(3,&local_60,local_70,&local_80);
    local_90 = (short **)0x3;
    local_88 = (float *)0x5;
    __vbaLateIdSt(local_c8[0],0xb,3,local_8c,5,local_84);
    in_FPUStatusWord = 0;
    if (local_1c == _DAT_00401bc0) {
      local_90 = (short **)0x3;
      local_88 = (float *)0xff;
      __vbaLateIdSt(local_c8[0],0x27,3,local_8c,0xff,local_84);
    }
    FUN_0044fdc0();
    __vbaStrMove();
    local_88 = &local_2c;
    local_58 = (code *)local_38;
    local_38 = 0;
    local_60 = (short **)0x8;
    local_90 = (short **)0x4004;
    Ordinal_660(local_70,&local_90,&local_60,1,1);
    local_78 = (int **)__vbaStrVarMove(local_70);
    local_80 = 8;
    __vbaLateIdSt(local_c8[0],0,8,local_7c,local_78,local_74);
    __vbaFreeStr();
    __vbaFreeVarList(3,&local_60,local_70,&local_80);
    pcVar11 = (code *)(uint)(ushort)((short)local_18 + 1);
    pcVar16 = pcVar11;
  } while (!SCARRY2((short)local_18,1));
  pcVar6 = __vbaGenerateBoundsError_exref;
  pppsStack_11c = (short ***)0x4f6323;
  __vbaErrorOverflow();
  puStack_128 = &DAT_00402706;
  pvStack_12c = ExceptionList;
  pcStack_194 = pcVar19;
  ppiStack_124 = (int **)&pcStack_198;
  pppiStack_120 = (int ***)&DAT_00402608;
  uStack_138 = 0;
  ppiStack_13c = (int **)0x0;
  ppsStack_140 = (short **)0x0;
  ppiStack_150 = (int **)0x0;
  ppiStack_154 = (int **)0x0;
  ppiStack_170 = (int **)0x0;
  ExceptionList = &pvStack_12c;
  pcStack_198 = pcVar23;
  pcStack_190 = pcVar6;
  ppcVar8 = &pcStack_198;
  pppsStack_11c = (short ***)&stack0xfffffffc;
  if (DAT_0050b570 == (int *)0x0) {
    piStack_19c = (int *)&DAT_0050b570;
    pppiStack_1a0 = (int ***)&DAT_004048dc;
    ppiStack_1a4 = (int **)0x4f6386;
    ExceptionList = &pvStack_12c;
    pppsStack_11c = (short ***)&stack0xfffffffc;
    __vbaNew2();
    ppcVar8 = (code **)ppiStack_124;
  }
  ppiStack_124 = (int **)ppcVar8;
  pppiStack_1a0 = &ppiStack_170;
  piStack_19c = DAT_0050b570;
  ppiStack_1a4 = (int **)0x4f6396;
  __vbaObjSetAddref();
  ppiStack_1a4 = ppiStack_170;
  pppsStack_1a8 = (short ***)0x4f63a2;
  pppsStack_1a8 = (short ***)(*(code *)(*ppiStack_170)[199])();
  pcVar19 = __vbaObjSet_exref;
  pppsStack_1ac = (short ***)&ppiStack_13c;
  pppsStack_1b0 = (short ***)0x4f63af;
  pppiVar12 = (int ***)__vbaObjSet();
  pppsStack_1b0 = (short ***)&ppiStack_154;
  ppiStack_1b8 = (int **)0x4f63be;
  pppsStack_1b4 = (short ***)pppiVar12;
  pppiVar13 = (int ***)(*(code *)(*pppiVar12)[0x3c])();
  if ((int)pppiVar13 < 0) {
    ppiStack_1b8 = (int **)0xf0;
    pppiStack_1bc = (int ***)&DAT_0040dc58;
    pppsStack_1c8 = (short ***)0x4f63d6;
    pppsStack_1c4 = (short ***)pppiVar13;
    pppsStack_1c0 = (short ***)pppiVar12;
    __vbaHresultCheckObj();
  }
  pppiVar13 = (int ***)__vbaFreeObj_exref;
  if (!SCARRY2((short)ppiStack_154,1)) {
    ppiStack_1b8 = (int **)0x4f63f5;
    DAT_0050b3e0 = (short)ppiStack_154 + 1;
    __vbaFreeObj();
    if (DAT_0050b3e0 == 0) {
      ppiStack_1b8 = (int **)0x4f6405;
      Ordinal_534();
LAB_004f68aa:
      ppiStack_1b8 = (int **)&LAB_004f68b4;
      pppiStack_1bc = (int ***)0x4f68b3;
      __vbaFreeObj();
      return;
    }
    ppiStack_1b8 = ppiStack_170;
    pppiStack_1bc = (int ***)0x4f641c;
    pppiStack_1bc = (int ***)(*(code *)(*ppiStack_170)[0xc6])();
    pppsStack_1c0 = (short ***)&ppiStack_13c;
    pppsStack_1c4 = (short ***)0x4f6423;
    pppiVar12 = (int ***)__vbaObjSet();
    pppsStack_1c4 = (short ***)0xffffffff;
    ppiStack_1cc = (int **)0x4f6430;
    pppsStack_1c8 = (short ***)pppiVar12;
    pppiVar14 = (int ***)(*(code *)(*pppiVar12)[0x25])();
    if ((int)pppiVar14 < 0) {
      ppiStack_1cc = (int **)0x94;
      pppsStack_1d0 = (short ***)&DAT_0040dc58;
      pppsStack_1dc = (short ***)0x4f6448;
      pppsStack_1d8 = (short ***)pppiVar14;
      pppsStack_1d4 = (short ***)pppiVar12;
      __vbaHresultCheckObj();
    }
    ppiStack_1cc = (int **)0x4f644d;
    __vbaFreeObj();
    ppiStack_1cc = ppiStack_170;
    pppsStack_1d0 = (short ***)0x4f6459;
    pppsStack_1d0 = (short ***)(*(code *)(*ppiStack_170)[0xc6])();
    pppsStack_1d4 = (short ***)&ppiStack_13c;
    pppsStack_1d8 = (short ***)0x4f6460;
    pppiVar12 = (int ***)__vbaObjSet();
    pppsStack_1d8 = (short ***)&ppiStack_154;
    ppiStack_1e0 = (int **)0x4f646f;
    pppsStack_1dc = (short ***)pppiVar12;
    pppiVar14 = (int ***)(*(code *)(*pppiVar12)[0x3a])();
    if ((int)pppiVar14 < 0) {
      ppiStack_1b8 = (int **)0xe8;
      pppiStack_1bc = (int ***)&DAT_0040dc58;
      pppsStack_1c8 = (short ***)0x4f6487;
      pppsStack_1c4 = (short ***)pppiVar14;
      pppsStack_1c0 = (short ***)pppiVar12;
      __vbaHresultCheckObj();
    }
    sVar20 = (short)ppiStack_154 + -1;
    pppiVar12 = (int ***)CONCAT22((short)((uint)pppiVar12 >> 0x10),sVar20);
    if (!SBORROW2((short)ppiStack_154,1)) {
      ppiStack_1b8 = (int **)0x4f649d;
      pppsStack_134 = (short ***)pppiVar12;
      __vbaFreeObj();
      if (sVar20 < 1) {
LAB_004f6569:
        if ((DAT_0050b3e4 == (short *)0x0) || (*DAT_0050b3e4 != 2)) {
          ppiStack_1b8 = (int **)0x4f65ce;
          iVar18 = __vbaGenerateBoundsError();
        }
        else {
          iVar17 = (int)DAT_0050b3e0;
          iVar18 = *(int *)(DAT_0050b3e4 + 0xe);
          if (*(uint *)(DAT_0050b3e4 + 0xc) <= (uint)(iVar17 - iVar18)) {
            ppiStack_1b8 = (int **)0x4f6592;
            __vbaGenerateBoundsError();
          }
          iVar22 = *(int *)(DAT_0050b3e4 + 10);
          if (*(uint *)(DAT_0050b3e4 + 8) <= 1U - iVar22) {
            ppiStack_1b8 = (int **)0x4f65af;
            __vbaGenerateBoundsError();
          }
          iVar18 = (*(int *)(DAT_0050b3e4 + 0xc) * (1U - iVar22) + (iVar17 - iVar18)) * 4;
          pppiVar13 = (int ***)__vbaFreeObj_exref;
        }
        uVar24 = 0;
        if (*(float *)(*(int *)(DAT_0050b3e4 + 6) + iVar18) == _DAT_00401bc0) {
          ppiStack_1b8 = ppiStack_170;
          pppiStack_1bc = (int ***)0x4f65f7;
          pppiStack_1bc = (int ***)(*(code *)(*ppiStack_170)[0xc6])();
          pppsStack_1c0 = (short ***)&ppiStack_13c;
          pppsStack_1c4 = (short ***)0x4f65fe;
          pppiVar12 = (int ***)__vbaObjSet();
          pppsStack_1c4 = (short ***)0x0;
          ppiStack_1cc = (int **)0x4f660b;
          pppsStack_1c8 = (short ***)pppiVar12;
          pppiVar14 = (int ***)(*(code *)(*pppiVar12)[0x25])();
          if ((int)pppiVar14 < 0) {
            ppiStack_1cc = (int **)0x94;
            pppsStack_1d0 = (short ***)&DAT_0040dc58;
            pppsStack_1dc = (short ***)0x4f6623;
            pppsStack_1d8 = (short ***)pppiVar14;
            pppsStack_1d4 = (short ***)pppiVar12;
            __vbaHresultCheckObj();
          }
          ppiStack_1cc = (int **)0x4f6628;
          (*(code *)pppiVar13)();
          ppiStack_1cc = ppiStack_170;
          pppsStack_1d0 = (short ***)0x4f6634;
          pppsStack_1d0 = (short ***)(*(code *)(*ppiStack_170)[0xc5])();
          pppsStack_1d4 = (short ***)&ppiStack_13c;
          pppsStack_1d8 = (short ***)0x4f663b;
          pppiVar12 = (int ***)__vbaObjSet();
          pppsStack_1d8 = (short ***)0x414cbc;
          ppiStack_1e0 = (int **)0x4f664b;
          pppsStack_1dc = (short ***)pppiVar12;
          pppsVar15 = (short ***)(*(code *)(*pppiVar12)[0x29])();
          if ((int)pppsVar15 < 0) {
            ppiStack_1e0 = (int **)0xa4;
            ppiStack_1e4 = (int **)&DAT_0040c3cc;
            pppsStack_1ec = pppsVar15;
            pppsStack_1e8 = (short ***)pppiVar12;
            __vbaHresultCheckObj();
          }
          ppiStack_1e0 = (int **)0x4f6668;
          (*(code *)pppiVar13)();
          goto LAB_004f68aa;
        }
        if ((DAT_0050b3e4 == (short *)0x0) || (*DAT_0050b3e4 != 2)) {
          ppiStack_1b8 = (int **)0x4f66cc;
          __vbaGenerateBoundsError();
        }
        else {
          if (*(uint *)(DAT_0050b3e4 + 0xc) <=
              (uint)((int)DAT_0050b3e0 - *(int *)(DAT_0050b3e4 + 0xe))) {
            ppiStack_1b8 = (int **)0x4f6696;
            __vbaGenerateBoundsError();
          }
          if (*(uint *)(DAT_0050b3e4 + 8) <= 1U - *(int *)(DAT_0050b3e4 + 10)) {
            ppiStack_1b8 = (int **)0x4f66b3;
            __vbaGenerateBoundsError();
          }
        }
        ppiStack_1b8 = (int **)0x4f66de;
        uStack_180 = __vbaFpI2();
        uStack_17c = 1;
        pppsStack_130 = (short ***)0x0;
        pppiVar14 = (int ***)pppsStack_130;
        do {
          pppsStack_130 = (short ***)pppiVar14;
          if ((short)uStack_180 < (short)pppsStack_130) {
            pppiStack_1bc = &ppiStack_170;
            ppiStack_1b8 = (int **)0x0;
            pppsStack_1c0 = (short ***)0x4f6885;
            __vbaObjSetAddref();
            goto LAB_004f68aa;
          }
          ppiStack_1b8 = ppiStack_170;
          pppiStack_1bc = (int ***)0x4f6703;
          pppiStack_1bc = (int ***)(*(code *)(*ppiStack_170)[0xc6])();
          pppsStack_1c0 = (short ***)&ppiStack_13c;
          pppsStack_1c4 = (short ***)0x4f670a;
          pppsStack_168 = (short ***)(*pcVar19)();
          if ((DAT_0050b3e4 == (short *)0x0) || (*DAT_0050b3e4 != 2)) {
            pppsStack_1c4 = (short ***)0x4f676c;
            iVar18 = __vbaGenerateBoundsError();
          }
          else {
            iVar17 = (int)DAT_0050b3e0;
            iVar18 = *(int *)(DAT_0050b3e4 + 0xe);
            if (*(uint *)(DAT_0050b3e4 + 0xc) <= (uint)(iVar17 - iVar18)) {
              pppsStack_1c4 = (short ***)0x4f6736;
              __vbaGenerateBoundsError();
            }
            iVar22 = *(int *)(DAT_0050b3e4 + 10);
            if (*(uint *)(DAT_0050b3e4 + 8) <= 3U - iVar22) {
              pppsStack_1c4 = (short ***)0x4f6753;
              __vbaGenerateBoundsError();
            }
            iVar18 = (*(int *)(DAT_0050b3e4 + 0xc) * (3U - iVar22) + (iVar17 - iVar18)) * 4;
          }
          if ((DAT_0050b3e4 == (short *)0x0) || (*DAT_0050b3e4 != 2)) {
            pppsStack_1c4 = (short ***)0x4f67c8;
            iVar17 = __vbaGenerateBoundsError();
          }
          else {
            iVar22 = (int)DAT_0050b3e0;
            iVar17 = *(int *)(DAT_0050b3e4 + 0xe);
            if (*(uint *)(DAT_0050b3e4 + 0xc) <= (uint)(iVar22 - iVar17)) {
              pppsStack_1c4 = (short ***)0x4f6797;
              __vbaGenerateBoundsError();
            }
            iVar5 = *(int *)(DAT_0050b3e4 + 10);
            if (*(uint *)(DAT_0050b3e4 + 8) <= (uint)-iVar5) {
              pppsStack_1c4 = (short ***)0x4f67af;
              __vbaGenerateBoundsError();
            }
            iVar17 = (*(int *)(DAT_0050b3e4 + 0xc) * -iVar5 + (iVar22 - iVar17)) * 4;
          }
          pppiVar12 = (int ***)pppsStack_130;
          pppsStack_1d4 = *(short ****)(DAT_0050b3e4 + 6);
          ppiVar1 = (int **)*pppsStack_168;
          sVar20 = (short)pppsStack_130;
          puStack_188 = (undefined *)(int)sVar20;
          fStack_18c = (float)(int)puStack_188;
          pppsStack_1d0 = (short ***)0xa;
          ppiStack_1cc = (int **)pppsStack_14c;
          pppsStack_1c8 = (short ***)0x80020004;
          if ((uVar24 & 0xd) != 0) {
            __vbaFPException();
            return;
          }
          pppsStack_1c4 = (short ***)ppiStack_144;
          pppsStack_1d8 = (short ***)0x4f6822;
          pppsStack_1d4 =
               (short ***)
               ((*(float *)((int)pppsStack_1d4 + iVar18) - *(float *)((int)pppsStack_1d4 + iVar17))
               + fStack_18c);
          __vbaStrR4();
          pppsStack_1d8 = (short ***)0x4f682d;
          pppsStack_1d8 = (short ***)__vbaStrMove();
          pppiVar13 = (int ***)pppsStack_168;
          pppsStack_1dc = pppsStack_168;
          ppiStack_1e0 = (int **)0x4f6838;
          pppsVar15 = (short ***)(*(code *)ppiVar1[0x7b])();
          uVar24 = 0;
          if ((int)pppsVar15 < 0) {
            ppiStack_1e0 = (int **)0x1ec;
            ppiStack_1e4 = (int **)&DAT_0040dc58;
            pppsStack_1e8 = (short ***)pppiVar13;
            pppsStack_1ec = pppsVar15;
            __vbaHresultCheckObj();
          }
          ppiStack_1e0 = (int **)0x4f6859;
          __vbaFreeStr();
          ppiStack_1e0 = (int **)0x4f6862;
          __vbaFreeObj();
          pcVar19 = __vbaObjSet_exref;
          pppiVar14 = (int ***)CONCAT22(extraout_var,(short)uStack_17c + sVar20);
        } while (!SCARRY2((short)uStack_17c,sVar20));
      }
      else {
        pppsStack_130 = (short ***)0x0;
        pppiVar14 = (int ***)pppsStack_130;
        do {
          pppsStack_130 = (short ***)pppiVar14;
          if ((short)pppiVar12 < (short)pppsStack_130) goto LAB_004f6569;
          ppiStack_1b8 = ppiStack_170;
          pppiStack_1bc = (int ***)0x4f64c3;
          pppiStack_1bc = (int ***)(*(code *)(*ppiStack_170)[0xc6])();
          pppsStack_1c0 = &ppsStack_140;
          pppsStack_1c4 = (short ***)0x4f64ca;
          pppiVar13 = (int ***)__vbaObjSet();
          pppsStack_1c4 = (short ***)ppiStack_170;
          pppsStack_1c8 = (short ***)0x4f64d8;
          pppsStack_1c8 = (short ***)(*(code *)(*ppiStack_170)[0xc6])();
          ppiStack_1cc = (int **)&ppiStack_13c;
          pppsStack_1d0 = (short ***)0x4f64df;
          pppiVar12 = (int ***)__vbaObjSet();
          pppsStack_1d0 = (short ***)&ppiStack_154;
          pppsStack_1d8 = (short ***)0x4f64ee;
          pppsStack_1d4 = (short ***)pppiVar12;
          pppiVar14 = (int ***)(*(code *)(*pppiVar12)[0x3a])();
          if ((int)pppiVar14 < 0) {
            ppiStack_1b8 = (int **)0xe8;
            pppiStack_1bc = (int ***)&DAT_0040dc58;
            pppsStack_1c8 = (short ***)0x4f6506;
            pppsStack_1c4 = (short ***)pppiVar14;
            pppsStack_1c0 = (short ***)pppiVar12;
            pppiVar14 = (int ***)__vbaHresultCheckObj();
          }
          ppiStack_1b8 = (int **)CONCAT22((short)((uint)pppiVar14 >> 0x10),(short)ppiStack_154 + -1)
          ;
          if (SBORROW2((short)ppiStack_154,1)) break;
          pppsStack_1c0 = (short ***)0x4f651e;
          pppiStack_1bc = pppiVar13;
          ppiStack_1cc = (int **)(*(code *)(*pppiVar13)[0x7c])();
          if ((int)ppiStack_1cc < 0) {
            pppsStack_1c0 = (short ***)0x1f0;
            pppsStack_1c4 = (short ***)&DAT_0040dc58;
            pppsStack_1d0 = (short ***)0x4f6536;
            pppsStack_1c8 = (short ***)pppiVar13;
            __vbaHresultCheckObj();
          }
          pppsStack_1c0 = &ppsStack_140;
          pppsStack_1c4 = (short ***)&ppiStack_13c;
          pppsStack_1c8 = (short ***)0x2;
          ppiStack_1cc = (int **)0x4f6546;
          __vbaFreeObjList();
          pppiVar12 = (int ***)pppsStack_134;
          pppiVar13 = (int ***)__vbaFreeObj_exref;
          pppiVar14 = (int ***)(uint)(ushort)((short)pppsStack_130 + 1);
        } while (!SCARRY2((short)pppsStack_130,1));
      }
    }
  }
  ppiStack_1b8 = (int **)FUN_004f68d0;
  __vbaErrorOverflow();
  pppsStack_1c4 = (short ***)&DAT_00402706;
  pppsStack_1c8 = ExceptionList;
  pppsStack_1c0 = (short ***)&pppsStack_1ec;
  pppiStack_1bc = (int ***)&DAT_00402618;
  ppiStack_1cc = (int **)0x0;
  pppsStack_1d0 = (short ***)0x0;
  ExceptionList = &pppsStack_1c8;
  pppsStack_1ec = (short ***)pppiVar13;
  pppsStack_1e8 = (short ***)pppiVar12;
  ppiStack_1e4 = (int **)pcVar19;
  ppppsVar7 = &pppsStack_1ec;
  ppiStack_1b8 = (int **)&pppsStack_11c;
  if (DAT_0050c53c == (int *)0x0) {
    ExceptionList = &pppsStack_1c8;
    ppiStack_1b8 = (int **)&pppsStack_11c;
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    ppppsVar7 = (short ****)pppsStack_1c0;
  }
  pppsStack_1c0 = (short ***)ppppsVar7;
  piVar3 = DAT_0050c53c;
  iVar18 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&ppiStack_1cc);
  if (iVar18 < 0) {
    __vbaHresultCheckObj(iVar18,piVar3,&DAT_0040b410,0x20);
  }
  ppiVar1 = ppiStack_1cc;
  ppiStack_1cc = (int **)0x0;
  __vbaObjSet(&pppsStack_1d0,ppiVar1);
  FUN_0048c990(&pppsStack_1d0);
  __vbaFreeObj();
  FUN_004f6a10();
  if ((DAT_0050b3c0 != 2) || (DAT_0050b338 != 1)) {
    if (DAT_0050b3c0 == 1) {
      if (DAT_0050c53c == (int *)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      piVar3 = DAT_0050c53c;
      iVar18 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&ppiStack_1cc);
      if (iVar18 < 0) {
        __vbaHresultCheckObj(iVar18,piVar3,&DAT_0040b410,0x20);
      }
      __vbaLateIdCall(ppiStack_1cc,0x20001,0);
      __vbaFreeObj();
    }
    FUN_004f89f0();
  }
  return;
}


