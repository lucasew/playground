/* entry 004cf810 name FUN_004cf810 size 2667 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf810(void)

{
  code *****pppppcVar1;
  code ****ppppcVar2;
  float fVar3;
  code ******ppppppcVar4;
  code *pcVar5;
  code *pcVar6;
  code ******ppppppcVar7;
  code ******ppppppcVar8;
  undefined4 uVar9;
  uint uVar10;
  int iVar11;
  undefined2 extraout_var;
  int *piVar12;
  undefined4 uVar13;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  short **ppsVar14;
  undefined2 extraout_var_02;
  undefined4 *puVar15;
  short sVar16;
  short sVar17;
  undefined2 extraout_var_03;
  int iVar18;
  code *pcVar19;
  code ******ppppppcVar20;
  code *****pppppcVar21;
  code ******ppppppcVar22;
  code *****pppppcVar23;
  bool bVar24;
  ushort in_FPUStatusWord;
  ushort uVar25;
  float10 fVar26;
  undefined *puVar27;
  code *pcStack_358;
  code *pcStack_354;
  code *****pppppcStack_350;
  undefined4 *puStack_34c;
  code *****pppppcStack_348;
  code *****pppppcStack_344;
  undefined *puStack_340;
  code *****pppppcStack_33c;
  code *****pppppcStack_338;
  code *****pppppcStack_334;
  code *****pppppcStack_330;
  code *****pppppcStack_32c;
  code *****pppppcStack_328;
  code *****pppppcStack_324;
  code *****pppppcStack_320;
  code *****pppppcStack_31c;
  code *****pppppcStack_318;
  code *****pppppcStack_314;
  code *****pppppcStack_310;
  code *****pppppcStack_30c;
  code *****pppppcStack_308;
  code *****pppppcStack_304;
  code *****pppppcStack_300;
  code *****pppppcStack_2fc;
  code *****pppppcStack_2f8;
  code *****pppppcStack_2f4;
  code *****pppppcStack_2f0;
  code *****pppppcStack_2ec;
  code *****pppppcStack_2e8;
  code *****pppppcStack_2e4;
  code *****pppppcStack_2e0;
  code *****pppppcStack_2dc;
  code *****pppppcStack_2d8;
  code *****pppppcStack_2d4;
  code *****pppppcStack_2d0;
  code *****pppppcStack_2cc;
  code *****pppppcStack_2c8;
  code ****ppppcStack_2c4;
  code *****pppppcStack_2c0;
  code *****pppppcStack_2bc;
  code *****pppppcStack_2b8;
  code *****pppppcStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  code *****pppppcStack_2a8;
  undefined4 uStack_2a4;
  code *****pppppcStack_2a0;
  code *****pppppcStack_29c;
  undefined *puStack_298;
  int *piStack_294;
  int *piStack_290;
  undefined4 uStack_28c;
  undefined4 *puStack_288;
  undefined *puStack_284;
  int *piStack_280;
  code ****ppppcStack_27c;
  code ****ppppcStack_278;
  code *pcStack_274;
  code *****pppppcStack_270;
  int iStack_26c;
  short sStack_24c;
  short sStack_244;
  undefined4 uStack_234;
  undefined4 uStack_224;
  uint uStack_214;
  undefined4 uStack_208;
  undefined4 uStack_204;
  code *****pppppcStack_1f8;
  code ***pppcStack_1f4;
  code ***pppcStack_1f0;
  code ***pppcStack_1ec;
  code ***pppcStack_1e8;
  code ****ppppcStack_1e4;
  code ****ppppcStack_1e0;
  code ****ppppcStack_1cc;
  code *****pppppcStack_1c8;
  wchar_t *pwStack_1c4;
  code *****pppppcStack_1c0;
  code *****pppppcStack_1bc;
  code *****pppppcStack_1b8;
  code *****pppppcStack_1b4;
  code *****pppppcStack_1b0;
  code *****pppppcStack_1ac;
  code *****pppppcStack_1a8;
  code *****pppppcStack_1a4;
  code *****pppppcStack_1a0;
  code ****ppppcStack_19c;
  undefined4 uStack_198;
  code *****pppppcStack_194;
  code ****ppppcStack_190;
  code *****pppppcStack_18c;
  code *****pppppcStack_188;
  code *****pppppcStack_184;
  code *****pppppcStack_180;
  code ****appppcStack_17c [4];
  code ****appppcStack_16c [4];
  code ****appppcStack_15c [2];
  undefined4 uStack_154;
  code ****appppcStack_14c [4];
  code ****ppppcStack_13c;
  code *****pppppcStack_138;
  code *****pppppcStack_134;
  code *****pppppcStack_130;
  code ****ppppcStack_12c;
  code *****pppppcStack_128;
  code *****pppppcStack_124;
  code *****pppppcStack_120;
  code ****ppppcStack_11c;
  code *****pppppcStack_118;
  code *****pppppcStack_114;
  code *****pppppcStack_110;
  undefined4 uStack_10c;
  code *****pppppcStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  code *****pppppcStack_dc;
  code *****pppppcStack_d8;
  code ****ppppcStack_d4;
  code ****ppppcStack_d0;
  code ****ppppcStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  code *****pppppcStack_c0;
  short **ppsStack_bc;
  short **ppsStack_b8;
  short **ppsStack_b4;
  undefined4 *puStack_b0;
  undefined4 *puStack_ac;
  short **ppsStack_a8;
  code *****pppppcStack_a4;
  undefined4 local_64 [2];
  int local_5c;
  undefined4 local_54 [2];
  float *local_4c;
  short *local_44 [4];
  short *local_34;
  uint local_30;
  float local_2c;
  short *local_28;
  undefined4 local_24;
  uint local_1c;
  uint local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff60;
  local_8 = &DAT_004023c8;
  ppsStack_a8 = (short **)(int)DAT_0050b332;
  pppppcVar23 = (code *****)0x0;
  pppppcVar21 = (code *****)0x1;
  pppppcStack_a4 = (code *****)0x0;
  puStack_ac = (undefined4 *)&DAT_00000001;
  ppsStack_b4 = &local_28;
  puStack_b0 = (undefined4 *)0x2;
  ppsStack_b8 = (short **)0x2;
  ppsStack_bc = (short **)0x80;
  local_28 = (short *)0x0;
  local_2c = 0.0;
  local_30 = 0;
  local_34 = (short *)0x0;
  local_44[0] = (short *)0x0;
  local_54[0] = 0;
  local_64[0] = 0;
  pppppcStack_c0 = (code *****)0x4cf875;
  ExceptionList = &pvStack_14;
  __vbaRedim();
  pcVar19 = __vbaGenerateBoundsError_exref;
  local_18 = 1;
  if ((local_28 == (short *)0x0) || (*local_28 != 1)) {
    pppppcStack_a4 = (code *****)0x4cf8ab;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    pppppcVar21 = (code *****)(1 - *(int *)(local_28 + 10));
    if (*(code ******)(local_28 + 8) <= pppppcVar21) {
      pppppcStack_a4 = (code *****)0x4cf89b;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)pppppcVar21 * 2;
  }
  local_24 = 0;
  *(undefined2 *)(*(int *)(local_28 + 6) + iVar11) = 1;
  if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
    pppppcStack_a4 = (code *****)0x4cf901;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    pppppcVar23 = (code *****)-(int)DAT_0050b19c[7];
    if (DAT_0050b19c[6] <= pppppcVar23) {
      pppppcStack_a4 = (code *****)0x4cf8d8;
      __vbaGenerateBoundsError();
    }
    pppppcVar21 = (code *****)-(int)DAT_0050b19c[5];
    if (DAT_0050b19c[4] <= pppppcVar21) {
      pppppcStack_a4 = (code *****)0x4cf8ec;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b19c[6] * (int)pppppcVar21) * 4;
  }
  *(undefined4 *)((int)DAT_0050b19c[3] + iVar11) = 0;
  if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
    pppppcStack_a4 = (code *****)0x4cf95c;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    pppppcVar21 = (code *****)(1 - (int)DAT_0050b1a0[7]);
    if (DAT_0050b1a0[6] <= pppppcVar21) {
      pppppcStack_a4 = (code *****)0x4cf934;
      __vbaGenerateBoundsError();
    }
    pppppcVar23 = (code *****)-(int)DAT_0050b1a0[5];
    if (DAT_0050b1a0[4] <= pppppcVar23) {
      pppppcStack_a4 = (code *****)0x4cf948;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((int)pppppcVar21 + (int)DAT_0050b1a0[6] * (int)pppppcVar23) * 2;
  }
  *(undefined2 *)((int)DAT_0050b1a0[3] + iVar11) = 0;
  do {
    sVar17 = DAT_0050b332;
    local_2c = -(float)_DAT_0050b134;
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004d0287;
    local_1c = 1;
    ppppppcVar20 = DAT_0050b19c;
    uVar10 = local_1c;
    while (local_1c = uVar10, (short)local_1c <= sVar17) {
      if ((local_28 == (short *)0x0) || (*local_28 != 1)) {
        pppppcStack_a4 = (code *****)0x4cf9ce;
        iVar11 = __vbaGenerateBoundsError();
        ppppppcVar20 = DAT_0050b19c;
      }
      else {
        pppppcVar23 = *(code ******)(local_28 + 10);
        pppppcVar21 = (code *****)((int)(short)local_1c - (int)pppppcVar23);
        if (*(code ******)(local_28 + 8) <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cf9c1;
          __vbaGenerateBoundsError();
          ppppppcVar20 = DAT_0050b19c;
        }
        iVar11 = (int)pppppcVar21 * 2;
      }
      if (*(short *)(*(int *)(local_28 + 6) + iVar11) == 0) {
        if ((ppppppcVar20 == (code ******)0x0) || (*(short *)ppppppcVar20 != 2)) {
          pppppcStack_a4 = (code *****)0x4cfa2e;
          iVar11 = __vbaGenerateBoundsError();
          ppppppcVar20 = DAT_0050b19c;
        }
        else {
          pppppcVar23 = (code *****)((int)(short)local_18 - (int)ppppppcVar20[7]);
          if (ppppppcVar20[6] <= pppppcVar23) {
            pppppcStack_a4 = (code *****)0x4cfa01;
            __vbaGenerateBoundsError();
            ppppppcVar20 = DAT_0050b19c;
          }
          pppppcVar21 = (code *****)((int)(short)local_1c - (int)ppppppcVar20[5]);
          if (ppppppcVar20[4] <= pppppcVar21) {
            pppppcStack_a4 = (code *****)0x4cfa19;
            __vbaGenerateBoundsError();
            ppppppcVar20 = DAT_0050b19c;
          }
          iVar11 = (int)((int)pppppcVar23 + (int)ppppppcVar20[6] * (int)pppppcVar21) * 4;
        }
        in_FPUStatusWord = 0;
        if (_DAT_00401bc0 < *(float *)((int)ppppppcVar20[3] + iVar11)) {
          if ((ppppppcVar20 == (code ******)0x0) || (*(short *)ppppppcVar20 != 2)) {
            pppppcStack_a4 = (code *****)0x4cfa94;
            iVar11 = __vbaGenerateBoundsError();
            ppppppcVar20 = DAT_0050b19c;
          }
          else {
            pppppcVar23 = (code *****)((int)(short)local_18 - (int)ppppppcVar20[7]);
            if (ppppppcVar20[6] <= pppppcVar23) {
              pppppcStack_a4 = (code *****)0x4cfa67;
              __vbaGenerateBoundsError();
              ppppppcVar20 = DAT_0050b19c;
            }
            pppppcVar21 = (code *****)((int)(short)local_1c - (int)ppppppcVar20[5]);
            if (ppppppcVar20[4] <= pppppcVar21) {
              pppppcStack_a4 = (code *****)0x4cfa7f;
              __vbaGenerateBoundsError();
              ppppppcVar20 = DAT_0050b19c;
            }
            iVar11 = (int)((int)pppppcVar23 + (int)ppppppcVar20[6] * (int)pppppcVar21) * 4;
          }
          in_FPUStatusWord = 0;
          if (local_2c < *(float *)((int)ppppppcVar20[3] + iVar11)) {
            if ((ppppppcVar20 == (code ******)0x0) || (*(short *)ppppppcVar20 != 2)) {
              pppppcStack_a4 = (code *****)0x4cfaf3;
              iVar11 = __vbaGenerateBoundsError();
              ppppppcVar20 = DAT_0050b19c;
            }
            else {
              pppppcVar23 = (code *****)((int)(short)local_18 - (int)ppppppcVar20[7]);
              if (ppppppcVar20[6] <= pppppcVar23) {
                pppppcStack_a4 = (code *****)0x4cfac6;
                __vbaGenerateBoundsError();
                ppppppcVar20 = DAT_0050b19c;
              }
              pppppcVar21 = (code *****)((int)(short)local_1c - (int)ppppppcVar20[5]);
              if (ppppppcVar20[4] <= pppppcVar21) {
                pppppcStack_a4 = (code *****)0x4cfade;
                __vbaGenerateBoundsError();
                ppppppcVar20 = DAT_0050b19c;
              }
              iVar11 = (int)((int)pppppcVar23 + (int)ppppppcVar20[6] * (int)pppppcVar21) * 4;
            }
            local_2c = *(float *)((int)ppppppcVar20[3] + iVar11);
            local_30 = local_1c;
          }
        }
      }
      uVar10 = (uint)(ushort)((short)local_1c + 1);
      if (SCARRY2((short)local_1c,1)) goto LAB_004d028c;
    }
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004d0287;
    pppppcStack_a4 = (code *****)0x4cfb43;
    fVar26 = (float10)__vbaFpR4();
    in_FPUStatusWord = 0;
    if (fVar26 == (float10)local_2c) {
      if ((short)local_18 == 1) goto code_r0x004d024e;
      if ((local_28 == (short *)0x0) || (*local_28 != 1)) {
        pppppcStack_a4 = (code *****)0x4cfb86;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar21 = (code *****)((int)(short)local_18 - *(int *)(local_28 + 10));
        if (*(code ******)(local_28 + 8) <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfb7c;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)pppppcVar21 * 2;
      }
      *(undefined2 *)(*(int *)(local_28 + 6) + iVar11) = 1;
      if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
        pppppcStack_a4 = (code *****)0x4cfbe1;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar23 = (code *****)(1 - (int)DAT_0050b1a0[7]);
        if (DAT_0050b1a0[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cfbb5;
          __vbaGenerateBoundsError();
        }
        pppppcVar21 = (code *****)((int)(short)local_24 - (int)DAT_0050b1a0[5]);
        if (DAT_0050b1a0[4] <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfbcd;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b1a0[6] * (int)pppppcVar21) * 2;
      }
      local_18 = CONCAT22(local_18._2_2_,*(undefined2 *)((int)DAT_0050b1a0[3] + iVar11));
      uVar13 = CONCAT22((short)((uint)DAT_0050b1a0[3] >> 0x10),(short)local_24 + -1);
      if (SBORROW2((short)local_24,1)) goto LAB_004d028c;
    }
    else {
      uVar13 = CONCAT22(extraout_var,(short)local_24 + 1);
      if (SCARRY2((short)local_24,1)) goto LAB_004d028c;
      local_24 = uVar13;
      if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
        pppppcStack_a4 = (code *****)0x4cfc64;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar23 = (code *****)-(int)DAT_0050b19c[7];
        if (DAT_0050b19c[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cfc37;
          __vbaGenerateBoundsError();
        }
        pppppcVar21 = (code *****)((int)(short)local_24 - (int)DAT_0050b19c[5]);
        if (DAT_0050b19c[4] <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfc4f;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b19c[6] * (int)pppppcVar21) * 4;
      }
      *(float *)((int)DAT_0050b19c[3] + iVar11) = local_2c;
      if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
        pppppcStack_a4 = (code *****)0x4cfcc2;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar23 = (code *****)(1 - (int)DAT_0050b1a0[7]);
        if (DAT_0050b1a0[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cfc96;
          __vbaGenerateBoundsError();
        }
        pppppcVar21 = (code *****)((int)(short)local_24 - (int)DAT_0050b1a0[5]);
        if (DAT_0050b1a0[4] <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfcae;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b1a0[6] * (int)pppppcVar21) * 2;
      }
      *(short *)((int)DAT_0050b1a0[3] + iVar11) = (short)local_18;
      if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
        pppppcStack_a4 = (code *****)0x4cfd22;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar23 = (code *****)(2 - (int)DAT_0050b1a0[7]);
        if (DAT_0050b1a0[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cfcf6;
          __vbaGenerateBoundsError();
        }
        pppppcVar21 = (code *****)((int)(short)local_24 - (int)DAT_0050b1a0[5]);
        if (DAT_0050b1a0[4] <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfd0e;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b1a0[6] * (int)pppppcVar21) * 2;
      }
      local_18 = local_30;
      *(short *)((int)DAT_0050b1a0[3] + iVar11) = (short)local_30;
      if ((local_28 == (short *)0x0) || (*local_28 != 1)) {
        pppppcStack_a4 = (code *****)0x4cfd5b;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar21 = (code *****)((int)(short)local_30 - *(int *)(local_28 + 10));
        if (*(code ******)(local_28 + 8) <= pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfd51;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)pppppcVar21 * 2;
      }
      *(undefined2 *)(*(int *)(local_28 + 6) + iVar11) = 1;
      uVar13 = local_24;
    }
    local_24 = uVar13;
  } while ((short)local_18 != DAT_0050b332);
  if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
    pppppcStack_a4 = (code *****)0x4cfdc3;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    pppppcVar23 = DAT_0050b1a0[7];
    if (DAT_0050b1a0[6] <= (code *****)(1 - (int)pppppcVar23)) {
      pppppcStack_a4 = (code *****)0x4cfd9b;
      __vbaGenerateBoundsError();
    }
    pppppcVar21 = DAT_0050b1a0[5];
    if (DAT_0050b1a0[4] <= (code *****)-(int)pppppcVar21) {
      pppppcStack_a4 = (code *****)0x4cfdaf;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((1 - (int)pppppcVar23) + (int)DAT_0050b1a0[6] * -(int)pppppcVar21) * 2;
  }
  *(short *)((int)DAT_0050b1a0[3] + iVar11) = (short)local_24;
  local_2c = (float)_DAT_0050b134;
  pppppcVar1 = (code *****)0x1;
  do {
    pppppcVar23 = pppppcVar1;
    sVar17 = (short)pppppcVar23;
    if ((short)local_24 < sVar17) {
      if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
        pppppcStack_a4 = (code *****)0x4cfef9;
        iVar11 = (*pcVar19)();
      }
      else {
        pppppcVar23 = (code *****)-(int)DAT_0050b19c[7];
        if (DAT_0050b19c[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cfed0;
          (*pcVar19)();
        }
        pppppcVar21 = DAT_0050b19c[5];
        if (DAT_0050b19c[4] <= (code *****)-(int)pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cfee4;
          (*pcVar19)();
        }
        iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b19c[6] * -(int)pppppcVar21) * 4;
      }
      *(float *)((int)DAT_0050b19c[3] + iVar11) = local_2c;
      if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
        pppppcStack_a4 = (code *****)0x4cff55;
        pppppcVar21 = (code *****)(*pcVar19)();
      }
      else {
        pppppcVar23 = (code *****)(1 - (int)DAT_0050b19c[7]);
        if (DAT_0050b19c[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cff2a;
          (*pcVar19)();
        }
        pppppcVar21 = DAT_0050b19c[5];
        if (DAT_0050b19c[4] <= (code *****)-(int)pppppcVar21) {
          pppppcStack_a4 = (code *****)0x4cff41;
          __vbaGenerateBoundsError();
        }
        pppppcVar21 = (code *****)
                      ((int)((int)pppppcVar23 + (int)DAT_0050b19c[6] * -(int)pppppcVar21) * 4);
      }
      pcVar19 = __vbaGenerateBoundsError_exref;
      if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
        pppppcStack_a4 = (code *****)0x4cffb4;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar23 = (code *****)(1 - (int)DAT_0050b19c[7]);
        if (DAT_0050b19c[6] <= pppppcVar23) {
          pppppcStack_a4 = (code *****)0x4cff7d;
          __vbaGenerateBoundsError();
        }
        pppppcVar1 = DAT_0050b19c[5];
        if (DAT_0050b19c[4] <= (code *****)-(int)pppppcVar1) {
          pppppcStack_a4 = (code *****)0x4cff94;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b19c[6] * -(int)pppppcVar1) * 4;
        pcVar19 = __vbaGenerateBoundsError_exref;
      }
      local_1c = 1;
      *(float *)((int)DAT_0050b19c[3] + iVar11) =
           local_2c + *(float *)((int)DAT_0050b19c[3] + (int)pppppcVar21);
      uVar10 = local_1c;
      if ((in_FPUStatusWord & 0xd) == 0) goto LAB_004cffd8;
      goto LAB_004d0287;
    }
    ppsStack_a8 = &local_34;
    pppppcStack_a4 = (code *****)DAT_0050b19c;
    puStack_ac = (undefined4 *)0x4cfe01;
    __vbaAryLock();
    if ((local_34 == (short *)0x0) || (*local_34 != 2)) {
      puStack_ac = (undefined4 *)0x4cfe55;
      local_5c = (*pcVar19)();
    }
    else {
      iVar11 = *(int *)(local_34 + 0xe);
      if (*(uint *)(local_34 + 0xc) <= (uint)-iVar11) {
        puStack_ac = (undefined4 *)0x4cfe20;
        __vbaGenerateBoundsError();
      }
      iVar18 = *(int *)(local_34 + 10);
      if (*(uint *)(local_34 + 8) <= (uint)(sVar17 - iVar18)) {
        puStack_ac = (undefined4 *)0x4cfe38;
        __vbaGenerateBoundsError();
      }
      local_5c = (*(int *)(local_34 + 0xc) * (sVar17 - iVar18) + -iVar11) * 4;
      pcVar19 = __vbaGenerateBoundsError_exref;
    }
    pppppcVar21 = (code *****)0x4004;
    puStack_ac = local_64;
    local_5c = *(int *)(local_34 + 6) + local_5c;
    local_4c = &local_2c;
    puStack_b0 = local_54;
    ppsStack_b4 = local_44;
    local_64[0] = 0x4004;
    local_54[0] = 0x4004;
    ppsStack_b8 = (short **)0x4cfe7d;
    FUN_0042b040();
    ppsStack_b8 = &local_34;
    ppsStack_bc = (short **)0x4cfe87;
    __vbaAryUnlock();
    ppsStack_bc = local_44;
    pppppcStack_c0 = (code *****)0x4cfe91;
    fVar26 = (float10)__vbaR4Var();
    local_2c = (float)fVar26;
    pppppcStack_c0 = (code *****)0x4cfe9d;
    __vbaFreeVar();
    pppppcVar1 = (code *****)(uint)(ushort)(sVar17 + 1);
  } while (!SCARRY2(sVar17,1));
  goto LAB_004d028c;
  while( true ) {
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2bc = (code *****)(int)sVar17;
    ppppcStack_2c4 = (code ****)0x3;
    pppppcStack_2c8 = (code *****)0xb;
    pppppcStack_2c0 = pppppcStack_188;
    pppppcStack_2cc = pppppcStack_1f8;
    pppppcStack_2b8 = pppppcStack_180;
    pppppcStack_2d0 = (code *****)0x4d07e8;
    pppppcStack_184 = pppppcStack_2bc;
    __vbaLateIdSt();
    pppppcStack_18c = (code *****)0x2;
    pppppcStack_2e0 = (code *****)0x28;
    pppppcStack_2dc = (code *****)0x2;
    pppppcStack_184 = (code *****)0x1;
    pppppcStack_2d8 = pppppcStack_188;
    pppppcStack_2e4 = pppppcStack_1f8;
    pppppcStack_2d4 = (code *****)&DAT_00000001;
    pppppcStack_2d0 = pppppcStack_180;
    pppppcStack_2e8 = (code *****)0x4d0825;
    __vbaLateIdSt();
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2f8 = (code *****)0x27;
    pppppcStack_2f4 = (code *****)0x3;
    pppppcStack_184 = (code *****)0xff0000;
    pppppcStack_2f0 = pppppcStack_188;
    pppppcStack_2fc = pppppcStack_1f8;
    pppppcStack_2ec = (code *****)0xff0000;
    pppppcStack_2e8 = pppppcStack_180;
    pppppcStack_300 = (code *****)0x4d0862;
    __vbaLateIdSt();
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_310 = (code *****)0x26;
    pppppcStack_30c = (code *****)0x3;
    pppppcStack_184 = (code *****)0xffff;
    pppppcStack_308 = pppppcStack_188;
    pppppcStack_314 = pppppcStack_1f8;
    pppppcStack_304 = (code *****)0xffff;
    pppppcStack_300 = pppppcStack_180;
    pppppcStack_318 = (code *****)0x4d089f;
    __vbaLateIdSt();
    pppppcStack_1b4 = (code *****)(int)sVar17;
    ppppcStack_19c = (code ****)0x3;
    pppppcStack_1bc = (code *****)0x3;
    pppppcStack_2b8 = &ppppcStack_11c;
    pppppcStack_2b4 = (code *****)0x410eb0;
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar9 = uStack_224;
    uVar13 = uStack_204;
    if (SCARRY2(DAT_0050b244,1)) break;
    pppppcStack_114 = (code *****)CONCAT22(pppppcStack_114._2_2_,DAT_0050b244 + 1);
    ppppcStack_11c = (code ****)0x2;
    pppppcStack_2bc = (code *****)0x4d08ed;
    pppppcStack_194 = (code *****)(int)(short)uStack_c4;
    Ordinal_536();
    pppppcStack_2bc = (code *****)0x4d08f4;
    pppppcStack_2bc = (code *****)(*pcVar19)();
    pppppcStack_2c0 = (code *****)0x4d08fb;
    __vbaStrCat();
    pppppcStack_2c0 = (code *****)0x4d0902;
    pppppcStack_2c0 = (code *****)(*pcVar19)();
    ppppcStack_2c4 = (code ****)DAT_0050b348;
    pppppcStack_2c8 = (code *****)0x4d0910;
    pppppcStack_2ec = (code *****)__vbaStrCat();
    ppppcStack_12c = (code ****)0x8;
    pppppcStack_2d4 = (code *****)ppppcStack_19c;
    pppppcStack_2d0 = (code *****)uStack_198;
    pppppcStack_2cc = pppppcStack_194;
    pppppcStack_2c8 = (code *****)ppppcStack_190;
    pppppcStack_2e4 = pppppcStack_1bc;
    pppppcStack_2e0 = pppppcStack_1b8;
    pppppcStack_2dc = pppppcStack_1b4;
    pppppcStack_2d8 = pppppcStack_1b0;
    pppppcStack_2f8 = (code *****)0x2;
    pppppcStack_2fc = (code *****)0x41;
    pppppcStack_2f4 = (code *****)0x8;
    pppppcStack_2f0 = pppppcStack_128;
    pppppcStack_2e8 = pppppcStack_120;
    pppppcStack_300 = pppppcStack_1f8;
    pppppcStack_304 = (code *****)0x4d099d;
    pppppcStack_124 = pppppcStack_2ec;
    __vbaLateIdCallSt();
    pppppcStack_304 = (code *****)&pppppcStack_dc;
    pppppcStack_308 = (code *****)&pppppcStack_d8;
    pppppcStack_30c = (code *****)0x2;
    pppppcStack_310 = (code *****)0x4d09ad;
    __vbaFreeStrList();
    pppppcStack_2c8 = &ppppcStack_12c;
    pppppcStack_2cc = &ppppcStack_11c;
    pppppcStack_2d0 = (code *****)0x2;
    pppppcStack_2d4 = (code *****)0x4d09c3;
    __vbaFreeVarList();
    ppppppcVar22 = (code ******)(uint)(ushort)(sVar17 + 1);
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar9 = uStack_224;
    uVar10 = uStack_214;
    uVar13 = uStack_204;
    if (SCARRY2(sVar17,1)) break;
LAB_004d07a4:
    uStack_214 = uVar10;
    ppppppcVar20 = ppppppcVar22;
    sVar17 = (short)ppppppcVar20;
    if ((short)uStack_214 < sVar17) {
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_2c8 = (code *****)0x30;
      ppppcStack_2c4 = (code ****)0x3;
      pppppcStack_184 = (code *****)0x2;
      pppppcStack_2c0 = pppppcStack_188;
      pppppcStack_2cc = pppppcStack_1f8;
      pppppcStack_2bc = (code *****)0x2;
      pppppcStack_2b8 = pppppcStack_180;
      pppppcStack_2d0 = (code *****)0x4d0a1e;
      __vbaLateIdSt();
      pppppcStack_2d4 = (code *****)(int)(short)uStack_c4;
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_2dc = (code *****)0x3;
      pppppcStack_1ac = (code *****)0xb;
      pppppcStack_2d8 = pppppcStack_188;
      pppppcStack_1a4 = (code *****)0xffffffff;
      pppppcStack_2f0 = (code *****)&DAT_00000001;
      pppppcStack_2f4 = (code *****)0x3b;
      pppppcStack_2d0 = pppppcStack_180;
      pppppcStack_2ec = (code *****)0xb;
      pppppcStack_2e8 = pppppcStack_1a8;
      pppppcStack_2f8 = pppppcStack_1f8;
      pppppcStack_2e4 = (code *****)0xffffffff;
      pppppcStack_2e0 = pppppcStack_1a0;
      pppppcStack_2fc = (code *****)0x4d0a95;
      pppppcStack_184 = pppppcStack_2d4;
      __vbaLateIdCallSt();
      pppppcStack_2fc = (code *****)0x0;
      pppppcStack_300 = (code *****)0x4;
      pppppcStack_308 = &ppppcStack_11c;
      pppppcStack_304 = pppppcStack_1f8;
      pppppcStack_30c = (code *****)0x4d0aaa;
      pppppcStack_2d0 = (code *****)__vbaLateIdCallLd();
      ppppppcVar20 = (code ******)__vbaI4Var_exref;
      pppppcStack_2d4 = (code *****)0x4d0ab6;
      iVar11 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      ppppppcVar8 = (code ******)pppppcStack_2c0;
      uVar9 = uStack_224;
      uVar13 = uStack_204;
      if (SCARRY4(iVar11,1)) break;
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_2c8 = (code *****)0x4;
      ppppcStack_2c4 = (code ****)0x3;
      pppppcStack_2c0 = pppppcStack_188;
      pppppcStack_2cc = pppppcStack_1f8;
      pppppcStack_2b8 = pppppcStack_180;
      pppppcStack_2d0 = (code *****)0x4d0af7;
      pppppcStack_2bc = (code *****)(iVar11 + 1);
      pppppcStack_184 = (code *****)(iVar11 + 1);
      __vbaLateIdSt();
      pppppcStack_2d0 = (code *****)0x4d0b00;
      __vbaFreeVar();
      pppppcStack_2d0 = (code *****)0x0;
      pppppcStack_2d4 = (code *****)0x4;
      pppppcStack_2dc = &ppppcStack_11c;
      pppppcStack_2d8 = pppppcStack_1f8;
      pppppcStack_2e0 = (code *****)0x4d0b15;
      pppppcStack_2d0 = (code *****)__vbaLateIdCallLd();
      pppppcStack_2d4 = (code *****)0x4d0b1b;
      iVar11 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      ppppppcVar8 = (code ******)pppppcStack_2c0;
      uVar9 = uStack_224;
      uVar13 = uStack_204;
      if (SBORROW4(iVar11,1)) break;
      pppppcStack_2b8 = (code *****)0x4d0b2c;
      uStack_c8 = __vbaI2I4();
      pppppcStack_2b8 = (code *****)0x4d0b38;
      __vbaFreeVar();
      if (1 < (short)uStack_c8) {
        pppppcStack_2b8 = (code *****)0x0;
        pppppcStack_2bc = (code *****)0x4;
        ppppcStack_2c4 = (code ****)&ppppcStack_11c;
        pppppcStack_2c0 = pppppcStack_1f8;
        pppppcStack_2c8 = (code *****)0x4d0b58;
        pppppcStack_2b8 = (code *****)__vbaLateIdCallLd();
        pppppcStack_2bc = (code *****)0x4d0b5e;
        iVar11 = __vbaI4Var();
        ppppppcVar7 = (code ******)pppppcStack_2cc;
        ppppppcVar8 = (code ******)pppppcStack_2c0;
        uVar9 = uStack_224;
        uVar13 = uStack_204;
        if (SBORROW4(iVar11,1)) break;
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_1ac = (code *****)0x3;
        ppppcStack_2c4 = (code ****)0x3;
        ppppcStack_1cc = (code ****)0x8;
        pppppcStack_2c0 = pppppcStack_188;
        pppppcStack_1a4 = (code *****)&DAT_00000001;
        pwStack_1c4 = L"Labels: ";
        pppppcStack_2b8 = pppppcStack_180;
        pppppcStack_2d4 = (code *****)0x3;
        pppppcStack_2d0 = pppppcStack_1a8;
        pppppcStack_2e8 = (code *****)0x2;
        pppppcStack_2ec = (code *****)0x41;
        pppppcStack_2cc = (code *****)&DAT_00000001;
        pppppcStack_2c8 = pppppcStack_1a0;
        pppppcStack_2e4 = (code *****)0x8;
        pppppcStack_2e0 = pppppcStack_1c8;
        pppppcStack_2dc = (code *****)0x413488;
        pppppcStack_2d8 = pppppcStack_1c0;
        pppppcStack_2f0 = pppppcStack_1f8;
        pppppcStack_2f4 = (code *****)0x4d0c14;
        pppppcStack_2bc = (code *****)(iVar11 + -1);
        pppppcStack_184 = (code *****)(iVar11 + -1);
        __vbaLateIdCallSt();
        pppppcStack_2b8 = (code *****)0x4d0c20;
        __vbaFreeVar();
      }
      pppppcStack_2b8 = (code *****)0x4d0c30;
      __vbaStrCopy();
      if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
        pppppcStack_2b8 = (code *****)0x4d0c93;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar23 = DAT_0050b1a0[7];
        if (DAT_0050b1a0[6] <= (code *****)(1U - (int)pppppcVar23)) {
          pppppcStack_2b8 = (code *****)0x4d0c57;
          __vbaGenerateBoundsError();
        }
        ppppcStack_1e0 = (code ****)-(int)DAT_0050b1a0[5];
        if (DAT_0050b1a0[4] <= ppppcStack_1e0) {
          pppppcStack_2b8 = (code *****)0x4d0c75;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)(1U - (int)pppppcVar23) + (int)DAT_0050b1a0[6] * (int)ppppcStack_1e0) *
                 2;
      }
      ppppppcVar20 = (code ******)__vbaStrCat_exref;
      uStack_c8 = CONCAT22(uStack_c8._2_2_,*(undefined2 *)((int)DAT_0050b1a0[3] + iVar11));
      ppsStack_b8 = (short **)0x1;
      ppsVar14 = ppsStack_b8;
      goto LAB_004d0cb2;
    }
  }
  goto LAB_004d266c;
LAB_004d0cb2:
  ppsStack_b8 = ppsVar14;
  sVar17 = (short)ppsStack_b8;
  if ((short)uStack_c8 < sVar17) {
    pcVar6 = pcVar19;
    if (DAT_0050b244 == 0) {
      pppppcStack_2b8 = (code *****)0x4d121e;
      __vbaStrCopy();
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      goto LAB_004d15a9;
    }
    pppppcStack_2b8 = (code *****)DAT_0050b34c;
    pppppcStack_2bc = (code *****)0x4d1230;
    __vbaLenBstr();
    pppppcStack_2bc = (code *****)0x4d1238;
    ppsStack_b8 = (short **)__vbaI2I4();
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar9 = uStack_224;
    uVar13 = uStack_204;
    if (!SBORROW2((short)ppsStack_b8,1)) {
      pppppcStack_2b8 = (code *****)(int)(short)((short)ppsStack_b8 + -1);
      pppppcStack_2bc = (code *****)DAT_0050b34c;
      pppppcStack_2c0 = (code *****)0x4d1255;
      Ordinal_616();
      pppppcStack_2c0 = (code *****)0x4d125e;
      (*pcVar19)();
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      goto LAB_004d15a9;
    }
    goto LAB_004d266c;
  }
  if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
    pppppcStack_2b8 = (code *****)0x4d0d2b;
    iStack_26c = __vbaGenerateBoundsError();
  }
  else {
    ppppcStack_1e4 = (code ****)(1 - (int)DAT_0050b1a0[7]);
    if (DAT_0050b1a0[6] <= ppppcStack_1e4) {
      pppppcStack_2b8 = (code *****)0x4d0cdf;
      __vbaGenerateBoundsError();
      sVar17 = (short)ppsStack_b8;
    }
    ppppcStack_1e0 = (code ****)((int)sVar17 - (int)DAT_0050b1a0[5]);
    if (DAT_0050b1a0[4] <= ppppcStack_1e0) {
      pppppcStack_2b8 = (code *****)0x4d0d03;
      __vbaGenerateBoundsError();
    }
    iStack_26c = (int)((int)ppppcStack_1e4 + (int)DAT_0050b1a0[6] * (int)ppppcStack_1e0) * 2;
  }
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if ((((SBORROW2(DAT_0050b244,1)) || (SCARRY2(DAT_0050b332,4))) ||
      (iVar11 = (int)(short)(DAT_0050b244 + -1) * (int)(short)(DAT_0050b332 + 4),
      sVar17 = (short)iVar11, sVar17 != iVar11)) ||
     ((sVar16 = *(short *)((int)DAT_0050b1a0[3] + iStack_26c) + 3,
      SCARRY2(*(short *)((int)DAT_0050b1a0[3] + iStack_26c),3) || (SCARRY2(sVar17,sVar16)))))
  goto LAB_004d266c;
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2bc = (code *****)(int)(short)(sVar17 + sVar16);
  pppppcStack_2c8 = (code *****)0xa;
  ppppcStack_2c4 = (code ****)0x3;
  pppppcStack_2c0 = pppppcStack_188;
  pppppcStack_2cc = pppppcStack_1f8;
  pppppcStack_2b8 = pppppcStack_180;
  pppppcStack_2d0 = (code *****)0x4d0dbd;
  pppppcStack_184 = pppppcStack_2bc;
  __vbaLateIdSt();
  if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
    pppppcStack_2b8 = (code *****)0x4d0e2e;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    ppppcStack_1e4 = (code ****)(2 - (int)DAT_0050b1a0[7]);
    if (DAT_0050b1a0[6] <= ppppcStack_1e4) {
      pppppcStack_2b8 = (code *****)0x4d0dea;
      __vbaGenerateBoundsError();
    }
    ppppcStack_1e0 = (code ****)((int)(short)ppsStack_b8 - (int)DAT_0050b1a0[5]);
    if (DAT_0050b1a0[4] <= ppppcStack_1e0) {
      pppppcStack_2b8 = (code *****)0x4d0e0c;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((int)ppppcStack_1e4 + (int)DAT_0050b1a0[6] * (int)ppppcStack_1e0) * 2;
  }
  pppppcStack_18c = (code *****)0x3;
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SCARRY2(*(short *)((int)DAT_0050b1a0[3] + iVar11),1)) goto LAB_004d266c;
  pppppcStack_2bc = (code *****)(int)(short)(*(short *)((int)DAT_0050b1a0[3] + iVar11) + 1);
  ppppcStack_2c4 = (code ****)0x3;
  pppppcStack_2c8 = (code *****)0xb;
  pppppcStack_2c0 = pppppcStack_188;
  pppppcStack_2cc = pppppcStack_1f8;
  pppppcStack_2b8 = pppppcStack_180;
  pppppcStack_2d0 = (code *****)0x4d0e80;
  pppppcStack_184 = pppppcStack_2bc;
  __vbaLateIdSt();
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2e0 = (code *****)0x26;
  pppppcStack_2dc = (code *****)0x3;
  pppppcStack_184 = (code *****)0xff;
  pppppcStack_2d8 = pppppcStack_188;
  pppppcStack_2e4 = pppppcStack_1f8;
  pppppcStack_2d4 = (code *****)0xff;
  pppppcStack_2d0 = pppppcStack_180;
  pppppcStack_2e8 = (code *****)0x4d0ebd;
  __vbaLateIdSt();
  pppppcStack_2e8 = (code *****)0x4d0ec2;
  FUN_0044fdc0();
  pppppcStack_2e8 = (code *****)0x4d0ec9;
  (*pcVar19)();
  pppppcStack_2ec = &ppppcStack_cc;
  pppppcStack_2e8 = (code *****)DAT_0050b1a0;
  pppppcStack_2f0 = (code *****)0x4d0eda;
  __vbaAryLock();
  if (((code *****)ppppcStack_cc == (code *****)0x0) || (*(short *)ppppcStack_cc != 2)) {
    pppppcStack_2f0 = (code *****)0x4d0f42;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    ppppcStack_1e4 = (code ****)(2 - (int)ppppcStack_cc[7]);
    if (ppppcStack_cc[6] <= ppppcStack_1e4) {
      pppppcStack_2f0 = (code *****)0x4d0f04;
      __vbaGenerateBoundsError();
    }
    ppppcStack_1e0 = (code ****)((int)(short)ppsStack_b8 - (int)ppppcStack_cc[5]);
    if (ppppcStack_cc[4] <= ppppcStack_1e0) {
      pppppcStack_2f0 = (code *****)0x4d0f23;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((int)ppppcStack_1e4 + (int)ppppcStack_cc[6] * (int)ppppcStack_1e0) * 2;
  }
  pppppcStack_2f0 = (code *****)&pppppcStack_18c;
  pppppcStack_184 = (code *****)((int)ppppcStack_cc[3] + iVar11);
  pppppcStack_18c = (code *****)0x4002;
  pppppcStack_2f4 = (code *****)0x4d0f67;
  Ordinal_536();
  pppppcStack_2f4 = (code *****)0x4d0f6e;
  (*pcVar19)();
  pppppcStack_2f4 = &ppppcStack_cc;
  pppppcStack_2f8 = (code *****)0x4d0f78;
  __vbaAryUnlock();
  pppppcStack_114 = pppppcStack_108;
  pppppcStack_2fc = &ppppcStack_d0;
  pppppcStack_2f8 = (code *****)DAT_0050b19c;
  pppppcStack_108 = (code *****)0x0;
  ppppcStack_11c = (code ****)0x8;
  pppppcStack_300 = (code *****)0x4d0f9d;
  __vbaAryLock();
  if (((code *****)ppppcStack_d0 == (code *****)0x0) || (*(short *)ppppcStack_d0 != 2)) {
    pppppcStack_300 = (code *****)0x4d1003;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    pppcStack_1ec = (code ***)-(int)ppppcStack_d0[7];
    if (ppppcStack_d0[6] <= pppcStack_1ec) {
      pppppcStack_300 = (code *****)0x4d0fc2;
      __vbaGenerateBoundsError();
    }
    pppcStack_1e8 = (code ***)((int)(short)ppsStack_b8 - (int)ppppcStack_d0[5]);
    if (ppppcStack_d0[4] <= pppcStack_1e8) {
      pppppcStack_300 = (code *****)0x4d0fe3;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((int)pppcStack_1ec + (int)ppppcStack_d0[6] * (int)pppcStack_1e8) * 4;
  }
  pppppcStack_300 = (code *****)&DAT_00000001;
  pppppcStack_194 = (code *****)((int)ppppcStack_d0[3] + iVar11);
  pppppcStack_308 = &ppppcStack_11c;
  pppppcStack_304 = (code *****)&DAT_00000001;
  pppppcStack_30c = &ppppcStack_19c;
  pppppcStack_310 = &ppppcStack_12c;
  ppppcStack_19c = (code ****)0x4004;
  pppppcStack_314 = (code *****)0x4d1037;
  Ordinal_660();
  pppppcStack_314 = &ppppcStack_d0;
  pppppcStack_318 = (code *****)0x4d1041;
  __vbaAryUnlock();
  pppppcStack_31c = &ppppcStack_d4;
  pppppcStack_318 = (code *****)DAT_0050b1a0;
  pppppcStack_320 = (code *****)0x4d1051;
  __vbaAryLock();
  if (((code *****)ppppcStack_d4 == (code *****)0x0) || (*(short *)ppppcStack_d4 != 2)) {
    pppppcStack_320 = (code *****)0x4d10b9;
    iVar11 = __vbaGenerateBoundsError();
  }
  else {
    pppcStack_1f4 = (code ***)(1 - (int)ppppcStack_d4[7]);
    if (ppppcStack_d4[6] <= pppcStack_1f4) {
      pppppcStack_320 = (code *****)0x4d107b;
      __vbaGenerateBoundsError();
    }
    pppcStack_1f0 = (code ***)((int)(short)ppsStack_b8 - (int)ppppcStack_d4[5]);
    if (ppppcStack_d4[4] <= pppcStack_1f0) {
      pppppcStack_320 = (code *****)0x4d109a;
      __vbaGenerateBoundsError();
    }
    iVar11 = (int)((int)pppcStack_1f4 + (int)ppppcStack_d4[6] * (int)pppcStack_1f0) * 2;
  }
  pppppcStack_1ac = (code *****)0x4002;
  pppppcStack_1a4 = (code *****)((int)ppppcStack_d4[3] + iVar11);
  pppppcStack_320 = (code *****)&pppppcStack_1ac;
  pppppcStack_324 = (code *****)0x4d10de;
  Ordinal_536();
  pppppcStack_324 = (code *****)0x4d10e5;
  (*pcVar19)();
  pppppcStack_324 = &ppppcStack_d4;
  pppppcStack_328 = (code *****)0x4d10ef;
  __vbaAryUnlock();
  pppppcStack_328 = (code *****)DAT_0050b34c;
  pppppcStack_32c = (code *****)&DAT_0040fd5c;
  pppppcStack_330 = (code *****)0x4d10fd;
  __vbaStrCat();
  pppppcStack_330 = (code *****)0x4d1104;
  pppppcStack_330 = (code *****)(*pcVar19)();
  pppppcStack_334 = pppppcStack_d8;
  pppppcStack_338 = (code *****)0x4d110f;
  Ordinal_519();
  pppppcStack_338 = (code *****)0x4d1116;
  pppppcStack_338 = (code *****)(*pcVar19)();
  pppppcStack_33c = (code *****)0x4d1119;
  __vbaStrCat();
  pppppcStack_33c = (code *****)0x4d1120;
  pppppcStack_33c = (code *****)(*pcVar19)();
  puStack_340 = &DAT_004134bc;
  pppppcStack_344 = (code *****)0x4d1128;
  __vbaStrCat();
  pppppcStack_344 = (code *****)0x4d112f;
  pppppcStack_344 = (code *****)(*pcVar19)();
  pppppcStack_348 = &ppppcStack_12c;
  puStack_34c = &uStack_e8;
  pppppcStack_350 = (code *****)0x4d1141;
  pppppcStack_350 = (code *****)__vbaStrVarVal();
  pcStack_354 = (code *)0x4d1148;
  Ordinal_519();
  pcStack_354 = (code *)0x4d114f;
  pcStack_354 = (code *)(*pcVar19)();
  pcStack_358 = (code *)0x4d1152;
  __vbaStrCat();
  pcStack_358 = (code *)0x4d1159;
  pcStack_358 = (code *)(*pcVar19)();
  __vbaStrCat(&DAT_00411cc4);
  uVar13 = (*pcVar19)();
  Ordinal_519(uStack_f8,uVar13);
  uVar13 = (*pcVar19)();
  __vbaStrCat(uVar13);
  uVar13 = (*pcVar19)();
  __vbaStrCat(&DAT_004134c8,uVar13);
  (*pcVar19)();
  __vbaFreeStrList(0xd,&pppppcStack_d8,&pppppcStack_dc,&uStack_e0,&uStack_e4,&uStack_e8,&uStack_ec,
                   &uStack_f0,&uStack_f4,&uStack_f8,&uStack_fc,&uStack_100,&uStack_104,
                   &pppppcStack_108);
  __vbaFreeVarList(2,&ppppcStack_11c,&ppppcStack_12c);
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  ppsVar14 = (short **)(uint)(ushort)((short)ppsStack_b8 + 1);
  if (SCARRY2((short)ppsStack_b8,1)) goto LAB_004d266c;
  goto LAB_004d0cb2;
LAB_004d194f:
  ppsStack_b8 = ppsVar14;
  if (1 < (short)ppsVar14) {
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2c8 = (code *****)0xb;
    ppppcStack_2c4 = (code ****)0x3;
    pppppcStack_184 = (code *****)0x0;
    pppppcStack_2c0 = pppppcStack_188;
    pppppcStack_2cc = pppppcStack_1f8;
    pppppcStack_2bc = (code *****)0x0;
    pppppcStack_2b8 = pppppcStack_180;
    pppppcStack_2d0 = (code *****)0x4d1de7;
    __vbaLateIdSt();
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2e0 = (code *****)0x26;
    pppppcStack_2dc = (code *****)0x3;
    pppppcStack_184 = (code *****)0xffff00;
    pppppcStack_2d8 = pppppcStack_188;
    pppppcStack_2e4 = pppppcStack_1f8;
    pppppcStack_2d4 = (code *****)0xffff00;
    pppppcStack_2d0 = pppppcStack_180;
    pppppcStack_2e8 = (code *****)0x4d1e24;
    __vbaLateIdSt();
    ppsVar14 = (short **)0x1;
    sStack_244 = DAT_0050b332;
    goto LAB_004d1e37;
  }
  pppppcStack_2b8 = (code *****)0x0;
  pppppcStack_2bc = (code *****)0x4;
  ppppcStack_2c4 = (code ****)&ppppcStack_11c;
  pppppcStack_2c0 = pppppcStack_1f8;
  pppppcStack_2c8 = (code *****)0x4d1975;
  pppppcStack_2b8 = (code *****)__vbaLateIdCallLd();
  ppppppcVar20 = (code ******)__vbaI4Var_exref;
  pppppcStack_2bc = (code *****)0x4d1981;
  iVar11 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SCARRY4(iVar11,1)) goto LAB_004d266c;
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2c8 = (code *****)0x4;
  ppppcStack_2c4 = (code ****)0x3;
  pppppcStack_2c0 = pppppcStack_188;
  pppppcStack_2cc = pppppcStack_1f8;
  pppppcStack_2b8 = pppppcStack_180;
  pppppcStack_2d0 = (code *****)0x4d19c2;
  pppppcStack_2bc = (code *****)(iVar11 + 1);
  pppppcStack_184 = (code *****)(iVar11 + 1);
  __vbaLateIdSt();
  pppppcStack_2d0 = (code *****)0x4d19cb;
  __vbaFreeVar();
  pppppcStack_2d0 = (code *****)0x0;
  pppppcStack_2d4 = (code *****)0x4;
  pppppcStack_2dc = &ppppcStack_11c;
  pppppcStack_2d8 = pppppcStack_1f8;
  pppppcStack_2e0 = (code *****)0x4d19e0;
  pppppcStack_2d0 = (code *****)__vbaLateIdCallLd();
  pppppcStack_2d4 = (code *****)0x4d19e6;
  iVar11 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SBORROW4(iVar11,1)) goto LAB_004d266c;
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2c8 = (code *****)0xa;
  ppppcStack_2c4 = (code ****)0x3;
  pppppcStack_2c0 = pppppcStack_188;
  pppppcStack_2cc = pppppcStack_1f8;
  pppppcStack_2b8 = pppppcStack_180;
  pppppcStack_2d0 = (code *****)0x4d1a27;
  pppppcStack_2bc = (code *****)(iVar11 + -1);
  pppppcStack_184 = (code *****)(iVar11 + -1);
  __vbaLateIdSt();
  pppppcStack_2d0 = (code *****)0x4d1a30;
  __vbaFreeVar();
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SCARRY2(DAT_0050b332,1)) goto LAB_004d266c;
  ppppppcVar22 = (code ******)0x0;
  uStack_234 = CONCAT22(extraout_var_02,DAT_0050b332 + 1);
  while( true ) {
    ppppppcVar20 = ppppppcVar22;
    sVar17 = (short)ppppppcVar20;
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar9 = uStack_224;
    uVar13 = uStack_204;
    if ((short)uStack_234 < sVar17) break;
    if ((sVar17 < 0) || (1 < sVar17)) {
      if ((short)ppsStack_b8 == 0) {
        pppppcStack_2b4 = (code *****)&DAT_0040de90;
        if (SBORROW2(sVar17,1)) goto LAB_004d266c;
        pppppcStack_114 = (code *****)CONCAT22(pppppcStack_114._2_2_,sVar17 + -1);
        ppppcStack_11c = (code ****)0x2;
        pppppcStack_2c0 = (code *****)0x4d1bb2;
        pppppcStack_2bc = &ppppcStack_11c;
        Ordinal_536();
        pppppcStack_2c0 = (code *****)0x4d1bb9;
        pppppcStack_2c0 = (code *****)(*pcVar19)();
        ppppcStack_2c4 = (code ****)0x4d1bc0;
        Ordinal_519();
        ppppcStack_2c4 = (code ****)0x4d1bc7;
        ppppcStack_2c4 = (code ****)(*pcVar19)();
        pppppcStack_2c8 = (code *****)0x4d1bce;
        __vbaStrCat();
        pppppcStack_2c8 = (code *****)0x4d1bd7;
        (*pcVar19)();
        pppppcStack_2c8 = (code *****)&pppppcStack_dc;
        pppppcStack_2cc = (code *****)&pppppcStack_d8;
        pppppcStack_2d0 = (code *****)0x2;
        pppppcStack_2d4 = (code *****)0x4d1be7;
        __vbaFreeStrList();
        pppppcStack_2c8 = (code *****)0x4d1bf3;
        __vbaFreeVar();
      }
      else if ((short)ppsStack_b8 == 1) {
        if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
          pppppcStack_2b8 = (code *****)0x4d1adc;
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          if (SBORROW2(sVar17,1)) goto LAB_004d266c;
          ppppcStack_1e0 = (code ****)((int)(short)(sVar17 + -1) - *(int *)(DAT_0050b394 + 10));
          if (*(code ******)(DAT_0050b394 + 8) <= ppppcStack_1e0) {
            pppppcStack_2b8 = (code *****)0x4d1ac2;
            __vbaGenerateBoundsError();
          }
          iVar11 = (int)ppppcStack_1e0 * 0x18;
        }
        pppppcStack_2b8 = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar11);
        pppppcStack_2bc = (code *****)0xc;
        pppppcStack_2c0 = (code *****)0x4d1af0;
        __vbaStrFixstr();
        pppppcStack_2c0 = (code *****)0x4d1af7;
        pppppcStack_2c0 = (code *****)(*pcVar19)();
        ppppcStack_2c4 = (code ****)0x4d1afe;
        Ordinal_519();
        ppppcStack_2c4 = (code ****)0x4d1b05;
        (*pcVar19)();
        if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
          pppppcStack_2b8 = (code *****)0x4d1b57;
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          ppppppcVar7 = (code ******)pppppcStack_2cc;
          ppppppcVar8 = (code ******)pppppcStack_2c0;
          uVar9 = uStack_224;
          uVar13 = uStack_204;
          if (SBORROW2(sVar17,1)) goto LAB_004d266c;
          ppppcStack_1e4 = (code ****)((int)(short)(sVar17 + -1) - *(int *)(DAT_0050b394 + 10));
          if (*(code ******)(DAT_0050b394 + 8) <= ppppcStack_1e4) {
            pppppcStack_2b8 = (code *****)0x4d1b3d;
            __vbaGenerateBoundsError();
          }
          iVar11 = (int)ppppcStack_1e4 * 0x18;
        }
        pppppcStack_2bc = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar11);
        pppppcStack_2b8 = pppppcStack_d8;
        pppppcStack_2c0 = (code *****)0xc;
        ppppcStack_2c4 = (code ****)0x4d1b6f;
        __vbaLsetFixstr();
        pppppcStack_dc = (code *****)0x0;
        ppppcStack_2c4 = (code ****)0x4d1b80;
        (*pcVar19)();
        ppppcStack_2c4 = (code ****)0x4d1b89;
        __vbaFreeStr();
      }
    }
    else {
      pppppcStack_2b8 = (code *****)0x4d1a71;
      __vbaStrCopy();
    }
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2bc = (code *****)(int)sVar17;
    ppppcStack_2c4 = (code ****)0x3;
    pppppcStack_2c8 = (code *****)0xb;
    pppppcStack_2c0 = pppppcStack_188;
    pppppcStack_2cc = pppppcStack_1f8;
    pppppcStack_2b8 = pppppcStack_180;
    pppppcStack_2d0 = (code *****)0x4d1c2e;
    pppppcStack_184 = pppppcStack_2bc;
    __vbaLateIdSt();
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2e0 = (code *****)0x27;
    pppppcStack_2dc = (code *****)0x3;
    pppppcStack_184 = (code *****)0xff0000;
    pppppcStack_2d8 = pppppcStack_188;
    pppppcStack_2e4 = pppppcStack_1f8;
    pppppcStack_2d4 = (code *****)0xff0000;
    pppppcStack_2d0 = pppppcStack_180;
    pppppcStack_2e8 = (code *****)0x4d1c6b;
    __vbaLateIdSt();
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_2f8 = (code *****)0x26;
    pppppcStack_2f4 = (code *****)0x3;
    pppppcStack_184 = (code *****)0xffff00;
    pppppcStack_2f0 = pppppcStack_188;
    pppppcStack_2fc = pppppcStack_1f8;
    pppppcStack_2ec = (code *****)0xffff00;
    pppppcStack_2e8 = pppppcStack_180;
    pppppcStack_300 = (code *****)0x4d1ca8;
    __vbaLateIdSt();
    pppppcStack_300 = (code *****)0x0;
    pppppcStack_304 = (code *****)0xa;
    pppppcStack_30c = &ppppcStack_11c;
    pppppcStack_308 = pppppcStack_1f8;
    pppppcStack_310 = (code *****)0x4d1cbd;
    pppppcStack_300 = (code *****)__vbaLateIdCallLd();
    pppppcStack_304 = (code *****)0x4d1cc7;
    pppppcStack_308 = (code *****)__vbaI4Var();
    pppppcStack_318 = (code *****)(int)sVar17;
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_1ac = (code *****)0x3;
    pppppcStack_310 = (code *****)0x3;
    pppppcStack_30c = pppppcStack_188;
    pwStack_1c4 = (wchar_t *)&DAT_0050b34c;
    ppppcStack_1cc = (code ****)0x4008;
    pppppcStack_304 = pppppcStack_180;
    pppppcStack_320 = (code *****)0x3;
    pppppcStack_31c = pppppcStack_1a8;
    pppppcStack_314 = pppppcStack_1a0;
    pppppcStack_334 = (code *****)0x2;
    pppppcStack_338 = (code *****)0x41;
    pppppcStack_330 = (code *****)0x4008;
    pppppcStack_32c = pppppcStack_1c8;
    pppppcStack_328 = (code *****)&DAT_0050b34c;
    pppppcStack_324 = pppppcStack_1c0;
    pppppcStack_33c = pppppcStack_1f8;
    puStack_340 = (undefined *)0x4d1d78;
    pppppcStack_1a4 = pppppcStack_318;
    pppppcStack_184 = pppppcStack_308;
    __vbaLateIdCallSt();
    pppppcStack_304 = (code *****)0x4d1d84;
    __vbaFreeVar();
    ppppppcVar22 = (code ******)(uint)(ushort)(sVar17 + 1);
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar9 = uStack_224;
    uVar13 = uStack_204;
    if (SCARRY2(sVar17,1)) goto LAB_004d266c;
  }
  ppsVar14 = (short **)(uint)(ushort)((short)ppsStack_b8 + 1);
  if (SCARRY2((short)ppsStack_b8,1)) goto LAB_004d266c;
  goto LAB_004d194f;
LAB_004d1e37:
  pppppcStack_2b8 = (code *****)0x0;
  ppsStack_b8 = ppsVar14;
  if (sStack_244 < (short)ppsVar14) {
    pppppcStack_2bc = (code *****)&pppppcStack_1f8;
    pppppcStack_2c0 = (code *****)0x4d25a9;
    __vbaObjSetAddref();
    goto code_r0x004d25aa;
  }
  pppppcStack_2bc = (code *****)0x4;
  ppppcStack_2c4 = (code ****)&ppppcStack_11c;
  pppppcStack_2c0 = pppppcStack_1f8;
  pppppcStack_2c8 = (code *****)0x4d1e5c;
  pppppcStack_2b8 = (code *****)__vbaLateIdCallLd();
  ppppppcVar20 = (code ******)__vbaI4Var_exref;
  pppppcStack_2bc = (code *****)0x4d1e68;
  iVar11 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SCARRY4(iVar11,1)) goto LAB_004d266c;
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2c8 = (code *****)0x4;
  ppppcStack_2c4 = (code ****)0x3;
  pppppcStack_2c0 = pppppcStack_188;
  pppppcStack_2cc = pppppcStack_1f8;
  pppppcStack_2b8 = pppppcStack_180;
  pppppcStack_2d0 = (code *****)0x4d1ea9;
  pppppcStack_2bc = (code *****)(iVar11 + 1);
  pppppcStack_184 = (code *****)(iVar11 + 1);
  __vbaLateIdSt();
  pppppcStack_2d0 = (code *****)0x4d1eb2;
  __vbaFreeVar();
  pppppcStack_2d0 = (code *****)0x0;
  pppppcStack_2d4 = (code *****)0x4;
  pppppcStack_2dc = &ppppcStack_11c;
  pppppcStack_2d8 = pppppcStack_1f8;
  pppppcStack_2e0 = (code *****)0x4d1ec7;
  pppppcStack_2d0 = (code *****)__vbaLateIdCallLd();
  pppppcStack_2d4 = (code *****)0x4d1ecd;
  iVar11 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SBORROW4(iVar11,1)) goto LAB_004d266c;
  pppppcStack_2b8 = (code *****)0x4d1ede;
  ppppppcVar20 = (code ******)__vbaI2I4();
  pppppcStack_2b8 = (code *****)0x4d1eec;
  pppppcStack_c0 = (code *****)ppppppcVar20;
  __vbaFreeVar();
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2bc = (code *****)(int)(short)ppppppcVar20;
  ppppcStack_2c4 = (code ****)0x3;
  pppppcStack_2c8 = (code *****)0xa;
  pppppcStack_2c0 = pppppcStack_188;
  pppppcStack_2cc = pppppcStack_1f8;
  pppppcStack_2b8 = pppppcStack_180;
  pppppcStack_2d0 = (code *****)0x4d1f27;
  pppppcStack_184 = pppppcStack_2bc;
  __vbaLateIdSt();
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2e0 = (code *****)0xb;
  pppppcStack_2dc = (code *****)0x3;
  pppppcStack_184 = (code *****)0x0;
  pppppcStack_2d8 = pppppcStack_188;
  pppppcStack_2e4 = pppppcStack_1f8;
  pppppcStack_2d4 = (code *****)0x0;
  pppppcStack_2d0 = pppppcStack_180;
  pppppcStack_2e8 = (code *****)0x4d1f61;
  __vbaLateIdSt();
  pppppcStack_184 = (code *****)0xff0000;
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_2f8 = (code *****)0x27;
  pppppcStack_2f4 = (code *****)0x3;
  pppppcStack_2f0 = pppppcStack_188;
  pppppcStack_2fc = pppppcStack_1f8;
  pppppcStack_2ec = (code *****)0xff0000;
  pppppcStack_2e8 = pppppcStack_180;
  pppppcStack_300 = (code *****)0x4d1f9e;
  __vbaLateIdSt();
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_310 = (code *****)0x26;
  pppppcStack_30c = (code *****)0x3;
  pppppcStack_184 = (code *****)0xffff00;
  pppppcStack_308 = pppppcStack_188;
  pppppcStack_314 = pppppcStack_1f8;
  pppppcStack_304 = (code *****)0xffff00;
  pppppcStack_300 = pppppcStack_180;
  pppppcStack_318 = (code *****)0x4d1fdb;
  __vbaLateIdSt();
  pppppcStack_18c = (code *****)0x3;
  pppppcStack_328 = (code *****)0xb;
  pppppcStack_324 = (code *****)0x3;
  pppppcStack_184 = (code *****)0x1;
  pppppcStack_320 = pppppcStack_188;
  pppppcStack_32c = pppppcStack_1f8;
  pppppcStack_31c = (code *****)&DAT_00000001;
  pppppcStack_318 = pppppcStack_180;
  pppppcStack_330 = (code *****)0x4d2018;
  __vbaLateIdSt();
  pppppcStack_18c = (code *****)0x3;
  puStack_340 = (undefined *)0x27;
  pppppcStack_33c = (code *****)0x3;
  pppppcStack_184 = (code *****)0xff0000;
  pppppcStack_338 = pppppcStack_188;
  pppppcStack_344 = pppppcStack_1f8;
  pppppcStack_334 = (code *****)0xff0000;
  pppppcStack_330 = pppppcStack_180;
  pppppcStack_348 = (code *****)0x4d2055;
  __vbaLateIdSt();
  pppppcStack_18c = (code *****)0x3;
  pcStack_358 = (code *)0x26;
  pcStack_354 = (code *)0x3;
  pppppcStack_184 = (code *****)0xffff00;
  pppppcStack_350 = pppppcStack_188;
  puStack_34c = (undefined4 *)0xffff00;
  pppppcStack_348 = pppppcStack_180;
  __vbaLateIdSt(pppppcStack_1f8);
  ppsVar14 = (short **)&DAT_00000001;
  sStack_24c = DAT_0050b332;
  while( true ) {
    ppsStack_bc = ppsVar14;
    if (sStack_24c < (short)ppsVar14) break;
    if ((short)ppsStack_b8 != (short)ppsVar14) {
      pppppcStack_2bc = (code *****)&pppppcStack_18c;
      pppppcStack_184 = (code *****)&ppsStack_b8;
      pppppcStack_2b8 = (code *****)&DAT_0040de90;
      pppppcStack_18c = (code *****)0x4002;
      pppppcStack_2c0 = (code *****)0x4d20e4;
      Ordinal_536();
      pppppcStack_2c0 = (code *****)0x4d20eb;
      pppppcStack_2c0 = (code *****)(*pcVar19)();
      ppppcStack_2c4 = (code ****)0x4d20f2;
      Ordinal_519();
      ppppcStack_2c4 = (code ****)0x4d20f9;
      ppppcStack_2c4 = (code ****)(*pcVar19)();
      pppppcStack_2c8 = (code *****)0x4d2100;
      __vbaStrCat();
      pppppcStack_2c8 = (code *****)0x4d2109;
      (*pcVar19)();
      pppppcStack_2c8 = (code *****)&pppppcStack_dc;
      pppppcStack_2cc = (code *****)&pppppcStack_d8;
      pppppcStack_2d0 = (code *****)0x2;
      pppppcStack_2d4 = (code *****)0x4d2119;
      __vbaFreeStrList();
      ppppppcVar20 = (code ******)(int)(short)pppppcStack_c0;
      pppppcStack_2cc = (code *****)&pppppcStack_18c;
      pppppcStack_184 = (code *****)&ppsStack_b8;
      pppppcStack_2c8 = (code *****)&DAT_0040de90;
      ppppcStack_19c = (code ****)0x3;
      pppppcStack_1b4 = (code *****)0x0;
      pppppcStack_1bc = (code *****)0x3;
      pppppcStack_18c = (code *****)0x4002;
      pppppcStack_2d0 = (code *****)0x4d2166;
      pppppcStack_194 = (code *****)ppppppcVar20;
      Ordinal_536();
      pppppcStack_2d0 = (code *****)0x4d216d;
      pppppcStack_2d0 = (code *****)(*pcVar19)();
      pppppcStack_2d4 = (code *****)0x4d2174;
      Ordinal_519();
      pppppcStack_2d4 = (code *****)0x4d217b;
      pppppcStack_2d4 = (code *****)(*pcVar19)();
      pppppcStack_2d8 = (code *****)0x4d2182;
      pppppcStack_2fc = (code *****)__vbaStrCat();
      ppppcStack_11c = (code ****)0x8;
      pppppcStack_2e4 = (code *****)ppppcStack_19c;
      pppppcStack_2e0 = (code *****)uStack_198;
      pppppcStack_2dc = pppppcStack_194;
      pppppcStack_2d8 = (code *****)ppppcStack_190;
      pppppcStack_2f4 = pppppcStack_1bc;
      pppppcStack_2f0 = pppppcStack_1b8;
      pppppcStack_2ec = pppppcStack_1b4;
      pppppcStack_2e8 = pppppcStack_1b0;
      pppppcStack_304 = (code *****)0x8;
      pppppcStack_300 = pppppcStack_118;
      pppppcStack_2f8 = pppppcStack_110;
      pppppcStack_308 = (code *****)0x2;
      pppppcStack_30c = (code *****)0x41;
      pppppcStack_310 = pppppcStack_1f8;
      pppppcStack_314 = (code *****)0x4d2206;
      pppppcStack_114 = pppppcStack_2fc;
      __vbaLateIdCallSt();
      pppppcStack_314 = (code *****)&pppppcStack_dc;
      pppppcStack_318 = (code *****)&pppppcStack_d8;
      pppppcStack_31c = (code *****)0x2;
      pppppcStack_320 = (code *****)0x4d2216;
      __vbaFreeStrList();
      pppppcStack_2d8 = (code *****)0x4d2222;
      __vbaFreeVar();
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_1a4 = (code *****)&DAT_00000001;
      pppppcStack_1ac = (code *****)0x3;
      pppppcStack_184 = (code *****)ppppppcVar20;
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppcStack_2d8 = (code *****)0x4d2289;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        ppppcStack_1e0 = (code ****)((int)(short)ppsStack_b8 - *(int *)(DAT_0050b394 + 10));
        if (*(code ******)(DAT_0050b394 + 8) <= ppppcStack_1e0) {
          pppppcStack_2d8 = (code *****)0x4d226f;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)ppppcStack_1e0 * 0x18;
      }
      pppppcStack_2d8 = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar11);
      pppppcStack_2dc = (code *****)0xc;
      pppppcStack_2e0 = (code *****)0x4d229d;
      __vbaStrFixstr();
      pppppcStack_2e0 = (code *****)0x4d22a4;
      pppppcStack_2e0 = (code *****)(*pcVar19)();
      pppppcStack_2e4 = (code *****)0x4d22ab;
      Ordinal_519();
      pppppcStack_2e4 = (code *****)0x4d22b2;
      (*pcVar19)();
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppcStack_2e4 = (code *****)0x4d22f8;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        ppppcStack_1e4 = (code ****)((int)(short)ppsStack_b8 - *(int *)(DAT_0050b394 + 10));
        if (*(code ******)(DAT_0050b394 + 8) <= ppppcStack_1e4) {
          pppppcStack_2e4 = (code *****)0x4d22de;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)ppppcStack_1e4 * 0x18;
      }
      pppppcStack_2e8 = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar11);
      pppppcStack_2e4 = pppppcStack_d8;
      pppppcStack_2ec = (code *****)0xc;
      pppppcStack_2f0 = (code *****)0x4d2310;
      __vbaLsetFixstr();
      pppppcStack_314 = pppppcStack_dc;
      ppppcStack_11c = (code ****)0x8;
      pppppcStack_2fc = pppppcStack_18c;
      pppppcStack_114 = pppppcStack_dc;
      pppppcStack_dc = (code *****)0x0;
      pppppcStack_2f8 = pppppcStack_188;
      pppppcStack_2f4 = pppppcStack_184;
      pppppcStack_2f0 = pppppcStack_180;
      pppppcStack_30c = pppppcStack_1ac;
      pppppcStack_308 = pppppcStack_1a8;
      pppppcStack_304 = pppppcStack_1a4;
      pppppcStack_300 = pppppcStack_1a0;
      pppppcStack_320 = (code *****)0x2;
      pppppcStack_324 = (code *****)0x41;
      pppppcStack_31c = (code *****)0x8;
      pppppcStack_318 = pppppcStack_118;
      pppppcStack_328 = pppppcStack_1f8;
      pppppcStack_310 = pppppcStack_110;
      pppppcStack_32c = (code *****)0x4d239e;
      __vbaLateIdCallSt();
      pppppcStack_2f0 = (code *****)0x4d23aa;
      __vbaFreeStr();
      pppppcStack_2f0 = (code *****)0x4d23b3;
      __vbaFreeVar();
      pppppcStack_2f0 = (code *****)0x4d23b8;
      FUN_0044fdc0();
      pppppcStack_2f0 = (code *****)0x4d23bf;
      (*pcVar19)();
      bVar24 = SCARRY2((short)ppsStack_bc,1);
      sVar17 = (short)ppsStack_bc + 1;
      ppppcStack_19c = (code ****)0x3;
      pppppcStack_1bc = (code *****)0x3;
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      ppppppcVar8 = (code ******)pppppcStack_2c0;
      uVar9 = uStack_224;
      uVar13 = uStack_204;
      if (bVar24) goto LAB_004d266c;
      pppppcStack_1b4 = (code *****)(int)sVar17;
      pppppcStack_114 = pppppcStack_d8;
      pppppcStack_2bc = &ppppcStack_cc;
      pppppcStack_2b8 = (code *****)DAT_0050b19c;
      pppppcStack_d8 = (code *****)0x0;
      ppppcStack_11c = (code ****)0x8;
      pppppcStack_2c0 = (code *****)0x4d2412;
      pppppcStack_194 = (code *****)ppppppcVar20;
      __vbaAryLock();
      if (((code *****)ppppcStack_cc == (code *****)0x0) || (*(short *)ppppcStack_cc != 2)) {
        pppppcStack_2c0 = (code *****)0x4d246e;
        iVar11 = __vbaGenerateBoundsError();
      }
      else {
        ppppcStack_1e4 = (code ****)((int)(short)ppsStack_b8 - (int)ppppcStack_cc[7]);
        if (ppppcStack_cc[6] <= ppppcStack_1e4) {
          pppppcStack_2c0 = (code *****)0x4d243b;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)(short)ppsStack_bc;
        ppppcVar2 = (code ****)ppppcStack_cc[5];
        if (ppppcStack_cc[4] <= (code ****)(iVar11 - (int)ppppcVar2)) {
          pppppcStack_2c0 = (code *****)0x4d2454;
          __vbaGenerateBoundsError();
        }
        iVar11 = (int)((int)ppppcStack_1e4 + (int)ppppcStack_cc[6] * (iVar11 - (int)ppppcVar2)) * 4;
      }
      pppppcStack_2c0 = (code *****)&DAT_00000001;
      pppppcStack_184 = (code *****)((int)ppppcStack_cc[3] + iVar11);
      pppppcStack_2c8 = &ppppcStack_11c;
      ppppcStack_2c4 = (code ****)&DAT_00000001;
      pppppcStack_2cc = (code *****)&pppppcStack_18c;
      pppppcStack_2d0 = &ppppcStack_12c;
      pppppcStack_18c = (code *****)0x4004;
      pppppcStack_2d4 = (code *****)0x4d24a2;
      Ordinal_660();
      pppppcStack_2d4 = &ppppcStack_cc;
      pppppcStack_2d8 = (code *****)0x4d24ac;
      __vbaAryUnlock();
      pppppcStack_2d8 = &ppppcStack_12c;
      pppppcStack_2dc = (code *****)0x4d24b9;
      pppppcStack_300 = (code *****)__vbaStrVarMove();
      ppppppcVar20 = (code ******)pppppcStack_1b0;
      pppppcStack_2e8 = (code *****)ppppcStack_19c;
      ppppcStack_13c = (code ****)0x8;
      pppppcStack_2e4 = (code *****)uStack_198;
      pppppcStack_2e0 = pppppcStack_194;
      pppppcStack_2dc = (code *****)ppppcStack_190;
      pppppcStack_2f8 = pppppcStack_1bc;
      pppppcStack_2f4 = pppppcStack_1b8;
      pppppcStack_2f0 = pppppcStack_1b4;
      pppppcStack_2ec = pppppcStack_1b0;
      pppppcStack_30c = (code *****)0x2;
      pppppcStack_310 = (code *****)0x41;
      pppppcStack_308 = (code *****)0x8;
      pppppcStack_304 = pppppcStack_138;
      pppppcStack_314 = pppppcStack_1f8;
      pppppcStack_2fc = pppppcStack_130;
      pppppcStack_318 = (code *****)0x4d2547;
      pppppcStack_134 = pppppcStack_300;
      __vbaLateIdCallSt();
      pppppcStack_2dc = (code *****)0x4d2553;
      __vbaFreeStr();
      pppppcStack_2dc = &ppppcStack_13c;
      pppppcStack_2e0 = &ppppcStack_12c;
      pppppcStack_2e4 = &ppppcStack_11c;
      pppppcStack_2e8 = (code *****)0x3;
      pppppcStack_2ec = (code *****)0x4d256d;
      __vbaFreeVarList();
    }
    ppsVar14 = (short **)(uint)(ushort)((short)ppsStack_bc + 1);
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar9 = uStack_224;
    uVar13 = uStack_204;
    if (SCARRY2((short)ppsStack_bc,1)) goto LAB_004d266c;
  }
  ppsVar14 = (short **)(uint)(ushort)((short)ppsStack_b8 + 1);
  ppppppcVar7 = (code ******)pppppcStack_2cc;
  ppppppcVar8 = (code ******)pppppcStack_2c0;
  uVar9 = uStack_224;
  uVar13 = uStack_204;
  if (SCARRY2((short)ppsStack_b8,1)) goto LAB_004d266c;
  goto LAB_004d1e37;
  while( true ) {
    if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
      pppppcStack_a4 = (code *****)0x4d01c1;
      pppppcVar21 = (code *****)__vbaGenerateBoundsError();
    }
    else {
      iVar11 = (int)(short)local_30;
      pppppcVar21 = DAT_0050b19c[7];
      if (DAT_0050b19c[6] <= (code *****)(iVar11 - (int)pppppcVar21)) {
        pppppcStack_a4 = (code *****)0x4d018e;
        __vbaGenerateBoundsError();
      }
      pppppcVar23 = (code *****)((int)(short)local_18 - (int)DAT_0050b19c[5]);
      if (DAT_0050b19c[4] <= pppppcVar23) {
        pppppcStack_a4 = (code *****)0x4d01a9;
        __vbaGenerateBoundsError();
      }
      pppppcVar21 = (code *****)
                    ((int)((iVar11 - (int)pppppcVar21) + (int)DAT_0050b19c[6] * (int)pppppcVar23) *
                    4);
    }
    if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
      pppppcStack_a4 = (code *****)0x4d021b;
      iVar11 = __vbaGenerateBoundsError();
    }
    else {
      iVar11 = (int)(short)local_30;
      pppppcVar1 = DAT_0050b19c[7];
      if (DAT_0050b19c[6] <= (code *****)(iVar11 - (int)pppppcVar1)) {
        pppppcStack_a4 = (code *****)0x4d01e8;
        __vbaGenerateBoundsError();
      }
      pppppcVar23 = (code *****)((int)(short)local_18 - (int)DAT_0050b19c[5]);
      if (DAT_0050b19c[4] <= pppppcVar23) {
        pppppcStack_a4 = (code *****)0x4d0203;
        __vbaGenerateBoundsError();
      }
      iVar11 = (int)((iVar11 - (int)pppppcVar1) + (int)DAT_0050b19c[6] * (int)pppppcVar23) * 4;
    }
    pcVar19 = __vbaGenerateBoundsError_exref;
    *(float *)((int)DAT_0050b19c[3] + iVar11) =
         local_2c + *(float *)((int)DAT_0050b19c[3] + (int)pppppcVar21);
    if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004d0287;
    uVar10 = (uint)(ushort)((short)local_1c + 1);
    if (SCARRY2((short)local_1c,1)) break;
LAB_004cffd8:
    local_1c = uVar10;
    if ((short)local_24 < (short)local_1c) {
code_r0x004d024e:
      pppppcStack_a4 = (code *****)&LAB_004d0276;
      ppsStack_a8 = &local_28;
      puStack_ac = (undefined4 *)0x0;
      puStack_b0 = (undefined4 *)0x4d0275;
      __vbaAryDestruct();
      return;
    }
    if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
      pppppcStack_a4 = (code *****)0x4d0035;
      iVar11 = (*pcVar19)();
    }
    else {
      pppppcVar23 = (code *****)(1 - (int)DAT_0050b1a0[7]);
      if (DAT_0050b1a0[6] <= pppppcVar23) {
        pppppcStack_a4 = (code *****)0x4d0009;
        (*pcVar19)();
      }
      pppppcVar21 = (code *****)((int)(short)local_1c - (int)DAT_0050b1a0[5]);
      if (DAT_0050b1a0[4] <= pppppcVar21) {
        pppppcStack_a4 = (code *****)0x4d0021;
        (*pcVar19)();
      }
      iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b1a0[6] * (int)pppppcVar21) * 2;
    }
    local_18 = CONCAT22(local_18._2_2_,*(undefined2 *)((int)DAT_0050b1a0[3] + iVar11));
    if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
      pppppcStack_a4 = (code *****)0x4d008f;
      iVar11 = (*pcVar19)();
    }
    else {
      pppppcVar23 = (code *****)(2 - (int)DAT_0050b1a0[7]);
      if (DAT_0050b1a0[6] <= pppppcVar23) {
        pppppcStack_a4 = (code *****)0x4d0063;
        (*pcVar19)();
      }
      pppppcVar21 = (code *****)((int)(short)local_1c - (int)DAT_0050b1a0[5]);
      if (DAT_0050b1a0[4] <= pppppcVar21) {
        pppppcStack_a4 = (code *****)0x4d007b;
        (*pcVar19)();
      }
      iVar11 = (int)((int)pppppcVar23 + (int)DAT_0050b1a0[6] * (int)pppppcVar21) * 2;
    }
    sVar17 = *(short *)((int)DAT_0050b1a0[3] + iVar11);
    local_30 = CONCAT22((short)((uint)pppppcVar21 >> 0x10),sVar17);
    if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
      pppppcStack_a4 = (code *****)0x4d00f2;
      iVar11 = (*pcVar19)();
    }
    else {
      iVar11 = (int)(short)local_18;
      pppppcVar21 = DAT_0050b19c[7];
      if (DAT_0050b19c[6] <= (code *****)(iVar11 - (int)pppppcVar21)) {
        pppppcStack_a4 = (code *****)0x4d00c4;
        __vbaGenerateBoundsError();
      }
      pppppcVar23 = (code *****)((int)sVar17 - (int)DAT_0050b19c[5]);
      if (DAT_0050b19c[4] <= pppppcVar23) {
        pppppcStack_a4 = (code *****)0x4d00de;
        __vbaGenerateBoundsError();
      }
      iVar11 = (int)((iVar11 - (int)pppppcVar21) + (int)DAT_0050b19c[6] * (int)pppppcVar23) * 4;
    }
    if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
      pppppcStack_a4 = (code *****)0x4d014c;
      iVar18 = __vbaGenerateBoundsError();
    }
    else {
      iVar18 = (int)(short)local_18;
      pppppcVar21 = DAT_0050b19c[7];
      if (DAT_0050b19c[6] <= (code *****)(iVar18 - (int)pppppcVar21)) {
        pppppcStack_a4 = (code *****)0x4d0119;
        __vbaGenerateBoundsError();
      }
      pppppcVar23 = (code *****)((int)(short)local_30 - (int)DAT_0050b19c[5]);
      if (DAT_0050b19c[4] <= pppppcVar23) {
        pppppcStack_a4 = (code *****)0x4d0134;
        __vbaGenerateBoundsError();
      }
      iVar18 = (int)((iVar18 - (int)pppppcVar21) + (int)DAT_0050b19c[6] * (int)pppppcVar23) * 4;
    }
    *(float *)((int)DAT_0050b19c[3] + iVar18) = *(float *)((int)DAT_0050b19c[3] + iVar11) - local_2c
    ;
    if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004d0287:
      __vbaFPException();
      return;
    }
  }
LAB_004d028c:
  pppppcStack_a4 = (code *****)0x4d0292;
  __vbaErrorOverflow();
  puStack_b0 = (undefined4 *)&DAT_00402706;
  ppsStack_b4 = ExceptionList;
  puStack_ac = &ppppcStack_27c;
  ppsStack_a8 = (short **)&DAT_004023d8;
  ppppppcVar20 = (code ******)0x0;
  ppsStack_b8 = (short **)0x0;
  ppppcStack_cc = (code ****)0x0;
  ppppcStack_d0 = (code ****)0x0;
  ppppcStack_d4 = (code ****)0x0;
  pppppcStack_d8 = (code *****)0x0;
  pppppcStack_dc = (code *****)0x0;
  uStack_e0 = 0;
  uStack_e4 = 0;
  uStack_e8 = 0;
  uStack_ec = 0;
  uStack_f0 = 0;
  uStack_f4 = 0;
  uStack_f8 = 0;
  uStack_fc = 0;
  uStack_100 = 0;
  uStack_104 = 0;
  pppppcStack_108 = (code *****)0x0;
  uStack_10c = 0;
  ppppcStack_11c = (code ****)0x0;
  ppppcStack_12c = (code ****)0x0;
  ppppcStack_13c = (code ****)0x0;
  appppcStack_14c[0] = (code ****)0x0;
  appppcStack_15c[0] = (code ****)0x0;
  appppcStack_16c[0] = (code ****)0x0;
  appppcStack_17c[0] = (code ****)0x0;
  pppppcStack_18c = (code *****)0x0;
  ppppcStack_19c = (code ****)0x0;
  pppppcStack_1ac = (code *****)0x0;
  pppppcStack_1bc = (code *****)0x0;
  ppppcStack_1cc = (code ****)0x0;
  pppppcStack_1f8 = (code *****)0x0;
  ExceptionList = &ppsStack_b4;
  ppppcStack_27c = (code ****)pppppcVar23;
  ppppcStack_278 = (code ****)pppppcVar21;
  pcStack_274 = pcVar19;
  pppppcVar23 = &ppppcStack_27c;
  pppppcStack_a4 = (code *****)&stack0xfffffffc;
  if (DAT_0050b420 == (int *)0x0) {
    piStack_280 = (int *)&DAT_0050b420;
    puStack_284 = &DAT_00408c88;
    puStack_288 = (undefined4 *)0x4d0368;
    ExceptionList = &ppsStack_b4;
    pppppcStack_a4 = (code *****)&stack0xfffffffc;
    __vbaNew2();
    pppppcVar23 = (code *****)puStack_ac;
  }
  puStack_ac = pppppcVar23;
  piStack_280 = DAT_0050b420;
  puStack_284 = (undefined *)0x4d0376;
  puStack_284 = (undefined *)(**(code **)(*DAT_0050b420 + 0x36c))();
  pcVar19 = __vbaObjSet_exref;
  puStack_288 = &uStack_10c;
  uStack_28c = 0x4d0383;
  piVar12 = (int *)__vbaObjSet();
  uStack_28c = 0xffffffff;
  piStack_294 = (int *)0x4d0390;
  piStack_290 = piVar12;
  iVar11 = (**(code **)(*piVar12 + 0x9c))();
  if (iVar11 < 0) {
    piStack_294 = (int *)0x9c;
    puStack_298 = &DAT_0040c3dc;
    uStack_2a4 = 0x4d03a8;
    pppppcStack_2a0 = (code *****)iVar11;
    pppppcStack_29c = (code *****)piVar12;
    __vbaHresultCheckObj();
  }
  piStack_294 = (int *)0x4d03b1;
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    piStack_294 = (int *)&DAT_0050b420;
    puStack_298 = &DAT_00408c88;
    pppppcStack_29c = (code *****)0x4d03ca;
    __vbaNew2();
  }
  piStack_294 = DAT_0050b420;
  puStack_298 = (undefined *)0x4d03d8;
  puStack_298 = (undefined *)(**(code **)(*DAT_0050b420 + 0x3a8))();
  pppppcStack_29c = (code *****)&pppppcStack_1f8;
  pppppcStack_2a0 = (code *****)0x4d03e2;
  __vbaObjSet();
  pcVar5 = __vbaLateIdSt_exref;
  pppppcStack_18c = (code *****)0x3;
  uStack_2ac = 3;
  pppppcStack_184 = (code *****)0x2;
  uStack_2b0 = 7;
  pppppcStack_2a8 = pppppcStack_188;
  pppppcStack_2b4 = pppppcStack_1f8;
  uStack_2a4 = 2;
  pppppcStack_2a0 = pppppcStack_180;
  pppppcStack_2b8 = (code *****)0x4d0425;
  __vbaLateIdSt();
  if (DAT_0050b338 == 1) {
    pppppcStack_2b8 = (code *****)0x4d1268;
    FUN_0044fdc0();
    pcVar19 = __vbaStrMove_exref;
    pppppcStack_2b8 = (code *****)0x4d1275;
    __vbaStrMove();
    pppppcStack_114 = pppppcStack_d8;
    pppppcStack_2bc = &ppppcStack_cc;
    pppppcStack_2b8 = (code *****)DAT_0050b19c;
    pppppcStack_194 = (code *****)0x4133e0;
    ppppcStack_19c = (code ****)0x8;
    pppppcStack_d8 = (code *****)0x0;
    ppppcStack_11c = (code ****)0x8;
    pppppcStack_2c0 = (code *****)0x4d12ab;
    __vbaAryLock();
    if (((code *****)ppppcStack_cc == (code *****)0x0) || (*(short *)ppppcStack_cc != 2)) {
      pppppcStack_2c0 = (code *****)0x4d1310;
      iVar11 = __vbaGenerateBoundsError();
    }
    else {
      ppppcStack_1e4 = (code ****)(1 - (int)ppppcStack_cc[7]);
      if (ppppcStack_cc[6] <= ppppcStack_1e4) {
        pppppcStack_2c0 = (code *****)0x4d12d5;
        __vbaGenerateBoundsError();
      }
      ppppcStack_1e0 = (code ****)-(int)ppppcStack_cc[5];
      if (ppppcStack_cc[4] <= ppppcStack_1e0) {
        pppppcStack_2c0 = (code *****)0x4d12f0;
        __vbaGenerateBoundsError();
      }
      iVar11 = (int)((int)ppppcStack_1e4 + (int)ppppcStack_cc[6] * (int)ppppcStack_1e0) * 4;
    }
    pppppcStack_2c0 = (code *****)&DAT_00000001;
    pppppcStack_184 = (code *****)((int)ppppcStack_cc[3] + iVar11);
    pppppcStack_2c8 = &ppppcStack_11c;
    ppppcStack_2c4 = (code ****)&DAT_00000001;
    pppppcStack_2cc = (code *****)&pppppcStack_18c;
    pppppcStack_2d0 = &ppppcStack_12c;
    pppppcStack_18c = (code *****)0x4004;
    pppppcStack_2d4 = (code *****)0x4d1344;
    Ordinal_660();
    pppppcStack_2d4 = &ppppcStack_cc;
    pppppcStack_2d8 = (code *****)0x4d134e;
    __vbaAryUnlock();
    pppppcStack_2d8 = (code *****)&pppppcStack_1bc;
    pppppcStack_1a4 = (code *****)0x41341c;
    pppppcStack_1ac = (code *****)0x8;
    pppppcStack_1b4 = (code *****)&DAT_0050b244;
    pppppcStack_1bc = (code *****)0x4002;
    pppppcStack_2dc = (code *****)0x4d137f;
    uStack_154 = Ordinal_536();
    pppppcStack_2dc = &ppppcStack_19c;
    pppppcStack_2e0 = &ppppcStack_12c;
    pppppcStack_2e4 = &ppppcStack_13c;
    appppcStack_15c[0] = (code ****)0x8;
    ppppcStack_1cc = (code ****)0x8;
    pwStack_1c4 = L" iterations)";
    pppppcStack_2e8 = (code *****)0x4d13b8;
    pppppcStack_2e8 = (code *****)__vbaVarCat();
    pppppcStack_2ec = (code *****)&pppppcStack_1ac;
    pppppcStack_2f0 = appppcStack_14c;
    pppppcStack_2f4 = (code *****)0x4d13c9;
    pppppcStack_2f4 = (code *****)__vbaVarCat();
    pppppcStack_2f8 = appppcStack_15c;
    pppppcStack_2fc = appppcStack_16c;
    pppppcStack_300 = (code *****)0x4d13da;
    pppppcStack_300 = (code *****)__vbaVarCat();
    pppppcStack_304 = &ppppcStack_1cc;
    pppppcStack_308 = appppcStack_17c;
    pppppcStack_30c = (code *****)0x4d13eb;
    pppppcStack_30c = (code *****)__vbaVarCat();
    pppppcStack_310 = (code *****)0x4d13f2;
    __vbaStrVarMove();
    pppppcStack_310 = (code *****)0x4d13fb;
    __vbaStrMove();
    pppppcStack_310 = (code *****)0x4d1404;
    __vbaFreeStr();
    pppppcStack_310 = appppcStack_17c;
    pppppcStack_314 = appppcStack_16c;
    pppppcStack_318 = appppcStack_15c;
    pppppcStack_31c = appppcStack_14c;
    pppppcStack_320 = &ppppcStack_13c;
    pppppcStack_324 = &ppppcStack_12c;
    pppppcStack_328 = &ppppcStack_11c;
    pppppcStack_32c = (code *****)0x7;
    pppppcStack_330 = (code *****)0x4d143a;
    __vbaFreeVarList();
    pppppcStack_184 = (code *****)0x0;
    pppppcStack_18c = (code *****)0x3;
    pppppcStack_320 = (code *****)0xa;
    pppppcStack_31c = (code *****)0x3;
    pppppcStack_318 = pppppcStack_188;
    pppppcStack_324 = pppppcStack_1f8;
    pppppcStack_314 = (code *****)0x0;
    pppppcStack_310 = pppppcStack_180;
    pppppcStack_328 = (code *****)0x4d1474;
    __vbaLateIdSt();
    ppppppcVar22 = (code ******)0x2;
    ppppppcVar20 = (code ******)0x2;
    uVar9 = CONCAT22(extraout_var_00,DAT_0050b332 + 1);
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    ppppppcVar8 = (code ******)pppppcStack_2c0;
    uVar13 = uStack_204;
    pppppcStack_2cc = pppppcStack_1f8;
    pppppcStack_2c0 = pppppcStack_188;
    sVar17 = DAT_0050b332;
    while (uStack_204 = uVar9, uVar9 = uStack_224, pppppcStack_1f8 = pppppcStack_2cc,
          !SCARRY2(sVar17,1)) {
      sVar17 = (short)ppppppcVar22;
      ppppppcVar20 = ppppppcVar22;
      pcVar6 = pcVar19;
      pppppcStack_188 = pppppcStack_2c0;
      if ((short)uStack_204 < sVar17) goto LAB_004d15a9;
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_2bc = (code *****)(int)sVar17;
      ppppcStack_2c4 = (code ****)0x3;
      pppppcStack_2c8 = (code *****)0xb;
      pppppcStack_2d0 = (code *****)0x4d14d7;
      pppppcStack_184 = pppppcStack_2bc;
      __vbaLateIdSt();
      pppppcStack_18c = (code *****)0x2;
      pppppcStack_2e0 = (code *****)0x28;
      pppppcStack_2dc = (code *****)0x2;
      pppppcStack_184 = (code *****)0x1;
      pppppcStack_2d8 = pppppcStack_188;
      pppppcStack_2e4 = pppppcStack_1f8;
      pppppcStack_2d4 = (code *****)&DAT_00000001;
      pppppcStack_2d0 = pppppcStack_180;
      pppppcStack_2e8 = (code *****)0x4d1514;
      __vbaLateIdSt();
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_2f8 = (code *****)0x27;
      pppppcStack_2f4 = (code *****)0x3;
      pppppcStack_184 = (code *****)0xff0000;
      pppppcStack_2f0 = pppppcStack_188;
      pppppcStack_2fc = pppppcStack_1f8;
      pppppcStack_2ec = (code *****)0xff0000;
      pppppcStack_2e8 = pppppcStack_180;
      pppppcStack_300 = (code *****)0x4d1551;
      __vbaLateIdSt();
      pppppcStack_18c = (code *****)0x3;
      pppppcStack_310 = (code *****)0x26;
      pppppcStack_30c = (code *****)0x3;
      pppppcStack_184 = (code *****)0xffff;
      pppppcStack_308 = pppppcStack_188;
      pppppcStack_314 = pppppcStack_1f8;
      pppppcStack_304 = (code *****)0xffff;
      pppppcStack_300 = pppppcStack_180;
      pppppcStack_318 = (code *****)0x4d158e;
      __vbaLateIdSt();
      ppppppcVar22 = (code ******)(uint)(ushort)(sVar17 + 1);
      uVar9 = uStack_204;
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      ppppppcVar8 = (code ******)pppppcStack_2c0;
      uVar13 = uStack_204;
      pppppcStack_2cc = pppppcStack_1f8;
      pppppcStack_2c0 = pppppcStack_188;
    }
  }
  else {
    pcVar6 = __vbaStrMove_exref;
    ppppppcVar7 = (code ******)pppppcStack_2cc;
    if (DAT_0050b338 == 2) {
      if (DAT_0050b244 < 1) {
        pppppcStack_2b8 = (code *****)0x4d0661;
        __vbaStrCopy();
        pcVar19 = __vbaStrMove_exref;
      }
      else {
        pppppcStack_2b8 = (code *****)0x0;
        pppppcStack_2bc = (code *****)0x4;
        ppppcStack_2c4 = (code ****)&ppppcStack_11c;
        pppppcStack_2c0 = pppppcStack_1f8;
        pppppcStack_2c8 = (code *****)0x4d045b;
        pppppcStack_2b8 = (code *****)__vbaLateIdCallLd();
        pppppcStack_2bc = (code *****)0x4d0465;
        iVar11 = __vbaI4Var();
        ppppppcVar7 = (code ******)pppppcStack_2cc;
        ppppppcVar8 = (code ******)pppppcStack_2c0;
        uVar9 = uStack_224;
        uVar13 = uStack_204;
        if (SCARRY4(iVar11,1)) goto LAB_004d266c;
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_2c8 = (code *****)0x4;
        ppppcStack_2c4 = (code ****)0x3;
        pppppcStack_2c0 = pppppcStack_188;
        pppppcStack_2cc = pppppcStack_1f8;
        pppppcStack_2b8 = pppppcStack_180;
        pppppcStack_2d0 = (code *****)0x4d04a6;
        pppppcStack_2bc = (code *****)(iVar11 + 1);
        pppppcStack_184 = (code *****)(iVar11 + 1);
        __vbaLateIdSt();
        pppppcStack_2d0 = (code *****)0x4d04af;
        __vbaFreeVar();
        if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
          pppppcStack_2d0 = (code *****)0x4d050c;
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          ppppcStack_1e4 = (code ****)-(int)DAT_0050b19c[7];
          if (DAT_0050b19c[6] <= ppppcStack_1e4) {
            pppppcStack_2d0 = (code *****)0x4d04d7;
            __vbaGenerateBoundsError();
          }
          pppppcVar23 = DAT_0050b19c[5];
          if (DAT_0050b19c[4] <= (code *****)-(int)pppppcVar23) {
            pppppcStack_2d0 = (code *****)0x4d04ef;
            __vbaGenerateBoundsError();
          }
          iVar11 = (int)((int)ppppcStack_1e4 + (int)DAT_0050b19c[6] * -(int)pppppcVar23) * 4;
        }
        if (*(float *)((int)DAT_0050b19c[3] + iVar11) == _DAT_00401bc0) {
code_r0x004d25aa:
          pppppcStack_2d0 = (code *****)&LAB_004d265b;
          pppppcStack_2d4 = (code *****)0x4d265a;
          __vbaFreeObj();
          return;
        }
        pppppcStack_2d0 = (code *****)0x4d052e;
        FUN_0044fdc0();
        pcVar19 = __vbaStrMove_exref;
        pppppcStack_2d0 = (code *****)0x4d053b;
        __vbaStrMove();
        pppppcStack_114 = pppppcStack_d8;
        ppppcStack_19c = (code ****)0x8;
        ppppcStack_11c = (code ****)0x8;
        pppppcStack_2d4 = &ppppcStack_cc;
        pppppcStack_2d0 = (code *****)DAT_0050b19c;
        pppppcStack_194 = (code *****)0x41344c;
        pppppcStack_d8 = (code *****)0x0;
        pppppcStack_2d8 = (code *****)0x4d056c;
        __vbaAryLock();
        if (((code *****)ppppcStack_cc == (code *****)0x0) || (*(short *)ppppcStack_cc != 2)) {
          pppppcStack_2d8 = (code *****)0x4d05c0;
          iVar11 = __vbaGenerateBoundsError();
        }
        else {
          ppppcStack_1e4 = (code ****)-(int)ppppcStack_cc[7];
          if (ppppcStack_cc[6] <= ppppcStack_1e4) {
            pppppcStack_2d8 = (code *****)0x4d0591;
            __vbaGenerateBoundsError();
          }
          ppppppcVar20 = (code ******)-(int)ppppcStack_cc[5];
          if (ppppcStack_cc[4] <= ppppppcVar20) {
            pppppcStack_2d8 = (code *****)0x4d05a6;
            __vbaGenerateBoundsError();
          }
          iVar11 = (int)((int)ppppcStack_1e4 + (int)ppppcStack_cc[6] * (int)ppppppcVar20) * 4;
        }
        pppppcStack_2d8 = (code *****)&DAT_00000001;
        pppppcStack_184 = (code *****)((int)ppppcStack_cc[3] + iVar11);
        pppppcStack_2e0 = &ppppcStack_11c;
        pppppcStack_2dc = (code *****)&DAT_00000001;
        pppppcStack_2e4 = (code *****)&pppppcStack_18c;
        pppppcStack_2e8 = &ppppcStack_12c;
        pppppcStack_18c = (code *****)0x4004;
        pppppcStack_2ec = (code *****)0x4d05f4;
        Ordinal_660();
        pppppcStack_2ec = &ppppcStack_cc;
        pppppcStack_2f0 = (code *****)0x4d05fe;
        __vbaAryUnlock();
        pppppcStack_2f0 = &ppppcStack_19c;
        pppppcStack_2f4 = &ppppcStack_12c;
        pppppcStack_2f8 = &ppppcStack_13c;
        pppppcStack_2fc = (code *****)0x4d0619;
        pppppcStack_2fc = (code *****)__vbaVarCat();
        pppppcStack_300 = (code *****)0x4d0620;
        __vbaStrVarMove();
        pppppcStack_300 = (code *****)0x4d0629;
        __vbaStrMove();
        pppppcStack_300 = (code *****)0x4d0632;
        __vbaFreeStr();
        pppppcStack_300 = &ppppcStack_13c;
        pppppcStack_304 = &ppppcStack_12c;
        pppppcStack_308 = &ppppcStack_11c;
        pppppcStack_30c = (code *****)0x3;
        pppppcStack_310 = (code *****)0x4d064c;
        __vbaFreeVarList();
      }
      pppppcStack_300 = (code *****)0x0;
      pppppcStack_304 = (code *****)0x4;
      pppppcStack_30c = &ppppcStack_11c;
      pppppcStack_308 = pppppcStack_1f8;
      pppppcStack_310 = (code *****)0x4d067c;
      pppppcStack_300 = (code *****)__vbaLateIdCallLd();
      pppppcStack_304 = (code *****)0x4d0686;
      iVar11 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      ppppppcVar8 = (code ******)pppppcStack_2c0;
      uVar9 = uStack_224;
      uVar13 = uStack_204;
      if (!SBORROW4(iVar11,1)) {
        pppppcStack_2b8 = (code *****)0x4d0697;
        uVar13 = __vbaI2I4();
        pppppcStack_2b8 = (code *****)0x4d06a5;
        uStack_c4 = uVar13;
        __vbaFreeVar();
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_2bc = (code *****)(int)(short)uVar13;
        ppppcStack_2c4 = (code ****)0x3;
        pppppcStack_2c8 = (code *****)0xa;
        pppppcStack_2c0 = pppppcStack_188;
        pppppcStack_2cc = pppppcStack_1f8;
        pppppcStack_2b8 = pppppcStack_180;
        pppppcStack_2d0 = (code *****)0x4d06e0;
        pppppcStack_184 = pppppcStack_2bc;
        __vbaLateIdSt();
        uStack_208 = 1;
        ppppppcVar22 = (code ******)0x0;
        do {
          ppppppcVar20 = ppppppcVar22;
          sVar17 = (short)ppppppcVar20;
          if (1 < sVar17) {
            ppppppcVar20 = (code ******)0x2;
            ppppppcVar22 = ppppppcVar20;
            ppppppcVar7 = (code ******)pppppcStack_2cc;
            ppppppcVar8 = (code ******)pppppcStack_2c0;
            uVar9 = uStack_224;
            uVar10 = (uint)(ushort)(DAT_0050b332 + 1);
            uVar13 = uStack_204;
            if (!SCARRY2(DAT_0050b332,1)) goto LAB_004d07a4;
            break;
          }
          pppppcStack_18c = (code *****)0x3;
          pppppcStack_2bc = (code *****)(int)sVar17;
          ppppcStack_2c4 = (code ****)0x3;
          pppppcStack_2c8 = (code *****)0xb;
          pppppcStack_2c0 = pppppcStack_188;
          pppppcStack_2cc = pppppcStack_1f8;
          pppppcStack_2b8 = pppppcStack_180;
          pppppcStack_2d0 = (code *****)0x4d0735;
          pppppcStack_184 = pppppcStack_2bc;
          __vbaLateIdSt();
          pppppcStack_18c = (code *****)0x3;
          pppppcStack_2e0 = (code *****)0x26;
          pppppcStack_2dc = (code *****)0x3;
          pppppcStack_184 = (code *****)0xffff;
          pppppcStack_2d8 = pppppcStack_188;
          pppppcStack_2e4 = pppppcStack_1f8;
          pppppcStack_2d4 = (code *****)0xffff;
          pppppcStack_2d0 = pppppcStack_180;
          pppppcStack_2e8 = (code *****)0x4d0772;
          __vbaLateIdSt();
          ppppppcVar22 = (code ******)CONCAT22(extraout_var_03,(short)uStack_208 + sVar17);
          ppppppcVar7 = (code ******)pppppcStack_2cc;
          ppppppcVar8 = (code ******)pppppcStack_2c0;
          uVar9 = uStack_224;
          uVar13 = uStack_204;
        } while (!SCARRY2((short)uStack_208,sVar17));
      }
    }
    else {
LAB_004d15a9:
      pppppcStack_2cc = (code *****)ppppppcVar7;
      pcVar19 = pcVar6;
      pppppcStack_2b8 = (code *****)0x0;
      pppppcStack_2bc = (code *****)0x4;
      ppppcStack_2c4 = (code ****)&ppppcStack_11c;
      pppppcStack_2c0 = pppppcStack_1f8;
      pppppcStack_2c8 = (code *****)0x4d15be;
      pppppcStack_2b8 = (code *****)__vbaLateIdCallLd();
      pppppcStack_2bc = (code *****)0x4d15c8;
      iVar11 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_2cc;
      ppppppcVar8 = (code ******)pppppcStack_2c0;
      uVar9 = uStack_224;
      uVar13 = uStack_204;
      if (!SBORROW4(iVar11,1)) {
        pppppcStack_2b8 = (code *****)0x4d15d9;
        sVar17 = __vbaI2I4();
        pppppcStack_2b8 = (code *****)0x4d15e4;
        __vbaFreeVar();
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_2bc = (code *****)(int)sVar17;
        ppppcStack_2c4 = (code ****)0x3;
        pppppcStack_2c0 = pppppcStack_188;
        pppppcStack_2c8 = (code *****)0xa;
        pppppcStack_2cc = pppppcStack_1f8;
        pppppcStack_2b8 = pppppcStack_180;
        pppppcStack_2d0 = (code *****)0x4d1625;
        pppppcStack_270 = pppppcStack_2bc;
        pppppcStack_184 = pppppcStack_2bc;
        __vbaLateIdSt();
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_2e0 = (code *****)0xb;
        pppppcStack_2dc = (code *****)0x3;
        pppppcStack_184 = (code *****)0x0;
        pppppcStack_2d8 = pppppcStack_188;
        pppppcStack_2e4 = pppppcStack_1f8;
        pppppcStack_2d4 = (code *****)0x0;
        pppppcStack_2d0 = pppppcStack_180;
        pppppcStack_2e8 = (code *****)0x4d165f;
        __vbaLateIdSt();
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_2f8 = (code *****)0x27;
        pppppcStack_2f4 = (code *****)0x3;
        pppppcStack_184 = (code *****)0xff0000;
        pppppcStack_2f0 = pppppcStack_188;
        pppppcStack_2fc = pppppcStack_1f8;
        pppppcStack_2ec = (code *****)0xff0000;
        pppppcStack_2e8 = pppppcStack_180;
        pppppcStack_300 = (code *****)0x4d169c;
        __vbaLateIdSt();
        pppppcStack_18c = (code *****)0x3;
        pppppcStack_310 = (code *****)0x26;
        pppppcStack_30c = (code *****)0x3;
        pppppcStack_184 = (code *****)0xffff00;
        pppppcStack_308 = pppppcStack_188;
        pppppcStack_314 = pppppcStack_1f8;
        pppppcStack_304 = (code *****)0xffff00;
        pppppcStack_300 = pppppcStack_180;
        pppppcStack_318 = (code *****)0x4d16d9;
        __vbaLateIdSt();
        ppppppcVar22 = (code ******)0x2;
        ppppppcVar20 = (code ******)0x2;
        uVar13 = CONCAT22(extraout_var_01,DAT_0050b332 + 1);
        ppppppcVar7 = (code ******)pppppcStack_2cc;
        ppppppcVar8 = (code ******)pppppcStack_2c0;
        uVar9 = uStack_224;
        pppppcStack_2cc = pppppcStack_1f8;
        pppppcStack_2c0 = pppppcStack_188;
        sVar17 = DAT_0050b332;
        while (uStack_224 = uVar13, ppppppcVar4 = ppppppcVar22, uVar13 = uStack_204,
              pppppcStack_1f8 = pppppcStack_2cc, !SCARRY2(sVar17,1)) {
          sVar17 = (short)ppppppcVar4;
          pppppcStack_188 = pppppcStack_2c0;
          if ((short)uStack_224 < sVar17) {
            pppppcStack_18c = (code *****)0x3;
            pppppcStack_2c8 = (code *****)0x30;
            ppppcStack_2c4 = (code ****)0x3;
            pppppcStack_184 = (code *****)0x2;
            pppppcStack_2bc = (code *****)0x2;
            pppppcStack_2d0 = (code *****)0x4d18d1;
            __vbaLateIdSt();
            pppppcStack_18c = (code *****)0x3;
            pppppcStack_184 = pppppcStack_270;
            pppppcStack_2dc = (code *****)0x3;
            pppppcStack_1ac = (code *****)0xb;
            pppppcStack_2d8 = pppppcStack_188;
            pppppcStack_2f0 = (code *****)&DAT_00000001;
            pppppcStack_2d4 = pppppcStack_270;
            pppppcStack_1a4 = (code *****)0xffffffff;
            pppppcStack_2f4 = (code *****)0x3b;
            pppppcStack_2d0 = pppppcStack_180;
            pppppcStack_2ec = (code *****)0xb;
            pppppcStack_2e8 = pppppcStack_1a8;
            pppppcStack_2f8 = pppppcStack_1f8;
            pppppcStack_2e4 = (code *****)0xffffffff;
            pppppcStack_2e0 = pppppcStack_1a0;
            pppppcStack_2fc = (code *****)0x4d194a;
            __vbaLateIdCallSt();
            ppsVar14 = (short **)0x0;
            goto LAB_004d194f;
          }
          pppppcStack_18c = (code *****)0x3;
          pppppcStack_2bc = (code *****)(int)sVar17;
          ppppcStack_2c4 = (code ****)0x3;
          pppppcStack_2c8 = (code *****)0xb;
          pppppcStack_2d0 = (code *****)0x4d173c;
          pppppcStack_184 = pppppcStack_2bc;
          __vbaLateIdSt();
          pppppcStack_18c = (code *****)0x2;
          pppppcStack_2e0 = (code *****)0x28;
          pppppcStack_2dc = (code *****)0x2;
          pppppcStack_184 = (code *****)0x1;
          pppppcStack_2d8 = pppppcStack_188;
          pppppcStack_2e4 = pppppcStack_1f8;
          pppppcStack_2d4 = (code *****)&DAT_00000001;
          pppppcStack_2d0 = pppppcStack_180;
          pppppcStack_2e8 = (code *****)0x4d1779;
          __vbaLateIdSt();
          pppppcStack_2ec = (code *****)0x41100000;
          if (DAT_0050b338 != 1) {
            pppppcStack_2ec = (code *****)0x40f00000;
          }
          pppppcStack_18c = (code *****)0x4;
          pppppcStack_2f8 = (code *****)0x4e;
          pppppcStack_2f4 = (code *****)0x4;
          pppppcStack_2f0 = pppppcStack_188;
          pppppcStack_2fc = pppppcStack_1f8;
          pppppcStack_2e8 = pppppcStack_180;
          pppppcStack_300 = (code *****)0x4d17c5;
          pppppcStack_184 = pppppcStack_2ec;
          __vbaLateIdSt();
          pppppcStack_314 = (code *****)(int)sVar17;
          pppppcStack_184 = pppppcStack_270;
          pppppcStack_18c = (code *****)0x3;
          pppppcStack_1ac = (code *****)0x3;
          pppppcStack_30c = (code *****)0x3;
          ppppcStack_1cc = (code ****)0x4008;
          pppppcStack_308 = pppppcStack_188;
          pwStack_1c4 = (wchar_t *)&DAT_0050b34c;
          pppppcStack_304 = pppppcStack_270;
          pppppcStack_300 = pppppcStack_180;
          pppppcStack_31c = (code *****)0x3;
          pppppcStack_318 = pppppcStack_1a8;
          pppppcStack_310 = pppppcStack_1a0;
          pppppcStack_330 = (code *****)0x2;
          pppppcStack_334 = (code *****)0x41;
          pppppcStack_32c = (code *****)0x4008;
          pppppcStack_328 = pppppcStack_1c8;
          pppppcStack_324 = (code *****)&DAT_0050b34c;
          pppppcStack_320 = pppppcStack_1c0;
          pppppcStack_338 = pppppcStack_1f8;
          pppppcStack_33c = (code *****)0x4d187c;
          pppppcStack_1a4 = pppppcStack_314;
          __vbaLateIdCallSt();
          ppppppcVar22 = (code ******)(uint)(ushort)(sVar17 + 1);
          ppppppcVar20 = ppppppcVar4;
          uVar13 = uStack_224;
          ppppppcVar7 = (code ******)pppppcStack_2cc;
          ppppppcVar8 = (code ******)pppppcStack_2c0;
          uVar9 = uStack_224;
          pppppcStack_2cc = pppppcStack_1f8;
          pppppcStack_2c0 = pppppcStack_188;
        }
      }
    }
  }
LAB_004d266c:
  uStack_204 = uVar13;
  uStack_224 = uVar9;
  pppppcStack_2c0 = (code *****)ppppppcVar8;
  pppppcStack_2cc = (code *****)ppppppcVar7;
  pppppcStack_2b8 = (code *****)0x4d2672;
  __vbaErrorOverflow();
  ppppcStack_2c4 = (code ****)&DAT_00402706;
  pppppcStack_2c8 = ExceptionList;
  pcStack_354 = pcVar5;
  pppppcStack_2c0 = (code *****)&pcStack_358;
  pppppcStack_2bc = (code *****)&DAT_004023e8;
  pppppcStack_2d4 = (code *****)0x0;
  pppppcStack_2d8 = (code *****)0x0;
  pppppcStack_2dc = (code *****)0x0;
  pppppcStack_300 = (code *****)0x0;
  pppppcStack_304 = (code *****)0x0;
  pppppcStack_308 = (code *****)0x0;
  pppppcStack_30c = (code *****)0x0;
  pppppcStack_330 = (code *****)0x0;
  ExceptionList = &pppppcStack_2c8;
  pcStack_358 = pcVar19;
  pppppcStack_350 = (code *****)ppppppcVar20;
  pppppcVar23 = (code *****)&pcStack_358;
  pppppcStack_2b8 = (code *****)&pppppcStack_a4;
  if (DAT_0050b420 == (int *)0x0) {
    ExceptionList = &pppppcStack_2c8;
    pppppcStack_2b8 = (code *****)&pppppcStack_a4;
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    pppppcVar23 = pppppcStack_2c0;
  }
  pppppcStack_2c0 = pppppcVar23;
  __vbaObjSetAddref(&pppppcStack_330,DAT_0050b420);
  uVar13 = (*(code *)(*pppppcStack_330)[0xdf])(pppppcStack_330);
  piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
  iVar11 = (**(code **)(*piVar12 + 0x9c))(piVar12,0);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_330)[0xd9])(pppppcStack_330);
  piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
  iVar11 = (**(code **)(*piVar12 + 0x9c))(piVar12,0xffffffff);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_330)[0xdb])(pppppcStack_330);
  piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
  iVar11 = (**(code **)(*piVar12 + 0x9c))(piVar12,0);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_330)[0xd3])(pppppcStack_330);
  piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
  iVar11 = (**(code **)(*piVar12 + 0x9c))(piVar12,0);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_330)[0xda])(pppppcStack_330);
  piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
  iVar11 = (**(code **)(*piVar12 + 0xe8))(piVar12,&pppppcStack_300);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040dc58,0xe8);
  }
  bVar24 = (short)pppppcStack_300 == 0;
  __vbaFreeObj();
  ppppppcVar22 = (code ******)pppppcStack_2e0;
  ppppppcVar20 = (code ******)pppppcStack_2e8;
  if (bVar24) {
    uVar13 = (*(code *)(*pppppcStack_330)[0xda])(pppppcStack_330);
    puVar15 = (undefined4 *)__vbaObjSet(&pppppcStack_2d4,uVar13);
    ppppppcVar22 = (code ******)pppppcStack_2e0;
    ppppppcVar20 = (code ******)pppppcStack_2e8;
    pppppcStack_338 = (code *****)*puVar15;
    iVar11 = (*(code *)pppppcStack_338[0x7b])
                       (puVar15,L"Maximum flows",10,pppppcStack_2e8,0x80020004,pppppcStack_2e0);
    if (iVar11 < 0) {
      __vbaHresultCheckObj(iVar11,puVar15,&DAT_0040dc58,0x1ec);
    }
    __vbaFreeObj();
    uVar13 = (*(code *)(*pppppcStack_330)[0xda])(pppppcStack_330);
    piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
    pppppcStack_2e4 = (code *****)0x80020004;
    iVar11 = (**(code **)(*piVar12 + 0x1ec))
                       (piVar12,L"Iterations",10,ppppppcVar20,0x80020004,ppppppcVar22);
    if (iVar11 < 0) {
      __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040dc58,0x1ec);
    }
    __vbaFreeObj();
  }
  uVar13 = (*(code *)(*pppppcStack_330)[0xea])
                     (pppppcStack_330,0x80010007,0xb,ppppppcVar20,0,ppppppcVar22);
  uVar13 = __vbaObjSet(&pppppcStack_2d4,uVar13);
  __vbaLateIdSt(uVar13);
  __vbaFreeObj();
  iVar11 = (*(code *)(*pppppcStack_330)[0x92])(pppppcStack_330,&pppppcStack_2d4);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_2d4,0,8,ppppppcVar20,L"arial",ppppppcVar22);
  __vbaFreeObj();
  iVar11 = (*(code *)(*pppppcStack_330)[0x92])(pppppcStack_330,&pppppcStack_2d4);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_2d4,2,2,ppppppcVar20,6,ppppppcVar22);
  __vbaFreeObj();
  iVar11 = (*(code *)(*pppppcStack_330)[0x1b])(pppppcStack_330,0xffffff);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x6c);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  __vbaObjSetAddref(&pppppcStack_2d4,DAT_0050b420);
  FUN_0048c990(&pppppcStack_2d4);
  uVar13 = __vbaCastObj(pppppcStack_2d4,&DAT_0040b85c);
  __vbaObjSet(&DAT_0050b420,uVar13);
  __vbaFreeObj();
  iVar11 = (*(code *)(*pppppcStack_330)[0x92])(pppppcStack_330,&pppppcStack_2d4);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_2d4,3,0xb,ppppppcVar20,0xffffffff,ppppppcVar22);
  __vbaFreeObj();
  pppppcStack_2e4 = (code *****)0xa;
  iVar11 = (*(code *)(*pppppcStack_330)[0x92])(pppppcStack_330,&pppppcStack_2d4);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_2d4,2,2,ppppppcVar20,pppppcStack_2e4,ppppppcVar22);
  __vbaFreeObj();
  pppppcStack_2ec = (code *****)0xb;
  iVar11 = (*(code *)(*pppppcStack_330)[0x92])(pppppcStack_330,&pppppcStack_2d4);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_2d4,3,pppppcStack_2ec,ppppppcVar20,0xffffffff,ppppppcVar22);
  __vbaFreeObj();
  iVar11 = (*(code *)(*pppppcStack_330)[0x4b])(pppppcStack_330,1);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,300);
  }
  __vbaStrCopy();
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar12 = DAT_0050c53c;
  iVar11 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_2d4);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040b410,0x18);
  }
  pppppcVar23 = pppppcStack_2d4;
  iVar11 = (*(code *)(*pppppcStack_2d4)[0x26])(pppppcStack_2d4,&pppppcStack_304);
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcVar23,&DAT_0040bb5c,0x98);
  }
  iVar11 = (*(code *)(*pppppcStack_330)[0xb9])(pppppcStack_330,DAT_0050b34c,&pppppcStack_308);
  uVar25 = 0;
  if (iVar11 < 0) {
    __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0x2e4);
  }
  if ((uVar25 & 0xd) == 0) {
    ppppppcVar20 = (code ******)
                   (((float)pppppcStack_304 - (float)pppppcStack_308) * (float)_DAT_00401268);
    if ((uVar25 & 0xd) == 0) {
      pppppcStack_33c = (code *****)ppppppcVar20;
      iVar11 = (*(code *)(*pppppcStack_330)[0x39])(pppppcStack_330,ppppppcVar20);
      if (iVar11 < 0) {
        __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0xe4);
      }
      __vbaFreeObj();
      if (DAT_0050b420 == (int *)0x0) {
        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      }
      __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,DAT_0050b34c);
      iVar11 = (*(code *)(*pppppcStack_330)[0x3a])(pppppcStack_330,&pppppcStack_304);
      if (iVar11 < 0) {
        __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0xe8);
      }
      if (DAT_0050c53c == (int *)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      piVar12 = DAT_0050c53c;
      iVar11 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_2d4);
      if (iVar11 < 0) {
        __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040b410,0x18);
      }
      pppppcVar23 = pppppcStack_2d4;
      iVar11 = (*(code *)(*pppppcStack_2d4)[0x26])(pppppcStack_2d4,&pppppcStack_308);
      if (iVar11 < 0) {
        __vbaHresultCheckObj(iVar11,pppppcVar23,&DAT_0040bb5c,0x98);
      }
      iVar11 = (*(code *)(*pppppcStack_330)[0x3a])(pppppcStack_330,&pppppcStack_30c);
      uVar25 = 0;
      if (iVar11 < 0) {
        __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0xe8);
      }
      if (DAT_0050b420 == (int *)0x0) {
        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      }
      piVar12 = DAT_0050b420;
      if ((uVar25 & 0xd) == 0) {
        iVar11 = (**(code **)(*DAT_0050b420 + 0x2c8))
                           (DAT_0050b420,4,0x44960000,pppppcStack_304,
                            (float)pppppcStack_308 - _DAT_004020e0,pppppcStack_30c,0);
        if (iVar11 < 0) {
          __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040b430,0x2c8);
        }
        __vbaFreeObj();
        iVar11 = (*(code *)(*pppppcStack_330)[0x3a])(pppppcStack_330,&pppppcStack_304);
        uVar25 = 0;
        if (iVar11 < 0) {
          __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0xe8);
        }
        uVar13 = (*(code *)(*pppppcStack_330)[0xd9])(pppppcStack_330);
        piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
        puVar27 = (undefined *)((float)pppppcStack_304 * (float)_DAT_00401280);
        if ((uVar25 & 0xd) == 0) {
          puStack_340 = puVar27;
          iVar11 = (**(code **)(*piVar12 + 0x7c))(piVar12,puVar27);
          if (iVar11 < 0) {
            __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x7c);
          }
          __vbaFreeObj();
          if (DAT_0050c53c == (int *)0x0) {
            __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
          }
          piVar12 = DAT_0050c53c;
          iVar11 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_2d4);
          if (iVar11 < 0) {
            __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040b410,0x18);
          }
          pppppcVar23 = pppppcStack_2d4;
          iVar11 = (*(code *)(*pppppcStack_2d4)[0x26])(pppppcStack_2d4,&pppppcStack_304);
          if (iVar11 < 0) {
            __vbaHresultCheckObj(iVar11,pppppcVar23,&DAT_0040bb5c,0x98);
          }
          uVar13 = (*(code *)(*pppppcStack_330)[0xd9])(pppppcStack_330);
          piVar12 = (int *)__vbaObjSet(&pppppcStack_2d8,uVar13);
          iVar11 = (**(code **)(*piVar12 + 0x80))(piVar12,&pppppcStack_308);
          uVar25 = 0;
          if (iVar11 < 0) {
            __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x80);
          }
          uVar13 = (*(code *)(*pppppcStack_330)[0xd9])(pppppcStack_330);
          piVar12 = (int *)__vbaObjSet(&pppppcStack_2dc,uVar13);
          if ((uVar25 & 0xd) == 0) {
            ppppppcVar20 = (code ******)
                           (((float)pppppcStack_304 - (float)pppppcStack_308) * (float)_DAT_00401268
                           );
            if ((uVar25 & 0xd) == 0) {
              pppppcStack_344 = (code *****)ppppppcVar20;
              iVar11 = (**(code **)(*piVar12 + 0x74))(piVar12,puVar27,ppppppcVar20);
              if (iVar11 < 0) {
                __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x74);
              }
              __vbaFreeObjList(3,&pppppcStack_2d4,&pppppcStack_2d8,&pppppcStack_2dc);
              iVar11 = (*(code *)(*pppppcStack_330)[0x3a])(pppppcStack_330,&pppppcStack_304);
              uVar25 = 0;
              if (iVar11 < 0) {
                __vbaHresultCheckObj(iVar11,pppppcStack_330,&DAT_0040b430,0xe8);
              }
              if ((uVar25 & 0xd) == 0) {
                DAT_0050b32e = __vbaFpI2();
                __vbaObjSetAddref(&pppppcStack_330,0);
                if (DAT_0050c53c == (int *)0x0) {
                  __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                }
                piVar12 = DAT_0050c53c;
                iVar11 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_2d4);
                if (iVar11 < 0) {
                  __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040b410,0x18);
                }
                pppppcVar23 = pppppcStack_2d4;
                iVar11 = (*(code *)(*pppppcStack_2d4)[0x14])(pppppcStack_2d4,&pppppcStack_304);
                uVar25 = 0;
                if (iVar11 < 0) {
                  __vbaHresultCheckObj(iVar11,pppppcVar23,&DAT_0040bb5c,0x50);
                }
                if (DAT_0050b420 == (int *)0x0) {
                  __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                }
                uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                piVar12 = (int *)__vbaObjSet(&pppppcStack_2d8,uVar13);
                ppppppcVar20 = (code ******)((float)pppppcStack_304 * (float)_DAT_00401730);
                if ((uVar25 & 0xd) == 0) {
                  pppppcStack_348 = (code *****)ppppppcVar20;
                  iVar11 = (**(code **)(*piVar12 + 0x7c))(piVar12,ppppppcVar20);
                  if (iVar11 < 0) {
                    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x7c);
                  }
                  __vbaFreeObjList(2,&pppppcStack_2d4,&pppppcStack_2d8);
                  if (DAT_0050c53c == (int *)0x0) {
                    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                  }
                  piVar12 = DAT_0050c53c;
                  iVar11 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_2d4);
                  if (iVar11 < 0) {
                    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040b410,0x18);
                  }
                  pppppcVar23 = pppppcStack_2d4;
                  iVar11 = (*(code *)(*pppppcStack_2d4)[0x26])(pppppcStack_2d4,&pppppcStack_304);
                  if (iVar11 < 0) {
                    __vbaHresultCheckObj(iVar11,pppppcVar23,&DAT_0040bb5c,0x98);
                  }
                  if (DAT_0050b420 == (int *)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                  piVar12 = (int *)__vbaObjSet(&pppppcStack_2d8,uVar13);
                  iVar11 = (**(code **)(*piVar12 + 0x80))(piVar12,&pppppcStack_308);
                  uVar25 = 0;
                  if (iVar11 < 0) {
                    __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x80);
                  }
                  if (DAT_0050b420 == (int *)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                  piVar12 = (int *)__vbaObjSet(&pppppcStack_2dc,uVar13);
                  if ((uVar25 & 0xd) == 0) {
                    fVar3 = ((float)pppppcStack_304 - (float)pppppcStack_308) * (float)_DAT_00401268
                    ;
                    if ((uVar25 & 0xd) == 0) {
                      puStack_34c = (undefined4 *)fVar3;
                      iVar11 = (**(code **)(*piVar12 + 0x74))(piVar12,ppppppcVar20,fVar3);
                      if (iVar11 < 0) {
                        __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x74);
                      }
                      __vbaFreeObjList(3,&pppppcStack_2d4,&pppppcStack_2d8,&pppppcStack_2dc);
                      if (DAT_0050b420 == (int *)0x0) {
                        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                      }
                      uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                      piVar12 = (int *)__vbaObjSet(&pppppcStack_2d4,uVar13);
                      iVar11 = (**(code **)(*piVar12 + 0x9c))(piVar12,0xffffffff);
                      if (iVar11 < 0) {
                        __vbaHresultCheckObj(iVar11,piVar12,&DAT_0040c3dc,0x9c);
                      }
                      __vbaFreeObj();
                      __vbaFreeObj(&LAB_004d3292);
                      return;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __vbaFPException();
  return;
}


