/* entry 004bf9b0 name FUN_004bf9b0 size 3298 */
/* strings:
 * Shortest routes
 *  DIJKSTRA'S SHORTEST ROUTE ALGORITHM
 * FLOYD'S SHORTEST ROUTE ALGORITHM
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf9b0(void)

{
  undefined1 *puVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  bool bVar5;
  ushort uVar6;
  float fVar7;
  int *local_7c [9];
  undefined4 local_58;
  float local_54;
  float local_50;
  undefined4 local_4c [5];
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  int *local_20 [3];
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff58;
  local_8 = &DAT_00402330;
  local_20[0] = (int *)0x0;
  local_24 = 0;
  local_28 = 0;
  local_4c[0] = 0;
  local_50 = 0.0;
  local_54 = 0.0;
  local_58 = 0;
  local_7c[0] = (int *)0x0;
  ExceptionList = &pvStack_14;
  puVar1 = &stack0xffffff58;
  if (DAT_0050b420 == (int *)0x0) {
    ExceptionList = &pvStack_14;
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    puVar1 = local_c;
  }
  local_c = puVar1;
  __vbaObjSetAddref(local_7c,DAT_0050b420);
  uVar2 = (**(code **)(*local_7c[0] + 0x37c))(local_7c[0]);
  piVar3 = (int *)__vbaObjSet(local_20,uVar2);
  iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar2 = (**(code **)(*local_7c[0] + 0x364))(local_7c[0]);
  piVar3 = (int *)__vbaObjSet(local_20,uVar2);
  iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0xffffffff);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar2 = (**(code **)(*local_7c[0] + 0x36c))(local_7c[0]);
  piVar3 = (int *)__vbaObjSet(local_20,uVar2);
  iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar2 = (**(code **)(*local_7c[0] + 0x34c))(local_7c[0]);
  piVar3 = (int *)__vbaObjSet(local_20,uVar2);
  iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar2 = (**(code **)(*local_7c[0] + 0x3a8))(local_7c[0],0x80010007,0xb,local_34,0,local_2c);
  uVar2 = __vbaObjSet(local_20,uVar2);
  __vbaLateIdSt(uVar2);
  __vbaFreeObj();
  uVar2 = (**(code **)(*local_7c[0] + 0x368))(local_7c[0]);
  piVar3 = (int *)__vbaObjSet(local_20,uVar2);
  iVar4 = (**(code **)(*piVar3 + 0xe8))(piVar3,local_4c);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040dc58,0xe8);
  }
  bVar5 = (short)local_4c[0] == 0;
  __vbaFreeObj();
  if (bVar5) {
    uVar2 = (**(code **)(*local_7c[0] + 0x368))(local_7c[0]);
    piVar3 = (int *)__vbaObjSet(local_20,uVar2);
    iVar4 = (**(code **)(*piVar3 + 0x1ec))
                      (piVar3,L"Shortest routes",10,local_34,0x80020004,local_2c);
    if (iVar4 < 0) {
      __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040dc58,0x1ec);
    }
    __vbaFreeObj();
    uVar2 = (**(code **)(*local_7c[0] + 0x368))(local_7c[0]);
    piVar3 = (int *)__vbaObjSet(local_20,uVar2);
    local_30 = 0x80020004;
    iVar4 = (**(code **)(*piVar3 + 0x1ec))(piVar3,L"Iterations",10,local_34,0x80020004,local_2c);
    if (iVar4 < 0) {
      __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040dc58,0x1ec);
    }
    __vbaFreeObj();
  }
  uVar2 = (**(code **)(*local_7c[0] + 0x3a8))(local_7c[0],0x80010007,0xb,local_34,0,local_2c);
  uVar2 = __vbaObjSet(local_20,uVar2);
  __vbaLateIdSt(uVar2);
  __vbaFreeObj();
  iVar4 = (**(code **)(*local_7c[0] + 0x248))(local_7c[0],local_20);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_20[0],0,8,local_34,L"arial",local_2c);
  __vbaFreeObj();
  iVar4 = (**(code **)(*local_7c[0] + 0x248))(local_7c[0],local_20);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_20[0],2,2,local_34,6,local_2c);
  __vbaFreeObj();
  iVar4 = (**(code **)(*local_7c[0] + 0x6c))(local_7c[0],0xffffff);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x6c);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  __vbaObjSetAddref(local_20,DAT_0050b420);
  FUN_0048c990(local_20);
  uVar2 = __vbaCastObj(local_20[0],&DAT_0040b85c);
  __vbaObjSet(&DAT_0050b420,uVar2);
  __vbaFreeObj();
  iVar4 = (**(code **)(*local_7c[0] + 0x248))(local_7c[0],local_20);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_20[0],3,0xb,local_34,0xffffffff,local_2c);
  __vbaFreeObj();
  local_30 = 10;
  iVar4 = (**(code **)(*local_7c[0] + 0x248))(local_7c[0],local_20);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_20[0],2,2,local_34,local_30,local_2c);
  __vbaFreeObj();
  local_38 = 0xb;
  iVar4 = (**(code **)(*local_7c[0] + 0x248))(local_7c[0],local_20);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_20[0],3,local_38,local_34,0xffffffff,local_2c);
  __vbaFreeObj();
  iVar4 = (**(code **)(*local_7c[0] + 300))(local_7c[0],1);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,300);
  }
  if ((DAT_0050b334 == 2) || (DAT_0050b334 == 3)) {
    __vbaStrCopy();
  }
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar3 = DAT_0050c53c;
  iVar4 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,local_20);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040b410,0x18);
  }
  piVar3 = local_20[0];
  iVar4 = (**(code **)(*local_20[0] + 0x98))(local_20[0],&local_50);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040bb5c,0x98);
  }
  iVar4 = (**(code **)(*local_7c[0] + 0x2e4))(local_7c[0],DAT_0050b34c,&local_54);
  uVar6 = 0;
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0x2e4);
  }
  if ((uVar6 & 0xd) == 0) {
    if ((uVar6 & 0xd) == 0) {
      iVar4 = (**(code **)(*local_7c[0] + 0xe4))
                        (local_7c[0],(local_50 - local_54) * (float)_DAT_00401268);
      if (iVar4 < 0) {
        __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0xe4);
      }
      __vbaFreeObj();
      if (DAT_0050b420 == (int *)0x0) {
        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      }
      __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,DAT_0050b34c);
      iVar4 = (**(code **)(*local_7c[0] + 0xe8))(local_7c[0],&local_50);
      if (iVar4 < 0) {
        __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0xe8);
      }
      if (DAT_0050c53c == (int *)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      piVar3 = DAT_0050c53c;
      iVar4 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,local_20);
      if (iVar4 < 0) {
        __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040b410,0x18);
      }
      piVar3 = local_20[0];
      iVar4 = (**(code **)(*local_20[0] + 0x98))(local_20[0],&local_54);
      if (iVar4 < 0) {
        __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040bb5c,0x98);
      }
      iVar4 = (**(code **)(*local_7c[0] + 0xe8))(local_7c[0],&local_58);
      uVar6 = 0;
      if (iVar4 < 0) {
        __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0xe8);
      }
      if (DAT_0050b420 == (int *)0x0) {
        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      }
      piVar3 = DAT_0050b420;
      if ((uVar6 & 0xd) == 0) {
        iVar4 = (**(code **)(*DAT_0050b420 + 0x2c8))
                          (DAT_0050b420,4,0x44960000,local_50,local_54 - _DAT_004020e0,local_58,0);
        if (iVar4 < 0) {
          __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040b430,0x2c8);
        }
        __vbaFreeObj();
        iVar4 = (**(code **)(*local_7c[0] + 0xe8))(local_7c[0],&local_50);
        uVar6 = 0;
        if (iVar4 < 0) {
          __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0xe8);
        }
        uVar2 = (**(code **)(*local_7c[0] + 0x364))(local_7c[0]);
        piVar3 = (int *)__vbaObjSet(local_20,uVar2);
        fVar7 = local_50 * (float)_DAT_00401280;
        if ((uVar6 & 0xd) == 0) {
          iVar4 = (**(code **)(*piVar3 + 0x7c))(piVar3,fVar7);
          if (iVar4 < 0) {
            __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x7c);
          }
          __vbaFreeObj();
          if (DAT_0050c53c == (int *)0x0) {
            __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
          }
          piVar3 = DAT_0050c53c;
          iVar4 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,local_20);
          if (iVar4 < 0) {
            __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040b410,0x18);
          }
          piVar3 = local_20[0];
          iVar4 = (**(code **)(*local_20[0] + 0x98))(local_20[0],&local_50);
          if (iVar4 < 0) {
            __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040bb5c,0x98);
          }
          uVar2 = (**(code **)(*local_7c[0] + 0x364))(local_7c[0]);
          piVar3 = (int *)__vbaObjSet(&local_24,uVar2);
          iVar4 = (**(code **)(*piVar3 + 0x80))(piVar3,&local_54);
          uVar6 = 0;
          if (iVar4 < 0) {
            __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x80);
          }
          uVar2 = (**(code **)(*local_7c[0] + 0x364))(local_7c[0]);
          piVar3 = (int *)__vbaObjSet(&local_28,uVar2);
          if ((uVar6 & 0xd) == 0) {
            if ((uVar6 & 0xd) == 0) {
              iVar4 = (**(code **)(*piVar3 + 0x74))
                                (piVar3,fVar7,(local_50 - local_54) * (float)_DAT_00401268);
              if (iVar4 < 0) {
                __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x74);
              }
              __vbaFreeObjList(3,local_20,&local_24,&local_28);
              uVar2 = (**(code **)(*local_7c[0] + 0x364))(local_7c[0]);
              piVar3 = (int *)__vbaObjSet(local_20,uVar2);
              iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0xffffffff);
              if (iVar4 < 0) {
                __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
              }
              __vbaFreeObj();
              iVar4 = (**(code **)(*local_7c[0] + 0xe8))(local_7c[0],&local_50);
              uVar6 = 0;
              if (iVar4 < 0) {
                __vbaHresultCheckObj(iVar4,local_7c[0],&DAT_0040b430,0xe8);
              }
              if ((uVar6 & 0xd) == 0) {
                DAT_0050b32e = __vbaFpI2();
                if (DAT_0050c53c == (int *)0x0) {
                  __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                }
                piVar3 = DAT_0050c53c;
                iVar4 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,local_20);
                if (iVar4 < 0) {
                  __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040b410,0x18);
                }
                piVar3 = local_20[0];
                iVar4 = (**(code **)(*local_20[0] + 0x50))(local_20[0],&local_50);
                uVar6 = 0;
                if (iVar4 < 0) {
                  __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040bb5c,0x50);
                }
                if (DAT_0050b420 == (int *)0x0) {
                  __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                }
                uVar2 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                piVar3 = (int *)__vbaObjSet(&local_24,uVar2);
                fVar7 = local_50 * (float)_DAT_00401760;
                if ((uVar6 & 0xd) == 0) {
                  iVar4 = (**(code **)(*piVar3 + 0x7c))(piVar3,fVar7);
                  if (iVar4 < 0) {
                    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x7c);
                  }
                  __vbaFreeObjList(2,local_20,&local_24);
                  if (DAT_0050c53c == (int *)0x0) {
                    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                  }
                  piVar3 = DAT_0050c53c;
                  iVar4 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,local_20);
                  if (iVar4 < 0) {
                    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040b410,0x18);
                  }
                  piVar3 = local_20[0];
                  iVar4 = (**(code **)(*local_20[0] + 0x98))(local_20[0],&local_50);
                  if (iVar4 < 0) {
                    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040bb5c,0x98);
                  }
                  if (DAT_0050b420 == (int *)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar2 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                  piVar3 = (int *)__vbaObjSet(&local_24,uVar2);
                  iVar4 = (**(code **)(*piVar3 + 0x80))(piVar3,&local_54);
                  uVar6 = 0;
                  if (iVar4 < 0) {
                    __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x80);
                  }
                  if (DAT_0050b420 == (int *)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar2 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                  piVar3 = (int *)__vbaObjSet(&local_28,uVar2);
                  if ((uVar6 & 0xd) == 0) {
                    if ((uVar6 & 0xd) == 0) {
                      iVar4 = (**(code **)(*piVar3 + 0x74))
                                        (piVar3,fVar7,(local_50 - local_54) * (float)_DAT_00401268);
                      if (iVar4 < 0) {
                        __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x74);
                      }
                      __vbaFreeObjList(3,local_20,&local_24,&local_28);
                      if (DAT_0050b420 == (int *)0x0) {
                        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                      }
                      uVar2 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                      piVar3 = (int *)__vbaObjSet(local_20,uVar2);
                      iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0xffffffff);
                      if (iVar4 < 0) {
                        __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
                      }
                      __vbaFreeObj();
                      if (DAT_0050b334 == 0x17) {
                        uVar2 = (**(code **)(*local_7c[0] + 0x364))(local_7c[0]);
                        piVar3 = (int *)__vbaObjSet(local_20,uVar2);
                        iVar4 = (**(code **)(*piVar3 + 0x9c))(piVar3,0);
                        if (iVar4 < 0) {
                          __vbaHresultCheckObj(iVar4,piVar3,&DAT_0040c3dc,0x9c);
                        }
                        __vbaFreeObj();
                        DAT_0050b338 = 1;
                        DAT_0050b334 = 3;
                        FUN_004cd650();
                      }
                      __vbaObjSetAddref(local_7c,0);
                      __vbaFreeObj(&LAB_004c06a5);
                      return;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __vbaFPException();
  return;
}


