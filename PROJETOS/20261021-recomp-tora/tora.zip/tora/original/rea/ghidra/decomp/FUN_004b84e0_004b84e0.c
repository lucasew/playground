/* entry 004b84e0 name FUN_004b84e0 size 894 */
/* strings:
 *  (North-West Corner Method)
 *  (Least-Cost Method )
 *  (Vogel's Method)
 * TRANSPORTATION MODEL-- ORIGINAL DATA
 * TRANSPORTATION MODEL -- TABLEAUS
 */

void FUN_004b84e0(void)

{
  int *piVar1;
  undefined1 *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined *local_5c;
  undefined *local_58;
  undefined4 local_54 [6];
  undefined4 local_3c;
  undefined4 local_34;
  undefined4 local_30 [4];
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff84;
  local_8 = &DAT_004022c8;
  local_18 = 0;
  local_1c = 0;
  local_20 = 0;
  local_30[0] = 0;
  local_54[0] = 0;
  local_58 = (undefined *)0x0;
  local_5c = (undefined *)0x0;
  ExceptionList = &pvStack_14;
  puVar2 = &stack0xffffff84;
  if (DAT_0050c53c == (int *)0x0) {
    ExceptionList = &pvStack_14;
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    puVar2 = local_c;
  }
  local_c = puVar2;
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  uVar4 = local_1c;
  local_1c = 0;
  __vbaObjSet(&local_20,uVar4);
  FUN_0048c990(&local_20);
  __vbaFreeObj();
  __vbaStrCopy();
  FUN_004d5050();
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  uVar4 = __vbaLateIdCallLd(local_30,local_1c,0x10028,0,&DAT_0040eb6c,3,0xb,local_3c,0,local_34);
  uVar4 = __vbaCastObjVar(uVar4);
  uVar4 = __vbaObjSet(&local_20,uVar4);
  __vbaLateIdSt(uVar4);
  __vbaFreeObjList(2,&local_1c,&local_20);
  __vbaFreeVar();
  local_54[0] = 1;
  local_5c = &DAT_0050b078;
  local_58 = &DAT_0050b054;
  FUN_0048cdf0(&DAT_0050b0b8,&local_58,&local_5c,local_54);
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  __vbaLateIdCall(local_1c,0x20001,0);
  __vbaFreeObj();
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  uVar4 = __vbaLateIdCallLd(local_30,local_1c,0x10028,0,&DAT_0040eb6c,3,0xb,local_3c,0,local_34);
  uVar4 = __vbaCastObjVar(uVar4);
  uVar4 = __vbaObjSet(&local_20,uVar4);
  __vbaLateIdSt(uVar4);
  __vbaFreeObjList(2,&local_1c,&local_20);
  __vbaFreeVar();
  if (((DAT_0050b2c8 == 1) || (DAT_0050b2c8 == 2)) || (DAT_0050b2c8 == 3)) {
    __vbaStrCopy();
  }
  __vbaStrCat(local_18,L"TRANSPORTATION MODEL -- TABLEAUS");
  __vbaStrMove();
  FUN_004d5050();
  local_54[0] = 2;
  local_5c = &DAT_0050b078;
  local_58 = &DAT_0050b054;
  FUN_0048cdf0(&DAT_0050b0cc,&local_58,&local_5c,local_54);
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  __vbaLateIdCall(local_1c,0x20000,0);
  __vbaFreeObj();
  __vbaFreeStr(&LAB_004b887b);
  return;
}


