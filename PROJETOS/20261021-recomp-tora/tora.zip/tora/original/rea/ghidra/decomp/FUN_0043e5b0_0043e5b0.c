/* entry 0043e5b0 name FUN_0043e5b0 size 8992 */
/* strings:
 * Last tableau shows solution is unbounded
 * Optimal Tableau
 * Last row completes minimal spanning tree
 * No more breakthroughs -- Algorithm end at iteration 
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0043e5b0(uint param_1)

{
  ushort uVar1;
  ushort uVar2;
  int *piVar3;
  code *******pppppppcVar4;
  undefined2 extraout_var;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  short sVar8;
  short sVar9;
  short sVar10;
  undefined2 extraout_var_00;
  short sVar11;
  undefined2 extraout_var_01;
  code *******unaff_EBX;
  code *pcVar12;
  code *******pppppppcVar13;
  code *******unaff_ESI;
  code *******pppppppcVar14;
  code *******unaff_EDI;
  undefined2 uVar17;
  code *******pppppppcVar15;
  int *piVar16;
  ushort in_FPUStatusWord;
  code ******ppppppcStack_1b8;
  code ******ppppppcStack_1b4;
  code ******ppppppcStack_1b0;
  code ******ppppppcStack_1ac;
  code ******ppppppcStack_1a8;
  code ******ppppppcStack_1a4;
  code ******ppppppcStack_1a0;
  code ******ppppppcStack_19c;
  code ******ppppppcStack_198;
  code ******ppppppcStack_194;
  code ******ppppppcStack_190;
  code ******ppppppcStack_18c;
  code ******ppppppcStack_188;
  code ******ppppppcStack_184;
  code ******ppppppcStack_180;
  code ******ppppppcStack_17c;
  code *****pppppcStack_178;
  code ******local_f4;
  code ******local_f0;
  code ******local_ec [3];
  uint local_e0;
  uint local_dc;
  undefined4 local_c8;
  code ******local_c4;
  code ******local_bc;
  undefined4 local_a8;
  code ******local_a4;
  code ******local_9c;
  undefined4 local_98;
  wchar_t *local_90;
  code ******local_88;
  code ******local_84;
  code ******local_80;
  code ******local_7c;
  code *****local_78 [2];
  undefined4 local_70;
  code *****local_68 [2];
  undefined4 local_60;
  code *****local_58 [4];
  code *****local_48 [2];
  undefined4 local_40;
  code *****local_38;
  undefined4 local_34;
  short *local_30 [2];
  undefined4 local_28;
  void *pvStack_18;
  undefined *puStack_14;
  undefined1 *local_10;
  undefined *local_c;
  uint local_8;
  
  puStack_14 = &DAT_00402706;
  pvStack_18 = ExceptionList;
  local_10 = &stack0xfffffe8c;
  local_c = &DAT_00401bd8;
  local_8 = param_1 & 1;
  pppppcStack_178 = (code *****)(param_1 & 0xfffffffe);
  ppppppcStack_17c = (code ******)0x43e5f2;
  ExceptionList = &pvStack_18;
  (*(code *)(*pppppcStack_178)[1])();
  pppppppcVar15 = (code *******)__vbaFreeObj_exref;
  pppppppcVar14 = (code *******)__vbaLateIdSt_exref;
  pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
  pcVar12 = __vbaObjSet_exref;
  _DAT_0050b20e = 2;
  local_30[0] = (short *)0x0;
  local_34 = 0;
  local_38 = (code *****)0x0;
  local_48[0] = (code *****)0x0;
  local_58[0] = (code *****)0x0;
  local_68[0] = (code *****)0x0;
  local_78[0] = (code *****)0x0;
  local_88 = (code ******)0x0;
  local_98 = 0;
  local_a8 = 0;
  local_c8 = 0;
  local_ec[0] = (code ******)0x0;
  local_f0 = (code ******)0x0;
  local_f4 = (code ******)0x0;
  switch(DAT_0050b238) {
  case 3:
    do {
      sVar11 = DAT_0050b29a + 1;
      local_88 = (code ******)0x3;
      pppppppcVar13 = (code *******)pcVar12;
      sVar10 = DAT_0050b244;
      if (((SCARRY2(DAT_0050b29a,1)) || (DAT_0050b29a = sVar11, SCARRY2(DAT_0050b20c,7))) ||
         ((iVar6 = (int)(short)(DAT_0050b20c + 7) * (int)sVar11, sVar11 = (short)iVar6,
          sVar11 != iVar6 || (DAT_0050b298 = sVar11, SCARRY2(DAT_0050b276,sVar11)))))
      goto LAB_00440949;
      local_80 = (code ******)(int)(short)(DAT_0050b276 + sVar11);
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_17c = (code ******)&DAT_0050b420;
        ppppppcStack_180 = (code ******)&DAT_00408c88;
        ppppppcStack_184 = (code ******)0x43e6d9;
        __vbaNew2();
      }
      ppppppcStack_18c = (code ******)0x4;
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_188 = local_88;
      ppppppcStack_184 = local_84;
      ppppppcStack_180 = local_80;
      ppppppcStack_17c = local_7c;
      ppppppcStack_194 = (code ******)0x43e708;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43e70f;
      ppppppcStack_19c = (code ******)__vbaObjSet();
      ppppppcStack_1a0 = (code ******)0x43e712;
      __vbaLateIdSt();
      ppppppcStack_1a0 = (code ******)0x43e717;
      __vbaFreeObj();
      sVar10 = DAT_0050b244;
      if (SCARRY2(DAT_0050b244,1)) goto LAB_00440949;
      if ((short)DAT_0050b260 == -0x56ce) {
        ppppppcStack_17c = (code ******)0x43e73d;
        DAT_0050b244 = DAT_0050b244 + 1;
        FUN_00481f60();
      }
      else {
        ppppppcStack_17c = (code ******)0x43e74b;
        DAT_0050b244 = DAT_0050b244 + 1;
        sVar11 = __vbaI2Abs();
        sVar8 = (short)((int)sVar11 * (int)DAT_0050b25e);
        sVar10 = DAT_0050b244;
        if ((int)sVar8 != (int)sVar11 * (int)DAT_0050b25e) goto LAB_00440949;
        if ((sVar8 < 1) && (DAT_0050b240 != -2)) {
          if (DAT_0050b25e == 0) {
            local_78[0] = (code *****)0xa;
            local_68[0] = (code *****)0xa;
            local_70 = 0x80020004;
            local_60 = 0x80020004;
            local_90 = L"Optimal Tableau";
            local_98 = 8;
            ppppppcStack_17c = (code ******)0x43e807;
            __vbaVarDup();
            local_80 = (code ******)0x40e1bc;
            local_88 = (code ******)0x8;
            ppppppcStack_17c = (code ******)0x43e81f;
            __vbaVarDup();
            ppppppcStack_17c = local_78;
            ppppppcStack_180 = local_68;
            ppppppcStack_184 = local_58;
            ppppppcStack_18c = local_48;
            ppppppcStack_188 = (code ******)0x40;
            ppppppcStack_190 = (code ******)0x43e837;
            Ordinal_595();
            ppppppcStack_190 = local_78;
            ppppppcStack_194 = local_68;
            ppppppcStack_198 = local_58;
            ppppppcStack_19c = local_48;
            ppppppcStack_1a0 = (code ******)0x4;
            ppppppcStack_1a4 = (code ******)0x43e84f;
            __vbaFreeVarList();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_190 = (code ******)&DAT_0050b420;
              ppppppcStack_194 = (code ******)&DAT_00408c88;
              ppppppcStack_198 = (code ******)0x43e86b;
              __vbaNew2();
            }
            ppppppcStack_190 = (code ******)DAT_0050b420;
            ppppppcStack_194 = (code ******)0x43e879;
            ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_198 = &local_38;
            ppppppcStack_19c = (code ******)0x43e880;
            pppppppcVar15 = (code *******)__vbaObjSet();
            ppppppcStack_19c = (code ******)0x0;
            ppppppcStack_1a4 = (code ******)0x43e88d;
            ppppppcStack_1a0 = (code ******)pppppppcVar15;
            iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
            if (iVar6 < 0) {
              ppppppcStack_1a4 = (code ******)0x8c;
              ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
              ppppppcStack_1b4 = (code ******)0x43e8a5;
              ppppppcStack_1b0 = (code ******)iVar6;
              ppppppcStack_1ac = (code ******)pppppppcVar15;
              __vbaHresultCheckObj();
            }
            ppppppcStack_1a4 = (code ******)0x43e8b0;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_1a4 = (code ******)&DAT_0050b420;
              ppppppcStack_1a8 = (code ******)&DAT_00408c88;
              ppppppcStack_1ac = (code ******)0x43e8c9;
              __vbaNew2();
            }
            ppppppcStack_1a4 = (code ******)DAT_0050b420;
            ppppppcStack_1a8 = (code ******)0x43e8d7;
            ppppppcStack_1a8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_1ac = &local_38;
            ppppppcStack_1b0 = (code ******)0x43e8de;
            pppppppcVar15 = (code *******)__vbaObjSet();
            ppppppcStack_1b0 = (code ******)0x0;
            ppppppcStack_1b8 = (code ******)0x43e8eb;
            ppppppcStack_1b4 = (code ******)pppppppcVar15;
            iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
            if (iVar6 < 0) {
              ppppppcStack_1b8 = (code ******)0x8c;
              __vbaHresultCheckObj(iVar6,pppppppcVar15,&DAT_0040bb6c);
            }
            ppppppcStack_1b8 = (code ******)0x43e908;
            __vbaFreeObj();
            break;
          }
          if ((short)DAT_0050b260 == 0) {
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_17c = (code ******)&DAT_0050b420;
              ppppppcStack_180 = (code ******)&DAT_00408c88;
              ppppppcStack_184 = (code ******)0x43e926;
              __vbaNew2();
            }
            ppppppcStack_17c = (code ******)DAT_0050b420;
            ppppppcStack_180 = (code ******)0x43e934;
            ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
            ppppppcStack_184 = (code ******)local_ec;
            ppppppcStack_188 = (code ******)0x43e93e;
            __vbaObjSet();
            ppppppcStack_188 = (code ******)0x43e94b;
            sVar10 = __vbaI2Abs();
            local_88 = (code ******)0x3;
            ppppppcStack_18c = (code ******)(int)sVar10;
            ppppppcStack_194 = (code ******)0x3;
            ppppppcStack_198 = (code ******)0xb;
            ppppppcStack_190 = local_84;
            ppppppcStack_19c = local_ec[0];
            ppppppcStack_188 = local_7c;
            ppppppcStack_1a0 = (code ******)0x43e97d;
            local_80 = ppppppcStack_18c;
            __vbaLateIdSt();
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_17c = (code ******)0x43e9d9;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              pppppppcVar15 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
              if (*(code **)(DAT_0050b1a4 + 0xc) <= pppppppcVar15) {
                ppppppcStack_17c = (code ******)0x43e9a4;
                __vbaGenerateBoundsError();
              }
              pppppppcVar14 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
              if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar14) {
                ppppppcStack_17c = (code ******)0x43e9c1;
                __vbaGenerateBoundsError();
              }
              iVar6 = (int)((int)pppppppcVar15 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar14)
                      * 2;
            }
            pppppppcVar13 = (code *******)&DAT_00000001;
            uVar17 = (undefined2)((uint)pppppppcVar15 >> 0x10);
            sVar11 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6) + DAT_0050b20c;
            pppppppcVar15 = (code *******)CONCAT22(uVar17,sVar11);
            sVar10 = DAT_0050b244;
            if (SCARRY2(*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6),DAT_0050b20c))
            goto LAB_00440949;
            pppppppcVar15 = (code *******)CONCAT22(uVar17,sVar11 + 5);
            if (SCARRY2(sVar11,5)) goto LAB_00440949;
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_17c = (code ******)0x43ea5f;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              local_e0 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_e0) {
                ppppppcStack_17c = (code ******)0x43ea26;
                __vbaGenerateBoundsError();
              }
              pppppppcVar14 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
              if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar14) {
                ppppppcStack_17c = (code ******)0x43ea43;
                __vbaGenerateBoundsError();
              }
              iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar14 + local_e0) * 2;
            }
            pppppppcVar4 = (code *******)
                           CONCAT22((short)((uint)pppppppcVar14 >> 0x10),
                                    *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar6));
            goto LAB_0043ea6c;
          }
        }
        else {
          ppppppcStack_17c = (code ******)0x43e78e;
          DAT_0050b240 = __vbaI2Abs();
          if (DAT_0050b274 == 5) {
            ppppppcStack_17c = (code ******)0x43e7aa;
            FUN_00482b00();
          }
          else {
            ppppppcStack_17c = (code ******)0x43e7a3;
            FUN_00481f60();
          }
        }
      }
    } while ((DAT_0050b240 == -2) || (DAT_0050b25e != 0));
    break;
  case 4:
    if (DAT_0050b420 == (code *******)0x0) {
      ppppppcStack_17c = (code ******)&DAT_0050b420;
      ppppppcStack_180 = (code ******)&DAT_00408c88;
      ppppppcStack_184 = (code ******)0x43ecc1;
      __vbaNew2();
    }
    ppppppcStack_17c = (code ******)DAT_0050b420;
    ppppppcStack_180 = (code ******)0x43eccf;
    ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xcf])();
    pppppppcVar15 = (code *******)__vbaObjSet_exref;
    ppppppcStack_184 = &local_38;
    ppppppcStack_188 = (code ******)0x43ecdc;
    pppppppcVar13 = (code *******)__vbaObjSet();
    ppppppcStack_188 = (code ******)0x0;
    ppppppcStack_190 = (code ******)0x43ece9;
    ppppppcStack_18c = (code ******)pppppppcVar13;
    pppppppcVar14 = (code *******)(*(code *)(*pppppppcVar13)[0x25])();
    if ((int)pppppppcVar14 < 0) {
      ppppppcStack_190 = (code ******)0x94;
      ppppppcStack_194 = (code ******)&DAT_0040c3dc;
      ppppppcStack_1a0 = (code ******)0x43ed01;
      ppppppcStack_19c = (code ******)pppppppcVar14;
      ppppppcStack_198 = (code ******)pppppppcVar13;
      __vbaHresultCheckObj();
    }
    pppppppcVar13 = (code *******)__vbaFreeObj_exref;
    ppppppcStack_190 = (code ******)0x43ed0c;
    __vbaFreeObj();
    if (DAT_0050b420 == (code *******)0x0) {
      ppppppcStack_190 = (code ******)&DAT_0050b420;
      ppppppcStack_194 = (code ******)&DAT_00408c88;
      ppppppcStack_198 = (code ******)0x43ed25;
      __vbaNew2();
    }
    ppppppcStack_190 = (code ******)DAT_0050b420;
    ppppppcStack_194 = (code ******)0x43ed33;
    ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xd0])();
    ppppppcStack_198 = &local_38;
    ppppppcStack_19c = (code ******)0x43ed3a;
    pppppppcVar14 = (code *******)__vbaObjSet();
    ppppppcStack_19c = (code ******)0x0;
    ppppppcStack_1a4 = (code ******)0x43ed47;
    ppppppcStack_1a0 = (code ******)pppppppcVar14;
    iVar6 = (*(code *)(*pppppppcVar14)[0x25])();
    if (iVar6 < 0) {
      ppppppcStack_1a4 = (code ******)0x94;
      ppppppcStack_1a8 = (code ******)&DAT_0040dc58;
      ppppppcStack_1b4 = (code ******)0x43ed5f;
      ppppppcStack_1b0 = (code ******)iVar6;
      ppppppcStack_1ac = (code ******)pppppppcVar14;
      __vbaHresultCheckObj();
    }
    ppppppcStack_1a4 = (code ******)0x43ed64;
    __vbaFreeObj();
    pppppppcVar14 = (code *******)__vbaLateIdSt_exref;
    do {
      sVar11 = DAT_0050b244 + 1;
      sVar10 = DAT_0050b244;
      if (((SCARRY2(DAT_0050b244,1)) ||
          (sVar8 = (short)(DAT_0050b2c4 * 3), (int)sVar8 != DAT_0050b2c4 * 3)) ||
         (sVar9 = sVar8 + 4, sVar10 = sVar11, SCARRY2(sVar8,4))) goto LAB_00440949;
      sVar8 = DAT_0050b298 + sVar9;
      local_88 = (code ******)0x3;
      if (((SCARRY2(DAT_0050b298,sVar9)) || (DAT_0050b298 = sVar8, SCARRY2(sVar11,1))) ||
         (iVar6 = (int)(short)(DAT_0050b244 + 2) * (int)sVar9, sVar8 = (short)iVar6, sVar8 != iVar6)
         ) goto LAB_00440949;
      local_80 = (code ******)(int)sVar8;
      DAT_0050b244 = sVar11;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_17c = (code ******)&DAT_0050b420;
        ppppppcStack_180 = (code ******)&DAT_00408c88;
        ppppppcStack_184 = (code ******)0x43edef;
        __vbaNew2();
      }
      ppppppcStack_18c = (code ******)0x4;
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_188 = local_88;
      ppppppcStack_184 = local_84;
      ppppppcStack_180 = local_80;
      ppppppcStack_17c = local_7c;
      ppppppcStack_194 = (code ******)0x43ee1e;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43ee25;
      ppppppcStack_19c = (code ******)__vbaObjSet();
      ppppppcStack_1a0 = (code ******)0x43ee28;
      __vbaLateIdSt();
      ppppppcStack_1a0 = (code ******)0x43ee2d;
      __vbaFreeObj();
      ppppppcStack_17c = (code ******)0x43ee32;
      FUN_004b8890();
    } while (DAT_0050b25e != 0);
    break;
  case 7:
    switch(DAT_0050b334) {
    case 1:
      pppppppcVar13 = (code *******)&DAT_00000001;
      sVar11 = DAT_0050b332 - 1;
      pppppppcVar14 = (code *******)CONCAT22((short)((uint)unaff_ESI >> 0x10),sVar11);
      DAT_0050b33a = 0;
      pppppppcVar15 = unaff_EDI;
      sVar10 = DAT_0050b244;
      if (!SBORROW2(DAT_0050b332,1)) {
        pppppppcVar4 = (code *******)&DAT_00000001;
        do {
          pppppppcVar15 = pppppppcVar4;
          sVar8 = (short)pppppppcVar15;
          if (sVar11 < sVar8) {
            local_78[0] = (code *****)0xa;
            local_68[0] = (code *****)0xa;
            local_70 = 0x80020004;
            local_60 = 0x80020004;
            local_90 = L"Optimum";
            local_98 = 8;
            ppppppcStack_17c = (code ******)0x43ef90;
            __vbaVarDup();
            local_80 = (code ******)0x40df54;
            local_88 = (code ******)0x8;
            ppppppcStack_17c = (code ******)0x43efa8;
            __vbaVarDup();
            ppppppcStack_17c = local_78;
            ppppppcStack_180 = local_68;
            ppppppcStack_184 = local_58;
            ppppppcStack_18c = local_48;
            ppppppcStack_188 = (code ******)0x40;
            ppppppcStack_190 = (code ******)0x43efc0;
            Ordinal_595();
            ppppppcStack_190 = local_78;
            ppppppcStack_194 = local_68;
            ppppppcStack_198 = local_58;
            ppppppcStack_19c = local_48;
            ppppppcStack_1a0 = (code ******)0x4;
            ppppppcStack_1a4 = (code ******)0x43efd8;
            __vbaFreeVarList();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_190 = (code ******)&DAT_0050b420;
              ppppppcStack_194 = (code ******)&DAT_00408c88;
              ppppppcStack_198 = (code ******)0x43eff4;
              __vbaNew2();
            }
            ppppppcStack_190 = (code ******)DAT_0050b420;
            ppppppcStack_194 = (code ******)0x43f002;
            ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_198 = &local_38;
            ppppppcStack_19c = (code ******)0x43f00f;
            pppppppcVar15 = (code *******)__vbaObjSet();
            ppppppcStack_19c = (code ******)0x0;
            ppppppcStack_1a4 = (code ******)0x43f01c;
            ppppppcStack_1a0 = (code ******)pppppppcVar15;
            iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
            if (iVar6 < 0) {
              ppppppcStack_1a4 = (code ******)0x8c;
              ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
              ppppppcStack_1b4 = (code ******)0x43f034;
              ppppppcStack_1b0 = (code ******)iVar6;
              ppppppcStack_1ac = (code ******)pppppppcVar15;
              __vbaHresultCheckObj();
            }
            pcVar12 = __vbaFreeObj_exref;
            ppppppcStack_1a4 = (code ******)0x43f03f;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_1a4 = (code ******)&DAT_0050b420;
              ppppppcStack_1a8 = (code ******)&DAT_00408c88;
              ppppppcStack_1ac = (code ******)0x43f058;
              __vbaNew2();
            }
            ppppppcStack_1a4 = (code ******)DAT_0050b420;
            ppppppcStack_1a8 = (code ******)0x43f066;
            ppppppcStack_1a8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_1ac = &local_38;
            ppppppcStack_1b0 = (code ******)0x43f06d;
            pppppppcVar15 = (code *******)__vbaObjSet();
            ppppppcStack_1b0 = (code ******)0x0;
            ppppppcStack_1b8 = (code ******)0x43f07a;
            ppppppcStack_1b4 = (code ******)pppppppcVar15;
            iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
joined_r0x0043f430:
            if (iVar6 < 0) {
LAB_0043f080:
              ppppppcStack_1a4 = (code ******)0x8c;
              ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
              ppppppcStack_1b4 = (code ******)0x43f092;
              ppppppcStack_1b0 = (code ******)iVar6;
              ppppppcStack_1ac = (code ******)pppppppcVar15;
              __vbaHresultCheckObj();
            }
LAB_0043f092:
            ppppppcStack_1a4 = (code ******)0x43f097;
            (*pcVar12)();
            goto switchD_0043e64f_caseD_5;
          }
          ppppppcStack_17c = (code ******)0x43ee8c;
          FUN_004bea60();
          if (DAT_0050b33a == 0) {
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_17c = (code ******)&DAT_0050b420;
              ppppppcStack_180 = (code ******)&DAT_00408c88;
              ppppppcStack_184 = (code ******)0x43eebf;
              __vbaNew2();
            }
            ppppppcStack_17c = (code ******)DAT_0050b420;
            ppppppcStack_180 = (code ******)0x43eecd;
            ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_184 = &local_38;
            ppppppcStack_188 = (code ******)0x43eeda;
            pppppppcVar15 = (code *******)__vbaObjSet();
            ppppppcStack_188 = (code ******)0x0;
            ppppppcStack_190 = (code ******)0x43eee7;
            ppppppcStack_18c = (code ******)pppppppcVar15;
            pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar15)[0x23])();
            if ((int)pppppppcVar13 < 0) {
              ppppppcStack_190 = (code ******)0x8c;
              ppppppcStack_194 = (code ******)&DAT_0040bb6c;
              ppppppcStack_1a0 = (code ******)0x43eeff;
              ppppppcStack_19c = (code ******)pppppppcVar13;
              ppppppcStack_198 = (code ******)pppppppcVar15;
              __vbaHresultCheckObj();
            }
            pcVar12 = __vbaFreeObj_exref;
            ppppppcStack_190 = (code ******)0x43ef0a;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_190 = (code ******)&DAT_0050b420;
              ppppppcStack_194 = (code ******)&DAT_00408c88;
              ppppppcStack_198 = (code ******)0x43ef23;
              __vbaNew2();
            }
            ppppppcStack_190 = (code ******)DAT_0050b420;
            ppppppcStack_194 = (code ******)0x43ef31;
            ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_198 = &local_38;
            ppppppcStack_19c = (code ******)0x43ef38;
            pppppppcVar15 = (code *******)__vbaObjSet();
            ppppppcStack_19c = (code ******)0x0;
            ppppppcStack_1a4 = (code ******)0x43ef45;
            ppppppcStack_1a0 = (code ******)pppppppcVar15;
            iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
            if (-1 < iVar6) goto LAB_0043f092;
            goto LAB_0043f080;
          }
          pppppppcVar4 = (code *******)CONCAT22(extraout_var,sVar8 + 1);
          sVar10 = DAT_0050b244;
        } while (!SCARRY2(sVar8,1));
      }
      break;
    case 2:
      local_80 = (code ******)&DAT_00000001;
      local_88 = (code ******)0x3;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_17c = (code ******)&DAT_0050b420;
        ppppppcStack_180 = (code ******)&DAT_00408c88;
        ppppppcStack_184 = (code ******)0x43f0c6;
        __vbaNew2();
      }
      ppppppcStack_18c = (code ******)0x4;
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_188 = local_88;
      ppppppcStack_184 = local_84;
      ppppppcStack_180 = local_80;
      ppppppcStack_17c = local_7c;
      ppppppcStack_194 = (code ******)0x43f0f5;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      pppppppcVar15 = (code *******)__vbaObjSet_exref;
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43f102;
      ppppppcStack_19c = (code ******)__vbaObjSet();
      ppppppcStack_1a0 = (code ******)0x43f10b;
      __vbaLateIdSt();
      ppppppcStack_1a0 = (code ******)0x43f116;
      __vbaFreeObj();
      local_80 = (code ******)0x4;
      local_88 = (code ******)0x3;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_1a0 = (code ******)&DAT_0050b420;
        ppppppcStack_1a4 = (code ******)&DAT_00408c88;
        ppppppcStack_1a8 = (code ******)0x43f140;
        __vbaNew2();
      }
      ppppppcStack_1b0 = (code ******)0x5;
      ppppppcStack_1b4 = (code ******)DAT_0050b420;
      ppppppcStack_1ac = local_88;
      ppppppcStack_1a8 = local_84;
      ppppppcStack_1a4 = local_80;
      ppppppcStack_1a0 = local_7c;
      ppppppcStack_1b8 = (code ******)0x43f16f;
      ppppppcStack_1b8 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      uVar7 = __vbaObjSet(&local_38);
      __vbaLateIdSt(uVar7);
      __vbaFreeObj();
      pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
      DAT_0050b33c = 1;
      if ((DAT_0050b1a8 == (short *)0x0) || (*DAT_0050b1a8 != 1)) {
        ppppppcStack_17c = (code ******)0x43f1c3;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        iVar6 = *(int *)(DAT_0050b1a8 + 10);
        if (*(uint *)(DAT_0050b1a8 + 8) <= 1U - iVar6) {
          ppppppcStack_17c = (code ******)0x43f1b0;
          __vbaGenerateBoundsError();
        }
        iVar6 = (1U - iVar6) * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b1a8 + 6) + iVar6) = 0xffff;
      if ((DAT_0050b1ac == (short *)0x0) || (*DAT_0050b1ac != 1)) {
        ppppppcStack_17c = (code ******)0x43f206;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        iVar6 = *(int *)(DAT_0050b1ac + 10);
        if (*(uint *)(DAT_0050b1ac + 8) <= 1U - iVar6) {
          ppppppcStack_17c = (code ******)0x43f1f5;
          __vbaGenerateBoundsError();
        }
        iVar6 = (1U - iVar6) * 4;
      }
      *(undefined4 *)(*(int *)(DAT_0050b1ac + 6) + iVar6) = 0;
      uVar1 = DAT_0050b332;
      pppppppcVar4 = (code *******)0x2;
      do {
        pppppppcVar14 = pppppppcVar4;
        uVar2 = DAT_0050b332;
        sVar11 = (short)pppppppcVar14;
        if ((short)uVar1 < sVar11) {
          pppppppcVar14 = (code *******)(uint)DAT_0050b332;
          sVar11 = 1;
          goto LAB_0043f2e4;
        }
        if ((DAT_0050b1ac == (short *)0x0) || (*DAT_0050b1ac != 1)) {
          ppppppcStack_17c = (code ******)0x43f267;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar15 = (code *******)((int)sVar11 - *(int *)(DAT_0050b1ac + 10));
          if (*(code ********)(DAT_0050b1ac + 8) <= pppppppcVar15) {
            ppppppcStack_17c = (code ******)0x43f256;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)pppppppcVar15 * 4;
        }
        *(float *)(*(int *)(DAT_0050b1ac + 6) + iVar6) = (float)_DAT_0050b134;
        if ((DAT_0050b1a8 == (short *)0x0) || (*DAT_0050b1a8 != 1)) {
          ppppppcStack_17c = (code ******)0x43f2b3;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar15 = (code *******)((int)sVar11 - *(int *)(DAT_0050b1a8 + 10));
          if (*(code ********)(DAT_0050b1a8 + 8) <= pppppppcVar15) {
            ppppppcStack_17c = (code ******)0x43f2a6;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)pppppppcVar15 * 2;
        }
        *(short *)(*(int *)(DAT_0050b1a8 + 6) + iVar6) = sVar11;
        pppppppcVar4 = (code *******)(uint)(ushort)(sVar11 + 1);
        sVar10 = DAT_0050b244;
      } while (!SCARRY2(sVar11,1));
      break;
    case 3:
      pppppppcVar13 = unaff_EBX;
      pppppppcVar4 = unaff_EDI;
      do {
        ppppppcStack_17c = (code ******)0x43f446;
        FUN_004c9e80();
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          ppppppcStack_17c = (code ******)0x43f49d;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar4 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
          if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar4) {
            ppppppcStack_17c = (code ******)0x43f46d;
            __vbaGenerateBoundsError();
          }
          pppppppcVar13 = (code *******)-*(int *)(DAT_0050b1a4 + 10);
          if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar13) {
            ppppppcStack_17c = (code ******)0x43f485;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)((int)pppppppcVar4 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar13) * 2;
        }
        if (0 < *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6)) {
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_17c = (code ******)&DAT_0050b420;
            ppppppcStack_180 = (code ******)&DAT_00408c88;
            ppppppcStack_184 = (code ******)0x43f4ca;
            __vbaNew2();
          }
          ppppppcStack_17c = (code ******)DAT_0050b420;
          ppppppcStack_180 = (code ******)0x43f4d8;
          ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
          ppppppcStack_184 = (code ******)&local_f0;
          ppppppcStack_188 = (code ******)0x43f4e6;
          __vbaObjSet();
          pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
          if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
            ppppppcStack_17c = (code ******)0x43f545;
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b1a4 + 0xe);
            if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar6) {
              ppppppcStack_17c = (code ******)0x43f50d;
              __vbaGenerateBoundsError();
            }
            iVar5 = *(int *)(DAT_0050b1a4 + 10);
            if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)-iVar5) {
              ppppppcStack_17c = (code ******)0x43f525;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * -iVar5 + (1U - iVar6)) * 2;
            pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
          }
          sVar11 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
          pppppppcVar4 = (code *******)&DAT_00000001;
          while (sVar8 = (short)pppppppcVar4, sVar8 <= sVar11) {
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_17c = (code ******)0x43f5c9;
              iVar6 = (*(code *)pppppppcVar13)();
            }
            else {
              local_e0 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_e0) {
                ppppppcStack_17c = (code ******)0x43f58e;
                (*(code *)pppppppcVar13)();
              }
              iVar6 = *(int *)(DAT_0050b1a4 + 10);
              if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(sVar8 - iVar6)) {
                ppppppcStack_17c = (code ******)0x43f5a9;
                __vbaGenerateBoundsError();
              }
              iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (sVar8 - iVar6) + local_e0) * 2;
              pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
            }
            ppppppcStack_180 = (code ******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
            local_88 = (code ******)0x3;
            ppppppcStack_188 = (code ******)0x3;
            ppppppcStack_18c = (code ******)0xa;
            ppppppcStack_184 = local_84;
            ppppppcStack_190 = local_f0;
            ppppppcStack_17c = local_7c;
            ppppppcStack_194 = (code ******)0x43f605;
            local_80 = ppppppcStack_180;
            __vbaLateIdSt();
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_194 = (code ******)0x43f669;
              iVar6 = (*(code *)pppppppcVar13)();
            }
            else {
              local_e0 = 2 - *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_e0) {
                ppppppcStack_194 = (code ******)0x43f62e;
                (*(code *)pppppppcVar13)();
              }
              iVar6 = *(int *)(DAT_0050b1a4 + 10);
              if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(sVar8 - iVar6)) {
                ppppppcStack_194 = (code ******)0x43f649;
                __vbaGenerateBoundsError();
              }
              iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (sVar8 - iVar6) + local_e0) * 2;
              pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
            }
            ppppppcStack_198 = (code ******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
            local_88 = (code ******)0x3;
            ppppppcStack_1a4 = (code ******)0xb;
            ppppppcStack_1a0 = (code ******)0x3;
            ppppppcStack_19c = local_84;
            ppppppcStack_1a8 = local_f0;
            ppppppcStack_194 = local_7c;
            ppppppcStack_1ac = (code ******)0x43f6a5;
            local_80 = ppppppcStack_198;
            __vbaLateIdSt();
            local_88 = (code ******)0x3;
            ppppppcStack_1b8 = (code ******)0x3;
            local_80 = (code ******)0xff00;
            ppppppcStack_1b4 = local_84;
            ppppppcStack_1b0 = (code ******)0xff00;
            ppppppcStack_1ac = local_7c;
            __vbaLateIdSt(local_f0,0x26);
            uVar7 = __vbaLateIdCallLd(local_48,local_f0,0xb,0);
            iVar6 = __vbaI4Var(uVar7);
            iVar5 = iVar6 + (short)DAT_0050b332;
            pppppppcVar15 = pppppppcVar4;
            sVar10 = DAT_0050b244;
            if (SCARRY4(iVar6,(int)(short)DAT_0050b332)) goto LAB_00440949;
            pppppppcVar4 = (code *******)(iVar5 + 1);
            local_88 = (code ******)0x3;
            if (SCARRY4(iVar5,1)) goto LAB_00440949;
            ppppppcStack_18c = (code ******)0xb;
            ppppppcStack_188 = (code ******)0x3;
            ppppppcStack_184 = local_84;
            ppppppcStack_190 = local_f0;
            ppppppcStack_17c = local_7c;
            ppppppcStack_194 = (code ******)0x43f73f;
            ppppppcStack_180 = (code ******)pppppppcVar4;
            local_80 = (code ******)pppppppcVar4;
            __vbaLateIdSt();
            ppppppcStack_194 = (code ******)0x43f748;
            __vbaFreeVar();
            local_88 = (code ******)0x3;
            ppppppcStack_1a4 = (code ******)0x26;
            ppppppcStack_1a0 = (code ******)0x3;
            local_80 = (code ******)0xff00;
            ppppppcStack_19c = local_84;
            ppppppcStack_1a8 = local_f0;
            ppppppcStack_198 = (code ******)0xff00;
            ppppppcStack_194 = local_7c;
            ppppppcStack_1ac = (code ******)0x43f77c;
            __vbaLateIdSt();
            pppppppcVar4 = (code *******)(uint)(ushort)(sVar8 + 1);
            sVar10 = DAT_0050b244;
            if (SCARRY2(sVar8,1)) goto LAB_00440949;
          }
          ppppppcStack_180 = (code ******)&local_f0;
          ppppppcStack_17c = (code ******)0x0;
          ppppppcStack_184 = (code ******)0x43f7a6;
          __vbaObjSetAddref();
        }
        pppppppcVar15 = pppppppcVar4;
        sVar10 = DAT_0050b244;
        if (SCARRY2(DAT_0050b244,1)) goto LAB_00440949;
        ppppppcStack_17c = (code ******)0x43f7c1;
        DAT_0050b244 = DAT_0050b244 + 1;
        FUN_004ca300();
        sVar10 = DAT_0050b244;
        if (SCARRY2(DAT_0050b332,1)) goto LAB_00440949;
      } while (DAT_0050b244 != (ushort)(DAT_0050b332 + 1));
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_17c = (code ******)&DAT_0050b420;
        ppppppcStack_180 = (code ******)&DAT_00408c88;
        ppppppcStack_184 = (code ******)0x43f7f8;
        __vbaNew2();
      }
      ppppppcStack_17c = (code ******)DAT_0050b420;
      ppppppcStack_180 = (code ******)0x43f806;
      ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      ppppppcStack_184 = &local_38;
      ppppppcStack_188 = (code ******)0x43f813;
      pppppppcVar15 = (code *******)__vbaObjSet();
      ppppppcStack_188 = (code ******)0x0;
      ppppppcStack_190 = (code ******)0x43f820;
      ppppppcStack_18c = (code ******)pppppppcVar15;
      pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar15)[0x23])();
      if ((int)pppppppcVar13 < 0) {
        ppppppcStack_190 = (code ******)0x8c;
        ppppppcStack_194 = (code ******)&DAT_0040bb6c;
        ppppppcStack_1a0 = (code ******)0x43f838;
        ppppppcStack_19c = (code ******)pppppppcVar13;
        ppppppcStack_198 = (code ******)pppppppcVar15;
        __vbaHresultCheckObj();
      }
      ppppppcStack_190 = (code ******)0x43f843;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_190 = (code ******)&DAT_0050b420;
        ppppppcStack_194 = (code ******)&DAT_00408c88;
        ppppppcStack_198 = (code ******)0x43f85c;
        __vbaNew2();
      }
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_194 = (code ******)0x43f86a;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43f871;
      pppppppcVar15 = (code *******)__vbaObjSet();
      ppppppcStack_19c = (code ******)0x0;
      ppppppcStack_1a4 = (code ******)0x43f87e;
      ppppppcStack_1a0 = (code ******)pppppppcVar15;
      iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_1a4 = (code ******)0x8c;
        ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
        ppppppcStack_1b4 = (code ******)0x43f896;
        ppppppcStack_1b0 = (code ******)iVar6;
        ppppppcStack_1ac = (code ******)pppppppcVar15;
        __vbaHresultCheckObj();
      }
      ppppppcStack_1a4 = (code ******)0x43f89b;
      __vbaFreeObj();
      local_78[0] = (code *****)0xa;
      local_68[0] = (code *****)0xa;
      local_70 = 0x80020004;
      local_60 = 0x80020004;
      local_90 = L"Optimum";
      local_98 = 8;
      ppppppcStack_1a4 = (code ******)0x43f8d7;
      __vbaVarDup();
      local_80 = (code ******)0x40dfc0;
      local_88 = (code ******)0x8;
      ppppppcStack_1a4 = (code ******)0x43f8ef;
      __vbaVarDup();
      ppppppcStack_1a4 = local_78;
      ppppppcStack_1a8 = local_68;
      ppppppcStack_1ac = local_58;
      ppppppcStack_1b4 = local_48;
      ppppppcStack_1b0 = (code ******)0x40;
      ppppppcStack_1b8 = (code ******)0x43f907;
      Ordinal_595();
LAB_0043f907:
      ppppppcStack_1b8 = local_78;
      __vbaFreeVarList(4,local_48,local_58,local_68);
      goto switchD_0043e64f_caseD_5;
    case 4:
      pppppppcVar14 = unaff_ESI;
      pppppppcVar15 = unaff_EDI;
      while( true ) {
        ppppppcStack_17c = (code ******)0x43f932;
        FUN_004cf810();
        if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
          ppppppcStack_17c = (code ******)0x43f979;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar15 = (code *******)-*(int *)(DAT_0050b19c + 0xe);
          if (*(code ********)(DAT_0050b19c + 0xc) <= pppppppcVar15) {
            ppppppcStack_17c = (code ******)0x43f950;
            __vbaGenerateBoundsError();
          }
          pppppppcVar14 = (code *******)-*(int *)(DAT_0050b19c + 10);
          if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar14) {
            ppppppcStack_17c = (code ******)0x43f964;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)((int)pppppppcVar15 + *(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar14) * 4;
        }
        if (*(float *)(*(int *)(DAT_0050b19c + 6) + iVar6) <= _DAT_00401bc0) break;
        sVar10 = DAT_0050b244;
        if (SCARRY2(DAT_0050b244,1)) goto LAB_00440949;
        ppppppcStack_17c = (code ******)0x43f9af;
        DAT_0050b244 = DAT_0050b244 + 1;
        FUN_004d02a0();
      }
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_17c = (code ******)&DAT_0050b420;
        ppppppcStack_180 = (code ******)&DAT_00408c88;
        ppppppcStack_184 = (code ******)0x43f9cd;
        __vbaNew2();
      }
      ppppppcStack_17c = (code ******)DAT_0050b420;
      ppppppcStack_180 = (code ******)0x43f9db;
      ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      pppppppcVar15 = (code *******)__vbaObjSet_exref;
      ppppppcStack_184 = &local_38;
      ppppppcStack_188 = (code ******)0x43f9e8;
      pppppppcVar13 = (code *******)__vbaObjSet();
      ppppppcStack_188 = (code ******)0x0;
      ppppppcStack_190 = (code ******)0x43f9f5;
      ppppppcStack_18c = (code ******)pppppppcVar13;
      pppppppcVar14 = (code *******)(*(code *)(*pppppppcVar13)[0x23])();
      if ((int)pppppppcVar14 < 0) {
        ppppppcStack_190 = (code ******)0x8c;
        ppppppcStack_194 = (code ******)&DAT_0040bb6c;
        ppppppcStack_1a0 = (code ******)0x43fa0d;
        ppppppcStack_19c = (code ******)pppppppcVar14;
        ppppppcStack_198 = (code ******)pppppppcVar13;
        __vbaHresultCheckObj();
      }
      pppppppcVar13 = (code *******)__vbaFreeObj_exref;
      ppppppcStack_190 = (code ******)0x43fa18;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_190 = (code ******)&DAT_0050b420;
        ppppppcStack_194 = (code ******)&DAT_00408c88;
        ppppppcStack_198 = (code ******)0x43fa31;
        __vbaNew2();
      }
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_194 = (code ******)0x43fa3f;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43fa46;
      pppppppcVar14 = (code *******)__vbaObjSet();
      ppppppcStack_19c = (code ******)0x0;
      ppppppcStack_1a4 = (code ******)0x43fa53;
      ppppppcStack_1a0 = (code ******)pppppppcVar14;
      iVar6 = (*(code *)(*pppppppcVar14)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_1a4 = (code ******)0x8c;
        ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
        ppppppcStack_1b4 = (code ******)0x43fa6b;
        ppppppcStack_1b0 = (code ******)iVar6;
        ppppppcStack_1ac = (code ******)pppppppcVar14;
        __vbaHresultCheckObj();
      }
      ppppppcStack_1a4 = (code ******)0x43fa70;
      __vbaFreeObj();
      local_78[0] = (code *****)0xa;
      local_68[0] = (code *****)0xa;
      pppppppcVar14 = (code *******)0x8;
      local_70 = 0x80020004;
      local_60 = 0x80020004;
      local_80 = (code ******)0x40e260;
      local_88 = (code ******)0x8;
      ppppppcStack_1a4 = (code ******)0x43faa7;
      __vbaVarDup();
      pppppcStack_178 = (code *****)0x40e1f0;
      ppppppcStack_17c = (code ******)CONCAT22(extraout_var_00,DAT_0050b244 + 1);
      sVar10 = DAT_0050b244;
      if (!SCARRY2(DAT_0050b244,1)) {
        ppppppcStack_180 = (code ******)0x43fac4;
        __vbaStrI2();
        ppppppcStack_180 = (code ******)0x43facf;
        ppppppcStack_180 = (code ******)__vbaStrMove();
        ppppppcStack_184 = (code ******)0x43fad6;
        local_40 = __vbaStrCat();
        ppppppcStack_184 = local_78;
        ppppppcStack_188 = local_68;
        ppppppcStack_18c = local_58;
        ppppppcStack_194 = local_48;
        ppppppcStack_190 = (code ******)0x0;
        local_48[0] = (code *****)0x8;
        ppppppcStack_198 = (code ******)0x43faf4;
        Ordinal_595();
        ppppppcStack_198 = (code ******)0x43fafd;
        __vbaFreeStr();
        goto LAB_0043f907;
      }
      break;
    default:
      goto switchD_0043e64f_caseD_5;
    }
    goto LAB_00440949;
  case 8:
    if ((DAT_0050b3d4 == (short *)0x0) || (*DAT_0050b3d4 != 1)) {
      ppppppcStack_17c = (code ******)0x43fb39;
      __vbaGenerateBoundsError();
      pppppppcVar14 = unaff_ESI;
    }
    else {
      pppppppcVar14 = (code *******)-*(int *)(DAT_0050b3d4 + 10);
      if (*(code ********)(DAT_0050b3d4 + 8) <= pppppppcVar14) {
        ppppppcStack_17c = (code ******)0x43fb24;
        __vbaGenerateBoundsError();
      }
    }
    pppppppcVar13 = unaff_EBX;
    pppppppcVar15 = unaff_EDI;
    sVar10 = DAT_0050b244;
    if (!SCARRY2(DAT_0050b332,1)) {
      if ((in_FPUStatusWord & 0xd) != 0) {
        __vbaFPException();
        return;
      }
      ppppppcStack_17c = (code ******)0x43fb81;
      local_28 = __vbaFpI2();
      pppppppcVar14 = (code *******)__vbaLateIdSt_exref;
      while (pppppppcVar13 = (code *******)__vbaI4Var_exref, sVar11 = DAT_0050b244 + 1,
            sVar10 = DAT_0050b244, !SCARRY2(DAT_0050b244,1)) {
        DAT_0050b244 = sVar11;
        if (DAT_0050b3c0 == 1) {
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_17c = (code ******)&DAT_0050b420;
            ppppppcStack_180 = (code ******)&DAT_00408c88;
            ppppppcStack_184 = (code ******)0x43fbcb;
            __vbaNew2();
          }
          ppppppcStack_17c = (code ******)DAT_0050b420;
          ppppppcStack_180 = (code ******)0x43fbd9;
          ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
          ppppppcStack_184 = (code ******)&local_f4;
          ppppppcStack_188 = (code ******)0x43fbe7;
          __vbaObjSet();
          if ((short)local_28 < DAT_0050b244) {
            if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
              ppppppcStack_17c = (code ******)0x43fc43;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              iVar6 = *(int *)(DAT_0050b3d8 + 10);
              pppppppcVar15 = (code *******)-iVar6;
              if (*(code ********)(DAT_0050b3d8 + 8) <= pppppppcVar15) {
                ppppppcStack_17c = (code ******)0x43fc2e;
                __vbaGenerateBoundsError();
              }
              iVar6 = iVar6 * -4;
            }
            if (*(float *)(*(int *)(DAT_0050b3d8 + 6) + iVar6) == _DAT_00401bc0) {
              ppppppcStack_17c = (code ******)0x43fc65;
              FUN_004ed5c0();
              pppppppcVar15 = (code *******)__vbaLateIdCallLd_exref;
              ppppppcStack_17c = (code ******)0x0;
              ppppppcStack_180 = (code ******)0x4;
              ppppppcStack_188 = local_58;
              ppppppcStack_184 = local_f4;
              ppppppcStack_18c = (code ******)0x43fc7c;
              ppppppcStack_17c = (code ******)__vbaLateIdCallLd();
              ppppppcStack_180 = (code ******)0x43fc82;
              iVar6 = __vbaI4Var();
              pppppcStack_178 = (code *****)local_48;
              sVar10 = DAT_0050b244;
              unaff_EDI = (code *******)local_f4;
              if (SBORROW4(iVar6,2)) break;
              ppppppcStack_17c = (code ******)0x43fca4;
              __vbaLateIdCallLd();
              iVar5 = __vbaI4Var();
              sVar10 = -(ushort)(iVar5 == iVar6 + -2);
              pppppppcVar15 = (code *******)CONCAT22((short)((uint)pppppppcVar15 >> 0x10),sVar10);
              unaff_EDI = (code *******)local_48;
              pppppcStack_178 = (code *****)0x2;
              ppppppcStack_17c = (code ******)0x43fccc;
              __vbaFreeVarList();
              if (sVar10 == 0) goto LAB_00440492;
              ppppppcStack_17c = (code ******)0x0;
              ppppppcStack_180 = (code ******)0x4;
              ppppppcStack_188 = local_48;
              ppppppcStack_184 = local_f4;
              ppppppcStack_18c = (code ******)0x43fced;
              ppppppcStack_17c = (code ******)__vbaLateIdCallLd();
              ppppppcStack_180 = (code ******)0x43fcf7;
              iVar6 = __vbaI4Var();
              sVar10 = DAT_0050b244;
              if (SBORROW4(iVar6,1)) break;
              local_88 = (code ******)0x3;
              ppppppcStack_18c = (code ******)0xa;
              ppppppcStack_188 = (code ******)0x3;
              ppppppcStack_184 = local_84;
              ppppppcStack_190 = local_f4;
              ppppppcStack_17c = local_7c;
              ppppppcStack_194 = (code ******)0x43fd2f;
              ppppppcStack_180 = (code ******)(iVar6 + -1);
              local_80 = (code ******)(iVar6 + -1);
              __vbaLateIdSt();
              ppppppcStack_194 = (code ******)0x43fd38;
              __vbaFreeVar();
              pppppppcVar4 = (code *******)0x4;
              while (sVar11 = (short)pppppppcVar4, pppppppcVar15 = pppppppcVar4, sVar11 < 7) {
                local_88 = (code ******)0x3;
                ppppppcStack_18c = (code ******)0xb;
                ppppppcStack_188 = (code ******)0x3;
                pppppppcVar13 = (code *******)(int)sVar11;
                ppppppcStack_184 = local_84;
                ppppppcStack_17c = local_7c;
                ppppppcStack_190 = local_f4;
                ppppppcStack_194 = (code ******)0x43fd7d;
                ppppppcStack_180 = (code ******)pppppppcVar13;
                local_80 = (code ******)pppppppcVar13;
                __vbaLateIdSt();
                ppppppcStack_194 = (code ******)0x0;
                ppppppcStack_198 = (code ******)0x4;
                ppppppcStack_1a0 = local_48;
                ppppppcStack_19c = local_f4;
                ppppppcStack_1a4 = (code ******)0x43fd92;
                ppppppcStack_194 = (code ******)__vbaLateIdCallLd();
                ppppppcStack_198 = (code ******)0x43fd9c;
                iVar6 = __vbaI4Var();
                sVar10 = DAT_0050b244;
                if (SBORROW4(iVar6,1)) goto LAB_00440949;
                local_88 = (code ******)0x3;
                ppppppcStack_188 = (code ******)0x3;
                ppppppcStack_184 = local_84;
                ppppppcStack_17c = local_7c;
                ppppppcStack_198 = (code ******)0x3;
                ppppppcStack_194 = local_a4;
                ppppppcStack_18c = local_9c;
                ppppppcStack_1ac = (code ******)0x2;
                ppppppcStack_1a8 = (code ******)0x8;
                ppppppcStack_1b0 = (code ******)0x41;
                ppppppcStack_1a4 = local_c4;
                ppppppcStack_1a0 = (code ******)0x40e0a8;
                ppppppcStack_19c = local_bc;
                ppppppcStack_1b4 = local_f4;
                ppppppcStack_1b8 = (code ******)0x43fe21;
                ppppppcStack_190 = (code ******)pppppppcVar13;
                ppppppcStack_180 = (code ******)(iVar6 + -1);
                local_80 = (code ******)(iVar6 + -1);
                __vbaLateIdCallSt();
                ppppppcStack_17c = (code ******)0x43fe2d;
                __vbaFreeVar();
                pppppppcVar4 = (code *******)(uint)(ushort)(sVar11 + 1);
                sVar10 = DAT_0050b244;
                if (SCARRY2(sVar11,1)) goto LAB_00440949;
              }
              local_88 = (code ******)0x3;
              ppppppcStack_18c = (code ******)0x30;
              ppppppcStack_188 = (code ******)0x3;
              local_80 = (code ******)0x2;
              ppppppcStack_184 = local_84;
              ppppppcStack_190 = local_f4;
              ppppppcStack_180 = (code ******)0x2;
              ppppppcStack_17c = local_7c;
              ppppppcStack_194 = (code ******)0x43fe76;
              __vbaLateIdSt();
              ppppppcStack_194 = (code ******)0x0;
              ppppppcStack_198 = (code ******)0x4;
              ppppppcStack_1a0 = local_48;
              ppppppcStack_19c = local_f4;
              ppppppcStack_1a4 = (code ******)0x43fe8b;
              ppppppcStack_194 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_198 = (code ******)0x43fe95;
              iVar6 = __vbaI4Var();
              sVar10 = DAT_0050b244;
              if (SBORROW4(iVar6,1)) break;
              local_88 = (code ******)0x3;
              ppppppcStack_188 = (code ******)0x3;
              ppppppcStack_184 = local_84;
              ppppppcStack_19c = (code ******)&DAT_00000001;
              ppppppcStack_1a0 = (code ******)0x3b;
              ppppppcStack_17c = local_7c;
              ppppppcStack_198 = (code ******)0xb;
              ppppppcStack_194 = local_a4;
              ppppppcStack_1a4 = local_f4;
              ppppppcStack_190 = (code ******)0xffffffff;
              ppppppcStack_18c = local_9c;
              ppppppcStack_1a8 = (code ******)0x43fef7;
              ppppppcStack_180 = (code ******)(iVar6 + -1);
              local_80 = (code ******)(iVar6 + -1);
              __vbaLateIdCallSt();
              pppppppcVar15 = (code *******)__vbaFreeVar_exref;
              ppppppcStack_17c = (code ******)0x43ff05;
              __vbaFreeVar();
              pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
              if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
                ppppppcStack_17c = (code ******)0x43ff44;
                iVar6 = __vbaGenerateBoundsError();
              }
              else {
                iVar6 = *(int *)(DAT_0050b3d8 + 10);
                if (*(uint *)(DAT_0050b3d8 + 8) <= (uint)-iVar6) {
                  ppppppcStack_17c = (code ******)0x43ff27;
                  __vbaGenerateBoundsError();
                }
                iVar6 = iVar6 * -4;
                pppppppcVar13 = (code *******)__vbaGenerateBoundsError_exref;
              }
              ppppppcStack_17c = (code ******)0x0;
              ppppppcStack_180 = (code ******)0x4;
              *(undefined4 *)(*(int *)(DAT_0050b3d8 + 6) + iVar6) = 0xc2c60000;
              ppppppcStack_188 = local_48;
              ppppppcStack_184 = local_f4;
              ppppppcStack_18c = (code ******)0x43ff69;
              ppppppcStack_17c = (code ******)__vbaLateIdCallLd();
              ppppppcStack_180 = (code ******)0x43ff73;
              iVar6 = __vbaI4Var();
              sVar10 = DAT_0050b244;
              if (SCARRY4(iVar6,1)) break;
              local_88 = (code ******)0x3;
              ppppppcStack_18c = (code ******)0x4;
              ppppppcStack_188 = (code ******)0x3;
              ppppppcStack_184 = local_84;
              ppppppcStack_190 = local_f4;
              ppppppcStack_17c = local_7c;
              ppppppcStack_194 = (code ******)0x43ffab;
              ppppppcStack_180 = (code ******)(iVar6 + 1);
              local_80 = (code ******)(iVar6 + 1);
              __vbaLateIdSt();
              ppppppcStack_194 = (code ******)0x43ffb0;
              __vbaFreeVar();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x43ffdf;
                (*(code *)pppppppcVar13)();
              }
              else {
                pppppppcVar15 = (code *******)-*(int *)(DAT_0050b3bc + 10);
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x43ffce;
                  (*(code *)pppppppcVar13)();
                }
              }
              pppppppcVar13 = (code *******)__vbaStrCopy_exref;
              ppppppcStack_194 = (code ******)0x43fff7;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x440033;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar15 = (code *******)(1 - *(int *)(DAT_0050b3bc + 10));
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x44001e;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_194 = (code ******)0x440045;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x440081;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar15 = (code *******)(2 - *(int *)(DAT_0050b3bc + 10));
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x44006c;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_194 = (code ******)0x440093;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x4400cf;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar15 = (code *******)(3 - *(int *)(DAT_0050b3bc + 10));
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x4400ba;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_194 = (code ******)0x4400e1;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x44011d;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar15 = (code *******)(4 - *(int *)(DAT_0050b3bc + 10));
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x440108;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_194 = (code ******)0x44012f;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x44016b;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar15 = (code *******)(5 - *(int *)(DAT_0050b3bc + 10));
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x440156;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_194 = (code ******)0x44017d;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (short *)0x0) || (*DAT_0050b3bc != 1)) {
                ppppppcStack_194 = (code ******)0x4401b9;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar15 = (code *******)(6 - *(int *)(DAT_0050b3bc + 10));
                if (*(code ********)(DAT_0050b3bc + 8) <= pppppppcVar15) {
                  ppppppcStack_194 = (code ******)0x4401a4;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_194 = (code ******)0x4401cf;
              __vbaStrCopy();
              ppppppcStack_194 = (code ******)0x0;
              ppppppcStack_198 = (code ******)0x4;
              ppppppcStack_1a0 = local_48;
              ppppppcStack_19c = local_f4;
              ppppppcStack_1a4 = (code ******)0x4401e4;
              ppppppcStack_194 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_198 = (code ******)0x4401ee;
              iVar6 = __vbaI4Var();
              sVar10 = DAT_0050b244;
              if (SBORROW4(iVar6,1)) break;
              local_88 = (code ******)0x3;
              ppppppcStack_18c = (code ******)0xa;
              ppppppcStack_188 = (code ******)0x3;
              ppppppcStack_184 = local_84;
              ppppppcStack_190 = local_f4;
              ppppppcStack_17c = local_7c;
              ppppppcStack_194 = (code ******)0x440226;
              ppppppcStack_180 = (code ******)(iVar6 + -1);
              local_80 = (code ******)(iVar6 + -1);
              __vbaLateIdSt();
              ppppppcStack_194 = (code ******)0x44022f;
              __vbaFreeVar();
              pppppppcVar4 = (code *******)0x0;
              while (pppppppcVar13 = pppppppcVar4, sVar11 = (short)pppppppcVar13, sVar11 < 7) {
                local_88 = (code ******)0x3;
                ppppppcStack_18c = (code ******)0xb;
                ppppppcStack_188 = (code ******)0x3;
                pppppppcVar15 = (code *******)(int)sVar11;
                ppppppcStack_184 = local_84;
                ppppppcStack_17c = local_7c;
                ppppppcStack_190 = local_f4;
                ppppppcStack_194 = (code ******)0x440271;
                ppppppcStack_180 = (code ******)pppppppcVar15;
                local_80 = (code ******)pppppppcVar15;
                __vbaLateIdSt();
                local_88 = (code ******)0x2;
                ppppppcStack_1a4 = (code ******)0x28;
                ppppppcStack_1a0 = (code ******)0x2;
                local_80 = (code ******)0x4;
                ppppppcStack_19c = local_84;
                ppppppcStack_1a8 = local_f4;
                ppppppcStack_198 = (code ******)0x4;
                ppppppcStack_194 = local_7c;
                ppppppcStack_1ac = (code ******)0x4402a5;
                __vbaLateIdSt();
                local_88 = (code ******)0x3;
                ppppppcStack_1b8 = (code ******)0x3;
                local_80 = (code ******)0xffff;
                ppppppcStack_1b4 = local_84;
                ppppppcStack_1b0 = (code ******)0xffff;
                ppppppcStack_1ac = local_7c;
                __vbaLateIdSt(local_f4,0x26);
                local_88 = (code ******)0x3;
                local_80 = (code ******)0xff0000;
                __vbaLateIdSt(local_f4,0x27,3,local_84,0xff0000,local_7c);
                uVar7 = __vbaLateIdCallLd(local_48,local_f4,10,0);
                local_80 = (code ******)__vbaI4Var(uVar7);
                local_88 = (code ******)0x3;
                __vbaAryLock(local_30,DAT_0050b3bc);
                if ((local_30[0] == (short *)0x0) || (*local_30[0] != 1)) {
                  iVar6 = __vbaGenerateBoundsError();
                }
                else {
                  local_dc = (int)pppppppcVar15 - *(int *)(local_30[0] + 10);
                  if (*(uint *)(local_30[0] + 8) <= local_dc) {
                    __vbaGenerateBoundsError();
                  }
                  iVar6 = local_dc << 2;
                }
                __vbaLateIdCallSt(local_f4,0x41,2,0x4008,local_c4,*(int *)(local_30[0] + 6) + iVar6,
                                  local_bc,3,local_a4,pppppppcVar15,local_9c,local_88,local_84,
                                  local_80,local_7c);
                __vbaAryUnlock(local_30);
                __vbaFreeVar();
                pppppppcVar4 = (code *******)(uint)(ushort)(sVar11 + 1);
                sVar10 = DAT_0050b244;
                if (SCARRY2(sVar11,1)) goto LAB_00440949;
              }
              if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
                ppppppcStack_17c = (code ******)0x44047d;
                iVar6 = __vbaGenerateBoundsError();
              }
              else {
                iVar6 = *(int *)(DAT_0050b19c + 0xe);
                if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-iVar6) {
                  ppppppcStack_17c = (code ******)0x44044c;
                  __vbaGenerateBoundsError();
                }
                pppppppcVar15 = (code *******)-*(int *)(DAT_0050b19c + 10);
                if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar15) {
                  ppppppcStack_17c = (code ******)0x440464;
                  __vbaGenerateBoundsError();
                }
                iVar6 = (*(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar15 + -iVar6) * 4;
              }
              *(undefined4 *)(*(int *)(DAT_0050b19c + 6) + iVar6) = 0;
            }
            ppppppcStack_17c = (code ******)0x440492;
            FUN_004ede00();
          }
          else {
            ppppppcStack_17c = (code ******)0x43fbf9;
            FUN_004ebd90();
            if (DAT_0050b3c2 == 0) goto switchD_0043e64f_caseD_5;
          }
LAB_00440492:
          if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
            ppppppcStack_17c = (code ******)0x4404e5;
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b19c + 0xe);
            if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-iVar6) {
              ppppppcStack_17c = (code ******)0x4404b4;
              __vbaGenerateBoundsError();
            }
            pppppppcVar15 = (code *******)-*(int *)(DAT_0050b19c + 10);
            if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar15) {
              ppppppcStack_17c = (code ******)0x4404cc;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar15 + -iVar6) * 4;
          }
          ppppppcStack_17c = (code ******)0x0;
          if (*(float *)(*(int *)(DAT_0050b19c + 6) + iVar6) == (float)(int)(short)DAT_0050b3c4) {
            ppppppcStack_180 = (code ******)0x4;
            ppppppcStack_188 = local_48;
            ppppppcStack_184 = local_f4;
            ppppppcStack_18c = (code ******)0x44053e;
            ppppppcStack_17c = (code ******)__vbaLateIdCallLd();
            pppppppcVar13 = (code *******)__vbaI4Var_exref;
            ppppppcStack_180 = (code ******)0x44054a;
            iVar6 = __vbaI4Var();
            sVar10 = DAT_0050b244;
            if (!SCARRY4(iVar6,1)) {
              local_88 = (code ******)0x3;
              ppppppcStack_18c = (code ******)0x4;
              ppppppcStack_188 = (code ******)0x3;
              ppppppcStack_184 = local_84;
              ppppppcStack_190 = local_f4;
              ppppppcStack_17c = local_7c;
              ppppppcStack_194 = (code ******)0x440582;
              ppppppcStack_180 = (code ******)(iVar6 + 1);
              local_80 = (code ******)(iVar6 + 1);
              __vbaLateIdSt();
              ppppppcStack_194 = (code ******)0x44058b;
              __vbaFreeVar();
              pppppppcVar4 = (code *******)0x0;
              goto LAB_0044058d;
            }
            break;
          }
          ppppppcStack_180 = (code ******)&local_f4;
          ppppppcStack_184 = (code ******)0x440526;
          __vbaObjSetAddref();
        }
      }
    }
    goto LAB_00440949;
  }
switchD_0043e64f_caseD_5:
  local_8 = 0;
  ppppppcStack_17c = (code ******)&LAB_004408fc;
  ppppppcStack_180 = (code ******)&local_f4;
  ppppppcStack_184 = (code ******)&local_f0;
  ppppppcStack_188 = (code ******)local_ec;
  ppppppcStack_18c = (code ******)0x3;
  ppppppcStack_190 = (code ******)0x4408f8;
  __vbaFreeObjList();
  return;
  while( true ) {
    ppppppcStack_17c = (code ******)0x0;
    ppppppcStack_180 = (code ******)0x4;
    ppppppcStack_188 = local_48;
    ppppppcStack_184 = local_f4;
    ppppppcStack_18c = (code ******)0x4405b0;
    ppppppcStack_17c = (code ******)__vbaLateIdCallLd();
    ppppppcStack_180 = (code ******)0x4405b6;
    iVar6 = (*(code *)pppppppcVar13)();
    sVar10 = DAT_0050b244;
    if (SBORROW4(iVar6,1)) break;
    local_88 = (code ******)0x3;
    ppppppcStack_188 = (code ******)0x3;
    ppppppcStack_190 = (code ******)(int)sVar11;
    ppppppcStack_184 = local_84;
    ppppppcStack_17c = local_7c;
    ppppppcStack_198 = (code ******)0x3;
    ppppppcStack_194 = local_a4;
    ppppppcStack_18c = local_9c;
    ppppppcStack_1ac = (code ******)0x2;
    ppppppcStack_1b0 = (code ******)0x41;
    ppppppcStack_1a8 = (code ******)0x8;
    ppppppcStack_1a4 = local_c4;
    ppppppcStack_1a0 = (code ******)0x40e168;
    ppppppcStack_19c = local_bc;
    ppppppcStack_1b4 = local_f4;
    ppppppcStack_1b8 = (code ******)0x44063e;
    ppppppcStack_180 = (code ******)(iVar6 + -1);
    local_80 = (code ******)(iVar6 + -1);
    __vbaLateIdCallSt();
    ppppppcStack_17c = (code ******)0x44064a;
    __vbaFreeVar();
    pppppppcVar13 = (code *******)__vbaI4Var_exref;
    pppppppcVar4 = (code *******)(uint)(ushort)(sVar11 + 1);
    sVar10 = DAT_0050b244;
    if (SCARRY2(sVar11,1)) break;
LAB_0044058d:
    sVar11 = (short)pppppppcVar4;
    pppppppcVar15 = pppppppcVar4;
    if (6 < sVar11) {
      local_88 = (code ******)0x3;
      ppppppcStack_18c = (code ******)0x30;
      ppppppcStack_188 = (code ******)0x3;
      local_80 = (code ******)0x2;
      ppppppcStack_184 = local_84;
      ppppppcStack_190 = local_f4;
      ppppppcStack_180 = (code ******)0x2;
      ppppppcStack_17c = local_7c;
      ppppppcStack_194 = (code ******)0x440699;
      __vbaLateIdSt();
      ppppppcStack_194 = (code ******)0x0;
      ppppppcStack_198 = (code ******)0x4;
      ppppppcStack_1a0 = local_48;
      ppppppcStack_19c = local_f4;
      ppppppcStack_1a4 = (code ******)0x4406ae;
      ppppppcStack_194 = (code ******)__vbaLateIdCallLd();
      ppppppcStack_198 = (code ******)0x4406b4;
      iVar6 = (*(code *)pppppppcVar13)();
      sVar10 = DAT_0050b244;
      if (!SBORROW4(iVar6,1)) {
        local_88 = (code ******)0x3;
        ppppppcStack_188 = (code ******)0x3;
        ppppppcStack_184 = local_84;
        ppppppcStack_19c = (code ******)0x1;
        ppppppcStack_1a0 = (code ******)0x3b;
        ppppppcStack_17c = local_7c;
        ppppppcStack_198 = (code ******)0xb;
        ppppppcStack_194 = local_a4;
        ppppppcStack_1a4 = local_f4;
        ppppppcStack_190 = (code ******)0xffffffff;
        ppppppcStack_18c = local_9c;
        ppppppcStack_1a8 = (code ******)0x440716;
        ppppppcStack_180 = (code ******)(iVar6 + -1);
        local_80 = (code ******)(iVar6 + -1);
        __vbaLateIdCallSt();
        ppppppcStack_17c = (code ******)0x440722;
        __vbaFreeVar();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_17c = (code ******)&DAT_0050b420;
          ppppppcStack_180 = (code ******)&DAT_00408c88;
          ppppppcStack_184 = (code ******)0x44073b;
          __vbaNew2();
        }
        ppppppcStack_17c = (code ******)DAT_0050b420;
        ppppppcStack_180 = (code ******)0x440749;
        ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
        ppppppcStack_184 = &local_38;
        ppppppcStack_188 = (code ******)0x440756;
        piVar16 = (int *)__vbaObjSet();
        ppppppcStack_188 = (code ******)0x0;
        ppppppcStack_190 = (code ******)0x440763;
        ppppppcStack_18c = (code ******)piVar16;
        iVar6 = (**(code **)(*piVar16 + 0x8c))();
        if (iVar6 < 0) {
          ppppppcStack_190 = (code ******)0x8c;
          ppppppcStack_194 = (code ******)&DAT_0040bb6c;
          ppppppcStack_1a0 = (code ******)0x44077d;
          ppppppcStack_19c = (code ******)iVar6;
          ppppppcStack_198 = (code ******)piVar16;
          __vbaHresultCheckObj();
        }
        ppppppcStack_190 = (code ******)0x44078e;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_190 = (code ******)&DAT_0050b420;
          ppppppcStack_194 = (code ******)&DAT_00408c88;
          ppppppcStack_198 = (code ******)0x4407a7;
          __vbaNew2();
        }
        ppppppcStack_190 = (code ******)DAT_0050b420;
        ppppppcStack_194 = (code ******)0x4407b5;
        ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
        ppppppcStack_198 = &local_38;
        ppppppcStack_19c = (code ******)0x4407bc;
        pppppppcVar15 = (code *******)__vbaObjSet();
        ppppppcStack_19c = (code ******)0x0;
        ppppppcStack_1a4 = (code ******)0x4407c9;
        ppppppcStack_1a0 = (code ******)pppppppcVar15;
        iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
        if (iVar6 < 0) {
          ppppppcStack_1a4 = (code ******)0x8c;
          ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
          ppppppcStack_1b4 = (code ******)0x4407dd;
          ppppppcStack_1b0 = (code ******)iVar6;
          ppppppcStack_1ac = (code ******)pppppppcVar15;
          __vbaHresultCheckObj();
        }
        ppppppcStack_1a4 = (code ******)0x4407e6;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_1a4 = (code ******)&DAT_0050b420;
          ppppppcStack_1a8 = (code ******)&DAT_00408c88;
          ppppppcStack_1ac = (code ******)0x4407ff;
          __vbaNew2();
        }
        ppppppcStack_1a4 = (code ******)DAT_0050b420;
        ppppppcStack_1a8 = (code ******)0x44080d;
        ppppppcStack_1a8 = (code ******)(*(code *)(*DAT_0050b420)[0xde])();
        ppppppcStack_1ac = &local_38;
        ppppppcStack_1b0 = (code ******)0x440814;
        pppppppcVar15 = (code *******)__vbaObjSet();
        ppppppcStack_1b0 = (code ******)0xffffffff;
        ppppppcStack_1b8 = (code ******)0x440821;
        ppppppcStack_1b4 = (code ******)pppppppcVar15;
        iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
        if (iVar6 < 0) {
          ppppppcStack_1b8 = (code ******)0x8c;
          __vbaHresultCheckObj(iVar6,pppppppcVar15,&DAT_0040bb6c);
        }
        ppppppcStack_1b8 = (code ******)0x44083e;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_1b8 = (code ******)&DAT_0050b420;
          __vbaNew2(&DAT_00408c88);
        }
        ppppppcStack_1b8 = (code ******)DAT_0050b420;
        uVar7 = (*(code *)(*DAT_0050b420)[0xde])();
        piVar16 = (int *)__vbaObjSet(&local_38,uVar7);
        iVar6 = (**(code **)(*piVar16 + 0x1a4))(piVar16);
        if (iVar6 < 0) {
          __vbaHresultCheckObj(iVar6,piVar16,&DAT_0040bb6c,0x1a4);
        }
        __vbaFreeObj();
        goto switchD_0043e64f_caseD_5;
      }
      break;
    }
  }
  goto LAB_00440949;
  while( true ) {
    ppppppcStack_17c = (code ******)0x43f2f4;
    FUN_004c5770();
    sVar11 = DAT_0050b244 + 1;
    pppppppcVar15 = (code *******)&DAT_00000001;
    sVar10 = DAT_0050b244;
    if (SCARRY2(DAT_0050b244,1)) break;
LAB_0043f2e4:
    DAT_0050b244 = sVar11;
    if ((short)uVar2 < sVar11) {
      local_78[0] = (code *****)0xa;
      local_68[0] = (code *****)0xa;
      local_70 = 0x80020004;
      local_60 = 0x80020004;
      local_90 = L"Optimum";
      local_98 = 8;
      ppppppcStack_17c = (code ******)0x43f342;
      __vbaVarDup();
      local_80 = (code ******)0x40dfc0;
      local_88 = (code ******)0x8;
      ppppppcStack_17c = (code ******)0x43f35a;
      __vbaVarDup();
      ppppppcStack_17c = local_78;
      ppppppcStack_180 = local_68;
      ppppppcStack_184 = local_58;
      ppppppcStack_18c = local_48;
      ppppppcStack_188 = (code ******)0x40;
      ppppppcStack_190 = (code ******)0x43f372;
      Ordinal_595();
      ppppppcStack_190 = local_78;
      ppppppcStack_194 = local_68;
      ppppppcStack_198 = local_58;
      ppppppcStack_19c = local_48;
      ppppppcStack_1a0 = (code ******)0x4;
      ppppppcStack_1a4 = (code ******)0x43f38a;
      __vbaFreeVarList();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_190 = (code ******)&DAT_0050b420;
        ppppppcStack_194 = (code ******)&DAT_00408c88;
        ppppppcStack_198 = (code ******)0x43f3a6;
        __vbaNew2();
      }
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_194 = (code ******)0x43f3b4;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43f3c1;
      pppppppcVar15 = (code *******)__vbaObjSet();
      ppppppcStack_19c = (code ******)0x0;
      ppppppcStack_1a4 = (code ******)0x43f3ce;
      ppppppcStack_1a0 = (code ******)pppppppcVar15;
      iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_1a4 = (code ******)0x8c;
        ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
        ppppppcStack_1b4 = (code ******)0x43f3e6;
        ppppppcStack_1b0 = (code ******)iVar6;
        ppppppcStack_1ac = (code ******)pppppppcVar15;
        __vbaHresultCheckObj();
      }
      pcVar12 = __vbaFreeObj_exref;
      ppppppcStack_1a4 = (code ******)0x43f3f1;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_1a4 = (code ******)&DAT_0050b420;
        ppppppcStack_1a8 = (code ******)&DAT_00408c88;
        ppppppcStack_1ac = (code ******)0x43f40a;
        __vbaNew2();
      }
      ppppppcStack_1a4 = (code ******)DAT_0050b420;
      ppppppcStack_1a8 = (code ******)0x43f418;
      ppppppcStack_1a8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_1ac = &local_38;
      ppppppcStack_1b0 = (code ******)0x43f41f;
      pppppppcVar15 = (code *******)__vbaObjSet();
      ppppppcStack_1b0 = (code ******)0x0;
      ppppppcStack_1b8 = (code ******)0x43f42c;
      ppppppcStack_1b4 = (code ******)pppppppcVar15;
      iVar6 = (*(code *)(*pppppppcVar15)[0x23])();
      goto joined_r0x0043f430;
    }
  }
  goto LAB_00440949;
  while( true ) {
    local_88 = (code ******)0x3;
    ppppppcStack_180 = (code ******)(int)sVar8;
    ppppppcStack_188 = (code ******)0x3;
    ppppppcStack_18c = (code ******)0xa;
    ppppppcStack_184 = local_84;
    ppppppcStack_190 = local_ec[0];
    ppppppcStack_17c = local_7c;
    ppppppcStack_194 = (code ******)0x43eaab;
    local_80 = ppppppcStack_180;
    __vbaLateIdSt();
    local_88 = (code ******)0x3;
    ppppppcStack_1a4 = (code ******)0x26;
    ppppppcStack_1a0 = (code ******)0x3;
    local_80 = (code ******)0xff00;
    ppppppcStack_19c = local_84;
    ppppppcStack_1a8 = local_ec[0];
    ppppppcStack_198 = (code ******)0xff00;
    ppppppcStack_194 = local_7c;
    ppppppcStack_1ac = (code ******)0x43eae3;
    __vbaLateIdSt();
    pppppppcVar4 = (code *******)CONCAT22(extraout_var_01,sVar8 + 1);
    sVar10 = DAT_0050b244;
    if (SCARRY2(sVar8,1)) break;
LAB_0043ea6c:
    pppppppcVar14 = pppppppcVar4;
    sVar8 = (short)pppppppcVar14;
    if ((short)(sVar11 + 5) < sVar8) {
      local_78[0] = (code *****)0xa;
      local_68[0] = (code *****)0xa;
      local_70 = 0x80020004;
      local_60 = 0x80020004;
      local_90 = L"Optimal Tableau";
      local_98 = 8;
      ppppppcStack_17c = (code ******)0x43eb32;
      __vbaVarDup();
      local_80 = (code ******)0x40dd2c;
      local_88 = (code ******)0x8;
      ppppppcStack_17c = (code ******)0x43eb4a;
      __vbaVarDup();
      ppppppcStack_17c = local_78;
      ppppppcStack_180 = local_68;
      ppppppcStack_184 = local_58;
      ppppppcStack_18c = local_48;
      ppppppcStack_188 = (code ******)0x40;
      ppppppcStack_190 = (code ******)0x43eb62;
      Ordinal_595();
      ppppppcStack_190 = local_78;
      ppppppcStack_194 = local_68;
      ppppppcStack_198 = local_58;
      ppppppcStack_19c = local_48;
      ppppppcStack_1a0 = (code ******)0x4;
      ppppppcStack_1a4 = (code ******)0x43eb7a;
      __vbaFreeVarList();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_190 = (code ******)&DAT_0050b420;
        ppppppcStack_194 = (code ******)&DAT_00408c88;
        ppppppcStack_198 = (code ******)0x43eb96;
        __vbaNew2();
      }
      ppppppcStack_190 = (code ******)DAT_0050b420;
      ppppppcStack_194 = (code ******)0x43eba4;
      ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      pppppppcVar15 = (code *******)__vbaObjSet_exref;
      ppppppcStack_198 = &local_38;
      ppppppcStack_19c = (code ******)0x43ebb1;
      pppppppcVar13 = (code *******)__vbaObjSet();
      ppppppcStack_19c = (code ******)0x0;
      ppppppcStack_1a4 = (code ******)0x43ebbe;
      ppppppcStack_1a0 = (code ******)pppppppcVar13;
      iVar6 = (*(code *)(*pppppppcVar13)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_1a4 = (code ******)0x8c;
        ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
        ppppppcStack_1b4 = (code ******)0x43ebd6;
        ppppppcStack_1b0 = (code ******)iVar6;
        ppppppcStack_1ac = (code ******)pppppppcVar13;
        __vbaHresultCheckObj();
      }
      pppppppcVar13 = (code *******)__vbaFreeObj_exref;
      ppppppcStack_1a4 = (code ******)0x43ebe1;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_1a4 = (code ******)&DAT_0050b420;
        ppppppcStack_1a8 = (code ******)&DAT_00408c88;
        ppppppcStack_1ac = (code ******)0x43ebfa;
        __vbaNew2();
      }
      ppppppcStack_1a4 = (code ******)DAT_0050b420;
      ppppppcStack_1a8 = (code ******)0x43ec08;
      ppppppcStack_1a8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_1ac = &local_38;
      ppppppcStack_1b0 = (code ******)0x43ec0f;
      pppppppcVar14 = (code *******)__vbaObjSet();
      ppppppcStack_1b0 = (code ******)0x0;
      ppppppcStack_1b8 = (code ******)0x43ec1c;
      ppppppcStack_1b4 = (code ******)pppppppcVar14;
      iVar6 = (*(code *)(*pppppppcVar14)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_1b8 = (code ******)0x8c;
        __vbaHresultCheckObj(iVar6,pppppppcVar14,&DAT_0040bb6c);
      }
      ppppppcStack_1b8 = (code ******)0x43ec39;
      __vbaFreeObj();
      ppppppcStack_1b8 = (code ******)0x0;
      ppppppcStack_1b8 = (code ******)__vbaLateIdCallLd(local_48,local_ec[0],4);
      iVar6 = __vbaI4Var();
      pppppppcVar4 = (code *******)(iVar6 - DAT_0050b276);
      sVar10 = DAT_0050b244;
      if (!SBORROW4(iVar6,(int)DAT_0050b276)) {
        local_88 = (code ******)0x3;
        ppppppcStack_18c = (code ******)0x4;
        ppppppcStack_188 = (code ******)0x3;
        ppppppcStack_184 = local_84;
        ppppppcStack_190 = local_ec[0];
        ppppppcStack_17c = local_7c;
        ppppppcStack_194 = (code ******)0x43ec9a;
        ppppppcStack_180 = (code ******)pppppppcVar4;
        local_80 = (code ******)pppppppcVar4;
        __vbaLateIdSt();
        ppppppcStack_194 = (code ******)0x43eca3;
        __vbaFreeVar();
        goto switchD_0043e64f_caseD_5;
      }
      break;
    }
  }
LAB_00440949:
  DAT_0050b244 = sVar10;
  ppppppcStack_17c = (code ******)0x44094f;
  __vbaErrorOverflow();
  ppppppcStack_18c = (code ******)&DAT_00402706;
  ppppppcStack_190 = ExceptionList;
  ppppppcStack_188 = (code ******)&ppppppcStack_1b8;
  ppppppcStack_184 = (code ******)&DAT_00401be8;
  ppppppcStack_180 = (code ******)((uint)unaff_EDI & 1);
  piVar16 = (int *)((uint)unaff_EDI & 0xfffffffe);
  ExceptionList = &ppppppcStack_190;
  ppppppcStack_1b8 = (code ******)pppppppcVar15;
  ppppppcStack_1b4 = (code ******)pppppppcVar14;
  ppppppcStack_1b0 = (code ******)pppppppcVar13;
  ppppppcStack_17c = (code ******)&stack0xfffffffc;
  (**(code **)(*piVar16 + 4))(piVar16);
  ppppppcStack_194 = (code ******)0x0;
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar3 = DAT_0050c53c;
  ppppppcStack_1ac = (code ******)*DAT_0050c53c;
  uVar7 = __vbaObjSetAddref(&ppppppcStack_194,piVar16);
  iVar6 = (**(code **)((int)ppppppcStack_1ac + 0x10))(piVar3,uVar7);
  if (iVar6 < 0) {
    __vbaHresultCheckObj(iVar6,piVar3,&DAT_0040b410,0x10);
  }
  __vbaFreeObj();
  DAT_0050b210 = 0;
  DAT_0050b1e0 = 0;
  FUN_00444530();
  if ((DAT_0050b238 == 4) || (DAT_0050b238 == 7)) {
    DAT_0050b206 = 2;
  }
  else {
    DAT_0050b206 = 1;
  }
  DAT_0050b204 = 1;
  FUN_0044a9d0(&DAT_0050b204,&DAT_0050b206);
  return;
}


