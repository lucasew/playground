/* entry 004871a0 name FUN_004871a0 size 5372 */
/* strings:
 * Inverse Matrix:  
 * Nonsingular Matrix -- Inverse does not exist
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004871a0(void)

{
  float ***pppfVar1;
  uint uVar2;
  double dVar3;
  code *pcVar4;
  float ****ppppfVar5;
  float **ppfVar6;
  undefined1 *puVar7;
  short sVar8;
  int iVar9;
  undefined4 uVar10;
  float *****pppppfVar11;
  int iVar12;
  undefined2 extraout_var;
  int *piVar13;
  float *****pppppfVar14;
  float *****pppppfVar15;
  float ****ppppfVar16;
  undefined *puVar17;
  undefined4 *puVar18;
  short sVar19;
  float *****extraout_ECX;
  float *****extraout_ECX_00;
  float *****extraout_ECX_01;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  float *****extraout_ECX_02;
  undefined4 extraout_ECX_03;
  undefined2 uVar21;
  undefined4 extraout_ECX_04;
  undefined4 extraout_ECX_05;
  undefined4 extraout_ECX_06;
  undefined4 extraout_ECX_07;
  undefined4 extraout_ECX_08;
  undefined4 extraout_ECX_09;
  undefined4 extraout_ECX_10;
  undefined4 extraout_ECX_11;
  short *psVar20;
  undefined4 extraout_ECX_12;
  undefined4 extraout_ECX_13;
  undefined4 extraout_ECX_14;
  undefined4 extraout_ECX_15;
  undefined4 extraout_ECX_16;
  code *pcVar22;
  code *pcVar23;
  float ****ppppfVar24;
  bool bVar25;
  ushort uVar26;
  float10 fVar27;
  code *pcStack_778;
  code *pcStack_774;
  code *pcStack_770;
  undefined4 auStack_768 [2];
  wchar_t *pwStack_760;
  undefined4 uStack_758;
  undefined4 uStack_754;
  wchar_t *pwStack_750;
  undefined4 uStack_74c;
  undefined4 auStack_748 [4];
  undefined4 uStack_738;
  int iStack_734;
  float ****ppppfStack_730;
  float ****ppppfStack_72c;
  float ****ppppfStack_728;
  float ****ppppfStack_724;
  float ****ppppfStack_720;
  float ****ppppfStack_71c;
  float ****ppppfStack_718;
  float ****ppppfStack_714;
  float ****ppppfStack_710;
  float ****ppppfStack_70c;
  float ****ppppfStack_708;
  float ****ppppfStack_704;
  float ****ppppfStack_700;
  float ****ppppfStack_6fc;
  float ****ppppfStack_6f8;
  float ****ppppfStack_6f4;
  float ****ppppfStack_6f0;
  float ****ppppfStack_6ec;
  float ****ppppfStack_6e8;
  float ****ppppfStack_6e4;
  float ****ppppfStack_6e0;
  float ****ppppfStack_6dc;
  float ****ppppfStack_6d8;
  float ****ppppfStack_6d4;
  float ****ppppfStack_6d0;
  float ****ppppfStack_6cc;
  float ****ppppfStack_6c8;
  float ****ppppfStack_6c4;
  float ****ppppfStack_6c0;
  float ****ppppfStack_6bc;
  undefined4 *puStack_6b8;
  float ****ppppfStack_6b4;
  float ****ppppfStack_6b0;
  float ****ppppfStack_6ac;
  float ***pppfStack_6a8;
  float ****ppppfStack_6a4;
  float ***pppfStack_6a0;
  float ****ppppfStack_69c;
  float ****ppppfStack_698;
  float ****ppppfStack_694;
  float ***pppfStack_690;
  float ****ppppfStack_68c;
  float ****ppppfStack_688;
  float ****ppppfStack_684;
  float ****ppppfStack_680;
  float ****ppppfStack_67c;
  float ****ppppfStack_678;
  float ****ppppfStack_674;
  float ****ppppfStack_670;
  float ****ppppfStack_66c;
  float ****ppppfStack_668;
  float ****ppppfStack_664;
  float ****ppppfStack_660;
  float ****ppppfStack_65c;
  float ****ppppfStack_658;
  float ****ppppfStack_654;
  float ****ppppfStack_650;
  float ****ppppfStack_64c;
  float ****ppppfStack_648;
  float ****ppppfStack_644;
  float ****ppppfStack_640;
  float ****ppppfStack_63c;
  float ****ppppfStack_638;
  float ****ppppfStack_634;
  float ****ppppfStack_630;
  float ****ppppfStack_62c;
  float ****ppppfStack_628;
  float ****ppppfStack_624;
  float ****ppppfStack_620;
  float ****ppppfStack_61c;
  float ****ppppfStack_618;
  float ****ppppfStack_614;
  float ****ppppfStack_610;
  float ****ppppfStack_60c;
  float ***pppfStack_608;
  float ****ppppfStack_604;
  undefined4 uStack_600;
  undefined4 uStack_5fc;
  undefined *puStack_5f8;
  undefined4 uStack_5f4;
  undefined4 uStack_5f0;
  float ****ppppfStack_5ec;
  undefined4 uStack_5e8;
  float ****ppppfStack_5e4;
  float ***pppfStack_5e0;
  float ****ppppfStack_5dc;
  undefined4 uStack_5d8;
  undefined4 uStack_5d4;
  undefined *puStack_5d0;
  undefined4 uStack_5cc;
  undefined4 uStack_5c8;
  float ****ppppfStack_5c4;
  undefined4 uStack_5c0;
  float ****ppppfStack_5bc;
  float ****ppppfStack_5b8;
  float ****ppppfStack_5b4;
  undefined4 uStack_5b0;
  undefined4 uStack_5ac;
  float ***pppfStack_5a8;
  float ****ppppfStack_5a4;
  float ****ppppfStack_5a0;
  float ****ppppfStack_59c;
  float ****ppppfStack_598;
  float ****ppppfStack_594;
  float ****ppppfStack_590;
  float ****ppppfStack_58c;
  float ****ppppfStack_588;
  float ****ppppfStack_584;
  float ****ppppfStack_580;
  float ****ppppfStack_57c;
  float ****ppppfStack_578;
  float ****ppppfStack_574;
  float ****ppppfStack_570;
  float ****ppppfStack_56c;
  float ****ppppfStack_568;
  float ****ppppfStack_564;
  float ****ppppfStack_560;
  float ****ppppfStack_55c;
  float ****ppppfStack_558;
  float ****ppppfStack_554;
  undefined4 *puStack_550;
  float ****ppppfStack_54c;
  undefined4 uStack_548;
  float ****ppppfStack_544;
  float ****ppppfStack_540;
  float ****ppppfStack_53c;
  float ****ppppfStack_538;
  float ****ppppfStack_534;
  float ****ppppfStack_530;
  float ****ppppfStack_52c;
  undefined4 uStack_528;
  float ***pppfStack_524;
  float ****ppppfStack_520;
  undefined *puStack_51c;
  float ****ppppfStack_518;
  float ****ppppfStack_514;
  float ****ppppfStack_510;
  int **ppiStack_50c;
  undefined4 uStack_508;
  float ****ppppfStack_504;
  undefined4 uStack_500;
  float ***pppfStack_4fc;
  float ****ppppfStack_4f8;
  undefined *puStack_4f4;
  float ****ppppfStack_4f0;
  int *piStack_4ec;
  float ****ppppfStack_4e8;
  undefined4 *puStack_4e4;
  undefined4 uStack_4e0;
  float ****ppppfStack_4dc;
  undefined *puStack_4d8;
  float ****ppppfStack_4d4;
  float ****ppppfStack_4d0;
  float ****ppppfStack_4cc;
  int *piStack_4c8;
  undefined4 uStack_4c4;
  float ****ppppfStack_4c0;
  undefined4 uStack_4bc;
  float ***pppfStack_4b8;
  float ****ppppfStack_4b4;
  undefined *puStack_4b0;
  float ****ppppfStack_4ac;
  int *piStack_4a8;
  float ****ppppfStack_4a4;
  float ****ppppfStack_4a0;
  undefined4 uStack_49c;
  float ***pppfStack_498;
  float ****ppppfStack_494;
  wchar_t *pwStack_490;
  float ****ppppfStack_48c;
  int *piStack_488;
  float ****ppppfStack_484;
  int **ppiStack_480;
  float ****ppppfStack_47c;
  undefined4 uStack_478;
  float ****ppppfStack_474;
  undefined4 uStack_470;
  float ****ppppfStack_46c;
  undefined4 uStack_468;
  float ***pppfStack_464;
  float ****ppppfStack_460;
  undefined *puStack_45c;
  float ****ppppfStack_458;
  int *piStack_454;
  int iStack_450;
  float ****ppppfStack_44c;
  undefined *puStack_448;
  float ****ppppfStack_444;
  int *piStack_440;
  int iStack_43c;
  float ****ppppfStack_438;
  undefined *puStack_434;
  float ****ppppfStack_430;
  int *piStack_42c;
  undefined4 uStack_428;
  float ****ppppfStack_424;
  undefined *puStack_420;
  float ****ppppfStack_41c;
  code *pcStack_418;
  float ****ppppfStack_414;
  code *pcStack_410;
  int iStack_40c;
  float ****ppppfStack_408;
  float ****ppppfStack_404;
  float ****ppppfStack_400;
  float ***pppfStack_3fc;
  undefined8 uStack_3f8;
  int iStack_3f0;
  double dStack_3ec;
  double dStack_3e4;
  int iStack_3dc;
  undefined8 uStack_3d8;
  int iStack_3d0;
  double dStack_3cc;
  float ****ppppfStack_3c4;
  float ****ppppfStack_3c0;
  float ****ppppfStack_3bc;
  undefined4 uStack_3a0;
  short sStack_390;
  undefined4 uStack_388;
  undefined4 uStack_380;
  undefined4 uStack_378;
  undefined4 uStack_370;
  undefined4 uStack_360;
  undefined4 uStack_350;
  float ****ppppfStack_344;
  int *apiStack_340 [8];
  float ****ppppfStack_320;
  uint uStack_31c;
  float ****ppppfStack_318;
  float ****ppppfStack_314;
  float ***pppfStack_310;
  float ****appppfStack_30c [5];
  undefined4 uStack_2f8;
  float ****ppppfStack_2f4;
  float ****ppppfStack_2f0;
  float ****ppppfStack_2ec;
  float ***apppfStack_2e8 [2];
  double dStack_2e0;
  undefined4 uStack_2c8;
  float ****ppppfStack_2c4;
  float ***pppfStack_2bc;
  float ****ppppfStack_2b8;
  float ****ppppfStack_2b4;
  float ****ppppfStack_2b0;
  float ****ppppfStack_2ac;
  float ****ppppfStack_2a8;
  float ****ppppfStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  float ****ppppfStack_294;
  float ****ppppfStack_290;
  float ****ppppfStack_28c;
  float ***pppfStack_288;
  undefined4 uStack_284;
  float ****ppppfStack_280;
  float ***pppfStack_27c;
  float ****ppppfStack_278;
  float ****ppppfStack_274;
  float ****ppppfStack_270;
  float ****ppppfStack_26c;
  float ***pppfStack_268;
  undefined4 uStack_264;
  float ****ppppfStack_260;
  float ****ppppfStack_25c;
  float ****ppppfStack_258;
  undefined4 uStack_254;
  float ****ppppfStack_250;
  float ****ppppfStack_24c;
  float ****ppppfStack_248;
  float ****ppppfStack_244;
  float ****ppppfStack_240;
  float ****ppppfStack_23c;
  float ***pppfStack_238;
  float ****ppppfStack_234;
  float ****ppppfStack_230;
  float ****ppppfStack_22c;
  float ***pppfStack_228;
  float ****ppppfStack_224;
  undefined8 uStack_220;
  float ****ppppfStack_218;
  float ****ppppfStack_214;
  float ***pppfStack_210;
  float ****ppppfStack_20c;
  float ***pppfStack_208;
  float ****ppppfStack_204;
  float ****ppppfStack_200;
  float ****ppppfStack_1fc;
  float ****ppppfStack_1f8;
  float ****ppppfStack_1f4;
  float ****ppppfStack_1f0;
  float ****ppppfStack_1ec;
  float ****ppppfStack_1e8;
  float ****ppppfStack_1e4;
  float ****ppppfStack_1e0;
  float ****ppppfStack_1dc;
  float ****ppppfStack_1d8;
  float ****ppppfStack_1d4;
  float ****ppppfStack_1d0;
  float ****ppppfStack_1cc;
  float ****ppppfStack_1c8;
  float ****ppppfStack_1c4;
  float ****ppppfStack_1c0;
  float ***pppfStack_1bc;
  float ****ppppfStack_1b8;
  float ****ppppfStack_1b4;
  float ***pppfStack_1b0;
  float ****ppppfStack_1ac;
  float ****ppppfStack_1a8;
  float ****ppppfStack_1a4;
  undefined4 uStack_1a0;
  float ****ppppfStack_19c;
  float ****ppppfStack_198;
  float ****ppppfStack_194;
  float ***pppfStack_190;
  float ****ppppfStack_18c;
  float ****ppppfStack_188;
  undefined *puStack_184;
  float ****ppppfStack_180;
  float ****ppppfStack_17c;
  float ****ppppfStack_178;
  undefined4 uStack_174;
  float ****ppppfStack_170;
  float ****ppppfStack_16c;
  float ***pppfStack_168;
  float ****ppppfStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined *puStack_158;
  undefined4 uStack_154;
  float ***pppfStack_150;
  float ****ppppfStack_14c;
  undefined *puStack_148;
  float ****ppppfStack_144;
  float ****ppppfStack_140;
  float ****ppppfStack_13c;
  float ****ppppfStack_138;
  float ****ppppfStack_134;
  float ***pppfStack_130;
  float ****ppppfStack_12c;
  float ****ppppfStack_128;
  float ***local_cc;
  float ***local_c8;
  float ***local_c4;
  float **local_c0 [2];
  int local_b8;
  float **local_b0 [2];
  wchar_t *local_a8;
  float ***local_a0 [2];
  undefined *local_98;
  float ****local_90;
  float ****local_8c;
  float ****local_88;
  float ****local_84;
  float ***local_80 [4];
  float ***local_70 [2];
  undefined4 local_68;
  float ***local_60 [4];
  float ***local_50 [4];
  float ***local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  float ****local_30;
  float ****local_2c;
  undefined4 local_28;
  float ***local_24 [2];
  undefined4 local_1c;
  float **local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined1 *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffedc;
  local_8 = &LAB_004020f8;
  local_18 = (float **)0x0;
  local_1c = 0;
  local_24[0] = (float ***)0x0;
  local_28 = 0;
  local_2c = (float ****)0x0;
  local_30 = (float ****)0x0;
  local_40 = (float ***)0x0;
  local_50[0] = (float ***)0x0;
  local_60[0] = (float ***)0x0;
  local_70[0] = (float ***)0x0;
  local_80[0] = (float ***)0x0;
  local_90 = (float ****)0x0;
  local_a0[0] = (float ***)0x0;
  local_b0[0] = (float **)0x0;
  local_c0[0] = (float **)0x0;
  local_c4 = (float ***)0x0;
  local_c8 = (float ***)0x0;
  local_cc = (float ***)0x0;
  ExceptionList = &pvStack_14;
  puVar7 = &stack0xfffffedc;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_128 = (float ****)&DAT_0050c53c;
    ppppfStack_12c = (float ****)&DAT_0040b420;
    pppfStack_130 = (float ***)0x487232;
    ExceptionList = &pvStack_14;
    __vbaNew2();
    puVar7 = local_c;
  }
  local_c = puVar7;
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_128 = (float ****)&local_2c;
  ppppfStack_12c = (float ****)DAT_0050c53c;
  pppfStack_130 = (float ***)0x487242;
  iVar9 = (*(code *)(*DAT_0050c53c)[8])();
  if (iVar9 < 0) {
    pppfStack_130 = (float ***)0x20;
    ppppfStack_134 = (float ****)&DAT_0040b410;
    ppppfStack_138 = (float ****)pppppfVar14;
    ppppfStack_140 = (float ****)0x487257;
    ppppfStack_13c = (float ****)iVar9;
    __vbaHresultCheckObj();
  }
  ppppfStack_134 = (float ****)&local_30;
  pppfStack_130 = (float ***)local_2c;
  local_2c = (float ****)0x0;
  ppppfStack_138 = (float ****)0x487268;
  __vbaObjSet();
  ppppfStack_138 = (float ****)&local_30;
  ppppfStack_13c = (float ****)0x487271;
  FUN_0048c990();
  ppppfStack_13c = (float ****)0x48727a;
  __vbaFreeObj();
  local_88 = (float ****)0x8;
  local_90 = (float ****)0x2;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_13c = (float ****)&DAT_0050c53c;
    ppppfStack_140 = (float ****)&DAT_0040b420;
    ppppfStack_144 = (float ****)0x4872a7;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_13c = (float ****)&local_2c;
  ppppfStack_140 = (float ****)DAT_0050c53c;
  ppppfStack_144 = (float ****)0x4872b7;
  pppfStack_150 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)pppfStack_150 < 0) {
    ppppfStack_144 = (float ****)0x20;
    puStack_148 = &DAT_0040b410;
    ppppfStack_14c = (float ****)pppppfVar14;
    uStack_154 = 0x4872cc;
    __vbaHresultCheckObj();
  }
  uStack_154 = 2;
  puStack_158 = &DAT_0040eb6c;
  pppfStack_150 = (float ***)local_90;
  uStack_15c = 0;
  uStack_160 = 0x10028;
  ppppfStack_14c = local_8c;
  puStack_148 = (undefined *)local_88;
  pppfStack_168 = (float ***)&local_40;
  ppppfStack_144 = local_84;
  ppppfStack_164 = local_2c;
  ppppfStack_16c = (float ****)0x48730d;
  uStack_15c = __vbaLateIdCallLd();
  uStack_160 = 0x487317;
  uStack_160 = __vbaCastObjVar();
  ppppfStack_164 = (float ****)&local_30;
  pppfStack_168 = (float ***)0x487322;
  pppfStack_168 = (float ***)__vbaObjSet();
  ppppfStack_16c = (float ****)0x48732b;
  __vbaLateIdSt();
  pcVar22 = __vbaFreeObjList_exref;
  ppppfStack_16c = (float ****)&local_30;
  ppppfStack_170 = (float ****)&local_2c;
  uStack_174 = 2;
  ppppfStack_178 = (float ****)0x48733d;
  __vbaFreeObjList();
  ppppfStack_16c = (float ****)0x487349;
  __vbaFreeVar();
  ppppfStack_16c = (float ****)0x48734e;
  local_38 = FUN_0044fdc0();
  local_40 = (float ***)0x8;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_16c = (float ****)&DAT_0050c53c;
    ppppfStack_170 = (float ****)&DAT_0040b420;
    uStack_174 = 0x487371;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_16c = (float ****)&local_2c;
  ppppfStack_170 = (float ****)DAT_0050c53c;
  uStack_174 = 0x487381;
  ppppfStack_180 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_180 < 0) {
    uStack_174 = 0x20;
    ppppfStack_178 = (float ****)&DAT_0040b410;
    ppppfStack_17c = (float ****)pppppfVar14;
    puStack_184 = (undefined *)0x487396;
    __vbaHresultCheckObj();
  }
  puStack_184 = (undefined *)0x1;
  ppppfStack_188 = (float ****)0x2000b;
  ppppfStack_180 = (float ****)local_40;
  ppppfStack_17c = (float ****)local_3c;
  ppppfStack_178 = (float ****)local_38;
  pppfStack_190 = (float ***)local_50;
  uStack_174 = local_34;
  ppppfStack_18c = local_2c;
  ppppfStack_194 = (float ****)0x4873c7;
  uStack_174 = __vbaLateIdCallLd();
  ppppfStack_178 = (float ****)0x4873d1;
  __vbaR4Var();
  ppppfStack_178 = (float ****)0x4873d7;
  DAT_0050b26c = __vbaFpI4();
  ppppfStack_178 = (float ****)0x4873e5;
  __vbaFreeObj();
  ppppfStack_178 = local_50;
  ppppfStack_17c = &local_40;
  ppppfStack_180 = (float ****)0x2;
  puStack_184 = (undefined *)0x4873f5;
  __vbaFreeVarList();
  ppppfStack_178 = (float ****)0x487409;
  __vbaStrCopy();
  ppppfStack_178 = (float ****)0x487424;
  __vbaStrCopy();
  ppppfStack_178 = (float ****)0x487429;
  FUN_004d5050();
  ppppfStack_178 = (float ****)0x487433;
  __vbaStrCopy();
  local_88 = (float ****)0x44960000;
  local_90 = (float ****)0x4;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_178 = (float ****)&DAT_0050c53c;
    ppppfStack_17c = (float ****)&DAT_0040b420;
    ppppfStack_180 = (float ****)0x487460;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_178 = (float ****)&local_2c;
  ppppfStack_17c = (float ****)DAT_0050c53c;
  ppppfStack_180 = (float ****)0x487470;
  ppppfStack_18c = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_18c < 0) {
    ppppfStack_180 = (float ****)0x20;
    puStack_184 = &DAT_0040b410;
    ppppfStack_188 = (float ****)pppppfVar14;
    pppfStack_190 = (float ***)0x487485;
    __vbaHresultCheckObj();
  }
  pppfStack_190 = (float ***)0x1000a;
  ppppfStack_18c = local_90;
  ppppfStack_188 = local_8c;
  puStack_184 = (undefined *)local_88;
  ppppfStack_180 = local_84;
  ppppfStack_194 = local_2c;
  ppppfStack_198 = (float ****)0x4874b5;
  __vbaLateIdSt();
  ppppfStack_198 = (float ****)0x4874be;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_198 = (float ****)&DAT_0050c53c;
    ppppfStack_19c = (float ****)&DAT_0040b420;
    uStack_1a0 = 0x4874d7;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_198 = (float ****)&local_2c;
  ppppfStack_19c = (float ****)DAT_0050c53c;
  uStack_1a0 = 0x4874e7;
  ppppfStack_1ac = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  uVar26 = 0;
  if ((int)ppppfStack_1ac < 0) {
    uStack_1a0 = 0x20;
    ppppfStack_1a4 = (float ****)&DAT_0040b410;
    ppppfStack_1a8 = (float ****)pppppfVar14;
    pppfStack_1b0 = (float ***)0x4874fc;
    __vbaHresultCheckObj();
  }
  uStack_1a0 = 0;
  ppppfStack_1a4 = (float ****)0x1000b;
  ppppfStack_1ac = &local_40;
  ppppfStack_1a8 = local_2c;
  pppfStack_1b0 = (float ***)0x487511;
  uStack_1a0 = __vbaLateIdCallLd();
  ppppfStack_1a4 = (float ****)0x48751b;
  fVar27 = (float10)__vbaR4Var();
  local_90 = (float ****)0x4;
  local_88 = (float ****)(float)(fVar27 + (float10)DAT_0050b26c);
  if ((uVar26 & 0xd) != 0) {
LAB_004886de:
    __vbaFPException();
    return;
  }
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1a4 = (float ****)&DAT_0050c53c;
    ppppfStack_1a8 = (float ****)&DAT_0040b420;
    ppppfStack_1ac = (float ****)0x487560;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1a4 = (float ****)&local_30;
  ppppfStack_1a8 = (float ****)DAT_0050c53c;
  ppppfStack_1ac = (float ****)0x487570;
  ppppfStack_1b8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_1b8 < 0) {
    ppppfStack_1ac = (float ****)0x20;
    pppfStack_1b0 = (float ***)&DAT_0040b410;
    ppppfStack_1b4 = (float ****)pppppfVar14;
    pppfStack_1bc = (float ***)0x487585;
    __vbaHresultCheckObj();
  }
  pppfStack_1bc = (float ***)0x1000b;
  ppppfStack_1b8 = local_90;
  ppppfStack_1b4 = local_8c;
  pppfStack_1b0 = (float ***)local_88;
  ppppfStack_1ac = local_84;
  ppppfStack_1c0 = local_30;
  ppppfStack_1c4 = (float ****)0x4875b5;
  __vbaLateIdSt();
  ppppfStack_1c4 = (float ****)&local_30;
  ppppfStack_1c8 = (float ****)&local_2c;
  ppppfStack_1cc = (float ****)0x2;
  ppppfStack_1d0 = (float ****)0x4875c1;
  __vbaFreeObjList();
  ppppfStack_1c4 = (float ****)0x4875cd;
  __vbaFreeVar();
  local_88 = (float ****)0xffffffff;
  local_90 = (float ****)0xb;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1c4 = (float ****)&DAT_0050c53c;
    ppppfStack_1c8 = (float ****)&DAT_0040b420;
    ppppfStack_1cc = (float ****)0x4875fa;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1c4 = (float ****)&local_2c;
  ppppfStack_1c8 = (float ****)DAT_0050c53c;
  ppppfStack_1cc = (float ****)0x48760a;
  ppppfStack_1d8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_1d8 < 0) {
    ppppfStack_1cc = (float ****)0x20;
    ppppfStack_1d0 = (float ****)&DAT_0040b410;
    ppppfStack_1d4 = (float ****)pppppfVar14;
    ppppfStack_1dc = (float ****)0x48761f;
    __vbaHresultCheckObj();
  }
  ppppfStack_1dc = (float ****)0x3;
  ppppfStack_1e0 = (float ****)&DAT_0040eb6c;
  ppppfStack_1d8 = local_90;
  ppppfStack_1e4 = (float ****)0x0;
  ppppfStack_1e8 = (float ****)0x10028;
  ppppfStack_1d4 = local_8c;
  ppppfStack_1d0 = local_88;
  ppppfStack_1f0 = &local_40;
  ppppfStack_1cc = local_84;
  ppppfStack_1ec = local_2c;
  ppppfStack_1f4 = (float ****)0x487660;
  ppppfStack_1e4 = (float ****)__vbaLateIdCallLd();
  ppppfStack_1e8 = (float ****)0x48766a;
  ppppfStack_1e8 = (float ****)__vbaCastObjVar();
  ppppfStack_1ec = (float ****)&local_30;
  ppppfStack_1f0 = (float ****)0x487675;
  ppppfStack_1f0 = (float ****)__vbaObjSet();
  ppppfStack_1f4 = (float ****)0x487678;
  __vbaLateIdSt();
  ppppfStack_1f4 = (float ****)&local_30;
  ppppfStack_1f8 = (float ****)&local_2c;
  ppppfStack_1fc = (float ****)0x2;
  ppppfStack_200 = (float ****)0x487684;
  __vbaFreeObjList();
  ppppfStack_1f4 = (float ****)0x487690;
  __vbaFreeVar();
  if (DAT_0050b238 == 1) {
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_1f4 = (float ****)&DAT_0050c53c;
      ppppfStack_1f8 = (float ****)&DAT_0040b420;
      ppppfStack_1fc = (float ****)0x4876b3;
      __vbaNew2();
    }
    pppppfVar14 = DAT_0050c53c;
    ppppfStack_1f4 = (float ****)&local_2c;
    ppppfStack_1f8 = (float ****)DAT_0050c53c;
    ppppfStack_1fc = (float ****)0x4876c3;
    pppfStack_208 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
    if ((int)pppfStack_208 < 0) {
      ppppfStack_1fc = (float ****)0x20;
      ppppfStack_200 = (float ****)&DAT_0040b410;
      ppppfStack_204 = (float ****)pppppfVar14;
      ppppfStack_20c = (float ****)0x4876d8;
      __vbaHresultCheckObj();
    }
    ppppfStack_1fc = (float ****)0x411528;
  }
  else {
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_1f4 = (float ****)&DAT_0050c53c;
      ppppfStack_1f8 = (float ****)&DAT_0040b420;
      ppppfStack_1fc = (float ****)0x4876f3;
      __vbaNew2();
    }
    pppppfVar14 = DAT_0050c53c;
    ppppfStack_1f4 = (float ****)&local_2c;
    ppppfStack_1f8 = (float ****)DAT_0050c53c;
    ppppfStack_1fc = (float ****)0x487703;
    pppfStack_208 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
    if ((int)pppfStack_208 < 0) {
      ppppfStack_1fc = (float ****)0x20;
      ppppfStack_200 = (float ****)&DAT_0040b410;
      ppppfStack_204 = (float ****)pppppfVar14;
      ppppfStack_20c = (float ****)0x487718;
      __vbaHresultCheckObj();
    }
    ppppfStack_1fc = (float ****)0x411550;
  }
  ppppfStack_200 = local_2c;
  ppppfStack_204 = (float ****)&DAT_0040bf08;
  pppfStack_208 = (float ***)0x48772c;
  __vbaPrintObj();
  ppppfStack_1fc = (float ****)0x487738;
  __vbaFreeObj();
  local_88 = (float ****)0x0;
  local_90 = (float ****)0xb;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1fc = (float ****)&DAT_0050c53c;
    ppppfStack_200 = (float ****)&DAT_0040b420;
    ppppfStack_204 = (float ****)0x487765;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1fc = (float ****)&local_2c;
  ppppfStack_200 = (float ****)DAT_0050c53c;
  ppppfStack_204 = (float ****)0x487775;
  pppfStack_210 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)pppfStack_210 < 0) {
    ppppfStack_204 = (float ****)0x20;
    pppfStack_208 = (float ***)&DAT_0040b410;
    ppppfStack_20c = (float ****)pppppfVar14;
    ppppfStack_214 = (float ****)0x48778a;
    __vbaHresultCheckObj();
  }
  ppppfStack_214 = (float ****)0x3;
  ppppfStack_218 = (float ****)&DAT_0040eb6c;
  pppfStack_210 = (float ***)local_90;
  uStack_220 = 3.23988487916856e-319;
  ppppfStack_20c = local_8c;
  pppfStack_208 = (float ***)local_88;
  pppfStack_228 = (float ***)&local_40;
  ppppfStack_204 = local_84;
  ppppfStack_224 = local_2c;
  ppppfStack_22c = (float ****)0x4877cb;
  uStack_220._4_4_ = __vbaLateIdCallLd();
  uStack_220._0_4_ = 0x4877d5;
  uVar10 = __vbaCastObjVar();
  ppppfStack_224 = (float ****)&local_30;
  uStack_220 = (double)CONCAT44(uStack_220._4_4_,uVar10);
  pppfStack_228 = (float ***)0x4877e0;
  pppfStack_228 = (float ***)__vbaObjSet();
  ppppfStack_22c = (float ****)0x4877e3;
  __vbaLateIdSt();
  ppppfStack_22c = (float ****)&local_30;
  ppppfStack_230 = (float ****)&local_2c;
  ppppfStack_234 = (float ****)0x2;
  pppfStack_238 = (float ***)0x4877ef;
  __vbaFreeObjList();
  ppppfStack_22c = (float ****)0x4877fb;
  __vbaFreeVar();
  ppppfStack_22c = &local_c4;
  ppppfStack_230 = &local_cc;
  ppppfStack_234 = &local_c8;
  pppfStack_238 = (float ***)&DAT_0050b0cc;
  local_c4 = (float ***)0x0;
  local_cc = (float ***)&DAT_0050b078;
  local_c8 = (float ***)&DAT_0050b054;
  ppppfStack_23c = (float ****)0x487838;
  FUN_0048cdf0();
  local_88 = (float ****)0x44960000;
  local_90 = (float ****)0x4;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_23c = (float ****)&DAT_0050c53c;
    ppppfStack_240 = (float ****)&DAT_0040b420;
    ppppfStack_244 = (float ****)0x487865;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_23c = (float ****)&local_2c;
  ppppfStack_240 = (float ****)DAT_0050c53c;
  ppppfStack_244 = (float ****)0x487875;
  ppppfStack_250 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_250 < 0) {
    ppppfStack_244 = (float ****)0x20;
    ppppfStack_248 = (float ****)&DAT_0040b410;
    ppppfStack_24c = (float ****)pppppfVar14;
    uStack_254 = 0x48788a;
    __vbaHresultCheckObj();
  }
  uStack_254 = 0x1000a;
  ppppfStack_250 = local_90;
  ppppfStack_24c = local_8c;
  ppppfStack_248 = local_88;
  ppppfStack_244 = local_84;
  ppppfStack_258 = local_2c;
  ppppfStack_25c = (float ****)0x4878ba;
  __vbaLateIdSt();
  ppppfStack_25c = (float ****)0x4878c3;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_25c = (float ****)&DAT_0050c53c;
    ppppfStack_260 = (float ****)&DAT_0040b420;
    uStack_264 = 0x4878dc;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_25c = (float ****)&local_2c;
  ppppfStack_260 = (float ****)DAT_0050c53c;
  uStack_264 = 0x4878ec;
  ppppfStack_270 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  uVar26 = 0;
  if ((int)ppppfStack_270 < 0) {
    uStack_264 = 0x20;
    pppfStack_268 = (float ***)&DAT_0040b410;
    ppppfStack_26c = (float ****)pppppfVar14;
    ppppfStack_274 = (float ****)0x487901;
    __vbaHresultCheckObj();
  }
  uStack_264 = 0;
  pppfStack_268 = (float ***)0x1000b;
  ppppfStack_270 = &local_40;
  ppppfStack_26c = local_2c;
  ppppfStack_274 = (float ****)0x487916;
  uStack_264 = __vbaLateIdCallLd();
  pppfStack_268 = (float ***)0x487920;
  fVar27 = (float10)__vbaR4Var();
  local_90 = (float ****)0x4;
  local_88 = (float ****)(float)(fVar27 + (float10)DAT_0050b26c);
  if ((uVar26 & 0xd) != 0) goto LAB_004886de;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1a4 = (float ****)&DAT_0050c53c;
    ppppfStack_1a8 = (float ****)&DAT_0040b420;
    ppppfStack_1ac = (float ****)0x487965;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1a4 = (float ****)&local_30;
  ppppfStack_1a8 = (float ****)DAT_0050c53c;
  ppppfStack_1ac = (float ****)0x487975;
  ppppfStack_1b8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_1b8 < 0) {
    ppppfStack_1ac = (float ****)0x20;
    pppfStack_1b0 = (float ***)&DAT_0040b410;
    ppppfStack_1b4 = (float ****)pppppfVar14;
    pppfStack_1bc = (float ***)0x48798a;
    __vbaHresultCheckObj();
  }
  pppfStack_1bc = (float ***)0x1000b;
  ppppfStack_1b8 = local_90;
  ppppfStack_1b4 = local_8c;
  pppfStack_1b0 = (float ***)local_88;
  ppppfStack_1ac = local_84;
  ppppfStack_1c0 = local_30;
  ppppfStack_1c4 = (float ****)0x4879ba;
  __vbaLateIdSt();
  ppppfStack_1c4 = (float ****)&local_30;
  ppppfStack_1c8 = (float ****)&local_2c;
  ppppfStack_1cc = (float ****)0x2;
  ppppfStack_1d0 = (float ****)0x4879c6;
  __vbaFreeObjList();
  ppppfStack_1c4 = (float ****)0x4879d2;
  __vbaFreeVar();
  local_88 = (float ****)0xffffffff;
  local_90 = (float ****)0xb;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1c4 = (float ****)&DAT_0050c53c;
    ppppfStack_1c8 = (float ****)&DAT_0040b420;
    ppppfStack_1cc = (float ****)0x4879ff;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1c4 = (float ****)&local_2c;
  ppppfStack_1c8 = (float ****)DAT_0050c53c;
  ppppfStack_1cc = (float ****)0x487a0f;
  ppppfStack_1d8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_1d8 < 0) {
    ppppfStack_1cc = (float ****)0x20;
    ppppfStack_1d0 = (float ****)&DAT_0040b410;
    ppppfStack_1d4 = (float ****)pppppfVar14;
    ppppfStack_1dc = (float ****)0x487a24;
    __vbaHresultCheckObj();
  }
  ppppfStack_1dc = (float ****)0x3;
  ppppfStack_1e0 = (float ****)&DAT_0040eb6c;
  ppppfStack_1d8 = local_90;
  ppppfStack_1e4 = (float ****)0x0;
  ppppfStack_1e8 = (float ****)0x10028;
  ppppfStack_1d4 = local_8c;
  ppppfStack_1d0 = local_88;
  ppppfStack_1f0 = &local_40;
  ppppfStack_1cc = local_84;
  ppppfStack_1ec = local_2c;
  ppppfStack_1f4 = (float ****)0x487a65;
  ppppfStack_1e4 = (float ****)__vbaLateIdCallLd();
  ppppfStack_1e8 = (float ****)0x487a6f;
  ppppfStack_1e8 = (float ****)__vbaCastObjVar();
  ppppfStack_1ec = (float ****)&local_30;
  ppppfStack_1f0 = (float ****)0x487a7a;
  ppppfStack_1f0 = (float ****)__vbaObjSet();
  ppppfStack_1f4 = (float ****)0x487a7d;
  __vbaLateIdSt();
  ppppfStack_1f4 = (float ****)&local_30;
  ppppfStack_1f8 = (float ****)&local_2c;
  ppppfStack_1fc = (float ****)0x2;
  ppppfStack_200 = (float ****)0x487a89;
  __vbaFreeObjList();
  ppppfStack_1f4 = (float ****)0x487a95;
  __vbaFreeVar();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1f4 = (float ****)&DAT_0050c53c;
    ppppfStack_1f8 = (float ****)&DAT_0040b420;
    ppppfStack_1fc = (float ****)0x487aae;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1f4 = (float ****)&local_2c;
  ppppfStack_1f8 = (float ****)DAT_0050c53c;
  ppppfStack_1fc = (float ****)0x487abe;
  pppfStack_208 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)pppfStack_208 < 0) {
    ppppfStack_1fc = (float ****)0x20;
    ppppfStack_200 = (float ****)&DAT_0040b410;
    ppppfStack_204 = (float ****)pppppfVar14;
    ppppfStack_20c = (float ****)0x487ad3;
    __vbaHresultCheckObj();
  }
  ppppfStack_1fc = (float ****)0x4112f8;
  ppppfStack_200 = local_2c;
  ppppfStack_204 = (float ****)&DAT_00411320;
  pppfStack_208 = (float ***)0x487ae7;
  __vbaPrintObj();
  ppppfStack_1fc = (float ****)0x487af3;
  __vbaFreeObj();
  local_88 = (float ****)0x0;
  local_90 = (float ****)0xb;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1fc = (float ****)&DAT_0050c53c;
    ppppfStack_200 = (float ****)&DAT_0040b420;
    ppppfStack_204 = (float ****)0x487b20;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1fc = (float ****)&local_2c;
  ppppfStack_200 = (float ****)DAT_0050c53c;
  ppppfStack_204 = (float ****)0x487b30;
  pppfStack_210 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)pppfStack_210 < 0) {
    ppppfStack_204 = (float ****)0x20;
    pppfStack_208 = (float ***)&DAT_0040b410;
    ppppfStack_20c = (float ****)pppppfVar14;
    ppppfStack_214 = (float ****)0x487b45;
    __vbaHresultCheckObj();
  }
  ppppfStack_214 = (float ****)0x3;
  ppppfStack_218 = (float ****)&DAT_0040eb6c;
  pppfStack_210 = (float ***)local_90;
  uStack_220 = 3.23988487916856e-319;
  ppppfStack_20c = local_8c;
  pppfStack_208 = (float ***)local_88;
  pppfStack_228 = (float ***)&local_40;
  ppppfStack_204 = local_84;
  ppppfStack_224 = local_2c;
  ppppfStack_22c = (float ****)0x487b86;
  uStack_220._4_4_ = __vbaLateIdCallLd();
  uStack_220._0_4_ = 0x487b90;
  uVar10 = __vbaCastObjVar();
  uStack_220 = (double)CONCAT44(uStack_220._4_4_,uVar10);
  ppppfStack_224 = (float ****)&local_30;
  pppfStack_228 = (float ***)0x487b9b;
  pppfStack_228 = (float ***)__vbaObjSet();
  ppppfStack_22c = (float ****)0x487b9e;
  __vbaLateIdSt();
  ppppfStack_22c = (float ****)&local_30;
  ppppfStack_230 = (float ****)&local_2c;
  ppppfStack_234 = (float ****)0x2;
  pppfStack_238 = (float ***)0x487baa;
  __vbaFreeObjList();
  ppppfStack_22c = (float ****)0x487bb6;
  __vbaFreeVar();
  local_88 = (float ****)0x44960000;
  local_90 = (float ****)0x4;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_22c = (float ****)&DAT_0050c53c;
    ppppfStack_230 = (float ****)&DAT_0040b420;
    ppppfStack_234 = (float ****)0x487be3;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_22c = (float ****)&local_2c;
  ppppfStack_230 = (float ****)DAT_0050c53c;
  ppppfStack_234 = (float ****)0x487bf3;
  ppppfStack_240 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_240 < 0) {
    ppppfStack_234 = (float ****)0x20;
    pppfStack_238 = (float ***)&DAT_0040b410;
    ppppfStack_23c = (float ****)pppppfVar14;
    ppppfStack_244 = (float ****)0x487c08;
    __vbaHresultCheckObj();
  }
  ppppfStack_244 = (float ****)0x1000a;
  ppppfStack_240 = local_90;
  ppppfStack_23c = local_8c;
  pppfStack_238 = (float ***)local_88;
  ppppfStack_234 = local_84;
  ppppfStack_248 = local_2c;
  ppppfStack_24c = (float ****)0x487c38;
  __vbaLateIdSt();
  ppppfStack_24c = (float ****)0x487c41;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_24c = (float ****)&DAT_0050c53c;
    ppppfStack_250 = (float ****)&DAT_0040b420;
    uStack_254 = 0x487c5a;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_24c = (float ****)&local_2c;
  ppppfStack_250 = (float ****)DAT_0050c53c;
  uStack_254 = 0x487c6a;
  ppppfStack_260 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  uVar26 = 0;
  if ((int)ppppfStack_260 < 0) {
    uStack_254 = 0x20;
    ppppfStack_258 = (float ****)&DAT_0040b410;
    ppppfStack_25c = (float ****)pppppfVar14;
    uStack_264 = 0x487c7f;
    __vbaHresultCheckObj();
  }
  uStack_254 = 0;
  ppppfStack_258 = (float ****)0x1000b;
  ppppfStack_260 = &local_40;
  ppppfStack_25c = local_2c;
  uStack_264 = 0x487c94;
  uStack_254 = __vbaLateIdCallLd();
  ppppfStack_258 = (float ****)0x487c9e;
  fVar27 = (float10)__vbaR4Var();
  local_90 = (float ****)0x4;
  local_88 = (float ****)(float)(fVar27 + (float10)DAT_0050b26c);
  if ((uVar26 & 0xd) != 0) goto LAB_004886de;
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1a4 = (float ****)&DAT_0050c53c;
    ppppfStack_1a8 = (float ****)&DAT_0040b420;
    ppppfStack_1ac = (float ****)0x487ce3;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1a4 = (float ****)&local_30;
  ppppfStack_1a8 = (float ****)DAT_0050c53c;
  ppppfStack_1ac = (float ****)0x487cf3;
  ppppfStack_1b8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)ppppfStack_1b8 < 0) {
    ppppfStack_1ac = (float ****)0x20;
    pppfStack_1b0 = (float ***)&DAT_0040b410;
    ppppfStack_1b4 = (float ****)pppppfVar14;
    pppfStack_1bc = (float ***)0x487d08;
    __vbaHresultCheckObj();
  }
  pppfStack_1bc = (float ***)0x1000b;
  ppppfStack_1b8 = local_90;
  ppppfStack_1b4 = local_8c;
  pppfStack_1b0 = (float ***)local_88;
  ppppfStack_1ac = local_84;
  ppppfStack_1c0 = local_30;
  ppppfStack_1c4 = (float ****)0x487d38;
  __vbaLateIdSt();
  ppppfStack_1c4 = (float ****)&local_30;
  ppppfStack_1c8 = (float ****)&local_2c;
  ppppfStack_1cc = (float ****)0x2;
  ppppfStack_1d0 = (float ****)0x487d44;
  __vbaFreeObjList();
  ppppfStack_1c4 = (float ****)0x487d50;
  __vbaFreeVar();
  if (_DAT_0050b144 == _DAT_00401490) {
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_1c4 = (float ****)&DAT_0050c53c;
      ppppfStack_1c8 = (float ****)&DAT_0040b420;
      ppppfStack_1cc = (float ****)0x487d80;
      __vbaNew2();
    }
    pppppfVar14 = DAT_0050c53c;
    ppppfStack_1c4 = (float ****)&local_2c;
    ppppfStack_1c8 = (float ****)DAT_0050c53c;
    ppppfStack_1cc = (float ****)0x487d90;
    ppppfStack_1d8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
    if ((int)ppppfStack_1d8 < 0) {
      ppppfStack_1cc = (float ****)0x20;
      ppppfStack_1d0 = (float ****)&DAT_0040b410;
      ppppfStack_1d4 = (float ****)pppppfVar14;
      ppppfStack_1dc = (float ****)0x487da5;
      __vbaHresultCheckObj();
    }
    ppppfStack_1cc = (float ****)0x411328;
    ppppfStack_1d0 = local_2c;
    ppppfStack_1d4 = (float ****)&DAT_0040bf08;
    ppppfStack_1d8 = (float ****)0x487db9;
    __vbaPrintObj();
    ppppfStack_1cc = (float ****)0x487dc7;
    __vbaFreeObj();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_1cc = (float ****)&DAT_0050c53c;
      ppppfStack_1d0 = (float ****)&DAT_0040b420;
      ppppfStack_1d4 = (float ****)0x487de0;
      __vbaNew2();
    }
    pppppfVar14 = DAT_0050c53c;
    ppppfStack_1cc = (float ****)&local_2c;
    ppppfStack_1d0 = (float ****)DAT_0050c53c;
    ppppfStack_1d4 = (float ****)0x487df0;
    ppppfStack_1e0 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
    if ((int)ppppfStack_1e0 < 0) {
      ppppfStack_1d4 = (float ****)0x20;
      ppppfStack_1d8 = (float ****)&DAT_0040b410;
      ppppfStack_1dc = (float ****)pppppfVar14;
      ppppfStack_1e4 = (float ****)0x487e05;
      __vbaHresultCheckObj();
    }
    ppppfStack_1d4 = (float ****)0x0;
    ppppfStack_1d8 = (float ****)0x20000;
    ppppfStack_1dc = local_2c;
    ppppfStack_1e0 = (float ****)0x487e16;
    __vbaLateIdCall();
    ppppfStack_1d4 = (float ****)0x487e1e;
    __vbaFreeObj();
LAB_004886c3:
    ppppfStack_1d4 = (float ****)&LAB_004886cd;
    ppppfStack_1d8 = (float ****)0x4886cc;
    __vbaFreeStr();
    return;
  }
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1c4 = (float ****)&DAT_0050c53c;
    ppppfStack_1c8 = (float ****)&DAT_0040b420;
    ppppfStack_1cc = (float ****)0x487e3d;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1c4 = (float ****)&local_2c;
  ppppfStack_1c8 = (float ****)DAT_0050c53c;
  ppppfStack_1cc = (float ****)0x487e4d;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[8])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_1cc = (float ****)0x20;
    ppppfStack_1d0 = (float ****)&DAT_0040b410;
    ppppfStack_1d4 = (float ****)pppppfVar14;
    ppppfStack_1dc = (float ****)0x487e62;
    ppppfStack_1d8 = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppfStack_1cc = (float ****)0x487e67;
  FUN_0044fdc0();
  ppppfStack_1cc = (float ****)0x487e72;
  __vbaStrMove();
  ppppfStack_1cc = (float ****)&DAT_00000001;
  local_38 = local_28;
  ppppfStack_1d4 = &local_40;
  ppppfStack_1d0 = (float ****)&DAT_00000001;
  ppppfStack_1d8 = (float ****)&local_90;
  ppppfStack_1dc = local_50;
  local_28 = 0;
  local_40 = (float ***)0x8;
  local_88 = (float ****)&DAT_0050b144;
  local_90 = (float ****)0x4005;
  ppppfStack_1e0 = (float ****)0x487eb3;
  Ordinal_660();
  ppppfStack_1e0 = local_50;
  ppppfStack_1e4 = (float ****)0x411170;
  ppppfStack_1e8 = local_2c;
  ppppfStack_1ec = (float ****)&DAT_0040fd0c;
  ppppfStack_1f0 = (float ****)0x487ecb;
  __vbaPrintObj();
  ppppfStack_1e0 = (float ****)0x487ed7;
  __vbaFreeStr();
  pcVar23 = __vbaFreeObj_exref;
  ppppfStack_1e0 = (float ****)0x487ee2;
  __vbaFreeObj();
  ppppfStack_1e0 = local_50;
  ppppfStack_1e4 = &local_40;
  ppppfStack_1e8 = (float ****)0x2;
  ppppfStack_1ec = (float ****)0x487ef2;
  __vbaFreeVarList();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_1e0 = (float ****)&DAT_0050c53c;
    ppppfStack_1e4 = (float ****)&DAT_0040b420;
    ppppfStack_1e8 = (float ****)0x487f0e;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_1e0 = (float ****)&local_2c;
  ppppfStack_1e4 = (float ****)DAT_0050c53c;
  ppppfStack_1e8 = (float ****)0x487f1e;
  ppppfStack_1f4 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
  uVar26 = 0;
  if ((int)ppppfStack_1f4 < 0) {
    ppppfStack_1e8 = (float ****)0x20;
    ppppfStack_1ec = (float ****)&DAT_0040b410;
    ppppfStack_1f0 = (float ****)pppppfVar14;
    ppppfStack_1f8 = (float ****)0x487f33;
    __vbaHresultCheckObj();
  }
  ppppfStack_1e8 = (float ****)0x0;
  ppppfStack_1ec = (float ****)0x1000b;
  ppppfStack_1f4 = &local_40;
  ppppfStack_1f0 = local_2c;
  ppppfStack_1f8 = (float ****)0x487f48;
  ppppfStack_1e8 = (float ****)__vbaLateIdCallLd();
  ppppfStack_1ec = (float ****)0x487f52;
  __vbaR4Var();
  if ((longlong)(int)((longlong)DAT_0050b26c * 3) == (longlong)DAT_0050b26c * 3) {
    if ((uVar26 & 0xd) != 0) goto LAB_004886de;
    ppppfStack_1a4 = (float ****)0x487f89;
    DAT_0050b268 = __vbaFpI4();
    ppppfStack_1a4 = (float ****)0x487f93;
    __vbaFreeObj();
    ppppfStack_1a4 = (float ****)0x487f9c;
    __vbaFreeVar();
    ppppfStack_1a4 = &local_c4;
    ppppfStack_1a8 = &local_cc;
    ppppfStack_1ac = &local_c8;
    pppfStack_1b0 = (float ***)&DAT_0050b0c4;
    local_c4 = (float ***)0xffffffff;
    local_cc = (float ***)&DAT_0050b078;
    local_c8 = (float ***)&DAT_0050b054;
    ppppfStack_1b4 = (float ****)0x487fd9;
    FUN_0048cdf0();
    if (DAT_0050b238 != 2) {
LAB_0048861d:
      if (DAT_0050c53c == (float *****)0x0) {
        ppppfStack_1a4 = (float ****)&DAT_0050c53c;
        ppppfStack_1a8 = (float ****)&DAT_0040b420;
        ppppfStack_1ac = (float ****)0x488636;
        __vbaNew2();
      }
      pppppfVar14 = DAT_0050c53c;
      ppppfStack_1a4 = (float ****)&local_2c;
      ppppfStack_1a8 = (float ****)DAT_0050c53c;
      ppppfStack_1ac = (float ****)0x488646;
      ppppfStack_1b8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
      if ((int)ppppfStack_1b8 < 0) {
        ppppfStack_1ac = (float ****)0x20;
        pppfStack_1b0 = (float ***)&DAT_0040b410;
        ppppfStack_1b4 = (float ****)pppppfVar14;
        pppfStack_1bc = (float ***)0x48865b;
        __vbaHresultCheckObj();
      }
      ppppfStack_1ac = (float ****)0x0;
      pppfStack_1b0 = (float ***)0x20000;
      ppppfStack_1b4 = local_2c;
      ppppfStack_1b8 = (float ****)0x48866c;
      __vbaLateIdCall();
      ppppfStack_1ac = (float ****)0x488678;
      __vbaFreeObj();
      goto LAB_004886c3;
    }
    iVar9 = (int)((longlong)DAT_0050b26c * 2);
    if ((longlong)iVar9 == (longlong)DAT_0050b26c * 2) {
      iVar12 = DAT_0050b268 - iVar9;
      local_88 = (float ****)0x44960000;
      if (!SBORROW4(DAT_0050b268,iVar9)) {
        local_90 = (float ****)0x4;
        DAT_0050b268 = iVar12;
        if (DAT_0050c53c == (float *****)0x0) {
          ppppfStack_1a4 = (float ****)&DAT_0050c53c;
          ppppfStack_1a8 = (float ****)&DAT_0040b420;
          ppppfStack_1ac = (float ****)0x488035;
          __vbaNew2();
        }
        pppppfVar14 = DAT_0050c53c;
        ppppfStack_1a4 = (float ****)&local_2c;
        ppppfStack_1a8 = (float ****)DAT_0050c53c;
        ppppfStack_1ac = (float ****)0x488045;
        ppppfStack_1b8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
        if ((int)ppppfStack_1b8 < 0) {
          ppppfStack_1ac = (float ****)0x20;
          pppfStack_1b0 = (float ***)&DAT_0040b410;
          ppppfStack_1b4 = (float ****)pppppfVar14;
          pppfStack_1bc = (float ***)0x48805c;
          __vbaHresultCheckObj();
        }
        pppfStack_1bc = (float ***)0x1000a;
        ppppfStack_1b8 = local_90;
        ppppfStack_1b4 = local_8c;
        pppfStack_1b0 = (float ***)local_88;
        ppppfStack_1ac = local_84;
        ppppfStack_1c0 = local_2c;
        ppppfStack_1c4 = (float ****)0x48809a;
        __vbaLateIdSt();
        ppppfStack_1c4 = (float ****)0x4880a3;
        __vbaFreeObj();
        local_88 = (float ****)(float)DAT_0050b268;
        local_90 = (float ****)0x4;
        if (DAT_0050c53c == (float *****)0x0) {
          ppppfStack_1c4 = (float ****)&DAT_0050c53c;
          ppppfStack_1c8 = (float ****)&DAT_0040b420;
          ppppfStack_1cc = (float ****)0x4880d2;
          __vbaNew2();
        }
        pppppfVar14 = DAT_0050c53c;
        ppppfStack_1c4 = (float ****)&local_2c;
        ppppfStack_1c8 = (float ****)DAT_0050c53c;
        ppppfStack_1cc = (float ****)0x4880e2;
        ppppfStack_1d8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
        if ((int)ppppfStack_1d8 < 0) {
          ppppfStack_1cc = (float ****)0x20;
          ppppfStack_1d0 = (float ****)&DAT_0040b410;
          ppppfStack_1d4 = (float ****)pppppfVar14;
          ppppfStack_1dc = (float ****)0x4880f3;
          __vbaHresultCheckObj();
        }
        ppppfStack_1dc = (float ****)0x1000b;
        ppppfStack_1d8 = local_90;
        ppppfStack_1d4 = local_8c;
        ppppfStack_1d0 = local_88;
        ppppfStack_1cc = local_84;
        ppppfStack_1e0 = local_2c;
        ppppfStack_1e4 = (float ****)0x488123;
        __vbaLateIdSt();
        ppppfStack_1e4 = (float ****)0x48812c;
        __vbaFreeObj();
        local_88 = (float ****)0xffffffff;
        local_90 = (float ****)0xb;
        if (DAT_0050c53c == (float *****)0x0) {
          ppppfStack_1e4 = (float ****)&DAT_0050c53c;
          ppppfStack_1e8 = (float ****)&DAT_0040b420;
          ppppfStack_1ec = (float ****)0x488159;
          __vbaNew2();
        }
        pppppfVar14 = DAT_0050c53c;
        ppppfStack_1e4 = (float ****)&local_2c;
        ppppfStack_1e8 = (float ****)DAT_0050c53c;
        ppppfStack_1ec = (float ****)0x488169;
        ppppfStack_1f8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
        if ((int)ppppfStack_1f8 < 0) {
          ppppfStack_1ec = (float ****)0x20;
          ppppfStack_1f0 = (float ****)&DAT_0040b410;
          ppppfStack_1f4 = (float ****)pppppfVar14;
          ppppfStack_1fc = (float ****)0x48817a;
          __vbaHresultCheckObj();
        }
        ppppfStack_1fc = (float ****)0x3;
        ppppfStack_200 = (float ****)&DAT_0040eb6c;
        ppppfStack_1f8 = local_90;
        ppppfStack_204 = (float ****)0x0;
        pppfStack_208 = (float ***)0x10028;
        ppppfStack_1f4 = local_8c;
        ppppfStack_1f0 = local_88;
        pppfStack_210 = (float ***)&local_40;
        ppppfStack_1ec = local_84;
        ppppfStack_20c = local_2c;
        ppppfStack_214 = (float ****)0x4881bb;
        ppppfStack_204 = (float ****)__vbaLateIdCallLd();
        pppfStack_208 = (float ***)0x4881c5;
        pppfStack_208 = (float ***)__vbaCastObjVar();
        ppppfStack_20c = (float ****)&local_30;
        pppfStack_210 = (float ***)0x4881d0;
        pppfStack_210 = (float ***)__vbaObjSet();
        ppppfStack_214 = (float ****)0x4881d3;
        __vbaLateIdSt();
        ppppfStack_214 = (float ****)&local_30;
        ppppfStack_218 = (float ****)&local_2c;
        uStack_220 = 4.24633930431128e-314;
        __vbaFreeObjList();
        ppppfStack_214 = (float ****)0x4881ef;
        __vbaFreeVar();
        if (DAT_0050c53c == (float *****)0x0) {
          ppppfStack_214 = (float ****)&DAT_0050c53c;
          ppppfStack_218 = (float ****)&DAT_0040b420;
          uStack_220 = (double)CONCAT44(0x488208,(undefined4)uStack_220);
          __vbaNew2();
        }
        pppppfVar14 = DAT_0050c53c;
        ppppfStack_214 = (float ****)&local_2c;
        ppppfStack_218 = (float ****)DAT_0050c53c;
        uStack_220 = (double)CONCAT44(0x488218,(undefined4)uStack_220);
        pppfStack_228 = (float ***)(*(code *)(*DAT_0050c53c)[8])();
        if ((int)pppfStack_228 < 0) {
          uStack_220 = 6.79059603468533e-313;
          ppppfStack_224 = (float ****)pppppfVar14;
          ppppfStack_22c = (float ****)0x488229;
          __vbaHresultCheckObj();
        }
        uStack_220 = (double)CONCAT44(L"Solution:",local_2c);
        ppppfStack_224 = (float ****)&DAT_0040bf08;
        pppfStack_228 = (float ***)0x48823d;
        __vbaPrintObj();
        uStack_220 = (double)CONCAT44(0x488249,(undefined4)uStack_220);
        __vbaFreeObj();
        local_88 = (float ****)0x0;
        local_90 = (float ****)0xb;
        if (DAT_0050c53c == (float *****)0x0) {
          uStack_220 = 3.731548275327462e-307;
          ppppfStack_224 = (float ****)0x488276;
          __vbaNew2();
        }
        pppppfVar14 = DAT_0050c53c;
        uStack_220 = (double)CONCAT44(&local_2c,DAT_0050c53c);
        ppppfStack_224 = (float ****)0x488286;
        ppppfStack_230 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
        if ((int)ppppfStack_230 < 0) {
          ppppfStack_224 = (float ****)0x20;
          pppfStack_228 = (float ***)&DAT_0040b410;
          ppppfStack_22c = (float ****)pppppfVar14;
          ppppfStack_234 = (float ****)0x488297;
          __vbaHresultCheckObj();
        }
        ppppfStack_234 = (float ****)0x3;
        pppfStack_238 = (float ***)&DAT_0040eb6c;
        ppppfStack_230 = local_90;
        ppppfStack_23c = (float ****)0x0;
        ppppfStack_240 = (float ****)0x10028;
        ppppfStack_22c = local_8c;
        pppfStack_228 = (float ***)local_88;
        ppppfStack_248 = &local_40;
        ppppfStack_224 = local_84;
        ppppfStack_244 = local_2c;
        ppppfStack_24c = (float ****)0x4882d8;
        ppppfStack_23c = (float ****)__vbaLateIdCallLd();
        ppppfStack_240 = (float ****)0x4882e2;
        ppppfStack_240 = (float ****)__vbaCastObjVar();
        ppppfStack_244 = (float ****)&local_30;
        ppppfStack_248 = (float ****)0x4882ed;
        ppppfStack_248 = (float ****)__vbaObjSet();
        ppppfStack_24c = (float ****)0x4882f0;
        __vbaLateIdSt();
        ppppfStack_24c = (float ****)&local_30;
        ppppfStack_250 = (float ****)&local_2c;
        uStack_254 = 2;
        ppppfStack_258 = (float ****)0x488300;
        __vbaFreeObjList();
        ppppfStack_24c = (float ****)0x48830c;
        __vbaFreeVar();
        sVar19 = DAT_0050b20a;
        pcVar22 = __vbaAryUnlock_exref;
        pcVar23 = (code *)&DAT_00000001;
        local_18 = (float **)0x1;
        ppfVar6 = local_18;
        do {
          local_18 = ppfVar6;
          if (sVar19 < (short)local_18) goto LAB_0048861d;
          iVar9 = DAT_0050b268 + DAT_0050b26c;
          if (SCARRY4(DAT_0050b268,DAT_0050b26c)) break;
          local_88 = (float ****)0x44bb8000;
          local_90 = (float ****)0x4;
          DAT_0050b268 = iVar9;
          if (DAT_0050c53c == (float *****)0x0) {
            ppppfStack_1a4 = (float ****)&DAT_0050c53c;
            ppppfStack_1a8 = (float ****)&DAT_0040b420;
            ppppfStack_1ac = (float ****)0x48837d;
            __vbaNew2();
          }
          pppppfVar14 = DAT_0050c53c;
          ppppfStack_1a4 = (float ****)&local_2c;
          ppppfStack_1a8 = (float ****)DAT_0050c53c;
          ppppfStack_1ac = (float ****)0x48838d;
          ppppfStack_1b8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
          if ((int)ppppfStack_1b8 < 0) {
            ppppfStack_1ac = (float ****)0x20;
            pppfStack_1b0 = (float ***)&DAT_0040b410;
            ppppfStack_1b4 = (float ****)pppppfVar14;
            pppfStack_1bc = (float ***)0x4883a2;
            __vbaHresultCheckObj();
          }
          pppfStack_1bc = (float ***)0x1000a;
          ppppfStack_1b8 = local_90;
          ppppfStack_1b4 = local_8c;
          pppfStack_1b0 = (float ***)local_88;
          ppppfStack_1ac = local_84;
          ppppfStack_1c0 = local_2c;
          ppppfStack_1c4 = (float ****)0x4883d6;
          __vbaLateIdSt();
          ppppfStack_1c4 = (float ****)0x4883df;
          __vbaFreeObj();
          local_88 = (float ****)(float)DAT_0050b268;
          local_90 = (float ****)0x4;
          if (DAT_0050c53c == (float *****)0x0) {
            ppppfStack_1c4 = (float ****)&DAT_0050c53c;
            ppppfStack_1c8 = (float ****)&DAT_0040b420;
            ppppfStack_1cc = (float ****)0x48840e;
            __vbaNew2();
          }
          pppppfVar14 = DAT_0050c53c;
          ppppfStack_1c4 = (float ****)&local_2c;
          ppppfStack_1c8 = (float ****)DAT_0050c53c;
          ppppfStack_1cc = (float ****)0x48841e;
          ppppfStack_1d8 = (float ****)(*(code *)(*DAT_0050c53c)[8])();
          if ((int)ppppfStack_1d8 < 0) {
            ppppfStack_1cc = (float ****)0x20;
            ppppfStack_1d0 = (float ****)&DAT_0040b410;
            ppppfStack_1d4 = (float ****)pppppfVar14;
            ppppfStack_1dc = (float ****)0x488433;
            __vbaHresultCheckObj();
          }
          ppppfStack_1dc = (float ****)0x1000b;
          ppppfStack_1d8 = local_90;
          ppppfStack_1d4 = local_8c;
          ppppfStack_1d0 = local_88;
          ppppfStack_1cc = local_84;
          ppppfStack_1e0 = local_2c;
          ppppfStack_1e4 = (float ****)0x488467;
          __vbaLateIdSt();
          ppppfStack_1e4 = (float ****)0x488470;
          __vbaFreeObj();
          if (DAT_0050c53c == (float *****)0x0) {
            ppppfStack_1e4 = (float ****)&DAT_0050c53c;
            ppppfStack_1e8 = (float ****)&DAT_0040b420;
            ppppfStack_1ec = (float ****)0x488489;
            __vbaNew2();
          }
          pppppfVar14 = DAT_0050c53c;
          ppppfStack_1e4 = (float ****)&local_2c;
          ppppfStack_1e8 = (float ****)DAT_0050c53c;
          ppppfStack_1ec = (float ****)0x488499;
          pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[8])();
          if ((int)pppppfVar11 < 0) {
            ppppfStack_1ec = (float ****)0x20;
            ppppfStack_1f0 = (float ****)&DAT_0040b410;
            ppppfStack_1f4 = (float ****)pppppfVar14;
            ppppfStack_1fc = (float ****)0x4884ae;
            ppppfStack_1f8 = (float ****)pppppfVar11;
            __vbaHresultCheckObj();
          }
          ppppfStack_1ec = (float ****)&local_90;
          ppppfStack_1f0 = &local_40;
          local_88 = (float ****)&local_18;
          local_90 = (float ****)0x4002;
          ppppfStack_1f4 = (float ****)0x4884d2;
          Ordinal_613();
          ppppfStack_1f4 = (float ****)0x4884d7;
          FUN_0044fdc0();
          ppppfStack_1f4 = (float ****)0x4884e2;
          __vbaStrMove();
          local_68 = local_28;
          ppppfStack_1f8 = local_24;
          ppppfStack_1f4 = (float ****)DAT_0050b0f4;
          local_28 = 0;
          local_70[0] = (float ***)0x8;
          ppppfStack_1fc = (float ****)0x488508;
          __vbaAryLock();
          if (((float ****)local_24[0] == (float ****)0x0) || (*(short *)local_24[0] != 1)) {
            ppppfStack_1fc = (float ****)0x488542;
            local_b8 = __vbaGenerateBoundsError();
          }
          else {
            iVar9 = (int)(short)local_18;
            pppfVar1 = (float ***)local_24[0][5];
            if (local_24[0][4] <= (float ***)(iVar9 - (int)pppfVar1)) {
              ppppfStack_1fc = (float ****)0x48852b;
              __vbaGenerateBoundsError();
            }
            local_b8 = (iVar9 - (int)pppfVar1) * 8;
          }
          pppppfVar14 = (float *****)0x8;
          ppppfStack_1fc = (float ****)&DAT_00000001;
          local_b8 = (int)local_24[0][3] + local_b8;
          ppppfStack_204 = local_70;
          ppppfStack_200 = (float ****)&DAT_00000001;
          pppfStack_208 = local_c0;
          ppppfStack_20c = local_80;
          local_c0[0] = (float **)0x4005;
          pppfStack_210 = (float ***)0x488573;
          Ordinal_660();
          pppfStack_210 = (float ***)local_24;
          ppppfStack_214 = (float ****)0x488579;
          __vbaAryUnlock();
          ppppfStack_214 = local_80;
          ppppfStack_218 = local_a0;
          uStack_220 = (double)CONCAT44(&local_40,local_50);
          local_98 = &DAT_0040c894;
          local_a0[0] = (float ***)0x8;
          local_a8 = L" =  ";
          local_b0[0] = (float **)0x8;
          ppppfStack_224 = (float ****)0x4885b2;
          ppppfStack_224 = (float ****)__vbaVarAdd();
          pppfStack_228 = local_b0;
          ppppfStack_22c = local_60;
          ppppfStack_230 = (float ****)0x4885c4;
          ppppfStack_230 = (float ****)__vbaVarCat();
          ppppfStack_234 = local_2c;
          pppfStack_238 = (float ***)&DAT_004111ac;
          ppppfStack_23c = (float ****)0x4885d4;
          __vbaPrintObj();
          ppppfStack_22c = (float ****)0x4885e0;
          __vbaFreeStr();
          ppppfStack_22c = (float ****)0x4885e9;
          __vbaFreeObj();
          ppppfStack_22c = local_80;
          ppppfStack_230 = local_70;
          ppppfStack_234 = local_60;
          pppfStack_238 = (float ***)local_50;
          ppppfStack_23c = &local_40;
          ppppfStack_240 = (float ****)0x5;
          ppppfStack_244 = (float ****)0x488605;
          __vbaFreeVarList();
          ppfVar6 = (float **)CONCAT22(extraout_var,(short)local_18 + 1);
        } while (!SCARRY2((short)local_18,1));
      }
    }
  }
  ppppfStack_1a4 = (float ****)0x4886e9;
  __vbaErrorOverflow();
  pppfStack_1b0 = (float ***)&DAT_00402706;
  ppppfStack_1b4 = ExceptionList;
  ppppfStack_1ac = (float ****)&pcStack_418;
  ppppfStack_1a8 = (float ****)&LAB_00402108;
  ppppfStack_1b8 = (float ****)0x0;
  pppfStack_1bc = (float ***)0x0;
  ppppfStack_1c0 = (float ****)0x0;
  ppppfStack_1c8 = (float ****)0x0;
  ppppfStack_1d0 = (float ****)0x0;
  ppppfStack_1d8 = (float ****)0x0;
  ppppfStack_1dc = (float ****)0x0;
  ppppfStack_1e0 = (float ****)0x0;
  ppppfStack_1e4 = (float ****)0x0;
  ppppfStack_1e8 = (float ****)0x0;
  ppppfStack_1ec = (float ****)0x0;
  ppppfStack_1f0 = (float ****)0x0;
  ppppfStack_1f4 = (float ****)0x0;
  ppppfStack_1f8 = (float ****)0x0;
  pppfStack_208 = (float ***)0x0;
  ppppfStack_218 = (float ****)0x0;
  pppfStack_228 = (float ***)0x0;
  pppfStack_238 = (float ***)0x0;
  ppppfStack_248 = (float ****)0x0;
  ppppfStack_258 = (float ****)0x0;
  pppfStack_268 = (float ***)0x0;
  ppppfStack_278 = (float ****)0x0;
  pppfStack_288 = (float ***)0x0;
  ppppfStack_2a8 = (float ****)0x0;
  ppppfStack_2b8 = (float ****)0x0;
  uStack_2c8 = 0;
  apppfStack_2e8[0] = (float ***)0x0;
  uStack_2f8 = 0;
  appppfStack_30c[0] = (float ****)0x0;
  pppfStack_310 = (float ***)0x0;
  ppppfStack_314 = (float ****)0x0;
  apiStack_340[0] = (int *)0x0;
  ppppfStack_344 = (float ****)0x0;
  ExceptionList = &ppppfStack_1b4;
  pcStack_418 = pcVar23;
  ppppfStack_414 = (float ****)pppppfVar14;
  pcStack_410 = pcVar22;
  ppppfVar24 = (float ****)&pcStack_418;
  ppppfStack_1a4 = (float ****)&stack0xfffffffc;
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_41c = (float ****)&DAT_0050b420;
    puStack_420 = &DAT_00408c88;
    ppppfStack_424 = (float ****)0x4887cd;
    ExceptionList = &ppppfStack_1b4;
    ppppfStack_1a4 = (float ****)&stack0xfffffffc;
    __vbaNew2();
    ppppfVar24 = ppppfStack_1ac;
  }
  ppppfStack_1ac = ppppfVar24;
  ppppfStack_41c = (float ****)DAT_0050b420;
  puStack_420 = (undefined *)0x4887db;
  puStack_420 = (undefined *)(*(code *)(*DAT_0050b420)[0xdb])();
  ppppfStack_424 = (float ****)&ppppfStack_1f0;
  uStack_428 = 0x4887e8;
  piVar13 = (int *)__vbaObjSet();
  uStack_428 = 0xffffffff;
  ppppfStack_430 = (float ****)0x4887f5;
  piStack_42c = piVar13;
  iVar9 = (**(code **)(*piVar13 + 0x9c))();
  if (iVar9 < 0) {
    ppppfStack_430 = (float ****)0x9c;
    puStack_434 = &DAT_0040c3dc;
    piStack_440 = (int *)0x48880d;
    iStack_43c = iVar9;
    ppppfStack_438 = (float ****)piVar13;
    __vbaHresultCheckObj();
  }
  ppppfStack_430 = (float ****)0x488816;
  __vbaFreeObj();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_430 = (float ****)&DAT_0050b420;
    puStack_434 = &DAT_00408c88;
    ppppfStack_438 = (float ****)0x48882f;
    __vbaNew2();
  }
  ppppfStack_430 = (float ****)DAT_0050b420;
  puStack_434 = (undefined *)0x48883d;
  puStack_434 = (undefined *)(*(code *)(*DAT_0050b420)[0xdc])();
  ppppfStack_438 = (float ****)&ppppfStack_1f0;
  iStack_43c = 0x488844;
  piVar13 = (int *)__vbaObjSet();
  iStack_43c = 0;
  ppppfStack_444 = (float ****)0x488850;
  piStack_440 = piVar13;
  iVar9 = (**(code **)(*piVar13 + 0x8c))();
  if (iVar9 < 0) {
    ppppfStack_444 = (float ****)0x8c;
    puStack_448 = &DAT_0040bb6c;
    piStack_454 = (int *)0x488868;
    iStack_450 = iVar9;
    ppppfStack_44c = (float ****)piVar13;
    __vbaHresultCheckObj();
  }
  ppppfStack_444 = (float ****)0x488871;
  __vbaFreeObj();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_444 = (float ****)&DAT_0050b420;
    puStack_448 = &DAT_00408c88;
    ppppfStack_44c = (float ****)0x48888a;
    __vbaNew2();
  }
  ppppfStack_444 = (float ****)DAT_0050b420;
  puStack_448 = (undefined *)0x488898;
  puStack_448 = (undefined *)(*(code *)(*DAT_0050b420)[0xdd])();
  ppppfStack_44c = (float ****)&ppppfStack_1f0;
  iStack_450 = 0x48889f;
  piVar13 = (int *)__vbaObjSet();
  iStack_450 = 0;
  ppppfStack_458 = (float ****)0x4888ab;
  piStack_454 = piVar13;
  iVar9 = (**(code **)(*piVar13 + 0x8c))();
  if (iVar9 < 0) {
    ppppfStack_458 = (float ****)0x8c;
    puStack_45c = &DAT_0040bb6c;
    uStack_468 = 0x4888c3;
    pppfStack_464 = (float ***)iVar9;
    ppppfStack_460 = (float ****)piVar13;
    __vbaHresultCheckObj();
  }
  ppppfStack_458 = (float ****)0x4888cc;
  __vbaFreeObj();
  DAT_0050b1fe = 2;
  ppppfStack_270 = (float ****)0x0;
  ppppfStack_278 = (float ****)0xb;
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_458 = (float ****)&DAT_0050b420;
    puStack_45c = &DAT_00408c88;
    ppppfStack_460 = (float ****)0x4888fe;
    __vbaNew2();
  }
  uStack_468 = 0x80010007;
  ppppfStack_46c = (float ****)DAT_0050b420;
  pppfStack_464 = (float ***)ppppfStack_278;
  ppppfStack_460 = ppppfStack_274;
  puStack_45c = (undefined *)ppppfStack_270;
  ppppfStack_458 = ppppfStack_26c;
  uStack_470 = 0x488939;
  uStack_470 = (*(code *)(*DAT_0050b420)[0xec])();
  ppppfStack_474 = (float ****)&ppppfStack_1f0;
  uStack_478 = 0x488940;
  uStack_478 = __vbaObjSet();
  pcVar22 = __vbaLateIdSt_exref;
  ppppfStack_47c = (float ****)0x488949;
  __vbaLateIdSt();
  ppppfStack_47c = (float ****)0x488952;
  __vbaFreeObj();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_47c = (float ****)&DAT_0050b420;
    ppiStack_480 = (int **)&DAT_00408c88;
    ppppfStack_484 = (float ****)0x48896a;
    __vbaNew2();
  }
  ppiStack_480 = apiStack_340;
  ppppfStack_47c = (float ****)DAT_0050b420;
  ppppfStack_484 = (float ****)0x48897f;
  __vbaObjSetAddref();
  ppppfStack_484 = (float ****)&ppppfStack_1f0;
  ppppfStack_270 = (float ****)0x40c3f0;
  ppppfStack_278 = (float ****)0x8;
  piStack_488 = apiStack_340[0];
  ppppfStack_48c = (float ****)0x4889a6;
  pppfStack_498 = (float ***)(**(code **)(*apiStack_340[0] + 0x248))();
  if ((int)pppfStack_498 < 0) {
    ppppfStack_48c = (float ****)0x248;
    pwStack_490 = L"믲㢺毡䞍྽닦\xf724㶱䞙缔횱䙏䆙赘鄽쭖䉂片摩";
    ppppfStack_494 = (float ****)apiStack_340[0];
    uStack_49c = 0x4889c4;
    __vbaHresultCheckObj();
  }
  uStack_49c = 0;
  pppfStack_498 = (float ***)ppppfStack_278;
  ppppfStack_494 = ppppfStack_274;
  pwStack_490 = (wchar_t *)ppppfStack_270;
  ppppfStack_48c = ppppfStack_26c;
  ppppfStack_4a0 = ppppfStack_1f0;
  ppppfStack_4a4 = (float ****)0x4889f4;
  __vbaLateIdSt();
  ppppfStack_4a4 = (float ****)0x4889fd;
  __vbaFreeObj();
  ppppfStack_4a4 = (float ****)&ppppfStack_1f0;
  ppppfStack_270 = (float ****)0x6;
  ppppfStack_278 = (float ****)0x2;
  piStack_4a8 = apiStack_340[0];
  ppppfStack_4ac = (float ****)0x488a24;
  pppfStack_4b8 = (float ***)(**(code **)(*apiStack_340[0] + 0x248))();
  if ((int)pppfStack_4b8 < 0) {
    ppppfStack_4ac = (float ****)0x248;
    puStack_4b0 = &DAT_0040b430;
    ppppfStack_4b4 = (float ****)apiStack_340[0];
    uStack_4bc = 0x488a42;
    __vbaHresultCheckObj();
  }
  uStack_4bc = 2;
  pppfStack_4b8 = (float ***)ppppfStack_278;
  ppppfStack_4b4 = ppppfStack_274;
  puStack_4b0 = (undefined *)ppppfStack_270;
  ppppfStack_4ac = ppppfStack_26c;
  ppppfStack_4c0 = ppppfStack_1f0;
  uStack_4c4 = 0x488a72;
  __vbaLateIdSt();
  uStack_4c4 = 0x488a7b;
  __vbaFreeObj();
  uStack_4c4 = 0xffffff;
  piStack_4c8 = apiStack_340[0];
  ppppfStack_4cc = (float ****)0x488a8c;
  iVar9 = (**(code **)(*apiStack_340[0] + 0x6c))();
  if (iVar9 < 0) {
    ppppfStack_4cc = (float ****)0x6c;
    ppppfStack_4d0 = (float ****)&DAT_0040b430;
    ppppfStack_4d4 = (float ****)apiStack_340[0];
    ppppfStack_4dc = (float ****)0x488aa7;
    puStack_4d8 = (undefined *)iVar9;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_4cc = (float ****)&DAT_0050b420;
    ppppfStack_4d0 = (float ****)&DAT_00408c88;
    ppppfStack_4d4 = (float ****)0x488ac0;
    __vbaNew2();
  }
  ppppfStack_4d0 = (float ****)&ppppfStack_1f0;
  ppppfStack_4cc = (float ****)DAT_0050b420;
  ppppfStack_4d4 = (float ****)0x488acc;
  __vbaObjSetAddref();
  ppppfStack_4d4 = (float ****)&ppppfStack_1f0;
  puStack_4d8 = (undefined *)0x488ad5;
  FUN_0048c990();
  puStack_4d8 = &DAT_0040b85c;
  ppppfStack_4dc = ppppfStack_1f0;
  uStack_4e0 = 0x488ae4;
  uStack_4e0 = __vbaCastObj();
  puStack_4e4 = &DAT_0050b420;
  ppppfStack_4e8 = (float ****)0x488aec;
  __vbaObjSet();
  ppppfStack_4e8 = (float ****)0x488af5;
  __vbaFreeObj();
  ppppfStack_4e8 = (float ****)&ppppfStack_1f0;
  ppppfStack_270 = (float ****)0xffffffff;
  ppppfStack_278 = (float ****)0xb;
  piStack_4ec = apiStack_340[0];
  ppppfStack_4f0 = (float ****)0x488b1c;
  pppfStack_4fc = (float ***)(**(code **)(*apiStack_340[0] + 0x248))();
  if ((int)pppfStack_4fc < 0) {
    ppppfStack_4f0 = (float ****)0x248;
    puStack_4f4 = &DAT_0040b430;
    ppppfStack_4f8 = (float ****)apiStack_340[0];
    uStack_500 = 0x488b3a;
    __vbaHresultCheckObj();
  }
  uStack_500 = 3;
  pppfStack_4fc = (float ***)ppppfStack_278;
  ppppfStack_4f8 = ppppfStack_274;
  puStack_4f4 = (undefined *)ppppfStack_270;
  ppppfStack_4f0 = ppppfStack_26c;
  ppppfStack_504 = ppppfStack_1f0;
  uStack_508 = 0x488b70;
  __vbaLateIdSt();
  uStack_508 = 0x488b79;
  __vbaFreeObj();
  ppiStack_50c = apiStack_340;
  uStack_508 = 0;
  ppppfStack_510 = (float ****)0x488b84;
  __vbaObjSetAddref();
  ppppfStack_270 = (float ****)0xa;
  ppppfStack_278 = (float ****)0x2;
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_510 = (float ****)&DAT_0050b420;
    ppppfStack_514 = (float ****)&DAT_00408c88;
    ppppfStack_518 = (float ****)0x488bb1;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_510 = (float ****)&ppppfStack_1f0;
  ppppfStack_514 = (float ****)DAT_0050b420;
  ppppfStack_518 = (float ****)0x488bc4;
  pppfStack_524 = (float ***)(*(code *)(*DAT_0050b420)[0x92])();
  if ((int)pppfStack_524 < 0) {
    ppppfStack_518 = (float ****)0x248;
    puStack_51c = &DAT_0040b430;
    ppppfStack_520 = (float ****)pppppfVar14;
    uStack_528 = 0x488bd8;
    __vbaHresultCheckObj();
  }
  uStack_528 = 2;
  pppfStack_524 = (float ***)ppppfStack_278;
  ppppfStack_520 = ppppfStack_274;
  puStack_51c = (undefined *)ppppfStack_270;
  ppppfStack_518 = ppppfStack_26c;
  ppppfStack_52c = ppppfStack_1f0;
  ppppfStack_530 = (float ****)0x488c08;
  __vbaLateIdSt();
  ppppfStack_530 = (float ****)0x488c11;
  __vbaFreeObj();
  ppppfStack_270 = (float ****)0xffffffff;
  ppppfStack_278 = (float ****)0xb;
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_530 = (float ****)&DAT_0050b420;
    ppppfStack_534 = (float ****)&DAT_00408c88;
    ppppfStack_538 = (float ****)0x488c3e;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_530 = (float ****)&ppppfStack_1f0;
  ppppfStack_534 = (float ****)DAT_0050b420;
  ppppfStack_538 = (float ****)0x488c51;
  ppppfStack_544 = (float ****)(*(code *)(*DAT_0050b420)[0x92])();
  if ((int)ppppfStack_544 < 0) {
    ppppfStack_538 = (float ****)0x248;
    ppppfStack_53c = (float ****)&DAT_0040b430;
    ppppfStack_540 = (float ****)pppppfVar14;
    uStack_548 = 0x488c65;
    __vbaHresultCheckObj();
  }
  uStack_548 = 3;
  ppppfStack_544 = ppppfStack_278;
  ppppfStack_540 = ppppfStack_274;
  ppppfStack_53c = ppppfStack_270;
  ppppfStack_538 = ppppfStack_26c;
  ppppfStack_54c = ppppfStack_1f0;
  puStack_550 = (undefined4 *)0x488c95;
  __vbaLateIdSt();
  puStack_550 = (undefined4 *)0x488c9e;
  __vbaFreeObj();
  if (DAT_0050b420 == (float *****)0x0) {
    puStack_550 = &DAT_0050b420;
    ppppfStack_554 = (float ****)&DAT_00408c88;
    ppppfStack_558 = (float ****)0x488cb7;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  puStack_550 = (undefined4 *)0x1;
  ppppfStack_554 = (float ****)DAT_0050b420;
  ppppfStack_558 = (float ****)0x488cc8;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x4b])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_558 = (float ****)0x12c;
    ppppfStack_55c = (float ****)&DAT_0040b430;
    ppppfStack_560 = (float ****)pppppfVar14;
    ppppfStack_568 = (float ****)0x488cdc;
    ppppfStack_564 = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppfStack_558 = (float ****)0x488cfb;
  __vbaStrCopy();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_558 = (float ****)&DAT_0050b420;
    ppppfStack_55c = (float ****)&DAT_00408c88;
    ppppfStack_560 = (float ****)0x488d14;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_558 = (float ****)appppfStack_30c;
  ppppfStack_55c = (float ****)DAT_0050b420;
  ppppfStack_560 = (float ****)0x488d2a;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x3a])();
  uVar26 = 0;
  if ((int)pppppfVar11 < 0) {
    ppppfStack_560 = (float ****)0xe8;
    ppppfStack_564 = (float ****)&DAT_0040b430;
    ppppfStack_568 = (float ****)pppppfVar14;
    ppppfStack_570 = (float ****)0x488d3e;
    ppppfStack_56c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_560 = (float ****)&DAT_0050b420;
    ppppfStack_564 = (float ****)&DAT_00408c88;
    ppppfStack_568 = (float ****)0x488d57;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  pppppfVar11 = (float *****)ppppfStack_55c;
  if ((uVar26 & 0xd) != 0) {
LAB_0048c2d4:
    ppppfStack_55c = (float ****)pppppfVar11;
    __vbaFPException();
    return;
  }
  ppppfStack_564 = (float ****)DAT_0050b420;
  ppppfStack_568 = (float ****)0x488d8c;
  ppppfStack_560 = (float ****)((float)appppfStack_30c[0] * (float)_DAT_004013e8);
  ppppfStack_3bc = (float ****)((float)appppfStack_30c[0] * (float)_DAT_004013e8);
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x3b])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_568 = (float ****)0xec;
    ppppfStack_56c = (float ****)&DAT_0040b430;
    ppppfStack_570 = (float ****)pppppfVar14;
    ppppfStack_578 = (float ****)0x488da0;
    ppppfStack_574 = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_568 = (float ****)&DAT_0050c53c;
    ppppfStack_56c = (float ****)&DAT_0040b420;
    ppppfStack_570 = (float ****)0x488db9;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_568 = (float ****)&ppppfStack_1f0;
  ppppfStack_56c = (float ****)DAT_0050c53c;
  ppppfStack_570 = (float ****)0x488dc9;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_570 = (float ****)0x18;
    ppppfStack_574 = (float ****)&DAT_0040b410;
    ppppfStack_578 = (float ****)pppppfVar14;
    ppppfStack_580 = (float ****)0x488dda;
    ppppfStack_57c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppfVar24 = ppppfStack_1f0;
  ppppfStack_570 = (float ****)appppfStack_30c;
  ppppfStack_574 = ppppfStack_1f0;
  ppppfStack_578 = (float ****)0x488def;
  pppppfVar14 = (float *****)(*(code *)(*ppppfStack_1f0)[0x26])();
  if ((int)pppppfVar14 < 0) {
    ppppfStack_578 = (float ****)0x98;
    ppppfStack_57c = (float ****)&DAT_0040bb5c;
    ppppfStack_580 = ppppfVar24;
    ppppfStack_588 = (float ****)0x488e03;
    ppppfStack_584 = (float ****)pppppfVar14;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_578 = (float ****)&DAT_0050b420;
    ppppfStack_57c = (float ****)&DAT_00408c88;
    ppppfStack_580 = (float ****)0x488e1c;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_578 = &pppfStack_310;
  ppppfStack_57c = (float ****)DAT_0050b34c;
  ppppfStack_580 = (float ****)DAT_0050b420;
  ppppfStack_584 = (float ****)0x488e39;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0xb9])();
  uVar26 = 0;
  if ((int)pppppfVar11 < 0) {
    ppppfStack_560 = (float ****)0x2e4;
    ppppfStack_564 = (float ****)&DAT_0040b430;
    ppppfStack_568 = (float ****)pppppfVar14;
    ppppfStack_570 = (float ****)0x488e4d;
    ppppfStack_56c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_560 = (float ****)&DAT_0050b420;
    ppppfStack_564 = (float ****)&DAT_00408c88;
    ppppfStack_568 = (float ****)0x488e66;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  pppppfVar11 = (float *****)ppppfStack_55c;
  if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
  ppppfStack_55c =
       (float ****)(((float)appppfStack_30c[0] - (float)pppfStack_310) * (float)_DAT_00401268);
  pppppfVar11 = (float *****)*DAT_0050b420;
  if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
  ppppfStack_564 = (float ****)DAT_0050b420;
  ppppfStack_568 = (float ****)0x488eab;
  ppppfStack_3c0 = ppppfStack_55c;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x39])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_568 = (float ****)0xe4;
    ppppfStack_56c = (float ****)&DAT_0040b430;
    ppppfStack_570 = (float ****)pppppfVar14;
    ppppfStack_578 = (float ****)0x488ebf;
    ppppfStack_574 = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppfStack_568 = (float ****)0x488ec8;
  __vbaFreeObj();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_568 = (float ****)&DAT_0050b420;
    ppppfStack_56c = (float ****)&DAT_00408c88;
    ppppfStack_570 = (float ****)0x488ee1;
    __vbaNew2();
  }
  ppppfStack_568 = (float ****)DAT_0050b34c;
  ppppfStack_56c = (float ****)DAT_0050b420;
  ppppfStack_570 = (float ****)&DAT_0040bf08;
  ppppfStack_574 = (float ****)0x488efb;
  __vbaPrintObj();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_568 = (float ****)&DAT_0050b420;
    ppppfStack_56c = (float ****)&DAT_00408c88;
    ppppfStack_570 = (float ****)0x488f17;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_568 = (float ****)0x44960000;
  ppppfStack_56c = (float ****)DAT_0050b420;
  ppppfStack_570 = (float ****)0x488f2b;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x39])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_570 = (float ****)0xe4;
    ppppfStack_574 = (float ****)&DAT_0040b430;
    ppppfStack_578 = (float ****)pppppfVar14;
    ppppfStack_580 = (float ****)0x488f43;
    ppppfStack_57c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_570 = (float ****)&DAT_0050b420;
    ppppfStack_574 = (float ****)&DAT_00408c88;
    ppppfStack_578 = (float ****)0x488f5c;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_570 = (float ****)appppfStack_30c;
  ppppfStack_574 = (float ****)DAT_0050b420;
  ppppfStack_578 = (float ****)0x488f72;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x3a])();
  uVar26 = 0;
  if ((int)pppppfVar11 < 0) {
    ppppfStack_560 = (float ****)0xe8;
    ppppfStack_564 = (float ****)&DAT_0040b430;
    ppppfStack_568 = (float ****)pppppfVar14;
    ppppfStack_570 = (float ****)0x488f8a;
    ppppfStack_56c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_560 = (float ****)&DAT_0050b420;
    ppppfStack_564 = (float ****)&DAT_00408c88;
    ppppfStack_568 = (float ****)0x488fa3;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  pppppfVar11 = (float *****)ppppfStack_55c;
  if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
  ppppfStack_564 = (float ****)DAT_0050b420;
  ppppfStack_568 = (float ****)0x488fd8;
  ppppfStack_560 = (float ****)((float)appppfStack_30c[0] * (float)_DAT_004013f0);
  ppppfStack_3c4 = (float ****)((float)appppfStack_30c[0] * (float)_DAT_004013f0);
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x3b])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_568 = (float ****)0xec;
    ppppfStack_56c = (float ****)&DAT_0040b430;
    ppppfStack_570 = (float ****)pppppfVar14;
    ppppfStack_578 = (float ****)0x488ff0;
    ppppfStack_574 = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_568 = (float ****)&DAT_0050b420;
    ppppfStack_56c = (float ****)&DAT_00408c88;
    ppppfStack_570 = (float ****)0x489009;
    __vbaNew2();
  }
  ppppfStack_568 = (float ****)0x40f6d0;
  ppppfStack_56c = *(float *****)(DAT_0050b37c + 4);
  ppppfStack_570 = (float ****)0x48901e;
  __vbaStrCat();
  ppppfStack_570 = (float ****)0x489029;
  ppppfStack_570 = (float ****)__vbaStrMove();
  ppppfStack_574 = (float ****)DAT_0050b420;
  ppppfStack_578 = (float ****)&DAT_0040bf08;
  ppppfStack_57c = (float ****)0x489038;
  __vbaPrintObj();
  ppppfStack_570 = (float ****)0x489044;
  __vbaFreeStr();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_570 = (float ****)&DAT_0050b420;
    ppppfStack_574 = (float ****)&DAT_00408c88;
    ppppfStack_578 = (float ****)0x48905d;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_570 = (float ****)appppfStack_30c;
  ppppfStack_574 = (float ****)DAT_0050b420;
  ppppfStack_578 = (float ****)0x489073;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x3a])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_578 = (float ****)0xe8;
    ppppfStack_57c = (float ****)&DAT_0040b430;
    ppppfStack_580 = (float ****)pppppfVar14;
    ppppfStack_588 = (float ****)0x48908d;
    ppppfStack_584 = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_578 = (float ****)&DAT_0050c53c;
    ppppfStack_57c = (float ****)&DAT_0040b420;
    ppppfStack_580 = (float ****)0x4890ae;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_578 = (float ****)&ppppfStack_1f0;
  ppppfStack_57c = (float ****)DAT_0050c53c;
  ppppfStack_580 = (float ****)0x4890be;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_580 = (float ****)0x18;
    ppppfStack_584 = (float ****)&DAT_0040b410;
    ppppfStack_588 = (float ****)pppppfVar14;
    ppppfStack_590 = (float ****)0x4890cf;
    ppppfStack_58c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppfVar24 = ppppfStack_1f0;
  ppppfStack_580 = &pppfStack_310;
  ppppfStack_584 = ppppfStack_1f0;
  ppppfStack_588 = (float ****)0x4890e4;
  pppppfVar14 = (float *****)(*(code *)(*ppppfStack_1f0)[0x26])();
  if ((int)pppppfVar14 < 0) {
    ppppfStack_588 = (float ****)0x98;
    ppppfStack_58c = (float ****)&DAT_0040bb5c;
    ppppfStack_590 = ppppfVar24;
    ppppfStack_598 = (float ****)0x4890f8;
    ppppfStack_594 = (float ****)pppppfVar14;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_588 = (float ****)&DAT_0050b420;
    ppppfStack_58c = (float ****)&DAT_00408c88;
    ppppfStack_590 = (float ****)0x489111;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_588 = (float ****)&ppppfStack_314;
  ppppfStack_58c = (float ****)DAT_0050b420;
  ppppfStack_590 = (float ****)0x489127;
  pppppfVar15 = (float *****)(*(code *)(*DAT_0050b420)[0x3a])();
  uVar26 = 0;
  pppppfVar11 = extraout_ECX;
  if ((int)pppppfVar15 < 0) {
    ppppfStack_554 = (float ****)0xe8;
    ppppfStack_558 = (float ****)&DAT_0040b430;
    ppppfStack_55c = (float ****)pppppfVar14;
    ppppfStack_564 = (float ****)0x48913b;
    ppppfStack_560 = (float ****)pppppfVar15;
    __vbaHresultCheckObj();
    pppppfVar11 = extraout_ECX_00;
  }
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_554 = (float ****)&DAT_0050b420;
    ppppfStack_558 = (float ****)&DAT_00408c88;
    ppppfStack_55c = (float ****)0x489154;
    __vbaNew2();
    pppppfVar11 = extraout_ECX_01;
  }
  pppppfVar14 = DAT_0050b420;
  ppppfStack_55c = (float ****)((float)pppfStack_310 - _DAT_004020e0);
  ppppfStack_554 = (float ****)0x0;
  ppppfStack_558 = ppppfStack_314;
  if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
  ppppfStack_560 = appppfStack_30c[0];
  ppppfStack_564 = (float ****)0x44960000;
  ppppfStack_568 = (float ****)0x4;
  ppppfStack_56c = (float ****)DAT_0050b420;
  ppppfStack_570 = (float ****)0x489194;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0xb2])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_570 = (float ****)0x2c8;
    ppppfStack_574 = (float ****)&DAT_0040b430;
    ppppfStack_578 = (float ****)pppppfVar14;
    ppppfStack_580 = (float ****)0x4891a8;
    ppppfStack_57c = (float ****)pppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppfStack_570 = (float ****)0x4891b1;
  __vbaFreeObj();
  ppppfStack_570 = (float ****)0x4891c1;
  __vbaStrCopy();
  if (DAT_0050b420 == (float *****)0x0) {
    ppppfStack_570 = (float ****)&DAT_0050b420;
    ppppfStack_574 = (float ****)&DAT_00408c88;
    ppppfStack_578 = (float ****)0x4891da;
    __vbaNew2();
  }
  ppppfStack_570 = (float ****)DAT_0050b420;
  ppppfStack_574 = (float ****)0x4891e8;
  ppppfStack_574 = (float ****)(*(code *)(*DAT_0050b420)[0xea])();
  ppppfStack_578 = (float ****)&ppppfStack_344;
  ppppfStack_57c = (float ****)0x4891f8;
  __vbaObjSet();
  ppppfStack_278 = (float ****)0x3;
  ppppfStack_58c = (float ****)0x7;
  ppppfStack_588 = (float ****)0x3;
  ppppfStack_270 = (float ****)0x1;
  ppppfStack_584 = ppppfStack_274;
  ppppfStack_590 = ppppfStack_344;
  ppppfStack_580 = (float ****)&DAT_00000001;
  ppppfStack_57c = ppppfStack_26c;
  ppppfStack_594 = (float ****)0x489235;
  __vbaLateIdSt();
  ppppfVar24 = (float ****)__vbaLateIdCallLd_exref;
  ppppfStack_278 = (float ****)0x8;
  ppppfStack_5a0 = (float ****)0x8;
  ppppfStack_270 = (float ****)0x40c3f0;
  ppppfStack_5a4 = (float ****)0x0;
  ppppfStack_59c = ppppfStack_274;
  pppfStack_5a8 = (float ***)&DAT_0040eb6c;
  uStack_5ac = 0;
  ppppfStack_598 = (float ****)0x40c3f0;
  uStack_5b0 = 0xfffffe00;
  ppppfStack_5b4 = ppppfStack_344;
  ppppfStack_594 = ppppfStack_26c;
  ppppfStack_5b8 = &pppfStack_208;
  ppppfStack_5bc = (float ****)0x489288;
  uStack_5ac = __vbaLateIdCallLd();
  uStack_5b0 = 0x489292;
  uStack_5b0 = __vbaCastObjVar();
  ppppfStack_5b4 = (float ****)&ppppfStack_1f0;
  ppppfStack_5b8 = (float ****)0x489299;
  ppppfStack_5b8 = (float ****)__vbaObjSet();
  ppppfStack_5bc = (float ****)0x48929c;
  __vbaLateIdSt();
  ppppfStack_5bc = (float ****)0x4892a5;
  __vbaFreeObj();
  pppppfVar14 = (float *****)__vbaFreeVar_exref;
  ppppfStack_5bc = (float ****)0x4892b0;
  __vbaFreeVar();
  ppppfStack_278 = (float ****)0x2;
  uStack_5cc = 2;
  uStack_5c8 = 2;
  ppppfStack_270 = (float ****)0x9;
  puStack_5d0 = &DAT_0040eb6c;
  ppppfStack_5c4 = ppppfStack_274;
  uStack_5d4 = 0;
  uStack_5d8 = 0xfffffe00;
  uStack_5c0 = 9;
  ppppfStack_5dc = ppppfStack_344;
  ppppfStack_5bc = ppppfStack_26c;
  pppfStack_5e0 = (float ***)&pppfStack_208;
  ppppfStack_5e4 = (float ****)0x4892fd;
  uStack_5d4 = __vbaLateIdCallLd();
  uStack_5d8 = 0x489307;
  uStack_5d8 = __vbaCastObjVar();
  ppppfStack_5dc = (float ****)&ppppfStack_1f0;
  pppfStack_5e0 = (float ***)0x489312;
  pppfStack_5e0 = (float ***)__vbaObjSet();
  ppppfStack_5e4 = (float ****)0x489315;
  __vbaLateIdSt();
  ppppfStack_5e4 = (float ****)0x48931e;
  __vbaFreeObj();
  ppppfStack_5e4 = (float ****)0x489323;
  __vbaFreeVar();
  ppppfStack_278 = (float ****)0xb;
  uStack_5f4 = 3;
  uStack_5f0 = 0xb;
  ppppfStack_270 = (float ****)0xffffffff;
  puStack_5f8 = &DAT_0040eb6c;
  ppppfStack_5ec = ppppfStack_274;
  uStack_5fc = 0;
  uStack_600 = 0xfffffe00;
  uStack_5e8 = 0xffffffff;
  ppppfStack_604 = ppppfStack_344;
  ppppfStack_5e4 = ppppfStack_26c;
  pppfStack_608 = (float ***)&pppfStack_208;
  ppppfStack_60c = (float ****)0x48936e;
  uStack_5fc = __vbaLateIdCallLd();
  uStack_600 = 0x489378;
  uStack_600 = __vbaCastObjVar();
  ppppfStack_604 = (float ****)&ppppfStack_1f0;
  pppfStack_608 = (float ***)0x489383;
  pppfStack_608 = (float ***)__vbaObjSet();
  ppppfStack_60c = (float ****)0x489386;
  __vbaLateIdSt();
  ppppfStack_60c = (float ****)0x48938f;
  __vbaFreeObj();
  ppppfStack_60c = (float ****)0x489394;
  __vbaFreeVar();
  ppppfStack_1cc = (float ****)CONCAT22(ppppfStack_1cc._2_2_,DAT_0050b20a);
  if (DAT_0050b238 == 1) {
    ppppfStack_1d0 = (float ****)0x2;
    if ((!SCARRY2(DAT_0050b20a,2)) &&
       (uVar2 = (short)(DAT_0050b20a + 2) * 2, (int)(short)uVar2 == uVar2)) {
      bVar25 = SCARRY2(DAT_0050b20a,1);
      sVar19 = DAT_0050b20a + 1;
LAB_004893fc:
      ppppfStack_1c8 = (float ****)(uVar2 & 0xffff);
      if (!bVar25) {
        ppppfStack_610 = (float ****)(int)sVar19;
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_61c = (float ****)0x5;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48943d;
        ppppfStack_270 = ppppfStack_610;
        __vbaLateIdSt();
        uVar21 = extraout_var_01;
        goto LAB_00489444;
      }
    }
  }
  else {
    uVar21 = extraout_var_00;
    if (DAT_0050b238 == 2) {
      ppppfStack_1d0 = (float ****)0x3;
      if ((!SCARRY2(DAT_0050b20a,2)) &&
         (uVar2 = (short)(DAT_0050b20a + 2) * 3, (int)(short)uVar2 == uVar2)) {
        bVar25 = SCARRY2(DAT_0050b20a,2);
        sVar19 = DAT_0050b20a + 2;
        goto LAB_004893fc;
      }
    }
    else {
LAB_00489444:
      if (_DAT_0050b144 == _DAT_00401490) {
        if (SCARRY2(DAT_0050b20a,3)) goto LAB_0048c2d9;
        ppppfStack_60c = (float ****)0x489474;
        ppppfStack_1c8 = (float ****)CONCAT22(uVar21,DAT_0050b20a + 3);
        __vbaStrCopy();
      }
      ppppfStack_610 = (float ****)(int)(short)ppppfStack_1c8;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_61c = (float ****)0x4;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x4894b0;
      ppppfStack_270 = ppppfStack_610;
      __vbaLateIdSt();
      ppppfStack_624 = (float ****)0x0;
      ppppfStack_628 = (float ****)0x5;
      ppppfStack_630 = &pppfStack_208;
      ppppfStack_62c = ppppfStack_344;
      ppppfStack_634 = (float ****)0x4894c1;
      ppppfStack_624 = (float ****)__vbaLateIdCallLd();
      ppppfStack_628 = (float ****)0x4894cb;
      iVar9 = __vbaI4Var();
      if (!SBORROW4(iVar9,1)) {
        ppppfStack_60c = (float ****)0x4894dc;
        uStack_350 = __vbaI2I4();
        ppppfStack_1b8 = (float ****)0x1;
        ppppfStack_60c = (float ****)0x4894ee;
        __vbaFreeVar();
        pppppfVar14 = (float *****)ppppfStack_28c;
        ppppfVar16 = ppppfStack_1b8;
        do {
          ppppfStack_1b8 = ppppfVar16;
          if ((short)uStack_350 < (short)ppppfStack_1b8) {
            ppppfStack_60c = (float ****)0x4115a4;
            ppppfStack_270 = (float ****)0x0;
            ppppfStack_278 = (float ****)0x3;
            ppppfStack_610 = (float ****)0x489635;
            iVar9 = __vbaLenBstr();
            ppppfVar16 = (float ****)((longlong)iVar9 * 100);
            if ((longlong)(int)ppppfVar16 == (longlong)iVar9 * 100) {
              ppppfStack_618 = ppppfStack_278;
              ppppfStack_614 = ppppfStack_274;
              ppppfStack_610 = ppppfStack_270;
              ppppfStack_60c = ppppfStack_26c;
              ppppfStack_62c = (float ****)0x1;
              ppppfStack_628 = (float ****)0x3;
              ppppfStack_630 = (float ****)0x39;
              ppppfStack_624 = ppppfStack_294;
              ppppfStack_61c = (float ****)pppppfVar14;
              ppppfStack_634 = ppppfStack_344;
              ppppfStack_638 = (float ****)0x489692;
              ppppfStack_620 = ppppfVar16;
              __vbaLateIdCallSt();
              ppppfStack_278 = (float ****)0x3;
              ppppfStack_618 = (float ****)0x3;
              ppppfStack_270 = (float ****)0x0;
              ppppfStack_614 = ppppfStack_274;
              ppppfStack_610 = (float ****)0x0;
              ppppfStack_60c = ppppfStack_26c;
              ppppfStack_628 = (float ****)0x2;
              ppppfStack_62c = (float ****)0x1;
              ppppfStack_630 = (float ****)0x38;
              ppppfStack_624 = ppppfStack_294;
              ppppfStack_620 = (float ****)0x1;
              ppppfStack_634 = ppppfStack_344;
              ppppfStack_61c = (float ****)pppppfVar14;
              ppppfStack_638 = (float ****)0x4896f1;
              __vbaLateIdCallSt();
              if (DAT_0050c53c == (float *****)0x0) {
                ppppfStack_60c = (float ****)&DAT_0050c53c;
                ppppfStack_610 = (float ****)&DAT_0040b420;
                ppppfStack_614 = (float ****)0x48970d;
                __vbaNew2();
              }
              ppppfStack_60c = (float ****)&ppppfStack_1f0;
              ppppfStack_610 = (float ****)DAT_0050c53c;
              ppppfStack_318 = (float ****)DAT_0050c53c;
              ppppfStack_614 = (float ****)0x489722;
              ppppfVar16 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
              if ((int)ppppfVar16 < 0) {
                ppppfStack_614 = (float ****)0x18;
                ppppfStack_618 = (float ****)&DAT_0040b410;
                ppppfStack_61c = ppppfStack_318;
                ppppfStack_624 = (float ****)0x48973d;
                ppppfStack_620 = ppppfVar16;
                __vbaHresultCheckObj();
              }
              ppppfStack_614 = (float ****)appppfStack_30c;
              ppppfStack_618 = ppppfStack_1f0;
              ppppfStack_320 = ppppfStack_1f0;
              ppppfStack_61c = (float ****)0x489756;
              ppppfStack_628 = (float ****)(*(code *)(*ppppfStack_1f0)[0x26])();
              uVar26 = 0;
              if ((int)ppppfStack_628 < 0) {
                ppppfStack_61c = (float ****)0x98;
                ppppfStack_620 = (float ****)&DAT_0040bb5c;
                ppppfStack_624 = ppppfStack_320;
                ppppfStack_62c = (float ****)0x489774;
                __vbaHresultCheckObj();
              }
              ppppfStack_278 = (float ****)0x3;
              ppppfStack_62c = (float ****)&DAT_00000001;
              ppppfStack_628 = (float ****)0x3;
              ppppfStack_270 = (float ****)&DAT_00000001;
              ppppfStack_630 = (float ****)0x39;
              ppppfStack_624 = ppppfStack_274;
              ppppfStack_634 = ppppfStack_344;
              ppppfStack_620 = (float ****)&DAT_00000001;
              ppppfStack_61c = ppppfStack_26c;
              ppppfStack_638 = &pppfStack_208;
              ppppfStack_63c = (float ****)0x4897b7;
              __vbaLateIdCallLd();
              pppppfVar11 = (float *****)ppppfStack_55c;
              if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
              dStack_3cc = (double)((float)appppfStack_30c[0] * (float)_DAT_004016c8);
              ppppfStack_560 = &pppfStack_208;
              ppppfStack_564 = (float ****)0x4897e0;
              iStack_3d0 = __vbaI4Var();
              dVar3 = (double)iStack_3d0;
              uStack_3d8 = dVar3;
              if (DAT_0050b000 != 0) {
                uStack_3d8._4_4_ = (float *****)((ulonglong)dVar3 >> 0x20);
                ppppfStack_560 = (float ****)uStack_3d8._4_4_;
                uStack_3d8._0_4_ = SUB84(dVar3,0);
                ppppfStack_55c = (float ****)(float *****)uStack_3d8;
                ppppfStack_568 = (float ****)0x48981a;
                adj_fdiv_m64();
              }
              pppppfVar11 = (float *****)ppppfStack_55c;
              if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
              ppppfStack_560 = (float ****)0x48982a;
              ppppfStack_1c0 = (float ****)__vbaFpI2();
              ppppfStack_560 = (float ****)0x489836;
              __vbaFreeObj();
              ppppfStack_560 = (float ****)0x48983f;
              __vbaFreeVar();
              ppppfStack_560 = (float ****)0x0;
              ppppfStack_564 = (float ****)0x5;
              ppppfStack_56c = &pppfStack_208;
              ppppfStack_568 = ppppfStack_344;
              ppppfStack_570 = (float ****)0x489850;
              __vbaLateIdCallLd();
              ppppfStack_560 = &pppfStack_208;
              ppppfStack_280 = (float ****)&ppppfStack_1c0;
              pppfStack_288 = (float ***)0x4002;
              ppppfStack_564 = (float ****)0x489870;
              iVar9 = __vbaI4Var();
              ppppfStack_60c = &pppfStack_288;
              if (!SBORROW4(iVar9,1)) {
                ppppfStack_610 = (float ****)&ppppfStack_218;
                ppppfStack_614 = &pppfStack_228;
                ppppfStack_218 = (float ****)0x3;
                ppppfStack_618 = (float ****)0x48989a;
                pppfStack_210 = (float ***)(iVar9 + -1);
                FUN_0042b040();
                ppppfStack_628 = (float ****)0x1;
                ppppfStack_62c = (float ****)0x39;
                ppppfStack_624 = (float ****)0x3;
                ppppfStack_620 = ppppfStack_294;
                ppppfStack_61c = (float ****)0x1;
                ppppfStack_634 = &pppfStack_238;
                ppppfStack_618 = (float ****)pppppfVar14;
                ppppfStack_630 = ppppfStack_344;
                ppppfStack_638 = (float ****)0x4898cd;
                ppppfStack_618 = (float ****)__vbaLateIdCallLd();
                ppppfStack_61c = (float ****)0x4898d7;
                ppppfStack_2b0 = (float ****)__vbaI4Var();
                ppppfStack_2b8 = (float ****)0x3;
                ppppfStack_628 = (float ****)0x3;
                ppppfStack_62c = (float ****)&DAT_00000001;
                ppppfStack_630 = (float ****)0x39;
                ppppfStack_624 = ppppfStack_2c4;
                ppppfStack_634 = ppppfStack_344;
                ppppfStack_620 = (float ****)0x0;
                ppppfStack_61c = (float ****)pppfStack_2bc;
                ppppfStack_638 = (float ****)&ppppfStack_258;
                ppppfStack_63c = (float ****)0x48991a;
                ppppfStack_61c = (float ****)__vbaLateIdCallLd();
                ppppfStack_620 = (float ****)0x489924;
                iStack_3dc = __vbaI4Var();
                dStack_3e4 = (double)iStack_3dc;
                apppfStack_2e8[0] = (float ***)0x5;
                dStack_2e0 = dStack_3e4 * _DAT_00402038;
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_560 = &pppfStack_228;
                ppppfStack_56c = (float ****)0x489977;
                ppppfStack_568 = (float ****)&ppppfStack_248;
                ppppfStack_564 = (float ****)&ppppfStack_2b8;
                ppppfStack_56c = (float ****)__vbaVarMul();
                ppppfStack_570 = apppfStack_2e8;
                ppppfStack_574 = &pppfStack_268;
                ppppfStack_578 = (float ****)0x48998c;
                ppppfStack_578 = (float ****)__vbaVarAdd();
                ppppfStack_57c = (float ****)0x489993;
                fVar27 = (float10)__vbaR4Var();
                ppppfStack_580 = (float ****)(float)fVar27;
                ppppfStack_58c = (float ****)0x80010005;
                ppppfStack_588 = (float ****)0x4;
                ppppfStack_584 = ppppfStack_2f4;
                ppppfStack_590 = ppppfStack_344;
                ppppfStack_57c = ppppfStack_2ec;
                ppppfStack_594 = (float ****)0x4899ce;
                ppppfStack_2f0 = ppppfStack_580;
                __vbaLateIdSt();
                ppppfStack_594 = &pppfStack_268;
                ppppfStack_598 = (float ****)&ppppfStack_258;
                ppppfStack_59c = &pppfStack_228;
                ppppfStack_5a0 = &pppfStack_238;
                ppppfStack_5a4 = (float ****)&ppppfStack_218;
                pppfStack_5a8 = (float ***)&pppfStack_208;
                uStack_5ac = 6;
                uStack_5b0 = 0x4899fa;
                __vbaFreeVarList();
                uStack_5b0 = 0;
                ppppfStack_5b4 = (float ****)0x80010005;
                ppppfStack_5bc = &pppfStack_208;
                ppppfStack_5b8 = ppppfStack_344;
                uStack_5c0 = 0x489a0e;
                __vbaLateIdCallLd();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_594 = (float ****)&DAT_0050c53c;
                  ppppfStack_598 = (float ****)&DAT_0040b420;
                  ppppfStack_59c = (float ****)0x489a2a;
                  __vbaNew2();
                }
                ppppfStack_594 = (float ****)&ppppfStack_1f0;
                ppppfStack_598 = (float ****)DAT_0050c53c;
                ppppfStack_318 = (float ****)DAT_0050c53c;
                ppppfStack_59c = (float ****)0x489a3f;
                ppppfVar16 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
                if ((int)ppppfVar16 < 0) {
                  ppppfStack_59c = (float ****)0x18;
                  ppppfStack_5a0 = (float ****)&DAT_0040b410;
                  ppppfStack_5a4 = ppppfStack_318;
                  uStack_5ac = 0x489a5a;
                  pppfStack_5a8 = (float ***)ppppfVar16;
                  __vbaHresultCheckObj();
                }
                ppppfStack_59c = (float ****)appppfStack_30c;
                ppppfStack_5a0 = ppppfStack_1f0;
                ppppfStack_320 = ppppfStack_1f0;
                ppppfStack_5a4 = (float ****)0x489a73;
                pppppfVar11 = (float *****)(*(code *)(*ppppfStack_1f0)[0x26])();
                uVar26 = 0;
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_560 = (float ****)0x98;
                  ppppfStack_564 = (float ****)&DAT_0040bb5c;
                  ppppfStack_568 = ppppfStack_320;
                  ppppfStack_570 = (float ****)0x489a91;
                  ppppfStack_56c = (float ****)pppppfVar11;
                  __vbaHresultCheckObj();
                }
                pppfStack_228 = (float ***)0x5;
                uStack_220 = (double)((float)appppfStack_30c[0] * (float)_DAT_00401760);
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_560 = &pppfStack_208;
                ppppfStack_564 = (float ****)0x489abe;
                fVar27 = (float10)__vbaR4Var();
                pppfStack_210 = (float ***)(float)fVar27;
                ppppfStack_564 = &pppfStack_228;
                ppppfStack_568 = (float ****)&ppppfStack_218;
                ppppfStack_56c = &pppfStack_238;
                ppppfStack_218 = (float ****)0x4;
                ppppfStack_570 = (float ****)0x489adf;
                FUN_0042b040();
                ppppfStack_570 = &pppfStack_238;
                ppppfStack_574 = (float ****)0x489aec;
                fVar27 = (float10)__vbaR4Var();
                ppppfStack_578 = (float ****)(float)fVar27;
                ppppfStack_584 = (float ****)0x80010005;
                ppppfStack_580 = (float ****)0x4;
                ppppfStack_57c = ppppfStack_294;
                ppppfStack_574 = (float ****)pppppfVar14;
                ppppfStack_588 = ppppfStack_344;
                ppppfStack_58c = (float ****)0x489b21;
                ppppfStack_290 = ppppfStack_578;
                __vbaLateIdSt();
                ppppfStack_58c = (float ****)0x489b2a;
                __vbaFreeObj();
                ppppfStack_58c = &pppfStack_238;
                ppppfStack_590 = &pppfStack_228;
                ppppfStack_594 = (float ****)&ppppfStack_218;
                ppppfStack_598 = &pppfStack_208;
                ppppfStack_59c = (float ****)0x4;
                ppppfStack_5a0 = (float ****)0x489b48;
                __vbaFreeVarList();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_58c = (float ****)&DAT_0050c53c;
                  ppppfStack_590 = (float ****)&DAT_0040b420;
                  ppppfStack_594 = (float ****)0x489b64;
                  __vbaNew2();
                }
                pppppfVar14 = DAT_0050c53c;
                ppppfStack_58c = (float ****)&ppppfStack_1f0;
                ppppfStack_590 = (float ****)DAT_0050c53c;
                ppppfStack_594 = (float ****)0x489b74;
                iVar9 = (*(code *)(*DAT_0050c53c)[6])();
                if (iVar9 < 0) {
                  ppppfStack_594 = (float ****)0x18;
                  ppppfStack_598 = (float ****)&DAT_0040b410;
                  ppppfStack_59c = (float ****)pppppfVar14;
                  ppppfStack_5a4 = (float ****)0x489b89;
                  ppppfStack_5a0 = (float ****)iVar9;
                  __vbaHresultCheckObj();
                }
                ppppfVar16 = ppppfStack_1f0;
                ppppfStack_594 = (float ****)appppfStack_30c;
                ppppfStack_598 = ppppfStack_1f0;
                ppppfStack_59c = (float ****)0x489b9b;
                pppfStack_5a8 = (float ***)(*(code *)(*ppppfStack_1f0)[0x14])();
                uVar26 = 0;
                if ((int)pppfStack_5a8 < 0) {
                  ppppfStack_59c = (float ****)0x50;
                  ppppfStack_5a0 = (float ****)&DAT_0040bb5c;
                  ppppfStack_5a4 = ppppfVar16;
                  uStack_5ac = 0x489bb0;
                  __vbaHresultCheckObj();
                }
                ppppfStack_278 = (float ****)0x3;
                uStack_5ac = 1;
                pppfStack_5a8 = (float ***)0x3;
                ppppfStack_270 = (float ****)&DAT_00000001;
                uStack_5b0 = 0x3a;
                ppppfStack_5a4 = ppppfStack_274;
                ppppfStack_5b4 = ppppfStack_344;
                ppppfStack_5a0 = (float ****)&DAT_00000001;
                ppppfStack_59c = ppppfStack_26c;
                ppppfStack_5b8 = &pppfStack_208;
                ppppfStack_5bc = (float ****)0x489bf3;
                __vbaLateIdCallLd();
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                dStack_3ec = (double)((float)appppfStack_30c[0] * (float)_DAT_00401268);
                ppppfStack_560 = &pppfStack_208;
                ppppfStack_564 = (float ****)0x489c1c;
                iStack_3f0 = __vbaI4Var();
                dVar3 = (double)iStack_3f0;
                uStack_3f8 = dVar3;
                if (DAT_0050b000 != 0) {
                  uStack_3f8._4_4_ = (float *****)((ulonglong)dVar3 >> 0x20);
                  ppppfStack_560 = (float ****)uStack_3f8._4_4_;
                  uStack_3f8._0_4_ = SUB84(dVar3,0);
                  ppppfStack_55c = (float ****)(float *****)uStack_3f8;
                  ppppfStack_568 = (float ****)0x489c56;
                  adj_fdiv_m64();
                }
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_560 = (float ****)0x489c66;
                __vbaFpI2();
                ppppfStack_560 = (float ****)0x489c6f;
                __vbaFreeObj();
                ppppfStack_560 = (float ****)0x489c78;
                __vbaFreeVar();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_560 = (float ****)&DAT_0050c53c;
                  ppppfStack_564 = (float ****)&DAT_0040b420;
                  ppppfStack_568 = (float ****)0x489c91;
                  __vbaNew2();
                }
                pppppfVar14 = DAT_0050c53c;
                ppppfStack_560 = (float ****)&ppppfStack_1f0;
                ppppfStack_564 = (float ****)DAT_0050c53c;
                ppppfStack_568 = (float ****)0x489ca1;
                pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_568 = (float ****)0x18;
                  ppppfStack_56c = (float ****)&DAT_0040b410;
                  ppppfStack_570 = (float ****)pppppfVar14;
                  ppppfStack_578 = (float ****)0x489cb6;
                  ppppfStack_574 = (float ****)pppppfVar11;
                  __vbaHresultCheckObj();
                }
                ppppfVar16 = ppppfStack_1f0;
                ppppfStack_568 = (float ****)appppfStack_30c;
                ppppfStack_56c = ppppfStack_1f0;
                ppppfStack_570 = (float ****)0x489ccb;
                ppppfStack_57c = (float ****)(*(code *)(*ppppfStack_1f0)[0x26])();
                uVar26 = 0;
                if ((int)ppppfStack_57c < 0) {
                  ppppfStack_570 = (float ****)0x98;
                  ppppfStack_574 = (float ****)&DAT_0040bb5c;
                  ppppfStack_578 = ppppfVar16;
                  ppppfStack_580 = (float ****)0x489ce3;
                  __vbaHresultCheckObj();
                }
                ppppfStack_570 = (float ****)0x0;
                ppppfStack_574 = (float ****)0x80010005;
                ppppfStack_57c = &pppfStack_208;
                ppppfStack_578 = ppppfStack_344;
                ppppfStack_580 = (float ****)0x489cf7;
                __vbaLateIdCallLd();
                ppppfStack_570 = &pppfStack_208;
                ppppfStack_574 = (float ****)0x489d04;
                fVar27 = (float10)__vbaR4Var();
                pppppfVar11 = (float *****)ppppfStack_55c;
                if (((uVar26 & 0xd) != 0) ||
                   (ppppfStack_270 =
                         (float ****)
                         (float)(((float10)(float)appppfStack_30c[0] - fVar27) *
                                (float10)_DAT_00401268), (uVar26 & 0xd) != 0)) goto LAB_0048c2d4;
                ppppfStack_278 = (float ****)0x4;
                ppppfStack_570 = (float ****)0x80010003;
                ppppfStack_56c = (float ****)0x4;
                ppppfStack_568 = ppppfStack_274;
                ppppfStack_574 = ppppfStack_344;
                ppppfStack_560 = ppppfStack_26c;
                ppppfStack_578 = (float ****)0x489d65;
                ppppfStack_564 = ppppfStack_270;
                __vbaLateIdSt();
                ppppfStack_578 = (float ****)0x489d6e;
                __vbaFreeObj();
                ppppfStack_578 = (float ****)0x489d77;
                __vbaFreeVar();
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_578 = (float ****)&DAT_0050b420;
                  ppppfStack_57c = (float ****)&DAT_00408c88;
                  ppppfStack_580 = (float ****)0x489d90;
                  __vbaNew2();
                }
                pppppfVar14 = DAT_0050b420;
                ppppfStack_578 = (float ****)appppfStack_30c;
                ppppfStack_57c = (float ****)DAT_0050b420;
                ppppfStack_580 = (float ****)0x489da6;
                pppppfVar11 = (float *****)(*(code *)(*DAT_0050b420)[0x3a])();
                uVar26 = 0;
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_560 = (float ****)0xe8;
                  ppppfStack_564 = (float ****)&DAT_0040b430;
                  ppppfStack_568 = (float ****)pppppfVar14;
                  ppppfStack_570 = (float ****)0x489dbe;
                  ppppfStack_56c = (float ****)pppppfVar11;
                  __vbaHresultCheckObj();
                }
                ppppfStack_270 = (float ****)((float)appppfStack_30c[0] * (float)_DAT_004013e8);
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_278 = (float ****)0x4;
                ppppfStack_570 = (float ****)0x80010004;
                ppppfStack_56c = (float ****)0x4;
                ppppfStack_568 = ppppfStack_274;
                ppppfStack_574 = ppppfStack_344;
                ppppfStack_560 = ppppfStack_26c;
                ppppfStack_578 = (float ****)0x489e15;
                ppppfStack_564 = ppppfStack_270;
                __vbaLateIdSt();
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_578 = (float ****)&DAT_0050b420;
                  ppppfStack_57c = (float ****)&DAT_00408c88;
                  ppppfStack_580 = (float ****)0x489e2e;
                  __vbaNew2();
                }
                ppppfStack_578 = (float ****)DAT_0050b420;
                ppppfStack_57c = (float ****)0x489e3c;
                ppppfStack_57c = (float ****)(*(code *)(*DAT_0050b420)[0xdb])();
                ppppfStack_580 = (float ****)&ppppfStack_1f0;
                ppppfStack_584 = (float ****)0x489e47;
                pppppfVar14 = (float *****)__vbaObjSet();
                ppppfStack_584 = (float ****)appppfStack_30c;
                ppppfStack_58c = (float ****)0x489e59;
                ppppfStack_588 = (float ****)pppppfVar14;
                pppppfVar11 = (float *****)(*(code *)(*pppppfVar14)[0x22])();
                uVar26 = 0;
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_58c = (float ****)0x88;
                  ppppfStack_590 = (float ****)&DAT_0040c3dc;
                  ppppfStack_59c = (float ****)0x489e71;
                  ppppfStack_598 = (float ****)pppppfVar11;
                  ppppfStack_594 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_58c = (float ****)&DAT_0050b420;
                  ppppfStack_590 = (float ****)&DAT_00408c88;
                  ppppfStack_594 = (float ****)0x489e8a;
                  __vbaNew2();
                }
                ppppfStack_58c = (float ****)DAT_0050b420;
                ppppfStack_590 = (float ****)0x489e98;
                ppppfStack_590 = (float ****)(*(code *)(*DAT_0050b420)[0xdb])();
                ppppfStack_594 = (float ****)&ppppfStack_1f4;
                ppppfStack_598 = (float ****)0x489ea3;
                ppppfStack_320 = (float ****)__vbaObjSet();
                ppppfVar16 = (float ****)*ppppfStack_320;
                ppppfStack_598 = (float ****)0x0;
                ppppfStack_59c = (float ****)0x80010004;
                ppppfStack_5a4 = &pppfStack_208;
                ppppfStack_5a0 = ppppfStack_344;
                pppfStack_5a8 = (float ***)0x489ebf;
                ppppfStack_598 = (float ****)__vbaLateIdCallLd();
                ppppfStack_59c = (float ****)0x489ec9;
                fVar27 = (float10)__vbaR4Var();
                ppppfVar5 = ppppfStack_320;
                pppppfVar11 = extraout_ECX_02;
                pppfStack_3fc = (float ***)ppppfVar16;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_55c = (float ****)(float)(fVar27 - (float10)(float)appppfStack_30c[0]);
                ppppfStack_560 = ppppfStack_320;
                ppppfStack_564 = (float ****)0x489ef3;
                ppppfStack_570 = (float ****)(*(code *)ppppfVar16[0x1f])();
                if ((int)ppppfStack_570 < 0) {
                  ppppfStack_564 = (float ****)0x7c;
                  ppppfStack_568 = (float ****)&DAT_0040c3dc;
                  ppppfStack_56c = ppppfVar5;
                  ppppfStack_574 = (float ****)0x489f08;
                  __vbaHresultCheckObj();
                }
                ppppfStack_564 = (float ****)&ppppfStack_1f4;
                ppppfStack_568 = (float ****)&ppppfStack_1f0;
                ppppfStack_56c = (float ****)0x2;
                ppppfStack_570 = (float ****)0x489f18;
                __vbaFreeObjList();
                ppppfStack_564 = (float ****)0x489f24;
                __vbaFreeVar();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_564 = (float ****)&DAT_0050c53c;
                  ppppfStack_568 = (float ****)&DAT_0040b420;
                  ppppfStack_56c = (float ****)0x489f3d;
                  __vbaNew2();
                }
                pppppfVar14 = DAT_0050c53c;
                ppppfStack_564 = (float ****)&ppppfStack_1f0;
                ppppfStack_568 = (float ****)DAT_0050c53c;
                ppppfStack_56c = (float ****)0x489f4d;
                pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_56c = (float ****)0x18;
                  ppppfStack_570 = (float ****)&DAT_0040b410;
                  ppppfStack_574 = (float ****)pppppfVar14;
                  ppppfStack_57c = (float ****)0x489f62;
                  ppppfStack_578 = (float ****)pppppfVar11;
                  __vbaHresultCheckObj();
                }
                ppppfVar16 = ppppfStack_1f0;
                ppppfStack_56c = (float ****)appppfStack_30c;
                ppppfStack_570 = ppppfStack_1f0;
                ppppfStack_574 = (float ****)0x489f77;
                pppppfVar14 = (float *****)(*(code *)(*ppppfStack_1f0)[0x26])();
                if ((int)pppppfVar14 < 0) {
                  ppppfStack_574 = (float ****)0x98;
                  ppppfStack_578 = (float ****)&DAT_0040bb5c;
                  ppppfStack_57c = ppppfVar16;
                  ppppfStack_584 = (float ****)0x489f8f;
                  ppppfStack_580 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_574 = (float ****)&DAT_0050b420;
                  ppppfStack_578 = (float ****)&DAT_00408c88;
                  ppppfStack_57c = (float ****)0x489fa8;
                  __vbaNew2();
                }
                ppppfStack_574 = (float ****)DAT_0050b420;
                ppppfStack_578 = (float ****)0x489fb6;
                ppppfStack_578 = (float ****)(*(code *)(*DAT_0050b420)[0xdb])();
                ppppfStack_57c = (float ****)&ppppfStack_1f4;
                ppppfStack_580 = (float ****)0x489fc1;
                pppppfVar14 = (float *****)__vbaObjSet();
                ppppfStack_580 = &pppfStack_310;
                ppppfStack_588 = (float ****)0x489fd3;
                ppppfStack_584 = (float ****)pppppfVar14;
                pppppfVar11 = (float *****)(*(code *)(*pppppfVar14)[0x20])();
                uVar26 = 0;
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_588 = (float ****)0x80;
                  ppppfStack_58c = (float ****)&DAT_0040c3dc;
                  ppppfStack_598 = (float ****)0x489feb;
                  ppppfStack_594 = (float ****)pppppfVar11;
                  ppppfStack_590 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_588 = (float ****)&DAT_0050b420;
                  ppppfStack_58c = (float ****)&DAT_00408c88;
                  ppppfStack_590 = (float ****)0x48a004;
                  __vbaNew2();
                }
                ppppfStack_588 = (float ****)DAT_0050b420;
                ppppfStack_58c = (float ****)0x48a012;
                ppppfStack_58c = (float ****)(*(code *)(*DAT_0050b420)[0xdb])();
                ppppfStack_590 = (float ****)&ppppfStack_1f8;
                ppppfStack_594 = (float ****)0x48a01d;
                pppppfVar14 = (float *****)__vbaObjSet();
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_55c =
                     (float ****)
                     (((float)appppfStack_30c[0] - (float)pppfStack_310) * (float)_DAT_00401268);
                pppppfVar11 = (float *****)*pppppfVar14;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_568 = (float ****)0x48a05b;
                ppppfStack_564 = (float ****)pppppfVar14;
                ppppfStack_400 = ppppfStack_55c;
                ppppfStack_574 = (float ****)(*(code *)(*pppppfVar14)[0x1d])();
                if ((int)ppppfStack_574 < 0) {
                  ppppfStack_568 = (float ****)0x74;
                  ppppfStack_56c = (float ****)&DAT_0040c3dc;
                  ppppfStack_578 = (float ****)0x48a070;
                  ppppfStack_570 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                ppppfStack_568 = (float ****)&ppppfStack_1f8;
                ppppfStack_56c = (float ****)&ppppfStack_1f4;
                ppppfStack_570 = (float ****)&ppppfStack_1f0;
                ppppfStack_574 = (float ****)0x3;
                ppppfStack_578 = (float ****)0x48a084;
                __vbaFreeObjList();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_568 = (float ****)&DAT_0050c53c;
                  ppppfStack_56c = (float ****)&DAT_0040b420;
                  ppppfStack_570 = (float ****)0x48a0a0;
                  __vbaNew2();
                }
                pppppfVar14 = DAT_0050c53c;
                ppppfStack_568 = (float ****)&ppppfStack_1f0;
                ppppfStack_56c = (float ****)DAT_0050c53c;
                ppppfStack_570 = (float ****)0x48a0b0;
                pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_570 = (float ****)0x18;
                  ppppfStack_574 = (float ****)&DAT_0040b410;
                  ppppfStack_578 = (float ****)pppppfVar14;
                  ppppfStack_580 = (float ****)0x48a0c5;
                  ppppfStack_57c = (float ****)pppppfVar11;
                  __vbaHresultCheckObj();
                }
                ppppfVar16 = ppppfStack_1f0;
                ppppfStack_570 = (float ****)appppfStack_30c;
                ppppfStack_574 = ppppfStack_1f0;
                ppppfStack_578 = (float ****)0x48a0d7;
                pppppfVar14 = (float *****)(*(code *)(*ppppfStack_1f0)[0x14])();
                uVar26 = 0;
                if ((int)pppppfVar14 < 0) {
                  ppppfStack_578 = (float ****)0x50;
                  ppppfStack_57c = (float ****)&DAT_0040bb5c;
                  ppppfStack_580 = ppppfVar16;
                  ppppfStack_588 = (float ****)0x48a0ec;
                  ppppfStack_584 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_578 = (float ****)&DAT_0050b420;
                  ppppfStack_57c = (float ****)&DAT_00408c88;
                  ppppfStack_580 = (float ****)0x48a105;
                  __vbaNew2();
                }
                ppppfStack_578 = (float ****)DAT_0050b420;
                ppppfStack_57c = (float ****)0x48a113;
                ppppfStack_57c = (float ****)(*(code *)(*DAT_0050b420)[0xdf])();
                ppppfStack_580 = (float ****)&ppppfStack_1f4;
                ppppfStack_584 = (float ****)0x48a11e;
                pppppfVar14 = (float *****)__vbaObjSet();
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_568 = (float ****)0x48a14c;
                ppppfStack_564 = (float ****)pppppfVar14;
                ppppfStack_560 = (float ****)((float)appppfStack_30c[0] * (float)_DAT_00401760);
                ppppfStack_404 = (float ****)((float)appppfStack_30c[0] * (float)_DAT_00401760);
                ppppfStack_574 = (float ****)(*(code *)(*pppppfVar14)[0x1f])();
                if ((int)ppppfStack_574 < 0) {
                  ppppfStack_568 = (float ****)0x7c;
                  ppppfStack_56c = (float ****)&DAT_0040c3dc;
                  ppppfStack_578 = (float ****)0x48a161;
                  ppppfStack_570 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                ppppfStack_568 = (float ****)&ppppfStack_1f4;
                ppppfStack_56c = (float ****)&ppppfStack_1f0;
                ppppfStack_570 = (float ****)0x2;
                ppppfStack_574 = (float ****)0x48a171;
                __vbaFreeObjList();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_568 = (float ****)&DAT_0050c53c;
                  ppppfStack_56c = (float ****)&DAT_0040b420;
                  ppppfStack_570 = (float ****)0x48a18d;
                  __vbaNew2();
                }
                pppppfVar14 = DAT_0050c53c;
                ppppfStack_568 = (float ****)&ppppfStack_1f0;
                ppppfStack_56c = (float ****)DAT_0050c53c;
                ppppfStack_570 = (float ****)0x48a19d;
                pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_570 = (float ****)0x18;
                  ppppfStack_574 = (float ****)&DAT_0040b410;
                  ppppfStack_578 = (float ****)pppppfVar14;
                  ppppfStack_580 = (float ****)0x48a1b2;
                  ppppfStack_57c = (float ****)pppppfVar11;
                  __vbaHresultCheckObj();
                }
                ppppfVar16 = ppppfStack_1f0;
                ppppfStack_570 = (float ****)appppfStack_30c;
                ppppfStack_574 = ppppfStack_1f0;
                ppppfStack_578 = (float ****)0x48a1c7;
                pppppfVar14 = (float *****)(*(code *)(*ppppfStack_1f0)[0x26])();
                if ((int)pppppfVar14 < 0) {
                  ppppfStack_578 = (float ****)0x98;
                  ppppfStack_57c = (float ****)&DAT_0040bb5c;
                  ppppfStack_580 = ppppfVar16;
                  ppppfStack_588 = (float ****)0x48a1df;
                  ppppfStack_584 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_578 = (float ****)&DAT_0050b420;
                  ppppfStack_57c = (float ****)&DAT_00408c88;
                  ppppfStack_580 = (float ****)0x48a1f8;
                  __vbaNew2();
                }
                ppppfStack_578 = (float ****)DAT_0050b420;
                ppppfStack_57c = (float ****)0x48a206;
                ppppfStack_57c = (float ****)(*(code *)(*DAT_0050b420)[0xdf])();
                ppppfStack_580 = (float ****)&ppppfStack_1f4;
                ppppfStack_584 = (float ****)0x48a211;
                pppppfVar14 = (float *****)__vbaObjSet();
                ppppfStack_584 = &pppfStack_310;
                ppppfStack_58c = (float ****)0x48a223;
                ppppfStack_588 = (float ****)pppppfVar14;
                pppppfVar11 = (float *****)(*(code *)(*pppppfVar14)[0x20])();
                uVar26 = 0;
                if ((int)pppppfVar11 < 0) {
                  ppppfStack_58c = (float ****)0x80;
                  ppppfStack_590 = (float ****)&DAT_0040c3dc;
                  ppppfStack_59c = (float ****)0x48a23b;
                  ppppfStack_598 = (float ****)pppppfVar11;
                  ppppfStack_594 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b420 == (float *****)0x0) {
                  ppppfStack_58c = (float ****)&DAT_0050b420;
                  ppppfStack_590 = (float ****)&DAT_00408c88;
                  ppppfStack_594 = (float ****)0x48a254;
                  __vbaNew2();
                }
                ppppfStack_58c = (float ****)DAT_0050b420;
                ppppfStack_590 = (float ****)0x48a262;
                ppppfStack_590 = (float ****)(*(code *)(*DAT_0050b420)[0xdf])();
                ppppfStack_594 = (float ****)&ppppfStack_1f8;
                ppppfStack_598 = (float ****)0x48a26d;
                pppppfVar14 = (float *****)__vbaObjSet();
                pppppfVar11 = (float *****)ppppfStack_55c;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_55c =
                     (float ****)
                     (((float)appppfStack_30c[0] - (float)pppfStack_310) * (float)_DAT_00401268);
                pppppfVar11 = (float *****)*pppppfVar14;
                if ((uVar26 & 0xd) != 0) goto LAB_0048c2d4;
                ppppfStack_568 = (float ****)0x48a2ab;
                ppppfStack_564 = (float ****)pppppfVar14;
                ppppfStack_408 = ppppfStack_55c;
                ppppfStack_574 = (float ****)(*(code *)(*pppppfVar14)[0x1d])();
                if ((int)ppppfStack_574 < 0) {
                  ppppfStack_568 = (float ****)0x74;
                  ppppfStack_56c = (float ****)&DAT_0040c3dc;
                  ppppfStack_578 = (float ****)0x48a2c0;
                  ppppfStack_570 = (float ****)pppppfVar14;
                  __vbaHresultCheckObj();
                }
                ppppfStack_568 = (float ****)&ppppfStack_1f8;
                ppppfStack_56c = (float ****)&ppppfStack_1f4;
                ppppfStack_570 = (float ****)&ppppfStack_1f0;
                ppppfStack_574 = (float ****)0x3;
                ppppfStack_578 = (float ****)0x48a2d4;
                __vbaFreeObjList();
                ppppfStack_568 = (float ****)0x48a2dc;
                iStack_40c = FUN_0042b130();
                ppppfStack_56c = (float ****)(float)iStack_40c;
                ppppfStack_278 = (float ****)0x4;
                ppppfStack_578 = (float ****)0x80010006;
                ppppfStack_574 = (float ****)0x4;
                ppppfStack_570 = ppppfStack_274;
                ppppfStack_57c = ppppfStack_344;
                ppppfStack_568 = ppppfStack_26c;
                ppppfStack_580 = (float ****)0x48a329;
                ppppfStack_270 = ppppfStack_56c;
                __vbaLateIdSt();
                pppppfVar14 = (float *****)__vbaI4Var_exref;
                ppppfStack_1c0 = (float ****)0x1;
                uVar10 = extraout_ECX_03;
                ppppfVar16 = ppppfStack_1c0;
                goto LAB_0048a337;
              }
            }
            break;
          }
          ppppfStack_270 = (float ****)(int)(short)ppppfStack_1b8;
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_60c = (float ****)0x48951c;
          FUN_0044fdc0();
          ppppfStack_60c = (float ****)0x489527;
          ppppfStack_60c = (float ****)__vbaStrMove();
          ppppfStack_610 = (float ****)0x48952e;
          iVar9 = __vbaLenBstr();
          ppppfVar16 = (float ****)((longlong)iVar9 * 0x8c);
          if ((longlong)(int)ppppfVar16 != (longlong)iVar9 * 0x8c) break;
          ppppfStack_618 = ppppfStack_278;
          ppppfStack_614 = ppppfStack_274;
          ppppfStack_610 = ppppfStack_270;
          ppppfStack_60c = ppppfStack_26c;
          ppppfStack_62c = (float ****)0x1;
          ppppfStack_628 = (float ****)0x3;
          ppppfStack_630 = (float ****)0x39;
          ppppfStack_624 = ppppfStack_294;
          ppppfStack_61c = (float ****)pppppfVar14;
          ppppfStack_634 = ppppfStack_344;
          ppppfStack_638 = (float ****)0x48958e;
          ppppfStack_620 = ppppfVar16;
          __vbaLateIdCallSt();
          ppppfStack_60c = (float ****)0x48959a;
          __vbaFreeStr();
          ppppfStack_610 = (float ****)(int)(short)ppppfStack_1b8;
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_618 = (float ****)0x3;
          ppppfStack_614 = ppppfStack_274;
          ppppfStack_62c = (float ****)&DAT_00000001;
          ppppfStack_630 = (float ****)0x38;
          ppppfStack_60c = ppppfStack_26c;
          ppppfStack_628 = (float ****)0x2;
          ppppfStack_624 = ppppfStack_294;
          ppppfStack_620 = (float ****)0x7;
          ppppfStack_634 = ppppfStack_344;
          ppppfStack_61c = (float ****)pppppfVar14;
          ppppfStack_638 = (float ****)0x4895fc;
          ppppfStack_270 = ppppfStack_610;
          __vbaLateIdCallSt();
          bVar25 = SCARRY2((short)ppppfStack_1b8,1);
          uVar26 = (short)ppppfStack_1b8 + 1;
          ppppfVar16 = (float ****)(uint)uVar26;
        } while (!bVar25);
      }
    }
  }
  goto LAB_0048c2d9;
LAB_0048a337:
  do {
    ppppfStack_1c0 = ppppfVar16;
    sVar19 = (short)ppppfStack_1c0;
    if ((short)ppppfStack_1d0 < sVar19) goto LAB_0048c219;
    uVar21 = (undefined2)((uint)uVar10 >> 0x10);
    pppfStack_608 = (float ***)0x0;
    if (SCARRY2(DAT_0050b20a,2)) break;
    pppfStack_608 = (float ***)0x5;
    if ((SBORROW2(sVar19,1)) ||
       (iVar9 = (int)(short)(DAT_0050b20a + 2) * (int)(short)(sVar19 + -1), sVar19 = (short)iVar9,
       sVar19 != iVar9)) break;
    pppppfVar11 = (float *****)CONCAT22(uVar21,sVar19 + 1);
    if (SCARRY2(sVar19,1)) break;
    ppppfStack_614 = ppppfStack_344;
    pppfStack_608 = (float ***)&pppfStack_208;
    ppppfStack_1c4 = (float ****)pppppfVar11;
    if (SBORROW2(sVar19 + 1,1)) break;
    ppppfStack_61c = (float ****)0x48a391;
    pppfStack_1bc = (float ***)CONCAT22(uVar21,sVar19);
    ppppfStack_60c = (float ****)__vbaLateIdCallLd();
    ppppfStack_610 = (float ****)0x48a397;
    iVar9 = __vbaI4Var();
    if (SBORROW4(iVar9,1)) break;
    ppppfStack_60c = (float ****)0x48a3a8;
    uStack_360 = __vbaI2I4();
    ppppfStack_1b8 = (float ****)0x0;
    ppppfStack_60c = (float ****)0x48a3be;
    __vbaFreeVar();
    uVar10 = extraout_ECX_04;
    ppppfVar16 = ppppfStack_1b8;
    while (ppppfStack_1b8 = ppppfVar16, (short)ppppfStack_1b8 <= (short)uStack_360) {
      if (SBORROW2((short)ppppfStack_1c4,1)) goto LAB_0048c2d9;
      ppppfStack_610 = (float ****)(int)(short)((short)ppppfStack_1c4 + -1);
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_61c = (float ****)0xa;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48a417;
      ppppfStack_270 = ppppfStack_610;
      __vbaLateIdSt();
      ppppfStack_628 = (float ****)(int)(short)ppppfStack_1b8;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_634 = (float ****)0xb;
      ppppfStack_630 = (float ****)0x3;
      ppppfStack_62c = ppppfStack_274;
      ppppfStack_638 = ppppfStack_344;
      ppppfStack_624 = ppppfStack_26c;
      ppppfStack_63c = (float ****)0x48a453;
      ppppfStack_270 = ppppfStack_628;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_64c = (float ****)0x26;
      ppppfStack_648 = (float ****)0x3;
      ppppfStack_270 = (float ****)0xffff00;
      ppppfStack_644 = ppppfStack_274;
      ppppfStack_650 = ppppfStack_344;
      ppppfStack_640 = (float ****)0xffff00;
      ppppfStack_63c = ppppfStack_26c;
      ppppfStack_654 = (float ****)0x48a490;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_664 = (float ****)0x27;
      ppppfStack_660 = (float ****)0x3;
      ppppfStack_270 = (float ****)0xff0000;
      ppppfStack_65c = ppppfStack_274;
      ppppfStack_668 = ppppfStack_344;
      ppppfStack_658 = (float ****)0xff0000;
      ppppfStack_654 = ppppfStack_26c;
      ppppfStack_66c = (float ****)0x48a4cd;
      __vbaLateIdSt();
      bVar25 = SCARRY2((short)ppppfStack_1b8,1);
      uVar26 = (short)ppppfStack_1b8 + 1;
      uVar10 = extraout_ECX_05;
      ppppfVar16 = (float ****)(uint)uVar26;
      if (bVar25) goto LAB_0048c2d9;
    }
    if ((short)ppppfStack_1c0 == 1) {
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_61c = (float ****)0xa;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_270 = (float ****)0x0;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_610 = (float ****)0x0;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48a950;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_634 = (float ****)0xb;
      ppppfStack_630 = (float ****)0x3;
      ppppfStack_270 = (float ****)0x1;
      ppppfStack_62c = ppppfStack_274;
      ppppfStack_638 = ppppfStack_344;
      ppppfStack_628 = (float ****)&DAT_00000001;
      ppppfStack_624 = ppppfStack_26c;
      ppppfStack_63c = (float ****)0x48a98d;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_64c = (float ****)0x27;
      ppppfStack_648 = (float ****)0x3;
      ppppfStack_270 = (float ****)0xff0000;
      ppppfStack_644 = ppppfStack_274;
      ppppfStack_650 = ppppfStack_344;
      ppppfStack_640 = (float ****)0xff0000;
      ppppfStack_63c = ppppfStack_26c;
      ppppfStack_654 = (float ****)0x48a9ca;
      __vbaLateIdSt();
      if (DAT_0050b238 == 1) {
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_61c = (float ****)0xa;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x0;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_610 = (float ****)0x0;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48ad4b;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_634 = (float ****)0xb;
        ppppfStack_630 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x0;
        ppppfStack_62c = ppppfStack_274;
        ppppfStack_638 = ppppfStack_344;
        ppppfStack_628 = (float ****)0x0;
        ppppfStack_624 = ppppfStack_26c;
        ppppfStack_63c = (float ****)0x48ad85;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_64c = (float ****)0x26;
        ppppfStack_648 = (float ****)0x3;
        ppppfStack_270 = (float ****)0xffff;
        ppppfStack_644 = ppppfStack_274;
        ppppfStack_650 = ppppfStack_344;
        ppppfStack_640 = (float ****)0xffff;
        ppppfStack_63c = ppppfStack_26c;
        ppppfStack_654 = (float ****)0x48adc2;
        __vbaLateIdSt();
        ppppfStack_654 = (float ****)0x0;
        ppppfStack_658 = (float ****)0x5;
        ppppfStack_660 = &pppfStack_208;
        ppppfStack_65c = ppppfStack_344;
        ppppfStack_664 = (float ****)0x48add3;
        ppppfStack_654 = (float ****)__vbaLateIdCallLd();
        ppppfStack_658 = (float ****)0x48add9;
        iVar9 = __vbaI4Var();
        if (SBORROW4(iVar9,1)) break;
        ppppfStack_60c = (float ****)0x48adea;
        uStack_370 = __vbaI2I4();
        ppppfStack_1b8 = (float ****)0x1;
        ppppfStack_60c = (float ****)0x48ae00;
        __vbaFreeVar();
        ppppfVar16 = ppppfStack_1b8;
        while( true ) {
          ppppfStack_1b8 = ppppfVar16;
          if ((short)uStack_370 < (short)ppppfStack_1b8) break;
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_610 = (float ****)(int)(short)ppppfStack_1b8;
          ppppfStack_618 = (float ****)0x3;
          ppppfStack_61c = (float ****)0xb;
          ppppfStack_614 = ppppfStack_274;
          ppppfStack_620 = ppppfStack_344;
          ppppfStack_60c = ppppfStack_26c;
          ppppfStack_624 = (float ****)0x48ae4b;
          ppppfStack_270 = ppppfStack_610;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x2;
          ppppfStack_634 = (float ****)0x28;
          ppppfStack_630 = (float ****)0x2;
          ppppfStack_270 = (float ****)0x1;
          ppppfStack_62c = ppppfStack_274;
          ppppfStack_638 = ppppfStack_344;
          ppppfStack_628 = (float ****)&DAT_00000001;
          ppppfStack_624 = ppppfStack_26c;
          ppppfStack_63c = (float ****)0x48ae88;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_64c = (float ****)0x26;
          ppppfStack_648 = (float ****)0x3;
          ppppfStack_270 = (float ****)0xffff;
          ppppfStack_644 = ppppfStack_274;
          ppppfStack_650 = ppppfStack_344;
          ppppfStack_640 = (float ****)0xffff;
          ppppfStack_63c = ppppfStack_26c;
          ppppfStack_654 = (float ****)0x48aec5;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x3;
          uStack_298 = 3;
          ppppfStack_660 = (float ****)0x3;
          ppppfStack_270 = (float ****)0x0;
          ppppfStack_65c = ppppfStack_274;
          ppppfStack_2b8 = (float ****)0x8;
          ppppfStack_658 = (float ****)0x0;
          ppppfStack_2b0 = (float ****)0x4115c8;
          ppppfStack_654 = ppppfStack_26c;
          ppppfStack_670 = (float ****)0x3;
          ppppfStack_66c = ppppfStack_294;
          ppppfStack_668 = (float ****)(int)(short)ppppfStack_1b8;
          ppppfStack_664 = ppppfStack_28c;
          ppppfStack_680 = (float ****)0x8;
          ppppfStack_67c = ppppfStack_2b4;
          ppppfStack_678 = (float ****)0x4115c8;
          ppppfStack_684 = (float ****)0x2;
          ppppfStack_674 = ppppfStack_2ac;
          ppppfStack_688 = (float ****)0x41;
          ppppfStack_68c = ppppfStack_344;
          pppfStack_690 = (float ***)0x48af6d;
          __vbaLateIdCallSt();
          ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1b8 + 1);
          if (SCARRY2((short)ppppfStack_1b8,1)) goto LAB_0048c2d9;
        }
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_61c = (float ****)0x30;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x2;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_610 = (float ****)0x2;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48afc4;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_630 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x0;
        ppppfStack_62c = ppppfStack_274;
        ppppfStack_644 = (float ****)&DAT_00000001;
        ppppfStack_648 = (float ****)0x3b;
        ppppfStack_628 = (float ****)0x0;
        ppppfStack_624 = ppppfStack_26c;
        ppppfStack_640 = (float ****)0xb;
        ppppfStack_63c = ppppfStack_294;
        ppppfStack_638 = (float ****)0xffffffff;
        ppppfStack_634 = ppppfStack_28c;
        ppppfStack_64c = ppppfStack_344;
        ppppfStack_650 = (float ****)0x48b028;
        __vbaLateIdCallSt();
        ppppfStack_624 = (float ****)0x48b039;
        __vbaStrCopy();
      }
      else {
        uVar10 = extraout_ECX_07;
        if (DAT_0050b238 != 2) goto LAB_0048b047;
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_61c = (float ****)0xa;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x0;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_610 = (float ****)0x0;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48aa19;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_634 = (float ****)0xb;
        ppppfStack_630 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x0;
        ppppfStack_62c = ppppfStack_274;
        ppppfStack_638 = ppppfStack_344;
        ppppfStack_628 = (float ****)0x0;
        ppppfStack_624 = ppppfStack_26c;
        ppppfStack_63c = (float ****)0x48aa53;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_64c = (float ****)0x26;
        ppppfStack_648 = (float ****)0x3;
        ppppfStack_270 = (float ****)0xffff;
        ppppfStack_644 = ppppfStack_274;
        ppppfStack_650 = ppppfStack_344;
        ppppfStack_640 = (float ****)0xffff;
        ppppfStack_63c = ppppfStack_26c;
        ppppfStack_654 = (float ****)0x48aa90;
        __vbaLateIdSt();
        ppppfStack_654 = (float ****)0x0;
        ppppfStack_658 = (float ****)0x5;
        ppppfStack_660 = &pppfStack_208;
        ppppfStack_65c = ppppfStack_344;
        ppppfStack_664 = (float ****)0x48aaa1;
        ppppfStack_654 = (float ****)__vbaLateIdCallLd();
        ppppfStack_658 = (float ****)0x48aaa7;
        iVar9 = __vbaI4Var();
        if (SBORROW4(iVar9,1)) break;
        ppppfStack_60c = (float ****)0x48aab8;
        uStack_378 = __vbaI2I4();
        ppppfStack_1b8 = (float ****)0x1;
        ppppfStack_60c = (float ****)0x48aace;
        __vbaFreeVar();
        ppppfVar16 = ppppfStack_1b8;
        while( true ) {
          ppppfStack_1b8 = ppppfVar16;
          if ((short)uStack_378 < (short)ppppfStack_1b8) break;
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_610 = (float ****)(int)(short)ppppfStack_1b8;
          ppppfStack_618 = (float ****)0x3;
          ppppfStack_61c = (float ****)0xb;
          ppppfStack_614 = ppppfStack_274;
          ppppfStack_620 = ppppfStack_344;
          ppppfStack_60c = ppppfStack_26c;
          ppppfStack_624 = (float ****)0x48ab19;
          ppppfStack_270 = ppppfStack_610;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x2;
          ppppfStack_634 = (float ****)0x28;
          ppppfStack_630 = (float ****)0x2;
          ppppfStack_270 = (float ****)0x1;
          ppppfStack_62c = ppppfStack_274;
          ppppfStack_638 = ppppfStack_344;
          ppppfStack_628 = (float ****)&DAT_00000001;
          ppppfStack_624 = ppppfStack_26c;
          ppppfStack_63c = (float ****)0x48ab56;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_64c = (float ****)0x26;
          ppppfStack_648 = (float ****)0x3;
          ppppfStack_270 = (float ****)0xffff;
          ppppfStack_644 = ppppfStack_274;
          ppppfStack_650 = ppppfStack_344;
          ppppfStack_640 = (float ****)0xffff;
          ppppfStack_63c = ppppfStack_26c;
          ppppfStack_654 = (float ****)0x48ab93;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x3;
          uStack_298 = 3;
          ppppfStack_660 = (float ****)0x3;
          ppppfStack_270 = (float ****)0x0;
          ppppfStack_65c = ppppfStack_274;
          ppppfStack_2b8 = (float ****)0x8;
          ppppfStack_658 = (float ****)0x0;
          ppppfStack_2b0 = (float ****)0x411608;
          ppppfStack_654 = ppppfStack_26c;
          ppppfStack_670 = (float ****)0x3;
          ppppfStack_66c = ppppfStack_294;
          ppppfStack_668 = (float ****)(int)(short)ppppfStack_1b8;
          ppppfStack_664 = ppppfStack_28c;
          ppppfStack_680 = (float ****)0x8;
          ppppfStack_67c = ppppfStack_2b4;
          ppppfStack_678 = (float ****)0x411608;
          ppppfStack_684 = (float ****)0x2;
          ppppfStack_674 = ppppfStack_2ac;
          ppppfStack_688 = (float ****)0x41;
          ppppfStack_68c = ppppfStack_344;
          pppfStack_690 = (float ***)0x48ac3b;
          __vbaLateIdCallSt();
          ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1b8 + 1);
          if (SCARRY2((short)ppppfStack_1b8,1)) goto LAB_0048c2d9;
        }
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_61c = (float ****)0x30;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x2;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_610 = (float ****)0x2;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48ac92;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_630 = (float ****)0x3;
        ppppfStack_270 = (float ****)0x0;
        ppppfStack_62c = ppppfStack_274;
        ppppfStack_644 = (float ****)&DAT_00000001;
        ppppfStack_648 = (float ****)0x3b;
        ppppfStack_628 = (float ****)0x0;
        ppppfStack_624 = ppppfStack_26c;
        ppppfStack_640 = (float ****)0xb;
        ppppfStack_63c = ppppfStack_294;
        ppppfStack_638 = (float ****)0xffffffff;
        ppppfStack_634 = ppppfStack_28c;
        ppppfStack_64c = ppppfStack_344;
        ppppfStack_650 = (float ****)0x48acf6;
        __vbaLateIdCallSt();
        ppppfStack_624 = (float ****)0x48ad07;
        __vbaStrCopy();
      }
      ppppfStack_624 = (float ****)0x48b047;
      __vbaStrCopy();
      uVar10 = extraout_ECX_08;
    }
    else if ((short)ppppfStack_1c0 == 2) {
      ppppfStack_60c = (float ****)0x48a50c;
      __vbaStrCopy();
      ppppfStack_60c = (float ****)0x48a51a;
      __vbaStrCopy();
      ppppfStack_60c = (float ****)0x48a51f;
      FUN_0044fdc0();
      ppppfStack_60c = (float ****)0x48a52a;
      __vbaStrMove();
      ppppfStack_60c = (float ****)DAT_0050b34c;
      ppppfStack_610 = (float ****)0x411640;
      ppppfStack_614 = (float ****)0x48a53c;
      uVar10 = __vbaStrCat();
      uStack_220 = (double)CONCAT44(uStack_220._4_4_,uVar10);
      ppppfStack_200 = ppppfStack_1e4;
      pppfStack_228 = (float ***)0x8;
      pppfStack_208 = (float ***)0x8;
      ppppfStack_614 = (float ****)&DAT_00000001;
      ppppfStack_61c = &pppfStack_208;
      ppppfStack_618 = (float ****)&DAT_00000001;
      ppppfStack_620 = (float ****)&ppppfStack_278;
      ppppfStack_624 = (float ****)&ppppfStack_218;
      ppppfStack_1e4 = (float ****)0x0;
      ppppfStack_270 = (float ****)&DAT_0050b144;
      ppppfStack_278 = (float ****)0x4005;
      ppppfStack_628 = (float ****)0x48a587;
      Ordinal_660();
      ppppfStack_628 = &pppfStack_228;
      ppppfStack_62c = (float ****)&ppppfStack_218;
      ppppfStack_630 = &pppfStack_238;
      ppppfStack_634 = (float ****)0x48a59f;
      ppppfStack_634 = (float ****)__vbaVarCat();
      ppppfStack_638 = (float ****)0x48a5a6;
      __vbaStrVarMove();
      ppppfStack_638 = (float ****)0x48a5b3;
      __vbaStrMove();
      ppppfStack_638 = (float ****)0x48a5bc;
      __vbaFreeStr();
      ppppfStack_638 = &pppfStack_238;
      ppppfStack_63c = (float ****)&ppppfStack_218;
      ppppfStack_640 = &pppfStack_228;
      ppppfStack_644 = &pppfStack_208;
      ppppfStack_648 = (float ****)0x4;
      ppppfStack_64c = (float ****)0x48a5da;
      __vbaFreeVarList();
      ppppfStack_63c = (float ****)(int)(short)pppfStack_1bc;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_648 = (float ****)0xa;
      ppppfStack_644 = (float ****)0x3;
      ppppfStack_640 = ppppfStack_274;
      ppppfStack_64c = ppppfStack_344;
      ppppfStack_638 = ppppfStack_26c;
      ppppfStack_650 = (float ****)0x48a616;
      ppppfStack_270 = ppppfStack_63c;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_270 = (float ****)0x0;
      ppppfStack_65c = (float ****)0x3;
      ppppfStack_658 = ppppfStack_274;
      ppppfStack_654 = (float ****)0x0;
      ppppfStack_660 = (float ****)0xb;
      ppppfStack_664 = ppppfStack_344;
      ppppfStack_650 = ppppfStack_26c;
      ppppfStack_668 = (float ****)0x48a650;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_678 = (float ****)0x26;
      ppppfStack_674 = (float ****)0x3;
      ppppfStack_270 = (float ****)0xffff;
      ppppfStack_670 = ppppfStack_274;
      ppppfStack_67c = ppppfStack_344;
      ppppfStack_66c = (float ****)0xffff;
      ppppfStack_668 = ppppfStack_26c;
      ppppfStack_680 = (float ****)0x48a68d;
      __vbaLateIdSt();
      ppppfStack_680 = (float ****)0x0;
      ppppfStack_684 = (float ****)0x5;
      ppppfStack_68c = &pppfStack_208;
      ppppfStack_688 = ppppfStack_344;
      pppfStack_690 = (float ***)0x48a69e;
      ppppfStack_680 = (float ****)__vbaLateIdCallLd();
      ppppfStack_684 = (float ****)0x48a6a4;
      iVar9 = __vbaI4Var();
      if (SBORROW4(iVar9,1)) break;
      ppppfStack_60c = (float ****)0x48a6b5;
      uStack_380 = __vbaI2I4();
      ppppfStack_1b8 = (float ****)0x1;
      ppppfStack_60c = (float ****)0x48a6cb;
      __vbaFreeVar();
      ppppfVar16 = ppppfStack_1b8;
      while( true ) {
        ppppfStack_1b8 = ppppfVar16;
        if ((short)uStack_380 < (short)ppppfStack_1b8) break;
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_610 = (float ****)(int)(short)ppppfStack_1b8;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_61c = (float ****)0xb;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48a716;
        ppppfStack_270 = ppppfStack_610;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x2;
        ppppfStack_634 = (float ****)0x28;
        ppppfStack_630 = (float ****)0x2;
        ppppfStack_270 = (float ****)0x1;
        ppppfStack_62c = ppppfStack_274;
        ppppfStack_638 = ppppfStack_344;
        ppppfStack_628 = (float ****)&DAT_00000001;
        ppppfStack_624 = ppppfStack_26c;
        ppppfStack_63c = (float ****)0x48a753;
        __vbaLateIdSt();
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_64c = (float ****)0x26;
        ppppfStack_648 = (float ****)0x3;
        ppppfStack_270 = (float ****)0xffff;
        ppppfStack_644 = ppppfStack_274;
        ppppfStack_650 = ppppfStack_344;
        ppppfStack_640 = (float ****)0xffff;
        ppppfStack_63c = ppppfStack_26c;
        ppppfStack_654 = (float ****)0x48a790;
        __vbaLateIdSt();
        ppppfStack_658 = (float ****)(int)(short)pppfStack_1bc;
        ppppfStack_278 = (float ****)0x3;
        uStack_298 = 3;
        ppppfStack_660 = (float ****)0x3;
        ppppfStack_2b8 = (float ****)0x4008;
        ppppfStack_65c = ppppfStack_274;
        ppppfStack_2b0 = (float ****)&DAT_0050b348;
        ppppfStack_654 = ppppfStack_26c;
        ppppfStack_670 = (float ****)0x3;
        ppppfStack_66c = ppppfStack_294;
        ppppfStack_668 = (float ****)(int)(short)ppppfStack_1b8;
        ppppfStack_664 = ppppfStack_28c;
        ppppfStack_680 = (float ****)0x4008;
        ppppfStack_67c = ppppfStack_2b4;
        ppppfStack_678 = (float ****)&DAT_0050b348;
        ppppfStack_684 = (float ****)0x2;
        ppppfStack_674 = ppppfStack_2ac;
        ppppfStack_688 = (float ****)0x41;
        ppppfStack_68c = ppppfStack_344;
        pppfStack_690 = (float ***)0x48a83a;
        ppppfStack_270 = ppppfStack_658;
        __vbaLateIdCallSt();
        ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1b8 + 1);
        if (SCARRY2((short)ppppfStack_1b8,1)) goto LAB_0048c2d9;
      }
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_61c = (float ****)0x30;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_270 = (float ****)0x2;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_610 = (float ****)0x2;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48a891;
      __vbaLateIdSt();
      ppppfStack_628 = (float ****)(int)(short)pppfStack_1bc;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_630 = (float ****)0x3;
      ppppfStack_62c = ppppfStack_274;
      ppppfStack_644 = (float ****)&DAT_00000001;
      ppppfStack_648 = (float ****)0x3b;
      ppppfStack_624 = ppppfStack_26c;
      ppppfStack_640 = (float ****)0xb;
      ppppfStack_63c = ppppfStack_294;
      ppppfStack_638 = (float ****)0xffffffff;
      ppppfStack_634 = ppppfStack_28c;
      ppppfStack_64c = ppppfStack_344;
      ppppfStack_650 = (float ****)0x48a8f7;
      ppppfStack_270 = ppppfStack_628;
      __vbaLateIdCallSt();
      uVar10 = extraout_ECX_06;
      if (_DAT_0050b144 == _DAT_00401490) goto code_r0x0048c229;
    }
    else if ((short)ppppfStack_1c0 == 3) {
      ppppfStack_610 = (float ****)(int)(short)pppfStack_1bc;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_61c = (float ****)0xa;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48ba7d;
      ppppfStack_270 = ppppfStack_610;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_634 = (float ****)0xb;
      ppppfStack_630 = (float ****)0x3;
      ppppfStack_270 = (float ****)0x0;
      ppppfStack_62c = ppppfStack_274;
      ppppfStack_638 = ppppfStack_344;
      ppppfStack_628 = (float ****)0x0;
      ppppfStack_624 = ppppfStack_26c;
      ppppfStack_63c = (float ****)0x48bab7;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_64c = (float ****)0x27;
      ppppfStack_648 = (float ****)0x3;
      ppppfStack_270 = (float ****)0xff0000;
      ppppfStack_644 = ppppfStack_274;
      ppppfStack_650 = ppppfStack_344;
      ppppfStack_640 = (float ****)0xff0000;
      ppppfStack_63c = ppppfStack_26c;
      ppppfStack_654 = (float ****)0x48baf4;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_664 = (float ****)0x26;
      ppppfStack_660 = (float ****)0x3;
      ppppfStack_270 = (float ****)0xffff;
      ppppfStack_65c = ppppfStack_274;
      ppppfStack_668 = ppppfStack_344;
      ppppfStack_658 = (float ****)0xffff;
      ppppfStack_654 = ppppfStack_26c;
      ppppfStack_66c = (float ****)0x48bb31;
      __vbaLateIdSt();
      ppppfStack_66c = (float ****)0x0;
      ppppfStack_670 = (float ****)0x5;
      ppppfStack_678 = &pppfStack_208;
      ppppfStack_674 = ppppfStack_344;
      ppppfStack_67c = (float ****)0x48bb42;
      ppppfStack_66c = (float ****)__vbaLateIdCallLd();
      ppppfStack_670 = (float ****)0x48bb48;
      iVar9 = __vbaI4Var();
      if (!SBORROW4(iVar9,1)) {
        ppppfStack_60c = (float ****)0x48bb59;
        uStack_388 = __vbaI2I4();
        ppppfStack_1b8 = (float ****)0x1;
        ppppfStack_60c = (float ****)0x48bb6f;
        __vbaFreeVar();
        ppppfVar16 = ppppfStack_1b8;
        goto LAB_0048bb72;
      }
      break;
    }
LAB_0048b047:
    ppppfVar16 = (float ****)0x0;
    while( true ) {
      sVar19 = (short)ppppfVar16;
      ppppfStack_1b8 = ppppfVar16;
      if ((short)ppppfStack_1cc < sVar19) break;
      ppppfStack_278 = (float ****)0x3;
      if (SCARRY2((short)ppppfStack_1c4,sVar19)) goto LAB_0048c2d9;
      ppppfStack_610 = (float ****)(int)(short)((short)ppppfStack_1c4 + sVar19);
      ppppfStack_61c = (float ****)0xa;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48b09e;
      ppppfStack_270 = ppppfStack_610;
      __vbaLateIdSt();
      ppppfStack_278 = (float ****)0x3;
      if (SCARRY2((short)ppppfStack_1c4,(short)ppppfStack_1b8)) goto LAB_0048c2d9;
      ppppfStack_610 = (float ****)(int)(short)((short)ppppfStack_1c4 + (short)ppppfStack_1b8);
      ppppfStack_61c = (float ****)0xc;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48b0e7;
      ppppfStack_270 = ppppfStack_610;
      __vbaLateIdSt();
      ppppfStack_624 = (float ****)0x0;
      ppppfStack_628 = (float ****)0x5;
      ppppfStack_630 = &pppfStack_208;
      ppppfStack_62c = ppppfStack_344;
      ppppfStack_634 = (float ****)0x48b0f8;
      ppppfStack_624 = (float ****)__vbaLateIdCallLd();
      ppppfStack_628 = (float ****)0x48b0fe;
      iVar9 = __vbaI4Var();
      if (SBORROW4(iVar9,1)) goto LAB_0048c2d9;
      ppppfStack_60c = (float ****)0x48b10f;
      uStack_3a0 = __vbaI2I4();
      pppfStack_1bc = (float ***)0x0;
      ppppfStack_60c = (float ****)0x48b125;
      __vbaFreeVar();
      uVar10 = extraout_ECX_09;
      ppppfVar16 = (float ****)pppfStack_1bc;
      while( true ) {
        pppfStack_1bc = (float ***)ppppfVar16;
        if ((short)uStack_3a0 < (short)pppfStack_1bc) break;
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_610 = (float ****)(int)(short)pppfStack_1bc;
        ppppfStack_618 = (float ****)0x3;
        ppppfStack_61c = (float ****)0xb;
        ppppfStack_614 = ppppfStack_274;
        ppppfStack_620 = ppppfStack_344;
        ppppfStack_60c = ppppfStack_26c;
        ppppfStack_624 = (float ****)0x48b170;
        ppppfStack_270 = ppppfStack_610;
        __vbaLateIdSt();
        ppppfStack_628 = (float ****)(int)(short)pppfStack_1bc;
        ppppfStack_278 = (float ****)0x3;
        ppppfStack_634 = (float ****)0xd;
        ppppfStack_630 = (float ****)0x3;
        ppppfStack_62c = ppppfStack_274;
        ppppfStack_638 = ppppfStack_344;
        ppppfStack_624 = ppppfStack_26c;
        ppppfStack_63c = (float ****)0x48b1ac;
        ppppfStack_270 = ppppfStack_628;
        __vbaLateIdSt();
        uVar10 = extraout_ECX_10;
        if ((0 < (short)ppppfStack_1b8) && (0 < (short)pppfStack_1bc)) {
          if ((short)ppppfStack_1c0 == 1) {
            if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
              ppppfStack_60c = (float ****)0x48b316;
              iVar9 = __vbaGenerateBoundsError();
              psVar20 = DAT_0050b0cc;
            }
            else {
              uStack_31c = (int)(short)ppppfStack_1b8 - *(int *)(DAT_0050b0cc + 0xe);
              if (*(uint *)(DAT_0050b0cc + 0xc) <= uStack_31c) {
                ppppfStack_60c = (float ****)0x48b2cf;
                __vbaGenerateBoundsError();
              }
              ppppfStack_318 = (float ****)((int)(short)pppfStack_1bc - *(int *)(DAT_0050b0cc + 10))
              ;
              if (*(float ******)(DAT_0050b0cc + 8) <= ppppfStack_318) {
                ppppfStack_60c = (float ****)0x48b2f3;
                __vbaGenerateBoundsError();
              }
              iVar9 = (*(int *)(DAT_0050b0cc + 0xc) * (int)ppppfStack_318 + uStack_31c) * 8;
              psVar20 = DAT_0050b0cc;
            }
LAB_0048b31c:
            DAT_0050b13c = *(undefined4 *)(*(int *)(psVar20 + 6) + iVar9);
            DAT_0050b140 = *(undefined4 *)(*(int *)(psVar20 + 6) + 4 + iVar9);
          }
          else if ((short)ppppfStack_1c0 == 2) {
            if ((short)ppppfStack_1d0 == 3) {
              ppppfStack_60c = (float ****)0x0;
              ppppfStack_610 = (float ****)0x5;
              ppppfStack_618 = &pppfStack_208;
              ppppfStack_614 = ppppfStack_344;
              ppppfStack_61c = (float ****)0x48b1ed;
              ppppfStack_60c = (float ****)__vbaLateIdCallLd();
              ppppfStack_610 = (float ****)0x48b1f3;
              iVar9 = __vbaI4Var();
              if (SBORROW4(iVar9,1)) goto LAB_0048c2d9;
              ppppfStack_318 = (float ****)-(uint)((int)(short)pppfStack_1bc == iVar9 + -1);
              ppppfStack_60c = (float ****)0x48b218;
              __vbaFreeVar();
              uVar10 = extraout_ECX_11;
              if ((short)ppppfStack_318 != 0) break;
            }
            if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
              ppppfStack_60c = (float ****)0x48b29c;
              iVar9 = __vbaGenerateBoundsError();
              psVar20 = DAT_0050b0c4;
            }
            else {
              uStack_31c = (int)(short)ppppfStack_1b8 - *(int *)(DAT_0050b0c4 + 0xe);
              if (*(uint *)(DAT_0050b0c4 + 0xc) <= uStack_31c) {
                ppppfStack_60c = (float ****)0x48b252;
                __vbaGenerateBoundsError();
              }
              ppppfStack_318 = (float ****)((int)(short)pppfStack_1bc - *(int *)(DAT_0050b0c4 + 10))
              ;
              if (*(float ******)(DAT_0050b0c4 + 8) <= ppppfStack_318) {
                ppppfStack_60c = (float ****)0x48b276;
                __vbaGenerateBoundsError();
              }
              iVar9 = (*(int *)(DAT_0050b0c4 + 0xc) * (int)ppppfStack_318 + uStack_31c) * 8;
              psVar20 = DAT_0050b0c4;
            }
            goto LAB_0048b31c;
          }
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_61c = (float ****)0x27;
          ppppfStack_618 = (float ****)0x3;
          ppppfStack_270 = (float ****)0xffffff;
          ppppfStack_614 = ppppfStack_274;
          ppppfStack_620 = ppppfStack_344;
          ppppfStack_610 = (float ****)0xffffff;
          ppppfStack_60c = ppppfStack_26c;
          ppppfStack_624 = (float ****)0x48b36e;
          __vbaLateIdSt();
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_634 = (float ****)0x26;
          ppppfStack_630 = (float ****)0x3;
          ppppfStack_270 = (float ****)0xff0000;
          ppppfStack_62c = ppppfStack_274;
          ppppfStack_638 = ppppfStack_344;
          ppppfStack_628 = (float ****)0xff0000;
          ppppfStack_624 = ppppfStack_26c;
          ppppfStack_63c = (float ****)0x48b3ab;
          __vbaLateIdSt();
          ppppfStack_63c = (float ****)0x48b3b0;
          FUN_0044fdc0();
          ppppfStack_63c = (float ****)0x48b3bb;
          __vbaStrMove();
          ppppfStack_63c = (float ****)0x0;
          ppppfStack_640 = (float ****)0xa;
          ppppfStack_648 = &pppfStack_228;
          ppppfStack_644 = ppppfStack_344;
          ppppfStack_64c = (float ****)0x48b3cf;
          ppppfStack_63c = (float ****)__vbaLateIdCallLd();
          ppppfStack_640 = (float ****)0x48b3d5;
          ppppfStack_280 = (float ****)__vbaI4Var();
          ppppfStack_640 = (float ****)0x0;
          ppppfStack_644 = (float ****)0xb;
          ppppfStack_64c = &pppfStack_238;
          ppppfStack_648 = ppppfStack_344;
          pppfStack_288 = (float ***)0x3;
          ppppfStack_650 = (float ****)0x48b3f9;
          ppppfStack_640 = (float ****)__vbaLateIdCallLd();
          ppppfStack_644 = (float ****)0x48b3ff;
          uStack_2a0 = __vbaI4Var();
          ppppfStack_200 = ppppfStack_1e4;
          ppppfStack_644 = (float ****)&DAT_00000001;
          ppppfStack_64c = &pppfStack_208;
          ppppfStack_648 = (float ****)&DAT_00000001;
          ppppfStack_650 = (float ****)&ppppfStack_278;
          ppppfStack_654 = (float ****)&ppppfStack_218;
          ppppfStack_1e4 = (float ****)0x0;
          pppfStack_208 = (float ***)0x8;
          ppppfStack_270 = (float ****)&DAT_0050b13c;
          ppppfStack_278 = (float ****)0x4005;
          ppppfStack_658 = (float ****)0x48b446;
          Ordinal_660();
          ppppfStack_658 = (float ****)&ppppfStack_218;
          ppppfStack_65c = (float ****)0x48b450;
          ppppfStack_680 = (float ****)__vbaStrVarMove();
          ppppfStack_248 = (float ****)0x8;
          ppppfStack_668 = (float ****)pppfStack_288;
          ppppfStack_664 = (float ****)uStack_284;
          ppppfStack_660 = ppppfStack_280;
          ppppfStack_65c = (float ****)pppfStack_27c;
          ppppfStack_678 = (float ****)0x3;
          ppppfStack_674 = ppppfStack_2a4;
          ppppfStack_670 = (float ****)uStack_2a0;
          ppppfStack_66c = (float ****)uStack_29c;
          ppppfStack_68c = (float ****)0x2;
          pppfStack_690 = (float ***)0x41;
          ppppfStack_688 = (float ****)0x8;
          ppppfStack_684 = ppppfStack_244;
          ppppfStack_694 = ppppfStack_344;
          ppppfStack_67c = ppppfStack_23c;
          ppppfStack_698 = (float ****)0x48b4e2;
          ppppfStack_240 = ppppfStack_680;
          __vbaLateIdCallSt();
          ppppfStack_65c = (float ****)0x48b4ee;
          __vbaFreeStr();
          ppppfStack_65c = (float ****)&ppppfStack_248;
          ppppfStack_660 = (float ****)&ppppfStack_218;
          ppppfStack_664 = &pppfStack_238;
          ppppfStack_668 = &pppfStack_228;
          ppppfStack_66c = &pppfStack_208;
          ppppfStack_670 = (float ****)0x5;
          ppppfStack_674 = (float ****)0x48b513;
          __vbaFreeVarList();
          uVar10 = extraout_ECX_12;
        }
        if ((short)ppppfStack_1b8 == 0) {
          if (0 < (short)pppfStack_1bc) {
            if ((DAT_0050b238 == 2) && ((short)ppppfStack_1c0 == 2)) {
              ppppfStack_60c = (float ****)0x0;
              ppppfStack_610 = (float ****)0x5;
              ppppfStack_618 = &pppfStack_208;
              ppppfStack_614 = ppppfStack_344;
              ppppfStack_61c = (float ****)0x48b551;
              ppppfStack_60c = (float ****)__vbaLateIdCallLd();
              ppppfStack_610 = (float ****)0x48b557;
              iVar9 = __vbaI4Var();
              if (SBORROW4(iVar9,1)) goto LAB_0048c2d9;
              ppppfStack_318 = (float ****)-(uint)((int)(short)pppfStack_1bc == iVar9 + -1);
              ppppfStack_60c = (float ****)0x48b57c;
              __vbaFreeVar();
              uVar10 = extraout_ECX_13;
              if ((short)ppppfStack_318 != 0) break;
            }
            ppppfStack_278 = (float ****)0x2;
            ppppfStack_61c = (float ****)0x28;
            ppppfStack_618 = (float ****)0x2;
            ppppfStack_270 = (float ****)0x4;
            ppppfStack_614 = ppppfStack_274;
            ppppfStack_620 = ppppfStack_344;
            ppppfStack_610 = (float ****)0x4;
            ppppfStack_60c = ppppfStack_26c;
            ppppfStack_624 = (float ****)0x48b5c7;
            __vbaLateIdSt();
            ppppfStack_278 = (float ****)0x3;
            ppppfStack_634 = (float ****)0x27;
            ppppfStack_630 = (float ****)0x3;
            ppppfStack_270 = (float ****)0xff0000;
            ppppfStack_62c = ppppfStack_274;
            ppppfStack_638 = ppppfStack_344;
            ppppfStack_628 = (float ****)0xff0000;
            ppppfStack_624 = ppppfStack_26c;
            ppppfStack_63c = (float ****)0x48b604;
            __vbaLateIdSt();
            ppppfStack_63c = (float ****)0x0;
            ppppfStack_640 = (float ****)0xa;
            ppppfStack_648 = &pppfStack_228;
            ppppfStack_644 = ppppfStack_344;
            ppppfStack_64c = (float ****)0x48b618;
            ppppfStack_63c = (float ****)__vbaLateIdCallLd();
            ppppfStack_640 = (float ****)0x48b61e;
            ppppfStack_290 = (float ****)__vbaI4Var();
            ppppfStack_640 = (float ****)0x0;
            ppppfStack_644 = (float ****)0xb;
            ppppfStack_64c = &pppfStack_238;
            ppppfStack_648 = ppppfStack_344;
            ppppfStack_650 = (float ****)0x48b638;
            ppppfStack_640 = (float ****)__vbaLateIdCallLd();
            ppppfStack_644 = (float ****)0x48b63e;
            ppppfStack_2b0 = (float ****)__vbaI4Var();
            ppppfStack_280 = ppppfStack_1d8;
            ppppfStack_644 = (float ****)&ppppfStack_278;
            ppppfStack_648 = &pppfStack_208;
            ppppfStack_270 = &pppfStack_1bc;
            ppppfStack_2b8 = (float ****)0x3;
            pppfStack_288 = (float ***)0x8;
            ppppfStack_278 = (float ****)0x4002;
            ppppfStack_64c = (float ****)0x48b685;
            Ordinal_613();
            ppppfStack_64c = &pppfStack_288;
            ppppfStack_650 = &pppfStack_208;
            ppppfStack_654 = (float ****)&ppppfStack_218;
            ppppfStack_658 = (float ****)0x48b69a;
            ppppfStack_658 = (float ****)__vbaVarAdd();
            ppppfStack_65c = (float ****)0x48b6a1;
            ppppfStack_680 = (float ****)__vbaStrVarMove();
            ppppfStack_248 = (float ****)0x8;
            ppppfStack_668 = (float ****)0x3;
            ppppfStack_664 = ppppfStack_294;
            ppppfStack_660 = ppppfStack_290;
            ppppfStack_65c = ppppfStack_28c;
            ppppfStack_678 = ppppfStack_2b8;
            ppppfStack_674 = ppppfStack_2b4;
            ppppfStack_670 = ppppfStack_2b0;
            ppppfStack_66c = ppppfStack_2ac;
            ppppfStack_68c = (float ****)0x2;
            pppfStack_690 = (float ***)0x41;
            ppppfStack_688 = (float ****)0x8;
            ppppfStack_684 = ppppfStack_244;
            ppppfStack_694 = ppppfStack_344;
            ppppfStack_67c = ppppfStack_23c;
            ppppfStack_698 = (float ****)0x48b733;
            ppppfStack_240 = ppppfStack_680;
            __vbaLateIdCallSt();
            ppppfStack_698 = (float ****)&ppppfStack_248;
            ppppfStack_69c = (float ****)&ppppfStack_218;
            pppfStack_6a0 = (float ***)&pppfStack_238;
            ppppfStack_6a4 = &pppfStack_228;
            pppfStack_6a8 = (float ***)&pppfStack_208;
            ppppfStack_6ac = (float ****)0x5;
            ppppfStack_6b0 = (float ****)0x48b758;
            __vbaFreeVarList();
            uVar10 = extraout_ECX_14;
            goto LAB_0048b75b;
          }
        }
        else {
LAB_0048b75b:
        }
        if (((short)pppfStack_1bc == 0) && (0 < (short)ppppfStack_1b8)) {
          ppppfStack_278 = (float ****)0x3;
          ppppfStack_61c = (float ****)0x27;
          ppppfStack_618 = (float ****)0x3;
          ppppfStack_270 = (float ****)0xff0000;
          ppppfStack_614 = ppppfStack_274;
          ppppfStack_620 = ppppfStack_344;
          ppppfStack_610 = (float ****)0xff0000;
          ppppfStack_60c = ppppfStack_26c;
          ppppfStack_624 = (float ****)0x48b7ae;
          __vbaLateIdSt();
          ppppfStack_624 = (float ****)0x0;
          ppppfStack_628 = (float ****)0xa;
          ppppfStack_630 = &pppfStack_228;
          ppppfStack_62c = ppppfStack_344;
          ppppfStack_634 = (float ****)0x48b7c2;
          ppppfStack_624 = (float ****)__vbaLateIdCallLd();
          ppppfStack_628 = (float ****)0x48b7c8;
          ppppfStack_290 = (float ****)__vbaI4Var();
          ppppfStack_628 = (float ****)0x0;
          ppppfStack_62c = (float ****)0xb;
          ppppfStack_634 = &pppfStack_238;
          ppppfStack_630 = ppppfStack_344;
          ppppfStack_638 = (float ****)0x48b7e2;
          ppppfStack_628 = (float ****)__vbaLateIdCallLd();
          ppppfStack_62c = (float ****)0x48b7e8;
          ppppfStack_2b0 = (float ****)__vbaI4Var();
          ppppfStack_280 = ppppfStack_1dc;
          ppppfStack_62c = (float ****)&ppppfStack_278;
          ppppfStack_630 = &pppfStack_208;
          ppppfStack_270 = (float ****)&ppppfStack_1b8;
          ppppfStack_2b8 = (float ****)0x3;
          pppfStack_288 = (float ***)0x8;
          ppppfStack_278 = (float ****)0x4002;
          ppppfStack_634 = (float ****)0x48b82f;
          Ordinal_613();
          ppppfStack_634 = &pppfStack_288;
          ppppfStack_638 = &pppfStack_208;
          ppppfStack_63c = (float ****)&ppppfStack_218;
          ppppfStack_640 = (float ****)0x48b844;
          ppppfStack_640 = (float ****)__vbaVarAdd();
          ppppfStack_644 = (float ****)0x48b84b;
          ppppfStack_668 = (float ****)__vbaStrVarMove();
          ppppfStack_248 = (float ****)0x8;
          ppppfStack_650 = (float ****)0x3;
          ppppfStack_64c = ppppfStack_294;
          ppppfStack_648 = ppppfStack_290;
          ppppfStack_644 = ppppfStack_28c;
          ppppfStack_660 = ppppfStack_2b8;
          ppppfStack_65c = ppppfStack_2b4;
          ppppfStack_658 = ppppfStack_2b0;
          ppppfStack_654 = ppppfStack_2ac;
          ppppfStack_674 = (float ****)0x2;
          ppppfStack_678 = (float ****)0x41;
          ppppfStack_670 = (float ****)0x8;
          ppppfStack_66c = ppppfStack_244;
          ppppfStack_67c = ppppfStack_344;
          ppppfStack_664 = ppppfStack_23c;
          ppppfStack_680 = (float ****)0x48b8dd;
          ppppfStack_240 = ppppfStack_668;
          __vbaLateIdCallSt();
          ppppfStack_680 = (float ****)&ppppfStack_248;
          ppppfStack_684 = (float ****)&ppppfStack_218;
          ppppfStack_688 = &pppfStack_238;
          ppppfStack_68c = &pppfStack_228;
          pppfStack_690 = (float ***)&pppfStack_208;
          ppppfStack_694 = (float ****)0x5;
          ppppfStack_698 = (float ****)0x48b902;
          __vbaFreeVarList();
          uVar10 = extraout_ECX_15;
        }
        ppppfVar16 = (float ****)(uint)(ushort)((short)pppfStack_1bc + 1);
        if (SCARRY2((short)pppfStack_1bc,1)) goto LAB_0048c2d9;
      }
      ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1b8 + 1);
      if (SCARRY2((short)ppppfStack_1b8,1)) goto LAB_0048c2d9;
    }
    if ((DAT_0050b238 == 2) && ((short)ppppfStack_1c0 == 1)) {
      ppppfStack_270 = (float ****)(int)(short)ppppfStack_1c4;
      ppppfStack_60c = (float ****)0x0;
      ppppfStack_610 = (float ****)0x5;
      ppppfStack_618 = &pppfStack_208;
      ppppfStack_614 = ppppfStack_344;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_61c = (float ****)0x48b970;
      ppppfStack_60c = (float ****)__vbaLateIdCallLd();
      ppppfStack_610 = (float ****)0x48b976;
      iVar9 = __vbaI4Var();
      if (SBORROW4(iVar9,1)) break;
      ppppfStack_2b8 = (float ****)0x8;
      ppppfStack_2b0 = (float ****)0x41168c;
      ppppfStack_618 = ppppfStack_278;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_610 = ppppfStack_270;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_628 = (float ****)0x3;
      ppppfStack_624 = ppppfStack_294;
      ppppfStack_63c = (float ****)0x2;
      ppppfStack_640 = (float ****)0x41;
      ppppfStack_61c = ppppfStack_28c;
      ppppfStack_638 = (float ****)0x8;
      ppppfStack_634 = ppppfStack_2b4;
      ppppfStack_630 = (float ****)0x41168c;
      ppppfStack_62c = ppppfStack_2ac;
      ppppfStack_644 = ppppfStack_344;
      ppppfStack_648 = (float ****)0x48ba15;
      ppppfStack_620 = (float ****)(iVar9 + -1);
      __vbaLateIdCallSt();
      ppppfStack_60c = (float ****)0x48ba21;
      __vbaFreeVar();
      uVar10 = extraout_ECX_16;
    }
    DAT_0050b21e = 1;
    ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1c0 + 1);
  } while (!SCARRY2((short)ppppfStack_1c0,1));
  goto LAB_0048c2d9;
  while( true ) {
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_610 = (float ****)(int)(short)ppppfStack_1b8;
    ppppfStack_618 = (float ****)0x3;
    ppppfStack_61c = (float ****)0xb;
    ppppfStack_614 = ppppfStack_274;
    ppppfStack_620 = ppppfStack_344;
    ppppfStack_60c = ppppfStack_26c;
    ppppfStack_624 = (float ****)0x48bbba;
    ppppfStack_270 = ppppfStack_610;
    __vbaLateIdSt();
    ppppfStack_278 = (float ****)0x2;
    ppppfStack_634 = (float ****)0x28;
    ppppfStack_630 = (float ****)0x2;
    ppppfStack_270 = (float ****)0x1;
    ppppfStack_62c = ppppfStack_274;
    ppppfStack_638 = ppppfStack_344;
    ppppfStack_628 = (float ****)&DAT_00000001;
    ppppfStack_624 = ppppfStack_26c;
    ppppfStack_63c = (float ****)0x48bbf7;
    __vbaLateIdSt();
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_64c = (float ****)0x26;
    ppppfStack_648 = (float ****)0x3;
    ppppfStack_270 = (float ****)0xffff;
    ppppfStack_644 = ppppfStack_274;
    ppppfStack_650 = ppppfStack_344;
    ppppfStack_640 = (float ****)0xffff;
    ppppfStack_63c = ppppfStack_26c;
    ppppfStack_654 = (float ****)0x48bc34;
    __vbaLateIdSt();
    ppppfStack_658 = (float ****)(int)(short)pppfStack_1bc;
    pppppfVar14 = &ppppfStack_660;
    ppppfStack_278 = (float ****)0x3;
    ppppfVar24 = (float ****)0x3;
    ppppfStack_660 = (float ****)0x3;
    ppppfStack_668 = (float ****)(int)(short)ppppfStack_1b8;
    ppppfStack_65c = ppppfStack_274;
    ppppfStack_2b8 = (float ****)0x8;
    ppppfStack_2b0 = (float ****)0x411668;
    ppppfStack_654 = ppppfStack_26c;
    ppppfStack_670 = (float ****)0x3;
    ppppfStack_66c = ppppfStack_294;
    ppppfStack_664 = ppppfStack_28c;
    ppppfStack_680 = (float ****)0x8;
    ppppfStack_67c = ppppfStack_2b4;
    ppppfStack_678 = (float ****)0x411668;
    ppppfStack_674 = ppppfStack_2ac;
    ppppfStack_684 = (float ****)0x2;
    ppppfStack_688 = (float ****)0x41;
    ppppfStack_68c = ppppfStack_344;
    pppfStack_690 = (float ***)0x48bcd4;
    ppppfStack_270 = ppppfStack_658;
    __vbaLateIdCallSt();
    ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1b8 + 1);
    if (SCARRY2((short)ppppfStack_1b8,1)) break;
LAB_0048bb72:
    ppppfStack_1b8 = ppppfVar16;
    if ((short)uStack_388 < (short)ppppfStack_1b8) {
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_61c = (float ****)0x30;
      ppppfStack_618 = (float ****)0x3;
      ppppfStack_270 = (float ****)0x2;
      ppppfStack_614 = ppppfStack_274;
      ppppfStack_620 = ppppfStack_344;
      ppppfStack_610 = (float ****)0x2;
      ppppfStack_60c = ppppfStack_26c;
      ppppfStack_624 = (float ****)0x48bd2b;
      __vbaLateIdSt();
      ppppfStack_628 = (float ****)(int)(short)pppfStack_1bc;
      pppppfVar14 = &ppppfStack_630;
      ppppfStack_278 = (float ****)0x3;
      ppppfStack_630 = (float ****)0x3;
      ppppfStack_62c = ppppfStack_274;
      ppppfStack_644 = (float ****)&DAT_00000001;
      ppppfStack_648 = (float ****)0x3b;
      ppppfStack_624 = ppppfStack_26c;
      ppppfStack_640 = (float ****)0xb;
      ppppfStack_63c = ppppfStack_294;
      ppppfStack_64c = ppppfStack_344;
      ppppfStack_638 = (float ****)0xffffffff;
      ppppfStack_634 = ppppfStack_28c;
      ppppfStack_650 = (float ****)0x48bd91;
      ppppfStack_270 = ppppfStack_628;
      uVar10 = __vbaLateIdCallSt();
      ppppfVar24 = (float ****)__vbaStrMove_exref;
      sStack_390 = DAT_0050b20a;
      ppppfStack_1b8 = (float ****)0x1;
      ppppfVar16 = ppppfStack_1b8;
      goto LAB_0048bdb0;
    }
  }
  goto LAB_0048c2d9;
  while( true ) {
    sVar8 = (short)ppppfStack_1c4 + -1 + sVar19;
    if (SCARRY2((short)ppppfStack_1c4 + -1,sVar19)) break;
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_610 = (float ****)(int)sVar8;
    ppppfStack_618 = (float ****)0x3;
    ppppfStack_61c = (float ****)0xa;
    ppppfStack_614 = ppppfStack_274;
    ppppfStack_620 = ppppfStack_344;
    ppppfStack_60c = ppppfStack_26c;
    ppppfStack_624 = (float ****)0x48be12;
    ppppfStack_270 = ppppfStack_610;
    pppfStack_1bc = (float ***)CONCAT22((short)((uint)uVar10 >> 0x10),sVar8);
    __vbaLateIdSt();
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_634 = (float ****)0xb;
    ppppfStack_630 = (float ****)0x3;
    ppppfStack_270 = (float ****)0x0;
    ppppfStack_62c = ppppfStack_274;
    ppppfStack_638 = ppppfStack_344;
    ppppfStack_628 = (float ****)0x0;
    ppppfStack_624 = ppppfStack_26c;
    ppppfStack_63c = (float ****)0x48be4c;
    __vbaLateIdSt();
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_64c = (float ****)0x27;
    ppppfStack_648 = (float ****)0x3;
    ppppfStack_270 = (float ****)0xff0000;
    ppppfStack_644 = ppppfStack_274;
    ppppfStack_650 = ppppfStack_344;
    ppppfStack_640 = (float ****)0xff0000;
    ppppfStack_63c = ppppfStack_26c;
    ppppfStack_654 = (float ****)0x48be89;
    __vbaLateIdSt();
    ppppfStack_278 = (float ****)0x2;
    ppppfStack_664 = (float ****)0x28;
    ppppfStack_660 = (float ****)0x2;
    ppppfStack_270 = (float ****)0x4;
    ppppfStack_65c = ppppfStack_274;
    ppppfStack_668 = ppppfStack_344;
    ppppfStack_658 = (float ****)0x4;
    ppppfStack_654 = ppppfStack_26c;
    ppppfStack_66c = (float ****)0x48bec6;
    __vbaLateIdSt();
    ppppfStack_280 = (float ****)(int)(short)pppfStack_1bc;
    ppppfStack_670 = (float ****)&ppppfStack_278;
    ppppfStack_270 = (float ****)&ppppfStack_1b8;
    ppppfStack_66c = (float ****)&DAT_0040c894;
    pppfStack_288 = (float ***)0x3;
    ppppfStack_278 = (float ****)0x4002;
    ppppfStack_674 = (float ****)0x48bf01;
    Ordinal_536();
    ppppfStack_674 = (float ****)0x48bf08;
    ppppfStack_674 = (float ****)__vbaStrMove();
    ppppfStack_678 = (float ****)0x48bf0f;
    Ordinal_519();
    ppppfStack_678 = (float ****)0x48bf16;
    ppppfStack_678 = (float ****)__vbaStrMove();
    ppppfStack_67c = (float ****)0x48bf1d;
    __vbaStrCat();
    ppppfStack_67c = (float ****)0x48bf24;
    ppppfStack_67c = (float ****)__vbaStrMove();
    ppppfStack_680 = (float ****)&DAT_00411680;
    ppppfStack_684 = (float ****)0x48bf30;
    pppfStack_6a8 = (float ***)__vbaStrCat();
    pppfStack_208 = (float ***)0x8;
    pppfStack_690 = pppfStack_288;
    ppppfStack_68c = (float ****)uStack_284;
    ppppfStack_688 = ppppfStack_280;
    ppppfStack_684 = (float ****)pppfStack_27c;
    pppfStack_6a0 = (float ***)0x3;
    ppppfStack_69c = ppppfStack_2a4;
    ppppfStack_698 = (float ****)0x0;
    ppppfStack_694 = (float ****)uStack_29c;
    ppppfStack_6b4 = (float ****)0x2;
    puStack_6b8 = (undefined4 *)0x41;
    ppppfStack_6b0 = (float ****)0x8;
    ppppfStack_6ac = ppppfStack_204;
    ppppfStack_6bc = ppppfStack_344;
    ppppfStack_6a4 = ppppfStack_1fc;
    ppppfStack_6c0 = (float ****)0x48bfad;
    ppppfStack_200 = (float ****)pppfStack_6a8;
    __vbaLateIdCallSt();
    ppppfStack_6c0 = (float ****)&ppppfStack_1ec;
    ppppfStack_6c4 = (float ****)&ppppfStack_1e8;
    ppppfStack_6c8 = (float ****)&ppppfStack_1e4;
    ppppfStack_6cc = (float ****)0x3;
    ppppfStack_6d0 = (float ****)0x48bfc1;
    __vbaFreeStrList();
    ppppfStack_684 = (float ****)0x48bfcd;
    __vbaFreeVar();
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_694 = (float ****)0xb;
    pppfStack_690 = (float ***)0x3;
    ppppfStack_270 = (float ****)0x1;
    ppppfStack_68c = ppppfStack_274;
    ppppfStack_698 = ppppfStack_344;
    ppppfStack_688 = (float ****)&DAT_00000001;
    ppppfStack_684 = ppppfStack_26c;
    ppppfStack_69c = (float ****)0x48c00a;
    __vbaLateIdSt();
    ppppfStack_270 = (float ****)0xff0000;
    ppppfStack_278 = (float ****)0x3;
    ppppfStack_6ac = (float ****)0x27;
    pppfStack_6a8 = (float ***)0x3;
    ppppfStack_6a4 = ppppfStack_274;
    ppppfStack_6b0 = ppppfStack_344;
    pppfStack_6a0 = (float ***)0xff0000;
    ppppfStack_69c = ppppfStack_26c;
    ppppfStack_6b4 = (float ****)0x48c047;
    __vbaLateIdSt();
    ppppfStack_278 = (float ****)0x2;
    ppppfStack_6c4 = (float ****)0x28;
    ppppfStack_6c0 = (float ****)0x2;
    ppppfStack_270 = (float ****)0x7;
    ppppfStack_6bc = ppppfStack_274;
    ppppfStack_6c8 = ppppfStack_344;
    puStack_6b8 = (undefined4 *)0x7;
    ppppfStack_6b4 = ppppfStack_26c;
    ppppfStack_6cc = (float ****)0x48c084;
    __vbaLateIdSt();
    ppppfStack_6cc = (float ****)0x48c089;
    FUN_0044fdc0();
    ppppfStack_6cc = (float ****)0x48c090;
    __vbaStrMove();
    ppppfStack_6d0 = (float ****)&ppppfStack_1e0;
    ppppfStack_280 = (float ****)(int)(short)pppfStack_1bc;
    ppppfStack_200 = ppppfStack_1e4;
    ppppfStack_6cc = (float ****)DAT_0050b0f4;
    pppfStack_288 = (float ***)0x3;
    pppppfVar14 = (float *****)&DAT_00000001;
    ppppfStack_2a8 = (float ****)0x3;
    ppppfStack_1e4 = (float ****)0x0;
    pppfStack_208 = (float ***)0x8;
    ppppfStack_6d4 = (float ****)0x48c0d7;
    __vbaAryLock();
    if ((ppppfStack_1e0 == (float ****)0x0) || (*(short *)ppppfStack_1e0 != 1)) {
      ppppfStack_6d4 = (float ****)0x48c113;
      iVar9 = __vbaGenerateBoundsError();
    }
    else {
      ppppfStack_318 = (float ****)((int)(short)ppppfStack_1b8 - (int)ppppfStack_1e0[5]);
      if (ppppfStack_1e0[4] <= ppppfStack_318) {
        ppppfStack_6d4 = (float ****)0x48c0ff;
        __vbaGenerateBoundsError();
      }
      iVar9 = (int)ppppfStack_318 << 3;
    }
    ppppfStack_6d4 = (float ****)0x1;
    ppppfStack_270 = (float ****)((int)ppppfStack_1e0[3] + iVar9);
    ppppfStack_6dc = &pppfStack_208;
    ppppfStack_6d8 = (float ****)&DAT_00000001;
    ppppfStack_6e0 = (float ****)&ppppfStack_278;
    ppppfStack_6e4 = (float ****)&ppppfStack_218;
    ppppfStack_278 = (float ****)0x4005;
    ppppfStack_6e8 = (float ****)0x48c144;
    Ordinal_660();
    ppppfStack_6e8 = (float ****)&ppppfStack_1e0;
    ppppfStack_6ec = (float ****)0x48c14e;
    __vbaAryUnlock();
    ppppfStack_6ec = (float ****)&ppppfStack_218;
    ppppfStack_6f0 = (float ****)0x48c158;
    ppppfStack_714 = (float ****)__vbaStrVarMove();
    pppfStack_228 = (float ***)0x8;
    uStack_220 = (double)CONCAT44(uStack_220._4_4_,ppppfStack_714);
    ppppfStack_6fc = (float ****)pppfStack_288;
    ppppfStack_6f8 = (float ****)uStack_284;
    ppppfStack_6f4 = ppppfStack_280;
    ppppfStack_6f0 = (float ****)pppfStack_27c;
    ppppfStack_70c = ppppfStack_2a8;
    ppppfStack_708 = ppppfStack_2a4;
    ppppfStack_704 = (float ****)0x1;
    ppppfStack_700 = (float ****)uStack_29c;
    ppppfStack_720 = (float ****)0x2;
    ppppfStack_724 = (float ****)0x41;
    ppppfStack_71c = (float ****)0x8;
    ppppfStack_718 = ppppfStack_224;
    ppppfStack_728 = ppppfStack_344;
    ppppfStack_710 = (float ****)uStack_220._4_4_;
    ppppfStack_72c = (float ****)0x48c1dc;
    __vbaLateIdCallSt();
    ppppfStack_6f0 = (float ****)0x48c1e8;
    __vbaFreeStr();
    ppppfStack_6f0 = &pppfStack_228;
    ppppfStack_6f4 = (float ****)&ppppfStack_218;
    ppppfStack_6f8 = &pppfStack_208;
    ppppfStack_6fc = (float ****)0x3;
    ppppfStack_700 = (float ****)0x48c1ff;
    uVar10 = __vbaFreeVarList();
    ppppfVar16 = (float ****)(uint)(ushort)((short)ppppfStack_1b8 + 1);
    if (SCARRY2((short)ppppfStack_1b8,1)) break;
LAB_0048bdb0:
    ppppfStack_1b8 = ppppfVar16;
    sVar19 = (short)ppppfStack_1b8;
    if (sStack_390 < sVar19) {
LAB_0048c219:
      ppppfStack_610 = (float ****)&ppppfStack_344;
      ppppfStack_60c = (float ****)0x0;
      ppppfStack_614 = (float ****)0x48c228;
      __vbaObjSetAddref();
code_r0x0048c229:
      ppppfStack_60c = (float ****)&LAB_0048c2c3;
      ppppfStack_610 = (float ****)&ppppfStack_344;
      ppppfStack_614 = (float ****)apiStack_340;
      ppppfStack_618 = (float ****)0x2;
      ppppfStack_61c = (float ****)0x48c2af;
      __vbaFreeObjList();
      ppppfStack_610 = (float ****)0x48c2bd;
      __vbaFreeStr();
      ppppfStack_610 = (float ****)0x48c2c2;
      __vbaFreeStr();
      return;
    }
    if (SBORROW2((short)ppppfStack_1c4,1)) break;
  }
LAB_0048c2d9:
  ppppfStack_60c = (float ****)0x48c2df;
  __vbaErrorOverflow();
  ppppfStack_618 = (float ****)&DAT_00402706;
  ppppfStack_61c = ExceptionList;
  ppppfStack_6b0 = (float ****)pcVar22;
  ppppfStack_614 = (float ****)&ppppfStack_6b4;
  ppppfStack_610 = (float ****)&DAT_00402128;
  ppppfStack_620 = (float ****)0x0;
  ppppfStack_630 = (float ****)0x0;
  ppppfStack_644 = (float ****)0x0;
  ppppfStack_65c = (float ****)0x0;
  ExceptionList = &ppppfStack_61c;
  ppppfStack_6b4 = ppppfVar24;
  ppppfStack_6ac = (float ****)pppppfVar14;
  pppppfVar14 = &ppppfStack_6b4;
  ppppfStack_60c = (float ****)&ppppfStack_1a4;
  if (DAT_0050b448 == 0) {
    puStack_6b8 = &DAT_0050b448;
    ppppfStack_6bc = (float ****)&DAT_004057e0;
    ppppfStack_6c0 = (float ****)0x48c333;
    ExceptionList = &ppppfStack_61c;
    ppppfStack_60c = (float ****)&ppppfStack_1a4;
    __vbaNew2();
    pppppfVar14 = (float *****)ppppfStack_614;
  }
  ppppfStack_614 = (float ****)pppppfVar14;
  ppppfStack_6bc = (float ****)&ppppfStack_65c;
  puStack_6b8 = (undefined4 *)DAT_0050b448;
  ppppfStack_6c0 = (float ****)0x48c343;
  __vbaObjSetAddref();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_6c0 = (float ****)&DAT_0050c53c;
    ppppfStack_6c4 = (float ****)&DAT_0040b420;
    ppppfStack_6c8 = (float ****)0x48c35b;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_6c0 = (float ****)&ppppfStack_620;
  ppppfStack_6c4 = (float ****)DAT_0050c53c;
  ppppfStack_6c8 = (float ****)0x48c36b;
  puVar17 = (undefined *)(*(code *)(*DAT_0050c53c)[6])();
  pcVar22 = __vbaHresultCheckObj_exref;
  if ((int)puVar17 < 0) {
    ppppfStack_6c8 = (float ****)0x18;
    ppppfStack_6cc = (float ****)&DAT_0040b410;
    ppppfStack_6d0 = (float ****)pppppfVar14;
    ppppfStack_6d8 = (float ****)0x48c382;
    ppppfStack_6d4 = (float ****)puVar17;
    __vbaHresultCheckObj();
  }
  ppppfVar24 = ppppfStack_620;
  ppppfStack_6c8 = (float ****)&ppppfStack_644;
  ppppfStack_6cc = ppppfStack_620;
  ppppfStack_6d0 = (float ****)0x48c39c;
  ppppfVar16 = (float ****)(*(code *)(*ppppfStack_620)[0x26])();
  if ((int)ppppfVar16 < 0) {
    ppppfStack_6d0 = (float ****)0x98;
    ppppfStack_6d4 = (float ****)&DAT_0040bb5c;
    ppppfStack_6d8 = ppppfVar24;
    ppppfStack_6e0 = (float ****)0x48c3b0;
    ppppfStack_6dc = ppppfVar16;
    __vbaHresultCheckObj();
  }
  bVar25 = ppppfStack_644 == (float ****)0x46160000;
  ppppfStack_6d0 = (float ****)0x48c3cb;
  __vbaFreeObj();
  if (bVar25) {
    ppppfStack_6d0 = (float ****)&ppppfStack_620;
    ppppfStack_6d4 = ppppfStack_65c;
    ppppfStack_6d8 = (float ****)0x48c3f0;
    ppppfStack_6e4 = (float ****)(*(code *)(*ppppfStack_65c)[0x92])();
    if ((int)ppppfStack_6e4 < 0) {
      ppppfStack_6d8 = (float ****)0x248;
      ppppfStack_6dc = (float ****)&DAT_0040c2b0;
      ppppfStack_6e0 = ppppfStack_65c;
      ppppfStack_6e8 = (float ****)0x48c407;
      __vbaHresultCheckObj();
    }
    ppppfVar16 = ppppfStack_624;
    ppppfVar24 = ppppfStack_62c;
    ppppfStack_6e8 = (float ****)0x2;
    ppppfStack_6ec = ppppfStack_620;
    ppppfStack_6e4 = (float ****)0x2;
    ppppfStack_6e0 = ppppfStack_62c;
    ppppfStack_6dc = (float ****)0x7;
    ppppfStack_6d8 = ppppfStack_624;
    ppppfStack_6f0 = (float ****)0x48c42b;
    __vbaLateIdSt();
    ppppfStack_6f0 = (float ****)0x48c434;
    __vbaFreeObj();
    ppppfStack_6f0 = (float ****)&ppppfStack_620;
    ppppfStack_6f4 = ppppfStack_65c;
    ppppfStack_6f8 = (float ****)0x48c444;
    ppppfStack_704 = (float ****)(*(code *)(*ppppfStack_65c)[0x92])();
    if ((int)ppppfStack_704 < 0) {
      ppppfStack_6f8 = (float ****)0x248;
      ppppfStack_6fc = (float ****)&DAT_0040c2b0;
      ppppfStack_700 = ppppfStack_65c;
      ppppfStack_708 = (float ****)0x48c45f;
      __vbaHresultCheckObj();
    }
    ppppfStack_708 = (float ****)0x3;
    ppppfStack_704 = (float ****)0xb;
    ppppfStack_700 = ppppfVar24;
    ppppfStack_6fc = (float ****)0x0;
    ppppfStack_70c = ppppfStack_620;
    ppppfStack_6f8 = ppppfVar16;
    ppppfStack_710 = (float ****)0x48c47e;
    __vbaLateIdSt();
    ppppfStack_710 = (float ****)0x48c487;
    __vbaFreeObj();
    pcVar22 = __vbaHresultCheckObj_exref;
  }
  ppppfStack_66c = (float ****)(int)DAT_0050b200;
  ppppfStack_6d0 = (float ****)(float)(int)ppppfStack_66c;
  ppppfStack_6d4 = ppppfStack_65c;
  ppppfStack_6d8 = (float ****)0x48c4af;
  ppppfStack_670 = ppppfStack_6d0;
  pppppfVar14 = (float *****)(*(code *)(*ppppfStack_65c)[0x39])();
  if ((int)pppppfVar14 < 0) {
    ppppfStack_6d8 = (float ****)0xe4;
    ppppfStack_6dc = (float ****)&DAT_0040c2b0;
    ppppfStack_6e0 = ppppfStack_65c;
    ppppfStack_6e8 = (float ****)0x48c4c6;
    ppppfStack_6e4 = (float ****)pppppfVar14;
    (*pcVar22)();
  }
  if (DAT_0050b448 == 0) {
    ppppfStack_6d8 = (float ****)&DAT_0050b448;
    ppppfStack_6dc = (float ****)&DAT_004057e0;
    ppppfStack_6e0 = (float ****)0x48c4de;
    __vbaNew2();
  }
  pcVar23 = __vbaPrintObj_exref;
  ppppfStack_6d8 = (float ****)&DAT_0040ca6c;
  ppppfStack_6dc = (float ****)DAT_0050b448;
  ppppfStack_6e0 = (float ****)&DAT_0040bf08;
  ppppfStack_6e4 = (float ****)0x48c4f7;
  __vbaPrintObj();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_6d8 = (float ****)&DAT_0050c53c;
    ppppfStack_6dc = (float ****)&DAT_0040b420;
    ppppfStack_6e0 = (float ****)0x48c513;
    __vbaNew2();
  }
  pppppfVar14 = DAT_0050c53c;
  ppppfStack_6d8 = (float ****)&ppppfStack_620;
  ppppfStack_6dc = (float ****)DAT_0050c53c;
  ppppfStack_6e0 = (float ****)0x48c523;
  pppppfVar11 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppfVar11 < 0) {
    ppppfStack_6e0 = (float ****)0x18;
    ppppfStack_6e4 = (float ****)&DAT_0040b410;
    ppppfStack_6e8 = (float ****)pppppfVar14;
    ppppfStack_6f0 = (float ****)0x48c534;
    ppppfStack_6ec = (float ****)pppppfVar11;
    (*pcVar22)();
  }
  ppppfVar24 = ppppfStack_620;
  ppppfStack_6e0 = (float ****)&ppppfStack_644;
  ppppfStack_6e4 = ppppfStack_620;
  ppppfStack_6e8 = (float ****)0x48c546;
  pppppfVar14 = (float *****)(*(code *)(*ppppfStack_620)[0x26])();
  if ((int)pppppfVar14 < 0) {
    ppppfStack_6e8 = (float ****)0x98;
    ppppfStack_6ec = (float ****)&DAT_0040bb5c;
    ppppfStack_6f0 = ppppfVar24;
    ppppfStack_6f8 = (float ****)0x48c55a;
    ppppfStack_6f4 = (float ****)pppppfVar14;
    (*pcVar22)();
  }
  ppppfVar24 = ppppfStack_644;
  ppppfStack_6e8 = (float ****)0x48c566;
  __vbaFreeObj();
  if (ppppfVar24 == (float ****)0x46960000) {
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_6e8 = (float ****)&DAT_0050c53c;
      ppppfStack_6ec = (float ****)&DAT_0040b420;
      ppppfStack_6f0 = (float ****)0x48c58b;
      __vbaNew2();
    }
    pppppfVar14 = DAT_0050c53c;
    ppppfStack_6e8 = (float ****)&ppppfStack_620;
    ppppfStack_6ec = (float ****)DAT_0050c53c;
    ppppfStack_6f0 = (float ****)0x48c59b;
    puVar17 = (undefined *)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)puVar17 < 0) {
      ppppfStack_6f0 = (float ****)0x18;
      ppppfStack_6f4 = (float ****)&DAT_0040b410;
      ppppfStack_6f8 = (float ****)pppppfVar14;
      ppppfStack_700 = (float ****)0x48c5ac;
      ppppfStack_6fc = (float ****)puVar17;
      (*pcVar22)();
    }
    ppppfVar24 = ppppfStack_620;
    ppppfStack_6f0 = (float ****)&ppppfStack_644;
    ppppfStack_6f4 = ppppfStack_620;
    ppppfStack_6f8 = (float ****)0x48c5bb;
    puVar17 = (undefined *)(*(code *)(*ppppfStack_620)[0x14])();
    uVar26 = 0;
    if ((int)puVar17 < 0) {
      ppppfStack_6f8 = (float ****)0x50;
      ppppfStack_6fc = (float ****)&DAT_0040bb5c;
      ppppfStack_700 = ppppfVar24;
      ppppfStack_708 = (float ****)0x48c5cc;
      ppppfStack_704 = (float ****)puVar17;
      (*pcVar22)();
    }
    ppppfStack_6f8 = (float ****)((float)ppppfStack_644 * (float)_DAT_00402120);
    if ((uVar26 & 0xd) != 0) {
LAB_0048c983:
      ppppfStack_6f8 = ppppfStack_65c;
      __vbaFPException();
      return;
    }
    ppppfStack_6fc = ppppfStack_65c;
    ppppfStack_700 = (float ****)0x48c5f5;
    ppppfStack_674 = ppppfStack_6f8;
    pppppfVar15 = (float *****)(*(code *)(*ppppfStack_65c)[0x3b])();
    pppppfVar14 = (float *****)ppppfStack_70c;
    pppppfVar11 = (float *****)ppppfStack_708;
    ppppfStack_708 = ppppfStack_65c;
  }
  else {
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_6e8 = (float ****)&DAT_0050c53c;
      ppppfStack_6ec = (float ****)&DAT_0040b420;
      ppppfStack_6f0 = (float ****)0x48c618;
      __vbaNew2();
    }
    pppppfVar14 = DAT_0050c53c;
    ppppfStack_6e8 = (float ****)&ppppfStack_620;
    ppppfStack_6ec = (float ****)DAT_0050c53c;
    ppppfStack_6f0 = (float ****)0x48c628;
    puVar17 = (undefined *)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)puVar17 < 0) {
      ppppfStack_6f0 = (float ****)0x18;
      ppppfStack_6f4 = (float ****)&DAT_0040b410;
      ppppfStack_6f8 = (float ****)pppppfVar14;
      ppppfStack_700 = (float ****)0x48c639;
      ppppfStack_6fc = (float ****)puVar17;
      (*pcVar22)();
    }
    ppppfVar24 = ppppfStack_620;
    ppppfStack_6f0 = (float ****)&ppppfStack_644;
    ppppfStack_6f4 = ppppfStack_620;
    ppppfStack_6f8 = (float ****)0x48c648;
    puVar17 = (undefined *)(*(code *)(*ppppfStack_620)[0x14])();
    uVar26 = 0;
    if ((int)puVar17 < 0) {
      ppppfStack_6f8 = (float ****)0x50;
      ppppfStack_6fc = (float ****)&DAT_0040bb5c;
      ppppfStack_700 = ppppfVar24;
      ppppfStack_708 = (float ****)0x48c659;
      ppppfStack_704 = (float ****)puVar17;
      (*pcVar22)();
    }
    ppppfStack_6f8 = (float ****)((float)ppppfStack_644 * (float)_DAT_00402118);
    if ((uVar26 & 0xd) != 0) goto LAB_0048c983;
    ppppfStack_6fc = ppppfStack_65c;
    ppppfStack_700 = (float ****)0x48c682;
    ppppfStack_678 = ppppfStack_6f8;
    pppppfVar15 = (float *****)(*(code *)(*ppppfStack_65c)[0x3b])();
    pppppfVar14 = (float *****)ppppfStack_70c;
    pppppfVar11 = (float *****)ppppfStack_708;
    ppppfStack_708 = ppppfStack_65c;
  }
  ppppfStack_70c = (float ****)pppppfVar15;
  ppppfStack_65c = ppppfStack_708;
  if ((int)ppppfStack_70c < 0) {
    ppppfStack_700 = (float ****)0xec;
    ppppfStack_704 = (float ****)&DAT_0040c2b0;
    ppppfStack_710 = (float ****)0x48c699;
    (*pcVar22)();
    pppppfVar14 = (float *****)ppppfStack_70c;
    pppppfVar11 = (float *****)ppppfStack_708;
  }
  ppppfStack_708 = (float ****)pppppfVar11;
  ppppfStack_70c = (float ****)pppppfVar14;
  ppppfStack_700 = (float ****)0x48c6a2;
  __vbaFreeObj();
  ppppfStack_67c = (float ****)(int)DAT_0050b200;
  ppppfStack_700 = (float ****)(float)(int)ppppfStack_67c;
  ppppfStack_704 = ppppfStack_65c;
  ppppfStack_708 = (float ****)0x48c6c2;
  ppppfStack_680 = ppppfStack_700;
  iVar9 = (*(code *)(*ppppfStack_65c)[0x39])();
  if (iVar9 < 0) {
    ppppfStack_708 = (float ****)0xe4;
    ppppfStack_70c = (float ****)&DAT_0040c2b0;
    ppppfStack_710 = ppppfStack_65c;
    ppppfStack_718 = (float ****)0x48c6d9;
    ppppfStack_714 = (float ****)iVar9;
    (*pcVar22)();
  }
  pcVar4 = __vbaNew2_exref;
  if (DAT_0050b448 == 0) {
    ppppfStack_708 = (float ****)&DAT_0050b448;
    ppppfStack_70c = (float ****)&DAT_004057e0;
    ppppfStack_710 = (float ****)0x48c6f4;
    __vbaNew2();
  }
  ppppfStack_708 = (float ****)0x41169c;
  ppppfStack_70c = (float ****)DAT_0050b448;
  ppppfStack_710 = (float ****)&DAT_0040bf08;
  ppppfStack_714 = (float ****)0x48c70e;
  __vbaPrintObj();
  sVar19 = DAT_0050b200 + 200;
  if (!SCARRY2(DAT_0050b200,200)) {
    DAT_0050b200 = sVar19;
    if ((DAT_0050b238 == 3) || (DAT_0050b238 == 5)) {
      ppppfStack_684 = (float ****)(int)sVar19;
      ppppfStack_708 = (float ****)(float)(int)ppppfStack_684;
      ppppfStack_70c = ppppfStack_65c;
      ppppfStack_710 = (float ****)0x48c754;
      ppppfStack_688 = ppppfStack_708;
      iVar9 = (*(code *)(*ppppfStack_65c)[0x39])();
      if (iVar9 < 0) {
        ppppfStack_710 = (float ****)0xe4;
        ppppfStack_714 = (float ****)&DAT_0040c2b0;
        ppppfStack_718 = ppppfStack_65c;
        ppppfStack_720 = (float ****)0x48c76b;
        ppppfStack_71c = (float ****)iVar9;
        (*pcVar22)();
      }
      if (DAT_0050b448 == 0) {
        ppppfStack_710 = (float ****)&DAT_0050b448;
        ppppfStack_714 = (float ****)&DAT_004057e0;
        ppppfStack_718 = (float ****)0x48c780;
        __vbaNew2();
      }
      ppppfStack_710 = (float ****)0x411744;
      ppppfStack_714 = (float ****)DAT_0050b448;
      ppppfStack_718 = (float ****)&DAT_0040bf08;
      ppppfStack_71c = (float ****)0x48c793;
      __vbaPrintObj();
    }
    ppppfStack_68c = (float ****)(int)DAT_0050b200;
    ppppfStack_708 = (float ****)(float)(int)ppppfStack_68c;
    ppppfStack_70c = ppppfStack_65c;
    ppppfStack_710 = (float ****)0x48c7be;
    pppfStack_690 = (float ***)ppppfStack_708;
    iVar9 = (*(code *)(*ppppfStack_65c)[0x39])();
    if (iVar9 < 0) {
      ppppfStack_710 = (float ****)0xe4;
      ppppfStack_714 = (float ****)&DAT_0040c2b0;
      ppppfStack_718 = ppppfStack_65c;
      ppppfStack_720 = (float ****)0x48c7d5;
      ppppfStack_71c = (float ****)iVar9;
      (*pcVar22)();
    }
    if (DAT_0050b448 == 0) {
      ppppfStack_710 = (float ****)&DAT_0050b448;
      ppppfStack_714 = (float ****)&DAT_004057e0;
      ppppfStack_718 = (float ****)0x48c7ea;
      __vbaNew2();
    }
    ppppfStack_710 = (float ****)0x4117d0;
    ppppfStack_714 = (float ****)DAT_0050b448;
    ppppfStack_718 = (float ****)&DAT_0040bf08;
    ppppfStack_71c = (float ****)0x48c7fd;
    __vbaPrintObj();
    ppppfStack_694 = (float ****)(int)DAT_0050b200;
    ppppfStack_710 = (float ****)(float)(int)ppppfStack_694;
    ppppfStack_714 = ppppfStack_65c;
    ppppfStack_718 = (float ****)0x48c82c;
    ppppfStack_698 = ppppfStack_710;
    iVar9 = (*(code *)(*ppppfStack_65c)[0x39])();
    if (iVar9 < 0) {
      ppppfStack_718 = (float ****)0xe4;
      ppppfStack_71c = (float ****)&DAT_0040c2b0;
      ppppfStack_720 = ppppfStack_65c;
      ppppfStack_728 = (float ****)0x48c843;
      ppppfStack_724 = (float ****)iVar9;
      (*pcVar22)();
    }
    if (DAT_0050b448 == 0) {
      ppppfStack_718 = (float ****)&DAT_0050b448;
      ppppfStack_71c = (float ****)&DAT_004057e0;
      ppppfStack_720 = (float ****)0x48c858;
      __vbaNew2();
    }
    ppppfStack_718 = (float ****)0x411858;
    ppppfStack_71c = (float ****)DAT_0050b448;
    ppppfStack_720 = (float ****)&DAT_0040bf08;
    ppppfStack_724 = (float ****)0x48c86b;
    __vbaPrintObj();
    ppppfStack_69c = (float ****)(int)DAT_0050b200;
    ppppfStack_718 = (float ****)(float)(int)ppppfStack_69c;
    ppppfStack_71c = ppppfStack_65c;
    ppppfStack_720 = (float ****)0x48c89a;
    pppfStack_6a0 = (float ***)ppppfStack_718;
    iVar9 = (*(code *)(*ppppfStack_65c)[0x39])();
    if (iVar9 < 0) {
      ppppfStack_720 = (float ****)0xe4;
      ppppfStack_724 = (float ****)&DAT_0040c2b0;
      ppppfStack_728 = ppppfStack_65c;
      ppppfStack_730 = (float ****)0x48c8b1;
      ppppfStack_72c = (float ****)iVar9;
      (*pcVar22)();
    }
    if (DAT_0050b448 == 0) {
      ppppfStack_720 = (float ****)&DAT_0050b448;
      ppppfStack_724 = (float ****)&DAT_004057e0;
      ppppfStack_728 = (float ****)0x48c8c6;
      __vbaNew2();
    }
    ppppfStack_720 = (float ****)0x411920;
    ppppfStack_724 = (float ****)DAT_0050b448;
    ppppfStack_728 = (float ****)&DAT_0040bf08;
    ppppfStack_72c = (float ****)0x48c8d9;
    __vbaPrintObj();
    ppppfStack_6a4 = (float ****)(int)DAT_0050b200;
    ppppfStack_720 = (float ****)(float)(int)ppppfStack_6a4;
    ppppfStack_724 = ppppfStack_65c;
    ppppfStack_728 = (float ****)0x48c908;
    pppfStack_6a8 = (float ***)ppppfStack_720;
    iVar9 = (*(code *)(*ppppfStack_65c)[0x39])();
    if (iVar9 < 0) {
      ppppfStack_728 = (float ****)0xe4;
      ppppfStack_72c = (float ****)&DAT_0040c2b0;
      ppppfStack_730 = ppppfStack_65c;
      uStack_738 = 0x48c91f;
      iStack_734 = iVar9;
      (*pcVar22)();
    }
    if (DAT_0050b448 == 0) {
      ppppfStack_728 = (float ****)&DAT_0050b448;
      ppppfStack_72c = (float ****)&DAT_004057e0;
      ppppfStack_730 = (float ****)0x48c934;
      __vbaNew2();
    }
    ppppfStack_728 = (float ****)0x4119ac;
    ppppfStack_72c = (float ****)DAT_0050b448;
    ppppfStack_730 = (float ****)&DAT_0040bf08;
    iStack_734 = 0x48c947;
    __vbaPrintObj();
    ppppfStack_72c = (float ****)&ppppfStack_65c;
    ppppfStack_728 = (float ****)0x0;
    ppppfStack_730 = (float ****)0x48c956;
    __vbaObjSetAddref();
    ppppfStack_730 = (float ****)&LAB_0048c972;
    iStack_734 = 0x48c971;
    __vbaFreeObj();
    return;
  }
  ppppfStack_708 = (float ****)0x48c98e;
  __vbaErrorOverflow();
  ppppfVar24 = ppppfStack_700;
  ppppfStack_714 = (float ****)&DAT_00402706;
  ppppfStack_718 = ExceptionList;
  pcStack_774 = pcVar4;
  ppppfStack_710 = (float ****)&pcStack_778;
  pcStack_778 = pcVar23;
  ppppfStack_70c = (float ****)&DAT_00402138;
  uStack_758 = 2;
  pwStack_750 = (wchar_t *)0x1;
  ppppfStack_728 = (float ****)0x0;
  uStack_738 = 0;
  auStack_748[0] = 0;
  auStack_768[0] = 0;
  ExceptionList = &ppppfStack_718;
  pcStack_770 = pcVar22;
  ppppfStack_708 = (float ****)&ppppfStack_60c;
  __vbaLateMemSt(*ppppfStack_700,L"ScaleMode",2,uStack_754,1,uStack_74c);
  uStack_758 = 8;
  pwStack_750 = L"arial";
  uVar10 = __vbaLateMemCallLd(&ppppfStack_728,*ppppfVar24,L"Font",0,L"Name",8,uStack_754,L"arial",
                              uStack_74c);
  __vbaVarLateMemSt(uVar10);
  __vbaFreeVar();
  uStack_758 = 2;
  pwStack_750 = (wchar_t *)0x6;
  uVar10 = __vbaLateMemCallLd(&ppppfStack_728,*ppppfVar24,L"Font",0,L"Size",2,uStack_754,6,
                              uStack_74c);
  __vbaVarLateMemSt(uVar10);
  __vbaFreeVar();
  pwStack_750 = (wchar_t *)0x0;
  uStack_758 = 0xb;
  uVar10 = __vbaLateMemCallLd(&ppppfStack_728,*ppppfVar24,L"Font",0,L"Bold",0xb,uStack_754,0,
                              uStack_74c);
  __vbaVarLateMemSt(uVar10);
  __vbaFreeVar();
  ppppfStack_720 = (float ****)FUN_0044fdc0();
  ppppfStack_728 = (float ****)0x8;
  uVar10 = __vbaLateMemCallLd(&uStack_738,*ppppfVar24,L"TextHeight",1,8,ppppfStack_724,
                              ppppfStack_720,ppppfStack_71c);
  DAT_0050b26c = __vbaI4Var(uVar10);
  __vbaFreeVarList(2,&ppppfStack_728,&uStack_738);
  uStack_758 = 2;
  pwStack_750 = (wchar_t *)0x4b0;
  __vbaLateMemSt(*ppppfVar24,L"CurrentX",2,uStack_754,0x4b0,uStack_74c);
  uStack_758 = 2;
  pwStack_750 = (wchar_t *)0x190;
  __vbaLateMemSt(*ppppfVar24,L"CurrentY",2,uStack_754,400,uStack_74c);
  Ordinal_608(&ppppfStack_728,0xae);
  uStack_758 = 8;
  auStack_768[0] = 8;
  pwStack_750 = L"TORA Optimization System, Windows";
  pwStack_760 = L"-version 2.00";
  uVar10 = __vbaVarCat(&uStack_738,&ppppfStack_728,&uStack_758);
  uVar10 = __vbaVarCat(auStack_748,auStack_768,uVar10);
  __vbaPrintObj(&DAT_0040f714,*ppppfVar24,uVar10);
  __vbaFreeVarList(3,&ppppfStack_728,&uStack_738,auStack_748);
  uStack_758 = 2;
  pwStack_750 = (wchar_t *)0x4b0;
  __vbaLateMemSt(*ppppfVar24,L"CurrentX",2,uStack_754,0x4b0,uStack_74c);
  puVar18 = (undefined4 *)__vbaLateMemCallLd(&ppppfStack_728,*ppppfVar24,L"CurrentY",0);
  __vbaLateMemSt(*ppppfVar24,L"CurrentY",*puVar18,puVar18[1],puVar18[2],puVar18[3]);
  __vbaFreeVar();
  Ordinal_608(&ppppfStack_728,0xa9);
  pwStack_750 = L"Copyright ";
  uStack_758 = 8;
  auStack_768[0] = 8;
  pwStack_760 = L" 2000-2007 Hamdy A. Taha.  All Rights Reserved";
  uVar10 = __vbaVarCat(&uStack_738,&ppppfStack_728,&uStack_758);
  uVar10 = __vbaVarCat(auStack_748,auStack_768,uVar10);
  __vbaPrintObj(&DAT_0040f714,*ppppfVar24,uVar10);
  __vbaFreeVarList(3,&ppppfStack_728,&uStack_738,auStack_748);
  uStack_758 = 2;
  pwStack_750 = (wchar_t *)0x4b0;
  __vbaLateMemSt(*ppppfVar24,L"CurrentX",2,uStack_754,0x4b0,uStack_74c);
  puVar18 = (undefined4 *)__vbaLateMemCallLd(&ppppfStack_728,*ppppfVar24,L"CurrentY",0);
  __vbaLateMemSt(*ppppfVar24,L"CurrentY",*puVar18,puVar18[1],puVar18[2],puVar18[3]);
  __vbaFreeVar();
  Ordinal_546(&ppppfStack_728);
  pwStack_750 = L"dddd, mmmm dd, yyyy h:mm";
  uStack_758 = 8;
  __vbaVarDup();
  Ordinal_660(auStack_748,&ppppfStack_728,&uStack_738,1,1);
  __vbaPrintObj(&DAT_0040f714,*ppppfVar24,auStack_748);
  __vbaFreeVarList(3,&ppppfStack_728,&uStack_738,auStack_748);
  return;
}


