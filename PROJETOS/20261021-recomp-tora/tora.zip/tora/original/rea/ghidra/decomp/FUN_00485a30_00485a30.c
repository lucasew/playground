/* entry 00485a30 name FUN_00485a30 size 4773 */
/* strings:
 * (M-Method)
 * (Two-Phase Method)
 * (Dual Simplex Method)
 * (Starting All-Slack Method)
 * (Bounded Simplex Method)
 * (Bounded Dual Simplex Method)
 * 1.  ENTERING variable: Click a NONBASIC variable (if correct, column turns green)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485a30(void)

{
  undefined1 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  code *pcVar5;
  bool bVar6;
  ushort uVar7;
  int *piVar8;
  float *pfVar9;
  int *local_88 [11];
  int *local_5c;
  float local_58;
  float local_54;
  undefined4 local_50 [6];
  undefined4 local_38;
  undefined4 local_30;
  int *local_2c;
  undefined4 local_28;
  undefined4 local_24 [2];
  undefined4 local_1c;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff48;
  local_8 = &DAT_004020e8;
  local_1c = 0;
  local_24[0] = 0;
  local_28 = 0;
  local_2c = (int *)0x0;
  local_50[0] = 0;
  local_54 = 0.0;
  local_58 = 0.0;
  local_5c = (int *)0x0;
  local_88[0] = (int *)0x0;
  ExceptionList = &pvStack_14;
  puVar1 = &stack0xffffff48;
  if (DAT_0050b420 == (int *)0x0) {
    ExceptionList = &pvStack_14;
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    puVar1 = local_c;
  }
  local_c = puVar1;
  __vbaObjSetAddref(local_88,DAT_0050b420);
  iVar2 = (**(code **)(*local_88[0] + 0x248))(local_88[0],&local_2c);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,local_88[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,0,8,local_38,L"arial",local_30);
  __vbaFreeObj();
  iVar2 = (**(code **)(*local_88[0] + 0x248))(local_88[0],&local_2c);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,local_88[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,2,2,local_38,6,local_30);
  __vbaFreeObj();
  iVar2 = (**(code **)(*local_88[0] + 0x6c))(local_88[0],0xffffff);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,local_88[0],&DAT_0040b430,0x6c);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  __vbaObjSetAddref(&local_2c,DAT_0050b420);
  FUN_0048c990(&local_2c);
  uVar3 = __vbaCastObj(local_2c,&DAT_0040b85c);
  __vbaObjSet(&DAT_0050b420,uVar3);
  __vbaFreeObj();
  iVar2 = (**(code **)(*local_88[0] + 0x248))(local_88[0],&local_2c);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,local_88[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,3,0xb,local_38,0xffffffff,local_30);
  __vbaFreeObj();
  __vbaObjSetAddref(local_88,0);
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  uVar3 = (**(code **)(*DAT_0050b420 + 0x364))(DAT_0050b420);
  piVar4 = (int *)__vbaObjSet(&local_2c,uVar3);
  iVar2 = (**(code **)(*piVar4 + 0x9c))(piVar4,0);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  uVar3 = (**(code **)(*DAT_0050b420 + 0x3b0))(DAT_0050b420,0x80010007,0xb,local_38,0,local_30);
  uVar3 = __vbaObjSet(&local_2c,uVar3);
  __vbaLateIdSt(uVar3);
  __vbaFreeObj();
  switch(DAT_0050b274) {
  case 2:
    break;
  case 3:
    break;
  case 4:
    break;
  case 5:
    break;
  case 6:
    break;
  case 7:
    break;
  default:
    goto switchD_00485d2a_default;
  }
  __vbaStrCopy();
switchD_00485d2a_default:
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar4 = DAT_0050b420;
  iVar2 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,2,2,local_38,10,local_30);
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar4 = DAT_0050b420;
  iVar2 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,3,0xb,local_38,0xffffffff,local_30);
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar4 = DAT_0050b420;
  iVar2 = (**(code **)(*DAT_0050b420 + 300))(DAT_0050b420,1);
  pcVar5 = __vbaHresultCheckObj_exref;
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,300);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar4 = DAT_0050b420;
  pfVar9 = &local_54;
  piVar8 = DAT_0050b420;
  iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,pfVar9);
  uVar7 = 0;
  if (iVar2 < 0) {
    __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0xe8);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar4 = DAT_0050b420;
  if ((uVar7 & 0xd) == 0) {
    iVar2 = (**(code **)(*DAT_0050b420 + 0xec))
                      (DAT_0050b420,_DAT_0050b028 * (float)_DAT_004016e0 * local_54);
    if (iVar2 < 0) {
      __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0xec);
    }
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar4 = DAT_0050c53c;
    iVar2 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
    if (iVar2 < 0) {
      __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b410,0x18);
    }
    piVar4 = local_2c;
    iVar2 = (**(code **)(*local_2c + 0x98))(local_2c,&local_54);
    if (iVar2 < 0) {
      __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040bb5c,0x98);
    }
    if (DAT_0050b420 == (int *)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    piVar4 = DAT_0050b420;
    iVar2 = *DAT_0050b420;
    __vbaStrCat(local_1c,L"SIMPLEX TABLEAU - ",&local_58);
    uVar3 = __vbaStrMove();
    iVar2 = (**(code **)(iVar2 + 0x2e4))(piVar4,uVar3);
    uVar7 = 0;
    if (iVar2 < 0) {
      __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0x2e4);
    }
    if (DAT_0050b420 == (int *)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    piVar4 = DAT_0050b420;
    if ((uVar7 & 0xd) == 0) {
      if ((uVar7 & 0xd) == 0) {
        iVar2 = (**(code **)(*DAT_0050b420 + 0xe4))
                          (DAT_0050b420,DAT_0050b024 * (float)_DAT_00401268 * (local_54 - local_58))
        ;
        if (iVar2 < 0) {
          __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0xe4);
        }
        __vbaFreeStr();
        __vbaFreeObj();
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        __vbaStrCat(local_1c,L"SIMPLEX TABLEAU - ");
        uVar3 = __vbaStrMove();
        __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,uVar3);
        __vbaFreeStr();
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar4 = DAT_0050b420;
        iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
        if (iVar2 < 0) {
          __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0xe8);
        }
        if (DAT_0050c53c == (int *)0x0) {
          __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
        }
        piVar4 = DAT_0050c53c;
        iVar2 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
        if (iVar2 < 0) {
          __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b410,0x18);
        }
        piVar4 = local_2c;
        iVar2 = (**(code **)(*local_2c + 0x98))(local_2c,&local_58);
        if (iVar2 < 0) {
          __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040bb5c,0x98);
        }
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar4 = DAT_0050b420;
        iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_5c);
        uVar7 = 0;
        if (iVar2 < 0) {
          __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0xe8);
        }
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar4 = DAT_0050b420;
        pfVar9 = (float *)0x0;
        piVar8 = local_5c;
        if ((uVar7 & 0xd) == 0) {
          iVar2 = (**(code **)(*DAT_0050b420 + 0x2c8))
                            (DAT_0050b420,4,0x44960000,local_54,
                             (local_58 - _DAT_004020e0) * DAT_0050b024,local_5c,0);
          if (iVar2 < 0) {
            __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0x2c8);
          }
          __vbaFreeObj();
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          uVar3 = (**(code **)(*DAT_0050b420 + 0x368))(DAT_0050b420);
          piVar4 = (int *)__vbaObjSet(&local_2c,uVar3);
          iVar2 = (**(code **)(*piVar4 + 0xe8))(piVar4,local_50);
          if (iVar2 < 0) {
            __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040dc58,0xe8);
          }
          bVar6 = (short)local_50[0] == 0;
          __vbaFreeObj();
          if (bVar6) {
            if (DAT_0050b420 == (int *)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            uVar3 = (**(code **)(*DAT_0050b420 + 0x368))(DAT_0050b420);
            piVar4 = (int *)__vbaObjSet(&local_2c,uVar3);
            iVar2 = (**(code **)(*piVar4 + 0x1ec))
                              (piVar4,L"Output summary",10,local_38,0x80020004,local_30);
            if (iVar2 < 0) {
              __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040dc58,0x1ec);
            }
            __vbaFreeObj();
            if (DAT_0050b420 == (int *)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            uVar3 = (**(code **)(*DAT_0050b420 + 0x368))(DAT_0050b420);
            piVar4 = (int *)__vbaObjSet(&local_2c,uVar3);
            iVar2 = (**(code **)(*piVar4 + 0x1ec))
                              (piVar4,L"Iterations",10,local_38,0x80020004,local_30);
            if (iVar2 < 0) {
              __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040dc58,0x1ec);
            }
            __vbaFreeObj();
            pcVar5 = __vbaHresultCheckObj_exref;
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar4 = DAT_0050b420;
          iVar2 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44960000);
          if (iVar2 < 0) {
            (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe4);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar4 = DAT_0050b420;
          iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
          uVar7 = 0;
          if (iVar2 < 0) {
            (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe8);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar4 = DAT_0050b420;
          if ((uVar7 & 0xd) == 0) {
            iVar2 = (**(code **)(*DAT_0050b420 + 0xec))
                              (DAT_0050b420,local_54 * (float)_DAT_00401280);
            if (iVar2 < 0) {
              (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xec);
            }
            __vbaStrCopy();
            if (DAT_0050b23c == 1) {
              __vbaStrCopy();
            }
            if (DAT_0050b420 == (int *)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            __vbaStrCat(*(undefined4 *)(DAT_0050b37c + 4),L"Title: ");
            uVar3 = __vbaStrMove();
            __vbaStrCat(local_1c,uVar3);
            uVar3 = __vbaStrMove();
            __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,uVar3);
            __vbaFreeStrList(2,local_24,&local_28);
            if (DAT_0050b420 == (int *)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            piVar4 = DAT_0050b420;
            iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
            if (iVar2 < 0) {
              (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe8);
            }
            if (DAT_0050c53c == (int *)0x0) {
              __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
            }
            piVar4 = DAT_0050c53c;
            iVar2 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
            if (iVar2 < 0) {
              (*pcVar5)(iVar2,piVar4,&DAT_0040b410,0x18);
            }
            piVar4 = local_2c;
            iVar2 = (**(code **)(*local_2c + 0x98))(local_2c,&local_58);
            if (iVar2 < 0) {
              (*pcVar5)(iVar2,piVar4,&DAT_0040bb5c,0x98);
            }
            if (DAT_0050b420 == (int *)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            piVar4 = DAT_0050b420;
            iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_5c);
            uVar7 = 0;
            if (iVar2 < 0) {
              (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe8);
            }
            if (DAT_0050b420 == (int *)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            piVar4 = DAT_0050b420;
            pfVar9 = (float *)0x0;
            piVar8 = local_5c;
            if ((uVar7 & 0xd) == 0) {
              iVar2 = (**(code **)(*DAT_0050b420 + 0x2c8))
                                (DAT_0050b420,4,0x44960000,local_54,
                                 (local_58 - _DAT_004020e0) * DAT_0050b024,local_5c,0);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0x2c8);
              }
              __vbaFreeObj();
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
              if (iVar2 < 0) {
                __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0x248);
              }
              __vbaLateIdSt(local_2c,2,2,local_38,8,local_30);
              __vbaFreeObj();
              if (DAT_0050c53c == (int *)0x0) {
                __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
              }
              piVar4 = DAT_0050c53c;
              iVar2 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
              pcVar5 = __vbaHresultCheckObj_exref;
              if (iVar2 < 0) {
                __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b410,0x18);
              }
              piVar4 = local_2c;
              iVar2 = (**(code **)(*local_2c + 0x98))(local_2c,&local_54);
              if (iVar2 < 0) {
                __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040bb5c,0x98);
              }
              bVar6 = local_54 == 9600.0;
              __vbaFreeObj();
              if (bVar6) {
                if (DAT_0050b420 == (int *)0x0) {
                  __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                }
                piVar4 = DAT_0050b420;
                iVar2 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
                if (iVar2 < 0) {
                  __vbaHresultCheckObj(iVar2,piVar4,&DAT_0040b430,0x248);
                }
                __vbaLateIdSt(local_2c,2,2,local_38,6,local_30);
                __vbaFreeObj();
                pcVar5 = __vbaHresultCheckObj_exref;
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44960000);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"Steps for generating NEXT tableau from CURRENT one:");
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44c80000);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar8 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar8,&DAT_0040b430,0xe8);
              }
              iVar2 = (**(code **)(*piVar4 + 0xec))(piVar4,local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xec);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"1.  ENTERING variable: Click a NONBASIC variable (if correct, column turns green)"
                           );
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44c80000);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar8 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar8,&DAT_0040b430,0xe8);
              }
              iVar2 = (**(code **)(*piVar4 + 0xec))(piVar4,local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xec);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"2.  LEAVING variable: Click a BASIC variable (if correct, row turns red)"
                           );
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44c80000);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar8 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar8,&DAT_0040b430,0xe8);
              }
              iVar2 = (**(code **)(*piVar4 + 0xec))(piVar4,local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xec);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"3.  Click command button NEXT ITERATION (or ALL ITERATIONS) -- This step may be executed without Steps 1 and/or 2."
                           );
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_54);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe8);
              }
              if (DAT_0050c53c == (int *)0x0) {
                __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
              }
              piVar4 = DAT_0050c53c;
              iVar2 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b410,0x18);
              }
              piVar4 = local_2c;
              iVar2 = (**(code **)(*local_2c + 0x98))(local_2c,&local_58);
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040bb5c,0x98);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              iVar2 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_5c);
              uVar7 = 0;
              if (iVar2 < 0) {
                (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0xe8);
              }
              if (DAT_0050b420 == (int *)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              piVar4 = DAT_0050b420;
              pfVar9 = (float *)0x0;
              piVar8 = local_5c;
              if ((uVar7 & 0xd) == 0) {
                iVar2 = (**(code **)(*DAT_0050b420 + 0x2c8))
                                  (DAT_0050b420,4,0x44960000,local_54,
                                   (local_58 - _DAT_004020e0) * DAT_0050b024);
                if (iVar2 < 0) {
                  (*pcVar5)(iVar2,piVar4,&DAT_0040b430,0x2c8);
                }
                __vbaFreeObj();
                __vbaFreeObj(&LAB_00486ced);
                __vbaFreeStr();
                return;
              }
            }
          }
        }
      }
    }
  }
  __vbaFPException(piVar8,pfVar9);
  return;
}


