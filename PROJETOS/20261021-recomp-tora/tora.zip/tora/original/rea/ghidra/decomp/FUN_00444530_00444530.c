/* entry 00444530 name FUN_00444530 size 1835 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00444530(void)

{
  code *pcVar1;
  code *pcVar2;
  code *pcVar3;
  undefined1 *puVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  undefined4 uVar8;
  undefined2 extraout_var;
  code *pcStack_204;
  code *pcStack_200;
  code *pcStack_1fc;
  int iStack_1f8;
  int iStack_1f4;
  undefined4 auStack_1e8 [2];
  int *piStack_1e0;
  int *piStack_1d8;
  undefined4 uStack_1d0;
  int iStack_1cc;
  int *piStack_1c8;
  undefined4 *puStack_1c4;
  undefined4 *puStack_1c0;
  int *piStack_1bc;
  int iStack_1b8;
  int *piStack_1b4;
  int *piStack_1b0;
  int *piStack_1ac;
  int iStack_1a8;
  int *piStack_1a4;
  int *piStack_1a0;
  int *piStack_19c;
  undefined4 *puStack_198;
  int *piStack_194;
  int *piStack_190;
  int *piStack_18c;
  int *piStack_188;
  int *piStack_184;
  int *piStack_180;
  undefined4 *puStack_17c;
  int *piStack_178;
  int *piStack_174;
  undefined4 *puStack_170;
  undefined4 *puStack_16c;
  int *piStack_168;
  int *piStack_164;
  undefined4 uStack_160;
  int *piStack_15c;
  int iStack_158;
  int *piStack_154;
  undefined *puStack_150;
  int *piStack_14c;
  int *piStack_148;
  undefined4 uStack_144;
  int iStack_140;
  undefined *puStack_13c;
  int *piStack_138;
  int **ppiStack_134;
  undefined4 uStack_130;
  int *piStack_12c;
  int iStack_128;
  int *piStack_124;
  undefined *puStack_120;
  int *piStack_11c;
  int *piStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined4 uStack_ec;
  int *piStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  int iStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  int iStack_cc;
  undefined4 uStack_c8;
  int *piStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  int iStack_b4;
  undefined4 uStack_b0;
  int **ppiStack_ac;
  int *piStack_a8;
  int *local_88 [4];
  undefined4 local_78;
  undefined4 local_74;
  int local_70 [3];
  undefined4 local_64;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48 [4];
  undefined4 local_38 [4];
  undefined4 local_28;
  int local_24;
  int local_20;
  int local_1c;
  undefined4 local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff5c;
  local_8 = &DAT_00401c68;
  DAT_0050b228 = DAT_0050b22c;
  DAT_0050b22a = DAT_0050b22e;
  local_18 = 0;
  local_1c = 0;
  local_20 = 0;
  local_24 = 0;
  local_28 = 0;
  local_38[0] = 0;
  local_48[0] = 0;
  local_70[1] = 0;
  local_70[0] = 0;
  local_74 = 0;
  local_78 = 0;
  local_88[0] = (int *)0x0;
  DAT_0050b29a = 0;
  DAT_0050b274 = 0;
  ExceptionList = &pvStack_14;
  puVar4 = &stack0xffffff5c;
  if (DAT_0050b448 == (int *)0x0) {
    piStack_a8 = (int *)&DAT_0050b448;
    ppiStack_ac = (int **)&DAT_004057e0;
    uStack_b0 = 0x4445c7;
    ExceptionList = &pvStack_14;
    __vbaNew2();
    puVar4 = local_c;
  }
  local_c = puVar4;
  ppiStack_ac = local_88;
  piStack_a8 = DAT_0050b448;
  uStack_b0 = 0x4445da;
  __vbaObjSetAddref();
  iStack_b4 = (int)DAT_0050b234;
  uStack_c0 = 4;
  uStack_bc = 3;
  uStack_b8 = local_54;
  piStack_c4 = local_88[0];
  uStack_b0 = local_4c;
  uStack_c8 = 0x44460d;
  uStack_c8 = (**(code **)(*local_88[0] + 0x378))();
  pcVar1 = __vbaObjSet_exref;
  iStack_cc = (int)&local_1c;
  uStack_d0 = 0x44461a;
  uStack_d0 = __vbaObjSet();
  uStack_d4 = 0x444621;
  __vbaLateIdSt();
  uStack_d4 = 0x44462a;
  __vbaFreeObj();
  iStack_d8 = (int)DAT_0050b236;
  uStack_e4 = 5;
  uStack_e0 = 3;
  uStack_dc = local_54;
  piStack_e8 = local_88[0];
  uStack_d4 = local_4c;
  uStack_ec = 0x444657;
  uStack_ec = (**(code **)(*local_88[0] + 0x378))();
  iStack_f0 = (int)&local_1c;
  uStack_f4 = 0x44465e;
  uStack_f4 = __vbaObjSet();
  uStack_f8 = 0x444665;
  __vbaLateIdSt();
  uStack_f8 = 0x44466e;
  __vbaFreeObj();
  local_50 = 0x80020004;
  local_58 = 10;
  uStack_104 = 10;
  uStack_100 = local_64;
  uStack_fc = 0x80020004;
  uStack_f8 = local_5c;
  uStack_114 = 10;
  uStack_110 = local_54;
  uStack_10c = 0x80020004;
  uStack_108 = local_4c;
  piStack_118 = local_88[0];
  piStack_11c = (int *)0x4446c3;
  iVar5 = (**(code **)(*local_88[0] + 0x2b0))();
  if (iVar5 < 0) {
    piStack_11c = (int *)0x2b0;
    puStack_120 = &DAT_0040c2b0;
    piStack_124 = local_88[0];
    piStack_12c = (int *)0x4446e3;
    iStack_128 = iVar5;
    __vbaHresultCheckObj();
  }
  piStack_11c = local_88[0];
  puStack_120 = (undefined *)0x4446fa;
  puStack_120 = (undefined *)(**(code **)(*local_88[0] + 0x314))();
  piStack_124 = &local_1c;
  iStack_128 = 0x444701;
  piVar6 = (int *)__vbaObjSet();
  iStack_128 = 0xffffffff;
  uStack_130 = 0x44470e;
  piStack_12c = piVar6;
  iVar5 = (**(code **)(*piVar6 + 0x8c))();
  if (iVar5 < 0) {
    uStack_130 = 0x8c;
    ppiStack_134 = (int **)&DAT_0040bb6c;
    iStack_140 = 0x444722;
    puStack_13c = (undefined *)iVar5;
    piStack_138 = piVar6;
    __vbaHresultCheckObj();
  }
  uStack_130 = 0x44472b;
  __vbaFreeObj();
  ppiStack_134 = local_88;
  uStack_130 = 0;
  piStack_138 = (int *)0x44473a;
  __vbaObjSetAddref();
  if (DAT_0050b448 == (int *)0x0) {
    piStack_138 = (int *)&DAT_0050b448;
    puStack_13c = &DAT_004057e0;
    iStack_140 = 0x444753;
    __vbaNew2();
  }
  piStack_138 = DAT_0050b448;
  puStack_13c = (undefined *)0x444761;
  puStack_13c = (undefined *)(**(code **)(*DAT_0050b448 + 0x31c))();
  iStack_140 = (int)&local_1c;
  uStack_144 = 0x444768;
  piVar6 = (int *)__vbaObjSet();
  uStack_144 = *(undefined4 *)(DAT_0050b37c + 4);
  piStack_14c = (int *)0x44477d;
  piStack_148 = piVar6;
  iVar5 = (**(code **)(*piVar6 + 0xa4))();
  if (iVar5 < 0) {
    piStack_14c = (int *)0xa4;
    puStack_150 = &DAT_0040c3cc;
    piStack_15c = (int *)0x444791;
    iStack_158 = iVar5;
    piStack_154 = piVar6;
    __vbaHresultCheckObj();
  }
  piStack_14c = (int *)0x44479a;
  __vbaFreeObj();
  if (DAT_0050b448 == (int *)0x0) {
    piStack_14c = (int *)&DAT_0050b448;
    puStack_150 = &DAT_004057e0;
    piStack_154 = (int *)0x4447b3;
    __vbaNew2();
  }
  piStack_14c = DAT_0050b448;
  puStack_150 = (undefined *)0x4447c1;
  puStack_150 = (undefined *)(**(code **)(*DAT_0050b448 + 0x324))();
  piStack_154 = &local_1c;
  iStack_158 = 0x4447c8;
  piVar6 = (int *)__vbaObjSet();
  iStack_158 = *(undefined4 *)(DAT_0050b37c + 8);
  uStack_160 = 0x4447dd;
  piStack_15c = piVar6;
  iVar5 = (**(code **)(*piVar6 + 0xa4))();
  if (iVar5 < 0) {
    uStack_160 = 0xa4;
    piStack_164 = (int *)&DAT_0040c3cc;
    puStack_170 = (undefined4 *)0x4447f1;
    puStack_16c = (undefined4 *)iVar5;
    piStack_168 = piVar6;
    __vbaHresultCheckObj();
  }
  uStack_160 = 0x4447fa;
  __vbaFreeObj();
  uStack_160 = *(undefined4 *)(DAT_0050b37c + 8);
  piStack_164 = (int *)0x444809;
  Ordinal_581();
  piStack_164 = (int *)0x444811;
  DAT_0050b20a = __vbaFpI2();
  switch(DAT_0050b238) {
  case 3:
  case 5:
  case 9:
    piStack_164 = *(int **)(DAT_0050b37c + 0xc);
    piStack_168 = (int *)0x444841;
    Ordinal_581();
    piStack_168 = (int *)0x444843;
    DAT_0050b20c = __vbaFpI2();
    if (DAT_0050b448 == (int *)0x0) {
      piStack_168 = (int *)&DAT_0050b448;
      puStack_16c = (undefined4 *)&DAT_004057e0;
      puStack_170 = (undefined4 *)0x444862;
      __vbaNew2();
    }
    piStack_168 = DAT_0050b448;
    puStack_16c = (undefined4 *)0x444870;
    puStack_16c = (undefined4 *)(**(code **)(*DAT_0050b448 + 0x318))();
    puStack_170 = &local_1c;
    piStack_174 = (int *)0x444877;
    piVar6 = (int *)__vbaObjSet();
    piStack_174 = *(int **)(DAT_0050b37c + 0xc);
    puStack_17c = (undefined4 *)0x44488c;
    piStack_178 = piVar6;
    piVar7 = (int *)(**(code **)(*piVar6 + 0xa4))();
    if ((int)piVar7 < 0) {
      puStack_17c = (undefined4 *)0xa4;
      piStack_180 = (int *)&DAT_0040c3cc;
      piStack_18c = (int *)0x4448a8;
      piStack_188 = piVar7;
      piStack_184 = piVar6;
      __vbaHresultCheckObj();
    }
    break;
  case 4:
    if (DAT_0050b448 == (int *)0x0) {
      piStack_164 = (int *)&DAT_0050b448;
      piStack_168 = (int *)&DAT_004057e0;
      puStack_16c = (undefined4 *)0x4448c6;
      __vbaNew2();
    }
    piStack_164 = DAT_0050b448;
    piStack_168 = (int *)0x4448d4;
    piStack_168 = (int *)(**(code **)(*DAT_0050b448 + 0x318))();
    puStack_16c = &local_1c;
    puStack_170 = (undefined4 *)0x4448db;
    piVar6 = (int *)__vbaObjSet();
    puStack_170 = *(undefined4 **)(DAT_0050b37c + 0xc);
    piStack_178 = (int *)0x4448f0;
    piStack_174 = piVar6;
    piVar7 = (int *)(**(code **)(*piVar6 + 0xa4))();
    if ((int)piVar7 < 0) {
      piStack_178 = (int *)0xa4;
      puStack_17c = (undefined4 *)&DAT_0040c3cc;
      piStack_188 = (int *)0x444908;
      piStack_184 = piVar7;
      piStack_180 = piVar6;
      __vbaHresultCheckObj();
    }
    piStack_178 = (int *)0x444911;
    __vbaFreeObj();
    piStack_178 = *(int **)(DAT_0050b37c + 8);
    puStack_17c = (undefined4 *)0x444920;
    Ordinal_581();
    puStack_17c = (undefined4 *)0x444922;
    DAT_0050b2c4 = __vbaFpI2();
    puStack_17c = *(undefined4 **)(DAT_0050b37c + 0xc);
    piStack_180 = (int *)0x444938;
    Ordinal_581();
    piStack_180 = (int *)0x44493a;
    DAT_0050b2c6 = __vbaFpI2();
  default:
    goto switchD_0044482a_caseD_6;
  case 8:
    if (DAT_0050b448 == (int *)0x0) {
      piStack_164 = (int *)&DAT_0050b448;
      piStack_168 = (int *)&DAT_004057e0;
      puStack_16c = (undefined4 *)0x44495e;
      __vbaNew2();
    }
    piStack_164 = DAT_0050b448;
    piStack_168 = (int *)0x44496c;
    piStack_168 = (int *)(**(code **)(*DAT_0050b448 + 0x324))();
    puStack_16c = &local_1c;
    puStack_170 = (undefined4 *)0x444973;
    piVar6 = (int *)__vbaObjSet();
    puStack_170 = (undefined4 *)0x0;
    piStack_178 = (int *)0x444980;
    piStack_174 = piVar6;
    piVar7 = (int *)(**(code **)(*piVar6 + 0x94))();
    if ((int)piVar7 < 0) {
      piStack_178 = (int *)0x94;
      puStack_17c = (undefined4 *)&DAT_0040c3cc;
      piStack_188 = (int *)0x44499a;
      piStack_184 = piVar7;
      piStack_180 = piVar6;
      __vbaHresultCheckObj();
    }
    piStack_178 = (int *)0x4449ab;
    __vbaFreeObj();
    if (DAT_0050b448 == (int *)0x0) {
      piStack_178 = (int *)&DAT_0050b448;
      puStack_17c = (undefined4 *)&DAT_004057e0;
      piStack_180 = (int *)0x4449c4;
      __vbaNew2();
    }
    piStack_178 = DAT_0050b448;
    puStack_17c = (undefined4 *)0x4449d2;
    puStack_17c = (undefined4 *)(**(code **)(*DAT_0050b448 + 0x33c))();
    piStack_180 = &local_1c;
    piStack_184 = (int *)0x4449d9;
    piVar6 = (int *)__vbaObjSet();
    piStack_184 = (int *)0x0;
    piStack_18c = (int *)0x4449e6;
    piStack_188 = piVar6;
    iVar5 = (**(code **)(*piVar6 + 0x9c))();
    if (iVar5 < 0) {
      piStack_18c = (int *)0x9c;
      piStack_190 = (int *)&DAT_0040ba5c;
      piStack_19c = (int *)0x4449fa;
      puStack_198 = (undefined4 *)iVar5;
      piStack_194 = piVar6;
      __vbaHresultCheckObj();
    }
    piStack_18c = (int *)0x444a03;
    __vbaFreeObj();
    if (DAT_0050b448 == (int *)0x0) {
      piStack_18c = (int *)&DAT_0050b448;
      piStack_190 = (int *)&DAT_004057e0;
      piStack_194 = (int *)0x444a1c;
      __vbaNew2();
    }
    piStack_18c = DAT_0050b448;
    piStack_190 = (int *)0x444a2a;
    piStack_190 = (int *)(**(code **)(*DAT_0050b448 + 0x330))();
    piStack_194 = &local_1c;
    puStack_198 = (undefined4 *)0x444a31;
    piVar6 = (int *)__vbaObjSet();
    puStack_198 = (undefined4 *)0x0;
    piStack_1a0 = (int *)0x444a3e;
    piStack_19c = piVar6;
    piVar7 = (int *)(**(code **)(*piVar6 + 0x9c))();
    if ((int)piVar7 < 0) {
      puStack_17c = (undefined4 *)0x9c;
      piStack_180 = (int *)&DAT_0040ba5c;
      piStack_18c = (int *)0x444a52;
      piStack_188 = piVar7;
      piStack_184 = piVar6;
      __vbaHresultCheckObj();
    }
  }
  puStack_17c = (undefined4 *)0x444a5b;
  __vbaFreeObj();
switchD_0044482a_caseD_6:
  DAT_0050b208 = 1;
  piStack_164 = (int *)0x444a69;
  FUN_0044baa0();
  if (DAT_0050b448 == (int *)0x0) {
    piStack_164 = (int *)&DAT_0050b448;
    piStack_168 = (int *)&DAT_004057e0;
    puStack_16c = (undefined4 *)0x444a84;
    __vbaNew2();
  }
  piStack_164 = DAT_0050b448;
  piStack_168 = (int *)0x444a9a;
  piStack_168 = (int *)(**(code **)(*DAT_0050b448 + 0x378))();
  puStack_16c = &local_28;
  puStack_170 = (undefined4 *)0x444aa1;
  __vbaObjSet();
  if (DAT_0050b448 == (int *)0x0) {
    puStack_170 = &DAT_0050b448;
    piStack_174 = (int *)&DAT_004057e0;
    piStack_178 = (int *)0x444ab6;
    __vbaNew2();
  }
  puStack_170 = (undefined4 *)0x0;
  piStack_174 = (int *)0x4;
  piStack_178 = DAT_0050b448;
  puStack_17c = (undefined4 *)0x444ac8;
  puStack_17c = (undefined4 *)(**(code **)(*DAT_0050b448 + 0x378))();
  piStack_180 = &local_1c;
  piStack_184 = (int *)0x444acf;
  piStack_184 = (int *)__vbaObjSet();
  piStack_188 = local_38;
  piStack_18c = (int *)0x444adc;
  __vbaLateIdCallLd();
  if (DAT_0050b448 == (int *)0x0) {
    puStack_17c = &DAT_0050b448;
    piStack_180 = (int *)&DAT_004057e0;
    piStack_184 = (int *)0x444af4;
    __vbaNew2();
  }
  puStack_17c = (undefined4 *)0x0;
  piStack_180 = (undefined4 *)0x5;
  piStack_184 = DAT_0050b448;
  piStack_188 = (int *)0x444b06;
  piStack_188 = (int *)(**(code **)(*DAT_0050b448 + 0x378))();
  piStack_18c = &local_20;
  piStack_190 = (int *)0x444b0d;
  piStack_190 = (int *)__vbaObjSet();
  piStack_194 = local_48;
  puStack_198 = (undefined4 *)0x444b14;
  piStack_188 = (int *)__vbaLateIdCallLd();
  pcVar3 = __vbaI4Var_exref;
  piStack_18c = (int *)0x444b20;
  iVar5 = __vbaI4Var();
  pcVar2 = __vbaI2I4_exref;
  if (!SBORROW4(iVar5,1)) {
    piStack_18c = (int *)0x444b33;
    local_78 = __vbaI2I4();
    piStack_18c = local_38;
    piStack_190 = (int *)0x444b3c;
    iVar5 = __vbaI4Var();
    if (!SBORROW4(iVar5,1)) {
      piStack_18c = (int *)0x444b49;
      local_74 = __vbaI2I4();
      piStack_190 = &local_24;
      piStack_18c = (int *)local_28;
      local_70[0] = 0;
      local_70[1] = 0;
      local_28 = 0;
      piStack_194 = (int *)0x444b61;
      __vbaObjSet();
      piStack_194 = (int *)0x444b6f;
      __vbaStrCopy();
      piStack_194 = &local_78;
      puStack_198 = &local_74;
      piStack_19c = local_70;
      piStack_1a0 = local_70 + 1;
      piStack_1a4 = &local_24;
      iStack_1a8 = (int)&local_18;
      piStack_1ac = (int *)0x444b8c;
      FUN_00444cc0();
      piStack_1ac = (int *)0x444b95;
      __vbaFreeStr();
      piStack_1ac = &local_28;
      piStack_1b0 = &local_24;
      piStack_1b4 = &local_20;
      iStack_1b8 = (int)&local_1c;
      piStack_1bc = (int *)0x4;
      puStack_1c0 = (undefined4 *)0x444bad;
      __vbaFreeObjList();
      puStack_1c0 = local_48;
      puStack_1c4 = local_38;
      piStack_1c8 = (int *)0x2;
      iStack_1cc = 0x444bbd;
      __vbaFreeVarList();
      if (DAT_0050b238 == 7) {
        if (DAT_0050b448 == (int *)0x0) {
          piStack_1ac = (int *)&DAT_0050b448;
          piStack_1b0 = (int *)&DAT_004057e0;
          piStack_1b4 = (int *)0x444be3;
          __vbaNew2();
        }
        piStack_1ac = DAT_0050b448;
        piStack_1b0 = (int *)0x444bf1;
        piStack_1b0 = (int *)(**(code **)(*DAT_0050b448 + 0x300))();
        piStack_1b4 = &local_1c;
        iStack_1b8 = 0x444bf8;
        piVar6 = (int *)__vbaObjSet();
        iStack_1b8 = CONCAT22(extraout_var,DAT_0050b336);
        puStack_1c0 = (undefined4 *)0x444c0b;
        piStack_1bc = piVar6;
        iVar5 = (**(code **)(*piVar6 + 0xe4))();
        if (iVar5 < 0) {
          puStack_1c0 = (undefined4 *)0xe4;
          puStack_1c4 = (undefined4 *)&DAT_0040c3ac;
          uStack_1d0 = 0x444c23;
          iStack_1cc = iVar5;
          piStack_1c8 = piVar6;
          __vbaHresultCheckObj();
        }
        puStack_1c0 = (undefined4 *)0x444c2c;
        __vbaFreeObj();
      }
      piStack_1ac = (int *)0x444c31;
      FUN_0044a160();
      piStack_1ac = (int *)0x444c36;
      FUN_0048c2e0();
      piStack_1ac = (int *)&LAB_00444c80;
      piStack_1b0 = (int *)0x444c7f;
      __vbaFreeObj();
      return;
    }
  }
  piStack_18c = (int *)0x444cb6;
  __vbaErrorOverflow();
  puStack_198 = (undefined4 *)&DAT_00402706;
  piStack_19c = ExceptionList;
  pcStack_1fc = pcVar1;
  pcStack_200 = pcVar3;
  piStack_194 = (int *)&pcStack_204;
  pcStack_204 = pcVar2;
  piStack_190 = (int *)&DAT_00401c78;
  piStack_1a0 = (int *)0x0;
  piStack_1a4 = (int *)0x0;
  piStack_1b4 = (int *)0x0;
  auStack_1e8[0] = 0;
  ExceptionList = &piStack_19c;
  piStack_18c = (int *)&stack0xfffffffc;
  __vbaObjSetAddref(auStack_1e8,*piStack_180);
  piStack_1bc = (int *)CONCAT22(piStack_1bc._2_2_,*(undefined2 *)puStack_17c);
  __vbaLateMemSt(auStack_1e8[0],&DAT_0040eaa0,2,puStack_1c0,piStack_1bc,iStack_1b8);
  piStack_1bc = (int *)CONCAT22(piStack_1bc._2_2_,(short)*piStack_178);
  __vbaLateMemSt(auStack_1e8[0],&DAT_0040eaa8,2,puStack_1c0,piStack_1bc,iStack_1b8);
  piStack_1bc = (int *)CONCAT22(piStack_1bc._2_2_,(short)*piStack_174);
  __vbaLateMemSt(auStack_1e8[0],L"RowSel",2,puStack_1c0,piStack_1bc,iStack_1b8);
  piStack_1bc = (int *)CONCAT22(piStack_1bc._2_2_,*(undefined2 *)puStack_170);
  __vbaLateMemSt(auStack_1e8[0],L"ColSel",2,puStack_1c0,piStack_1bc,iStack_1b8);
  iVar5 = __vbaStrCmp(&DAT_0040c888,*piStack_184);
  if (iVar5 == 0) {
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar6 = DAT_0050c53c;
    iVar5 = (**(code **)(*DAT_0050c53c + 0x1c))(DAT_0050c53c,&piStack_1a4);
    if (iVar5 < 0) {
      __vbaHresultCheckObj(iVar5,piVar6,&DAT_0040b410,0x1c);
    }
    piVar6 = piStack_1a4;
    iStack_1f4 = *piStack_1a4;
    uVar8 = __vbaLateMemCallLd(&piStack_1b4,auStack_1e8[0],L"Clip",0,10,puStack_1c0,0x80020004,
                               iStack_1b8);
    uVar8 = __vbaStrVarVal(&piStack_1a0,uVar8);
    iVar5 = (**(code **)(iStack_1f4 + 0x60))(piVar6,uVar8);
    if (iVar5 < 0) {
      __vbaHresultCheckObj(iVar5,piVar6,&DAT_0040eadc,0x60);
    }
    __vbaFreeStr();
  }
  else {
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piStack_1d8 = DAT_0050c53c;
    iVar5 = (**(code **)(*DAT_0050c53c + 0x1c))(DAT_0050c53c,&piStack_1a4);
    if (iVar5 < 0) {
      __vbaHresultCheckObj(iVar5,piStack_1d8,&DAT_0040b410,0x1c);
    }
    piStack_1e0 = piStack_1a4;
    iStack_1f8 = *piStack_1a4;
    iVar5 = (**(code **)(iStack_1f8 + 0x5c))
                      (piStack_1a4,10,puStack_1c0,0x80020004,iStack_1b8,&piStack_1a0);
    if (iVar5 < 0) {
      __vbaHresultCheckObj(iVar5,piStack_1e0,&DAT_0040eadc,0x5c);
    }
    piVar6 = piStack_1a0;
    piStack_1b4 = (int *)0x8;
    piStack_1ac = piStack_1a0;
    piStack_1a0 = (int *)0x0;
    __vbaLateMemSt(auStack_1e8[0],L"Clip",8,piStack_1b0,piVar6,iStack_1a8);
  }
  __vbaFreeObj();
  __vbaFreeVar();
  __vbaObjSetAddref(auStack_1e8,0);
  __vbaFreeObj(&LAB_00444f98);
  return;
}


