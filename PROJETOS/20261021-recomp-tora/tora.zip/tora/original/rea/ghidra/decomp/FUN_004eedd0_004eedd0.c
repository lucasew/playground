/* entry 004eedd0 name FUN_004eedd0 size 2967 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004eedd0(void)

{
  float **ppfVar1;
  float **ppfVar2;
  code **ppcVar3;
  short sVar4;
  int iVar5;
  float ****ppppfVar6;
  undefined4 uVar7;
  float ****ppppfVar8;
  int *piVar9;
  undefined2 extraout_var;
  float ****extraout_EDX;
  undefined2 uVar10;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  undefined2 extraout_var_02;
  float ***pppfVar11;
  uint uVar12;
  short sVar13;
  short sVar14;
  float ***unaff_ESI;
  float ***pppfVar15;
  float ****ppppfVar16;
  int iVar17;
  code *pcVar18;
  ushort uVar19;
  float10 fVar20;
  double dVar21;
  code *pcStack_488;
  float ***pppfStack_484;
  float ***pppfStack_480;
  undefined8 uStack_47c;
  int iStack_474;
  undefined8 uStack_470;
  float ***pppfStack_468;
  undefined8 uStack_464;
  float ***pppfStack_45c;
  undefined8 uStack_458;
  float ***pppfStack_450;
  float ***pppfStack_44c;
  float ***pppfStack_448;
  float ***pppfStack_444;
  float ***pppfStack_440;
  float ***pppfStack_43c;
  float ***pppfStack_438;
  float ***pppfStack_434;
  float ***pppfStack_430;
  float ***pppfStack_42c;
  float ***pppfStack_428;
  float ***pppfStack_424;
  float ***pppfStack_420;
  float ***pppfStack_41c;
  float ***pppfStack_418;
  float ***pppfStack_414;
  float ***pppfStack_410;
  float ***pppfStack_40c;
  undefined8 uStack_408;
  float ***pppfStack_400;
  float ***pppfStack_3fc;
  float ***pppfStack_3f8;
  float ***pppfStack_3f4;
  float ***pppfStack_3f0;
  float ***pppfStack_3ec;
  float ***pppfStack_3e8;
  float ***pppfStack_3e4;
  float ***pppfStack_3e0;
  float ***pppfStack_3dc;
  float ***pppfStack_3d8;
  float ***pppfStack_3d4;
  float ***pppfStack_3d0;
  float ***pppfStack_3cc;
  float ***pppfStack_3c8;
  float ***pppfStack_3c4;
  undefined *puStack_3c0;
  float ***pppfStack_3bc;
  float ***pppfStack_3b8;
  undefined4 uStack_3b4;
  undefined4 uStack_3b0;
  float ***pppfStack_3ac;
  undefined4 uStack_3a8;
  float ***pppfStack_3a4;
  undefined4 uStack_3a0;
  int iStack_39c;
  float ***pppfStack_398;
  undefined *puStack_394;
  float ***pppfStack_390;
  int *piStack_38c;
  int iStack_388;
  float ***pppfStack_384;
  undefined *puStack_380;
  float ***pppfStack_37c;
  float ***pppfStack_378;
  undefined4 uStack_374;
  float ***pppfStack_370;
  undefined4 uStack_36c;
  float **ppfStack_368;
  float ***pppfStack_364;
  undefined *puStack_360;
  float ***pppfStack_35c;
  float ***pppfStack_358;
  float ***pppfStack_354;
  float ***pppfStack_350;
  undefined4 uStack_34c;
  float **ppfStack_348;
  float ***pppfStack_344;
  undefined *puStack_340;
  float ***pppfStack_33c;
  float ***pppfStack_338;
  float ***pppfStack_334;
  float ***pppfStack_330;
  undefined4 uStack_32c;
  float ***pppfStack_328;
  undefined4 uStack_324;
  float **ppfStack_320;
  float ***pppfStack_31c;
  wchar_t *pwStack_318;
  float ***pppfStack_314;
  float ***pppfStack_310;
  float ***pppfStack_30c;
  float ***pppfStack_308;
  float ***pppfStack_304;
  code *pcStack_300;
  float **ppfStack_2fc;
  float **ppfStack_2f8;
  int iStack_2f4;
  int iStack_2f0;
  float fStack_2ec;
  float fStack_2e8;
  float **ppfStack_2e4;
  int iStack_2e0;
  float fStack_2dc;
  float fStack_2d8;
  int iStack_2d4;
  short sStack_2b4;
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_28c;
  undefined4 uStack_284;
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_264;
  float ***pppfStack_254;
  float ***apppfStack_250 [6];
  float ***pppfStack_238;
  float ***pppfStack_234;
  float ***pppfStack_230;
  undefined8 uStack_22c;
  float ***pppfStack_224;
  float **ppfStack_220;
  float ***apppfStack_21c [9];
  undefined4 uStack_1f8;
  float ***pppfStack_1f4;
  float ***pppfStack_1ec;
  undefined4 uStack_1e8;
  float ***pppfStack_1e4;
  float **ppfStack_1dc;
  float ***pppfStack_1d8;
  float ***pppfStack_1d4;
  undefined4 uStack_1d0;
  float ***pppfStack_1cc;
  float **ppfStack_1c8;
  float **ppfStack_1c4;
  float **ppfStack_1c0;
  undefined4 uStack_1bc;
  float ***pppfStack_1b8;
  float ***pppfStack_1b4;
  float ***pppfStack_1b0;
  float ***pppfStack_1ac;
  float **ppfStack_1a8;
  float ***pppfStack_1a4;
  float ***pppfStack_1a0;
  float **ppfStack_19c;
  float **ppfStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  float ***pppfStack_18c;
  float **appfStack_188 [2];
  float **ppfStack_180;
  float **ppfStack_178;
  float ***pppfStack_174;
  float ***pppfStack_170;
  float ***pppfStack_16c;
  float **ppfStack_168;
  float **ppfStack_164;
  float ***pppfStack_160;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined4 uStack_154;
  float **ppfStack_150;
  float ***pppfStack_14c;
  float **ppfStack_148;
  float ***pppfStack_144;
  float *pfStack_140;
  undefined4 *puStack_13c;
  float ***pppfStack_138;
  float **ppfStack_134;
  undefined4 *puStack_130;
  float ***pppfStack_12c;
  float **ppfStack_128;
  uint uStack_124;
  float **ppfStack_120;
  undefined4 *puStack_11c;
  undefined4 *puStack_118;
  undefined4 *puStack_114;
  wchar_t *pwStack_110;
  float ***pppfStack_10c;
  int local_fc;
  undefined4 local_d0;
  float **local_cc;
  uint local_c8;
  uint local_c4;
  uint local_c0;
  undefined4 local_9c;
  wchar_t *local_94;
  float *local_8c [2];
  uint *local_84;
  undefined4 local_7c [2];
  undefined4 local_74;
  undefined4 local_6c [2];
  undefined4 local_64;
  float *local_5c [4];
  float **local_4c [2];
  undefined4 local_44;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  uint local_30;
  float local_2c;
  float local_28;
  undefined4 local_24;
  uint local_20;
  float **local_1c;
  uint local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  sVar4 = DAT_0050b332;
  pcVar18 = __vbaGenerateBoundsError_exref;
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffef8;
  local_8 = &DAT_00402590;
  local_30 = 0;
  local_34 = 0;
  local_38 = 0;
  local_3c = 0;
  local_4c[0] = (float **)0x0;
  local_5c[0] = (float *)0x0;
  local_6c[0] = 0;
  local_7c[0] = 0;
  local_8c[0] = (float *)0x0;
  local_9c = 0;
  local_d0 = 0;
  DAT_0050b3c2 = 0;
  local_18 = 1;
  ppppfVar16 = DAT_0050b3cc;
  ExceptionList = &pvStack_14;
  uVar12 = local_18;
  do {
    local_18 = uVar12;
    pppfVar11 = (float ***)0x0;
    if (sVar4 < (short)local_18) {
      local_24 = 0;
      goto LAB_004eefe5;
    }
    if ((ppppfVar16 == (float ****)0x0) || (*(short *)ppppfVar16 != 2)) {
      pppfStack_10c = (float ***)0x4eeea5;
      iVar5 = __vbaGenerateBoundsError();
      ppppfVar16 = DAT_0050b3cc;
    }
    else {
      pppfVar11 = (float ***)-(int)ppppfVar16[7];
      if (ppppfVar16[6] <= pppfVar11) {
        pppfStack_10c = (float ***)0x4eee78;
        __vbaGenerateBoundsError();
        ppppfVar16 = DAT_0050b3cc;
      }
      unaff_ESI = (float ***)((int)(short)local_18 - (int)ppppfVar16[5]);
      if (ppppfVar16[4] <= unaff_ESI) {
        pppfStack_10c = (float ***)0x4eee90;
        __vbaGenerateBoundsError();
        ppppfVar16 = DAT_0050b3cc;
      }
      iVar5 = (int)((int)ppppfVar16[6] * (int)unaff_ESI + (int)pppfVar11) * 4;
    }
    if (*(float *)((int)ppppfVar16[3] + iVar5) == _DAT_00401488) {
      DAT_0050b3c2 = 1;
      if ((DAT_0050b3d4 == (float ****)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
        pppfStack_10c = (float ***)0x4eeefe;
        iVar5 = __vbaGenerateBoundsError();
      }
      else {
        unaff_ESI = (float ***)((int)(short)local_18 - (int)DAT_0050b3d4[5]);
        if (DAT_0050b3d4[4] <= unaff_ESI) {
          pppfStack_10c = (float ***)0x4eeeed;
          __vbaGenerateBoundsError();
        }
        iVar5 = (int)unaff_ESI * 4;
      }
      *(undefined4 *)((int)DAT_0050b3d4[3] + iVar5) = 0;
      if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
        pppfStack_10c = (float ***)0x4eef5d;
        iVar5 = __vbaGenerateBoundsError();
      }
      else {
        pppfVar11 = (float ***)((int)(short)local_18 - *(int *)(DAT_0050b3e8 + 0xe));
        if (*(float ****)(DAT_0050b3e8 + 0xc) <= pppfVar11) {
          pppfStack_10c = (float ***)0x4eef30;
          __vbaGenerateBoundsError();
        }
        unaff_ESI = (float ***)(1 - *(int *)(DAT_0050b3e8 + 10));
        if (*(float ****)(DAT_0050b3e8 + 8) <= unaff_ESI) {
          pppfStack_10c = (float ***)0x4eef49;
          __vbaGenerateBoundsError();
        }
        iVar5 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)unaff_ESI + (int)pppfVar11) * 2;
      }
      *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar5) = (short)local_18;
      if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
        pppfStack_10c = (float ***)0x4eefb4;
        iVar5 = __vbaGenerateBoundsError();
      }
      else {
        unaff_ESI = (float ***)((int)(short)local_18 - *(int *)(DAT_0050b3e8 + 0xe));
        if (*(float ****)(DAT_0050b3e8 + 0xc) <= unaff_ESI) {
          pppfStack_10c = (float ***)0x4eef8c;
          __vbaGenerateBoundsError();
        }
        pppfVar11 = (float ***)-*(int *)(DAT_0050b3e8 + 10);
        if (*(float ****)(DAT_0050b3e8 + 8) <= pppfVar11) {
          pppfStack_10c = (float ***)0x4eefa0;
          __vbaGenerateBoundsError();
        }
        iVar5 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)pppfVar11 + (int)unaff_ESI) * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar5) = 1;
      ppppfVar16 = DAT_0050b3cc;
    }
    uVar12 = (uint)(ushort)((short)local_18 + 1);
  } while (!SCARRY2((short)local_18,1));
LAB_004ef9a0:
  pppfStack_10c = (float ***)0x4ef9a6;
  __vbaErrorOverflow();
  puStack_118 = (undefined4 *)&DAT_00402706;
  puStack_11c = ExceptionList;
  puStack_114 = &pcStack_300;
  pcStack_300 = pcVar18;
  pwStack_110 = L"\x06\x04";
  ppfStack_134 = (float **)0x0;
  puStack_13c = (undefined4 *)0x0;
  ppfStack_148 = (float **)0x0;
  pppfStack_14c = (float ***)0x0;
  ppfStack_150 = (float **)0x0;
  uStack_154 = 0;
  uStack_158 = 0;
  uStack_15c = 0;
  pppfStack_160 = (float ***)0x0;
  ppfStack_164 = (float **)0x0;
  ppfStack_168 = (float **)0x0;
  ppfStack_178 = (float **)0x0;
  appfStack_188[0] = (float **)0x0;
  ppfStack_198 = (float **)0x0;
  ppfStack_1a8 = (float **)0x0;
  pppfStack_1b8 = (float ***)0x0;
  ppfStack_1c8 = (float **)0x0;
  pppfStack_1d8 = (float ***)0x0;
  uStack_1e8 = 0;
  uStack_1f8 = 0;
  apppfStack_21c[0] = (float ***)0x0;
  ppfStack_220 = (float **)0x0;
  pppfStack_224 = (float ***)0x0;
  apppfStack_250[0] = (float ***)0x0;
  pppfStack_254 = (float ***)0x0;
  DAT_0050b1fe = 2;
  ExceptionList = &puStack_11c;
  ppfStack_2fc = (float **)unaff_ESI;
  ppfStack_2f8 = (float **)pppfVar11;
  ppcVar3 = &pcStack_300;
  pppfStack_10c = (float ***)&stack0xfffffffc;
  if (DAT_0050b420 == (float ****)0x0) {
    pppfStack_304 = (float ***)&DAT_0050b420;
    pppfStack_308 = (float ***)&DAT_00408c88;
    pppfStack_30c = (float ***)0x4efa6f;
    ExceptionList = &puStack_11c;
    pppfStack_10c = (float ***)&stack0xfffffffc;
    __vbaNew2();
    ppcVar3 = (code **)puStack_114;
  }
  puStack_114 = ppcVar3;
  pppfStack_308 = (float ***)apppfStack_250;
  pppfStack_304 = (float ***)DAT_0050b420;
  pppfStack_30c = (float ***)0x4efa82;
  __vbaObjSetAddref();
  pppfStack_30c = (float ***)&pppfStack_160;
  pppfStack_1b0 = (float ***)0x40c3f0;
  pppfStack_1b8 = (float ***)0x8;
  pppfStack_310 = apppfStack_250[0];
  pppfStack_314 = (float ***)0x4efaa9;
  ppfStack_320 = (float **)(*(code *)(*apppfStack_250[0])[0x92])();
  if ((int)ppfStack_320 < 0) {
    pppfStack_314 = (float ***)0x248;
    pwStack_318 = L"믲㢺毡䞍྽닦\xf724㶱䞙缔횱䙏䆙赘鄽쭖䉂片摩";
    pppfStack_31c = apppfStack_250[0];
    uStack_324 = 0x4efac9;
    __vbaHresultCheckObj();
  }
  ppppfVar16 = (float ****)__vbaLateIdSt_exref;
  uStack_324 = 0;
  ppfStack_320 = (float **)pppfStack_1b8;
  pppfStack_31c = pppfStack_1b4;
  pwStack_318 = (wchar_t *)pppfStack_1b0;
  pppfStack_314 = pppfStack_1ac;
  pppfStack_328 = pppfStack_160;
  uStack_32c = 0x4efb07;
  __vbaLateIdSt();
  uStack_32c = 0x4efb12;
  __vbaFreeObj();
  uStack_32c = 0xffffff;
  pppfStack_330 = apppfStack_250[0];
  pppfStack_334 = (float ***)0x4efb23;
  iVar5 = (*(code *)(*apppfStack_250[0])[0x1b])();
  if (iVar5 < 0) {
    pppfStack_334 = (float ***)0x6c;
    pppfStack_338 = (float ***)&DAT_0040b430;
    pppfStack_33c = apppfStack_250[0];
    pppfStack_344 = (float ***)0x4efb3a;
    puStack_340 = (undefined *)iVar5;
    __vbaHresultCheckObj();
  }
  pppfStack_334 = (float ***)&pppfStack_160;
  pppfStack_1b0 = (float ***)0xa;
  pppfStack_1b8 = (float ***)0x2;
  pppfStack_338 = apppfStack_250[0];
  pppfStack_33c = (float ***)0x4efb61;
  ppfStack_348 = (float **)(*(code *)(*apppfStack_250[0])[0x92])();
  if ((int)ppfStack_348 < 0) {
    pppfStack_33c = (float ***)0x248;
    puStack_340 = &DAT_0040b430;
    pppfStack_344 = apppfStack_250[0];
    uStack_34c = 0x4efb7b;
    __vbaHresultCheckObj();
  }
  uStack_34c = 2;
  ppfStack_348 = (float **)pppfStack_1b8;
  pppfStack_344 = pppfStack_1b4;
  puStack_340 = (undefined *)pppfStack_1b0;
  pppfStack_33c = pppfStack_1ac;
  pppfStack_350 = pppfStack_160;
  pppfStack_354 = (float ***)0x4efbab;
  __vbaLateIdSt();
  pppfStack_354 = (float ***)0x4efbb0;
  __vbaFreeObj();
  pppfStack_354 = (float ***)&pppfStack_160;
  pppfStack_1b0 = (float ***)0xffffffff;
  pppfStack_1b8 = (float ***)0xb;
  pppfStack_358 = apppfStack_250[0];
  pppfStack_35c = (float ***)0x4efbd7;
  ppfStack_368 = (float **)(*(code *)(*apppfStack_250[0])[0x92])();
  if ((int)ppfStack_368 < 0) {
    pppfStack_35c = (float ***)0x248;
    puStack_360 = &DAT_0040b430;
    pppfStack_364 = apppfStack_250[0];
    uStack_36c = 0x4efbf1;
    __vbaHresultCheckObj();
  }
  uStack_36c = 3;
  ppfStack_368 = (float **)pppfStack_1b8;
  pppfStack_364 = pppfStack_1b4;
  puStack_360 = (undefined *)pppfStack_1b0;
  pppfStack_35c = pppfStack_1ac;
  pppfStack_370 = pppfStack_160;
  uStack_374 = 0x4efc21;
  __vbaLateIdSt();
  uStack_374 = 0x4efc26;
  __vbaFreeObj();
  uStack_374 = 1;
  pppfStack_378 = apppfStack_250[0];
  pppfStack_37c = (float ***)0x4efc37;
  iVar5 = (*(code *)(*apppfStack_250[0])[0x4b])();
  if (iVar5 < 0) {
    pppfStack_37c = (float ***)0x12c;
    puStack_380 = &DAT_0040b430;
    pppfStack_384 = apppfStack_250[0];
    piStack_38c = (int *)0x4efc51;
    iStack_388 = iVar5;
    __vbaHresultCheckObj();
  }
  pppfStack_37c = apppfStack_250[0];
  puStack_380 = (undefined *)0x4efc60;
  puStack_380 = (undefined *)(*(code *)(*apppfStack_250[0])[0xd1])();
  pppfStack_384 = (float ***)&pppfStack_160;
  iStack_388 = 0x4efc6b;
  piStack_38c = (int *)__vbaObjSet();
  iStack_388 = 0;
  pppfStack_390 = (float ***)0x4efc7c;
  pppfStack_230 = (float ***)piStack_38c;
  iVar5 = (**(code **)(*piStack_38c + 0x9c))();
  if (iVar5 < 0) {
    pppfStack_390 = (float ***)0x9c;
    puStack_394 = &DAT_0040c3dc;
    pppfStack_398 = pppfStack_230;
    uStack_3a0 = 0x4efc96;
    iStack_39c = iVar5;
    __vbaHresultCheckObj();
  }
  pppfStack_390 = (float ***)0x4efc9b;
  __vbaFreeObj();
  pppfStack_1b8 = (float ***)0xb;
  uStack_3a0 = 0x80010007;
  iStack_39c = 0xb;
  pppfStack_1b0 = (float ***)0xffffffff;
  pppfStack_398 = pppfStack_1b4;
  puStack_394 = (undefined *)0xffffffff;
  pppfStack_390 = pppfStack_1ac;
  pppfStack_3a4 = apppfStack_250[0];
  uStack_3a8 = 0x4efcdf;
  uStack_3a8 = (*(code *)(*apppfStack_250[0])[0xea])();
  pppfStack_3ac = (float ***)&pppfStack_160;
  uStack_3b0 = 0x4efcea;
  uStack_3b0 = __vbaObjSet();
  uStack_3b4 = 0x4efced;
  __vbaLateIdSt();
  uStack_3b4 = 0x4efcf2;
  __vbaFreeObj();
  uStack_3b4 = 0x44960000;
  pppfStack_3b8 = apppfStack_250[0];
  pppfStack_3bc = (float ***)0x4efd06;
  iVar5 = (*(code *)(*apppfStack_250[0])[0x39])();
  if (iVar5 < 0) {
    pppfStack_3bc = (float ***)0xe4;
    puStack_3c0 = &DAT_0040b430;
    pppfStack_3c4 = apppfStack_250[0];
    pppfStack_3cc = (float ***)0x4efd20;
    pppfStack_3c8 = (float ***)iVar5;
    __vbaHresultCheckObj();
  }
  pppfStack_3bc = apppfStack_250[0];
  puStack_3c0 = (undefined *)0x4efd2f;
  puStack_3c0 = (undefined *)(*(code *)(*apppfStack_250[0])[0xd9])();
  pppfStack_3c4 = (float ***)&pppfStack_160;
  pppfStack_3c8 = (float ***)0x4efd3a;
  pppfStack_3cc = (float ***)__vbaObjSet();
  pppfStack_3c8 = (float ***)apppfStack_21c;
  pppfStack_3d0 = (float ***)0x4efd50;
  pppfStack_230 = pppfStack_3cc;
  ppppfVar6 = (float ****)(*(code *)(*pppfStack_3cc)[0x22])();
  uVar19 = 0;
  if ((int)ppppfVar6 < 0) {
    pppfStack_3d0 = (float ***)0x88;
    pppfStack_3d4 = (float ***)&DAT_0040c3dc;
    pppfStack_3d8 = pppfStack_230;
    pppfStack_3e0 = (float ***)0x4efd6a;
    pppfStack_3dc = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  iStack_2d4 = (int)DAT_0050b32e;
  fStack_2d8 = (float)iStack_2d4;
  pppfStack_3d0 = apppfStack_250[0];
  ppppfVar6 = (float ****)pppfStack_3d0;
  if ((uVar19 & 0xd) != 0) {
LAB_004f2fd3:
    pppfStack_3d0 = (float ***)ppppfVar6;
    __vbaFPException();
    return;
  }
  pppfStack_3d4 = apppfStack_250[0];
  pppfStack_3d8 = (float ***)0x4efdac;
  pppfStack_3d0 = (float ***)(fStack_2d8 + (float)apppfStack_21c[0]);
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3b])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3d8 = (float ***)0xec;
    pppfStack_3dc = (float ***)&DAT_0040b430;
    pppfStack_3e0 = apppfStack_250[0];
    pppfStack_3e8 = (float ***)0x4efdc6;
    pppfStack_3e4 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3d8 = (float ***)0x4efdcb;
  __vbaFreeObj();
  pppfStack_3d8 = apppfStack_250[0];
  pppfStack_3dc = (float ***)0x4efdda;
  pppfStack_3dc = (float ***)(*(code *)(*apppfStack_250[0])[0xdc])();
  pppfStack_3e0 = (float ***)&pppfStack_160;
  pppfStack_3e4 = (float ***)0x4efde5;
  pppfStack_3e8 = (float ***)__vbaObjSet();
  pppfStack_3e4 = (float ***)0x0;
  pppfStack_3ec = (float ***)0x4efdf6;
  pppfStack_230 = pppfStack_3e8;
  ppppfVar6 = (float ****)(*(code *)(*pppfStack_3e8)[0x23])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3ec = (float ***)0x8c;
    pppfStack_3f0 = (float ***)&DAT_0040bb6c;
    pppfStack_3f4 = pppfStack_230;
    pppfStack_3fc = (float ***)0x4efe10;
    pppfStack_3f8 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3ec = (float ***)0x4efe15;
  __vbaFreeObj();
  pppfStack_3ec = apppfStack_250[0];
  pppfStack_3f0 = (float ***)0x4efe24;
  pppfStack_3f0 = (float ***)(*(code *)(*apppfStack_250[0])[0xdd])();
  pppfStack_3f4 = (float ***)&pppfStack_160;
  pppfStack_3f8 = (float ***)0x4efe2f;
  pppfStack_3fc = (float ***)__vbaObjSet();
  pppfStack_3f8 = (float ***)0x0;
  pppfStack_400 = (float ***)0x4efe40;
  pppfStack_230 = pppfStack_3fc;
  ppppfVar6 = (float ****)(*(code *)(*pppfStack_3fc)[0x23])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_400 = (float ***)0x8c;
    uStack_408 = (double)CONCAT44(&DAT_0040bb6c,pppfStack_230);
    pppfStack_410 = (float ***)0x4efe5a;
    pppfStack_40c = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_400 = (float ***)0x4efe5f;
  __vbaFreeObj();
  pppfStack_400 = apppfStack_250[0];
  uStack_408 = (double)CONCAT44(0x4efe6e,(undefined4)uStack_408);
  uVar7 = (*(code *)(*apppfStack_250[0])[0xdb])();
  uStack_408 = (double)CONCAT44(uVar7,&pppfStack_160);
  pppfStack_40c = (float ***)0x4efe79;
  pppfStack_234 = (float ***)__vbaObjSet();
  pppfStack_40c = (float ***)apppfStack_21c;
  pppfStack_410 = apppfStack_250[0];
  pppfStack_414 = (float ***)0x4efe95;
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3a])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_414 = (float ***)0xe8;
    pppfStack_418 = (float ***)&DAT_0040b430;
    pppfStack_41c = apppfStack_250[0];
    pppfStack_424 = (float ***)0x4efeaf;
    pppfStack_420 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_414 = apppfStack_21c[0];
  pppfStack_418 = pppfStack_234;
  pppfStack_41c = (float ***)0x4efec2;
  ppppfVar6 = (float ****)(*(code *)(*pppfStack_234)[0x1f])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_41c = (float ***)0x7c;
    pppfStack_420 = (float ***)&DAT_0040c3dc;
    pppfStack_424 = pppfStack_234;
    pppfStack_42c = (float ***)0x4efed9;
    pppfStack_428 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_41c = (float ***)0x4efede;
  __vbaFreeObj();
  if (DAT_0050c53c == (float ****)0x0) {
    pppfStack_41c = (float ***)&DAT_0050c53c;
    pppfStack_420 = (float ***)&DAT_0040b420;
    pppfStack_424 = (float ***)0x4efef7;
    __vbaNew2();
  }
  ppppfVar6 = DAT_0050c53c;
  pppfStack_41c = (float ***)&pppfStack_160;
  pppfStack_420 = (float ***)DAT_0050c53c;
  pppfStack_424 = (float ***)0x4eff07;
  ppppfVar8 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)ppppfVar8 < 0) {
    pppfStack_424 = (float ***)0x18;
    pppfStack_428 = (float ***)&DAT_0040b410;
    pppfStack_42c = (float ***)ppppfVar6;
    pppfStack_434 = (float ***)0x4eff18;
    pppfStack_430 = (float ***)ppppfVar8;
    __vbaHresultCheckObj();
  }
  pppfVar11 = pppfStack_160;
  pppfStack_424 = (float ***)apppfStack_21c;
  pppfStack_428 = pppfStack_160;
  pppfStack_42c = (float ***)0x4eff2d;
  ppppfVar6 = (float ****)(*(code *)(*pppfStack_160)[0x26])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_42c = (float ***)0x98;
    pppfStack_430 = (float ***)&DAT_0040bb5c;
    pppfStack_434 = pppfVar11;
    pppfStack_43c = (float ***)0x4eff41;
    pppfStack_438 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_42c = apppfStack_250[0];
  pppfStack_430 = (float ***)0x4eff50;
  pppfStack_430 = (float ***)(*(code *)(*apppfStack_250[0])[0xdb])();
  pppfStack_434 = &ppfStack_164;
  pppfStack_438 = (float ***)0x4eff5b;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_438 = &ppfStack_220;
  pppfStack_440 = (float ***)0x4eff6d;
  pppfStack_43c = (float ***)ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x20])();
  uVar19 = 0;
  if ((int)ppppfVar8 < 0) {
    pppfStack_440 = (float ***)0x80;
    pppfStack_444 = (float ***)&DAT_0040c3dc;
    pppfStack_450 = (float ***)0x4eff81;
    pppfStack_44c = (float ***)ppppfVar8;
    pppfStack_448 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_440 = apppfStack_250[0];
  pppfStack_444 = (float ***)0x4eff90;
  pppfStack_444 = (float ***)(*(code *)(*apppfStack_250[0])[0xdb])();
  pppfStack_448 = &ppfStack_168;
  pppfStack_44c = (float ***)0x4eff9b;
  ppppfVar8 = (float ****)__vbaObjSet();
  ppppfVar6 = (float ****)pppfStack_3d0;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3d0 =
       (float ***)(((float)apppfStack_21c[0] - (float)ppfStack_220) * (float)_DAT_00401268);
  ppppfVar6 = (float ****)*ppppfVar8;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3dc = (float ***)0x4effd9;
  pppfStack_3d8 = (float ***)ppppfVar8;
  fStack_2dc = (float)pppfStack_3d0;
  pppfStack_3e8 = (float ***)(*(code *)(*ppppfVar8)[0x1d])();
  if ((int)pppfStack_3e8 < 0) {
    pppfStack_3dc = (float ***)0x74;
    pppfStack_3e0 = (float ***)&DAT_0040c3dc;
    pppfStack_3ec = (float ***)0x4effea;
    pppfStack_3e4 = (float ***)ppppfVar8;
    __vbaHresultCheckObj();
  }
  pppfStack_3dc = &ppfStack_168;
  pppfStack_3e0 = &ppfStack_164;
  pppfStack_3e4 = (float ***)&pppfStack_160;
  pppfStack_3e8 = (float ***)0x3;
  pppfStack_3ec = (float ***)0x4efffe;
  __vbaFreeObjList();
  pppfStack_3dc = apppfStack_250[0];
  pppfStack_3e0 = (float ***)0x4f0010;
  pppfStack_3e0 = (float ***)(*(code *)(*apppfStack_250[0])[0xdb])();
  pppfStack_3e4 = (float ***)&pppfStack_160;
  pppfStack_3e8 = (float ***)0x4f001b;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_3e8 = (float ***)0xffffffff;
  pppfStack_3f0 = (float ***)0x4f0028;
  pppfStack_3ec = (float ***)ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x27])();
  if ((int)ppppfVar8 < 0) {
    pppfStack_3f0 = (float ***)0x9c;
    pppfStack_3f4 = (float ***)&DAT_0040c3dc;
    pppfStack_400 = (float ***)0x4f003c;
    pppfStack_3fc = (float ***)ppppfVar8;
    pppfStack_3f8 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3f0 = (float ***)0x4f0045;
  __vbaFreeObj();
  pppfStack_3f0 = apppfStack_250[0];
  pppfStack_3f4 = (float ***)0x4f0054;
  pppfStack_3f4 = (float ***)(*(code *)(*apppfStack_250[0])[0xdb])();
  pppfStack_3f8 = (float ***)&pppfStack_160;
  pppfStack_3fc = (float ***)0x4f005f;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_3fc = &ppfStack_220;
  uStack_408 = (double)CONCAT44(0x4f0071,(undefined4)uStack_408);
  pppfStack_400 = (float ***)ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x22])();
  if ((int)ppppfVar8 < 0) {
    uStack_408 = 2.88593524605243e-312;
    pppfStack_414 = (float ***)0x4f0085;
    pppfStack_410 = (float ***)ppppfVar8;
    pppfStack_40c = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  uStack_408 = (double)CONCAT44(apppfStack_21c,apppfStack_250[0]);
  pppfStack_40c = (float ***)0x4f009b;
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3a])();
  uVar19 = 0;
  if ((int)ppppfVar6 < 0) {
    pppfStack_3d0 = (float ***)0xe8;
    pppfStack_3d4 = (float ***)&DAT_0040b430;
    pppfStack_3d8 = apppfStack_250[0];
    pppfStack_3e0 = (float ***)0x4f00b5;
    pppfStack_3dc = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3d0 = apppfStack_250[0];
  ppppfVar6 = (float ****)pppfStack_3d0;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3d4 = apppfStack_250[0];
  pppfStack_3d8 = (float ***)0x4f00de;
  pppfStack_3d0 = (float ***)((float)ppfStack_220 + (float)apppfStack_21c[0]);
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3b])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3d8 = (float ***)0xec;
    pppfStack_3dc = (float ***)&DAT_0040b430;
    pppfStack_3e0 = apppfStack_250[0];
    pppfStack_3e8 = (float ***)0x4f00f8;
    pppfStack_3e4 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3d8 = (float ***)0x4f0101;
  __vbaFreeObj();
  pppfStack_3d8 = (float ***)apppfStack_21c;
  pppfStack_3dc = apppfStack_250[0];
  pppfStack_3e0 = (float ***)0x4f0117;
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3a])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3e0 = (float ***)0xe8;
    pppfStack_3e4 = (float ***)&DAT_0040b430;
    pppfStack_3e8 = apppfStack_250[0];
    pppfStack_3f0 = (float ***)0x4f0131;
    pppfStack_3ec = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  if (DAT_0050c53c == (float ****)0x0) {
    pppfStack_3e0 = (float ***)&DAT_0050c53c;
    pppfStack_3e4 = (float ***)&DAT_0040b420;
    pppfStack_3e8 = (float ***)0x4f014a;
    __vbaNew2();
  }
  ppppfVar6 = DAT_0050c53c;
  pppfStack_3e0 = (float ***)&pppfStack_160;
  pppfStack_3e4 = (float ***)DAT_0050c53c;
  pppfStack_3e8 = (float ***)0x4f015a;
  ppppfVar8 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)ppppfVar8 < 0) {
    pppfStack_3e8 = (float ***)0x18;
    pppfStack_3ec = (float ***)&DAT_0040b410;
    pppfStack_3f0 = (float ***)ppppfVar6;
    pppfStack_3f8 = (float ***)0x4f016b;
    pppfStack_3f4 = (float ***)ppppfVar8;
    __vbaHresultCheckObj();
  }
  pppfVar11 = pppfStack_160;
  pppfStack_3e8 = &ppfStack_220;
  pppfStack_3ec = pppfStack_160;
  pppfStack_3f0 = (float ***)0x4f0180;
  ppppfVar6 = (float ****)(*(code *)(*pppfStack_160)[0x26])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3f0 = (float ***)0x98;
    pppfStack_3f4 = (float ***)&DAT_0040bb5c;
    pppfStack_3f8 = pppfVar11;
    pppfStack_400 = (float ***)0x4f0194;
    pppfStack_3fc = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3f0 = (float ***)&pppfStack_224;
  pppfStack_3f4 = apppfStack_250[0];
  pppfStack_3f8 = (float ***)0x4f01aa;
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3a])();
  uVar19 = 0;
  if ((int)ppppfVar6 < 0) {
    pppfStack_3c8 = (float ***)0xe8;
    pppfStack_3cc = (float ***)&DAT_0040b430;
    pppfStack_3d0 = apppfStack_250[0];
    pppfStack_3d8 = (float ***)0x4f01c4;
    pppfStack_3d4 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float ****)0x0) {
    pppfStack_3c8 = (float ***)&DAT_0050b420;
    pppfStack_3cc = (float ***)&DAT_00408c88;
    pppfStack_3d0 = (float ***)0x4f01dd;
    __vbaNew2();
  }
  ppppfVar8 = DAT_0050b420;
  pppfStack_3d0 = (float ***)((float)ppfStack_220 - _DAT_004020e0);
  pppfStack_3c8 = (float ***)0x0;
  pppfStack_3cc = pppfStack_224;
  ppppfVar6 = (float ****)*DAT_0050b420;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3d4 = apppfStack_21c[0];
  pppfStack_3d8 = (float ***)0x44960000;
  pppfStack_3dc = (float ***)0x4;
  pppfStack_3e0 = (float ***)DAT_0050b420;
  pppfStack_3e4 = (float ***)0x4f021d;
  ppppfVar6 = (float ****)(*(code *)(*DAT_0050b420)[0xb2])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3e4 = (float ***)0x2c8;
    pppfStack_3e8 = (float ***)&DAT_0040b430;
    pppfStack_3ec = (float ***)ppppfVar8;
    pppfStack_3f4 = (float ***)0x4f0231;
    pppfStack_3f0 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3e4 = (float ***)0x4f023a;
  __vbaFreeObj();
  pppfStack_3e4 = (float ***)0x44960000;
  pppfStack_3e8 = apppfStack_250[0];
  pppfStack_3ec = (float ***)0x4f024e;
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x39])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3ec = (float ***)0xe4;
    pppfStack_3f0 = (float ***)&DAT_0040b430;
    pppfStack_3f4 = apppfStack_250[0];
    pppfStack_3fc = (float ***)0x4f0268;
    pppfStack_3f8 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float ****)0x0) {
    pppfStack_3ec = (float ***)&DAT_0050b420;
    pppfStack_3f0 = (float ***)&DAT_00408c88;
    pppfStack_3f4 = (float ***)0x4f0281;
    __vbaNew2();
  }
  pppfStack_3ec = (float ***)0x40f6d0;
  pppfStack_3f0 = *(float ****)(DAT_0050b37c + 4);
  pppfStack_3f4 = (float ***)0x4f0295;
  __vbaStrCat();
  pppfStack_3f4 = (float ***)0x4f02a0;
  pppfStack_3f4 = (float ***)__vbaStrMove();
  pppfStack_3f8 = (float ***)DAT_0050b420;
  pppfStack_3fc = (float ***)&DAT_0040bf08;
  pppfStack_400 = (float ***)0x4f02b3;
  __vbaPrintObj();
  pppfStack_3f4 = (float ***)0x4f02bf;
  __vbaFreeStr();
  if ((DAT_0050b338 == 1) || (DAT_0050b338 == 2)) {
    pppfStack_3f4 = (float ***)0x4f02e3;
    __vbaStrCopy();
  }
  pppfStack_3f4 = apppfStack_250[0];
  pppfStack_3f8 = (float ***)0x4f02f2;
  pppfStack_3f8 = (float ***)(*(code *)(*apppfStack_250[0])[0xdc])();
  pppfStack_3fc = (float ***)&pppfStack_160;
  pppfStack_400 = (float ***)0x4f02fd;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_400 = (float ***)0x0;
  uStack_408._0_4_ = 0x4f030a;
  uStack_408._4_4_ = ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x23])();
  if ((int)ppppfVar8 < 0) {
    uStack_408._0_4_ = 0x8c;
    pppfStack_40c = (float ***)&DAT_0040bb6c;
    pppfStack_418 = (float ***)0x4f031e;
    pppfStack_414 = (float ***)ppppfVar8;
    pppfStack_410 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  uStack_408._0_4_ = 0x4f0327;
  __vbaFreeObj();
  uStack_408 = (double)CONCAT44(uStack_408._4_4_,apppfStack_250[0]);
  pppfStack_40c = (float ***)0x4f0336;
  pppfStack_40c = (float ***)(*(code *)(*apppfStack_250[0])[0xdd])();
  pppfStack_410 = (float ***)&pppfStack_160;
  pppfStack_414 = (float ***)0x4f0341;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_414 = (float ***)0x0;
  pppfStack_41c = (float ***)0x4f034e;
  pppfStack_418 = (float ***)ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x23])();
  if ((int)ppppfVar8 < 0) {
    pppfStack_41c = (float ***)0x8c;
    pppfStack_420 = (float ***)&DAT_0040bb6c;
    pppfStack_42c = (float ***)0x4f0362;
    pppfStack_428 = (float ***)ppppfVar8;
    pppfStack_424 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_41c = (float ***)0x4f036b;
  __vbaFreeObj();
  pppfStack_41c = apppfStack_250[0];
  pppfStack_420 = (float ***)0x4f037a;
  pppfStack_420 = (float ***)(*(code *)(*apppfStack_250[0])[0xe8])();
  pppfStack_424 = (float ***)&pppfStack_160;
  pppfStack_428 = (float ***)0x4f0385;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_428 = (float ***)DAT_0050b34c;
  pppfStack_430 = (float ***)0x4f0394;
  pppfStack_42c = (float ***)ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x15])();
  if ((int)ppppfVar8 < 0) {
    pppfStack_430 = (float ***)0x54;
    pppfStack_434 = (float ***)&DAT_0040ba5c;
    pppfStack_440 = (float ***)0x4f03a5;
    pppfStack_43c = (float ***)ppppfVar8;
    pppfStack_438 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_430 = (float ***)0x4f03ae;
  __vbaFreeObj();
  pppfStack_430 = (float ***)apppfStack_21c;
  pppfStack_434 = apppfStack_250[0];
  pppfStack_438 = (float ***)0x4f03c4;
  pppfVar11 = (float ***)(*(code *)(*apppfStack_250[0])[0x3a])();
  if ((int)pppfVar11 < 0) {
    pppfStack_438 = (float ***)0xe8;
    pppfStack_43c = (float ***)&DAT_0040b430;
    pppfStack_440 = apppfStack_250[0];
    pppfStack_448 = (float ***)0x4f03de;
    pppfStack_444 = pppfVar11;
    __vbaHresultCheckObj();
  }
  pppfStack_438 = (float ***)0x4f03ea;
  pppfStack_12c = (float ***)__vbaFpI2();
  pppfStack_438 = apppfStack_250[0];
  pppfStack_43c = (float ***)0x4f03fc;
  pppfStack_43c = (float ***)(*(code *)(*apppfStack_250[0])[0xe8])();
  pppfStack_440 = (float ***)&pppfStack_160;
  pppfStack_444 = (float ***)0x4f0407;
  ppppfVar6 = (float ****)__vbaObjSet();
  iStack_2e0 = (int)(short)pppfStack_12c;
  pppfStack_444 = (float ***)(float)iStack_2e0;
  pppfStack_44c = (float ***)0x4f042c;
  pppfStack_448 = (float ***)ppppfVar6;
  ppfStack_2e4 = (float **)pppfStack_444;
  iVar5 = (*(code *)(*ppppfVar6)[0x1f])();
  if (iVar5 < 0) {
    pppfStack_44c = (float ***)0x7c;
    pppfStack_450 = (float ***)&DAT_0040ba5c;
    uStack_458 = (double)CONCAT44(ppppfVar6,iVar5);
    pppfStack_45c = (float ***)0x4f043d;
    __vbaHresultCheckObj();
  }
  pppfStack_44c = (float ***)0x4f0446;
  __vbaFreeObj();
  if (DAT_0050c53c == (float ****)0x0) {
    pppfStack_44c = (float ***)&DAT_0050c53c;
    pppfStack_450 = (float ***)&DAT_0040b420;
    uStack_458 = (double)CONCAT44(0x4f045f,(undefined4)uStack_458);
    __vbaNew2();
  }
  ppppfVar6 = DAT_0050c53c;
  pppfStack_44c = (float ***)&pppfStack_160;
  pppfStack_450 = (float ***)DAT_0050c53c;
  uStack_458 = (double)CONCAT44(0x4f046f,(undefined4)uStack_458);
  iVar5 = (*(code *)(*DAT_0050c53c)[6])();
  if (iVar5 < 0) {
    uStack_458 = 5.09299940191312e-313;
    pppfStack_45c = (float ***)ppppfVar6;
    uStack_464 = (double)CONCAT44(iVar5,0x4f0480);
    __vbaHresultCheckObj();
  }
  pppfVar11 = pppfStack_160;
  uStack_458 = (double)CONCAT44(apppfStack_21c,pppfStack_160);
  pppfStack_45c = (float ***)0x4f0495;
  pppfStack_468 = (float ***)(*(code *)(*pppfStack_160)[0x26])();
  if ((int)pppfStack_468 < 0) {
    pppfStack_45c = (float ***)0x98;
    uStack_464 = (double)CONCAT44(&DAT_0040bb5c,pppfVar11);
    uStack_470 = (double)CONCAT44(0x4f04a9,(undefined4)uStack_470);
    __vbaHresultCheckObj();
  }
  pppfStack_45c = &ppfStack_220;
  uStack_464 = (double)CONCAT44(DAT_0050b34c,apppfStack_250[0]);
  pppfStack_468 = (float ***)0x4f04c6;
  iVar5 = (*(code *)(*apppfStack_250[0])[0xb9])();
  uVar19 = 0;
  if (iVar5 < 0) {
    pppfStack_468 = (float ***)0x2e4;
    uStack_470 = (double)CONCAT44(&DAT_0040b430,apppfStack_250[0]);
    uStack_47c = (double)CONCAT44(0x4f04e0,(undefined4)uStack_47c);
    iStack_474 = iVar5;
    __vbaHresultCheckObj();
  }
  pppfStack_468 = apppfStack_250[0];
  uStack_470 = (double)CONCAT44(0x4f04ef,(undefined4)uStack_470);
  uVar7 = (*(code *)(*apppfStack_250[0])[0xe8])();
  uStack_470 = (double)CONCAT44(uVar7,&ppfStack_164);
  iStack_474 = 0x4f04fa;
  ppppfVar8 = (float ****)__vbaObjSet();
  ppppfVar6 = (float ****)pppfStack_3d0;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3d0 =
       (float ***)(((float)apppfStack_21c[0] - (float)ppfStack_220) * (float)_DAT_00401268);
  ppppfVar6 = (float ****)*ppppfVar8;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3dc = (float ***)0x4f0538;
  pppfStack_3d8 = (float ***)ppppfVar8;
  fStack_2e8 = (float)pppfStack_3d0;
  pppfStack_3e8 = (float ***)(*(code *)(*ppppfVar8)[0x1d])();
  if ((int)pppfStack_3e8 < 0) {
    pppfStack_3dc = (float ***)0x74;
    pppfStack_3e0 = (float ***)&DAT_0040ba5c;
    pppfStack_3ec = (float ***)0x4f0549;
    pppfStack_3e4 = (float ***)ppppfVar8;
    __vbaHresultCheckObj();
  }
  pppfStack_3dc = &ppfStack_164;
  pppfStack_3e0 = (float ***)&pppfStack_160;
  pppfStack_3e4 = (float ***)0x2;
  pppfStack_3e8 = (float ***)0x4f0559;
  __vbaFreeObjList();
  pppfStack_3dc = apppfStack_250[0];
  pppfStack_3e0 = (float ***)0x4f056b;
  pppfStack_3e0 = (float ***)(*(code *)(*apppfStack_250[0])[0xe8])();
  pppfStack_3e4 = (float ***)&pppfStack_160;
  pppfStack_3e8 = (float ***)0x4f0576;
  ppppfVar6 = (float ****)__vbaObjSet();
  pppfStack_3e8 = (float ***)apppfStack_21c;
  pppfStack_3f0 = (float ***)0x4f0588;
  pppfStack_3ec = (float ***)ppppfVar6;
  ppppfVar8 = (float ****)(*(code *)(*ppppfVar6)[0x22])();
  uVar19 = 0;
  if ((int)ppppfVar8 < 0) {
    pppfStack_3d0 = (float ***)0x88;
    pppfStack_3d4 = (float ***)&DAT_0040ba5c;
    pppfStack_3e0 = (float ***)0x4f059c;
    pppfStack_3dc = (float ***)ppppfVar8;
    pppfStack_3d8 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  fStack_2ec = (float)iStack_2e0;
  pppfStack_3d0 = apppfStack_250[0];
  ppppfVar6 = (float ****)pppfStack_3d0;
  if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
  pppfStack_3d4 = apppfStack_250[0];
  pppfStack_3d8 = (float ***)0x4f05d1;
  pppfStack_3d0 = (float ***)(fStack_2ec + (float)apppfStack_21c[0]);
  ppppfVar6 = (float ****)(*(code *)(*apppfStack_250[0])[0x3b])();
  if ((int)ppppfVar6 < 0) {
    pppfStack_3d8 = (float ***)0xec;
    pppfStack_3dc = (float ***)&DAT_0040b430;
    pppfStack_3e0 = apppfStack_250[0];
    pppfStack_3e8 = (float ***)0x4f05eb;
    pppfStack_3e4 = (float ***)ppppfVar6;
    __vbaHresultCheckObj();
  }
  pppfStack_3d8 = (float ***)0x4f05f4;
  __vbaFreeObj();
  pppfStack_3dc = (float ***)apppfStack_250;
  pppfStack_3d8 = (float ***)0x0;
  pppfStack_3e0 = (float ***)0x4f0603;
  __vbaObjSetAddref();
  if (DAT_0050b420 == (float ****)0x0) {
    pppfStack_3e0 = (float ***)&DAT_0050b420;
    pppfStack_3e4 = (float ***)&DAT_00408c88;
    pppfStack_3e8 = (float ***)0x4f061c;
    __vbaNew2();
  }
  pppfStack_3e0 = (float ***)DAT_0050b420;
  pppfStack_3e4 = (float ***)0x4f062a;
  pppfStack_3e4 = (float ***)(*(code *)(*DAT_0050b420)[0xea])();
  pppfStack_3e8 = (float ***)&pppfStack_254;
  pppfStack_3ec = (float ***)0x4f063a;
  __vbaObjSet();
  pppfStack_1b8 = (float ***)0x3;
  pppfStack_1b0 = (float ***)0x3;
  pppfStack_3f8 = (float ***)0x3;
  pppfStack_3fc = (float ***)0x1a;
  pppfStack_3f4 = pppfStack_1b4;
  pppfStack_400 = pppfStack_254;
  pppfStack_3f0 = (float ***)0x3;
  pppfStack_3ec = pppfStack_1ac;
  uStack_408 = (double)CONCAT44(0x4f0674,(undefined4)uStack_408);
  __vbaLateIdSt();
  pppfStack_1b8 = (float ***)0x3;
  pppfStack_414 = (float ***)0xfffffe0b;
  pppfStack_410 = (float ***)0x3;
  pppfStack_1b0 = (float ***)0xff0000;
  pppfStack_40c = pppfStack_1b4;
  pppfStack_418 = pppfStack_254;
  uStack_408 = (double)CONCAT44(pppfStack_1ac,0xff0000);
  pppfStack_41c = (float ***)0x4f06b4;
  __vbaLateIdSt();
  pppfStack_1b8 = (float ***)0x3;
  pppfStack_42c = (float ***)0xfffffdff;
  pppfStack_428 = (float ***)0x3;
  pppfStack_1b0 = (float ***)0xffffff;
  pppfStack_424 = pppfStack_1b4;
  pppfStack_430 = pppfStack_254;
  pppfStack_420 = (float ***)0xffffff;
  pppfStack_41c = pppfStack_1ac;
  pppfStack_434 = (float ***)0x4f06f4;
  __vbaLateIdSt();
  ppppfVar8 = (float ****)__vbaLateIdCallLd_exref;
  pppfStack_1b8 = (float ***)0x8;
  pppfStack_440 = (float ***)0x8;
  pppfStack_1b0 = (float ***)0x40c3f0;
  pppfStack_444 = (float ***)0x0;
  pppfStack_43c = pppfStack_1b4;
  pppfStack_448 = (float ***)&DAT_0040eb6c;
  pppfStack_44c = (float ***)0x0;
  pppfStack_438 = (float ***)0x40c3f0;
  pppfStack_450 = (float ***)0xfffffe00;
  pppfStack_434 = pppfStack_1ac;
  uStack_458 = (double)CONCAT44(pppfStack_254,&ppfStack_178);
  pppfStack_45c = (float ***)0x4f0747;
  pppfStack_44c = (float ***)__vbaLateIdCallLd();
  pppfStack_450 = (float ***)0x4f0751;
  pppfStack_450 = (float ***)__vbaCastObjVar();
  uStack_458._4_4_ = &pppfStack_160;
  uStack_458._0_4_ = 0x4f0758;
  uVar7 = __vbaObjSet();
  uStack_458 = (double)CONCAT44(uStack_458._4_4_,uVar7);
  pppfStack_45c = (float ***)0x4f075b;
  __vbaLateIdSt();
  pppfStack_45c = (float ***)0x4f0764;
  __vbaFreeObj();
  pcVar18 = __vbaFreeVar_exref;
  pppfStack_45c = (float ***)0x4f076f;
  __vbaFreeVar();
  pppfStack_1b8 = (float ***)0x2;
  pppfStack_468 = (float ***)0x2;
  pppfStack_1b0 = (float ***)0x9;
  uStack_470 = 4.2460936197935e-314;
  iStack_474 = 0;
  uStack_464 = (double)CONCAT44(9,pppfStack_1b4);
  uStack_47c = (double)CONCAT44(0xfffffe00,pppfStack_254);
  pppfStack_45c = pppfStack_1ac;
  pppfStack_480 = &ppfStack_178;
  pppfStack_484 = (float ***)0x4f07bc;
  iStack_474 = __vbaLateIdCallLd();
  uStack_47c = (double)CONCAT44(0x4f07c6,(undefined4)uStack_47c);
  uVar7 = __vbaCastObjVar();
  uStack_47c = (double)CONCAT44(uVar7,&pppfStack_160);
  pppfStack_480 = (float ***)0x4f07d1;
  pppfStack_480 = (float ***)__vbaObjSet();
  pppfStack_484 = (float ***)0x4f07d4;
  __vbaLateIdSt();
  pppfStack_484 = (float ***)0x4f07dd;
  __vbaFreeObj();
  pppfStack_484 = (float ***)0x4f07e2;
  __vbaFreeVar();
  pppfStack_1b8 = (float ***)0xb;
  pppfStack_1b0 = (float ***)0xffffffff;
  pcStack_488 = (code *)0xffffffff;
  pppfStack_484 = pppfStack_1ac;
  uVar7 = __vbaLateIdCallLd(&ppfStack_178,pppfStack_254,0xfffffe00,0,&DAT_0040eb6c,3,0xb,
                            pppfStack_1b4);
  uVar7 = __vbaCastObjVar(uVar7);
  uVar7 = __vbaObjSet(&pppfStack_160,uVar7);
  __vbaLateIdSt(uVar7);
  __vbaFreeObj();
  __vbaFreeVar();
  if (DAT_0050b420 == (float ****)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  pppfStack_230 = (float ***)DAT_0050b420;
  iVar5 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,apppfStack_21c);
  uVar19 = 0;
  if (iVar5 < 0) {
    __vbaHresultCheckObj(iVar5,pppfStack_230,&DAT_0040b430,0xe8);
  }
  pppfStack_1b8 = (float ***)0x4;
  pppfStack_1b0 = apppfStack_21c[0];
  __vbaLateIdSt(pppfStack_254,0x80010004,4,pppfStack_1b4,apppfStack_21c[0],pppfStack_1ac);
  if (DAT_0050b338 == 1) {
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3e4 = (float ***)0x5;
    pppfStack_3e0 = (float ***)0x3;
    pppfStack_1b0 = (float ***)0x4;
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3e8 = pppfStack_254;
    pppfStack_3d8 = (float ***)0x4;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3ec = (float ***)0x4f1d8f;
    __vbaLateIdSt();
    pppfStack_1b8 = (float ***)0x3;
    if (!SCARRY2((short)DAT_0050b3c4,3)) {
      pppfStack_3d8 = (float ***)(int)(short)((short)DAT_0050b3c4 + 3);
      pppfStack_3e4 = (float ***)0x4;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f1ddb;
      pppfStack_1b0 = pppfStack_3d8;
      __vbaLateIdSt();
      pppfStack_3ec = (float ***)0x0;
      pppfStack_3f0 = (float ***)0x4;
      pppfStack_3f8 = &ppfStack_178;
      pppfStack_3f4 = pppfStack_254;
      pppfStack_3fc = (float ***)0x4f1dec;
      pppfStack_3ec = (float ***)__vbaLateIdCallLd();
      pppfStack_3f0 = (float ***)0x4f1df6;
      iVar5 = __vbaI4Var();
      if (!SBORROW4(iVar5,1)) {
        pppfStack_3d4 = (float ***)0x4f1e07;
        uStack_264 = __vbaI2I4();
        ppfStack_120 = (float **)0x0;
        pppfStack_3d4 = (float ***)0x4f1e19;
        __vbaFreeVar();
        pcVar18 = __vbaLateIdCallSt_exref;
        pppfVar11 = (float ***)ppfStack_120;
        do {
          ppfStack_120 = (float **)pppfVar11;
          if ((short)uStack_264 < (short)ppfStack_120) {
            pppfStack_1b8 = (float ***)0x3;
            pppfStack_3e4 = (float ***)0x22;
            pppfStack_3e0 = (float ***)0x3;
            pppfStack_1b0 = (float ***)0x0;
            pppfStack_3dc = pppfStack_1b4;
            pppfStack_3e8 = pppfStack_254;
            pppfStack_3d8 = (float ***)0x0;
            pppfStack_3d4 = pppfStack_1ac;
            pppfStack_3ec = (float ***)0x4f1f41;
            __vbaLateIdSt();
            pppfStack_1b8 = (float ***)0x3;
            pppfStack_3fc = (float ***)0x1a;
            pppfStack_3f8 = (float ***)0x3;
            pppfStack_1b0 = (float ***)0x2;
            pppfStack_3f4 = pppfStack_1b4;
            pppfStack_400 = pppfStack_254;
            pppfStack_3f0 = (float ***)0x2;
            pppfStack_3ec = pppfStack_1ac;
            uStack_408 = (double)CONCAT44(0x4f1f7e,(undefined4)uStack_408);
            __vbaLateIdSt();
            if (DAT_0050c53c == (float ****)0x0) {
              uStack_408 = 3.731548275327462e-307;
              pppfStack_40c = (float ***)0x4f1f97;
              __vbaNew2();
            }
            uStack_408 = (double)CONCAT44(&pppfStack_160,DAT_0050c53c);
            pppfStack_230 = (float ***)DAT_0050c53c;
            pppfStack_40c = (float ***)0x4f1fac;
            ppppfVar6 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)ppppfVar6 < 0) {
              pppfStack_40c = (float ***)0x18;
              pppfStack_410 = (float ***)&DAT_0040b410;
              pppfStack_414 = pppfStack_230;
              pppfStack_41c = (float ***)0x4f1fc7;
              pppfStack_418 = (float ***)ppppfVar6;
              __vbaHresultCheckObj();
            }
            pppfStack_40c = (float ***)apppfStack_21c;
            pppfStack_410 = pppfStack_160;
            pppfStack_238 = pppfStack_160;
            pppfStack_414 = (float ***)0x4f1fe0;
            ppppfVar6 = (float ****)(*(code *)(*pppfStack_160)[0x26])();
            uVar19 = 0;
            if ((int)ppppfVar6 < 0) {
              pppfStack_3d4 = (float ***)0x98;
              pppfStack_3d8 = (float ***)&DAT_0040bb5c;
              pppfStack_3dc = pppfStack_238;
              pppfStack_3e4 = (float ***)0x4f1ffe;
              pppfStack_3e0 = (float ***)ppppfVar6;
              __vbaHresultCheckObj();
            }
            pppfStack_1b0 = (float ***)((float)apppfStack_21c[0] * (float)_DAT_00401370);
            ppppfVar6 = (float ****)pppfStack_3d0;
            if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
            pppfStack_1b8 = (float ***)0x4;
            pppfStack_3e4 = (float ***)0x80010005;
            pppfStack_3e0 = (float ***)0x4;
            pppfStack_3dc = pppfStack_1b4;
            pppfStack_3e8 = pppfStack_254;
            pppfStack_3d4 = pppfStack_1ac;
            pppfStack_3ec = (float ***)0x4f2055;
            pppfStack_3d8 = pppfStack_1b0;
            __vbaLateIdSt();
            pppfStack_3ec = (float ***)0x4f205e;
            __vbaFreeObj();
            ppfStack_120 = (float **)0x0;
            pppfVar11 = (float ***)ppfStack_120;
            goto LAB_004f2065;
          }
          ppppfVar6 = (float ****)&DAT_00000001;
          while( true ) {
            sVar4 = (short)ppppfVar6;
            if (3 < sVar4) break;
            pppfStack_3d8 = (float ***)(int)(short)ppfStack_120;
            pppfStack_1b8 = (float ***)0x3;
            pppfStack_1d8 = (float ***)0x3;
            pppfStack_3e0 = (float ***)0x3;
            pppfStack_3dc = pppfStack_1b4;
            pppfStack_3d4 = pppfStack_1ac;
            pppfStack_3f0 = (float ***)0x3;
            pppfStack_3ec = pppfStack_1d4;
            pppfStack_3e8 = (float ***)(int)sVar4;
            pppfStack_3e4 = pppfStack_1cc;
            uStack_408 = 4.24399161404481e-314;
            pppfStack_400 = (float ***)0x8;
            pppfStack_3fc = pppfStack_1f4;
            pppfStack_3f8 = (float ***)&DAT_0040ca6c;
            pppfStack_3f4 = pppfStack_1ec;
            pppfStack_40c = pppfStack_254;
            pppfStack_410 = (float ***)0x4f1ed2;
            pppfStack_1b0 = pppfStack_3d8;
            __vbaLateIdCallSt();
            ppppfVar8 = ppppfVar6;
            ppppfVar6 = (float ****)(uint)(ushort)(sVar4 + 1);
            if (SCARRY2(sVar4,1)) goto LAB_004f2fd8;
          }
          ppppfVar8 = (float ****)__vbaLateIdCallLd_exref;
          pppfVar11 = (float ***)(uint)(ushort)((short)ppfStack_120 + 1);
        } while (!SCARRY2((short)ppfStack_120,1));
      }
    }
  }
  else {
    if (DAT_0050b338 != 2) {
LAB_004f2f35:
      pppfStack_3d8 = (float ***)&pppfStack_254;
      pppfStack_3d4 = (float ***)0x0;
      pppfStack_3dc = (float ***)0x4f2f44;
      __vbaObjSetAddref();
      pppfStack_3dc = (float ***)&LAB_004f2fc2;
      pppfStack_3e0 = (float ***)&pppfStack_254;
      pppfStack_3e4 = (float ***)apppfStack_250;
      pppfStack_3e8 = (float ***)0x2;
      pppfStack_3ec = (float ***)0x4f2fbe;
      __vbaFreeObjList();
      return;
    }
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3e4 = (float ***)0x5;
    pppfStack_3e0 = (float ***)0x3;
    pppfStack_1b0 = (float ***)0x4;
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3e8 = pppfStack_254;
    pppfStack_3d8 = (float ***)0x4;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3ec = (float ***)0x4f0938;
    __vbaLateIdSt();
    pppfStack_1b8 = (float ***)0x3;
    if (!SCARRY2(DAT_0050b332,2)) {
      pppfStack_3d8 = (float ***)(int)(short)(DAT_0050b332 + 2);
      pppfStack_3e4 = (float ***)0x4;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f0984;
      pppfStack_1b0 = pppfStack_3d8;
      __vbaLateIdSt();
      pppfStack_3ec = (float ***)0x0;
      pppfStack_3f0 = (float ***)0x4;
      pppfStack_3f8 = &ppfStack_178;
      pppfStack_3f4 = pppfStack_254;
      pppfStack_3fc = (float ***)0x4f0995;
      pppfStack_3ec = (float ***)__vbaLateIdCallLd();
      pppfStack_3f0 = (float ***)0x4f099f;
      iVar5 = __vbaI4Var();
      if (!SBORROW4(iVar5,1)) {
        pppfStack_3d4 = (float ***)0x4f09b0;
        uStack_28c = __vbaI2I4();
        ppfStack_120 = (float **)0x0;
        pppfStack_3d4 = (float ***)0x4f09c2;
        __vbaFreeVar();
        pcVar18 = __vbaLateIdCallSt_exref;
        pppfVar11 = (float ***)ppfStack_120;
        do {
          ppfStack_120 = (float **)pppfVar11;
          if ((short)uStack_28c < (short)ppfStack_120) {
            pppfStack_1b8 = (float ***)0x3;
            pppfStack_3e4 = (float ***)0x22;
            pppfStack_3e0 = (float ***)0x3;
            pppfStack_1b0 = (float ***)0x0;
            pppfStack_3dc = pppfStack_1b4;
            pppfStack_3e8 = pppfStack_254;
            pppfStack_3d8 = (float ***)0x0;
            pppfStack_3d4 = pppfStack_1ac;
            pppfStack_3ec = (float ***)0x4f0ae7;
            __vbaLateIdSt();
            pppfStack_1b8 = (float ***)0x3;
            pppfStack_3fc = (float ***)0x1a;
            pppfStack_3f8 = (float ***)0x3;
            pppfStack_1b0 = (float ***)0x2;
            pppfStack_3f4 = pppfStack_1b4;
            pppfStack_400 = pppfStack_254;
            pppfStack_3f0 = (float ***)0x2;
            pppfStack_3ec = pppfStack_1ac;
            uStack_408 = (double)CONCAT44(0x4f0b24,(undefined4)uStack_408);
            __vbaLateIdSt();
            if (DAT_0050c53c == (float ****)0x0) {
              uStack_408 = 3.731548275327462e-307;
              pppfStack_40c = (float ***)0x4f0b3d;
              __vbaNew2();
            }
            uStack_408 = (double)CONCAT44(&pppfStack_160,DAT_0050c53c);
            pppfStack_230 = (float ***)DAT_0050c53c;
            pppfStack_40c = (float ***)0x4f0b52;
            ppppfVar6 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)ppppfVar6 < 0) {
              pppfStack_40c = (float ***)0x18;
              pppfStack_410 = (float ***)&DAT_0040b410;
              pppfStack_414 = pppfStack_230;
              pppfStack_41c = (float ***)0x4f0b6d;
              pppfStack_418 = (float ***)ppppfVar6;
              __vbaHresultCheckObj();
            }
            pppfStack_40c = (float ***)apppfStack_21c;
            pppfStack_410 = pppfStack_160;
            pppfStack_238 = pppfStack_160;
            pppfStack_414 = (float ***)0x4f0b86;
            ppppfVar6 = (float ****)(*(code *)(*pppfStack_160)[0x26])();
            uVar19 = 0;
            if ((int)ppppfVar6 < 0) {
              pppfStack_3d4 = (float ***)0x98;
              pppfStack_3d8 = (float ***)&DAT_0040bb5c;
              pppfStack_3dc = pppfStack_238;
              pppfStack_3e4 = (float ***)0x4f0ba4;
              pppfStack_3e0 = (float ***)ppppfVar6;
              __vbaHresultCheckObj();
            }
            pppfStack_1b0 = (float ***)((float)apppfStack_21c[0] * (float)_DAT_00401730);
            ppppfVar6 = (float ****)pppfStack_3d0;
            if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
            pppfStack_1b8 = (float ***)0x4;
            pppfStack_3e4 = (float ***)0x80010005;
            pppfStack_3e0 = (float ***)0x4;
            pppfStack_3dc = pppfStack_1b4;
            pppfStack_3e8 = pppfStack_254;
            pppfStack_3d4 = pppfStack_1ac;
            pppfStack_3ec = (float ***)0x4f0bfb;
            pppfStack_3d8 = pppfStack_1b0;
            __vbaLateIdSt();
            pppfStack_3ec = (float ***)0x4f0c04;
            __vbaFreeObj();
            ppfStack_120 = (float **)0x0;
            pppfVar11 = (float ***)ppfStack_120;
            goto LAB_004f0c0b;
          }
          ppppfVar6 = (float ****)0x0;
          while( true ) {
            sVar4 = (short)ppppfVar6;
            if (3 < sVar4) break;
            pppfStack_3d8 = (float ***)(int)(short)ppfStack_120;
            pppfStack_1b8 = (float ***)0x3;
            pppfStack_1d8 = (float ***)0x3;
            pppfStack_3e0 = (float ***)0x3;
            pppfStack_3dc = pppfStack_1b4;
            pppfStack_3d4 = pppfStack_1ac;
            pppfStack_3f0 = (float ***)0x3;
            pppfStack_3ec = pppfStack_1d4;
            pppfStack_3e8 = (float ***)(int)sVar4;
            pppfStack_3e4 = pppfStack_1cc;
            uStack_408 = 4.24399161404481e-314;
            pppfStack_400 = (float ***)0x8;
            pppfStack_3fc = pppfStack_1f4;
            pppfStack_3f8 = (float ***)&DAT_0040ca6c;
            pppfStack_3f4 = pppfStack_1ec;
            pppfStack_40c = pppfStack_254;
            pppfStack_410 = (float ***)0x4f0a78;
            pppfStack_1b0 = pppfStack_3d8;
            __vbaLateIdCallSt();
            ppppfVar8 = ppppfVar6;
            ppppfVar6 = (float ****)(uint)(ushort)(sVar4 + 1);
            if (SCARRY2(sVar4,1)) goto LAB_004f2fd8;
          }
          ppppfVar8 = (float ****)__vbaLateIdCallLd_exref;
          pppfVar11 = (float ***)(uint)(ushort)((short)ppfStack_120 + 1);
        } while (!SCARRY2((short)ppfStack_120,1));
      }
    }
  }
  goto LAB_004f2fd8;
LAB_004eefe5:
  if (DAT_0050b420 == (float ****)0x0) {
    pppfStack_10c = (float ***)&DAT_0050b420;
    pwStack_110 = L"\x01\aꙴ@";
    puStack_114 = (undefined4 *)0x4eeffe;
    __vbaNew2();
  }
  pppfStack_10c = (float ***)DAT_0050b420;
  pwStack_110 = L"閍Ｔ\xffff剐ᗿ႐@ꅦ댲Pඋ돌Pƾ";
  pwStack_110 = (wchar_t *)(*(code *)(*DAT_0050b420)[0xea])();
  puStack_114 = &local_d0;
  puStack_118 = (undefined4 *)0x4ef01a;
  __vbaObjSet();
  sVar4 = DAT_0050b332;
  local_1c = (float **)0x1;
  ppppfVar16 = DAT_0050b3cc;
  pppfVar15 = (float ***)local_1c;
  while( true ) {
    local_1c = (float **)pppfVar15;
    unaff_ESI = (float ***)local_1c;
    pppfVar11 = (float ***)0x0;
    sVar13 = (short)local_1c;
    if (sVar4 < sVar13) break;
    if ((ppppfVar16 == (float ****)0x0) || (*(short *)ppppfVar16 != 2)) {
      pppfStack_10c = (float ***)0x4ef086;
      iVar5 = __vbaGenerateBoundsError();
      ppppfVar16 = DAT_0050b3cc;
    }
    else {
      pppfVar11 = (float ***)-(int)ppppfVar16[7];
      if (ppppfVar16[6] <= pppfVar11) {
        pppfStack_10c = (float ***)0x4ef05a;
        __vbaGenerateBoundsError();
        ppppfVar16 = DAT_0050b3cc;
      }
      unaff_ESI = (float ***)((int)sVar13 - (int)ppppfVar16[5]);
      if (ppppfVar16[4] <= unaff_ESI) {
        pppfStack_10c = (float ***)0x4ef071;
        __vbaGenerateBoundsError();
        ppppfVar16 = DAT_0050b3cc;
      }
      iVar5 = (int)((int)ppppfVar16[6] * (int)unaff_ESI + (int)pppfVar11) * 4;
    }
    sVar13 = DAT_0050b332;
    if (*(float *)((int)ppppfVar16[3] + iVar5) != _DAT_00402558) {
      local_2c = -(float)_DAT_0050b134;
      local_18 = 1;
      uVar12 = local_18;
      while (local_18 = uVar12, (short)local_18 <= sVar13) {
        if ((DAT_0050b3d4 == (float ****)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
          pppfStack_10c = (float ***)0x4ef10c;
          iVar5 = __vbaGenerateBoundsError();
          ppppfVar16 = DAT_0050b3cc;
        }
        else {
          pppfVar11 = DAT_0050b3d4[5];
          pppfVar15 = (float ***)((int)(short)local_18 - (int)pppfVar11);
          if (DAT_0050b3d4[4] <= pppfVar15) {
            pppfStack_10c = (float ***)0x4ef0fb;
            __vbaGenerateBoundsError();
            ppppfVar16 = DAT_0050b3cc;
          }
          iVar5 = (int)pppfVar15 * 4;
        }
        unaff_ESI = DAT_0050b3d4[3];
        if (*(float *)((int)unaff_ESI + iVar5) == _DAT_00401488) {
          if ((ppppfVar16 == (float ****)0x0) || (*(short *)ppppfVar16 != 2)) {
            pppfStack_10c = (float ***)0x4ef178;
            iVar5 = __vbaGenerateBoundsError();
            ppppfVar16 = DAT_0050b3cc;
          }
          else {
            pppfVar11 = (float ***)((int)(short)local_18 - (int)ppppfVar16[7]);
            if (ppppfVar16[6] <= pppfVar11) {
              pppfStack_10c = (float ***)0x4ef14b;
              __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            unaff_ESI = (float ***)((int)(short)local_1c - (int)ppppfVar16[5]);
            if (ppppfVar16[4] <= unaff_ESI) {
              pppfStack_10c = (float ***)0x4ef163;
              __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            iVar5 = (int)((int)ppppfVar16[6] * (int)unaff_ESI + (int)pppfVar11) * 4;
          }
          if (*(float *)((int)ppppfVar16[3] + iVar5) != _DAT_00401488) {
            if ((ppppfVar16 == (float ****)0x0) || (*(short *)ppppfVar16 != 2)) {
              pppfStack_10c = (float ***)0x4ef1de;
              iVar5 = __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            else {
              pppfVar11 = (float ***)((int)(short)local_18 - (int)ppppfVar16[7]);
              if (ppppfVar16[6] <= pppfVar11) {
                pppfStack_10c = (float ***)0x4ef1b1;
                __vbaGenerateBoundsError();
                ppppfVar16 = DAT_0050b3cc;
              }
              unaff_ESI = (float ***)((int)(short)local_1c - (int)ppppfVar16[5]);
              if (ppppfVar16[4] <= unaff_ESI) {
                pppfStack_10c = (float ***)0x4ef1c9;
                __vbaGenerateBoundsError();
                ppppfVar16 = DAT_0050b3cc;
              }
              iVar5 = (int)((int)ppppfVar16[6] * (int)unaff_ESI + (int)pppfVar11) * 4;
            }
            if (*(float *)((int)ppppfVar16[3] + iVar5) == _DAT_00401488) goto LAB_004ef201;
            goto LAB_004ef7c1;
          }
        }
        else {
LAB_004ef201:
          if ((DAT_0050b3d4 == (float ****)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
            pppfStack_10c = (float ***)0x4ef22e;
            iVar5 = __vbaGenerateBoundsError();
            ppppfVar16 = DAT_0050b3cc;
          }
          else {
            iVar5 = (int)(short)local_18;
            pppfVar11 = DAT_0050b3d4[5];
            if (DAT_0050b3d4[4] <= (float ***)(iVar5 - (int)pppfVar11)) {
              pppfStack_10c = (float ***)0x4ef21d;
              __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            iVar5 = (iVar5 - (int)pppfVar11) * 4;
          }
          unaff_ESI = DAT_0050b3d4[3];
          if (*(float *)((int)unaff_ESI + iVar5) != _DAT_00401488) {
            if ((ppppfVar16 == (float ****)0x0) || (*(short *)ppppfVar16 != 2)) {
              pppfStack_10c = (float ***)0x4ef296;
              iVar5 = __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            else {
              pppfVar11 = (float ***)((int)(short)local_18 - (int)ppppfVar16[7]);
              if (ppppfVar16[6] <= pppfVar11) {
                pppfStack_10c = (float ***)0x4ef269;
                __vbaGenerateBoundsError();
                ppppfVar16 = DAT_0050b3cc;
              }
              unaff_ESI = (float ***)((int)(short)local_1c - (int)ppppfVar16[5]);
              if (ppppfVar16[4] <= unaff_ESI) {
                pppfStack_10c = (float ***)0x4ef281;
                __vbaGenerateBoundsError();
                ppppfVar16 = DAT_0050b3cc;
              }
              iVar5 = (int)((int)ppppfVar16[6] * (int)unaff_ESI + (int)pppfVar11) * 4;
            }
            if (*(float *)((int)ppppfVar16[3] + iVar5) == _DAT_00401488) goto LAB_004ef38d;
          }
          uVar19 = 0;
          if ((DAT_0050b3d4 == (float ****)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
            pppfStack_10c = (float ***)0x4ef2ec;
            local_fc = __vbaGenerateBoundsError();
            ppppfVar16 = DAT_0050b3cc;
          }
          else {
            iVar5 = (int)(short)local_18;
            pppfVar11 = DAT_0050b3d4[5];
            if (DAT_0050b3d4[4] <= (float ***)(iVar5 - (int)pppfVar11)) {
              pppfStack_10c = (float ***)0x4ef2d5;
              __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            local_fc = (iVar5 - (int)pppfVar11) * 4;
          }
          if ((ppppfVar16 == (float ****)0x0) || (*(short *)ppppfVar16 != 2)) {
            pppfStack_10c = (float ***)0x4ef341;
            iVar5 = __vbaGenerateBoundsError();
            ppppfVar16 = DAT_0050b3cc;
          }
          else {
            iVar5 = (int)(short)local_18;
            pppfVar11 = ppppfVar16[7];
            if (ppppfVar16[6] <= (float ***)(iVar5 - (int)pppfVar11)) {
              pppfStack_10c = (float ***)0x4ef314;
              __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            iVar17 = (int)(short)local_1c;
            pppfVar15 = ppppfVar16[5];
            if (ppppfVar16[4] <= (float ***)(iVar17 - (int)pppfVar15)) {
              pppfStack_10c = (float ***)0x4ef32c;
              __vbaGenerateBoundsError();
              ppppfVar16 = DAT_0050b3cc;
            }
            iVar5 = (int)((int)ppppfVar16[6] * (iVar17 - (int)pppfVar15) + (iVar5 - (int)pppfVar11))
                    * 4;
          }
          unaff_ESI = ppppfVar16[3];
          pppfVar11 = DAT_0050b3d4[3];
          local_28 = *(float *)((int)unaff_ESI + iVar5) + *(float *)((int)pppfVar11 + local_fc);
          if ((uVar19 & 0xd) != 0) {
            __vbaFPException();
            return;
          }
          if (local_2c < local_28) {
            local_30 = local_18;
            local_2c = local_28;
          }
        }
LAB_004ef38d:
        uVar12 = (uint)(ushort)((short)local_18 + 1);
        if (SCARRY2((short)local_18,1)) goto LAB_004ef9a0;
      }
      if ((DAT_0050b3d4 == (float ****)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
        pppfStack_10c = (float ***)0x4ef3d1;
        iVar5 = __vbaGenerateBoundsError();
        ppppfVar16 = DAT_0050b3cc;
      }
      else {
        iVar5 = (int)(short)local_1c;
        pppfVar11 = DAT_0050b3d4[5];
        if (DAT_0050b3d4[4] <= (float ***)(iVar5 - (int)pppfVar11)) {
          pppfStack_10c = (float ***)0x4ef3c0;
          __vbaGenerateBoundsError();
          ppppfVar16 = DAT_0050b3cc;
        }
        iVar5 = (iVar5 - (int)pppfVar11) * 4;
      }
      unaff_ESI = DAT_0050b3d4[3];
      if (*(float *)((int)unaff_ESI + iVar5) == _DAT_00401488) {
        DAT_0050b3c2 = 1;
        if ((DAT_0050b3d4 == (float ****)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
          pppfStack_10c = (float ***)0x4ef424;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          iVar5 = (int)(short)local_1c;
          pppfVar15 = DAT_0050b3d4[5];
          if (DAT_0050b3d4[4] <= (float ***)(iVar5 - (int)pppfVar15)) {
            pppfStack_10c = (float ***)0x4ef419;
            __vbaGenerateBoundsError();
          }
          iVar5 = (iVar5 - (int)pppfVar15) * 4;
        }
        *(float *)((int)DAT_0050b3d4[3] + iVar5) = local_2c;
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          pppfStack_10c = (float ***)0x4ef47d;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          iVar17 = (int)(short)local_30;
          iVar5 = *(int *)(DAT_0050b3e8 + 0xe);
          if (*(uint *)(DAT_0050b3e8 + 0xc) <= (uint)(iVar17 - iVar5)) {
            pppfStack_10c = (float ***)0x4ef455;
            __vbaGenerateBoundsError();
          }
          pppfVar11 = (float ***)-*(int *)(DAT_0050b3e8 + 10);
          if (*(float ****)(DAT_0050b3e8 + 8) <= pppfVar11) {
            pppfStack_10c = (float ***)0x4ef469;
            __vbaGenerateBoundsError();
          }
          iVar5 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)pppfVar11 + (iVar17 - iVar5)) * 2;
        }
        local_20 = 1;
        sVar13 = *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar5);
        uVar12 = local_20;
        while( true ) {
          local_20 = uVar12;
          sVar14 = (short)local_20;
          if (sVar13 < sVar14) break;
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            pppfStack_10c = (float ***)0x4ef4f9;
            unaff_ESI = (float ***)__vbaGenerateBoundsError();
          }
          else {
            local_cc = (float **)((int)(short)local_30 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(float ****)(DAT_0050b3e8 + 0xc) <= local_cc) {
              pppfStack_10c = (float ***)0x4ef4c8;
              __vbaGenerateBoundsError();
            }
            pppfVar11 = (float ***)((int)sVar14 - *(int *)(DAT_0050b3e8 + 10));
            if (*(float ****)(DAT_0050b3e8 + 8) <= pppfVar11) {
              pppfStack_10c = (float ***)0x4ef4df;
              __vbaGenerateBoundsError();
            }
            unaff_ESI = (float ***)
                        ((int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)pppfVar11 + (int)local_cc) * 2);
          }
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            pppfStack_10c = (float ***)0x4ef553;
            iVar5 = __vbaGenerateBoundsError();
          }
          else {
            local_c4 = (int)(short)local_1c - *(int *)(DAT_0050b3e8 + 0xe);
            if (*(uint *)(DAT_0050b3e8 + 0xc) <= local_c4) {
              pppfStack_10c = (float ***)0x4ef523;
              __vbaGenerateBoundsError();
            }
            pppfVar11 = (float ***)((int)(short)local_20 - *(int *)(DAT_0050b3e8 + 10));
            if (*(float ****)(DAT_0050b3e8 + 8) <= pppfVar11) {
              pppfStack_10c = (float ***)0x4ef53b;
              __vbaGenerateBoundsError();
            }
            iVar5 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)pppfVar11 + local_c4) * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar5) =
               *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + (int)unaff_ESI);
          uVar12 = (uint)(ushort)((short)local_20 + 1);
          if (SCARRY2((short)local_20,1)) goto LAB_004ef9a0;
        }
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          pppfStack_10c = (float ***)0x4ef5d1;
          unaff_ESI = (float ***)__vbaGenerateBoundsError();
        }
        else {
          pppfVar11 = (float ***)((int)(short)local_30 - *(int *)(DAT_0050b3e8 + 0xe));
          if (*(float ****)(DAT_0050b3e8 + 0xc) <= pppfVar11) {
            pppfStack_10c = (float ***)0x4ef59f;
            __vbaGenerateBoundsError();
          }
          local_c8 = -*(int *)(DAT_0050b3e8 + 10);
          if (*(uint *)(DAT_0050b3e8 + 8) <= local_c8) {
            pppfStack_10c = (float ***)0x4ef5b9;
            __vbaGenerateBoundsError();
          }
          unaff_ESI = (float ***)
                      ((int)(*(int *)(DAT_0050b3e8 + 0xc) * local_c8 + (int)pppfVar11) * 2);
        }
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          pppfStack_10c = (float ***)0x4ef629;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          pppfVar11 = (float ***)((int)(short)local_1c - *(int *)(DAT_0050b3e8 + 0xe));
          if (*(float ****)(DAT_0050b3e8 + 0xc) <= pppfVar11) {
            pppfStack_10c = (float ***)0x4ef5f5;
            __vbaGenerateBoundsError();
          }
          local_c0 = -*(int *)(DAT_0050b3e8 + 10);
          if (*(uint *)(DAT_0050b3e8 + 8) <= local_c0) {
            pppfStack_10c = (float ***)0x4ef60f;
            __vbaGenerateBoundsError();
          }
          iVar5 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * local_c0 + (int)pppfVar11) * 2;
        }
        sVar13 = *(short *)(*(int *)(DAT_0050b3e8 + 6) + (int)unaff_ESI);
        if (SCARRY2(sVar13,1)) goto LAB_004ef9a0;
        *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar5) = sVar13 + 1;
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          pppfStack_10c = (float ***)0x4ef6f3;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          iVar5 = (int)(short)local_1c;
          pppfVar11 = (float ***)(iVar5 - *(int *)(DAT_0050b3e8 + 0xe));
          local_cc = (float **)pppfVar11;
          if (*(float ****)(DAT_0050b3e8 + 0xc) <= pppfVar11) {
            pppfStack_10c = (float ***)0x4ef676;
            __vbaGenerateBoundsError();
          }
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            pppfStack_10c = (float ***)0x4ef6c4;
            iVar5 = __vbaGenerateBoundsError();
          }
          else {
            uVar12 = iVar5 - *(int *)(DAT_0050b3e8 + 0xe);
            if (*(uint *)(DAT_0050b3e8 + 0xc) <= uVar12) {
              pppfStack_10c = (float ***)0x4ef696;
              __vbaGenerateBoundsError();
            }
            iVar5 = *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= (uint)-iVar5) {
              pppfStack_10c = (float ***)0x4ef6aa;
              __vbaGenerateBoundsError();
            }
            iVar5 = (*(int *)(DAT_0050b3e8 + 0xc) * -iVar5 + uVar12) * 2;
            pppfVar11 = (float ***)local_cc;
          }
          unaff_ESI = (float ***)
                      ((int)*(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar5) -
                      *(int *)(DAT_0050b3e8 + 10));
          if (*(float ****)(DAT_0050b3e8 + 8) <= unaff_ESI) {
            pppfStack_10c = (float ***)0x4ef6df;
            __vbaGenerateBoundsError();
          }
          iVar5 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)unaff_ESI + (int)pppfVar11) * 2;
        }
        *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar5) = (short)local_1c;
        if ((DAT_0050b3cc == (float ****)0x0) || (*(short *)DAT_0050b3cc != 2)) {
          pppfStack_10c = (float ***)0x4ef74b;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          unaff_ESI = (float ***)((int)(short)local_1c - (int)DAT_0050b3cc[7]);
          if (DAT_0050b3cc[6] <= unaff_ESI) {
            pppfStack_10c = (float ***)0x4ef722;
            __vbaGenerateBoundsError();
          }
          pppfVar11 = (float ***)-(int)DAT_0050b3cc[5];
          if (DAT_0050b3cc[4] <= pppfVar11) {
            pppfStack_10c = (float ***)0x4ef736;
            __vbaGenerateBoundsError();
          }
          iVar5 = (int)((int)DAT_0050b3cc[6] * (int)pppfVar11 + (int)unaff_ESI) * 4;
        }
        if (*(float *)((int)DAT_0050b3cc[3] + iVar5) == _DAT_00401488) {
          local_24 = 1;
        }
        if ((DAT_0050b3cc == (float ****)0x0) || (*(short *)DAT_0050b3cc != 2)) {
          pppfStack_10c = (float ***)0x4ef7ac;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          pppfVar11 = (float ***)-(int)DAT_0050b3cc[7];
          if (DAT_0050b3cc[6] <= pppfVar11) {
            pppfStack_10c = (float ***)0x4ef783;
            __vbaGenerateBoundsError();
          }
          unaff_ESI = (float ***)-(int)DAT_0050b3cc[5];
          if (DAT_0050b3cc[4] <= unaff_ESI) {
            pppfStack_10c = (float ***)0x4ef797;
            __vbaGenerateBoundsError();
          }
          iVar5 = (int)((int)DAT_0050b3cc[6] * (int)unaff_ESI + (int)pppfVar11) * 4;
        }
        *(float *)((int)DAT_0050b3cc[3] + iVar5) = local_2c;
        ppppfVar16 = DAT_0050b3cc;
      }
    }
LAB_004ef7c1:
    pppfVar15 = (float ***)(uint)(ushort)((short)local_1c + 1);
    if (SCARRY2((short)local_1c,1)) goto LAB_004ef9a0;
  }
  if (DAT_0050b3c2 == 0) {
    pppfStack_10c = (float ***)local_8c;
    local_84 = &local_30;
    local_8c[0] = (float *)0x4002;
    pwStack_110 = L"㖋መ@킋䶍ￌ맖\x04耂સ";
    Ordinal_536();
    pwStack_110 = L"ҹȀ뢀\n";
    __vbaStrMove();
    local_74 = 0x80020004;
    local_64 = 0x80020004;
    local_7c[0] = 10;
    local_6c[0] = 10;
    local_94 = L"Input Data Error";
    local_9c = 8;
    pwStack_110 = L"喋棌䫐A䶍쟐책";
    __vbaVarDup();
    pwStack_110 = L"Loop detected.  Forward Pass cannot proceed past node";
    local_38 = 0;
    puStack_114 = (undefined4 *)0x4ef87a;
    puStack_114 = (undefined4 *)__vbaStrMove();
    puStack_118 = (undefined4 *)0x4ef881;
    local_44 = __vbaStrCat();
    puStack_118 = local_7c;
    puStack_11c = local_6c;
    ppfStack_120 = local_5c;
    ppfStack_128 = (float **)local_4c;
    uStack_124 = 0x10;
    local_4c[0] = (float **)0x8;
    pppfStack_12c = (float ***)0x4ef89f;
    Ordinal_595();
    pppfStack_12c = (float ***)&local_38;
    puStack_130 = &local_34;
    ppfStack_134 = (float **)0x2;
    pppfStack_138 = (float ***)0x4ef8af;
    __vbaFreeStrList();
    pppfStack_138 = (float ***)local_7c;
    puStack_13c = local_6c;
    pfStack_140 = (float *)local_5c;
    pppfStack_144 = local_4c;
    ppfStack_148 = (float **)0x4;
    pppfStack_14c = (float ***)0x4ef8c7;
    __vbaFreeVarList();
    if (DAT_0050c53c == (float ****)0x0) {
      pppfStack_12c = (float ***)&DAT_0050c53c;
      puStack_130 = (undefined4 *)&DAT_0040b420;
      ppfStack_134 = (float **)0x4ef8e3;
      __vbaNew2();
    }
    ppppfVar16 = DAT_0050c53c;
    if (DAT_0050b420 == (float ****)0x0) {
      pppfStack_12c = (float ***)&DAT_0050b420;
      puStack_130 = (undefined4 *)&DAT_00408c88;
      ppfStack_134 = (float **)0x4ef902;
      __vbaNew2();
    }
    pppfVar11 = *ppppfVar16;
    puStack_130 = &local_3c;
    pppfStack_12c = (float ***)DAT_0050b420;
    ppfStack_134 = (float **)0x4ef915;
    ppfStack_134 = (float **)__vbaObjSetAddref();
    pppfStack_138 = (float ***)ppppfVar16;
    puStack_13c = (undefined4 *)0x4ef91a;
    pppfVar11 = (float ***)(*(code *)pppfVar11[4])();
    if ((int)pppfVar11 < 0) {
      puStack_13c = (undefined4 *)0x10;
      pfStack_140 = (float *)&DAT_0040b410;
      pppfStack_144 = (float ***)ppppfVar16;
      pppfStack_14c = (float ***)0x4ef92f;
      ppfStack_148 = (float **)pppfVar11;
      __vbaHresultCheckObj();
    }
    puStack_13c = (undefined4 *)0x4ef938;
    __vbaFreeObj();
    pppfStack_10c = (float ***)0x4ef93d;
    FUN_00444530();
    goto code_r0x004ef93e;
  }
  pwStack_110 = (wchar_t *)&local_d0;
  pppfStack_10c = (float ***)0x0;
  puStack_114 = (undefined4 *)0x4ef7f3;
  __vbaObjSetAddref();
  if ((short)local_24 != 0) {
code_r0x004ef93e:
    pppfStack_10c = (float ***)&LAB_004ef98a;
    pwStack_110 = L"诃\xf04d幟襤\r";
    __vbaFreeObj();
    return;
  }
  goto LAB_004eefe5;
  while( true ) {
    pppfStack_1b0 = (float ***)(int)(short)ppfStack_120;
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3d4 = (float ***)0x0;
    pppfStack_3d8 = (float ***)0x80010005;
    pppfStack_3e0 = &ppfStack_178;
    pppfStack_3dc = pppfStack_254;
    pppfStack_3e4 = (float ***)0x4f2098;
    pppfStack_3d4 = (float ***)(*(code *)ppppfVar8)();
    pppfStack_3d8 = (float ***)0x4f20a2;
    __vbaR4Var();
    ppppfVar6 = (float ****)pppfStack_3d0;
    if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
    pppfStack_3d4 = (float ***)0x4f20b8;
    iVar5 = __vbaFpI4();
    pppfStack_1d8 = (float ***)0x3;
    pppfStack_3e0 = pppfStack_1b8;
    pppfStack_3e8 = (float ***)((int)(iVar5 + (iVar5 >> 0x1f & 3U)) >> 2);
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3d8 = pppfStack_1b0;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3f4 = (float ***)&DAT_00000001;
    pppfStack_3f8 = (float ***)0x39;
    pppfStack_3f0 = (float ***)0x3;
    pppfStack_3ec = pppfStack_1d4;
    pppfStack_3fc = pppfStack_254;
    pppfStack_3e4 = pppfStack_1cc;
    pppfStack_400 = (float ***)0x4f2122;
    __vbaLateIdCallSt();
    pppfStack_3d4 = (float ***)0x4f212e;
    __vbaFreeVar();
    pppfVar11 = (float ***)(uint)(ushort)((short)ppfStack_120 + 1);
    if (SCARRY2((short)ppfStack_120,1)) break;
LAB_004f2065:
    ppfStack_120 = (float **)pppfVar11;
    if (3 < (short)ppfStack_120) {
      pppfStack_3d4 = (float ***)0x4f214a;
      iStack_2f4 = FUN_0042b130();
      pppfStack_3d8 = (float ***)(float)iStack_2f4;
      pppfStack_1b8 = (float ***)0x4;
      pppfStack_3e4 = (float ***)0x80010006;
      pppfStack_3e0 = (float ***)0x4;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f2197;
      pppfStack_1b0 = pppfStack_3d8;
      __vbaLateIdSt();
      if (DAT_0050c53c == (float ****)0x0) {
        pppfStack_3ec = (float ***)&DAT_0050c53c;
        pppfStack_3f0 = (float ***)&DAT_0040b420;
        pppfStack_3f4 = (float ***)0x4f21b0;
        __vbaNew2();
      }
      pppfStack_3ec = (float ***)&pppfStack_160;
      pppfStack_3f0 = (float ***)DAT_0050c53c;
      pppfStack_230 = (float ***)DAT_0050c53c;
      pppfStack_3f4 = (float ***)0x4f21c5;
      ppppfVar6 = (float ****)(*(code *)(*DAT_0050c53c)[6])();
      if ((int)ppppfVar6 < 0) {
        pppfStack_3f4 = (float ***)0x18;
        pppfStack_3f8 = (float ***)&DAT_0040b410;
        pppfStack_3fc = pppfStack_230;
        uStack_408 = (double)CONCAT44(0x4f21e0,(undefined4)uStack_408);
        pppfStack_400 = (float ***)ppppfVar6;
        __vbaHresultCheckObj();
      }
      pppfStack_3f4 = (float ***)apppfStack_21c;
      pppfStack_3f8 = pppfStack_160;
      pppfStack_238 = pppfStack_160;
      pppfStack_3fc = (float ***)0x4f21f9;
      iVar5 = (*(code *)(*pppfStack_160)[0x26])();
      uVar19 = 0;
      if (iVar5 < 0) {
        pppfStack_3fc = (float ***)0x98;
        pppfStack_400 = (float ***)&DAT_0040bb5c;
        uStack_408 = (double)CONCAT44(pppfStack_238,iVar5);
        pppfStack_40c = (float ***)0x4f2217;
        __vbaHresultCheckObj();
      }
      pppfStack_3fc = (float ***)0x0;
      pppfStack_400 = (float ***)0x80010005;
      uStack_408 = (double)CONCAT44(pppfStack_254,&ppfStack_178);
      pppfStack_40c = (float ***)0x4f222b;
      (*(code *)ppppfVar8)();
      pppfStack_3fc = &ppfStack_178;
      pppfStack_400 = (float ***)0x4f2238;
      fVar20 = (float10)__vbaR4Var();
      ppppfVar6 = (float ****)pppfStack_3d0;
      if (((uVar19 & 0xd) != 0) ||
         (pppfStack_1b0 =
               (float ***)
               (float)(((float10)(float)apppfStack_21c[0] - fVar20) * (float10)_DAT_00401268),
         (uVar19 & 0xd) != 0)) goto LAB_004f2fd3;
      pppfStack_1b8 = (float ***)0x4;
      pppfStack_3e4 = (float ***)0x80010003;
      pppfStack_3e0 = (float ***)0x4;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f2299;
      pppfStack_3d8 = pppfStack_1b0;
      __vbaLateIdSt();
      pppfStack_3ec = (float ***)0x4f22a2;
      __vbaFreeObj();
      pppfStack_3ec = (float ***)0x4f22ab;
      __vbaFreeVar();
      pppfVar11 = pppfStack_1cc;
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_40c = (float ***)0x1;
      pppfStack_410 = (float ***)0x38;
      pppfStack_3f0 = (float ***)0x0;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(pppfStack_1d4,2);
      pppfStack_400 = (float ***)0x4;
      pppfStack_3fc = pppfStack_1cc;
      pppfStack_414 = pppfStack_254;
      pppfStack_418 = (float ***)0x4f230d;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x1;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_3f0 = (float ***)0x1;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(pppfStack_1d4,2);
      pppfStack_40c = (float ***)0x1;
      pppfStack_410 = (float ***)0x38;
      pppfStack_400 = (float ***)0x1;
      pppfStack_414 = pppfStack_254;
      pppfStack_3fc = pppfVar11;
      pppfStack_418 = (float ***)0x4f236b;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x2;
      pppfStack_1d8 = (float ***)0x2;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_40c = (float ***)0x1;
      pppfStack_410 = (float ***)0x38;
      pppfStack_3f0 = (float ***)0x2;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(pppfStack_1d4,2);
      pppfStack_400 = (float ***)0x7;
      pppfStack_3fc = pppfVar11;
      pppfStack_414 = pppfStack_254;
      pppfStack_418 = (float ***)0x4f23d1;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_40c = (float ***)&DAT_00000001;
      pppfStack_410 = (float ***)0x38;
      pppfStack_3f0 = (float ***)0x3;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(pppfStack_1d4,2);
      pppfStack_400 = (float ***)0x7;
      pppfStack_414 = pppfStack_254;
      pppfStack_3fc = pppfVar11;
      pppfStack_418 = (float ***)0x4f242d;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3fc = (float ***)0xa;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_400 = pppfStack_254;
      pppfStack_3f0 = (float ***)0x0;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(0x4f2467,(undefined4)uStack_408);
      __vbaLateIdSt();
      uStack_27c = 3;
      uStack_278 = 1;
      ppppfVar6 = (float ****)0x0;
      goto LAB_004f247d;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3d8 = (float ***)(int)sVar4;
    pppfStack_3e0 = (float ***)0x3;
    pppfStack_3e4 = (float ***)0xb;
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3e8 = pppfStack_254;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3ec = (float ***)0x4f24c5;
    pppfStack_1b0 = pppfStack_3d8;
    __vbaLateIdSt();
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3fc = (float ***)0x26;
    pppfStack_3f8 = (float ***)0x3;
    pppfStack_1b0 = (float ***)0xffff;
    pppfStack_3f4 = pppfStack_1b4;
    pppfStack_400 = pppfStack_254;
    pppfStack_3f0 = (float ***)0xffff;
    pppfStack_3ec = pppfStack_1ac;
    uStack_408 = (double)CONCAT44(0x4f2502,(undefined4)uStack_408);
    __vbaLateIdSt();
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_414 = (float ***)0x27;
    pppfStack_410 = (float ***)0x3;
    pppfStack_1b0 = (float ***)0xff0000;
    pppfStack_40c = pppfStack_1b4;
    pppfStack_418 = pppfStack_254;
    uStack_408 = (double)CONCAT44(pppfStack_1ac,0xff0000);
    pppfStack_41c = (float ***)0x4f253f;
    __vbaLateIdSt();
    ppppfVar6 = (float ****)CONCAT22(extraout_var_02,(short)uStack_278 + sVar4);
    if (SCARRY2((short)uStack_278,sVar4)) break;
LAB_004f247d:
    ppppfVar8 = ppppfVar6;
    sVar4 = (short)ppppfVar8;
    if ((short)uStack_27c < sVar4) {
      ppppfVar8 = &pppfStack_3e0;
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3d8 = (float ***)0x0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3f0 = (float ***)0x3;
      pppfStack_3ec = pppfStack_1d4;
      pppfStack_3e8 = (float ***)0x0;
      pppfStack_3e4 = pppfStack_1cc;
      uStack_408 = 4.24399161404481e-314;
      pppfStack_400 = (float ***)0x8;
      pppfStack_3fc = pppfStack_1f4;
      pppfStack_3f8 = (float ***)0x40e0dc;
      pppfStack_3f4 = pppfStack_1ec;
      pppfStack_40c = pppfStack_254;
      pppfStack_410 = (float ***)0x4f25db;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3e4 = (float ***)0xa;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d8 = (float ***)0x0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f2615;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3fc = (float ***)0xb;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x1;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_400 = pppfStack_254;
      pppfStack_3f0 = (float ***)&DAT_00000001;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(0x4f2652,(undefined4)uStack_408);
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x2;
      pppfStack_410 = (float ***)0x2;
      pppfStack_1b0 = (float ***)0x4;
      pppfStack_40c = pppfStack_1b4;
      uStack_408 = (double)CONCAT44(pppfStack_1ac,4);
      pppfStack_414 = (float ***)0x28;
      pppfStack_418 = pppfStack_254;
      pppfStack_41c = (float ***)0x4f268f;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x8;
      pppfStack_42c = (float ***)0x0;
      pppfStack_428 = (float ***)0x8;
      pppfStack_1b0 = (float ***)0x40ef38;
      pppfStack_424 = pppfStack_1b4;
      pppfStack_430 = pppfStack_254;
      pppfStack_420 = (float ***)0x40ef38;
      pppfStack_41c = pppfStack_1ac;
      pppfStack_434 = (float ***)0x4f26cc;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_444 = (float ***)0xa;
      pppfStack_440 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_43c = pppfStack_1b4;
      pppfStack_448 = pppfStack_254;
      pppfStack_438 = (float ***)0x0;
      pppfStack_434 = pppfStack_1ac;
      pppfStack_44c = (float ***)0x4f2706;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_45c = (float ***)0xb;
      pppfStack_1b0 = (float ***)0x2;
      uStack_458 = (double)CONCAT44(pppfStack_1b4,3);
      pppfStack_450 = (float ***)0x2;
      pppfStack_44c = pppfStack_1ac;
      uStack_464._4_4_ = (float ****)pppfStack_254;
      uStack_464._0_4_ = 0x4f2743;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x2;
      iStack_474 = 0x28;
      pppfStack_1b0 = (float ***)0x4;
      uStack_470 = (double)CONCAT44(pppfStack_1b4,2);
      pppfStack_468 = (float ***)0x4;
      uStack_464 = (double)CONCAT44(uStack_464._4_4_,pppfStack_1ac);
      uStack_47c._4_4_ = (float ****)pppfStack_254;
      uStack_47c._0_4_ = 0x4f2780;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x8;
      pcStack_488 = (code *)0x8;
      pppfStack_1b0 = (float ***)0x414bd8;
      pppfStack_484 = pppfStack_1b4;
      pppfStack_480 = (float ***)0x414bd8;
      uStack_47c = (double)CONCAT44(uStack_47c._4_4_,pppfStack_1ac);
      __vbaLateIdSt(pppfStack_254,0);
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      __vbaLateIdSt(pppfStack_254,10,3,pppfStack_1b4,0,pppfStack_1ac);
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x3;
      __vbaLateIdSt(pppfStack_254,0xb,3,pppfStack_1b4,3,pppfStack_1ac);
      pppfStack_1b8 = (float ***)0x2;
      pppfStack_1b0 = (float ***)0x4;
      __vbaLateIdSt(pppfStack_254,0x28,2,pppfStack_1b4,4,pppfStack_1ac);
      pppfStack_1b8 = (float ***)0x8;
      pppfStack_1b0 = (float ***)0x414bf8;
      __vbaLateIdSt(pppfStack_254,0,8,pppfStack_1b4,L"Variance",pppfStack_1ac);
      uStack_284 = DAT_0050b3c4;
      ppfStack_120 = (float **)&DAT_00000001;
      pppfVar11 = (float ***)ppfStack_120;
      goto LAB_004f28bf;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
      pppfStack_3d4 = (float ***)0x4f293e;
      __vbaGenerateBoundsError();
    }
    else {
      pppfStack_234 = (float ***)((int)sVar4 - *(int *)(DAT_0050b19c + 0xe));
      if (*(float *****)(DAT_0050b19c + 0xc) <= pppfStack_234) {
        pppfStack_3d4 = (float ***)0x4f2904;
        __vbaGenerateBoundsError();
      }
      if (*(uint *)(DAT_0050b19c + 8) <= 1U - *(int *)(DAT_0050b19c + 10)) {
        pppfStack_3d4 = (float ***)0x4f2921;
        __vbaGenerateBoundsError();
      }
    }
    pppfStack_3d4 = (float ***)0x4f2952;
    ppfStack_134 = (float **)__vbaFpI2();
    if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
      pppfStack_3d4 = (float ***)0x4f29c7;
      __vbaGenerateBoundsError();
    }
    else {
      pppfStack_234 = (float ***)((int)(short)ppfStack_120 - *(int *)(DAT_0050b19c + 0xe));
      if (*(float *****)(DAT_0050b19c + 0xc) <= pppfStack_234) {
        pppfStack_3d4 = (float ***)0x4f2981;
        __vbaGenerateBoundsError();
      }
      pppfStack_230 = (float ***)(2 - *(int *)(DAT_0050b19c + 10));
      if (*(float *****)(DAT_0050b19c + 8) <= pppfStack_230) {
        pppfStack_3d4 = (float ***)0x4f29a4;
        __vbaGenerateBoundsError();
      }
    }
    pppfStack_3d4 = (float ***)0x4f29d5;
    puStack_13c = (undefined4 *)__vbaFpI2();
    pppfStack_1b0 = &ppfStack_134;
    pppfStack_3d4 = (float ***)&pppfStack_1b8;
    ppfStack_1c0 = (float **)&puStack_13c;
    pppfStack_1b8 = (float ***)0x4002;
    pppfVar11 = (float ***)(int)(short)(sVar4 + 1);
    ppfStack_1c8 = (float **)0x4002;
    pppfStack_3d8 = (float ***)0x4f2a0b;
    Ordinal_536();
    pppfStack_3d8 = (float ***)0x4f2a18;
    pppfStack_3d8 = (float ***)__vbaStrMove();
    pppfStack_3dc = (float ***)0x4f2a1f;
    Ordinal_519();
    pppfStack_3dc = (float ***)0x4f2a26;
    pppfStack_3dc = (float ***)__vbaStrMove();
    pppfStack_3e0 = (float ***)&DAT_0040cc9c;
    pppfStack_3e4 = (float ***)0x4f2a32;
    __vbaStrCat();
    pppfStack_3e4 = (float ***)0x4f2a39;
    pppfStack_3e4 = (float ***)__vbaStrMove();
    pppfStack_3e8 = &ppfStack_1c8;
    pppfStack_3ec = (float ***)0x4f2a47;
    Ordinal_536();
    pppfStack_3ec = (float ***)0x4f2a4e;
    pppfStack_3ec = (float ***)__vbaStrMove();
    pppfStack_3f0 = (float ***)0x4f2a55;
    Ordinal_519();
    pppfStack_3f0 = (float ***)0x4f2a5c;
    pppfStack_3f0 = (float ***)__vbaStrMove();
    pppfStack_3f4 = (float ***)0x4f2a63;
    pppfStack_418 = (float ***)__vbaStrCat();
    ppfStack_178 = (float **)0x8;
    pppfStack_400 = (float ***)0x3;
    pppfStack_3fc = pppfStack_1d4;
    pppfStack_3f4 = pppfStack_1cc;
    pppfStack_410 = (float ***)0x3;
    pppfStack_40c = pppfStack_1f4;
    uStack_408 = (double)(ZEXT48(pppfStack_1ec) << 0x20);
    pppfStack_424 = (float ***)0x2;
    pppfStack_428 = (float ***)0x41;
    pppfStack_420 = (float ***)0x8;
    pppfStack_41c = pppfStack_174;
    pppfStack_42c = pppfStack_254;
    pppfStack_414 = pppfStack_16c;
    pppfStack_430 = (float ***)0x4f2ad7;
    pppfStack_3f8 = pppfVar11;
    pppfStack_170 = pppfStack_418;
    __vbaLateIdCallSt();
    pppfStack_430 = (float ***)&uStack_15c;
    pppfStack_434 = (float ***)&uStack_158;
    pppfStack_438 = (float ***)&uStack_154;
    pppfStack_43c = &ppfStack_150;
    pppfStack_440 = (float ***)&pppfStack_14c;
    pppfStack_444 = (float ***)0x5;
    pppfStack_448 = (float ***)0x4f2af3;
    __vbaFreeStrList();
    pppfStack_3f4 = (float ***)0x4f2aff;
    __vbaFreeVar();
    pppfStack_3f8 = &ppfStack_148;
    pppfStack_3f4 = (float ***)DAT_0050b3d0;
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3fc = (float ***)0x4f2b20;
    pppfStack_1b0 = pppfVar11;
    __vbaAryLock();
    if (((float ***)ppfStack_148 == (float ***)0x0) || (*(short *)ppfStack_148 != 1)) {
      pppfStack_3fc = (float ***)0x4f2b5d;
      iVar5 = __vbaGenerateBoundsError();
    }
    else {
      pppfStack_230 = (float ***)((int)(short)ppfStack_120 - (int)ppfStack_148[5]);
      if (ppfStack_148[4] <= pppfStack_230) {
        pppfStack_3fc = (float ***)0x4f2b49;
        __vbaGenerateBoundsError();
      }
      iVar5 = (int)pppfStack_230 << 2;
    }
    pppfStack_420 = (float ***)((int)ppfStack_148[3] + iVar5);
    uStack_408 = (double)CONCAT44(pppfStack_1b4,pppfStack_1b8);
    pppfStack_400 = pppfStack_1b0;
    pppfStack_3fc = pppfStack_1ac;
    pppfStack_418 = (float ***)0x3;
    pppfStack_414 = pppfStack_1d4;
    pppfStack_410 = (float ***)0x1;
    pppfStack_40c = pppfStack_1cc;
    pppfStack_42c = (float ***)0x2;
    pppfStack_428 = (float ***)0x4008;
    pppfStack_430 = (float ***)0x41;
    pppfStack_424 = pppfStack_1f4;
    pppfStack_41c = pppfStack_1ec;
    pppfStack_434 = pppfStack_254;
    pppfStack_438 = (float ***)0x4f2be1;
    __vbaLateIdCallSt();
    pppfStack_3fc = &ppfStack_148;
    pppfStack_400 = (float ***)0x4f2bee;
    __vbaAryUnlock();
    pppfStack_400 = (float ***)0x4f2bf3;
    FUN_0044fdc0();
    pppfStack_400 = (float ***)0x4f2bfa;
    __vbaStrMove();
    pppfStack_170 = pppfStack_14c;
    uStack_408._4_4_ = (float ****)&ppfStack_148;
    pppfStack_400 = (float ***)DAT_0050b3cc;
    ppfStack_1c8 = (float **)0x3;
    pppfStack_14c = (float ***)0x0;
    ppfStack_178 = (float **)0x8;
    uStack_408._0_4_ = 0x4f2c2f;
    ppfStack_1c0 = (float **)pppfVar11;
    __vbaAryLock();
    if (((float ***)ppfStack_148 == (float ***)0x0) || (*(short *)ppfStack_148 != 2)) {
      uStack_408._0_4_ = 0x4f2c99;
      iVar5 = __vbaGenerateBoundsError();
    }
    else {
      pppfStack_234 = (float ***)((int)(short)ppfStack_134 - (int)ppfStack_148[7]);
      if (ppfStack_148[6] <= pppfStack_234) {
        uStack_408._0_4_ = 0x4f2c58;
        __vbaGenerateBoundsError();
      }
      pppfStack_230 = (float ***)((int)(short)puStack_13c - (int)ppfStack_148[5]);
      if (ppfStack_148[4] <= pppfStack_230) {
        uStack_408._0_4_ = 0x4f2c79;
        __vbaGenerateBoundsError();
      }
      iVar5 = (int)((int)ppfStack_148[6] * (int)pppfStack_230 + (int)pppfStack_234) * 4;
    }
    uStack_408 = (double)CONCAT44(uStack_408._4_4_,1);
    pppfStack_1b0 = (float ***)((int)ppfStack_148[3] + iVar5);
    pppfStack_410 = &ppfStack_178;
    pppfStack_40c = (float ***)&DAT_00000001;
    pppfStack_414 = (float ***)&pppfStack_1b8;
    pppfStack_418 = appfStack_188;
    pppfStack_1b8 = (float ***)0x4004;
    pppfStack_41c = (float ***)0x4f2cca;
    Ordinal_660();
    pppfStack_41c = &ppfStack_148;
    pppfStack_420 = (float ***)0x4f2cd4;
    __vbaAryUnlock();
    pppfStack_420 = appfStack_188;
    pppfStack_424 = (float ***)0x4f2cde;
    pppfStack_448 = (float ***)__vbaStrVarMove();
    ppfStack_198 = (float **)0x8;
    pppfStack_430 = (float ***)ppfStack_1c8;
    pppfStack_42c = (float ***)ppfStack_1c4;
    pppfStack_428 = (float ***)ppfStack_1c0;
    pppfStack_424 = (float ***)uStack_1bc;
    pppfStack_440 = (float ***)0x3;
    pppfStack_43c = pppfStack_1e4;
    pppfStack_438 = (float ***)0x2;
    pppfStack_434 = (float ***)ppfStack_1dc;
    uStack_458 = 4.24399161404481e-314;
    pppfStack_450 = (float ***)0x8;
    pppfStack_44c = (float ***)uStack_194;
    pppfStack_45c = pppfStack_254;
    pppfStack_444 = pppfStack_18c;
    uStack_464 = (double)CONCAT44(0x4f2d68,(undefined4)uStack_464);
    uStack_190 = pppfStack_448;
    __vbaLateIdCallSt();
    pppfStack_424 = (float ***)0x4f2d74;
    __vbaFreeStr();
    pppfStack_424 = &ppfStack_198;
    pppfStack_428 = appfStack_188;
    pppfStack_42c = &ppfStack_178;
    pppfStack_430 = (float ***)0x3;
    pppfStack_434 = (float ***)0x4f2d8b;
    __vbaFreeVarList();
    pppfStack_424 = (float ***)0x4f2d93;
    FUN_0044fdc0();
    pppfStack_424 = (float ***)0x4f2d9a;
    __vbaStrMove();
    pppfStack_170 = pppfStack_14c;
    ppfStack_1c8 = (float **)0x3;
    uStack_1e8 = 3;
    pppfStack_14c = (float ***)0x0;
    ppfStack_178 = (float **)0x8;
    pppfStack_424 = (float ***)DAT_0050b3c8;
    pppfStack_428 = &ppfStack_148;
    pppfStack_42c = (float ***)0x4f2dd6;
    ppfStack_1c0 = (float **)pppfVar11;
    __vbaAryLock();
    if (((float ***)ppfStack_148 == (float ***)0x0) || (*(short *)ppfStack_148 != 2)) {
      pppfStack_42c = (float ***)0x4f2e32;
      iVar5 = __vbaGenerateBoundsError();
    }
    else {
      pppfStack_234 = (float ***)((int)(short)ppfStack_134 - (int)ppfStack_148[7]);
      if (ppfStack_148[6] <= pppfStack_234) {
        pppfStack_42c = (float ***)0x4f2dff;
        __vbaGenerateBoundsError();
      }
      iVar5 = (int)(short)puStack_13c;
      ppfVar1 = (float **)ppfStack_148[5];
      if (ppfStack_148[4] <= (float **)(iVar5 - (int)ppfVar1)) {
        pppfStack_42c = (float ***)0x4f2e18;
        __vbaGenerateBoundsError();
      }
      iVar5 = (int)((int)ppfStack_148[6] * (iVar5 - (int)ppfVar1) + (int)pppfStack_234) * 4;
    }
    pppfStack_42c = (float ***)&DAT_00000001;
    pppfStack_1b0 = (float ***)((int)ppfStack_148[3] + iVar5);
    pppfStack_434 = &ppfStack_178;
    pppfStack_430 = (float ***)&DAT_00000001;
    pppfStack_438 = (float ***)&pppfStack_1b8;
    pppfStack_43c = appfStack_188;
    pppfStack_1b8 = (float ***)0x4004;
    pppfStack_440 = (float ***)0x4f2e63;
    Ordinal_660();
    pppfStack_440 = &ppfStack_148;
    pppfStack_444 = (float ***)0x4f2e6d;
    __vbaAryUnlock();
    pppfStack_444 = appfStack_188;
    pppfStack_448 = (float ***)0x4f2e77;
    uStack_190 = __vbaStrVarMove();
    ppppfVar16 = (float ****)ppfStack_1dc;
    ppppfVar8 = (float ****)pppfStack_1e4;
    ppfStack_198 = (float **)0x8;
    pppfStack_450 = (float ***)ppfStack_1c4;
    pppfStack_44c = (float ***)ppfStack_1c0;
    pppfStack_448 = (float ***)uStack_1bc;
    uStack_464 = (double)CONCAT44(pppfStack_1e4,uStack_1e8);
    pppfStack_45c = (float ***)0x3;
    uStack_458 = (double)CONCAT44(ppfStack_1c8,ppfStack_1dc);
    uStack_47c = 4.24399161404481e-314;
    iStack_474 = 8;
    pppfStack_480 = pppfStack_254;
    uStack_470 = (double)CONCAT44(uStack_190,uStack_194);
    pppfStack_468 = pppfStack_18c;
    pppfStack_484 = (float ***)0x4f2ef8;
    __vbaLateIdCallSt();
    pppfStack_448 = (float ***)0x4f2f04;
    __vbaFreeStr();
    pppfStack_448 = &ppfStack_198;
    pppfStack_44c = appfStack_188;
    pppfStack_450 = &ppfStack_178;
    uStack_458 = 6.36855127864054e-314;
    __vbaFreeVarList();
    pppfVar11 = (float ***)(uint)(ushort)((short)ppfStack_120 + 1);
    if (SCARRY2((short)ppfStack_120,1)) break;
LAB_004f28bf:
    ppfStack_120 = (float **)pppfVar11;
    sVar4 = (short)ppfStack_120;
    if ((short)uStack_284 < sVar4) goto LAB_004f2f35;
    ppppfVar16 = (float ****)CONCAT22((short)((uint)ppppfVar16 >> 0x10),sVar4 + 1);
    if (SCARRY2(sVar4,1)) break;
  }
  goto LAB_004f2fd8;
  while( true ) {
    pppfStack_1b0 = (float ***)(int)(short)ppfStack_120;
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3d4 = (float ***)0x0;
    pppfStack_3d8 = (float ***)0x80010005;
    pppfStack_3e0 = &ppfStack_178;
    pppfStack_3dc = pppfStack_254;
    pppfStack_3e4 = (float ***)0x4f0c3e;
    pppfStack_3d4 = (float ***)(*(code *)ppppfVar8)();
    pppfStack_3d8 = (float ***)0x4f0c48;
    __vbaR4Var();
    ppppfVar6 = (float ****)pppfStack_3d0;
    if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
    pppfStack_3d4 = (float ***)0x4f0c5e;
    pppfStack_3e8 = (float ***)__vbaFpI4();
    pppfStack_3e0 = pppfStack_1b8;
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3d8 = pppfStack_1b0;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3f4 = (float ***)&DAT_00000001;
    pppfStack_3f0 = (float ***)0x3;
    pppfStack_3f8 = (float ***)0x39;
    pppfStack_3ec = pppfStack_1d4;
    pppfStack_3fc = pppfStack_254;
    pppfStack_3e4 = pppfStack_1cc;
    pppfStack_400 = (float ***)0x4f0cb4;
    __vbaLateIdCallSt();
    pppfStack_3d4 = (float ***)0x4f0cc0;
    __vbaFreeVar();
    pppfVar11 = (float ***)(uint)(ushort)((short)ppfStack_120 + 1);
    if (SCARRY2((short)ppfStack_120,1)) break;
LAB_004f0c0b:
    ppfStack_120 = (float **)pppfVar11;
    if (3 < (short)ppfStack_120) {
      pppfStack_3d4 = (float ***)0x0;
      pppfStack_3d8 = (float ***)0x80010005;
      pppfStack_3e0 = &ppfStack_178;
      pppfStack_3dc = pppfStack_254;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3e4 = (float ***)0x4f0cff;
      pppfStack_3d4 = (float ***)(*(code *)ppppfVar8)();
      pppfStack_3d8 = (float ***)0x4f0d09;
      __vbaR4Var();
      ppppfVar6 = (float ****)pppfStack_3d0;
      if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
      pppfStack_3d4 = (float ***)0x4f0d1f;
      pppfStack_3e8 = (float ***)__vbaFpI4();
      pppfStack_3e0 = pppfStack_1b8;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3d8 = pppfStack_1b0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3f4 = (float ***)&DAT_00000001;
      pppfStack_3f0 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x39;
      pppfStack_3ec = pppfStack_1d4;
      pppfStack_3fc = pppfStack_254;
      pppfStack_3e4 = pppfStack_1cc;
      pppfStack_400 = (float ***)0x4f0d75;
      __vbaLateIdCallSt();
      pppfStack_3d4 = (float ***)0x4f0d81;
      __vbaFreeVar();
      pppfStack_3d4 = (float ***)0x0;
      pppfStack_3d8 = (float ***)0x80010005;
      pppfStack_3e0 = &ppfStack_178;
      pppfStack_3dc = pppfStack_254;
      pppfStack_1b0 = (float ***)&DAT_00000001;
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3e4 = (float ***)0x4f0da9;
      pppfStack_3d4 = (float ***)(*(code *)ppppfVar8)();
      pppfStack_3d8 = (float ***)0x4f0db3;
      __vbaR4Var();
      ppppfVar6 = (float ****)pppfStack_3d0;
      if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
      pppfStack_3d4 = (float ***)0x4f0dc9;
      pppfStack_3e8 = (float ***)__vbaFpI4();
      pppfStack_3e0 = pppfStack_1b8;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3d8 = pppfStack_1b0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3f4 = (float ***)0x1;
      pppfStack_3f0 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x39;
      pppfStack_3ec = pppfStack_1d4;
      pppfStack_3e4 = pppfStack_1cc;
      pppfStack_3fc = pppfStack_254;
      pppfStack_400 = (float ***)0x4f0e1f;
      __vbaLateIdCallSt();
      pppfStack_3d4 = (float ***)0x4f0e2b;
      __vbaFreeVar();
      pppfStack_3d4 = (float ***)0x4f0e30;
      iStack_2f0 = FUN_0042b130();
      pppfStack_3d8 = (float ***)(float)iStack_2f0;
      pppfStack_1b8 = (float ***)0x4;
      pppfStack_3e4 = (float ***)0x80010006;
      pppfStack_3e0 = (float ***)0x4;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f0e7d;
      pppfStack_1b0 = pppfStack_3d8;
      __vbaLateIdSt();
      if (DAT_0050c53c == (float ****)0x0) {
        pppfStack_3ec = (float ***)&DAT_0050c53c;
        pppfStack_3f0 = (float ***)&DAT_0040b420;
        pppfStack_3f4 = (float ***)0x4f0e96;
        __vbaNew2();
      }
      pppfStack_3ec = (float ***)&pppfStack_160;
      pppfStack_3f0 = (float ***)DAT_0050c53c;
      pppfStack_230 = (float ***)DAT_0050c53c;
      pppfStack_3f4 = (float ***)0x4f0eab;
      iVar5 = (*(code *)(*DAT_0050c53c)[6])();
      if (iVar5 < 0) {
        pppfStack_3f4 = (float ***)0x18;
        pppfStack_3f8 = (float ***)&DAT_0040b410;
        pppfStack_3fc = pppfStack_230;
        uStack_408 = (double)CONCAT44(0x4f0ec6,(undefined4)uStack_408);
        pppfStack_400 = (float ***)iVar5;
        __vbaHresultCheckObj();
      }
      pppfStack_3f4 = (float ***)apppfStack_21c;
      pppfStack_3f8 = pppfStack_160;
      pppfStack_238 = pppfStack_160;
      pppfStack_3fc = (float ***)0x4f0edf;
      iVar5 = (*(code *)(*pppfStack_160)[0x26])();
      uVar19 = 0;
      if (iVar5 < 0) {
        pppfStack_3fc = (float ***)0x98;
        pppfStack_400 = (float ***)&DAT_0040bb5c;
        uStack_408 = (double)CONCAT44(pppfStack_238,iVar5);
        pppfStack_40c = (float ***)0x4f0efd;
        __vbaHresultCheckObj();
      }
      pppfStack_3fc = (float ***)0x0;
      pppfStack_400 = (float ***)0x80010005;
      uStack_408 = (double)CONCAT44(pppfStack_254,&ppfStack_178);
      pppfStack_40c = (float ***)0x4f0f11;
      (*(code *)ppppfVar8)();
      pppfStack_3fc = &ppfStack_178;
      pppfStack_400 = (float ***)0x4f0f1e;
      fVar20 = (float10)__vbaR4Var();
      ppppfVar6 = (float ****)pppfStack_3d0;
      if (((uVar19 & 0xd) != 0) ||
         (pppfStack_1b0 =
               (float ***)
               (float)(((float10)(float)apppfStack_21c[0] - fVar20) * (float10)_DAT_00401268),
         (uVar19 & 0xd) != 0)) goto LAB_004f2fd3;
      pppfStack_1b8 = (float ***)0x4;
      pppfStack_3e4 = (float ***)0x80010003;
      pppfStack_3e0 = (float ***)0x4;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f0f7f;
      pppfStack_3d8 = pppfStack_1b0;
      __vbaLateIdSt();
      pppfStack_3ec = (float ***)0x4f0f88;
      __vbaFreeObj();
      pppfStack_3ec = (float ***)0x4f0f91;
      __vbaFreeVar();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_40c = (float ***)0x1;
      pppfStack_410 = (float ***)0x38;
      pppfStack_3f0 = (float ***)0x0;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(pppfStack_1d4,2);
      pppfStack_414 = pppfStack_254;
      pppfStack_400 = (float ***)0x1;
      pppfStack_3fc = pppfStack_1cc;
      pppfStack_418 = (float ***)0x4f0ff3;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x1;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_3f0 = (float ***)&DAT_00000001;
      pppfStack_3ec = pppfStack_1ac;
      pppfStack_40c = (float ***)&DAT_00000001;
      pppfStack_410 = (float ***)0x38;
      uStack_408 = (double)CONCAT44(pppfStack_1d4,2);
      pppfStack_414 = pppfStack_254;
      pppfStack_400 = (float ***)&DAT_00000001;
      pppfStack_3fc = pppfStack_1cc;
      pppfStack_418 = (float ***)0x4f1055;
      __vbaLateIdCallSt();
      ppppfVar8 = (float ****)pppfStack_1cc;
      uStack_2a4 = 3;
      uStack_2a0 = 1;
      ppfStack_120 = (float **)0x2;
      pppfVar11 = (float ***)ppfStack_120;
      goto LAB_004f1079;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    pppfStack_3d8 = (float ***)(int)(short)ppfStack_120;
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3e0 = (float ***)0x3;
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3f4 = (float ***)&DAT_00000001;
    pppfStack_3f8 = (float ***)0x38;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3f0 = (float ***)0x2;
    pppfStack_3ec = pppfStack_1d4;
    pppfStack_3e8 = (float ***)0x7;
    pppfStack_3fc = pppfStack_254;
    pppfStack_3e4 = (float ***)ppppfVar8;
    pppfStack_400 = (float ***)0x4f10e4;
    pppfStack_1b0 = pppfStack_3d8;
    __vbaLateIdCallSt();
    pppfVar11 = (float ***)CONCAT22(extraout_var,(short)uStack_2a0 + (short)ppfStack_120);
    if (SCARRY2((short)uStack_2a0,(short)ppfStack_120)) break;
LAB_004f1079:
    ppfStack_120 = (float **)pppfVar11;
    if ((short)uStack_2a4 < (short)ppfStack_120) {
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3e4 = (float ***)0xa;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d8 = (float ***)0x0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f113a;
      __vbaLateIdSt();
      ppfStack_120 = (float **)0x0;
      pppfVar11 = (float ***)ppfStack_120;
      goto LAB_004f1141;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    pppfStack_3d8 = (float ***)(int)(short)ppfStack_120;
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3e4 = (float ***)0xb;
    pppfStack_3e0 = (float ***)0x3;
    pppfStack_3dc = pppfStack_1b4;
    pppfStack_3e8 = pppfStack_254;
    pppfStack_3d4 = pppfStack_1ac;
    pppfStack_3ec = (float ***)0x4f118c;
    pppfStack_1b0 = pppfStack_3d8;
    __vbaLateIdSt();
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_3fc = (float ***)0x26;
    pppfStack_3f8 = (float ***)0x3;
    pppfStack_1b0 = (float ***)0xffff;
    pppfStack_3f4 = pppfStack_1b4;
    pppfStack_400 = pppfStack_254;
    pppfStack_3f0 = (float ***)0xffff;
    pppfStack_3ec = pppfStack_1ac;
    uStack_408 = (double)CONCAT44(0x4f11c9,(undefined4)uStack_408);
    __vbaLateIdSt();
    pppfStack_1b8 = (float ***)0x3;
    pppfStack_414 = (float ***)0x27;
    pppfStack_410 = (float ***)0x3;
    pppfStack_1b0 = (float ***)0xff0000;
    pppfStack_40c = pppfStack_1b4;
    pppfStack_418 = pppfStack_254;
    uStack_408 = (double)CONCAT44(pppfStack_1ac,0xff0000);
    pppfStack_41c = (float ***)0x4f1206;
    __vbaLateIdSt();
    pppfVar11 = (float ***)(uint)(ushort)((short)ppfStack_120 + 1);
    if (SCARRY2((short)ppfStack_120,1)) break;
LAB_004f1141:
    ppfStack_120 = (float **)pppfVar11;
    if (3 < (short)ppfStack_120) {
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1d8 = (float ***)0x3;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      uStack_1d0 = 0;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3d8 = (float ***)0x0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3f0 = (float ***)0x3;
      pppfStack_3ec = pppfStack_1d4;
      pppfStack_3e8 = (float ***)0x0;
      pppfStack_3e4 = (float ***)ppppfVar8;
      uStack_408 = 4.24399161404481e-314;
      pppfStack_400 = (float ***)0x8;
      pppfStack_3fc = pppfStack_1f4;
      pppfStack_3f8 = (float ***)0x413078;
      pppfStack_3f4 = pppfStack_1ec;
      pppfStack_40c = pppfStack_254;
      pppfStack_410 = (float ***)0x4f12ad;
      __vbaLateIdCallSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1d8 = (float ***)0x3;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3d8 = (float ***)0x0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3f0 = (float ***)0x3;
      pppfStack_3ec = pppfStack_1d4;
      pppfStack_3e8 = (float ***)0x1;
      pppfStack_3e4 = (float ***)ppppfVar8;
      uStack_408 = 4.24399161404481e-314;
      pppfStack_400 = (float ***)0x8;
      pppfStack_3fc = pppfStack_1f4;
      pppfStack_3f8 = (float ***)0x414c10;
      pppfStack_3f4 = pppfStack_1ec;
      pppfStack_40c = pppfStack_254;
      pppfStack_410 = (float ***)0x4f1336;
      __vbaLateIdCallSt();
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3e0 = (float ***)0x3;
      pppfStack_3e4 = (float ***)0xa;
      pppfStack_3dc = pppfStack_1b4;
      pppfStack_3e8 = pppfStack_254;
      pppfStack_3d8 = (float ***)0x0;
      pppfStack_3d4 = pppfStack_1ac;
      pppfStack_3ec = (float ***)0x4f1370;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_3fc = (float ***)0xb;
      pppfStack_3f8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x2;
      pppfStack_3f4 = pppfStack_1b4;
      pppfStack_400 = pppfStack_254;
      pppfStack_3f0 = (float ***)0x2;
      pppfStack_3ec = pppfStack_1ac;
      uStack_408 = (double)CONCAT44(0x4f13ad,(undefined4)uStack_408);
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x2;
      pppfStack_414 = (float ***)0x28;
      pppfStack_410 = (float ***)0x2;
      pppfStack_1b0 = (float ***)0x4;
      pppfStack_40c = pppfStack_1b4;
      pppfStack_418 = pppfStack_254;
      uStack_408 = (double)CONCAT44(pppfStack_1ac,4);
      pppfStack_41c = (float ***)0x4f13ea;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1d8 = (float ***)0x3;
      pppfStack_428 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_424 = pppfStack_1b4;
      pppfStack_420 = (float ***)0x0;
      pppfStack_41c = pppfStack_1ac;
      pppfStack_438 = (float ***)0x3;
      pppfStack_434 = pppfStack_1d4;
      pppfStack_430 = (float ***)0x2;
      pppfStack_42c = (float ***)ppppfVar8;
      pppfStack_44c = (float ***)0x2;
      pppfStack_450 = (float ***)0x41;
      pppfStack_448 = (float ***)0x8;
      pppfStack_444 = pppfStack_1f4;
      pppfStack_440 = (float ***)0x414bd8;
      pppfStack_43c = pppfStack_1ec;
      uStack_458 = (double)CONCAT44(pppfStack_254,0x4f1473);
      __vbaLateIdCallSt();
      pppfStack_1b0 = (float ***)0x0;
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_42c = (float ***)0xa;
      pppfStack_428 = (float ***)0x3;
      pppfStack_424 = pppfStack_1b4;
      pppfStack_430 = pppfStack_254;
      pppfStack_420 = (float ***)0x0;
      pppfStack_41c = pppfStack_1ac;
      pppfStack_434 = (float ***)0x4f14ad;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x3;
      pppfStack_1b0 = (float ***)0x3;
      pppfStack_440 = (float ***)0x3;
      pppfStack_444 = (float ***)0xb;
      pppfStack_43c = pppfStack_1b4;
      pppfStack_448 = pppfStack_254;
      pppfStack_438 = (float ***)0x3;
      pppfStack_434 = pppfStack_1ac;
      pppfStack_44c = (float ***)0x4f14e7;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x2;
      pppfStack_45c = (float ***)0x28;
      pppfStack_1b0 = (float ***)0x4;
      uStack_458 = (double)CONCAT44(pppfStack_1b4,2);
      pppfStack_450 = (float ***)0x4;
      pppfStack_44c = pppfStack_1ac;
      uStack_464._4_4_ = (float ****)pppfStack_254;
      uStack_464._0_4_ = 0x4f1524;
      __vbaLateIdSt();
      pppfStack_1b8 = (float ***)0x8;
      iStack_474 = 0;
      pppfStack_1b0 = (float ***)0x414c60;
      uStack_470 = (double)CONCAT44(pppfStack_1b4,8);
      pppfStack_468 = (float ***)0x414c60;
      uStack_464 = (double)CONCAT44(uStack_464._4_4_,pppfStack_1ac);
      uStack_47c = (double)CONCAT44(pppfStack_254,0x4f1561);
      __vbaLateIdSt();
      sStack_2b4 = DAT_0050b332;
      ppfStack_120 = (float **)&DAT_00000001;
      ppppfVar6 = DAT_0050b3cc;
      pppfVar11 = (float ***)ppfStack_120;
      goto LAB_004f157d;
    }
  }
  goto LAB_004f2fd8;
LAB_004f157d:
  do {
    ppfStack_120 = (float **)pppfVar11;
    ppppfVar16 = (float ****)ppfStack_120;
    sVar4 = (short)ppfStack_120;
    if (sStack_2b4 < sVar4) goto LAB_004f2f35;
    if ((ppppfVar6 == (float ****)0x0) || (*(short *)ppppfVar6 != 2)) {
      pppfStack_3d4 = (float ***)0x4f15e6;
      iVar5 = __vbaGenerateBoundsError();
      ppppfVar6 = DAT_0050b3cc;
    }
    else {
      ppppfVar8 = (float ****)((int)sVar4 - (int)ppppfVar6[7]);
      if (ppppfVar6[6] <= ppppfVar8) {
        pppfStack_3d4 = (float ***)0x4f15a9;
        __vbaGenerateBoundsError();
        ppppfVar6 = DAT_0050b3cc;
      }
      pppfStack_230 = (float ***)-(int)ppppfVar6[5];
      if (ppppfVar6[4] <= pppfStack_230) {
        pppfStack_3d4 = (float ***)0x4f15c7;
        __vbaGenerateBoundsError();
        ppppfVar6 = DAT_0050b3cc;
      }
      iVar5 = (int)((int)ppppfVar6[6] * (int)pppfStack_230 + (int)ppppfVar8) * 4;
    }
    uVar19 = 0;
    if (*(float *)((int)ppppfVar6[3] + iVar5) != _DAT_00402558) {
      if ((ppppfVar6 == (float ****)0x0) || (*(short *)ppppfVar6 != 2)) {
        pppfStack_3d4 = (float ***)0x4f165d;
        iVar5 = __vbaGenerateBoundsError();
        ppppfVar6 = DAT_0050b3cc;
      }
      else {
        pppfStack_234 = (float ***)-(int)ppppfVar6[7];
        if (ppppfVar6[6] <= pppfStack_234) {
          pppfStack_3d4 = (float ***)0x4f1625;
          __vbaGenerateBoundsError();
          ppppfVar6 = DAT_0050b3cc;
        }
        ppppfVar8 = (float ****)((int)sVar4 - (int)ppppfVar6[5]);
        if (ppppfVar6[4] <= ppppfVar8) {
          pppfStack_3d4 = (float ***)0x4f1640;
          __vbaGenerateBoundsError();
          ppppfVar6 = DAT_0050b3cc;
        }
        iVar5 = (int)((int)ppppfVar6[6] * (int)ppppfVar8 + (int)pppfStack_234) * 4;
      }
      uVar19 = 0;
      if (*(float *)((int)ppppfVar6[3] + iVar5) != _DAT_00401488) {
        pppfStack_1b8 = (float ***)0x3;
        pppfStack_1d8 = (float ***)0x3;
        pppfStack_3d8 = (float ***)0x4f169b;
        pppfStack_3d4 = (float ***)ppppfVar16;
        pppfStack_1b0 = (float ***)(int)sVar4;
        pppfStack_3fc = (float ***)__vbaStrI2();
        ppppfVar16 = &pppfStack_3f4;
        pppfStack_3e4 = pppfStack_1b8;
        ppfStack_178 = (float **)0x8;
        pppfStack_3e0 = pppfStack_1b4;
        pppfStack_3dc = pppfStack_1b0;
        pppfStack_3d8 = pppfStack_1ac;
        pppfStack_3f4 = pppfStack_1d8;
        pppfStack_3f0 = pppfStack_1d4;
        pppfStack_3ec = (float ***)0x0;
        pppfStack_3e8 = pppfStack_1cc;
        pppfStack_40c = (float ***)0x41;
        uStack_408 = 1.69759663287103e-313;
        pppfStack_400 = pppfStack_174;
        pppfStack_410 = pppfStack_254;
        pppfStack_3f8 = pppfStack_16c;
        pppfStack_414 = (float ***)0x4f1715;
        pppfStack_170 = pppfStack_3fc;
        __vbaLateIdCallSt();
        pppfStack_3d8 = (float ***)0x4f1721;
        __vbaFreeVar();
        pppfStack_144 = (float ***)0x0;
        pppfStack_3d8 = (float ***)0x4f1738;
        __vbaStrCopy();
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          pppfStack_3d4 = (float ***)0x4f178a;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          uVar12 = (int)(int)sVar4 - *(int *)(DAT_0050b3e8 + 0xe);
          if (*(uint *)(DAT_0050b3e8 + 0xc) <= uVar12) {
            pppfStack_3d4 = (float ***)0x4f175a;
            __vbaGenerateBoundsError();
          }
          ppppfVar16 = (float ****)-*(int *)(DAT_0050b3e8 + 10);
          if (*(float ****)(DAT_0050b3e8 + 8) <= ppppfVar16) {
            pppfStack_3d4 = (float ***)0x4f1772;
            __vbaGenerateBoundsError();
          }
          iVar5 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppfVar16 + uVar12) * 2;
        }
        ppppfVar8 = (float ****)__vbaStrMove_exref;
        uStack_124 = 1;
        ppfStack_128 = (float **)
                       CONCAT22(ppfStack_128._2_2_,
                                *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar5));
        uVar12 = uStack_124;
        while( true ) {
          uStack_124 = uVar12;
          if ((short)ppfStack_128 < (short)uStack_124) break;
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            pppfStack_3d4 = (float ***)0x4f1812;
            iVar5 = __vbaGenerateBoundsError();
          }
          else {
            pppfStack_234 = (float ***)((int)(short)ppfStack_120 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(float *****)(DAT_0050b3e8 + 0xc) <= pppfStack_234) {
              pppfStack_3d4 = (float ***)0x4f17de;
              __vbaGenerateBoundsError();
            }
            iVar17 = (int)(short)uStack_124;
            iVar5 = *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= (uint)(iVar17 - iVar5)) {
              pppfStack_3d4 = (float ***)0x4f17fa;
              __vbaGenerateBoundsError();
            }
            iVar5 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (iVar17 - iVar5) + (int)pppfStack_234) * 2;
          }
          ppfStack_134 = (float **)
                         CONCAT22((short)((uint)iVar5 >> 0x10),
                                  *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar5));
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            pppfStack_3d4 = (float ***)0x4f188b;
            iVar5 = __vbaGenerateBoundsError();
            uVar10 = extraout_var_01;
          }
          else {
            ppppfVar16 = *(float *****)(DAT_0050b3e8 + 0xe);
            ppppfVar6 = *(float *****)(DAT_0050b3e8 + 0xc);
            pppfStack_234 = (float ***)((int)(short)ppfStack_120 - (int)ppppfVar16);
            if (ppppfVar6 <= pppfStack_234) {
              pppfStack_3d4 = (float ***)0x4f1848;
              __vbaGenerateBoundsError();
              ppppfVar6 = extraout_EDX;
            }
            uVar10 = (undefined2)((uint)ppppfVar6 >> 0x10);
            if (SCARRY2((short)uStack_124,1)) goto LAB_004f2fd8;
            uVar12 = (int)(short)((short)uStack_124 + 1) - *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= uVar12) {
              pppfStack_3d4 = (float ***)0x4f186f;
              __vbaGenerateBoundsError();
              uVar10 = extraout_var_00;
            }
            iVar5 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * uVar12 + (int)pppfStack_234) * 2;
          }
          puStack_13c = (undefined4 *)
                        CONCAT22(uVar10,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar5));
          pppfStack_3d8 = (float ***)&pppfStack_1b8;
          pppfStack_1b0 = &ppfStack_134;
          pppfStack_3d4 = (float ***)DAT_0050b348;
          pppfStack_1b8 = (float ***)0x4002;
          pppfStack_3dc = (float ***)0x4f18c2;
          Ordinal_536();
          pppfStack_3dc = (float ***)0x4f18c9;
          pppfStack_3dc = (float ***)__vbaStrMove();
          ppppfVar16 = (float ****)__vbaStrCat_exref;
          pppfStack_3e0 = (float ***)0x4f18d2;
          __vbaStrCat();
          pppfStack_3e0 = (float ***)0x4f18d9;
          pppfStack_3e0 = (float ***)__vbaStrMove();
          pppfStack_3e4 = (float ***)&DAT_0040cc9c;
          pppfStack_3e8 = (float ***)0x4f18e1;
          __vbaStrCat();
          pppfStack_3e8 = (float ***)0x4f18ea;
          __vbaStrMove();
          pppfStack_3e8 = &ppfStack_150;
          pppfStack_3ec = (float ***)&pppfStack_14c;
          pppfStack_3f0 = (float ***)0x2;
          pppfStack_3f4 = (float ***)0x4f18fa;
          __vbaFreeStrList();
          if ((short)uStack_124 == (short)ppfStack_128) break;
          if ((DAT_0050b3c8 == (float ****)0x0) || (*(short *)DAT_0050b3c8 != 2)) {
            pppfStack_3d4 = (float ***)0x4f1970;
            iVar5 = __vbaGenerateBoundsError();
          }
          else {
            pppfStack_234 = (float ***)((int)(short)ppfStack_134 - (int)DAT_0050b3c8[7]);
            if (DAT_0050b3c8[6] <= pppfStack_234) {
              pppfStack_3d4 = (float ***)0x4f1937;
              __vbaGenerateBoundsError();
            }
            ppppfVar16 = (float ****)((int)(short)puStack_13c - (int)DAT_0050b3c8[5]);
            if (DAT_0050b3c8[4] <= ppppfVar16) {
              pppfStack_3d4 = (float ***)0x4f1953;
              __vbaGenerateBoundsError();
            }
            iVar5 = (int)((int)DAT_0050b3c8[6] * (int)ppppfVar16 + (int)pppfStack_234) * 4;
          }
          pppfStack_144 =
               (float ***)((float)pppfStack_144 + *(float *)((int)DAT_0050b3c8[3] + iVar5));
          ppppfVar6 = (float ****)pppfStack_3d0;
          if ((uVar19 & 0xd) != 0) goto LAB_004f2fd3;
          uVar12 = (uint)(ushort)((short)uStack_124 + 1);
          if (SCARRY2((short)uStack_124,1)) goto LAB_004f2fd8;
        }
        pppfStack_3d4 = (float ***)DAT_0050b348;
        pppfStack_3d8 = (float ***)0x4f19b6;
        __vbaLenBstr();
        pppfStack_3d8 = (float ***)0x4f19be;
        sVar4 = __vbaI2I4();
        if (SBORROW2(sVar4,1)) break;
        pppfStack_170 = (float ***)CONCAT22(pppfStack_170._2_2_,sVar4 + -1);
        pppfStack_3d4 = &ppfStack_178;
        pppfStack_3d8 = (float ***)&DAT_00000001;
        pppfStack_3dc = (float ***)DAT_0050b348;
        ppfStack_178 = (float **)0x2;
        pppfStack_3e0 = (float ***)0x4f19e6;
        Ordinal_631();
        pppfStack_3e0 = (float ***)0x4f19ef;
        __vbaStrMove();
        pppfStack_3e0 = (float ***)0x4f19f8;
        __vbaFreeVar();
        pppfVar11 = (float ***)(int)(short)ppfStack_120;
        pppfStack_1b8 = (float ***)0x3;
        pppfStack_1d8 = (float ***)0x3;
        pppfStack_3ec = (float ***)0x3;
        pppfStack_3e8 = pppfStack_1b4;
        pppfStack_3e0 = pppfStack_1ac;
        pppfStack_3fc = (float ***)0x3;
        pppfStack_3f8 = pppfStack_1d4;
        pppfStack_410 = (float ***)0x2;
        pppfStack_414 = (float ***)0x41;
        pppfStack_3f4 = (float ***)0x1;
        pppfStack_3f0 = pppfStack_1cc;
        pppfStack_40c = (float ***)0x4008;
        uStack_408 = (double)CONCAT44(&DAT_0050b348,pppfStack_1f4);
        pppfStack_400 = pppfStack_1ec;
        pppfStack_418 = pppfStack_254;
        pppfStack_41c = (float ***)0x4f1a89;
        pppfStack_3e4 = pppfVar11;
        pppfStack_1b0 = pppfVar11;
        __vbaLateIdCallSt();
        pppfStack_3e0 = (float ***)0x4f1a91;
        FUN_0044fdc0();
        pppfStack_3e0 = (float ***)0x4f1a98;
        __vbaStrMove();
        pppfStack_170 = pppfStack_14c;
        pppfStack_3e4 = &ppfStack_148;
        pppfStack_3e0 = (float ***)DAT_0050b3d4;
        ppfStack_1c8 = (float **)0x3;
        pppfStack_14c = (float ***)0x0;
        ppfStack_178 = (float **)0x8;
        pppfStack_3e8 = (float ***)0x4f1acd;
        ppfStack_1c0 = (float **)pppfVar11;
        __vbaAryLock();
        if (((float ***)ppfStack_148 == (float ***)0x0) || (*(short *)ppfStack_148 != 1)) {
          pppfStack_3e8 = (float ***)0x4f1b08;
          iVar5 = __vbaGenerateBoundsError();
        }
        else {
          pppfStack_230 = (float ***)((int)pppfVar11 - (int)ppfStack_148[5]);
          if (ppfStack_148[4] <= pppfStack_230) {
            pppfStack_3e8 = (float ***)0x4f1af4;
            __vbaGenerateBoundsError();
          }
          iVar5 = (int)pppfStack_230 << 2;
        }
        pppfStack_3e8 = (float ***)&DAT_00000001;
        pppfStack_1b0 = (float ***)((int)ppfStack_148[3] + iVar5);
        pppfStack_3f0 = &ppfStack_178;
        pppfStack_3ec = (float ***)&DAT_00000001;
        pppfStack_3f4 = (float ***)&pppfStack_1b8;
        pppfStack_3f8 = appfStack_188;
        pppfStack_1b8 = (float ***)0x4004;
        pppfStack_3fc = (float ***)0x4f1b39;
        Ordinal_660();
        pppfStack_3fc = &ppfStack_148;
        pppfStack_400 = (float ***)0x4f1b43;
        __vbaAryUnlock();
        pppfStack_400 = appfStack_188;
        uStack_408 = (double)CONCAT44(0x4f1b4d,(undefined4)uStack_408);
        pppfStack_428 = (float ***)__vbaStrVarMove();
        ppfStack_198 = (float **)0x8;
        pppfStack_410 = (float ***)ppfStack_1c8;
        pppfStack_40c = (float ***)ppfStack_1c4;
        uStack_408 = (double)CONCAT44(uStack_1bc,ppfStack_1c0);
        pppfStack_420 = (float ***)0x3;
        pppfStack_41c = pppfStack_1e4;
        pppfStack_418 = (float ***)0x2;
        pppfStack_414 = (float ***)ppfStack_1dc;
        pppfStack_434 = (float ***)0x2;
        pppfStack_438 = (float ***)0x41;
        pppfStack_430 = (float ***)0x8;
        pppfStack_42c = (float ***)uStack_194;
        pppfStack_43c = pppfStack_254;
        pppfStack_424 = pppfStack_18c;
        pppfStack_440 = (float ***)0x4f1bd7;
        uStack_190 = pppfStack_428;
        __vbaLateIdCallSt();
        uStack_408 = (double)CONCAT44(0x4f1be3,(undefined4)uStack_408);
        __vbaFreeStr();
        pppfStack_40c = &ppfStack_178;
        uStack_408 = (double)CONCAT44(&ppfStack_198,appfStack_188);
        pppfStack_410 = (float ***)0x3;
        pppfStack_414 = (float ***)0x4f1bfa;
        __vbaFreeVarList();
        uStack_408 = (double)(float)pppfStack_144;
        pppfStack_40c = (float ***)0x4f1c09;
        fVar20 = (float10)Ordinal_614();
        uStack_22c = (double)fVar20;
        pppfStack_40c = (float ***)0x4f1c14;
        FUN_0044fdc0();
        pppfStack_40c = (float ***)0x4f1c1b;
        __vbaStrMove();
        ppfStack_180 = (float **)pppfStack_14c;
        ppppfVar8 = (float ****)0x3;
        ppfStack_1c8 = (float **)0x3;
        pppfStack_14c = (float ***)0x0;
        pppfStack_170 = (float ***)(float ****)uStack_22c;
        pppfStack_40c = (float ***)&DAT_00000001;
        pppfStack_414 = appfStack_188;
        pppfStack_16c = (float ***)uStack_22c._4_4_;
        pppfStack_410 = (float ***)&DAT_00000001;
        pppfStack_418 = &ppfStack_178;
        pppfStack_41c = &ppfStack_198;
        appfStack_188[0] = (float **)0x8;
        ppfStack_178 = (float **)0x5;
        pppfStack_420 = (float ***)0x4f1c74;
        ppfStack_1c0 = (float **)pppfVar11;
        Ordinal_660();
        pppfStack_420 = &ppfStack_198;
        pppfStack_424 = (float ***)0x4f1c81;
        pppfStack_448 = (float ***)__vbaStrVarMove();
        ppfStack_1a8 = (float **)0x8;
        pppfStack_430 = (float ***)ppfStack_1c8;
        pppfStack_42c = (float ***)ppfStack_1c4;
        pppfStack_428 = (float ***)ppfStack_1c0;
        pppfStack_424 = (float ***)uStack_1bc;
        pppfStack_440 = (float ***)0x3;
        pppfStack_43c = pppfStack_1e4;
        pppfStack_438 = (float ***)0x3;
        pppfStack_434 = (float ***)ppfStack_1dc;
        uStack_458 = 4.24399161404481e-314;
        pppfStack_450 = (float ***)0x8;
        pppfStack_44c = pppfStack_1a4;
        pppfStack_45c = pppfStack_254;
        pppfStack_444 = (float ***)ppfStack_19c;
        uStack_464 = (double)CONCAT44(0x4f1d04,(undefined4)uStack_464);
        pppfStack_1a0 = pppfStack_448;
        __vbaLateIdCallSt();
        pppfStack_424 = (float ***)0x4f1d10;
        __vbaFreeStr();
        pppfStack_424 = &ppfStack_1a8;
        pppfStack_428 = &ppfStack_198;
        pppfStack_42c = appfStack_188;
        pppfStack_430 = &ppfStack_178;
        pppfStack_434 = (float ***)0x4;
        pppfStack_438 = (float ***)0x4f1d2e;
        __vbaFreeVarList();
        ppppfVar6 = DAT_0050b3cc;
        ppppfVar16 = (float ****)ppfStack_120;
      }
    }
    pppfVar11 = (float ***)(uint)(ushort)((short)ppppfVar16 + 1);
  } while (!SCARRY2((short)ppppfVar16,1));
LAB_004f2fd8:
  pppfStack_3d4 = (float ***)0x4f2fde;
  __vbaErrorOverflow();
  pppfStack_3e0 = (float ***)&DAT_00402706;
  pppfStack_3e4 = ExceptionList;
  pppfStack_3dc = (float ***)&pcStack_488;
  pppfStack_3d8 = (float ***)&DAT_004025b8;
  pppfStack_3e8 = (float ***)0x0;
  pppfStack_3ec = (float ***)0x0;
  pppfStack_3fc = (float ***)0x0;
  pppfStack_40c = (float ***)0x0;
  pppfStack_440 = (float ***)0x0;
  pppfStack_414 = (float ***)&DAT_0050b3c4;
  pppfStack_41c = (float ***)0x4002;
  ExceptionList = &pppfStack_3e4;
  pcStack_488 = pcVar18;
  pppfStack_484 = (float ***)ppppfVar16;
  pppfStack_480 = (float ***)ppppfVar8;
  pppfStack_3d4 = (float ***)&pppfStack_10c;
  __vbaAryLock(&pppfStack_3e8,DAT_0050b3cc);
  if ((pppfStack_3e8 == (float ***)0x0) || (*(short *)pppfStack_3e8 != 2)) {
    iVar5 = __vbaGenerateBoundsError();
  }
  else {
    ppfVar1 = pppfStack_3e8[7];
    if (pppfStack_3e8[6] <= (float **)-(int)ppfVar1) {
      __vbaGenerateBoundsError();
    }
    ppfVar2 = pppfStack_3e8[5];
    if (pppfStack_3e8[4] <= (float **)-(int)ppfVar2) {
      __vbaGenerateBoundsError();
    }
    iVar5 = (int)((int)pppfStack_3e8[6] * -(int)ppfVar2 + -(int)ppfVar1) * 4;
  }
  uStack_408 = (double)CONCAT44((int)pppfStack_3e8[3] + iVar5,(undefined4)uStack_408);
  pppfStack_40c = (float ***)0x4004;
  FUN_0042af50(&pppfStack_3fc,&pppfStack_40c,&pppfStack_41c);
  __vbaAryUnlock(&pppfStack_3e8);
  ppppfVar16 = &pppfStack_3fc;
  DAT_0050b27c = __vbaI2Var(ppppfVar16);
  __vbaFreeVar();
  DAT_0050b280 = DAT_0050b27c;
  DAT_0050b1d4 = 1;
  if (10 < DAT_0050b27c) {
    pppfStack_450 = (float ***)(int)DAT_0050b27c;
    uStack_458 = (double)(int)pppfStack_450;
    if ((uVar19 & 0xd) != 0) goto LAB_004f3326;
    pppfStack_440 = (float ***)__vbaFpI2();
    DAT_0050b1d4 = FUN_00476930(&pppfStack_440);
  }
  pppfStack_45c = (float ***)(int)DAT_0050b27c;
  DAT_0050b27a = -DAT_0050b1d4;
  uStack_464 = (double)(int)pppfStack_45c;
  pppfStack_468 = (float ***)(int)DAT_0050b1d4;
  uStack_470 = (double)(int)pppfStack_468;
  if (DAT_0050b000 != 0) {
    dVar21 = uStack_470;
    adj_fdiv_m64();
    ppppfVar16 = SUB84(dVar21,0);
  }
  if ((uVar19 & 0xd) == 0) {
    __vbaFPInt(ppppfVar16);
    iStack_474 = (int)DAT_0050b1d4;
    uStack_47c = (double)iStack_474;
    if ((uVar19 & 0xd) == 0) {
      DAT_0050b27c = __vbaFpI2();
      DAT_0050b27e = DAT_0050b27a;
      DAT_0050b280 = DAT_0050b27c;
      if (DAT_0050b570 == (int *)0x0) {
        __vbaNew2(&DAT_004048dc,&DAT_0050b570);
      }
      uVar7 = (**(code **)(*DAT_0050b570 + 0x350))(DAT_0050b570);
      piVar9 = (int *)__vbaObjSet(&pppfStack_3ec,uVar7);
      pppfStack_434 = (float ***)CONCAT22(pppfStack_434._2_2_,DAT_0050b27e);
      pppfStack_424 = (float ***)CONCAT22(pppfStack_424._2_2_,DAT_0050b27c);
      pppfStack_414 = (float ***)CONCAT22(pppfStack_414._2_2_,DAT_0050b280);
      pppfStack_41c = (float ***)0x2;
      pppfStack_40c = (float ***)0x2;
      uStack_408._0_6_ = CONCAT24(DAT_0050b27a,(undefined4)uStack_408);
      iVar5 = (**(code **)(*piVar9 + 0x28c))
                        (piVar9,4,2,(undefined4)uStack_408,uStack_408._4_4_,pppfStack_400,2,
                         pppfStack_418,pppfStack_414,pppfStack_410,2,pppfStack_428,pppfStack_424,
                         pppfStack_420,2,pppfStack_438,pppfStack_434,pppfStack_430);
      if (iVar5 < 0) {
        __vbaHresultCheckObj(iVar5,piVar9,&DAT_0040c908,0x28c);
      }
      __vbaFreeObj();
      return;
    }
  }
LAB_004f3326:
  __vbaFPException();
  return;
}


