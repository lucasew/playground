/* entry 004ed5c0 name FUN_004ed5c0 size 2058 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ed5c0(void)

{
  float ****ppppfVar1;
  float ****ppppfVar2;
  float **ppfVar3;
  float *****pppppfVar4;
  float *****pppppfVar5;
  short sVar6;
  code *pcVar7;
  code **ppcVar8;
  float ******ppppppfVar9;
  undefined1 *puVar10;
  short sVar11;
  int iVar12;
  undefined4 uVar13;
  float *******pppppppfVar14;
  float *******pppppppfVar15;
  int *piVar16;
  undefined2 extraout_var;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  float *******extraout_EDX;
  undefined2 uVar17;
  undefined2 extraout_var_02;
  undefined2 extraout_var_03;
  undefined2 extraout_var_04;
  short sVar18;
  float ******ppppppfVar19;
  uint uVar20;
  code *pcVar21;
  float ******ppppppfVar22;
  code *pcVar23;
  float *******pppppppfVar24;
  uint uVar25;
  int iVar26;
  ushort uVar27;
  float10 fVar28;
  double dVar29;
  code *pcStack_6c0;
  float ******ppppppfStack_6bc;
  float ******ppppppfStack_6b8;
  undefined8 uStack_6b4;
  int iStack_6ac;
  undefined8 uStack_6a8;
  float ******ppppppfStack_6a0;
  undefined8 uStack_69c;
  float ******ppppppfStack_694;
  undefined8 uStack_690;
  float ******ppppppfStack_688;
  float ******ppppppfStack_684;
  float ******ppppppfStack_680;
  float ******ppppppfStack_67c;
  float ******ppppppfStack_678;
  float ******ppppppfStack_674;
  float ******ppppppfStack_670;
  float ******ppppppfStack_66c;
  float ******ppppppfStack_668;
  float ******ppppppfStack_664;
  float ******ppppppfStack_660;
  float ******ppppppfStack_65c;
  float ******ppppppfStack_658;
  float ******ppppppfStack_654;
  float ******ppppppfStack_650;
  float ******ppppppfStack_64c;
  float ******ppppppfStack_648;
  float ******ppppppfStack_644;
  undefined8 uStack_640;
  float ******ppppppfStack_638;
  float ******ppppppfStack_634;
  float ******ppppppfStack_630;
  float ******ppppppfStack_62c;
  float ******ppppppfStack_628;
  float ******ppppppfStack_624;
  float ******ppppppfStack_620;
  float ******ppppppfStack_61c;
  float ******ppppppfStack_618;
  float ******ppppppfStack_614;
  float ******ppppppfStack_610;
  float ******ppppppfStack_60c;
  float ******ppppppfStack_608;
  float ******ppppppfStack_604;
  float ******ppppppfStack_600;
  float ******ppppppfStack_5fc;
  undefined *puStack_5f8;
  float ******ppppppfStack_5f4;
  float ******ppppppfStack_5f0;
  undefined4 uStack_5ec;
  undefined4 uStack_5e8;
  float ******ppppppfStack_5e4;
  undefined4 uStack_5e0;
  float ******ppppppfStack_5dc;
  undefined4 uStack_5d8;
  int iStack_5d4;
  float ******ppppppfStack_5d0;
  undefined *puStack_5cc;
  float ******ppppppfStack_5c8;
  int *piStack_5c4;
  int iStack_5c0;
  float ******ppppppfStack_5bc;
  undefined *puStack_5b8;
  float ******ppppppfStack_5b4;
  float ******ppppppfStack_5b0;
  undefined4 uStack_5ac;
  float ******ppppppfStack_5a8;
  undefined4 uStack_5a4;
  float *****pppppfStack_5a0;
  float ******ppppppfStack_59c;
  undefined *puStack_598;
  float ******ppppppfStack_594;
  float ******ppppppfStack_590;
  float ******ppppppfStack_58c;
  float ******ppppppfStack_588;
  undefined4 uStack_584;
  float *****pppppfStack_580;
  float ******ppppppfStack_57c;
  undefined *puStack_578;
  float ******ppppppfStack_574;
  float ******ppppppfStack_570;
  float ******ppppppfStack_56c;
  float ******ppppppfStack_568;
  undefined4 uStack_564;
  float ******ppppppfStack_560;
  undefined4 uStack_55c;
  float *****pppppfStack_558;
  float ******ppppppfStack_554;
  wchar_t *pwStack_550;
  float ******ppppppfStack_54c;
  float ******ppppppfStack_548;
  float ******ppppppfStack_544;
  float ******ppppppfStack_540;
  float ******ppppppfStack_53c;
  code *pcStack_538;
  float *****pppppfStack_534;
  float *****pppppfStack_530;
  int iStack_52c;
  int iStack_528;
  float fStack_524;
  float fStack_520;
  float *****pppppfStack_51c;
  int iStack_518;
  float fStack_514;
  float fStack_510;
  int iStack_50c;
  short sStack_4ec;
  undefined4 uStack_4dc;
  undefined4 uStack_4d8;
  undefined4 uStack_4c4;
  undefined4 uStack_4bc;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_49c;
  float ******ppppppfStack_48c;
  float ******appppppfStack_488 [6];
  float ******ppppppfStack_470;
  float ******ppppppfStack_46c;
  float ******ppppppfStack_468;
  undefined8 uStack_464;
  float ******ppppppfStack_45c;
  float *****pppppfStack_458;
  float ******appppppfStack_454 [9];
  undefined4 uStack_430;
  float ******ppppppfStack_42c;
  float ******ppppppfStack_424;
  undefined4 uStack_420;
  float ******ppppppfStack_41c;
  float *****pppppfStack_414;
  float ******ppppppfStack_410;
  float ******ppppppfStack_40c;
  undefined4 uStack_408;
  float ******ppppppfStack_404;
  float *****pppppfStack_400;
  float *****pppppfStack_3fc;
  float *****pppppfStack_3f8;
  undefined4 uStack_3f4;
  float ******ppppppfStack_3f0;
  float ******ppppppfStack_3ec;
  float ******ppppppfStack_3e8;
  float ******ppppppfStack_3e4;
  float *****pppppfStack_3e0;
  float ******ppppppfStack_3dc;
  float ******ppppppfStack_3d8;
  float *****pppppfStack_3d4;
  float *****pppppfStack_3d0;
  undefined4 uStack_3cc;
  undefined4 uStack_3c8;
  float ******ppppppfStack_3c4;
  float *****apppppfStack_3c0 [2];
  float *****pppppfStack_3b8;
  float *****pppppfStack_3b0;
  float ******ppppppfStack_3ac;
  float ******ppppppfStack_3a8;
  float ******ppppppfStack_3a4;
  float *****pppppfStack_3a0;
  float *****pppppfStack_39c;
  float ******ppppppfStack_398;
  undefined4 uStack_394;
  undefined4 uStack_390;
  undefined4 uStack_38c;
  float *****pppppfStack_388;
  float ******ppppppfStack_384;
  float *****pppppfStack_380;
  float ******ppppppfStack_37c;
  float ****ppppfStack_378;
  float *****pppppfStack_374;
  float ******ppppppfStack_370;
  float *****pppppfStack_36c;
  float ******ppppppfStack_368;
  float ******ppppppfStack_364;
  float *****pppppfStack_360;
  uint uStack_35c;
  float *****pppppfStack_358;
  float *****pppppfStack_354;
  float *****pppppfStack_350;
  undefined4 *puStack_34c;
  wchar_t *pwStack_348;
  float ******ppppppfStack_344;
  code *pcStack_340;
  float *****pppppfStack_33c;
  code *pcStack_338;
  float *****pppppfStack_334;
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  float ****ppppfStack_324;
  undefined4 uStack_320;
  float **ppfStack_31c;
  undefined4 uStack_318;
  float *****pppppfStack_314;
  float *****pppppfStack_310;
  float ***pppfStack_30c;
  undefined4 uStack_308;
  float *****pppppfStack_304;
  float *****pppppfStack_300;
  float *****pppppfStack_2fc;
  float ****ppppfStack_2f8;
  float ***pppfStack_2f4;
  float *****pppppfStack_2f0;
  float *****pppppfStack_2ec;
  float ****ppppfStack_2e8;
  undefined4 uStack_2e4;
  float ****ppppfStack_2e0;
  float ****ppppfStack_2dc;
  float *****pppppfStack_2d8;
  float ****ppppfStack_2d4;
  float ***pppfStack_2d0;
  float *****pppppfStack_2cc;
  float *****pppppfStack_2c8;
  float ****ppppfStack_2c4;
  undefined4 uStack_2c0;
  float *****pppppfStack_2bc;
  float ****ppppfStack_2b8;
  float *****pppppfStack_2b4;
  float ****ppppfStack_2b0;
  float ***pppfStack_2ac;
  float *****pppppfStack_2a8;
  float *****pppppfStack_2a4;
  float ****ppppfStack_2a0;
  undefined4 uStack_29c;
  float ****ppppfStack_298;
  float ****ppppfStack_294;
  float *****pppppfStack_290;
  float ****ppppfStack_28c;
  float ***pppfStack_288;
  float *****pppppfStack_284;
  float ***pppfStack_280;
  float *****pppppfStack_27c;
  float *****pppppfStack_278;
  float ****ppppfStack_274;
  float *****pppppfStack_270;
  float ******ppppppfStack_26c;
  float *****pppppfStack_268;
  float *****pppppfStack_264;
  float *****pppppfStack_260;
  float *****pppppfStack_25c;
  float *****pppppfStack_258;
  float *****pppppfStack_254;
  float *****pppppfStack_250;
  float *****pppppfStack_24c;
  float ******ppppppfStack_248;
  float *****pppppfStack_244;
  float *****pppppfStack_240;
  float ******ppppppfStack_23c;
  undefined4 uStack_238;
  float *****pppppfStack_234;
  undefined *puStack_230;
  float ******ppppppfStack_22c;
  float *****pppppfStack_228;
  code *pcStack_224;
  uint uStack_220;
  float ****ppppfStack_21c;
  float *****pppppfStack_218;
  int iStack_214;
  int iStack_210;
  int iStack_20c;
  int iStack_208;
  float *****pppppfStack_1e4;
  float *****pppppfStack_1e0;
  float *****pppppfStack_1dc;
  uint uStack_1d8;
  float ***pppfStack_1d0;
  float ***pppfStack_1cc;
  undefined4 uStack_1b8;
  float *****pppppfStack_1b4;
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  float *****pppppfStack_1a4;
  undefined4 uStack_1a0;
  float ***pppfStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_18c;
  float **ppfStack_188;
  float ***pppfStack_184;
  undefined4 uStack_180;
  float *****pppppfStack_17c;
  float ***pppfStack_178;
  float *****pppppfStack_174;
  float *****pppppfStack_170;
  float *****pppppfStack_16c;
  float ****ppppfStack_168;
  float ****ppppfStack_164;
  float ****ppppfStack_160;
  float **ppfStack_15c;
  float ****ppppfStack_158;
  float **ppfStack_154;
  undefined4 *puStack_150;
  float **ppfStack_14c;
  float ****ppppfStack_148;
  undefined4 *puStack_144;
  float **ppfStack_140;
  float **ppfStack_13c;
  float **ppfStack_138;
  float ***pppfStack_134;
  float **ppfStack_130;
  float ***pppfStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  float **ppfStack_120;
  float **ppfStack_11c;
  float **ppfStack_118;
  float **ppfStack_114;
  float **ppfStack_110;
  float ****ppppfStack_10c;
  float **ppfStack_108;
  undefined *puStack_104;
  float ******ppppppfStack_100;
  float *****local_f0;
  float **local_d4 [12];
  float *****local_a4;
  float ***local_a0;
  undefined4 local_98;
  float ***local_94;
  undefined4 local_90;
  undefined4 local_88;
  undefined4 local_84;
  float ***local_80;
  undefined4 local_78;
  undefined4 local_74;
  float **local_70;
  float **local_6c;
  float ***local_68;
  undefined4 local_64;
  float **local_60;
  float *****local_5c;
  float *****local_58;
  float **local_54 [4];
  float **local_44;
  undefined4 local_40;
  float ***local_3c;
  undefined4 local_38;
  float **local_34 [2];
  float local_2c;
  float local_24;
  float local_20;
  uint local_1c;
  uint local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined1 *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff04;
  local_8 = &LAB_00402570;
  local_20 = 0.0;
  local_24 = 0.0;
  local_34[0] = (float **)0x0;
  local_44 = (float **)0x0;
  local_54[0] = (float **)0x0;
  local_64 = 0;
  local_74 = 0;
  local_84 = 0;
  local_94 = (float ***)0x0;
  local_a4 = (float *****)0x0;
  local_d4[0] = (float **)0x0;
  DAT_0050b3c2 = 0;
  ExceptionList = &pvStack_14;
  puVar10 = &stack0xffffff04;
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_100 = (float ******)&DAT_0050b420;
    puStack_104 = &DAT_00408c88;
    ppfStack_108 = (float **)0x4ed638;
    ExceptionList = &pvStack_14;
    __vbaNew2();
    puVar10 = local_c;
  }
  local_c = puVar10;
  ppppppfStack_100 = (float ******)DAT_0050b420;
  puStack_104 = (undefined *)0x4ed646;
  puStack_104 = (undefined *)(*(code *)(*DAT_0050b420)[0xea])();
  ppfStack_108 = (float **)local_d4;
  ppppfStack_10c = (float ****)0x4ed654;
  __vbaObjSet();
  sVar11 = DAT_0050b332;
  pcVar23 = __vbaGenerateBoundsError_exref;
  local_18 = 1;
  pppppppfVar24 = DAT_0050b3cc;
  uVar25 = local_18;
  do {
    local_18 = uVar25;
    uVar20 = local_18;
    local_f0 = (float *****)0x0;
    if (sVar11 < (short)local_18) {
      ppfStack_110 = (float **)local_d4;
      ppppfStack_10c = (float ****)0x0;
      ppfStack_114 = (float **)0x4edd9f;
      __vbaObjSetAddref();
LAB_004eddcc:
      puStack_150 = (undefined4 *)&LAB_004eddd9;
      ppfStack_154 = (float **)0x4eddd8;
      __vbaFreeObj();
      return;
    }
    if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
      ppppfStack_10c = (float ****)0x4ed6c9;
      iVar12 = __vbaGenerateBoundsError();
      pppppppfVar24 = DAT_0050b3cc;
    }
    else {
      local_f0 = (float *****)((int)(short)local_18 - (int)pppppppfVar24[7]);
      if (pppppppfVar24[6] <= local_f0) {
        ppppfStack_10c = (float ****)0x4ed69d;
        __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      ppppppfVar19 = pppppppfVar24[5];
      if (pppppppfVar24[4] <= (float ******)-(int)ppppppfVar19) {
        ppppfStack_10c = (float ****)0x4ed6b1;
        __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      iVar12 = (int)((int)local_f0 + (int)pppppppfVar24[6] * -(int)ppppppfVar19) * 4;
      uVar20 = local_18;
    }
    sVar6 = DAT_0050b332;
    if (*(float *)((int)pppppppfVar24[3] + iVar12) != _DAT_00402558) {
      local_20 = (float)_DAT_0050b134;
      local_1c = 1;
      uVar25 = local_1c;
      while( true ) {
        local_1c = uVar25;
        sVar18 = (short)uVar20;
        if (sVar6 < (short)local_1c) break;
        if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
          ppppfStack_10c = (float ****)0x4ed744;
          iVar12 = __vbaGenerateBoundsError();
          pppppppfVar24 = DAT_0050b3cc;
        }
        else {
          uVar25 = (int)(short)local_1c - *(int *)(DAT_0050b3d8 + 10);
          if (*(uint *)(DAT_0050b3d8 + 8) <= uVar25) {
            ppppfStack_10c = (float ****)0x4ed733;
            __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          iVar12 = uVar25 * 4;
        }
        local_f0 = *(float ******)(DAT_0050b3d8 + 6);
        if (*(float *)((int)local_f0 + iVar12) == _DAT_00401488) {
          if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
            ppppfStack_10c = (float ****)0x4ed7b2;
            iVar12 = __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            ppppppfVar19 = pppppppfVar24[7];
            if (pppppppfVar24[6] <= (float ******)((int)sVar18 - (int)ppppppfVar19)) {
              ppppfStack_10c = (float ****)0x4ed782;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            local_f0 = (float *****)((int)(short)local_1c - (int)pppppppfVar24[5]);
            if (pppppppfVar24[4] <= local_f0) {
              ppppfStack_10c = (float ****)0x4ed79a;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (int)((int)pppppppfVar24[6] * (int)local_f0 + ((int)sVar18 - (int)ppppppfVar19)
                          ) * 4;
            uVar20 = local_18;
          }
          uVar27 = 0;
          if (*(float *)((int)pppppppfVar24[3] + iVar12) != _DAT_00401488) {
            if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
              ppppfStack_10c = (float ****)0x4ed81a;
              iVar12 = __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            else {
              ppppppfVar19 = (float ******)((int)(short)uVar20 - (int)pppppppfVar24[7]);
              if (pppppppfVar24[6] <= ppppppfVar19) {
                ppppfStack_10c = (float ****)0x4ed7ea;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              local_f0 = (float *****)((int)(short)local_1c - (int)pppppppfVar24[5]);
              if (pppppppfVar24[4] <= local_f0) {
                ppppfStack_10c = (float ****)0x4ed802;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              iVar12 = (int)((int)pppppppfVar24[6] * (int)local_f0 + (int)ppppppfVar19) * 4;
              uVar20 = local_18;
            }
            if (*(float *)((int)pppppppfVar24[3] + iVar12) == _DAT_00401488) goto LAB_004ed83d;
            goto LAB_004eda59;
          }
        }
        else {
LAB_004ed83d:
          if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
            ppppfStack_10c = (float ****)0x4ed86a;
            iVar12 = __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            iVar26 = (int)(short)local_1c;
            iVar12 = *(int *)(DAT_0050b3d8 + 10);
            if (*(uint *)(DAT_0050b3d8 + 8) <= (uint)(iVar26 - iVar12)) {
              ppppfStack_10c = (float ****)0x4ed859;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (iVar26 - iVar12) * 4;
          }
          local_f0 = *(float ******)(DAT_0050b3d8 + 6);
          if (*(float *)((int)local_f0 + iVar12) != _DAT_00401488) {
            if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
              ppppfStack_10c = (float ****)0x4ed8d4;
              iVar12 = __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            else {
              ppppppfVar19 = (float ******)((int)(short)uVar20 - (int)pppppppfVar24[7]);
              if (pppppppfVar24[6] <= ppppppfVar19) {
                ppppfStack_10c = (float ****)0x4ed8a4;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              local_f0 = (float *****)((int)(short)local_1c - (int)pppppppfVar24[5]);
              if (pppppppfVar24[4] <= local_f0) {
                ppppfStack_10c = (float ****)0x4ed8bc;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              iVar12 = (int)((int)pppppppfVar24[6] * (int)local_f0 + (int)ppppppfVar19) * 4;
              uVar20 = local_18;
            }
            uVar27 = 0;
            if (*(float *)((int)pppppppfVar24[3] + iVar12) == _DAT_00401488) goto LAB_004ed9f7;
          }
          uVar27 = 0;
          if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
            ppppfStack_10c = (float ****)0x4ed92a;
            local_f0 = (float *****)__vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            iVar26 = (int)(short)local_1c;
            iVar12 = *(int *)(DAT_0050b3d8 + 10);
            if (*(uint *)(DAT_0050b3d8 + 8) <= (uint)(iVar26 - iVar12)) {
              ppppfStack_10c = (float ****)0x4ed913;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            local_f0 = (float *****)((iVar26 - iVar12) * 4);
          }
          if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
            ppppfStack_10c = (float ****)0x4ed981;
            iVar12 = __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            ppppppfVar19 = (float ******)((int)(short)uVar20 - (int)pppppppfVar24[7]);
            if (pppppppfVar24[6] <= ppppppfVar19) {
              ppppfStack_10c = (float ****)0x4ed951;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (int)(short)local_1c;
            ppppppfVar22 = pppppppfVar24[5];
            if (pppppppfVar24[4] <= (float ******)(iVar12 - (int)ppppppfVar22)) {
              ppppfStack_10c = (float ****)0x4ed969;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (int)((int)pppppppfVar24[6] * (iVar12 - (int)ppppppfVar22) + (int)ppppppfVar19)
                     * 4;
            uVar20 = local_18;
          }
          local_2c = *(float *)((int)local_f0 + *(int *)(DAT_0050b3d8 + 6)) -
                     *(float *)((int)pppppppfVar24[3] + iVar12);
          local_6c = (float **)&local_20;
          if ((uVar27 & 0xd) != 0) {
            __vbaFPException();
            return;
          }
          ppppfStack_10c = (float ****)local_34;
          local_34[0] = (float **)0x4;
          local_74 = 0x4004;
          ppfStack_118 = (float **)0x4ed9d1;
          ppfStack_114 = (float **)&local_44;
          ppfStack_110 = (float **)&local_74;
          FUN_0042b040();
          ppfStack_118 = (float **)&local_44;
          ppfStack_11c = (float **)0x4ed9db;
          fVar28 = (float10)__vbaR4Var();
          local_20 = (float)fVar28;
          ppfStack_11c = (float **)&local_44;
          ppfStack_120 = (float **)local_34;
          uStack_124 = 2;
          uStack_128 = 0x4ed9ee;
          __vbaFreeVarList();
          pppppppfVar24 = DAT_0050b3cc;
        }
LAB_004ed9f7:
        uVar25 = (uint)(ushort)((short)local_1c + 1);
        if (SCARRY2((short)local_1c,1)) goto LAB_004eddef;
      }
      if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
        ppppfStack_10c = (float ****)0x4eda3a;
        iVar12 = __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      else {
        iVar12 = *(int *)(DAT_0050b3d8 + 10);
        if (*(uint *)(DAT_0050b3d8 + 8) <= (uint)(sVar18 - iVar12)) {
          ppppfStack_10c = (float ****)0x4eda29;
          __vbaGenerateBoundsError();
          pppppppfVar24 = DAT_0050b3cc;
        }
        iVar12 = (sVar18 - iVar12) * 4;
      }
      local_f0 = *(float ******)(DAT_0050b3d8 + 6);
      uVar27 = 0;
      if (*(float *)((int)local_f0 + iVar12) == _DAT_00401488) {
        if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
          ppppfStack_10c = (float ****)0x4eda99;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          iVar12 = *(int *)(DAT_0050b3d8 + 10);
          if (*(uint *)(DAT_0050b3d8 + 8) <= (uint)(sVar18 - iVar12)) {
            ppppfStack_10c = (float ****)0x4eda8e;
            __vbaGenerateBoundsError();
          }
          iVar12 = (sVar18 - iVar12) * 4;
        }
        pcVar23 = __vbaLateIdCallLd_exref;
        ppppfStack_10c = (float ****)0x0;
        ppfStack_110 = (float **)0xa;
        *(float *)(*(int *)(DAT_0050b3d8 + 6) + iVar12) = local_20;
        ppfStack_118 = (float **)local_34;
        ppfStack_114 = local_d4[0];
        ppfStack_11c = (float **)0x4edabf;
        ppppfStack_10c = (float ****)__vbaLateIdCallLd();
        local_f0 = (float *****)__vbaI4Var_exref;
        ppfStack_110 = (float **)0x4edacb;
        iVar12 = __vbaI4Var();
        if (!SCARRY4(iVar12,1)) {
          local_74 = 3;
          ppfStack_11c = (float **)0xa;
          ppfStack_118 = (float **)0x3;
          ppfStack_114 = local_70;
          ppfStack_120 = local_d4[0];
          ppppfStack_10c = (float ****)local_68;
          uStack_124 = 0x4edb04;
          ppfStack_110 = (float **)(iVar12 + 1);
          local_6c = (float **)(iVar12 + 1);
          __vbaLateIdSt();
          uStack_124 = 0x4edb0d;
          __vbaFreeVar();
          uStack_124 = 0;
          uStack_128 = 10;
          ppfStack_130 = (float **)local_34;
          pppfStack_12c = (float ***)local_d4[0];
          pppfStack_134 = (float ***)0x4edb1e;
          uStack_124 = __vbaLateIdCallLd();
          uStack_128 = 0x4edb24;
          local_6c = (float **)__vbaI4Var();
          uStack_128 = CONCAT22(extraout_var,DAT_0050b244);
          local_74 = 3;
          local_94 = (float ***)0x3;
          pppfStack_12c = (float ***)0x4edb4b;
          puStack_150 = (undefined4 *)__vbaStrI2();
          local_44 = (float **)0x8;
          ppfStack_138 = (float **)local_74;
          pppfStack_134 = (float ***)local_70;
          ppfStack_130 = local_6c;
          pppfStack_12c = local_68;
          ppppfStack_148 = (float ****)local_94;
          puStack_144 = (undefined4 *)local_90;
          ppfStack_140 = (float **)0x4;
          ppfStack_13c = (float **)local_88;
          ppppfStack_158 = (float ****)0x8;
          ppfStack_154 = (float **)local_40;
          ppfStack_15c = (float **)0x2;
          ppppfStack_160 = (float ****)0x41;
          ppppfStack_164 = (float ****)local_d4[0];
          ppfStack_14c = (float **)local_38;
          ppppfStack_168 = (float ****)0x4edbbf;
          local_3c = (float ***)puStack_150;
          __vbaLateIdCallSt();
          ppppfStack_168 = (float ****)&local_44;
          pppppfStack_16c = (float *****)local_34;
          pppppfStack_170 = (float *****)0x2;
          pppppfStack_174 = (float *****)0x4edbcf;
          __vbaFreeVarList();
          ppfStack_138 = (float **)local_34;
          pppfStack_12c = (float ***)0x0;
          ppfStack_130 = (float **)0xa;
          pppfStack_134 = (float ***)local_d4[0];
          ppfStack_13c = (float **)0x4edbe3;
          pppfStack_12c = (float ***)__vbaLateIdCallLd();
          ppfStack_130 = (float **)0x4edbe9;
          local_6c = (float **)__vbaI4Var();
          ppfStack_130 = (float **)local_18;
          local_74 = 3;
          pppfStack_134 = (float ***)0x4edbfd;
          ppppfStack_158 = (float ****)__vbaStrI2();
          local_44 = (float **)0x8;
          ppfStack_140 = (float **)local_74;
          ppfStack_13c = local_70;
          ppfStack_138 = local_6c;
          pppfStack_134 = local_68;
          puStack_150 = (undefined4 *)0x3;
          ppfStack_14c = (float **)local_90;
          ppppfStack_148 = (float ****)0x5;
          puStack_144 = (undefined4 *)local_88;
          ppppfStack_164 = (float ****)0x2;
          ppppfStack_168 = (float ****)0x41;
          ppppfStack_160 = (float ****)0x8;
          ppfStack_15c = (float **)local_40;
          pppppfStack_16c = (float *****)local_d4[0];
          ppfStack_154 = (float **)local_38;
          pppppfStack_170 = (float *****)0x4edc6f;
          local_3c = (float ***)ppppfStack_158;
          __vbaLateIdCallSt();
          pppppfStack_170 = (float *****)&local_44;
          pppppfStack_174 = (float *****)local_34;
          pppfStack_178 = (float ***)0x2;
          pppppfStack_17c = (float *****)0x4edc7f;
          __vbaFreeVarList();
          pppfStack_134 = (float ***)0x4edc87;
          FUN_0044fdc0();
          pppfStack_134 = (float ***)0x4edc92;
          __vbaStrMove();
          pppfStack_134 = (float ***)0x0;
          ppfStack_138 = (float **)0xa;
          ppfStack_13c = local_d4[0];
          ppfStack_140 = (float **)local_54;
          puStack_144 = (undefined4 *)0x4edca3;
          pppfStack_134 = (float ***)__vbaLateIdCallLd();
          ppfStack_138 = (float **)0x4edca9;
          uVar13 = __vbaI4Var();
          local_2c = local_24;
          local_6c = (float **)&local_20;
          ppfStack_138 = (float **)0x1;
          ppfStack_140 = (float **)local_34;
          ppfStack_13c = (float **)0x1;
          puStack_144 = &local_74;
          ppppfStack_148 = (float ****)&local_44;
          local_a4 = (float *****)0x3;
          local_24 = 0.0;
          local_34[0] = (float **)0x8;
          local_74 = 0x4004;
          ppfStack_14c = (float **)0x4edced;
          Ordinal_660();
          ppfStack_14c = (float **)&local_44;
          puStack_150 = (undefined4 *)0x4edcf7;
          pppppfStack_174 = (float *****)__vbaStrVarMove();
          local_64 = 8;
          ppfStack_15c = (float **)0x3;
          ppppfStack_158 = (float ****)local_80;
          puStack_150 = (undefined4 *)local_78;
          pppppfStack_16c = local_a4;
          ppppfStack_168 = (float ****)local_a0;
          ppppfStack_164 = (float ****)0x6;
          ppppfStack_160 = (float ****)local_98;
          uStack_180 = 2;
          pppfStack_184 = (float ***)0x41;
          pppppfStack_17c = (float *****)0x8;
          pppfStack_178 = (float ***)local_60;
          ppfStack_188 = local_d4[0];
          pppppfStack_170 = local_58;
          uStack_18c = 0x4edd62;
          ppfStack_154 = (float **)uVar13;
          local_5c = pppppfStack_174;
          __vbaLateIdCallSt();
          puStack_150 = (undefined4 *)0x4edd6e;
          __vbaFreeStr();
          puStack_150 = &local_64;
          ppfStack_154 = (float **)&local_44;
          ppppfStack_158 = (float ****)local_54;
          ppfStack_15c = (float **)local_34;
          ppppfStack_160 = (float ****)0x4;
          ppppfStack_164 = (float ****)0x4edd86;
          __vbaFreeVarList();
          goto LAB_004eddcc;
        }
        break;
      }
    }
LAB_004eda59:
    uVar27 = 0;
    uVar25 = (uint)(ushort)((short)uVar20 + 1);
  } while (!SCARRY2((short)uVar20,1));
LAB_004eddef:
  ppppfStack_10c = (float ****)0x4eddf5;
  __vbaErrorOverflow();
  ppfStack_118 = (float **)&DAT_00402706;
  ppfStack_11c = ExceptionList;
  ppfStack_114 = (float **)&pppppfStack_228;
  ppfStack_110 = (float **)&DAT_00402580;
  pppfStack_134 = (float ***)0x0;
  ppfStack_138 = (float **)0x0;
  ppppfStack_148 = (float ****)0x0;
  ppppfStack_158 = (float ****)0x0;
  ppppfStack_168 = (float ****)0x0;
  pppfStack_178 = (float ***)0x0;
  ppfStack_188 = (float **)0x0;
  uStack_198 = 0;
  uStack_1a8 = 0;
  uStack_1b8 = 0;
  pppppfStack_1e4 = (float *****)0x0;
  pppppfStack_228 = local_f0;
  pcStack_224 = pcVar23;
  uStack_220 = uVar20;
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_22c = (float ******)0x4edeb7;
    ExceptionList = &ppfStack_11c;
    ppppfStack_10c = (float ****)&stack0xfffffffc;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    uStack_1d8 = -*(int *)(DAT_0050b19c + 0xe);
    ExceptionList = &ppfStack_11c;
    ppfStack_114 = (float **)&pppppfStack_228;
    ppppfStack_10c = (float ****)&stack0xfffffffc;
    if (*(uint *)(DAT_0050b19c + 0xc) <= uStack_1d8) {
      ppppppfStack_22c = (float ******)0x4ede84;
      ExceptionList = &ppfStack_11c;
      ppfStack_114 = (float **)&pppppfStack_228;
      ppppfStack_10c = (float ****)&stack0xfffffffc;
      __vbaGenerateBoundsError();
    }
    iVar12 = *(int *)(DAT_0050b19c + 10);
    if (*(uint *)(DAT_0050b19c + 8) <= (uint)-iVar12) {
      ppppppfStack_22c = (float ******)0x4ede97;
      __vbaGenerateBoundsError();
    }
    iVar12 = (*(int *)(DAT_0050b19c + 0xc) * -iVar12 + uStack_1d8) * 4;
  }
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_22c = (float ******)0x4edf07;
    iVar26 = __vbaGenerateBoundsError();
  }
  else {
    pppfStack_1d0 = (float ***)-*(int *)(DAT_0050b19c + 0xe);
    if (*(float *****)(DAT_0050b19c + 0xc) <= pppfStack_1d0) {
      ppppppfStack_22c = (float ******)0x4ededc;
      __vbaGenerateBoundsError();
    }
    iVar26 = *(int *)(DAT_0050b19c + 10);
    if (*(uint *)(DAT_0050b19c + 8) <= (uint)-iVar26) {
      ppppppfStack_22c = (float ******)0x4edeef;
      __vbaGenerateBoundsError();
    }
    iVar26 = (int)(*(int *)(DAT_0050b19c + 0xc) * -iVar26 + (int)pppfStack_1d0) * 4;
  }
  *(float *)(*(int *)(DAT_0050b19c + 6) + iVar26) =
       *(float *)(*(int *)(DAT_0050b19c + 6) + iVar12) + _DAT_00402478;
  if ((uVar27 & 0xd) != 0) {
LAB_004eedc1:
    __vbaFPException();
    return;
  }
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_22c = (float ******)0x4edf6e;
    __vbaGenerateBoundsError();
  }
  else {
    if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-*(int *)(DAT_0050b19c + 0xe)) {
      ppppppfStack_22c = (float ******)0x4edf45;
      __vbaGenerateBoundsError();
    }
    if (*(uint *)(DAT_0050b19c + 8) <= (uint)-*(int *)(DAT_0050b19c + 10)) {
      ppppppfStack_22c = (float ******)0x4edf59;
      __vbaGenerateBoundsError();
    }
  }
  ppppppfStack_22c = (float ******)0x4edf80;
  ppfStack_130 = (float **)__vbaFpI2();
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_22c = (float ******)0x4edfd2;
    __vbaGenerateBoundsError();
  }
  else {
    if (*(uint *)(DAT_0050b19c + 0xc) <=
        (uint)((int)(short)ppfStack_130 - *(int *)(DAT_0050b19c + 0xe))) {
      ppppppfStack_22c = (float ******)0x4edfa4;
      __vbaGenerateBoundsError();
    }
    if (*(uint *)(DAT_0050b19c + 8) <= 1U - *(int *)(DAT_0050b19c + 10)) {
      ppppppfStack_22c = (float ******)0x4edfbd;
      __vbaGenerateBoundsError();
    }
  }
  ppppppfStack_22c = (float ******)0x4edfe4;
  uVar13 = __vbaFpI2();
  uStack_128 = uVar13;
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_22c = (float ******)0x4ee03c;
    __vbaGenerateBoundsError();
  }
  else {
    if (*(uint *)(DAT_0050b19c + 0xc) <=
        (uint)((int)(short)ppfStack_130 - *(int *)(DAT_0050b19c + 0xe))) {
      ppppppfStack_22c = (float ******)0x4ee00b;
      __vbaGenerateBoundsError();
    }
    uVar13 = uStack_128;
    if (*(uint *)(DAT_0050b19c + 8) <= 2U - *(int *)(DAT_0050b19c + 10)) {
      ppppppfStack_22c = (float ******)0x4ee024;
      __vbaGenerateBoundsError();
      uVar13 = uStack_128;
    }
  }
  ppppppfStack_22c = (float ******)0x4ee04e;
  pppfStack_12c = (float ***)__vbaFpI2();
  if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
    ppppppfStack_22c = (float ******)0x4ee083;
    iStack_208 = __vbaGenerateBoundsError();
  }
  else {
    uVar25 = (int)(short)pppfStack_12c - *(int *)(DAT_0050b3d8 + 10);
    if (*(uint *)(DAT_0050b3d8 + 8) <= uVar25) {
      ppppppfStack_22c = (float ******)0x4ee072;
      __vbaGenerateBoundsError();
    }
    iStack_208 = uVar25 * 4;
  }
  if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
    ppppppfStack_22c = (float ******)0x4ee0b4;
    iStack_20c = __vbaGenerateBoundsError();
  }
  else {
    ppppppfVar19 = (float ******)((int)(short)uVar13 - (int)DAT_0050b3d4[5]);
    if (DAT_0050b3d4[4] <= ppppppfVar19) {
      ppppppfStack_22c = (float ******)0x4ee0a9;
      __vbaGenerateBoundsError();
    }
    iStack_20c = (int)ppppppfVar19 * 4;
  }
  if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
    ppppppfStack_22c = (float ******)0x4ee105;
    iStack_210 = __vbaGenerateBoundsError();
  }
  else {
    ppppppfVar19 = (float ******)((int)(short)uVar13 - (int)DAT_0050b3cc[7]);
    if (DAT_0050b3cc[6] <= ppppppfVar19) {
      ppppppfStack_22c = (float ******)0x4ee0da;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)(short)pppfStack_12c;
    ppppppfVar22 = DAT_0050b3cc[5];
    if (DAT_0050b3cc[4] <= (float ******)(iVar12 - (int)ppppppfVar22)) {
      ppppppfStack_22c = (float ******)0x4ee0f1;
      __vbaGenerateBoundsError();
    }
    iStack_210 = (int)((int)DAT_0050b3cc[6] * (iVar12 - (int)ppppppfVar22) + (int)ppppppfVar19) * 4;
  }
  if ((DAT_0050b3e4 == (float *****)0x0) || (*(short *)DAT_0050b3e4 != 2)) {
    ppppppfStack_22c = (float ******)0x4ee15b;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    iVar12 = (int)(short)ppfStack_130;
    ppppfVar1 = DAT_0050b3e4[7];
    if (DAT_0050b3e4[6] <= (float ****)(iVar12 - (int)ppppfVar1)) {
      ppppppfStack_22c = (float ******)0x4ee12d;
      __vbaGenerateBoundsError();
    }
    ppppfVar2 = DAT_0050b3e4[5];
    if (DAT_0050b3e4[4] <= (float ****)(1U - (int)ppppfVar2)) {
      ppppppfStack_22c = (float ******)0x4ee146;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)DAT_0050b3e4[6] * (int)(1U - (int)ppppfVar2) + (iVar12 - (int)ppppfVar1)) *
             4;
  }
  *(float *)((int)DAT_0050b3e4[3] + iVar12) =
       (*(float *)(*(int *)(DAT_0050b3d8 + 6) + iStack_208) -
       *(float *)((int)DAT_0050b3d4[3] + iStack_20c)) -
       *(float *)((int)DAT_0050b3cc[3] + iStack_210);
  if ((uVar27 & 0xd) != 0) goto LAB_004eedc1;
  if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
    ppppppfStack_22c = (float ******)0x4ee1de;
    iStack_214 = __vbaGenerateBoundsError();
  }
  else {
    iVar12 = (int)(short)pppfStack_12c;
    ppppppfVar19 = DAT_0050b3d4[5];
    if (DAT_0050b3d4[4] <= (float ******)(iVar12 - (int)ppppppfVar19)) {
      ppppppfStack_22c = (float ******)0x4ee1c8;
      __vbaGenerateBoundsError();
    }
    iStack_214 = (iVar12 - (int)ppppppfVar19) * 4;
  }
  if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
    ppppppfStack_22c = (float ******)0x4ee216;
    pppppfStack_218 = (float *****)__vbaGenerateBoundsError();
  }
  else {
    iVar12 = (int)(short)uStack_128;
    ppppppfVar19 = DAT_0050b3d4[5];
    if (DAT_0050b3d4[4] <= (float ******)(iVar12 - (int)ppppppfVar19)) {
      ppppppfStack_22c = (float ******)0x4ee205;
      __vbaGenerateBoundsError();
    }
    pppppfStack_218 = (float *****)((iVar12 - (int)ppppppfVar19) * 4);
  }
  if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
    ppppppfStack_22c = (float ******)0x4ee281;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    pppppfStack_1e0 = (float *****)((int)(short)uStack_128 - (int)DAT_0050b3cc[7]);
    if (DAT_0050b3cc[6] <= pppppfStack_1e0) {
      ppppppfStack_22c = (float ******)0x4ee244;
      __vbaGenerateBoundsError();
    }
    pppppfStack_1dc = (float *****)((int)(short)pppfStack_12c - (int)DAT_0050b3cc[5]);
    if (DAT_0050b3cc[4] <= pppppfStack_1dc) {
      ppppppfStack_22c = (float ******)0x4ee262;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)DAT_0050b3cc[6] * (int)pppppfStack_1dc + (int)pppppfStack_1e0) * 4;
  }
  if ((DAT_0050b3e4 == (float *****)0x0) || (*(short *)DAT_0050b3e4 != 2)) {
    ppppppfStack_22c = (float ******)0x4ee2fd;
    iVar26 = __vbaGenerateBoundsError();
  }
  else {
    pppfStack_1d0 = (float ***)((int)(short)ppfStack_130 - (int)DAT_0050b3e4[7]);
    if (DAT_0050b3e4[6] <= pppfStack_1d0) {
      ppppppfStack_22c = (float ******)0x4ee2b1;
      __vbaGenerateBoundsError();
    }
    pppfStack_1cc = (float ***)(2 - (int)DAT_0050b3e4[5]);
    if (DAT_0050b3e4[4] <= pppfStack_1cc) {
      ppppppfStack_22c = (float ******)0x4ee2d6;
      __vbaGenerateBoundsError();
    }
    iVar26 = (int)((int)DAT_0050b3e4[6] * (int)pppfStack_1cc + (int)pppfStack_1d0) * 4;
  }
  ppppppfVar19 = (float ******)pppppfStack_218;
  *(float *)((int)DAT_0050b3e4[3] + iVar26) =
       (*(float *)(iStack_214 + (int)DAT_0050b3d4[3]) -
       *(float *)((int)pppppfStack_218 + (int)DAT_0050b3d4[3])) -
       *(float *)((int)DAT_0050b3cc[3] + iVar12);
  if ((uVar27 & 0xd) != 0) goto LAB_004eedc1;
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_22c = (float ******)&DAT_0050b420;
    puStack_230 = &DAT_00408c88;
    pppppfStack_234 = (float *****)0x4ee354;
    __vbaNew2();
  }
  ppppppfStack_22c = (float ******)DAT_0050b420;
  puStack_230 = (undefined *)0x4ee362;
  puStack_230 = (undefined *)(*(code *)(*DAT_0050b420)[0xea])();
  pppppfStack_234 = (float *****)&pppppfStack_1e4;
  uStack_238 = 0x4ee370;
  __vbaObjSet();
  pcVar23 = __vbaLateIdCallLd_exref;
  uStack_238 = 0;
  ppppppfStack_23c = (float ******)0x4;
  pppppfStack_244 = &ppppfStack_148;
  pppppfStack_240 = pppppfStack_1e4;
  ppppppfStack_248 = (float ******)0x4ee387;
  uStack_238 = __vbaLateIdCallLd();
  pcVar21 = __vbaI4Var_exref;
  ppppppfStack_23c = (float ******)0x4ee393;
  iVar12 = __vbaI4Var();
  pcVar7 = __vbaLateIdSt_exref;
  if (!SCARRY4(iVar12,1)) {
    pppfStack_178 = (float ***)0x3;
    pppppfStack_24c = (float *****)0x4;
    ppppppfStack_248 = (float ******)0x3;
    pppppfStack_244 = pppppfStack_174;
    pppppfStack_250 = pppppfStack_1e4;
    ppppppfStack_23c = (float ******)pppppfStack_16c;
    pppppfStack_254 = (float *****)0x4ee3ce;
    pppppfStack_240 = (float *****)(iVar12 + 1);
    pppppfStack_170 = (float *****)(iVar12 + 1);
    __vbaLateIdSt();
    pppppfStack_254 = (float *****)0x4ee3d7;
    __vbaFreeVar();
    pppppfStack_254 = (float *****)0x0;
    pppppfStack_258 = (float *****)0x4;
    pppppfStack_260 = &ppppfStack_148;
    pppppfStack_25c = pppppfStack_1e4;
    pppppfStack_264 = (float *****)0x4ee3e8;
    pppppfStack_254 = (float *****)__vbaLateIdCallLd();
    pppppfStack_258 = (float *****)0x4ee3ee;
    iVar12 = __vbaI4Var();
    ppppppfVar19 = (float ******)pcVar7;
    if (!SBORROW4(iVar12,1)) {
      pppfStack_178 = (float ***)0x3;
      pppppfStack_24c = (float *****)0xa;
      ppppppfStack_248 = (float ******)0x3;
      pppppfStack_244 = pppppfStack_174;
      pppppfStack_250 = pppppfStack_1e4;
      ppppppfStack_23c = (float ******)pppppfStack_16c;
      pppppfStack_254 = (float *****)0x4ee423;
      pppppfStack_240 = (float *****)(iVar12 + -1);
      pppppfStack_170 = (float *****)(iVar12 + -1);
      __vbaLateIdSt();
      pppppfStack_254 = (float *****)0x4ee42c;
      __vbaFreeVar();
      pppppfStack_254 = (float *****)0x0;
      pppppfStack_258 = (float *****)0xa;
      pppppfStack_260 = &ppppfStack_148;
      pppppfStack_25c = pppppfStack_1e4;
      pppppfStack_264 = (float *****)0x4ee43d;
      pppppfStack_254 = (float *****)__vbaLateIdCallLd();
      pppppfStack_258 = (float *****)0x4ee443;
      __vbaI4Var();
      pppppfStack_258 = (float *****)0x4ee44b;
      ppfStack_120 = (float **)__vbaI2I4();
      pppppfStack_258 = (float *****)0x4ee457;
      __vbaFreeVar();
      pppfStack_178 = (float ***)0x3;
      pppppfStack_268 = (float *****)0xb;
      pppppfStack_264 = (float *****)0x3;
      pppppfStack_170 = (float *****)0x0;
      pppppfStack_260 = pppppfStack_174;
      ppppppfStack_26c = (float ******)pppppfStack_1e4;
      pppppfStack_25c = (float *****)0x0;
      pppppfStack_258 = pppppfStack_16c;
      pppppfStack_270 = (float *****)0x4ee485;
      __vbaLateIdSt();
      pppfStack_178 = (float ***)0x2;
      pppfStack_280 = (float ***)0x28;
      pppppfStack_27c = (float *****)0x2;
      pppppfStack_170 = (float *****)0x1;
      pppppfStack_278 = pppppfStack_174;
      pppppfStack_284 = pppppfStack_1e4;
      ppppfStack_274 = (float ****)0x1;
      pppppfStack_270 = pppppfStack_16c;
      pppfStack_288 = (float ***)0x4ee4b6;
      __vbaLateIdSt();
      if ((DAT_0050b3e4 == (float *****)0x0) || (*(short *)DAT_0050b3e4 != 2)) {
        ppppppfStack_23c = (float ******)0x4ee512;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        iVar12 = (int)(short)ppfStack_130;
        ppppfVar1 = DAT_0050b3e4[7];
        if (DAT_0050b3e4[6] <= (float ****)(iVar12 - (int)ppppfVar1)) {
          ppppppfStack_23c = (float ******)0x4ee4dc;
          __vbaGenerateBoundsError();
        }
        ppppfVar2 = DAT_0050b3e4[5];
        if (DAT_0050b3e4[4] <= (float ****)(1U - (int)ppppfVar2)) {
          ppppppfStack_23c = (float ******)0x4ee4f9;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)((int)DAT_0050b3e4[6] * (int)(1U - (int)ppppfVar2) + (iVar12 - (int)ppppfVar1)
                      ) * 4;
      }
      if (*(float *)((int)DAT_0050b3e4[3] + iVar12) != _DAT_00401bc0) {
LAB_004ee5b0:
        ppppfStack_21c = (float ****)(int)(short)ppfStack_120;
        pppppfStack_240 = (float *****)&pppfStack_134;
        ppppppfStack_23c = (float ******)DAT_0050b3d0;
        pppfStack_178 = (float ***)0x3;
        pppppfStack_244 = (float *****)0x4ee5d7;
        pppppfStack_170 = (float *****)ppppfStack_21c;
        __vbaAryLock();
        if ((pppfStack_134 == (float ***)0x0) || (*(short *)pppfStack_134 != 1)) {
          pppppfStack_244 = (float *****)0x4ee60c;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          iVar12 = (int)(short)ppfStack_130;
          ppfVar3 = pppfStack_134[5];
          if (pppfStack_134[4] <= (float **)(iVar12 - (int)ppfVar3)) {
            pppppfStack_244 = (float *****)0x4ee5fa;
            __vbaGenerateBoundsError();
          }
          iVar12 = (iVar12 - (int)ppfVar3) * 4;
        }
        pppppfStack_250 = (float *****)pppfStack_178;
        pppppfStack_268 = (float *****)((int)pppfStack_134[3] + iVar12);
        pppppfStack_24c = pppppfStack_174;
        ppppppfStack_248 = (float ******)pppppfStack_170;
        pppppfStack_244 = pppppfStack_16c;
        pppppfStack_260 = (float *****)0x3;
        pppppfStack_25c = (float *****)uStack_194;
        pppppfStack_258 = (float *****)0x0;
        pppppfStack_254 = (float *****)uStack_18c;
        ppppfStack_274 = (float ****)0x2;
        pppppfStack_270 = (float *****)0x4008;
        pppppfStack_278 = (float *****)0x41;
        ppppppfStack_26c = (float ******)pppppfStack_1b4;
        pppppfStack_264 = (float *****)uStack_1ac;
        pppppfStack_27c = pppppfStack_1e4;
        pppfStack_280 = (float ***)0x4ee67d;
        __vbaLateIdCallSt();
        pppppfStack_244 = (float *****)&pppfStack_134;
        ppppppfStack_248 = (float ******)0x4ee68c;
        __vbaAryUnlock();
        ppppppfStack_248 = (float ******)0x4ee691;
        FUN_0044fdc0();
        ppppppfStack_248 = (float ******)0x4ee69c;
        __vbaStrMove();
        ppfStack_140 = ppfStack_138;
        pppppfStack_24c = (float *****)&pppfStack_134;
        ppppppfStack_248 = (float ******)DAT_0050b3cc;
        ppfStack_138 = (float **)0x0;
        ppppfStack_148 = (float ****)0x8;
        pppppfStack_250 = (float *****)0x4ee6c1;
        __vbaAryLock();
        if ((pppfStack_134 == (float ***)0x0) || (*(short *)pppfStack_134 != 2)) {
          pppppfStack_250 = (float *****)0x4ee71d;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          pppfStack_1d0 = (float ***)((int)(short)uStack_128 - (int)pppfStack_134[7]);
          if (pppfStack_134[6] <= pppfStack_1d0) {
            pppppfStack_250 = (float *****)0x4ee6ea;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)(short)pppfStack_12c;
          ppfVar3 = pppfStack_134[5];
          if (pppfStack_134[4] <= (float **)(iVar12 - (int)ppfVar3)) {
            pppppfStack_250 = (float *****)0x4ee703;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)pppfStack_134[6] * (iVar12 - (int)ppfVar3) + (int)pppfStack_1d0) * 4;
        }
        pppppfStack_170 = (float *****)((int)pppfStack_134[3] + iVar12);
        pppppfStack_250 = (float *****)0x1;
        pppppfStack_258 = &ppppfStack_148;
        pppppfStack_254 = (float *****)0x1;
        pppppfStack_25c = (float *****)&pppfStack_178;
        pppppfStack_260 = &ppppfStack_158;
        pppfStack_178 = (float ***)0x4004;
        pppppfStack_264 = (float *****)0x4ee747;
        Ordinal_660();
        pppppfStack_264 = (float *****)&pppfStack_134;
        pppppfStack_268 = (float *****)0x4ee74d;
        __vbaAryUnlock();
        pppppfStack_268 = &ppppfStack_158;
        ppppppfStack_26c = (float ******)0x4ee757;
        pppppfStack_290 = (float *****)__vbaStrVarMove();
        ppppfStack_168 = (float ****)0x8;
        pppppfStack_278 = (float *****)0x3;
        ppppfStack_274 = (float ****)pppfStack_184;
        pppppfStack_270 = (float *****)ppppfStack_21c;
        ppppppfStack_26c = (float ******)pppppfStack_17c;
        pppfStack_288 = (float ***)0x3;
        pppppfStack_284 = pppppfStack_1a4;
        pppfStack_280 = (float ***)0x1;
        pppppfStack_27c = (float *****)pppfStack_19c;
        uStack_29c = 2;
        ppppfStack_2a0 = (float ****)0x41;
        ppppfStack_298 = (float ****)0x8;
        ppppfStack_294 = ppppfStack_164;
        pppppfStack_2a4 = pppppfStack_1e4;
        ppppfStack_28c = (float ****)ppfStack_15c;
        pppppfStack_2a8 = (float *****)0x4ee7ce;
        ppppfStack_160 = (float ****)pppppfStack_290;
        __vbaLateIdCallSt();
        ppppppfStack_26c = (float ******)0x4ee7da;
        __vbaFreeStr();
        ppppppfStack_26c = (float ******)&ppppfStack_168;
        pppppfStack_270 = &ppppfStack_158;
        ppppfStack_274 = (float ****)&ppppfStack_148;
        pppppfStack_278 = (float *****)0x3;
        pppppfStack_27c = (float *****)0x4ee7ee;
        __vbaFreeVarList();
        ppppppfStack_26c = (float ******)0x4ee7f6;
        FUN_0044fdc0();
        ppppppfStack_26c = (float ******)0x4ee801;
        __vbaStrMove();
        ppfStack_140 = ppfStack_138;
        pppppfStack_270 = (float *****)&pppfStack_134;
        ppppppfStack_26c = (float ******)DAT_0050b3d4;
        ppfStack_138 = (float **)0x0;
        ppppfStack_148 = (float ****)0x8;
        ppppfStack_274 = (float ****)0x4ee826;
        __vbaAryLock();
        if ((pppfStack_134 == (float ***)0x0) || (*(short *)pppfStack_134 != 1)) {
          ppppfStack_274 = (float ****)0x4ee863;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          pppfStack_1cc = (float ***)((int)(short)uStack_128 - (int)pppfStack_134[5]);
          if (pppfStack_134[4] <= pppfStack_1cc) {
            ppppfStack_274 = (float ****)0x4ee84f;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)pppfStack_1cc << 2;
        }
        ppppfStack_274 = (float ****)0x1;
        pppppfStack_170 = (float *****)((int)pppfStack_134[3] + iVar12);
        pppppfStack_27c = &ppppfStack_148;
        pppppfStack_278 = (float *****)0x1;
        pppfStack_280 = (float ***)&pppfStack_178;
        pppppfStack_284 = &ppppfStack_158;
        pppfStack_178 = (float ***)0x4004;
        pppfStack_288 = (float ***)0x4ee887;
        Ordinal_660();
        pppfStack_288 = (float ***)&pppfStack_134;
        ppppfStack_28c = (float ****)0x4ee88d;
        __vbaAryUnlock();
        ppppfStack_28c = (float ****)&ppppfStack_158;
        pppppfStack_290 = (float *****)0x4ee897;
        pppppfStack_2b4 = (float *****)__vbaStrVarMove();
        ppppfStack_168 = (float ****)0x8;
        uStack_29c = 3;
        ppppfStack_298 = (float ****)pppfStack_184;
        ppppfStack_294 = ppppfStack_21c;
        pppppfStack_290 = pppppfStack_17c;
        pppfStack_2ac = (float ***)0x3;
        pppppfStack_2a8 = pppppfStack_1a4;
        pppppfStack_2a4 = (float *****)0x2;
        ppppfStack_2a0 = (float ****)pppfStack_19c;
        uStack_2c0 = 2;
        ppppfStack_2c4 = (float ****)0x41;
        pppppfStack_2bc = (float *****)0x8;
        ppppfStack_2b8 = ppppfStack_164;
        pppppfStack_2c8 = pppppfStack_1e4;
        ppppfStack_2b0 = (float ****)ppfStack_15c;
        pppppfStack_2cc = (float *****)0x4ee90e;
        ppppfStack_160 = (float ****)pppppfStack_2b4;
        __vbaLateIdCallSt();
        pppppfStack_290 = (float *****)0x4ee91a;
        __vbaFreeStr();
        pppppfStack_290 = &ppppfStack_168;
        ppppfStack_294 = (float ****)&ppppfStack_158;
        ppppfStack_298 = (float ****)&ppppfStack_148;
        uStack_29c = 3;
        ppppfStack_2a0 = (float ****)0x4ee92e;
        __vbaFreeVarList();
        pppppfStack_290 = (float *****)0x4ee936;
        FUN_0044fdc0();
        pppppfStack_290 = (float *****)0x4ee941;
        __vbaStrMove();
        ppfStack_140 = ppfStack_138;
        ppppfStack_294 = &pppfStack_134;
        pppppfStack_290 = (float *****)DAT_0050b3d8;
        uStack_1a0 = 4;
        ppfStack_138 = (float **)0x0;
        ppppfStack_148 = (float ****)0x8;
        ppppfStack_298 = (float ****)0x4ee970;
        __vbaAryLock();
        if ((pppfStack_134 == (float ***)0x0) || (*(short *)pppfStack_134 != 1)) {
          ppppfStack_298 = (float ****)0x4ee9ad;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          pppfStack_1cc = (float ***)((int)(short)pppfStack_12c - (int)pppfStack_134[5]);
          if (pppfStack_134[4] <= pppfStack_1cc) {
            ppppfStack_298 = (float ****)0x4ee999;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)pppfStack_1cc << 2;
        }
        ppppfStack_298 = (float ****)0x1;
        pppppfStack_170 = (float *****)((int)pppfStack_134[3] + iVar12);
        ppppfStack_2a0 = (float ****)&ppppfStack_148;
        uStack_29c = 1;
        pppppfStack_2a4 = (float *****)&pppfStack_178;
        pppppfStack_2a8 = &ppppfStack_158;
        pppfStack_178 = (float ***)0x4004;
        pppfStack_2ac = (float ***)0x4ee9d1;
        Ordinal_660();
        pppfStack_2ac = (float ***)&pppfStack_134;
        ppppfStack_2b0 = (float ****)0x4ee9d7;
        __vbaAryUnlock();
        ppppfStack_2b0 = (float ****)&ppppfStack_158;
        pppppfStack_2b4 = (float *****)0x4ee9e1;
        pppppfStack_2d8 = (float *****)__vbaStrVarMove();
        ppppfStack_168 = (float ****)0x8;
        uStack_2c0 = 3;
        pppppfStack_2bc = (float *****)pppfStack_184;
        ppppfStack_2b8 = ppppfStack_21c;
        pppppfStack_2b4 = pppppfStack_17c;
        pppfStack_2d0 = (float ***)0x3;
        pppppfStack_2cc = pppppfStack_1a4;
        pppppfStack_2c8 = (float *****)uStack_1a0;
        ppppfStack_2c4 = (float ****)pppfStack_19c;
        uStack_2e4 = 2;
        ppppfStack_2e8 = (float ****)0x41;
        ppppfStack_2e0 = (float ****)0x8;
        ppppfStack_2dc = ppppfStack_164;
        pppppfStack_2ec = pppppfStack_1e4;
        ppppfStack_2d4 = (float ****)ppfStack_15c;
        pppppfStack_2f0 = (float *****)0x4eea59;
        ppppfStack_160 = (float ****)pppppfStack_2d8;
        __vbaLateIdCallSt();
        pppppfStack_2b4 = (float *****)0x4eea65;
        __vbaFreeStr();
        pppppfStack_2b4 = &ppppfStack_168;
        ppppfStack_2b8 = (float ****)&ppppfStack_158;
        pppppfStack_2bc = &ppppfStack_148;
        uStack_2c0 = 3;
        ppppfStack_2c4 = (float ****)0x4eea79;
        __vbaFreeVarList();
        pppppfStack_2b4 = (float *****)0x4eea81;
        FUN_0044fdc0();
        pppppfStack_2b4 = (float *****)0x4eea8c;
        __vbaStrMove();
        ppfStack_140 = ppfStack_138;
        ppppfStack_2b8 = &pppfStack_134;
        pppppfStack_2b4 = DAT_0050b3e4;
        ppfStack_138 = (float **)0x0;
        ppppfStack_148 = (float ****)0x8;
        pppppfStack_2bc = (float *****)0x4eeab1;
        __vbaAryLock();
        if ((pppfStack_134 == (float ***)0x0) || (*(short *)pppfStack_134 != 2)) {
          pppppfStack_2bc = (float *****)0x4eeb1c;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          pppfStack_1d0 = (float ***)((int)(short)ppfStack_130 - (int)pppfStack_134[7]);
          if (pppfStack_134[6] <= pppfStack_1d0) {
            pppppfStack_2bc = (float *****)0x4eeada;
            __vbaGenerateBoundsError();
          }
          pppfStack_1cc = (float ***)(1 - (int)pppfStack_134[5]);
          if (pppfStack_134[4] <= pppfStack_1cc) {
            pppppfStack_2bc = (float *****)0x4eeafc;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)pppfStack_134[6] * (int)pppfStack_1cc + (int)pppfStack_1d0) * 4;
        }
        pppppfStack_2bc = (float *****)0x1;
        pppppfStack_170 = (float *****)((int)pppfStack_134[3] + iVar12);
        ppppfStack_2c4 = (float ****)&ppppfStack_148;
        uStack_2c0 = 1;
        pppppfStack_2c8 = (float *****)&pppfStack_178;
        pppppfStack_2cc = &ppppfStack_158;
        pppfStack_178 = (float ***)0x4004;
        pppfStack_2d0 = (float ***)0x4eeb40;
        Ordinal_660();
        pppfStack_2d0 = (float ***)&pppfStack_134;
        ppppfStack_2d4 = (float ****)0x4eeb46;
        __vbaAryUnlock();
        ppppfStack_2d4 = (float ****)&ppppfStack_158;
        pppppfStack_2d8 = (float *****)0x4eeb50;
        pppppfStack_2fc = (float *****)__vbaStrVarMove();
        ppppfStack_168 = (float ****)0x8;
        uStack_2e4 = 3;
        ppppfStack_2e0 = (float ****)pppfStack_184;
        ppppfStack_2dc = ppppfStack_21c;
        pppppfStack_2d8 = pppppfStack_17c;
        pppfStack_2f4 = (float ***)0x3;
        pppppfStack_2f0 = pppppfStack_1a4;
        pppppfStack_2ec = (float *****)0x5;
        ppppfStack_2e8 = (float ****)pppfStack_19c;
        uStack_308 = 2;
        pppfStack_30c = (float ***)0x41;
        pppppfStack_304 = (float *****)0x8;
        pppppfStack_300 = (float *****)ppppfStack_164;
        pppppfStack_310 = pppppfStack_1e4;
        ppppfStack_2f8 = (float ****)ppfStack_15c;
        pppppfStack_314 = (float *****)0x4eebc7;
        ppppfStack_160 = (float ****)pppppfStack_2fc;
        __vbaLateIdCallSt();
        pppppfStack_2d8 = (float *****)0x4eebd3;
        __vbaFreeStr();
        pppppfStack_2d8 = &ppppfStack_168;
        ppppfStack_2dc = (float ****)&ppppfStack_158;
        ppppfStack_2e0 = (float ****)&ppppfStack_148;
        uStack_2e4 = 3;
        ppppfStack_2e8 = (float ****)0x4eebe7;
        __vbaFreeVarList();
        pppppfStack_2d8 = (float *****)0x4eebef;
        FUN_0044fdc0();
        pppppfStack_2d8 = (float *****)0x4eebfa;
        __vbaStrMove();
        ppfStack_140 = ppfStack_138;
        ppppfStack_2dc = &pppfStack_134;
        pppppfStack_2d8 = DAT_0050b3e4;
        uStack_1a0 = 6;
        ppfStack_138 = (float **)0x0;
        ppppfStack_148 = (float ****)0x8;
        ppppfStack_2e0 = (float ****)0x4eec29;
        __vbaAryLock();
        if ((pppfStack_134 == (float ***)0x0) || (*(short *)pppfStack_134 != 2)) {
          ppppfStack_2e0 = (float ****)0x4eec94;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          pppfStack_1d0 = (float ***)((int)(short)ppfStack_130 - (int)pppfStack_134[7]);
          if (pppfStack_134[6] <= pppfStack_1d0) {
            ppppfStack_2e0 = (float ****)0x4eec52;
            __vbaGenerateBoundsError();
          }
          pppfStack_1cc = (float ***)(2 - (int)pppfStack_134[5]);
          if (pppfStack_134[4] <= pppfStack_1cc) {
            ppppfStack_2e0 = (float ****)0x4eec74;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)pppfStack_134[6] * (int)pppfStack_1cc + (int)pppfStack_1d0) * 4;
        }
        ppppfStack_2e0 = (float ****)0x1;
        pppppfStack_170 = (float *****)((int)pppfStack_134[3] + iVar12);
        ppppfStack_2e8 = (float ****)&ppppfStack_148;
        uStack_2e4 = 1;
        pppppfStack_2ec = (float *****)&pppfStack_178;
        pppppfStack_2f0 = &ppppfStack_158;
        pppfStack_178 = (float ***)0x4004;
        pppfStack_2f4 = (float ***)0x4eecb8;
        Ordinal_660();
        pppfStack_2f4 = (float ***)&pppfStack_134;
        ppppfStack_2f8 = (float ****)0x4eecbe;
        __vbaAryUnlock();
        ppppfStack_2f8 = (float ****)&ppppfStack_158;
        pppppfStack_2fc = (float *****)0x4eecc8;
        uStack_320 = __vbaStrVarMove();
        uStack_308 = 3;
        ppppfStack_168 = (float ****)0x8;
        pppppfStack_304 = (float *****)pppfStack_184;
        pppppfStack_300 = (float *****)ppppfStack_21c;
        pppppfStack_2fc = pppppfStack_17c;
        uStack_318 = 3;
        pppppfStack_314 = pppppfStack_1a4;
        pppppfStack_310 = (float *****)uStack_1a0;
        pppfStack_30c = pppfStack_19c;
        uStack_32c = 2;
        uStack_330 = 0x41;
        uStack_328 = 8;
        ppppfStack_324 = ppppfStack_164;
        pppppfStack_334 = pppppfStack_1e4;
        ppfStack_31c = ppfStack_15c;
        pcStack_338 = (code *)0x4eed3e;
        ppppfStack_160 = (float ****)uStack_320;
        __vbaLateIdCallSt();
        pppppfStack_2fc = (float *****)0x4eed4a;
        __vbaFreeStr();
        pppppfStack_2fc = &ppppfStack_168;
        pppppfStack_300 = &ppppfStack_158;
        pppppfStack_304 = &ppppfStack_148;
        uStack_308 = 3;
        pppfStack_30c = (float ***)0x4eed5e;
        __vbaFreeVarList();
        pppppfStack_300 = (float *****)&pppppfStack_1e4;
        pppppfStack_2fc = (float *****)0x0;
        pppppfStack_304 = (float *****)0x4eed70;
        __vbaObjSetAddref();
        pppppfStack_304 = (float *****)&LAB_004eedb0;
        uStack_308 = 0x4eedaf;
        __vbaFreeObj();
        return;
      }
      pcVar21 = (code *)&DAT_00000001;
      pcVar7 = (code *)0x0;
      do {
        pcVar23 = pcVar7;
        sVar11 = (short)pcVar23;
        if (6 < sVar11) goto LAB_004ee5b0;
        pppfStack_178 = (float ***)0x3;
        pppppfStack_240 = (float *****)(int)sVar11;
        ppppppfStack_248 = (float ******)0x3;
        pppppfStack_24c = (float *****)0xb;
        pppppfStack_244 = pppppfStack_174;
        pppppfStack_250 = pppppfStack_1e4;
        ppppppfStack_23c = (float ******)pppppfStack_16c;
        pppppfStack_254 = (float *****)0x4ee56f;
        pppppfStack_170 = pppppfStack_240;
        __vbaLateIdSt();
        pppfStack_178 = (float ***)0x3;
        pppppfStack_264 = (float *****)0x27;
        pppppfStack_260 = (float *****)0x3;
        pppppfStack_170 = (float *****)0xff;
        pppppfStack_25c = pppppfStack_174;
        pppppfStack_268 = pppppfStack_1e4;
        pppppfStack_258 = (float *****)0xff;
        pppppfStack_254 = pppppfStack_16c;
        ppppppfStack_26c = (float ******)0x4ee5a0;
        __vbaLateIdSt();
        pcVar7 = (code *)CONCAT22(extraout_var_01,sVar11 + 1);
      } while (!SCARRY2(sVar11,1));
    }
  }
  ppppppfStack_23c = (float ******)0x4eedcc;
  __vbaErrorOverflow();
  pcVar7 = __vbaGenerateBoundsError_exref;
  ppppppfStack_248 = (float ******)&DAT_00402706;
  pppppfStack_24c = ExceptionList;
  pppppfStack_244 = (float *****)&pcStack_340;
  pppppfStack_240 = (float *****)&DAT_00402590;
  pppppfStack_268 = (float *****)0x0;
  ppppppfStack_26c = (float ******)0x0;
  pppppfStack_270 = (float *****)0x0;
  ppppfStack_274 = (float ****)0x0;
  pppppfStack_284 = (float *****)0x0;
  ppppfStack_294 = (float ****)0x0;
  pppppfStack_2a4 = (float *****)0x0;
  pppppfStack_2b4 = (float *****)0x0;
  ppppfStack_2c4 = (float ****)0x0;
  ppppfStack_2d4 = (float ****)0x0;
  uStack_308 = 0;
  DAT_0050b3c2 = 0;
  pppppfStack_310 = (float *****)CONCAT22(pppppfStack_310._2_2_,DAT_0050b332);
  pppppfStack_250 = (float *****)0x1;
  pppppppfVar24 = DAT_0050b3cc;
  ExceptionList = &pppppfStack_24c;
  pcStack_340 = pcVar23;
  pppppfStack_33c = (float *****)ppppppfVar19;
  pcStack_338 = pcVar21;
  pppppfVar4 = pppppfStack_250;
  ppppppfStack_23c = (float ******)&ppppfStack_10c;
  do {
    pppppfStack_250 = pppppfVar4;
    ppppppfVar22 = (float ******)0x0;
    if ((short)pppppfStack_310 < (short)pppppfStack_250) {
      pppppfStack_25c = (float *****)0x0;
      goto LAB_004eefe5;
    }
    if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
      ppppppfStack_344 = (float ******)0x4eeea5;
      iVar12 = __vbaGenerateBoundsError();
      pppppppfVar24 = DAT_0050b3cc;
    }
    else {
      ppppppfVar22 = (float ******)-(int)pppppppfVar24[7];
      if (pppppppfVar24[6] <= ppppppfVar22) {
        ppppppfStack_344 = (float ******)0x4eee78;
        __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      ppppppfVar19 = (float ******)((int)(short)pppppfStack_250 - (int)pppppppfVar24[5]);
      if (pppppppfVar24[4] <= ppppppfVar19) {
        ppppppfStack_344 = (float ******)0x4eee90;
        __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      iVar12 = (int)((int)pppppppfVar24[6] * (int)ppppppfVar19 + (int)ppppppfVar22) * 4;
    }
    if (*(float *)((int)pppppppfVar24[3] + iVar12) == _DAT_00401488) {
      DAT_0050b3c2 = 1;
      if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
        ppppppfStack_344 = (float ******)0x4eeefe;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        ppppppfVar19 = (float ******)((int)(short)pppppfStack_250 - (int)DAT_0050b3d4[5]);
        if (DAT_0050b3d4[4] <= ppppppfVar19) {
          ppppppfStack_344 = (float ******)0x4eeeed;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)ppppppfVar19 * 4;
      }
      *(undefined4 *)((int)DAT_0050b3d4[3] + iVar12) = 0;
      if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
        ppppppfStack_344 = (float ******)0x4eef5d;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        ppppppfVar22 = (float ******)((int)(short)pppppfStack_250 - *(int *)(DAT_0050b3e8 + 0xe));
        if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar22) {
          ppppppfStack_344 = (float ******)0x4eef30;
          __vbaGenerateBoundsError();
        }
        ppppppfVar19 = (float ******)(1 - *(int *)(DAT_0050b3e8 + 10));
        if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar19) {
          ppppppfStack_344 = (float ******)0x4eef49;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar19 + (int)ppppppfVar22) * 2;
      }
      *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar12) = (short)pppppfStack_250;
      if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
        ppppppfStack_344 = (float ******)0x4eefb4;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        ppppppfVar19 = (float ******)((int)(short)pppppfStack_250 - *(int *)(DAT_0050b3e8 + 0xe));
        if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar19) {
          ppppppfStack_344 = (float ******)0x4eef8c;
          __vbaGenerateBoundsError();
        }
        ppppppfVar22 = (float ******)-*(int *)(DAT_0050b3e8 + 10);
        if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar22) {
          ppppppfStack_344 = (float ******)0x4eefa0;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)((int)ppppppfVar19 + *(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar22) * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar12) = 1;
      pppppppfVar24 = DAT_0050b3cc;
    }
    pppppfVar4 = (float *****)(uint)(ushort)((short)pppppfStack_250 + 1);
  } while (!SCARRY2((short)pppppfStack_250,1));
LAB_004ef9a0:
  ppppppfStack_344 = (float ******)0x4ef9a6;
  __vbaErrorOverflow();
  pppppfStack_350 = (float *****)&DAT_00402706;
  pppppfStack_354 = ExceptionList;
  puStack_34c = &pcStack_538;
  pcStack_538 = pcVar7;
  pwStack_348 = L"\x06\x04";
  pppppfStack_36c = (float *****)0x0;
  pppppfStack_374 = (float *****)0x0;
  pppppfStack_380 = (float *****)0x0;
  ppppppfStack_384 = (float ******)0x0;
  pppppfStack_388 = (float *****)0x0;
  uStack_38c = 0;
  uStack_390 = 0;
  uStack_394 = 0;
  ppppppfStack_398 = (float ******)0x0;
  pppppfStack_39c = (float *****)0x0;
  pppppfStack_3a0 = (float *****)0x0;
  pppppfStack_3b0 = (float *****)0x0;
  apppppfStack_3c0[0] = (float *****)0x0;
  pppppfStack_3d0 = (float *****)0x0;
  pppppfStack_3e0 = (float *****)0x0;
  ppppppfStack_3f0 = (float ******)0x0;
  pppppfStack_400 = (float *****)0x0;
  ppppppfStack_410 = (float ******)0x0;
  uStack_420 = 0;
  uStack_430 = 0;
  appppppfStack_454[0] = (float ******)0x0;
  pppppfStack_458 = (float *****)0x0;
  ppppppfStack_45c = (float ******)0x0;
  appppppfStack_488[0] = (float ******)0x0;
  ppppppfStack_48c = (float ******)0x0;
  DAT_0050b1fe = 2;
  ExceptionList = &pppppfStack_354;
  pppppfStack_534 = (float *****)ppppppfVar19;
  pppppfStack_530 = (float *****)ppppppfVar22;
  ppcVar8 = &pcStack_538;
  ppppppfStack_344 = (float ******)&ppppppfStack_23c;
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_53c = (float ******)&DAT_0050b420;
    ppppppfStack_540 = (float ******)&DAT_00408c88;
    ppppppfStack_544 = (float ******)0x4efa6f;
    ExceptionList = &pppppfStack_354;
    ppppppfStack_344 = (float ******)&ppppppfStack_23c;
    __vbaNew2();
    ppcVar8 = (code **)puStack_34c;
  }
  puStack_34c = ppcVar8;
  ppppppfStack_540 = (float ******)appppppfStack_488;
  ppppppfStack_53c = (float ******)DAT_0050b420;
  ppppppfStack_544 = (float ******)0x4efa82;
  __vbaObjSetAddref();
  ppppppfStack_544 = (float ******)&ppppppfStack_398;
  ppppppfStack_3e8 = (float ******)0x40c3f0;
  ppppppfStack_3f0 = (float ******)0x8;
  ppppppfStack_548 = appppppfStack_488[0];
  ppppppfStack_54c = (float ******)0x4efaa9;
  pppppfStack_558 = (float *****)(*(code *)(*appppppfStack_488[0])[0x92])();
  if ((int)pppppfStack_558 < 0) {
    ppppppfStack_54c = (float ******)0x248;
    pwStack_550 = L"믲㢺毡䞍྽닦\xf724㶱䞙缔횱䙏䆙赘鄽쭖䉂片摩";
    ppppppfStack_554 = appppppfStack_488[0];
    uStack_55c = 0x4efac9;
    __vbaHresultCheckObj();
  }
  pppppppfVar24 = (float *******)__vbaLateIdSt_exref;
  uStack_55c = 0;
  pppppfStack_558 = (float *****)ppppppfStack_3f0;
  ppppppfStack_554 = ppppppfStack_3ec;
  pwStack_550 = (wchar_t *)ppppppfStack_3e8;
  ppppppfStack_54c = ppppppfStack_3e4;
  ppppppfStack_560 = ppppppfStack_398;
  uStack_564 = 0x4efb07;
  __vbaLateIdSt();
  uStack_564 = 0x4efb12;
  __vbaFreeObj();
  uStack_564 = 0xffffff;
  ppppppfStack_568 = appppppfStack_488[0];
  ppppppfStack_56c = (float ******)0x4efb23;
  iVar12 = (*(code *)(*appppppfStack_488[0])[0x1b])();
  if (iVar12 < 0) {
    ppppppfStack_56c = (float ******)0x6c;
    ppppppfStack_570 = (float ******)&DAT_0040b430;
    ppppppfStack_574 = appppppfStack_488[0];
    ppppppfStack_57c = (float ******)0x4efb3a;
    puStack_578 = (undefined *)iVar12;
    __vbaHresultCheckObj();
  }
  ppppppfStack_56c = (float ******)&ppppppfStack_398;
  ppppppfStack_3e8 = (float ******)0xa;
  ppppppfStack_3f0 = (float ******)0x2;
  ppppppfStack_570 = appppppfStack_488[0];
  ppppppfStack_574 = (float ******)0x4efb61;
  pppppfStack_580 = (float *****)(*(code *)(*appppppfStack_488[0])[0x92])();
  if ((int)pppppfStack_580 < 0) {
    ppppppfStack_574 = (float ******)0x248;
    puStack_578 = &DAT_0040b430;
    ppppppfStack_57c = appppppfStack_488[0];
    uStack_584 = 0x4efb7b;
    __vbaHresultCheckObj();
  }
  uStack_584 = 2;
  pppppfStack_580 = (float *****)ppppppfStack_3f0;
  ppppppfStack_57c = ppppppfStack_3ec;
  puStack_578 = (undefined *)ppppppfStack_3e8;
  ppppppfStack_574 = ppppppfStack_3e4;
  ppppppfStack_588 = ppppppfStack_398;
  ppppppfStack_58c = (float ******)0x4efbab;
  __vbaLateIdSt();
  ppppppfStack_58c = (float ******)0x4efbb0;
  __vbaFreeObj();
  ppppppfStack_58c = (float ******)&ppppppfStack_398;
  ppppppfStack_3e8 = (float ******)0xffffffff;
  ppppppfStack_3f0 = (float ******)0xb;
  ppppppfStack_590 = appppppfStack_488[0];
  ppppppfStack_594 = (float ******)0x4efbd7;
  pppppfStack_5a0 = (float *****)(*(code *)(*appppppfStack_488[0])[0x92])();
  if ((int)pppppfStack_5a0 < 0) {
    ppppppfStack_594 = (float ******)0x248;
    puStack_598 = &DAT_0040b430;
    ppppppfStack_59c = appppppfStack_488[0];
    uStack_5a4 = 0x4efbf1;
    __vbaHresultCheckObj();
  }
  uStack_5a4 = 3;
  pppppfStack_5a0 = (float *****)ppppppfStack_3f0;
  ppppppfStack_59c = ppppppfStack_3ec;
  puStack_598 = (undefined *)ppppppfStack_3e8;
  ppppppfStack_594 = ppppppfStack_3e4;
  ppppppfStack_5a8 = ppppppfStack_398;
  uStack_5ac = 0x4efc21;
  __vbaLateIdSt();
  uStack_5ac = 0x4efc26;
  __vbaFreeObj();
  uStack_5ac = 1;
  ppppppfStack_5b0 = appppppfStack_488[0];
  ppppppfStack_5b4 = (float ******)0x4efc37;
  iVar12 = (*(code *)(*appppppfStack_488[0])[0x4b])();
  if (iVar12 < 0) {
    ppppppfStack_5b4 = (float ******)0x12c;
    puStack_5b8 = &DAT_0040b430;
    ppppppfStack_5bc = appppppfStack_488[0];
    piStack_5c4 = (int *)0x4efc51;
    iStack_5c0 = iVar12;
    __vbaHresultCheckObj();
  }
  ppppppfStack_5b4 = appppppfStack_488[0];
  puStack_5b8 = (undefined *)0x4efc60;
  puStack_5b8 = (undefined *)(*(code *)(*appppppfStack_488[0])[0xd1])();
  ppppppfStack_5bc = (float ******)&ppppppfStack_398;
  iStack_5c0 = 0x4efc6b;
  piStack_5c4 = (int *)__vbaObjSet();
  iStack_5c0 = 0;
  ppppppfStack_5c8 = (float ******)0x4efc7c;
  ppppppfStack_468 = (float ******)piStack_5c4;
  iVar12 = (**(code **)(*piStack_5c4 + 0x9c))();
  if (iVar12 < 0) {
    ppppppfStack_5c8 = (float ******)0x9c;
    puStack_5cc = &DAT_0040c3dc;
    ppppppfStack_5d0 = ppppppfStack_468;
    uStack_5d8 = 0x4efc96;
    iStack_5d4 = iVar12;
    __vbaHresultCheckObj();
  }
  ppppppfStack_5c8 = (float ******)0x4efc9b;
  __vbaFreeObj();
  ppppppfStack_3f0 = (float ******)0xb;
  uStack_5d8 = 0x80010007;
  iStack_5d4 = 0xb;
  ppppppfStack_3e8 = (float ******)0xffffffff;
  ppppppfStack_5d0 = ppppppfStack_3ec;
  puStack_5cc = (undefined *)0xffffffff;
  ppppppfStack_5c8 = ppppppfStack_3e4;
  ppppppfStack_5dc = appppppfStack_488[0];
  uStack_5e0 = 0x4efcdf;
  uStack_5e0 = (*(code *)(*appppppfStack_488[0])[0xea])();
  ppppppfStack_5e4 = (float ******)&ppppppfStack_398;
  uStack_5e8 = 0x4efcea;
  uStack_5e8 = __vbaObjSet();
  uStack_5ec = 0x4efced;
  __vbaLateIdSt();
  uStack_5ec = 0x4efcf2;
  __vbaFreeObj();
  uStack_5ec = 0x44960000;
  ppppppfStack_5f0 = appppppfStack_488[0];
  ppppppfStack_5f4 = (float ******)0x4efd06;
  iVar12 = (*(code *)(*appppppfStack_488[0])[0x39])();
  if (iVar12 < 0) {
    ppppppfStack_5f4 = (float ******)0xe4;
    puStack_5f8 = &DAT_0040b430;
    ppppppfStack_5fc = appppppfStack_488[0];
    ppppppfStack_604 = (float ******)0x4efd20;
    ppppppfStack_600 = (float ******)iVar12;
    __vbaHresultCheckObj();
  }
  ppppppfStack_5f4 = appppppfStack_488[0];
  puStack_5f8 = (undefined *)0x4efd2f;
  puStack_5f8 = (undefined *)(*(code *)(*appppppfStack_488[0])[0xd9])();
  ppppppfStack_5fc = (float ******)&ppppppfStack_398;
  ppppppfStack_600 = (float ******)0x4efd3a;
  ppppppfStack_604 = (float ******)__vbaObjSet();
  ppppppfStack_600 = (float ******)appppppfStack_454;
  ppppppfStack_608 = (float ******)0x4efd50;
  ppppppfStack_468 = ppppppfStack_604;
  pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_604)[0x22])();
  uVar27 = 0;
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_608 = (float ******)0x88;
    ppppppfStack_60c = (float ******)&DAT_0040c3dc;
    ppppppfStack_610 = ppppppfStack_468;
    ppppppfStack_618 = (float ******)0x4efd6a;
    ppppppfStack_614 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  iStack_50c = (int)DAT_0050b32e;
  fStack_510 = (float)iStack_50c;
  ppppppfStack_608 = appppppfStack_488[0];
  pppppppfVar14 = (float *******)ppppppfStack_608;
  if ((uVar27 & 0xd) != 0) {
LAB_004f2fd3:
    ppppppfStack_608 = (float ******)pppppppfVar14;
    __vbaFPException();
    return;
  }
  ppppppfStack_60c = appppppfStack_488[0];
  ppppppfStack_610 = (float ******)0x4efdac;
  ppppppfStack_608 = (float ******)(fStack_510 + (float)appppppfStack_454[0]);
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3b])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_610 = (float ******)0xec;
    ppppppfStack_614 = (float ******)&DAT_0040b430;
    ppppppfStack_618 = appppppfStack_488[0];
    ppppppfStack_620 = (float ******)0x4efdc6;
    ppppppfStack_61c = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_610 = (float ******)0x4efdcb;
  __vbaFreeObj();
  ppppppfStack_610 = appppppfStack_488[0];
  ppppppfStack_614 = (float ******)0x4efdda;
  ppppppfStack_614 = (float ******)(*(code *)(*appppppfStack_488[0])[0xdc])();
  ppppppfStack_618 = (float ******)&ppppppfStack_398;
  ppppppfStack_61c = (float ******)0x4efde5;
  ppppppfStack_620 = (float ******)__vbaObjSet();
  ppppppfStack_61c = (float ******)0x0;
  ppppppfStack_624 = (float ******)0x4efdf6;
  ppppppfStack_468 = ppppppfStack_620;
  pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_620)[0x23])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_624 = (float ******)0x8c;
    ppppppfStack_628 = (float ******)&DAT_0040bb6c;
    ppppppfStack_62c = ppppppfStack_468;
    ppppppfStack_634 = (float ******)0x4efe10;
    ppppppfStack_630 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_624 = (float ******)0x4efe15;
  __vbaFreeObj();
  ppppppfStack_624 = appppppfStack_488[0];
  ppppppfStack_628 = (float ******)0x4efe24;
  ppppppfStack_628 = (float ******)(*(code *)(*appppppfStack_488[0])[0xdd])();
  ppppppfStack_62c = (float ******)&ppppppfStack_398;
  ppppppfStack_630 = (float ******)0x4efe2f;
  ppppppfStack_634 = (float ******)__vbaObjSet();
  ppppppfStack_630 = (float ******)0x0;
  ppppppfStack_638 = (float ******)0x4efe40;
  ppppppfStack_468 = ppppppfStack_634;
  pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_634)[0x23])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_638 = (float ******)0x8c;
    uStack_640 = (double)CONCAT44(&DAT_0040bb6c,ppppppfStack_468);
    ppppppfStack_648 = (float ******)0x4efe5a;
    ppppppfStack_644 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_638 = (float ******)0x4efe5f;
  __vbaFreeObj();
  ppppppfStack_638 = appppppfStack_488[0];
  uStack_640 = (double)CONCAT44(0x4efe6e,(undefined4)uStack_640);
  uVar13 = (*(code *)(*appppppfStack_488[0])[0xdb])();
  uStack_640 = (double)CONCAT44(uVar13,&ppppppfStack_398);
  ppppppfStack_644 = (float ******)0x4efe79;
  ppppppfStack_46c = (float ******)__vbaObjSet();
  ppppppfStack_644 = (float ******)appppppfStack_454;
  ppppppfStack_648 = appppppfStack_488[0];
  ppppppfStack_64c = (float ******)0x4efe95;
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3a])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_64c = (float ******)0xe8;
    ppppppfStack_650 = (float ******)&DAT_0040b430;
    ppppppfStack_654 = appppppfStack_488[0];
    ppppppfStack_65c = (float ******)0x4efeaf;
    ppppppfStack_658 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_64c = appppppfStack_454[0];
  ppppppfStack_650 = ppppppfStack_46c;
  ppppppfStack_654 = (float ******)0x4efec2;
  pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_46c)[0x1f])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_654 = (float ******)0x7c;
    ppppppfStack_658 = (float ******)&DAT_0040c3dc;
    ppppppfStack_65c = ppppppfStack_46c;
    ppppppfStack_664 = (float ******)0x4efed9;
    ppppppfStack_660 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_654 = (float ******)0x4efede;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *******)0x0) {
    ppppppfStack_654 = (float ******)&DAT_0050c53c;
    ppppppfStack_658 = (float ******)&DAT_0040b420;
    ppppppfStack_65c = (float ******)0x4efef7;
    __vbaNew2();
  }
  pppppppfVar14 = DAT_0050c53c;
  ppppppfStack_654 = (float ******)&ppppppfStack_398;
  ppppppfStack_658 = (float ******)DAT_0050c53c;
  ppppppfStack_65c = (float ******)0x4eff07;
  pppppppfVar15 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_65c = (float ******)0x18;
    ppppppfStack_660 = (float ******)&DAT_0040b410;
    ppppppfStack_664 = (float ******)pppppppfVar14;
    ppppppfStack_66c = (float ******)0x4eff18;
    ppppppfStack_668 = (float ******)pppppppfVar15;
    __vbaHresultCheckObj();
  }
  ppppppfVar19 = ppppppfStack_398;
  ppppppfStack_65c = (float ******)appppppfStack_454;
  ppppppfStack_660 = ppppppfStack_398;
  ppppppfStack_664 = (float ******)0x4eff2d;
  pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_398)[0x26])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_664 = (float ******)0x98;
    ppppppfStack_668 = (float ******)&DAT_0040bb5c;
    ppppppfStack_66c = ppppppfVar19;
    ppppppfStack_674 = (float ******)0x4eff41;
    ppppppfStack_670 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_664 = appppppfStack_488[0];
  ppppppfStack_668 = (float ******)0x4eff50;
  ppppppfStack_668 = (float ******)(*(code *)(*appppppfStack_488[0])[0xdb])();
  ppppppfStack_66c = &pppppfStack_39c;
  ppppppfStack_670 = (float ******)0x4eff5b;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_670 = &pppppfStack_458;
  ppppppfStack_678 = (float ******)0x4eff6d;
  ppppppfStack_674 = (float ******)pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x20])();
  uVar27 = 0;
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_678 = (float ******)0x80;
    ppppppfStack_67c = (float ******)&DAT_0040c3dc;
    ppppppfStack_688 = (float ******)0x4eff81;
    ppppppfStack_684 = (float ******)pppppppfVar15;
    ppppppfStack_680 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_678 = appppppfStack_488[0];
  ppppppfStack_67c = (float ******)0x4eff90;
  ppppppfStack_67c = (float ******)(*(code *)(*appppppfStack_488[0])[0xdb])();
  ppppppfStack_680 = &pppppfStack_3a0;
  ppppppfStack_684 = (float ******)0x4eff9b;
  pppppppfVar15 = (float *******)__vbaObjSet();
  pppppppfVar14 = (float *******)ppppppfStack_608;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_608 =
       (float ******)(((float)appppppfStack_454[0] - (float)pppppfStack_458) * (float)_DAT_00401268)
  ;
  pppppppfVar14 = (float *******)*pppppppfVar15;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_614 = (float ******)0x4effd9;
  ppppppfStack_610 = (float ******)pppppppfVar15;
  fStack_514 = (float)ppppppfStack_608;
  ppppppfStack_620 = (float ******)(*(code *)(*pppppppfVar15)[0x1d])();
  if ((int)ppppppfStack_620 < 0) {
    ppppppfStack_614 = (float ******)0x74;
    ppppppfStack_618 = (float ******)&DAT_0040c3dc;
    ppppppfStack_624 = (float ******)0x4effea;
    ppppppfStack_61c = (float ******)pppppppfVar15;
    __vbaHresultCheckObj();
  }
  ppppppfStack_614 = &pppppfStack_3a0;
  ppppppfStack_618 = &pppppfStack_39c;
  ppppppfStack_61c = (float ******)&ppppppfStack_398;
  ppppppfStack_620 = (float ******)0x3;
  ppppppfStack_624 = (float ******)0x4efffe;
  __vbaFreeObjList();
  ppppppfStack_614 = appppppfStack_488[0];
  ppppppfStack_618 = (float ******)0x4f0010;
  ppppppfStack_618 = (float ******)(*(code *)(*appppppfStack_488[0])[0xdb])();
  ppppppfStack_61c = (float ******)&ppppppfStack_398;
  ppppppfStack_620 = (float ******)0x4f001b;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_620 = (float ******)0xffffffff;
  ppppppfStack_628 = (float ******)0x4f0028;
  ppppppfStack_624 = (float ******)pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x27])();
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_628 = (float ******)0x9c;
    ppppppfStack_62c = (float ******)&DAT_0040c3dc;
    ppppppfStack_638 = (float ******)0x4f003c;
    ppppppfStack_634 = (float ******)pppppppfVar15;
    ppppppfStack_630 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_628 = (float ******)0x4f0045;
  __vbaFreeObj();
  ppppppfStack_628 = appppppfStack_488[0];
  ppppppfStack_62c = (float ******)0x4f0054;
  ppppppfStack_62c = (float ******)(*(code *)(*appppppfStack_488[0])[0xdb])();
  ppppppfStack_630 = (float ******)&ppppppfStack_398;
  ppppppfStack_634 = (float ******)0x4f005f;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_634 = &pppppfStack_458;
  uStack_640 = (double)CONCAT44(0x4f0071,(undefined4)uStack_640);
  ppppppfStack_638 = (float ******)pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x22])();
  if ((int)pppppppfVar15 < 0) {
    uStack_640 = 2.88593524605243e-312;
    ppppppfStack_64c = (float ******)0x4f0085;
    ppppppfStack_648 = (float ******)pppppppfVar15;
    ppppppfStack_644 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  uStack_640 = (double)CONCAT44(appppppfStack_454,appppppfStack_488[0]);
  ppppppfStack_644 = (float ******)0x4f009b;
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3a])();
  uVar27 = 0;
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_608 = (float ******)0xe8;
    ppppppfStack_60c = (float ******)&DAT_0040b430;
    ppppppfStack_610 = appppppfStack_488[0];
    ppppppfStack_618 = (float ******)0x4f00b5;
    ppppppfStack_614 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_608 = appppppfStack_488[0];
  pppppppfVar14 = (float *******)ppppppfStack_608;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_60c = appppppfStack_488[0];
  ppppppfStack_610 = (float ******)0x4f00de;
  ppppppfStack_608 = (float ******)((float)pppppfStack_458 + (float)appppppfStack_454[0]);
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3b])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_610 = (float ******)0xec;
    ppppppfStack_614 = (float ******)&DAT_0040b430;
    ppppppfStack_618 = appppppfStack_488[0];
    ppppppfStack_620 = (float ******)0x4f00f8;
    ppppppfStack_61c = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_610 = (float ******)0x4f0101;
  __vbaFreeObj();
  ppppppfStack_610 = (float ******)appppppfStack_454;
  ppppppfStack_614 = appppppfStack_488[0];
  ppppppfStack_618 = (float ******)0x4f0117;
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3a])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_618 = (float ******)0xe8;
    ppppppfStack_61c = (float ******)&DAT_0040b430;
    ppppppfStack_620 = appppppfStack_488[0];
    ppppppfStack_628 = (float ******)0x4f0131;
    ppppppfStack_624 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  if (DAT_0050c53c == (float *******)0x0) {
    ppppppfStack_618 = (float ******)&DAT_0050c53c;
    ppppppfStack_61c = (float ******)&DAT_0040b420;
    ppppppfStack_620 = (float ******)0x4f014a;
    __vbaNew2();
  }
  pppppppfVar14 = DAT_0050c53c;
  ppppppfStack_618 = (float ******)&ppppppfStack_398;
  ppppppfStack_61c = (float ******)DAT_0050c53c;
  ppppppfStack_620 = (float ******)0x4f015a;
  pppppppfVar15 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_620 = (float ******)0x18;
    ppppppfStack_624 = (float ******)&DAT_0040b410;
    ppppppfStack_628 = (float ******)pppppppfVar14;
    ppppppfStack_630 = (float ******)0x4f016b;
    ppppppfStack_62c = (float ******)pppppppfVar15;
    __vbaHresultCheckObj();
  }
  ppppppfVar19 = ppppppfStack_398;
  ppppppfStack_620 = &pppppfStack_458;
  ppppppfStack_624 = ppppppfStack_398;
  ppppppfStack_628 = (float ******)0x4f0180;
  pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_398)[0x26])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_628 = (float ******)0x98;
    ppppppfStack_62c = (float ******)&DAT_0040bb5c;
    ppppppfStack_630 = ppppppfVar19;
    ppppppfStack_638 = (float ******)0x4f0194;
    ppppppfStack_634 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_628 = (float ******)&ppppppfStack_45c;
  ppppppfStack_62c = appppppfStack_488[0];
  ppppppfStack_630 = (float ******)0x4f01aa;
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3a])();
  uVar27 = 0;
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_600 = (float ******)0xe8;
    ppppppfStack_604 = (float ******)&DAT_0040b430;
    ppppppfStack_608 = appppppfStack_488[0];
    ppppppfStack_610 = (float ******)0x4f01c4;
    ppppppfStack_60c = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_600 = (float ******)&DAT_0050b420;
    ppppppfStack_604 = (float ******)&DAT_00408c88;
    ppppppfStack_608 = (float ******)0x4f01dd;
    __vbaNew2();
  }
  pppppppfVar15 = DAT_0050b420;
  ppppppfStack_608 = (float ******)((float)pppppfStack_458 - _DAT_004020e0);
  ppppppfStack_600 = (float ******)0x0;
  ppppppfStack_604 = ppppppfStack_45c;
  pppppppfVar14 = (float *******)*DAT_0050b420;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_60c = appppppfStack_454[0];
  ppppppfStack_610 = (float ******)0x44960000;
  ppppppfStack_614 = (float ******)0x4;
  ppppppfStack_618 = (float ******)DAT_0050b420;
  ppppppfStack_61c = (float ******)0x4f021d;
  pppppppfVar14 = (float *******)(*(code *)(*DAT_0050b420)[0xb2])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_61c = (float ******)0x2c8;
    ppppppfStack_620 = (float ******)&DAT_0040b430;
    ppppppfStack_624 = (float ******)pppppppfVar15;
    ppppppfStack_62c = (float ******)0x4f0231;
    ppppppfStack_628 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_61c = (float ******)0x4f023a;
  __vbaFreeObj();
  ppppppfStack_61c = (float ******)0x44960000;
  ppppppfStack_620 = appppppfStack_488[0];
  ppppppfStack_624 = (float ******)0x4f024e;
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x39])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_624 = (float ******)0xe4;
    ppppppfStack_628 = (float ******)&DAT_0040b430;
    ppppppfStack_62c = appppppfStack_488[0];
    ppppppfStack_634 = (float ******)0x4f0268;
    ppppppfStack_630 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_624 = (float ******)&DAT_0050b420;
    ppppppfStack_628 = (float ******)&DAT_00408c88;
    ppppppfStack_62c = (float ******)0x4f0281;
    __vbaNew2();
  }
  ppppppfStack_624 = (float ******)0x40f6d0;
  ppppppfStack_628 = *(float *******)(DAT_0050b37c + 4);
  ppppppfStack_62c = (float ******)0x4f0295;
  __vbaStrCat();
  ppppppfStack_62c = (float ******)0x4f02a0;
  ppppppfStack_62c = (float ******)__vbaStrMove();
  ppppppfStack_630 = (float ******)DAT_0050b420;
  ppppppfStack_634 = (float ******)&DAT_0040bf08;
  ppppppfStack_638 = (float ******)0x4f02b3;
  __vbaPrintObj();
  ppppppfStack_62c = (float ******)0x4f02bf;
  __vbaFreeStr();
  if ((DAT_0050b338 == 1) || (DAT_0050b338 == 2)) {
    ppppppfStack_62c = (float ******)0x4f02e3;
    __vbaStrCopy();
  }
  ppppppfStack_62c = appppppfStack_488[0];
  ppppppfStack_630 = (float ******)0x4f02f2;
  ppppppfStack_630 = (float ******)(*(code *)(*appppppfStack_488[0])[0xdc])();
  ppppppfStack_634 = (float ******)&ppppppfStack_398;
  ppppppfStack_638 = (float ******)0x4f02fd;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_638 = (float ******)0x0;
  uStack_640._0_4_ = 0x4f030a;
  uStack_640._4_4_ = pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x23])();
  if ((int)pppppppfVar15 < 0) {
    uStack_640._0_4_ = 0x8c;
    ppppppfStack_644 = (float ******)&DAT_0040bb6c;
    ppppppfStack_650 = (float ******)0x4f031e;
    ppppppfStack_64c = (float ******)pppppppfVar15;
    ppppppfStack_648 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  uStack_640._0_4_ = 0x4f0327;
  __vbaFreeObj();
  uStack_640 = (double)CONCAT44(uStack_640._4_4_,appppppfStack_488[0]);
  ppppppfStack_644 = (float ******)0x4f0336;
  ppppppfStack_644 = (float ******)(*(code *)(*appppppfStack_488[0])[0xdd])();
  ppppppfStack_648 = (float ******)&ppppppfStack_398;
  ppppppfStack_64c = (float ******)0x4f0341;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_64c = (float ******)0x0;
  ppppppfStack_654 = (float ******)0x4f034e;
  ppppppfStack_650 = (float ******)pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x23])();
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_654 = (float ******)0x8c;
    ppppppfStack_658 = (float ******)&DAT_0040bb6c;
    ppppppfStack_664 = (float ******)0x4f0362;
    ppppppfStack_660 = (float ******)pppppppfVar15;
    ppppppfStack_65c = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_654 = (float ******)0x4f036b;
  __vbaFreeObj();
  ppppppfStack_654 = appppppfStack_488[0];
  ppppppfStack_658 = (float ******)0x4f037a;
  ppppppfStack_658 = (float ******)(*(code *)(*appppppfStack_488[0])[0xe8])();
  ppppppfStack_65c = (float ******)&ppppppfStack_398;
  ppppppfStack_660 = (float ******)0x4f0385;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_660 = (float ******)DAT_0050b34c;
  ppppppfStack_668 = (float ******)0x4f0394;
  ppppppfStack_664 = (float ******)pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x15])();
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_668 = (float ******)0x54;
    ppppppfStack_66c = (float ******)&DAT_0040ba5c;
    ppppppfStack_678 = (float ******)0x4f03a5;
    ppppppfStack_674 = (float ******)pppppppfVar15;
    ppppppfStack_670 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_668 = (float ******)0x4f03ae;
  __vbaFreeObj();
  ppppppfStack_668 = (float ******)appppppfStack_454;
  ppppppfStack_66c = appppppfStack_488[0];
  ppppppfStack_670 = (float ******)0x4f03c4;
  ppppppfVar19 = (float ******)(*(code *)(*appppppfStack_488[0])[0x3a])();
  if ((int)ppppppfVar19 < 0) {
    ppppppfStack_670 = (float ******)0xe8;
    ppppppfStack_674 = (float ******)&DAT_0040b430;
    ppppppfStack_678 = appppppfStack_488[0];
    ppppppfStack_680 = (float ******)0x4f03de;
    ppppppfStack_67c = ppppppfVar19;
    __vbaHresultCheckObj();
  }
  ppppppfStack_670 = (float ******)0x4f03ea;
  ppppppfStack_364 = (float ******)__vbaFpI2();
  ppppppfStack_670 = appppppfStack_488[0];
  ppppppfStack_674 = (float ******)0x4f03fc;
  ppppppfStack_674 = (float ******)(*(code *)(*appppppfStack_488[0])[0xe8])();
  ppppppfStack_678 = (float ******)&ppppppfStack_398;
  ppppppfStack_67c = (float ******)0x4f0407;
  pppppppfVar14 = (float *******)__vbaObjSet();
  iStack_518 = (int)(short)ppppppfStack_364;
  ppppppfStack_67c = (float ******)(float)iStack_518;
  ppppppfStack_684 = (float ******)0x4f042c;
  ppppppfStack_680 = (float ******)pppppppfVar14;
  pppppfStack_51c = (float *****)ppppppfStack_67c;
  iVar12 = (*(code *)(*pppppppfVar14)[0x1f])();
  if (iVar12 < 0) {
    ppppppfStack_684 = (float ******)0x7c;
    ppppppfStack_688 = (float ******)&DAT_0040ba5c;
    uStack_690 = (double)CONCAT44(pppppppfVar14,iVar12);
    ppppppfStack_694 = (float ******)0x4f043d;
    __vbaHresultCheckObj();
  }
  ppppppfStack_684 = (float ******)0x4f0446;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *******)0x0) {
    ppppppfStack_684 = (float ******)&DAT_0050c53c;
    ppppppfStack_688 = (float ******)&DAT_0040b420;
    uStack_690 = (double)CONCAT44(0x4f045f,(undefined4)uStack_690);
    __vbaNew2();
  }
  pppppppfVar14 = DAT_0050c53c;
  ppppppfStack_684 = (float ******)&ppppppfStack_398;
  ppppppfStack_688 = (float ******)DAT_0050c53c;
  uStack_690 = (double)CONCAT44(0x4f046f,(undefined4)uStack_690);
  iVar12 = (*(code *)(*DAT_0050c53c)[6])();
  if (iVar12 < 0) {
    uStack_690 = 5.09299940191312e-313;
    ppppppfStack_694 = (float ******)pppppppfVar14;
    uStack_69c = (double)CONCAT44(iVar12,0x4f0480);
    __vbaHresultCheckObj();
  }
  ppppppfVar19 = ppppppfStack_398;
  uStack_690 = (double)CONCAT44(appppppfStack_454,ppppppfStack_398);
  ppppppfStack_694 = (float ******)0x4f0495;
  ppppppfStack_6a0 = (float ******)(*(code *)(*ppppppfStack_398)[0x26])();
  if ((int)ppppppfStack_6a0 < 0) {
    ppppppfStack_694 = (float ******)0x98;
    uStack_69c = (double)CONCAT44(&DAT_0040bb5c,ppppppfVar19);
    uStack_6a8 = (double)CONCAT44(0x4f04a9,(undefined4)uStack_6a8);
    __vbaHresultCheckObj();
  }
  ppppppfStack_694 = &pppppfStack_458;
  uStack_69c = (double)CONCAT44(DAT_0050b34c,appppppfStack_488[0]);
  ppppppfStack_6a0 = (float ******)0x4f04c6;
  iVar12 = (*(code *)(*appppppfStack_488[0])[0xb9])();
  uVar27 = 0;
  if (iVar12 < 0) {
    ppppppfStack_6a0 = (float ******)0x2e4;
    uStack_6a8 = (double)CONCAT44(&DAT_0040b430,appppppfStack_488[0]);
    uStack_6b4 = (double)CONCAT44(0x4f04e0,(undefined4)uStack_6b4);
    iStack_6ac = iVar12;
    __vbaHresultCheckObj();
  }
  ppppppfStack_6a0 = appppppfStack_488[0];
  uStack_6a8 = (double)CONCAT44(0x4f04ef,(undefined4)uStack_6a8);
  uVar13 = (*(code *)(*appppppfStack_488[0])[0xe8])();
  uStack_6a8 = (double)CONCAT44(uVar13,&pppppfStack_39c);
  iStack_6ac = 0x4f04fa;
  pppppppfVar15 = (float *******)__vbaObjSet();
  pppppppfVar14 = (float *******)ppppppfStack_608;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_608 =
       (float ******)(((float)appppppfStack_454[0] - (float)pppppfStack_458) * (float)_DAT_00401268)
  ;
  pppppppfVar14 = (float *******)*pppppppfVar15;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_614 = (float ******)0x4f0538;
  ppppppfStack_610 = (float ******)pppppppfVar15;
  fStack_520 = (float)ppppppfStack_608;
  ppppppfStack_620 = (float ******)(*(code *)(*pppppppfVar15)[0x1d])();
  if ((int)ppppppfStack_620 < 0) {
    ppppppfStack_614 = (float ******)0x74;
    ppppppfStack_618 = (float ******)&DAT_0040ba5c;
    ppppppfStack_624 = (float ******)0x4f0549;
    ppppppfStack_61c = (float ******)pppppppfVar15;
    __vbaHresultCheckObj();
  }
  ppppppfStack_614 = &pppppfStack_39c;
  ppppppfStack_618 = (float ******)&ppppppfStack_398;
  ppppppfStack_61c = (float ******)0x2;
  ppppppfStack_620 = (float ******)0x4f0559;
  __vbaFreeObjList();
  ppppppfStack_614 = appppppfStack_488[0];
  ppppppfStack_618 = (float ******)0x4f056b;
  ppppppfStack_618 = (float ******)(*(code *)(*appppppfStack_488[0])[0xe8])();
  ppppppfStack_61c = (float ******)&ppppppfStack_398;
  ppppppfStack_620 = (float ******)0x4f0576;
  pppppppfVar14 = (float *******)__vbaObjSet();
  ppppppfStack_620 = (float ******)appppppfStack_454;
  ppppppfStack_628 = (float ******)0x4f0588;
  ppppppfStack_624 = (float ******)pppppppfVar14;
  pppppppfVar15 = (float *******)(*(code *)(*pppppppfVar14)[0x22])();
  uVar27 = 0;
  if ((int)pppppppfVar15 < 0) {
    ppppppfStack_608 = (float ******)0x88;
    ppppppfStack_60c = (float ******)&DAT_0040ba5c;
    ppppppfStack_618 = (float ******)0x4f059c;
    ppppppfStack_614 = (float ******)pppppppfVar15;
    ppppppfStack_610 = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  fStack_524 = (float)iStack_518;
  ppppppfStack_608 = appppppfStack_488[0];
  pppppppfVar14 = (float *******)ppppppfStack_608;
  if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_60c = appppppfStack_488[0];
  ppppppfStack_610 = (float ******)0x4f05d1;
  ppppppfStack_608 = (float ******)(fStack_524 + (float)appppppfStack_454[0]);
  pppppppfVar14 = (float *******)(*(code *)(*appppppfStack_488[0])[0x3b])();
  if ((int)pppppppfVar14 < 0) {
    ppppppfStack_610 = (float ******)0xec;
    ppppppfStack_614 = (float ******)&DAT_0040b430;
    ppppppfStack_618 = appppppfStack_488[0];
    ppppppfStack_620 = (float ******)0x4f05eb;
    ppppppfStack_61c = (float ******)pppppppfVar14;
    __vbaHresultCheckObj();
  }
  ppppppfStack_610 = (float ******)0x4f05f4;
  __vbaFreeObj();
  ppppppfStack_614 = (float ******)appppppfStack_488;
  ppppppfStack_610 = (float ******)0x0;
  ppppppfStack_618 = (float ******)0x4f0603;
  __vbaObjSetAddref();
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_618 = (float ******)&DAT_0050b420;
    ppppppfStack_61c = (float ******)&DAT_00408c88;
    ppppppfStack_620 = (float ******)0x4f061c;
    __vbaNew2();
  }
  ppppppfStack_618 = (float ******)DAT_0050b420;
  ppppppfStack_61c = (float ******)0x4f062a;
  ppppppfStack_61c = (float ******)(*(code *)(*DAT_0050b420)[0xea])();
  ppppppfStack_620 = (float ******)&ppppppfStack_48c;
  ppppppfStack_624 = (float ******)0x4f063a;
  __vbaObjSet();
  ppppppfStack_3f0 = (float ******)0x3;
  ppppppfStack_3e8 = (float ******)0x3;
  ppppppfStack_630 = (float ******)0x3;
  ppppppfStack_634 = (float ******)0x1a;
  ppppppfStack_62c = ppppppfStack_3ec;
  ppppppfStack_638 = ppppppfStack_48c;
  ppppppfStack_628 = (float ******)0x3;
  ppppppfStack_624 = ppppppfStack_3e4;
  uStack_640 = (double)CONCAT44(0x4f0674,(undefined4)uStack_640);
  __vbaLateIdSt();
  ppppppfStack_3f0 = (float ******)0x3;
  ppppppfStack_64c = (float ******)0xfffffe0b;
  ppppppfStack_648 = (float ******)0x3;
  ppppppfStack_3e8 = (float ******)0xff0000;
  ppppppfStack_644 = ppppppfStack_3ec;
  ppppppfStack_650 = ppppppfStack_48c;
  uStack_640 = (double)CONCAT44(ppppppfStack_3e4,0xff0000);
  ppppppfStack_654 = (float ******)0x4f06b4;
  __vbaLateIdSt();
  ppppppfStack_3f0 = (float ******)0x3;
  ppppppfStack_664 = (float ******)0xfffffdff;
  ppppppfStack_660 = (float ******)0x3;
  ppppppfStack_3e8 = (float ******)0xffffff;
  ppppppfStack_65c = ppppppfStack_3ec;
  ppppppfStack_668 = ppppppfStack_48c;
  ppppppfStack_658 = (float ******)0xffffff;
  ppppppfStack_654 = ppppppfStack_3e4;
  ppppppfStack_66c = (float ******)0x4f06f4;
  __vbaLateIdSt();
  pppppppfVar15 = (float *******)__vbaLateIdCallLd_exref;
  ppppppfStack_3f0 = (float ******)0x8;
  ppppppfStack_678 = (float ******)0x8;
  ppppppfStack_3e8 = (float ******)0x40c3f0;
  ppppppfStack_67c = (float ******)0x0;
  ppppppfStack_674 = ppppppfStack_3ec;
  ppppppfStack_680 = (float ******)&DAT_0040eb6c;
  ppppppfStack_684 = (float ******)0x0;
  ppppppfStack_670 = (float ******)0x40c3f0;
  ppppppfStack_688 = (float ******)0xfffffe00;
  ppppppfStack_66c = ppppppfStack_3e4;
  uStack_690 = (double)CONCAT44(ppppppfStack_48c,&pppppfStack_3b0);
  ppppppfStack_694 = (float ******)0x4f0747;
  ppppppfStack_684 = (float ******)__vbaLateIdCallLd();
  ppppppfStack_688 = (float ******)0x4f0751;
  ppppppfStack_688 = (float ******)__vbaCastObjVar();
  uStack_690._4_4_ = &ppppppfStack_398;
  uStack_690._0_4_ = 0x4f0758;
  uVar13 = __vbaObjSet();
  uStack_690 = (double)CONCAT44(uStack_690._4_4_,uVar13);
  ppppppfStack_694 = (float ******)0x4f075b;
  __vbaLateIdSt();
  ppppppfStack_694 = (float ******)0x4f0764;
  __vbaFreeObj();
  pcVar23 = __vbaFreeVar_exref;
  ppppppfStack_694 = (float ******)0x4f076f;
  __vbaFreeVar();
  ppppppfStack_3f0 = (float ******)0x2;
  ppppppfStack_6a0 = (float ******)0x2;
  ppppppfStack_3e8 = (float ******)0x9;
  uStack_6a8 = 4.2460936197935e-314;
  iStack_6ac = 0;
  uStack_69c = (double)CONCAT44(9,ppppppfStack_3ec);
  uStack_6b4 = (double)CONCAT44(0xfffffe00,ppppppfStack_48c);
  ppppppfStack_694 = ppppppfStack_3e4;
  ppppppfStack_6b8 = &pppppfStack_3b0;
  ppppppfStack_6bc = (float ******)0x4f07bc;
  iStack_6ac = __vbaLateIdCallLd();
  uStack_6b4 = (double)CONCAT44(0x4f07c6,(undefined4)uStack_6b4);
  uVar13 = __vbaCastObjVar();
  uStack_6b4 = (double)CONCAT44(uVar13,&ppppppfStack_398);
  ppppppfStack_6b8 = (float ******)0x4f07d1;
  ppppppfStack_6b8 = (float ******)__vbaObjSet();
  ppppppfStack_6bc = (float ******)0x4f07d4;
  __vbaLateIdSt();
  ppppppfStack_6bc = (float ******)0x4f07dd;
  __vbaFreeObj();
  ppppppfStack_6bc = (float ******)0x4f07e2;
  __vbaFreeVar();
  ppppppfStack_3f0 = (float ******)0xb;
  ppppppfStack_3e8 = (float ******)0xffffffff;
  pcStack_6c0 = (code *)0xffffffff;
  ppppppfStack_6bc = ppppppfStack_3e4;
  uVar13 = __vbaLateIdCallLd(&pppppfStack_3b0,ppppppfStack_48c,0xfffffe00,0,&DAT_0040eb6c,3,0xb,
                             ppppppfStack_3ec);
  uVar13 = __vbaCastObjVar(uVar13);
  uVar13 = __vbaObjSet(&ppppppfStack_398,uVar13);
  __vbaLateIdSt(uVar13);
  __vbaFreeObj();
  __vbaFreeVar();
  if (DAT_0050b420 == (float *******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppfStack_468 = (float ******)DAT_0050b420;
  iVar12 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,appppppfStack_454);
  uVar27 = 0;
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,ppppppfStack_468,&DAT_0040b430,0xe8);
  }
  ppppppfStack_3f0 = (float ******)0x4;
  ppppppfStack_3e8 = appppppfStack_454[0];
  __vbaLateIdSt(ppppppfStack_48c,0x80010004,4,ppppppfStack_3ec,appppppfStack_454[0],ppppppfStack_3e4
               );
  if (DAT_0050b338 == 1) {
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_61c = (float ******)0x5;
    ppppppfStack_618 = (float ******)0x3;
    ppppppfStack_3e8 = (float ******)0x4;
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_620 = ppppppfStack_48c;
    ppppppfStack_610 = (float ******)0x4;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_624 = (float ******)0x4f1d8f;
    __vbaLateIdSt();
    ppppppfStack_3f0 = (float ******)0x3;
    if (!SCARRY2((short)DAT_0050b3c4,3)) {
      ppppppfStack_610 = (float ******)(int)(short)((short)DAT_0050b3c4 + 3);
      ppppppfStack_61c = (float ******)0x4;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f1ddb;
      ppppppfStack_3e8 = ppppppfStack_610;
      __vbaLateIdSt();
      ppppppfStack_624 = (float ******)0x0;
      ppppppfStack_628 = (float ******)0x4;
      ppppppfStack_630 = &pppppfStack_3b0;
      ppppppfStack_62c = ppppppfStack_48c;
      ppppppfStack_634 = (float ******)0x4f1dec;
      ppppppfStack_624 = (float ******)__vbaLateIdCallLd();
      ppppppfStack_628 = (float ******)0x4f1df6;
      iVar12 = __vbaI4Var();
      if (!SBORROW4(iVar12,1)) {
        ppppppfStack_60c = (float ******)0x4f1e07;
        uStack_49c = __vbaI2I4();
        pppppfStack_358 = (float *****)0x0;
        ppppppfStack_60c = (float ******)0x4f1e19;
        __vbaFreeVar();
        pcVar23 = __vbaLateIdCallSt_exref;
        ppppppfVar19 = (float ******)pppppfStack_358;
        do {
          pppppfStack_358 = (float *****)ppppppfVar19;
          if ((short)uStack_49c < (short)pppppfStack_358) {
            ppppppfStack_3f0 = (float ******)0x3;
            ppppppfStack_61c = (float ******)0x22;
            ppppppfStack_618 = (float ******)0x3;
            ppppppfStack_3e8 = (float ******)0x0;
            ppppppfStack_614 = ppppppfStack_3ec;
            ppppppfStack_620 = ppppppfStack_48c;
            ppppppfStack_610 = (float ******)0x0;
            ppppppfStack_60c = ppppppfStack_3e4;
            ppppppfStack_624 = (float ******)0x4f1f41;
            __vbaLateIdSt();
            ppppppfStack_3f0 = (float ******)0x3;
            ppppppfStack_634 = (float ******)0x1a;
            ppppppfStack_630 = (float ******)0x3;
            ppppppfStack_3e8 = (float ******)0x2;
            ppppppfStack_62c = ppppppfStack_3ec;
            ppppppfStack_638 = ppppppfStack_48c;
            ppppppfStack_628 = (float ******)0x2;
            ppppppfStack_624 = ppppppfStack_3e4;
            uStack_640 = (double)CONCAT44(0x4f1f7e,(undefined4)uStack_640);
            __vbaLateIdSt();
            if (DAT_0050c53c == (float *******)0x0) {
              uStack_640 = 3.731548275327462e-307;
              ppppppfStack_644 = (float ******)0x4f1f97;
              __vbaNew2();
            }
            uStack_640 = (double)CONCAT44(&ppppppfStack_398,DAT_0050c53c);
            ppppppfStack_468 = (float ******)DAT_0050c53c;
            ppppppfStack_644 = (float ******)0x4f1fac;
            pppppppfVar14 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)pppppppfVar14 < 0) {
              ppppppfStack_644 = (float ******)0x18;
              ppppppfStack_648 = (float ******)&DAT_0040b410;
              ppppppfStack_64c = ppppppfStack_468;
              ppppppfStack_654 = (float ******)0x4f1fc7;
              ppppppfStack_650 = (float ******)pppppppfVar14;
              __vbaHresultCheckObj();
            }
            ppppppfStack_644 = (float ******)appppppfStack_454;
            ppppppfStack_648 = ppppppfStack_398;
            ppppppfStack_470 = ppppppfStack_398;
            ppppppfStack_64c = (float ******)0x4f1fe0;
            pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_398)[0x26])();
            uVar27 = 0;
            if ((int)pppppppfVar14 < 0) {
              ppppppfStack_60c = (float ******)0x98;
              ppppppfStack_610 = (float ******)&DAT_0040bb5c;
              ppppppfStack_614 = ppppppfStack_470;
              ppppppfStack_61c = (float ******)0x4f1ffe;
              ppppppfStack_618 = (float ******)pppppppfVar14;
              __vbaHresultCheckObj();
            }
            ppppppfStack_3e8 = (float ******)((float)appppppfStack_454[0] * (float)_DAT_00401370);
            pppppppfVar14 = (float *******)ppppppfStack_608;
            if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
            ppppppfStack_3f0 = (float ******)0x4;
            ppppppfStack_61c = (float ******)0x80010005;
            ppppppfStack_618 = (float ******)0x4;
            ppppppfStack_614 = ppppppfStack_3ec;
            ppppppfStack_620 = ppppppfStack_48c;
            ppppppfStack_60c = ppppppfStack_3e4;
            ppppppfStack_624 = (float ******)0x4f2055;
            ppppppfStack_610 = ppppppfStack_3e8;
            __vbaLateIdSt();
            ppppppfStack_624 = (float ******)0x4f205e;
            __vbaFreeObj();
            pppppfStack_358 = (float *****)0x0;
            ppppppfVar19 = (float ******)pppppfStack_358;
            goto LAB_004f2065;
          }
          pppppppfVar14 = (float *******)&DAT_00000001;
          while( true ) {
            sVar11 = (short)pppppppfVar14;
            if (3 < sVar11) break;
            ppppppfStack_610 = (float ******)(int)(short)pppppfStack_358;
            ppppppfStack_3f0 = (float ******)0x3;
            ppppppfStack_410 = (float ******)0x3;
            ppppppfStack_618 = (float ******)0x3;
            ppppppfStack_614 = ppppppfStack_3ec;
            ppppppfStack_60c = ppppppfStack_3e4;
            ppppppfStack_628 = (float ******)0x3;
            ppppppfStack_624 = ppppppfStack_40c;
            ppppppfStack_620 = (float ******)(int)sVar11;
            ppppppfStack_61c = ppppppfStack_404;
            uStack_640 = 4.24399161404481e-314;
            ppppppfStack_638 = (float ******)0x8;
            ppppppfStack_634 = ppppppfStack_42c;
            ppppppfStack_630 = (float ******)&DAT_0040ca6c;
            ppppppfStack_62c = ppppppfStack_424;
            ppppppfStack_644 = ppppppfStack_48c;
            ppppppfStack_648 = (float ******)0x4f1ed2;
            ppppppfStack_3e8 = ppppppfStack_610;
            __vbaLateIdCallSt();
            pppppppfVar15 = pppppppfVar14;
            pppppppfVar14 = (float *******)(uint)(ushort)(sVar11 + 1);
            if (SCARRY2(sVar11,1)) goto LAB_004f2fd8;
          }
          pppppppfVar15 = (float *******)__vbaLateIdCallLd_exref;
          ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppfStack_358 + 1);
        } while (!SCARRY2((short)pppppfStack_358,1));
      }
    }
  }
  else {
    if (DAT_0050b338 != 2) {
LAB_004f2f35:
      ppppppfStack_610 = (float ******)&ppppppfStack_48c;
      ppppppfStack_60c = (float ******)0x0;
      ppppppfStack_614 = (float ******)0x4f2f44;
      __vbaObjSetAddref();
      ppppppfStack_614 = (float ******)&LAB_004f2fc2;
      ppppppfStack_618 = (float ******)&ppppppfStack_48c;
      ppppppfStack_61c = (float ******)appppppfStack_488;
      ppppppfStack_620 = (float ******)0x2;
      ppppppfStack_624 = (float ******)0x4f2fbe;
      __vbaFreeObjList();
      return;
    }
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_61c = (float ******)0x5;
    ppppppfStack_618 = (float ******)0x3;
    ppppppfStack_3e8 = (float ******)0x4;
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_620 = ppppppfStack_48c;
    ppppppfStack_610 = (float ******)0x4;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_624 = (float ******)0x4f0938;
    __vbaLateIdSt();
    ppppppfStack_3f0 = (float ******)0x3;
    if (!SCARRY2(DAT_0050b332,2)) {
      ppppppfStack_610 = (float ******)(int)(short)(DAT_0050b332 + 2);
      ppppppfStack_61c = (float ******)0x4;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f0984;
      ppppppfStack_3e8 = ppppppfStack_610;
      __vbaLateIdSt();
      ppppppfStack_624 = (float ******)0x0;
      ppppppfStack_628 = (float ******)0x4;
      ppppppfStack_630 = &pppppfStack_3b0;
      ppppppfStack_62c = ppppppfStack_48c;
      ppppppfStack_634 = (float ******)0x4f0995;
      ppppppfStack_624 = (float ******)__vbaLateIdCallLd();
      ppppppfStack_628 = (float ******)0x4f099f;
      iVar12 = __vbaI4Var();
      if (!SBORROW4(iVar12,1)) {
        ppppppfStack_60c = (float ******)0x4f09b0;
        uStack_4c4 = __vbaI2I4();
        pppppfStack_358 = (float *****)0x0;
        ppppppfStack_60c = (float ******)0x4f09c2;
        __vbaFreeVar();
        pcVar23 = __vbaLateIdCallSt_exref;
        ppppppfVar19 = (float ******)pppppfStack_358;
        do {
          pppppfStack_358 = (float *****)ppppppfVar19;
          if ((short)uStack_4c4 < (short)pppppfStack_358) {
            ppppppfStack_3f0 = (float ******)0x3;
            ppppppfStack_61c = (float ******)0x22;
            ppppppfStack_618 = (float ******)0x3;
            ppppppfStack_3e8 = (float ******)0x0;
            ppppppfStack_614 = ppppppfStack_3ec;
            ppppppfStack_620 = ppppppfStack_48c;
            ppppppfStack_610 = (float ******)0x0;
            ppppppfStack_60c = ppppppfStack_3e4;
            ppppppfStack_624 = (float ******)0x4f0ae7;
            __vbaLateIdSt();
            ppppppfStack_3f0 = (float ******)0x3;
            ppppppfStack_634 = (float ******)0x1a;
            ppppppfStack_630 = (float ******)0x3;
            ppppppfStack_3e8 = (float ******)0x2;
            ppppppfStack_62c = ppppppfStack_3ec;
            ppppppfStack_638 = ppppppfStack_48c;
            ppppppfStack_628 = (float ******)0x2;
            ppppppfStack_624 = ppppppfStack_3e4;
            uStack_640 = (double)CONCAT44(0x4f0b24,(undefined4)uStack_640);
            __vbaLateIdSt();
            if (DAT_0050c53c == (float *******)0x0) {
              uStack_640 = 3.731548275327462e-307;
              ppppppfStack_644 = (float ******)0x4f0b3d;
              __vbaNew2();
            }
            uStack_640 = (double)CONCAT44(&ppppppfStack_398,DAT_0050c53c);
            ppppppfStack_468 = (float ******)DAT_0050c53c;
            ppppppfStack_644 = (float ******)0x4f0b52;
            pppppppfVar14 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)pppppppfVar14 < 0) {
              ppppppfStack_644 = (float ******)0x18;
              ppppppfStack_648 = (float ******)&DAT_0040b410;
              ppppppfStack_64c = ppppppfStack_468;
              ppppppfStack_654 = (float ******)0x4f0b6d;
              ppppppfStack_650 = (float ******)pppppppfVar14;
              __vbaHresultCheckObj();
            }
            ppppppfStack_644 = (float ******)appppppfStack_454;
            ppppppfStack_648 = ppppppfStack_398;
            ppppppfStack_470 = ppppppfStack_398;
            ppppppfStack_64c = (float ******)0x4f0b86;
            pppppppfVar14 = (float *******)(*(code *)(*ppppppfStack_398)[0x26])();
            uVar27 = 0;
            if ((int)pppppppfVar14 < 0) {
              ppppppfStack_60c = (float ******)0x98;
              ppppppfStack_610 = (float ******)&DAT_0040bb5c;
              ppppppfStack_614 = ppppppfStack_470;
              ppppppfStack_61c = (float ******)0x4f0ba4;
              ppppppfStack_618 = (float ******)pppppppfVar14;
              __vbaHresultCheckObj();
            }
            ppppppfStack_3e8 = (float ******)((float)appppppfStack_454[0] * (float)_DAT_00401730);
            pppppppfVar14 = (float *******)ppppppfStack_608;
            if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
            ppppppfStack_3f0 = (float ******)0x4;
            ppppppfStack_61c = (float ******)0x80010005;
            ppppppfStack_618 = (float ******)0x4;
            ppppppfStack_614 = ppppppfStack_3ec;
            ppppppfStack_620 = ppppppfStack_48c;
            ppppppfStack_60c = ppppppfStack_3e4;
            ppppppfStack_624 = (float ******)0x4f0bfb;
            ppppppfStack_610 = ppppppfStack_3e8;
            __vbaLateIdSt();
            ppppppfStack_624 = (float ******)0x4f0c04;
            __vbaFreeObj();
            pppppfStack_358 = (float *****)0x0;
            ppppppfVar19 = (float ******)pppppfStack_358;
            goto LAB_004f0c0b;
          }
          pppppppfVar14 = (float *******)0x0;
          while( true ) {
            sVar11 = (short)pppppppfVar14;
            if (3 < sVar11) break;
            ppppppfStack_610 = (float ******)(int)(short)pppppfStack_358;
            ppppppfStack_3f0 = (float ******)0x3;
            ppppppfStack_410 = (float ******)0x3;
            ppppppfStack_618 = (float ******)0x3;
            ppppppfStack_614 = ppppppfStack_3ec;
            ppppppfStack_60c = ppppppfStack_3e4;
            ppppppfStack_628 = (float ******)0x3;
            ppppppfStack_624 = ppppppfStack_40c;
            ppppppfStack_620 = (float ******)(int)sVar11;
            ppppppfStack_61c = ppppppfStack_404;
            uStack_640 = 4.24399161404481e-314;
            ppppppfStack_638 = (float ******)0x8;
            ppppppfStack_634 = ppppppfStack_42c;
            ppppppfStack_630 = (float ******)&DAT_0040ca6c;
            ppppppfStack_62c = ppppppfStack_424;
            ppppppfStack_644 = ppppppfStack_48c;
            ppppppfStack_648 = (float ******)0x4f0a78;
            ppppppfStack_3e8 = ppppppfStack_610;
            __vbaLateIdCallSt();
            pppppppfVar15 = pppppppfVar14;
            pppppppfVar14 = (float *******)(uint)(ushort)(sVar11 + 1);
            if (SCARRY2(sVar11,1)) goto LAB_004f2fd8;
          }
          pppppppfVar15 = (float *******)__vbaLateIdCallLd_exref;
          ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppfStack_358 + 1);
        } while (!SCARRY2((short)pppppfStack_358,1));
      }
    }
  }
  goto LAB_004f2fd8;
LAB_004eefe5:
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_344 = (float ******)&DAT_0050b420;
    pwStack_348 = L"\x01\aꙴ@";
    puStack_34c = (undefined4 *)0x4eeffe;
    __vbaNew2();
  }
  ppppppfStack_344 = (float ******)DAT_0050b420;
  pwStack_348 = L"閍Ｔ\xffff剐ᗿ႐@ꅦ댲Pඋ돌Pƾ";
  pwStack_348 = (wchar_t *)(*(code *)(*DAT_0050b420)[0xea])();
  puStack_34c = &uStack_308;
  pppppfStack_350 = (float *****)0x4ef01a;
  __vbaObjSet();
  uStack_318 = CONCAT22(uStack_318._2_2_,DAT_0050b332);
  pppppfStack_254 = (float *****)&DAT_00000001;
  pppppppfVar24 = DAT_0050b3cc;
  ppppppfVar9 = (float ******)pppppfStack_254;
  while( true ) {
    pppppfStack_254 = (float *****)ppppppfVar9;
    ppppppfVar19 = (float ******)pppppfStack_254;
    ppppppfVar22 = (float ******)0x0;
    sVar11 = (short)pppppfStack_254;
    if ((short)uStack_318 < sVar11) break;
    if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
      ppppppfStack_344 = (float ******)0x4ef086;
      iVar12 = __vbaGenerateBoundsError();
      pppppppfVar24 = DAT_0050b3cc;
    }
    else {
      ppppppfVar22 = (float ******)-(int)pppppppfVar24[7];
      if (pppppppfVar24[6] <= ppppppfVar22) {
        ppppppfStack_344 = (float ******)0x4ef05a;
        __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      ppppppfVar19 = (float ******)((int)sVar11 - (int)pppppppfVar24[5]);
      if (pppppppfVar24[4] <= ppppppfVar19) {
        ppppppfStack_344 = (float ******)0x4ef071;
        __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      iVar12 = (int)((int)pppppppfVar24[6] * (int)ppppppfVar19 + (int)ppppppfVar22) * 4;
    }
    if (*(float *)((int)pppppppfVar24[3] + iVar12) != _DAT_00402558) {
      pppppfStack_264 = (float *****)-(float)_DAT_0050b134;
      uStack_320 = CONCAT22(uStack_320._2_2_,DAT_0050b332);
      pppppfStack_250 = (float *****)0x1;
      pppppfVar4 = pppppfStack_250;
      while( true ) {
        pppppfStack_250 = pppppfVar4;
        if ((short)uStack_320 < (short)pppppfStack_250) break;
        if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
          ppppppfStack_344 = (float ******)0x4ef10c;
          iVar12 = __vbaGenerateBoundsError();
          pppppppfVar24 = DAT_0050b3cc;
        }
        else {
          ppppppfVar22 = DAT_0050b3d4[5];
          ppppppfVar19 = (float ******)((int)(short)pppppfStack_250 - (int)ppppppfVar22);
          if (DAT_0050b3d4[4] <= ppppppfVar19) {
            ppppppfStack_344 = (float ******)0x4ef0fb;
            __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          iVar12 = (int)ppppppfVar19 * 4;
        }
        ppppppfVar19 = DAT_0050b3d4[3];
        if (*(float *)((int)ppppppfVar19 + iVar12) == _DAT_00401488) {
          if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
            ppppppfStack_344 = (float ******)0x4ef178;
            iVar12 = __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            ppppppfVar22 = (float ******)((int)(short)pppppfStack_250 - (int)pppppppfVar24[7]);
            if (pppppppfVar24[6] <= ppppppfVar22) {
              ppppppfStack_344 = (float ******)0x4ef14b;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            ppppppfVar19 = (float ******)((int)(short)pppppfStack_254 - (int)pppppppfVar24[5]);
            if (pppppppfVar24[4] <= ppppppfVar19) {
              ppppppfStack_344 = (float ******)0x4ef163;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (int)((int)pppppppfVar24[6] * (int)ppppppfVar19 + (int)ppppppfVar22) * 4;
          }
          if (*(float *)((int)pppppppfVar24[3] + iVar12) != _DAT_00401488) {
            if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
              ppppppfStack_344 = (float ******)0x4ef1de;
              iVar12 = __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            else {
              ppppppfVar22 = (float ******)((int)(short)pppppfStack_250 - (int)pppppppfVar24[7]);
              if (pppppppfVar24[6] <= ppppppfVar22) {
                ppppppfStack_344 = (float ******)0x4ef1b1;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              ppppppfVar19 = (float ******)((int)(short)pppppfStack_254 - (int)pppppppfVar24[5]);
              if (pppppppfVar24[4] <= ppppppfVar19) {
                ppppppfStack_344 = (float ******)0x4ef1c9;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              iVar12 = (int)((int)pppppppfVar24[6] * (int)ppppppfVar19 + (int)ppppppfVar22) * 4;
            }
            if (*(float *)((int)pppppppfVar24[3] + iVar12) == _DAT_00401488) goto LAB_004ef201;
            goto LAB_004ef7c1;
          }
        }
        else {
LAB_004ef201:
          if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
            ppppppfStack_344 = (float ******)0x4ef22e;
            iVar12 = __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            iVar12 = (int)(short)pppppfStack_250;
            ppppppfVar22 = DAT_0050b3d4[5];
            if (DAT_0050b3d4[4] <= (float ******)(iVar12 - (int)ppppppfVar22)) {
              ppppppfStack_344 = (float ******)0x4ef21d;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (iVar12 - (int)ppppppfVar22) * 4;
          }
          ppppppfVar19 = DAT_0050b3d4[3];
          if (*(float *)((int)ppppppfVar19 + iVar12) != _DAT_00401488) {
            if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
              ppppppfStack_344 = (float ******)0x4ef296;
              iVar12 = __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            else {
              ppppppfVar22 = (float ******)((int)(short)pppppfStack_250 - (int)pppppppfVar24[7]);
              if (pppppppfVar24[6] <= ppppppfVar22) {
                ppppppfStack_344 = (float ******)0x4ef269;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              ppppppfVar19 = (float ******)((int)(short)pppppfStack_254 - (int)pppppppfVar24[5]);
              if (pppppppfVar24[4] <= ppppppfVar19) {
                ppppppfStack_344 = (float ******)0x4ef281;
                __vbaGenerateBoundsError();
                pppppppfVar24 = DAT_0050b3cc;
              }
              iVar12 = (int)((int)pppppppfVar24[6] * (int)ppppppfVar19 + (int)ppppppfVar22) * 4;
            }
            if (*(float *)((int)pppppppfVar24[3] + iVar12) == _DAT_00401488) goto LAB_004ef38d;
          }
          uVar27 = 0;
          if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
            ppppppfStack_344 = (float ******)0x4ef2ec;
            pppppfStack_334 = (float *****)__vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            iVar12 = (int)(short)pppppfStack_250;
            ppppppfVar19 = DAT_0050b3d4[5];
            if (DAT_0050b3d4[4] <= (float ******)(iVar12 - (int)ppppppfVar19)) {
              ppppppfStack_344 = (float ******)0x4ef2d5;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            pppppfStack_334 = (float *****)((iVar12 - (int)ppppppfVar19) * 4);
          }
          if ((pppppppfVar24 == (float *******)0x0) || (*(short *)pppppppfVar24 != 2)) {
            ppppppfStack_344 = (float ******)0x4ef341;
            iVar12 = __vbaGenerateBoundsError();
            pppppppfVar24 = DAT_0050b3cc;
          }
          else {
            iVar12 = (int)(short)pppppfStack_250;
            ppppppfVar19 = pppppppfVar24[7];
            if (pppppppfVar24[6] <= (float ******)(iVar12 - (int)ppppppfVar19)) {
              ppppppfStack_344 = (float ******)0x4ef314;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar26 = (int)(short)pppppfStack_254;
            ppppppfVar22 = pppppppfVar24[5];
            if (pppppppfVar24[4] <= (float ******)(iVar26 - (int)ppppppfVar22)) {
              ppppppfStack_344 = (float ******)0x4ef32c;
              __vbaGenerateBoundsError();
              pppppppfVar24 = DAT_0050b3cc;
            }
            iVar12 = (int)((int)pppppppfVar24[6] * (iVar26 - (int)ppppppfVar22) +
                          (iVar12 - (int)ppppppfVar19)) * 4;
          }
          ppppppfVar19 = pppppppfVar24[3];
          ppppppfVar22 = DAT_0050b3d4[3];
          pppppfStack_260 =
               (float *****)
               (*(float *)((int)ppppppfVar19 + iVar12) +
               *(float *)((int)ppppppfVar22 + (int)pppppfStack_334));
          if ((uVar27 & 0xd) != 0) {
            __vbaFPException();
            return;
          }
          if ((float)pppppfStack_264 < (float)pppppfStack_260) {
            pppppfStack_268 = pppppfStack_250;
            pppppfStack_264 = pppppfStack_260;
          }
        }
LAB_004ef38d:
        pppppfVar4 = (float *****)(uint)(ushort)((short)pppppfStack_250 + 1);
        if (SCARRY2((short)pppppfStack_250,1)) goto LAB_004ef9a0;
      }
      if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
        ppppppfStack_344 = (float ******)0x4ef3d1;
        iVar12 = __vbaGenerateBoundsError();
        pppppppfVar24 = DAT_0050b3cc;
      }
      else {
        iVar12 = (int)(short)pppppfStack_254;
        ppppppfVar22 = DAT_0050b3d4[5];
        if (DAT_0050b3d4[4] <= (float ******)(iVar12 - (int)ppppppfVar22)) {
          ppppppfStack_344 = (float ******)0x4ef3c0;
          __vbaGenerateBoundsError();
          pppppppfVar24 = DAT_0050b3cc;
        }
        iVar12 = (iVar12 - (int)ppppppfVar22) * 4;
      }
      ppppppfVar19 = DAT_0050b3d4[3];
      if (*(float *)((int)ppppppfVar19 + iVar12) == _DAT_00401488) {
        DAT_0050b3c2 = 1;
        if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
          ppppppfStack_344 = (float ******)0x4ef424;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          iVar12 = (int)(short)pppppfStack_254;
          ppppppfVar19 = DAT_0050b3d4[5];
          if (DAT_0050b3d4[4] <= (float ******)(iVar12 - (int)ppppppfVar19)) {
            ppppppfStack_344 = (float ******)0x4ef419;
            __vbaGenerateBoundsError();
          }
          iVar12 = (iVar12 - (int)ppppppfVar19) * 4;
        }
        *(float ******)((int)DAT_0050b3d4[3] + iVar12) = pppppfStack_264;
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_344 = (float ******)0x4ef47d;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          iVar26 = (int)(short)pppppfStack_268;
          iVar12 = *(int *)(DAT_0050b3e8 + 0xe);
          if (*(uint *)(DAT_0050b3e8 + 0xc) <= (uint)(iVar26 - iVar12)) {
            ppppppfStack_344 = (float ******)0x4ef455;
            __vbaGenerateBoundsError();
          }
          ppppppfVar22 = (float ******)-*(int *)(DAT_0050b3e8 + 10);
          if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar22) {
            ppppppfStack_344 = (float ******)0x4ef469;
            __vbaGenerateBoundsError();
          }
          iVar12 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar22 + (iVar26 - iVar12)) * 2;
        }
        pppppfStack_258 = (float *****)&DAT_00000001;
        uStack_328 = CONCAT22(uStack_328._2_2_,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar12))
        ;
        ppppppfVar9 = (float ******)pppppfStack_258;
        while( true ) {
          pppppfStack_258 = (float *****)ppppppfVar9;
          sVar11 = (short)pppppfStack_258;
          if ((short)uStack_328 < sVar11) break;
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_344 = (float ******)0x4ef4f9;
            ppppppfVar19 = (float ******)__vbaGenerateBoundsError();
          }
          else {
            pppppfStack_304 =
                 (float *****)((int)(short)pppppfStack_268 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(float *******)(DAT_0050b3e8 + 0xc) <= pppppfStack_304) {
              ppppppfStack_344 = (float ******)0x4ef4c8;
              __vbaGenerateBoundsError();
            }
            ppppppfVar22 = (float ******)((int)sVar11 - *(int *)(DAT_0050b3e8 + 10));
            if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar22) {
              ppppppfStack_344 = (float ******)0x4ef4df;
              __vbaGenerateBoundsError();
            }
            ppppppfVar19 = (float ******)
                           ((int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar22 +
                                 (int)pppppfStack_304) * 2);
          }
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_344 = (float ******)0x4ef553;
            iVar12 = __vbaGenerateBoundsError();
          }
          else {
            pppppfStack_2fc =
                 (float *****)((int)(short)pppppfStack_254 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(uint *)(DAT_0050b3e8 + 0xc) <= pppppfStack_2fc) {
              ppppppfStack_344 = (float ******)0x4ef523;
              __vbaGenerateBoundsError();
            }
            ppppppfVar22 = (float ******)((int)(short)pppppfStack_258 - *(int *)(DAT_0050b3e8 + 10))
            ;
            if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar22) {
              ppppppfStack_344 = (float ******)0x4ef53b;
              __vbaGenerateBoundsError();
            }
            iVar12 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar22 + (int)pppppfStack_2fc) * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar12) =
               *(undefined2 *)((int)ppppppfVar19 + *(int *)(DAT_0050b3e8 + 6));
          ppppppfVar9 = (float ******)(uint)(ushort)((short)pppppfStack_258 + 1);
          if (SCARRY2((short)pppppfStack_258,1)) goto LAB_004ef9a0;
        }
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_344 = (float ******)0x4ef5d1;
          ppppppfVar19 = (float ******)__vbaGenerateBoundsError();
        }
        else {
          ppppppfVar22 = (float ******)((int)(short)pppppfStack_268 - *(int *)(DAT_0050b3e8 + 0xe));
          if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar22) {
            ppppppfStack_344 = (float ******)0x4ef59f;
            __vbaGenerateBoundsError();
          }
          pppppfStack_300 = (float *****)-*(int *)(DAT_0050b3e8 + 10);
          if (*(uint *)(DAT_0050b3e8 + 8) <= pppppfStack_300) {
            ppppppfStack_344 = (float ******)0x4ef5b9;
            __vbaGenerateBoundsError();
          }
          ppppppfVar19 = (float ******)
                         ((int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)pppppfStack_300 +
                               (int)ppppppfVar22) * 2);
        }
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_344 = (float ******)0x4ef629;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfVar22 = (float ******)((int)(short)pppppfStack_254 - *(int *)(DAT_0050b3e8 + 0xe));
          if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar22) {
            ppppppfStack_344 = (float ******)0x4ef5f5;
            __vbaGenerateBoundsError();
          }
          ppppfStack_2f8 = (float ****)-*(int *)(DAT_0050b3e8 + 10);
          if (*(uint *)(DAT_0050b3e8 + 8) <= ppppfStack_2f8) {
            ppppppfStack_344 = (float ******)0x4ef60f;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppfStack_2f8 + (int)ppppppfVar22) * 2
          ;
        }
        sVar11 = *(short *)((int)ppppppfVar19 + *(int *)(DAT_0050b3e8 + 6));
        if (SCARRY2(sVar11,1)) goto LAB_004ef9a0;
        *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar12) = sVar11 + 1;
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_344 = (float ******)0x4ef6f3;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          iVar12 = (int)(short)pppppfStack_254;
          ppppppfVar22 = (float ******)(iVar12 - *(int *)(DAT_0050b3e8 + 0xe));
          pppppfStack_304 = (float *****)ppppppfVar22;
          if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar22) {
            ppppppfStack_344 = (float ******)0x4ef676;
            __vbaGenerateBoundsError();
          }
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_344 = (float ******)0x4ef6c4;
            iVar12 = __vbaGenerateBoundsError();
          }
          else {
            uVar25 = iVar12 - *(int *)(DAT_0050b3e8 + 0xe);
            if (*(uint *)(DAT_0050b3e8 + 0xc) <= uVar25) {
              ppppppfStack_344 = (float ******)0x4ef696;
              __vbaGenerateBoundsError();
            }
            iVar12 = *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= (uint)-iVar12) {
              ppppppfStack_344 = (float ******)0x4ef6aa;
              __vbaGenerateBoundsError();
            }
            iVar12 = (*(int *)(DAT_0050b3e8 + 0xc) * -iVar12 + uVar25) * 2;
            ppppppfVar22 = (float ******)pppppfStack_304;
          }
          ppppppfVar19 = (float ******)
                         ((int)*(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar12) -
                         *(int *)(DAT_0050b3e8 + 10));
          if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar19) {
            ppppppfStack_344 = (float ******)0x4ef6df;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar19 + (int)ppppppfVar22) * 2;
        }
        *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar12) = (short)pppppfStack_254;
        if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
          ppppppfStack_344 = (float ******)0x4ef74b;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfVar19 = (float ******)((int)(short)pppppfStack_254 - (int)DAT_0050b3cc[7]);
          if (DAT_0050b3cc[6] <= ppppppfVar19) {
            ppppppfStack_344 = (float ******)0x4ef722;
            __vbaGenerateBoundsError();
          }
          ppppppfVar22 = (float ******)-(int)DAT_0050b3cc[5];
          if (DAT_0050b3cc[4] <= ppppppfVar22) {
            ppppppfStack_344 = (float ******)0x4ef736;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)ppppppfVar19 + (int)DAT_0050b3cc[6] * (int)ppppppfVar22) * 4;
        }
        if (*(float *)((int)DAT_0050b3cc[3] + iVar12) == _DAT_00401488) {
          pppppfStack_25c = (float *****)&DAT_00000001;
        }
        if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
          ppppppfStack_344 = (float ******)0x4ef7ac;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfVar22 = (float ******)-(int)DAT_0050b3cc[7];
          if (DAT_0050b3cc[6] <= ppppppfVar22) {
            ppppppfStack_344 = (float ******)0x4ef783;
            __vbaGenerateBoundsError();
          }
          ppppppfVar19 = (float ******)-(int)DAT_0050b3cc[5];
          if (DAT_0050b3cc[4] <= ppppppfVar19) {
            ppppppfStack_344 = (float ******)0x4ef797;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)DAT_0050b3cc[6] * (int)ppppppfVar19 + (int)ppppppfVar22) * 4;
        }
        *(float ******)((int)DAT_0050b3cc[3] + iVar12) = pppppfStack_264;
        pppppppfVar24 = DAT_0050b3cc;
      }
    }
LAB_004ef7c1:
    ppppppfVar9 = (float ******)(uint)(ushort)((short)pppppfStack_254 + 1);
    if (SCARRY2((short)pppppfStack_254,1)) goto LAB_004ef9a0;
  }
  if (DAT_0050b3c2 == 0) {
    ppppppfStack_344 = (float ******)&ppppfStack_2c4;
    pppppfStack_2bc = (float *****)&pppppfStack_268;
    ppppfStack_2c4 = (float ****)0x4002;
    pwStack_348 = L"㖋መ@킋䶍ￌ맖\x04耂સ";
    Ordinal_536();
    pwStack_348 = L"ҹȀ뢀\n";
    __vbaStrMove();
    pppfStack_2ac = (float ***)0x80020004;
    uStack_29c = 0x80020004;
    pppppfStack_2b4 = (float *****)0xa;
    pppppfStack_2a4 = (float *****)0xa;
    pppppfStack_2cc = (float *****)0x40c860;
    ppppfStack_2d4 = (float ****)0x8;
    pwStack_348 = L"喋棌䫐A䶍쟐책";
    __vbaVarDup();
    pwStack_348 = L"Loop detected.  Forward Pass cannot proceed past node";
    pppppfStack_270 = (float *****)0x0;
    puStack_34c = (undefined4 *)0x4ef87a;
    puStack_34c = (undefined4 *)__vbaStrMove();
    pppppfStack_350 = (float *****)0x4ef881;
    pppppfStack_27c = (float *****)__vbaStrCat();
    pppppfStack_350 = (float *****)&pppppfStack_2b4;
    pppppfStack_354 = (float *****)&pppppfStack_2a4;
    pppppfStack_358 = &ppppfStack_294;
    pppppfStack_360 = (float *****)&pppppfStack_284;
    uStack_35c = 0x10;
    pppppfStack_284 = (float *****)0x8;
    ppppppfStack_364 = (float ******)0x4ef89f;
    Ordinal_595();
    ppppppfStack_364 = &pppppfStack_270;
    ppppppfStack_368 = (float ******)&ppppppfStack_26c;
    pppppfStack_36c = (float *****)0x2;
    ppppppfStack_370 = (float ******)0x4ef8af;
    __vbaFreeStrList();
    ppppppfStack_370 = &pppppfStack_2b4;
    pppppfStack_374 = (float *****)&pppppfStack_2a4;
    ppppfStack_378 = (float ****)&ppppfStack_294;
    ppppppfStack_37c = &pppppfStack_284;
    pppppfStack_380 = (float *****)0x4;
    ppppppfStack_384 = (float ******)0x4ef8c7;
    __vbaFreeVarList();
    if (DAT_0050c53c == (float *******)0x0) {
      ppppppfStack_364 = (float ******)&DAT_0050c53c;
      ppppppfStack_368 = (float ******)&DAT_0040b420;
      pppppfStack_36c = (float *****)0x4ef8e3;
      __vbaNew2();
    }
    pppppppfVar24 = DAT_0050c53c;
    if (DAT_0050b420 == (float *******)0x0) {
      ppppppfStack_364 = (float ******)&DAT_0050b420;
      ppppppfStack_368 = (float ******)&DAT_00408c88;
      pppppfStack_36c = (float *****)0x4ef902;
      __vbaNew2();
    }
    ppppppfVar19 = *pppppppfVar24;
    ppppppfStack_368 = (float ******)&ppppfStack_274;
    ppppppfStack_364 = (float ******)DAT_0050b420;
    pppppfStack_36c = (float *****)0x4ef915;
    pppppfStack_36c = (float *****)__vbaObjSetAddref();
    ppppppfStack_370 = (float ******)pppppppfVar24;
    pppppfStack_374 = (float *****)0x4ef91a;
    ppppppfVar19 = (float ******)(*(code *)ppppppfVar19[4])();
    if ((int)ppppppfVar19 < 0) {
      pppppfStack_374 = (float *****)0x10;
      ppppfStack_378 = (float ****)&DAT_0040b410;
      ppppppfStack_37c = (float ******)pppppppfVar24;
      ppppppfStack_384 = (float ******)0x4ef92f;
      pppppfStack_380 = (float *****)ppppppfVar19;
      __vbaHresultCheckObj();
    }
    pppppfStack_374 = (float *****)0x4ef938;
    __vbaFreeObj();
    ppppppfStack_344 = (float ******)0x4ef93d;
    FUN_00444530();
    goto code_r0x004ef93e;
  }
  pwStack_348 = (wchar_t *)&uStack_308;
  ppppppfStack_344 = (float ******)0x0;
  puStack_34c = (undefined4 *)0x4ef7f3;
  __vbaObjSetAddref();
  if ((short)pppppfStack_25c != 0) {
code_r0x004ef93e:
    ppppppfStack_344 = (float ******)&LAB_004ef98a;
    pwStack_348 = L"诃\xf04d幟襤\r";
    __vbaFreeObj();
    return;
  }
  goto LAB_004eefe5;
  while( true ) {
    ppppppfStack_3e8 = (float ******)(int)(short)pppppfStack_358;
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_60c = (float ******)0x0;
    ppppppfStack_610 = (float ******)0x80010005;
    ppppppfStack_618 = &pppppfStack_3b0;
    ppppppfStack_614 = ppppppfStack_48c;
    ppppppfStack_61c = (float ******)0x4f2098;
    ppppppfStack_60c = (float ******)(*(code *)pppppppfVar15)();
    ppppppfStack_610 = (float ******)0x4f20a2;
    __vbaR4Var();
    pppppppfVar14 = (float *******)ppppppfStack_608;
    if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
    ppppppfStack_60c = (float ******)0x4f20b8;
    iVar12 = __vbaFpI4();
    ppppppfStack_410 = (float ******)0x3;
    ppppppfStack_618 = ppppppfStack_3f0;
    ppppppfStack_620 = (float ******)((int)(iVar12 + (iVar12 >> 0x1f & 3U)) >> 2);
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_610 = ppppppfStack_3e8;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_62c = (float ******)&DAT_00000001;
    ppppppfStack_630 = (float ******)0x39;
    ppppppfStack_628 = (float ******)0x3;
    ppppppfStack_624 = ppppppfStack_40c;
    ppppppfStack_634 = ppppppfStack_48c;
    ppppppfStack_61c = ppppppfStack_404;
    ppppppfStack_638 = (float ******)0x4f2122;
    __vbaLateIdCallSt();
    ppppppfStack_60c = (float ******)0x4f212e;
    __vbaFreeVar();
    ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppfStack_358 + 1);
    if (SCARRY2((short)pppppfStack_358,1)) break;
LAB_004f2065:
    pppppfStack_358 = (float *****)ppppppfVar19;
    if (3 < (short)pppppfStack_358) {
      ppppppfStack_60c = (float ******)0x4f214a;
      iStack_52c = FUN_0042b130();
      ppppppfStack_610 = (float ******)(float)iStack_52c;
      ppppppfStack_3f0 = (float ******)0x4;
      ppppppfStack_61c = (float ******)0x80010006;
      ppppppfStack_618 = (float ******)0x4;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f2197;
      ppppppfStack_3e8 = ppppppfStack_610;
      __vbaLateIdSt();
      if (DAT_0050c53c == (float *******)0x0) {
        ppppppfStack_624 = (float ******)&DAT_0050c53c;
        ppppppfStack_628 = (float ******)&DAT_0040b420;
        ppppppfStack_62c = (float ******)0x4f21b0;
        __vbaNew2();
      }
      ppppppfStack_624 = (float ******)&ppppppfStack_398;
      ppppppfStack_628 = (float ******)DAT_0050c53c;
      ppppppfStack_468 = (float ******)DAT_0050c53c;
      ppppppfStack_62c = (float ******)0x4f21c5;
      pppppppfVar14 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
      if ((int)pppppppfVar14 < 0) {
        ppppppfStack_62c = (float ******)0x18;
        ppppppfStack_630 = (float ******)&DAT_0040b410;
        ppppppfStack_634 = ppppppfStack_468;
        uStack_640 = (double)CONCAT44(0x4f21e0,(undefined4)uStack_640);
        ppppppfStack_638 = (float ******)pppppppfVar14;
        __vbaHresultCheckObj();
      }
      ppppppfStack_62c = (float ******)appppppfStack_454;
      ppppppfStack_630 = ppppppfStack_398;
      ppppppfStack_470 = ppppppfStack_398;
      ppppppfStack_634 = (float ******)0x4f21f9;
      iVar12 = (*(code *)(*ppppppfStack_398)[0x26])();
      uVar27 = 0;
      if (iVar12 < 0) {
        ppppppfStack_634 = (float ******)0x98;
        ppppppfStack_638 = (float ******)&DAT_0040bb5c;
        uStack_640 = (double)CONCAT44(ppppppfStack_470,iVar12);
        ppppppfStack_644 = (float ******)0x4f2217;
        __vbaHresultCheckObj();
      }
      ppppppfStack_634 = (float ******)0x0;
      ppppppfStack_638 = (float ******)0x80010005;
      uStack_640 = (double)CONCAT44(ppppppfStack_48c,&pppppfStack_3b0);
      ppppppfStack_644 = (float ******)0x4f222b;
      (*(code *)pppppppfVar15)();
      ppppppfStack_634 = &pppppfStack_3b0;
      ppppppfStack_638 = (float ******)0x4f2238;
      fVar28 = (float10)__vbaR4Var();
      pppppppfVar14 = (float *******)ppppppfStack_608;
      if (((uVar27 & 0xd) != 0) ||
         (ppppppfStack_3e8 =
               (float ******)
               (float)(((float10)(float)appppppfStack_454[0] - fVar28) * (float10)_DAT_00401268),
         (uVar27 & 0xd) != 0)) goto LAB_004f2fd3;
      ppppppfStack_3f0 = (float ******)0x4;
      ppppppfStack_61c = (float ******)0x80010003;
      ppppppfStack_618 = (float ******)0x4;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f2299;
      ppppppfStack_610 = ppppppfStack_3e8;
      __vbaLateIdSt();
      ppppppfStack_624 = (float ******)0x4f22a2;
      __vbaFreeObj();
      ppppppfStack_624 = (float ******)0x4f22ab;
      __vbaFreeVar();
      ppppppfVar19 = ppppppfStack_404;
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_644 = (float ******)0x1;
      ppppppfStack_648 = (float ******)0x38;
      ppppppfStack_628 = (float ******)0x0;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(ppppppfStack_40c,2);
      ppppppfStack_638 = (float ******)0x4;
      ppppppfStack_634 = ppppppfStack_404;
      ppppppfStack_64c = ppppppfStack_48c;
      ppppppfStack_650 = (float ******)0x4f230d;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x1;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_628 = (float ******)0x1;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(ppppppfStack_40c,2);
      ppppppfStack_644 = (float ******)0x1;
      ppppppfStack_648 = (float ******)0x38;
      ppppppfStack_638 = (float ******)0x1;
      ppppppfStack_64c = ppppppfStack_48c;
      ppppppfStack_634 = ppppppfVar19;
      ppppppfStack_650 = (float ******)0x4f236b;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x2;
      ppppppfStack_410 = (float ******)0x2;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_644 = (float ******)0x1;
      ppppppfStack_648 = (float ******)0x38;
      ppppppfStack_628 = (float ******)0x2;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(ppppppfStack_40c,2);
      ppppppfStack_638 = (float ******)0x7;
      ppppppfStack_634 = ppppppfVar19;
      ppppppfStack_64c = ppppppfStack_48c;
      ppppppfStack_650 = (float ******)0x4f23d1;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_644 = (float ******)&DAT_00000001;
      ppppppfStack_648 = (float ******)0x38;
      ppppppfStack_628 = (float ******)0x3;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(ppppppfStack_40c,2);
      ppppppfStack_638 = (float ******)0x7;
      ppppppfStack_64c = ppppppfStack_48c;
      ppppppfStack_634 = ppppppfVar19;
      ppppppfStack_650 = (float ******)0x4f242d;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_634 = (float ******)0xa;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_638 = ppppppfStack_48c;
      ppppppfStack_628 = (float ******)0x0;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(0x4f2467,(undefined4)uStack_640);
      __vbaLateIdSt();
      uStack_4b4 = 3;
      uStack_4b0 = 1;
      pppppppfVar14 = (float *******)0x0;
      goto LAB_004f247d;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_610 = (float ******)(int)sVar11;
    ppppppfStack_618 = (float ******)0x3;
    ppppppfStack_61c = (float ******)0xb;
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_620 = ppppppfStack_48c;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_624 = (float ******)0x4f24c5;
    ppppppfStack_3e8 = ppppppfStack_610;
    __vbaLateIdSt();
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_634 = (float ******)0x26;
    ppppppfStack_630 = (float ******)0x3;
    ppppppfStack_3e8 = (float ******)0xffff;
    ppppppfStack_62c = ppppppfStack_3ec;
    ppppppfStack_638 = ppppppfStack_48c;
    ppppppfStack_628 = (float ******)0xffff;
    ppppppfStack_624 = ppppppfStack_3e4;
    uStack_640 = (double)CONCAT44(0x4f2502,(undefined4)uStack_640);
    __vbaLateIdSt();
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_64c = (float ******)0x27;
    ppppppfStack_648 = (float ******)0x3;
    ppppppfStack_3e8 = (float ******)0xff0000;
    ppppppfStack_644 = ppppppfStack_3ec;
    ppppppfStack_650 = ppppppfStack_48c;
    uStack_640 = (double)CONCAT44(ppppppfStack_3e4,0xff0000);
    ppppppfStack_654 = (float ******)0x4f253f;
    __vbaLateIdSt();
    pppppppfVar14 = (float *******)CONCAT22(extraout_var_04,(short)uStack_4b0 + sVar11);
    if (SCARRY2((short)uStack_4b0,sVar11)) break;
LAB_004f247d:
    pppppppfVar15 = pppppppfVar14;
    sVar11 = (short)pppppppfVar15;
    if ((short)uStack_4b4 < sVar11) {
      pppppppfVar15 = &ppppppfStack_618;
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_610 = (float ******)0x0;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_628 = (float ******)0x3;
      ppppppfStack_624 = ppppppfStack_40c;
      ppppppfStack_620 = (float ******)0x0;
      ppppppfStack_61c = ppppppfStack_404;
      uStack_640 = 4.24399161404481e-314;
      ppppppfStack_638 = (float ******)0x8;
      ppppppfStack_634 = ppppppfStack_42c;
      ppppppfStack_630 = (float ******)0x40e0dc;
      ppppppfStack_62c = ppppppfStack_424;
      ppppppfStack_644 = ppppppfStack_48c;
      ppppppfStack_648 = (float ******)0x4f25db;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_61c = (float ******)0xa;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_610 = (float ******)0x0;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f2615;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_634 = (float ******)0xb;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x1;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_638 = ppppppfStack_48c;
      ppppppfStack_628 = (float ******)&DAT_00000001;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(0x4f2652,(undefined4)uStack_640);
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x2;
      ppppppfStack_648 = (float ******)0x2;
      ppppppfStack_3e8 = (float ******)0x4;
      ppppppfStack_644 = ppppppfStack_3ec;
      uStack_640 = (double)CONCAT44(ppppppfStack_3e4,4);
      ppppppfStack_64c = (float ******)0x28;
      ppppppfStack_650 = ppppppfStack_48c;
      ppppppfStack_654 = (float ******)0x4f268f;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x8;
      ppppppfStack_664 = (float ******)0x0;
      ppppppfStack_660 = (float ******)0x8;
      ppppppfStack_3e8 = (float ******)0x40ef38;
      ppppppfStack_65c = ppppppfStack_3ec;
      ppppppfStack_668 = ppppppfStack_48c;
      ppppppfStack_658 = (float ******)0x40ef38;
      ppppppfStack_654 = ppppppfStack_3e4;
      ppppppfStack_66c = (float ******)0x4f26cc;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_67c = (float ******)0xa;
      ppppppfStack_678 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_674 = ppppppfStack_3ec;
      ppppppfStack_680 = ppppppfStack_48c;
      ppppppfStack_670 = (float ******)0x0;
      ppppppfStack_66c = ppppppfStack_3e4;
      ppppppfStack_684 = (float ******)0x4f2706;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_694 = (float ******)0xb;
      ppppppfStack_3e8 = (float ******)0x2;
      uStack_690 = (double)CONCAT44(ppppppfStack_3ec,3);
      ppppppfStack_688 = (float ******)0x2;
      ppppppfStack_684 = ppppppfStack_3e4;
      uStack_69c._4_4_ = (float *******)ppppppfStack_48c;
      uStack_69c._0_4_ = 0x4f2743;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x2;
      iStack_6ac = 0x28;
      ppppppfStack_3e8 = (float ******)0x4;
      uStack_6a8 = (double)CONCAT44(ppppppfStack_3ec,2);
      ppppppfStack_6a0 = (float ******)0x4;
      uStack_69c = (double)CONCAT44(uStack_69c._4_4_,ppppppfStack_3e4);
      uStack_6b4._4_4_ = (float *******)ppppppfStack_48c;
      uStack_6b4._0_4_ = 0x4f2780;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x8;
      pcStack_6c0 = (code *)0x8;
      ppppppfStack_3e8 = (float ******)0x414bd8;
      ppppppfStack_6bc = ppppppfStack_3ec;
      ppppppfStack_6b8 = (float ******)0x414bd8;
      uStack_6b4 = (double)CONCAT44(uStack_6b4._4_4_,ppppppfStack_3e4);
      __vbaLateIdSt(ppppppfStack_48c,0);
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      __vbaLateIdSt(ppppppfStack_48c,10,3,ppppppfStack_3ec,0,ppppppfStack_3e4);
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x3;
      __vbaLateIdSt(ppppppfStack_48c,0xb,3,ppppppfStack_3ec,3,ppppppfStack_3e4);
      ppppppfStack_3f0 = (float ******)0x2;
      ppppppfStack_3e8 = (float ******)0x4;
      __vbaLateIdSt(ppppppfStack_48c,0x28,2,ppppppfStack_3ec,4,ppppppfStack_3e4);
      ppppppfStack_3f0 = (float ******)0x8;
      ppppppfStack_3e8 = (float ******)0x414bf8;
      __vbaLateIdSt(ppppppfStack_48c,0,8,ppppppfStack_3ec,L"Variance",ppppppfStack_3e4);
      uStack_4bc = DAT_0050b3c4;
      pppppfStack_358 = (float *****)&DAT_00000001;
      ppppppfVar19 = (float ******)pppppfStack_358;
      goto LAB_004f28bf;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
      ppppppfStack_60c = (float ******)0x4f293e;
      __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_46c = (float ******)((int)sVar11 - *(int *)(DAT_0050b19c + 0xe));
      if (*(float ********)(DAT_0050b19c + 0xc) <= ppppppfStack_46c) {
        ppppppfStack_60c = (float ******)0x4f2904;
        __vbaGenerateBoundsError();
      }
      if (*(uint *)(DAT_0050b19c + 8) <= 1U - *(int *)(DAT_0050b19c + 10)) {
        ppppppfStack_60c = (float ******)0x4f2921;
        __vbaGenerateBoundsError();
      }
    }
    ppppppfStack_60c = (float ******)0x4f2952;
    pppppfStack_36c = (float *****)__vbaFpI2();
    if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
      ppppppfStack_60c = (float ******)0x4f29c7;
      __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_46c = (float ******)((int)(short)pppppfStack_358 - *(int *)(DAT_0050b19c + 0xe));
      if (*(float ********)(DAT_0050b19c + 0xc) <= ppppppfStack_46c) {
        ppppppfStack_60c = (float ******)0x4f2981;
        __vbaGenerateBoundsError();
      }
      ppppppfStack_468 = (float ******)(2 - *(int *)(DAT_0050b19c + 10));
      if (*(float ********)(DAT_0050b19c + 8) <= ppppppfStack_468) {
        ppppppfStack_60c = (float ******)0x4f29a4;
        __vbaGenerateBoundsError();
      }
    }
    ppppppfStack_60c = (float ******)0x4f29d5;
    pppppfStack_374 = (float *****)__vbaFpI2();
    ppppppfStack_3e8 = &pppppfStack_36c;
    ppppppfStack_60c = (float ******)&ppppppfStack_3f0;
    pppppfStack_3f8 = (float *****)&pppppfStack_374;
    ppppppfStack_3f0 = (float ******)0x4002;
    ppppppfVar19 = (float ******)(int)(short)(sVar11 + 1);
    pppppfStack_400 = (float *****)0x4002;
    ppppppfStack_610 = (float ******)0x4f2a0b;
    Ordinal_536();
    ppppppfStack_610 = (float ******)0x4f2a18;
    ppppppfStack_610 = (float ******)__vbaStrMove();
    ppppppfStack_614 = (float ******)0x4f2a1f;
    Ordinal_519();
    ppppppfStack_614 = (float ******)0x4f2a26;
    ppppppfStack_614 = (float ******)__vbaStrMove();
    ppppppfStack_618 = (float ******)&DAT_0040cc9c;
    ppppppfStack_61c = (float ******)0x4f2a32;
    __vbaStrCat();
    ppppppfStack_61c = (float ******)0x4f2a39;
    ppppppfStack_61c = (float ******)__vbaStrMove();
    ppppppfStack_620 = &pppppfStack_400;
    ppppppfStack_624 = (float ******)0x4f2a47;
    Ordinal_536();
    ppppppfStack_624 = (float ******)0x4f2a4e;
    ppppppfStack_624 = (float ******)__vbaStrMove();
    ppppppfStack_628 = (float ******)0x4f2a55;
    Ordinal_519();
    ppppppfStack_628 = (float ******)0x4f2a5c;
    ppppppfStack_628 = (float ******)__vbaStrMove();
    ppppppfStack_62c = (float ******)0x4f2a63;
    ppppppfStack_650 = (float ******)__vbaStrCat();
    pppppfStack_3b0 = (float *****)0x8;
    ppppppfStack_638 = (float ******)0x3;
    ppppppfStack_634 = ppppppfStack_40c;
    ppppppfStack_62c = ppppppfStack_404;
    ppppppfStack_648 = (float ******)0x3;
    ppppppfStack_644 = ppppppfStack_42c;
    uStack_640 = (double)(ZEXT48(ppppppfStack_424) << 0x20);
    ppppppfStack_65c = (float ******)0x2;
    ppppppfStack_660 = (float ******)0x41;
    ppppppfStack_658 = (float ******)0x8;
    ppppppfStack_654 = ppppppfStack_3ac;
    ppppppfStack_664 = ppppppfStack_48c;
    ppppppfStack_64c = ppppppfStack_3a4;
    ppppppfStack_668 = (float ******)0x4f2ad7;
    ppppppfStack_630 = ppppppfVar19;
    ppppppfStack_3a8 = ppppppfStack_650;
    __vbaLateIdCallSt();
    ppppppfStack_668 = (float ******)&uStack_394;
    ppppppfStack_66c = (float ******)&uStack_390;
    ppppppfStack_670 = (float ******)&uStack_38c;
    ppppppfStack_674 = &pppppfStack_388;
    ppppppfStack_678 = (float ******)&ppppppfStack_384;
    ppppppfStack_67c = (float ******)0x5;
    ppppppfStack_680 = (float ******)0x4f2af3;
    __vbaFreeStrList();
    ppppppfStack_62c = (float ******)0x4f2aff;
    __vbaFreeVar();
    ppppppfStack_630 = &pppppfStack_380;
    ppppppfStack_62c = (float ******)DAT_0050b3d0;
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_634 = (float ******)0x4f2b20;
    ppppppfStack_3e8 = ppppppfVar19;
    __vbaAryLock();
    if (((float ******)pppppfStack_380 == (float ******)0x0) || (*(short *)pppppfStack_380 != 1)) {
      ppppppfStack_634 = (float ******)0x4f2b5d;
      iVar12 = __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_468 = (float ******)((int)(short)pppppfStack_358 - (int)pppppfStack_380[5]);
      if (pppppfStack_380[4] <= ppppppfStack_468) {
        ppppppfStack_634 = (float ******)0x4f2b49;
        __vbaGenerateBoundsError();
      }
      iVar12 = (int)ppppppfStack_468 << 2;
    }
    ppppppfStack_658 = (float ******)((int)pppppfStack_380[3] + iVar12);
    uStack_640 = (double)CONCAT44(ppppppfStack_3ec,ppppppfStack_3f0);
    ppppppfStack_638 = ppppppfStack_3e8;
    ppppppfStack_634 = ppppppfStack_3e4;
    ppppppfStack_650 = (float ******)0x3;
    ppppppfStack_64c = ppppppfStack_40c;
    ppppppfStack_648 = (float ******)0x1;
    ppppppfStack_644 = ppppppfStack_404;
    ppppppfStack_664 = (float ******)0x2;
    ppppppfStack_660 = (float ******)0x4008;
    ppppppfStack_668 = (float ******)0x41;
    ppppppfStack_65c = ppppppfStack_42c;
    ppppppfStack_654 = ppppppfStack_424;
    ppppppfStack_66c = ppppppfStack_48c;
    ppppppfStack_670 = (float ******)0x4f2be1;
    __vbaLateIdCallSt();
    ppppppfStack_634 = &pppppfStack_380;
    ppppppfStack_638 = (float ******)0x4f2bee;
    __vbaAryUnlock();
    ppppppfStack_638 = (float ******)0x4f2bf3;
    FUN_0044fdc0();
    ppppppfStack_638 = (float ******)0x4f2bfa;
    __vbaStrMove();
    ppppppfStack_3a8 = ppppppfStack_384;
    uStack_640._4_4_ = (float *******)&pppppfStack_380;
    ppppppfStack_638 = (float ******)DAT_0050b3cc;
    pppppfStack_400 = (float *****)0x3;
    ppppppfStack_384 = (float ******)0x0;
    pppppfStack_3b0 = (float *****)0x8;
    uStack_640._0_4_ = 0x4f2c2f;
    pppppfStack_3f8 = (float *****)ppppppfVar19;
    __vbaAryLock();
    if (((float ******)pppppfStack_380 == (float ******)0x0) || (*(short *)pppppfStack_380 != 2)) {
      uStack_640._0_4_ = 0x4f2c99;
      iVar12 = __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_46c = (float ******)((int)(short)pppppfStack_36c - (int)pppppfStack_380[7]);
      if (pppppfStack_380[6] <= ppppppfStack_46c) {
        uStack_640._0_4_ = 0x4f2c58;
        __vbaGenerateBoundsError();
      }
      ppppppfStack_468 = (float ******)((int)(short)pppppfStack_374 - (int)pppppfStack_380[5]);
      if (pppppfStack_380[4] <= ppppppfStack_468) {
        uStack_640._0_4_ = 0x4f2c79;
        __vbaGenerateBoundsError();
      }
      iVar12 = (int)((int)pppppfStack_380[6] * (int)ppppppfStack_468 + (int)ppppppfStack_46c) * 4;
    }
    uStack_640 = (double)CONCAT44(uStack_640._4_4_,1);
    ppppppfStack_3e8 = (float ******)((int)pppppfStack_380[3] + iVar12);
    ppppppfStack_648 = &pppppfStack_3b0;
    ppppppfStack_644 = (float ******)&DAT_00000001;
    ppppppfStack_64c = (float ******)&ppppppfStack_3f0;
    ppppppfStack_650 = apppppfStack_3c0;
    ppppppfStack_3f0 = (float ******)0x4004;
    ppppppfStack_654 = (float ******)0x4f2cca;
    Ordinal_660();
    ppppppfStack_654 = &pppppfStack_380;
    ppppppfStack_658 = (float ******)0x4f2cd4;
    __vbaAryUnlock();
    ppppppfStack_658 = apppppfStack_3c0;
    ppppppfStack_65c = (float ******)0x4f2cde;
    ppppppfStack_680 = (float ******)__vbaStrVarMove();
    pppppfStack_3d0 = (float *****)0x8;
    ppppppfStack_668 = (float ******)pppppfStack_400;
    ppppppfStack_664 = (float ******)pppppfStack_3fc;
    ppppppfStack_660 = (float ******)pppppfStack_3f8;
    ppppppfStack_65c = (float ******)uStack_3f4;
    ppppppfStack_678 = (float ******)0x3;
    ppppppfStack_674 = ppppppfStack_41c;
    ppppppfStack_670 = (float ******)0x2;
    ppppppfStack_66c = (float ******)pppppfStack_414;
    uStack_690 = 4.24399161404481e-314;
    ppppppfStack_688 = (float ******)0x8;
    ppppppfStack_684 = (float ******)uStack_3cc;
    ppppppfStack_694 = ppppppfStack_48c;
    ppppppfStack_67c = ppppppfStack_3c4;
    uStack_69c = (double)CONCAT44(0x4f2d68,(undefined4)uStack_69c);
    uStack_3c8 = ppppppfStack_680;
    __vbaLateIdCallSt();
    ppppppfStack_65c = (float ******)0x4f2d74;
    __vbaFreeStr();
    ppppppfStack_65c = &pppppfStack_3d0;
    ppppppfStack_660 = apppppfStack_3c0;
    ppppppfStack_664 = &pppppfStack_3b0;
    ppppppfStack_668 = (float ******)0x3;
    ppppppfStack_66c = (float ******)0x4f2d8b;
    __vbaFreeVarList();
    ppppppfStack_65c = (float ******)0x4f2d93;
    FUN_0044fdc0();
    ppppppfStack_65c = (float ******)0x4f2d9a;
    __vbaStrMove();
    ppppppfStack_3a8 = ppppppfStack_384;
    pppppfStack_400 = (float *****)0x3;
    uStack_420 = 3;
    ppppppfStack_384 = (float ******)0x0;
    pppppfStack_3b0 = (float *****)0x8;
    ppppppfStack_65c = (float ******)DAT_0050b3c8;
    ppppppfStack_660 = &pppppfStack_380;
    ppppppfStack_664 = (float ******)0x4f2dd6;
    pppppfStack_3f8 = (float *****)ppppppfVar19;
    __vbaAryLock();
    if (((float ******)pppppfStack_380 == (float ******)0x0) || (*(short *)pppppfStack_380 != 2)) {
      ppppppfStack_664 = (float ******)0x4f2e32;
      iVar12 = __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_46c = (float ******)((int)(short)pppppfStack_36c - (int)pppppfStack_380[7]);
      if (pppppfStack_380[6] <= ppppppfStack_46c) {
        ppppppfStack_664 = (float ******)0x4f2dff;
        __vbaGenerateBoundsError();
      }
      iVar12 = (int)(short)pppppfStack_374;
      pppppfVar4 = (float *****)pppppfStack_380[5];
      if (pppppfStack_380[4] <= (float *****)(iVar12 - (int)pppppfVar4)) {
        ppppppfStack_664 = (float ******)0x4f2e18;
        __vbaGenerateBoundsError();
      }
      iVar12 = (int)((int)pppppfStack_380[6] * (iVar12 - (int)pppppfVar4) + (int)ppppppfStack_46c) *
               4;
    }
    ppppppfStack_664 = (float ******)&DAT_00000001;
    ppppppfStack_3e8 = (float ******)((int)pppppfStack_380[3] + iVar12);
    ppppppfStack_66c = &pppppfStack_3b0;
    ppppppfStack_668 = (float ******)&DAT_00000001;
    ppppppfStack_670 = (float ******)&ppppppfStack_3f0;
    ppppppfStack_674 = apppppfStack_3c0;
    ppppppfStack_3f0 = (float ******)0x4004;
    ppppppfStack_678 = (float ******)0x4f2e63;
    Ordinal_660();
    ppppppfStack_678 = &pppppfStack_380;
    ppppppfStack_67c = (float ******)0x4f2e6d;
    __vbaAryUnlock();
    ppppppfStack_67c = apppppfStack_3c0;
    ppppppfStack_680 = (float ******)0x4f2e77;
    uStack_3c8 = __vbaStrVarMove();
    pppppppfVar24 = (float *******)pppppfStack_414;
    pppppppfVar15 = (float *******)ppppppfStack_41c;
    pppppfStack_3d0 = (float *****)0x8;
    ppppppfStack_688 = (float ******)pppppfStack_3fc;
    ppppppfStack_684 = (float ******)pppppfStack_3f8;
    ppppppfStack_680 = (float ******)uStack_3f4;
    uStack_69c = (double)CONCAT44(ppppppfStack_41c,uStack_420);
    ppppppfStack_694 = (float ******)0x3;
    uStack_690 = (double)CONCAT44(pppppfStack_400,pppppfStack_414);
    uStack_6b4 = 4.24399161404481e-314;
    iStack_6ac = 8;
    ppppppfStack_6b8 = ppppppfStack_48c;
    uStack_6a8 = (double)CONCAT44(uStack_3c8,uStack_3cc);
    ppppppfStack_6a0 = ppppppfStack_3c4;
    ppppppfStack_6bc = (float ******)0x4f2ef8;
    __vbaLateIdCallSt();
    ppppppfStack_680 = (float ******)0x4f2f04;
    __vbaFreeStr();
    ppppppfStack_680 = &pppppfStack_3d0;
    ppppppfStack_684 = apppppfStack_3c0;
    ppppppfStack_688 = &pppppfStack_3b0;
    uStack_690 = 6.36855127864054e-314;
    __vbaFreeVarList();
    ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppfStack_358 + 1);
    if (SCARRY2((short)pppppfStack_358,1)) break;
LAB_004f28bf:
    pppppfStack_358 = (float *****)ppppppfVar19;
    sVar11 = (short)pppppfStack_358;
    if ((short)uStack_4bc < sVar11) goto LAB_004f2f35;
    pppppppfVar24 = (float *******)CONCAT22((short)((uint)pppppppfVar24 >> 0x10),sVar11 + 1);
    if (SCARRY2(sVar11,1)) break;
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_3e8 = (float ******)(int)(short)pppppfStack_358;
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_60c = (float ******)0x0;
    ppppppfStack_610 = (float ******)0x80010005;
    ppppppfStack_618 = &pppppfStack_3b0;
    ppppppfStack_614 = ppppppfStack_48c;
    ppppppfStack_61c = (float ******)0x4f0c3e;
    ppppppfStack_60c = (float ******)(*(code *)pppppppfVar15)();
    ppppppfStack_610 = (float ******)0x4f0c48;
    __vbaR4Var();
    pppppppfVar14 = (float *******)ppppppfStack_608;
    if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
    ppppppfStack_60c = (float ******)0x4f0c5e;
    ppppppfStack_620 = (float ******)__vbaFpI4();
    ppppppfStack_618 = ppppppfStack_3f0;
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_610 = ppppppfStack_3e8;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_62c = (float ******)&DAT_00000001;
    ppppppfStack_628 = (float ******)0x3;
    ppppppfStack_630 = (float ******)0x39;
    ppppppfStack_624 = ppppppfStack_40c;
    ppppppfStack_634 = ppppppfStack_48c;
    ppppppfStack_61c = ppppppfStack_404;
    ppppppfStack_638 = (float ******)0x4f0cb4;
    __vbaLateIdCallSt();
    ppppppfStack_60c = (float ******)0x4f0cc0;
    __vbaFreeVar();
    ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppfStack_358 + 1);
    if (SCARRY2((short)pppppfStack_358,1)) break;
LAB_004f0c0b:
    pppppfStack_358 = (float *****)ppppppfVar19;
    if (3 < (short)pppppfStack_358) {
      ppppppfStack_60c = (float ******)0x0;
      ppppppfStack_610 = (float ******)0x80010005;
      ppppppfStack_618 = &pppppfStack_3b0;
      ppppppfStack_614 = ppppppfStack_48c;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_61c = (float ******)0x4f0cff;
      ppppppfStack_60c = (float ******)(*(code *)pppppppfVar15)();
      ppppppfStack_610 = (float ******)0x4f0d09;
      __vbaR4Var();
      pppppppfVar14 = (float *******)ppppppfStack_608;
      if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
      ppppppfStack_60c = (float ******)0x4f0d1f;
      ppppppfStack_620 = (float ******)__vbaFpI4();
      ppppppfStack_618 = ppppppfStack_3f0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_610 = ppppppfStack_3e8;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_62c = (float ******)&DAT_00000001;
      ppppppfStack_628 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x39;
      ppppppfStack_624 = ppppppfStack_40c;
      ppppppfStack_634 = ppppppfStack_48c;
      ppppppfStack_61c = ppppppfStack_404;
      ppppppfStack_638 = (float ******)0x4f0d75;
      __vbaLateIdCallSt();
      ppppppfStack_60c = (float ******)0x4f0d81;
      __vbaFreeVar();
      ppppppfStack_60c = (float ******)0x0;
      ppppppfStack_610 = (float ******)0x80010005;
      ppppppfStack_618 = &pppppfStack_3b0;
      ppppppfStack_614 = ppppppfStack_48c;
      ppppppfStack_3e8 = (float ******)&DAT_00000001;
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_61c = (float ******)0x4f0da9;
      ppppppfStack_60c = (float ******)(*(code *)pppppppfVar15)();
      ppppppfStack_610 = (float ******)0x4f0db3;
      __vbaR4Var();
      pppppppfVar14 = (float *******)ppppppfStack_608;
      if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
      ppppppfStack_60c = (float ******)0x4f0dc9;
      ppppppfStack_620 = (float ******)__vbaFpI4();
      ppppppfStack_618 = ppppppfStack_3f0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_610 = ppppppfStack_3e8;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_62c = (float ******)0x1;
      ppppppfStack_628 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x39;
      ppppppfStack_624 = ppppppfStack_40c;
      ppppppfStack_61c = ppppppfStack_404;
      ppppppfStack_634 = ppppppfStack_48c;
      ppppppfStack_638 = (float ******)0x4f0e1f;
      __vbaLateIdCallSt();
      ppppppfStack_60c = (float ******)0x4f0e2b;
      __vbaFreeVar();
      ppppppfStack_60c = (float ******)0x4f0e30;
      iStack_528 = FUN_0042b130();
      ppppppfStack_610 = (float ******)(float)iStack_528;
      ppppppfStack_3f0 = (float ******)0x4;
      ppppppfStack_61c = (float ******)0x80010006;
      ppppppfStack_618 = (float ******)0x4;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f0e7d;
      ppppppfStack_3e8 = ppppppfStack_610;
      __vbaLateIdSt();
      if (DAT_0050c53c == (float *******)0x0) {
        ppppppfStack_624 = (float ******)&DAT_0050c53c;
        ppppppfStack_628 = (float ******)&DAT_0040b420;
        ppppppfStack_62c = (float ******)0x4f0e96;
        __vbaNew2();
      }
      ppppppfStack_624 = (float ******)&ppppppfStack_398;
      ppppppfStack_628 = (float ******)DAT_0050c53c;
      ppppppfStack_468 = (float ******)DAT_0050c53c;
      ppppppfStack_62c = (float ******)0x4f0eab;
      iVar12 = (*(code *)(*DAT_0050c53c)[6])();
      if (iVar12 < 0) {
        ppppppfStack_62c = (float ******)0x18;
        ppppppfStack_630 = (float ******)&DAT_0040b410;
        ppppppfStack_634 = ppppppfStack_468;
        uStack_640 = (double)CONCAT44(0x4f0ec6,(undefined4)uStack_640);
        ppppppfStack_638 = (float ******)iVar12;
        __vbaHresultCheckObj();
      }
      ppppppfStack_62c = (float ******)appppppfStack_454;
      ppppppfStack_630 = ppppppfStack_398;
      ppppppfStack_470 = ppppppfStack_398;
      ppppppfStack_634 = (float ******)0x4f0edf;
      iVar12 = (*(code *)(*ppppppfStack_398)[0x26])();
      uVar27 = 0;
      if (iVar12 < 0) {
        ppppppfStack_634 = (float ******)0x98;
        ppppppfStack_638 = (float ******)&DAT_0040bb5c;
        uStack_640 = (double)CONCAT44(ppppppfStack_470,iVar12);
        ppppppfStack_644 = (float ******)0x4f0efd;
        __vbaHresultCheckObj();
      }
      ppppppfStack_634 = (float ******)0x0;
      ppppppfStack_638 = (float ******)0x80010005;
      uStack_640 = (double)CONCAT44(ppppppfStack_48c,&pppppfStack_3b0);
      ppppppfStack_644 = (float ******)0x4f0f11;
      (*(code *)pppppppfVar15)();
      ppppppfStack_634 = &pppppfStack_3b0;
      ppppppfStack_638 = (float ******)0x4f0f1e;
      fVar28 = (float10)__vbaR4Var();
      pppppppfVar14 = (float *******)ppppppfStack_608;
      if (((uVar27 & 0xd) != 0) ||
         (ppppppfStack_3e8 =
               (float ******)
               (float)(((float10)(float)appppppfStack_454[0] - fVar28) * (float10)_DAT_00401268),
         (uVar27 & 0xd) != 0)) goto LAB_004f2fd3;
      ppppppfStack_3f0 = (float ******)0x4;
      ppppppfStack_61c = (float ******)0x80010003;
      ppppppfStack_618 = (float ******)0x4;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f0f7f;
      ppppppfStack_610 = ppppppfStack_3e8;
      __vbaLateIdSt();
      ppppppfStack_624 = (float ******)0x4f0f88;
      __vbaFreeObj();
      ppppppfStack_624 = (float ******)0x4f0f91;
      __vbaFreeVar();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_644 = (float ******)0x1;
      ppppppfStack_648 = (float ******)0x38;
      ppppppfStack_628 = (float ******)0x0;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(ppppppfStack_40c,2);
      ppppppfStack_64c = ppppppfStack_48c;
      ppppppfStack_638 = (float ******)0x1;
      ppppppfStack_634 = ppppppfStack_404;
      ppppppfStack_650 = (float ******)0x4f0ff3;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x1;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_628 = (float ******)&DAT_00000001;
      ppppppfStack_624 = ppppppfStack_3e4;
      ppppppfStack_644 = (float ******)&DAT_00000001;
      ppppppfStack_648 = (float ******)0x38;
      uStack_640 = (double)CONCAT44(ppppppfStack_40c,2);
      ppppppfStack_64c = ppppppfStack_48c;
      ppppppfStack_638 = (float ******)&DAT_00000001;
      ppppppfStack_634 = ppppppfStack_404;
      ppppppfStack_650 = (float ******)0x4f1055;
      __vbaLateIdCallSt();
      pppppppfVar15 = (float *******)ppppppfStack_404;
      uStack_4dc = 3;
      uStack_4d8 = 1;
      pppppfStack_358 = (float *****)0x2;
      ppppppfVar19 = (float ******)pppppfStack_358;
      goto LAB_004f1079;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_610 = (float ******)(int)(short)pppppfStack_358;
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_618 = (float ******)0x3;
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_62c = (float ******)&DAT_00000001;
    ppppppfStack_630 = (float ******)0x38;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_628 = (float ******)0x2;
    ppppppfStack_624 = ppppppfStack_40c;
    ppppppfStack_620 = (float ******)0x7;
    ppppppfStack_634 = ppppppfStack_48c;
    ppppppfStack_61c = (float ******)pppppppfVar15;
    ppppppfStack_638 = (float ******)0x4f10e4;
    ppppppfStack_3e8 = ppppppfStack_610;
    __vbaLateIdCallSt();
    ppppppfVar19 = (float ******)
                   CONCAT22(extraout_var_00,(short)uStack_4d8 + (short)pppppfStack_358);
    if (SCARRY2((short)uStack_4d8,(short)pppppfStack_358)) break;
LAB_004f1079:
    pppppfStack_358 = (float *****)ppppppfVar19;
    if ((short)uStack_4dc < (short)pppppfStack_358) {
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_61c = (float ******)0xa;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_610 = (float ******)0x0;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f113a;
      __vbaLateIdSt();
      pppppfStack_358 = (float *****)0x0;
      ppppppfVar19 = (float ******)pppppfStack_358;
      goto LAB_004f1141;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_610 = (float ******)(int)(short)pppppfStack_358;
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_61c = (float ******)0xb;
    ppppppfStack_618 = (float ******)0x3;
    ppppppfStack_614 = ppppppfStack_3ec;
    ppppppfStack_620 = ppppppfStack_48c;
    ppppppfStack_60c = ppppppfStack_3e4;
    ppppppfStack_624 = (float ******)0x4f118c;
    ppppppfStack_3e8 = ppppppfStack_610;
    __vbaLateIdSt();
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_634 = (float ******)0x26;
    ppppppfStack_630 = (float ******)0x3;
    ppppppfStack_3e8 = (float ******)0xffff;
    ppppppfStack_62c = ppppppfStack_3ec;
    ppppppfStack_638 = ppppppfStack_48c;
    ppppppfStack_628 = (float ******)0xffff;
    ppppppfStack_624 = ppppppfStack_3e4;
    uStack_640 = (double)CONCAT44(0x4f11c9,(undefined4)uStack_640);
    __vbaLateIdSt();
    ppppppfStack_3f0 = (float ******)0x3;
    ppppppfStack_64c = (float ******)0x27;
    ppppppfStack_648 = (float ******)0x3;
    ppppppfStack_3e8 = (float ******)0xff0000;
    ppppppfStack_644 = ppppppfStack_3ec;
    ppppppfStack_650 = ppppppfStack_48c;
    uStack_640 = (double)CONCAT44(ppppppfStack_3e4,0xff0000);
    ppppppfStack_654 = (float ******)0x4f1206;
    __vbaLateIdSt();
    ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppfStack_358 + 1);
    if (SCARRY2((short)pppppfStack_358,1)) break;
LAB_004f1141:
    pppppfStack_358 = (float *****)ppppppfVar19;
    if (3 < (short)pppppfStack_358) {
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_410 = (float ******)0x3;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      uStack_408 = 0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_610 = (float ******)0x0;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_628 = (float ******)0x3;
      ppppppfStack_624 = ppppppfStack_40c;
      ppppppfStack_620 = (float ******)0x0;
      ppppppfStack_61c = (float ******)pppppppfVar15;
      uStack_640 = 4.24399161404481e-314;
      ppppppfStack_638 = (float ******)0x8;
      ppppppfStack_634 = ppppppfStack_42c;
      ppppppfStack_630 = (float ******)0x413078;
      ppppppfStack_62c = ppppppfStack_424;
      ppppppfStack_644 = ppppppfStack_48c;
      ppppppfStack_648 = (float ******)0x4f12ad;
      __vbaLateIdCallSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_410 = (float ******)0x3;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_610 = (float ******)0x0;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_628 = (float ******)0x3;
      ppppppfStack_624 = ppppppfStack_40c;
      ppppppfStack_620 = (float ******)0x1;
      ppppppfStack_61c = (float ******)pppppppfVar15;
      uStack_640 = 4.24399161404481e-314;
      ppppppfStack_638 = (float ******)0x8;
      ppppppfStack_634 = ppppppfStack_42c;
      ppppppfStack_630 = (float ******)0x414c10;
      ppppppfStack_62c = ppppppfStack_424;
      ppppppfStack_644 = ppppppfStack_48c;
      ppppppfStack_648 = (float ******)0x4f1336;
      __vbaLateIdCallSt();
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_618 = (float ******)0x3;
      ppppppfStack_61c = (float ******)0xa;
      ppppppfStack_614 = ppppppfStack_3ec;
      ppppppfStack_620 = ppppppfStack_48c;
      ppppppfStack_610 = (float ******)0x0;
      ppppppfStack_60c = ppppppfStack_3e4;
      ppppppfStack_624 = (float ******)0x4f1370;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_634 = (float ******)0xb;
      ppppppfStack_630 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x2;
      ppppppfStack_62c = ppppppfStack_3ec;
      ppppppfStack_638 = ppppppfStack_48c;
      ppppppfStack_628 = (float ******)0x2;
      ppppppfStack_624 = ppppppfStack_3e4;
      uStack_640 = (double)CONCAT44(0x4f13ad,(undefined4)uStack_640);
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x2;
      ppppppfStack_64c = (float ******)0x28;
      ppppppfStack_648 = (float ******)0x2;
      ppppppfStack_3e8 = (float ******)0x4;
      ppppppfStack_644 = ppppppfStack_3ec;
      ppppppfStack_650 = ppppppfStack_48c;
      uStack_640 = (double)CONCAT44(ppppppfStack_3e4,4);
      ppppppfStack_654 = (float ******)0x4f13ea;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_410 = (float ******)0x3;
      ppppppfStack_660 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_65c = ppppppfStack_3ec;
      ppppppfStack_658 = (float ******)0x0;
      ppppppfStack_654 = ppppppfStack_3e4;
      ppppppfStack_670 = (float ******)0x3;
      ppppppfStack_66c = ppppppfStack_40c;
      ppppppfStack_668 = (float ******)0x2;
      ppppppfStack_664 = (float ******)pppppppfVar15;
      ppppppfStack_684 = (float ******)0x2;
      ppppppfStack_688 = (float ******)0x41;
      ppppppfStack_680 = (float ******)0x8;
      ppppppfStack_67c = ppppppfStack_42c;
      ppppppfStack_678 = (float ******)0x414bd8;
      ppppppfStack_674 = ppppppfStack_424;
      uStack_690 = (double)CONCAT44(ppppppfStack_48c,0x4f1473);
      __vbaLateIdCallSt();
      ppppppfStack_3e8 = (float ******)0x0;
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_664 = (float ******)0xa;
      ppppppfStack_660 = (float ******)0x3;
      ppppppfStack_65c = ppppppfStack_3ec;
      ppppppfStack_668 = ppppppfStack_48c;
      ppppppfStack_658 = (float ******)0x0;
      ppppppfStack_654 = ppppppfStack_3e4;
      ppppppfStack_66c = (float ******)0x4f14ad;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x3;
      ppppppfStack_3e8 = (float ******)0x3;
      ppppppfStack_678 = (float ******)0x3;
      ppppppfStack_67c = (float ******)0xb;
      ppppppfStack_674 = ppppppfStack_3ec;
      ppppppfStack_680 = ppppppfStack_48c;
      ppppppfStack_670 = (float ******)0x3;
      ppppppfStack_66c = ppppppfStack_3e4;
      ppppppfStack_684 = (float ******)0x4f14e7;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x2;
      ppppppfStack_694 = (float ******)0x28;
      ppppppfStack_3e8 = (float ******)0x4;
      uStack_690 = (double)CONCAT44(ppppppfStack_3ec,2);
      ppppppfStack_688 = (float ******)0x4;
      ppppppfStack_684 = ppppppfStack_3e4;
      uStack_69c._4_4_ = (float *******)ppppppfStack_48c;
      uStack_69c._0_4_ = 0x4f1524;
      __vbaLateIdSt();
      ppppppfStack_3f0 = (float ******)0x8;
      iStack_6ac = 0;
      ppppppfStack_3e8 = (float ******)0x414c60;
      uStack_6a8 = (double)CONCAT44(ppppppfStack_3ec,8);
      ppppppfStack_6a0 = (float ******)0x414c60;
      uStack_69c = (double)CONCAT44(uStack_69c._4_4_,ppppppfStack_3e4);
      uStack_6b4 = (double)CONCAT44(ppppppfStack_48c,0x4f1561);
      __vbaLateIdSt();
      sStack_4ec = DAT_0050b332;
      pppppfStack_358 = (float *****)&DAT_00000001;
      pppppppfVar14 = DAT_0050b3cc;
      ppppppfVar19 = (float ******)pppppfStack_358;
      goto LAB_004f157d;
    }
  }
  goto LAB_004f2fd8;
LAB_004f157d:
  do {
    pppppfStack_358 = (float *****)ppppppfVar19;
    pppppppfVar24 = (float *******)pppppfStack_358;
    sVar11 = (short)pppppfStack_358;
    if (sStack_4ec < sVar11) goto LAB_004f2f35;
    if ((pppppppfVar14 == (float *******)0x0) || (*(short *)pppppppfVar14 != 2)) {
      ppppppfStack_60c = (float ******)0x4f15e6;
      iVar12 = __vbaGenerateBoundsError();
      pppppppfVar14 = DAT_0050b3cc;
    }
    else {
      pppppppfVar15 = (float *******)((int)sVar11 - (int)pppppppfVar14[7]);
      if (pppppppfVar14[6] <= pppppppfVar15) {
        ppppppfStack_60c = (float ******)0x4f15a9;
        __vbaGenerateBoundsError();
        pppppppfVar14 = DAT_0050b3cc;
      }
      ppppppfStack_468 = (float ******)-(int)pppppppfVar14[5];
      if (pppppppfVar14[4] <= ppppppfStack_468) {
        ppppppfStack_60c = (float ******)0x4f15c7;
        __vbaGenerateBoundsError();
        pppppppfVar14 = DAT_0050b3cc;
      }
      iVar12 = (int)((int)pppppppfVar14[6] * (int)ppppppfStack_468 + (int)pppppppfVar15) * 4;
    }
    uVar27 = 0;
    if (*(float *)((int)pppppppfVar14[3] + iVar12) != _DAT_00402558) {
      if ((pppppppfVar14 == (float *******)0x0) || (*(short *)pppppppfVar14 != 2)) {
        ppppppfStack_60c = (float ******)0x4f165d;
        iVar12 = __vbaGenerateBoundsError();
        pppppppfVar14 = DAT_0050b3cc;
      }
      else {
        ppppppfStack_46c = (float ******)-(int)pppppppfVar14[7];
        if (pppppppfVar14[6] <= ppppppfStack_46c) {
          ppppppfStack_60c = (float ******)0x4f1625;
          __vbaGenerateBoundsError();
          pppppppfVar14 = DAT_0050b3cc;
        }
        pppppppfVar15 = (float *******)((int)sVar11 - (int)pppppppfVar14[5]);
        if (pppppppfVar14[4] <= pppppppfVar15) {
          ppppppfStack_60c = (float ******)0x4f1640;
          __vbaGenerateBoundsError();
          pppppppfVar14 = DAT_0050b3cc;
        }
        iVar12 = (int)((int)pppppppfVar14[6] * (int)pppppppfVar15 + (int)ppppppfStack_46c) * 4;
      }
      uVar27 = 0;
      if (*(float *)((int)pppppppfVar14[3] + iVar12) != _DAT_00401488) {
        ppppppfStack_3f0 = (float ******)0x3;
        ppppppfStack_410 = (float ******)0x3;
        ppppppfStack_610 = (float ******)0x4f169b;
        ppppppfStack_60c = (float ******)pppppppfVar24;
        ppppppfStack_3e8 = (float ******)(int)sVar11;
        ppppppfStack_634 = (float ******)__vbaStrI2();
        pppppppfVar24 = &ppppppfStack_62c;
        ppppppfStack_61c = ppppppfStack_3f0;
        pppppfStack_3b0 = (float *****)0x8;
        ppppppfStack_618 = ppppppfStack_3ec;
        ppppppfStack_614 = ppppppfStack_3e8;
        ppppppfStack_610 = ppppppfStack_3e4;
        ppppppfStack_62c = ppppppfStack_410;
        ppppppfStack_628 = ppppppfStack_40c;
        ppppppfStack_624 = (float ******)0x0;
        ppppppfStack_620 = ppppppfStack_404;
        ppppppfStack_644 = (float ******)0x41;
        uStack_640 = 1.69759663287103e-313;
        ppppppfStack_638 = ppppppfStack_3ac;
        ppppppfStack_648 = ppppppfStack_48c;
        ppppppfStack_630 = ppppppfStack_3a4;
        ppppppfStack_64c = (float ******)0x4f1715;
        ppppppfStack_3a8 = ppppppfStack_634;
        __vbaLateIdCallSt();
        ppppppfStack_610 = (float ******)0x4f1721;
        __vbaFreeVar();
        ppppppfStack_37c = (float ******)0x0;
        ppppppfStack_610 = (float ******)0x4f1738;
        __vbaStrCopy();
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_60c = (float ******)0x4f178a;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          uVar25 = (int)(int)sVar11 - *(int *)(DAT_0050b3e8 + 0xe);
          if (*(uint *)(DAT_0050b3e8 + 0xc) <= uVar25) {
            ppppppfStack_60c = (float ******)0x4f175a;
            __vbaGenerateBoundsError();
          }
          pppppppfVar24 = (float *******)-*(int *)(DAT_0050b3e8 + 10);
          if (*(float *******)(DAT_0050b3e8 + 8) <= pppppppfVar24) {
            ppppppfStack_60c = (float ******)0x4f1772;
            __vbaGenerateBoundsError();
          }
          iVar12 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)pppppppfVar24 + uVar25) * 2;
        }
        pppppppfVar15 = (float *******)__vbaStrMove_exref;
        uStack_35c = 1;
        pppppfStack_360 =
             (float *****)
             CONCAT22(pppppfStack_360._2_2_,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar12));
        uVar25 = uStack_35c;
        while( true ) {
          uStack_35c = uVar25;
          if ((short)pppppfStack_360 < (short)uStack_35c) break;
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_60c = (float ******)0x4f1812;
            iVar12 = __vbaGenerateBoundsError();
          }
          else {
            ppppppfStack_46c =
                 (float ******)((int)(short)pppppfStack_358 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(float ********)(DAT_0050b3e8 + 0xc) <= ppppppfStack_46c) {
              ppppppfStack_60c = (float ******)0x4f17de;
              __vbaGenerateBoundsError();
            }
            iVar26 = (int)(short)uStack_35c;
            iVar12 = *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= (uint)(iVar26 - iVar12)) {
              ppppppfStack_60c = (float ******)0x4f17fa;
              __vbaGenerateBoundsError();
            }
            iVar12 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (iVar26 - iVar12) + (int)ppppppfStack_46c)
                     * 2;
          }
          pppppfStack_36c =
               (float *****)
               CONCAT22((short)((uint)iVar12 >> 0x10),
                        *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar12));
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_60c = (float ******)0x4f188b;
            iVar12 = __vbaGenerateBoundsError();
            uVar17 = extraout_var_03;
          }
          else {
            pppppppfVar24 = *(float ********)(DAT_0050b3e8 + 0xe);
            pppppppfVar14 = *(float ********)(DAT_0050b3e8 + 0xc);
            ppppppfStack_46c = (float ******)((int)(short)pppppfStack_358 - (int)pppppppfVar24);
            if (pppppppfVar14 <= ppppppfStack_46c) {
              ppppppfStack_60c = (float ******)0x4f1848;
              __vbaGenerateBoundsError();
              pppppppfVar14 = extraout_EDX;
            }
            uVar17 = (undefined2)((uint)pppppppfVar14 >> 0x10);
            if (SCARRY2((short)uStack_35c,1)) goto LAB_004f2fd8;
            uVar25 = (int)(short)((short)uStack_35c + 1) - *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= uVar25) {
              ppppppfStack_60c = (float ******)0x4f186f;
              __vbaGenerateBoundsError();
              uVar17 = extraout_var_02;
            }
            iVar12 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * uVar25 + (int)ppppppfStack_46c) * 2;
          }
          pppppfStack_374 =
               (float *****)CONCAT22(uVar17,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar12));
          ppppppfStack_610 = (float ******)&ppppppfStack_3f0;
          ppppppfStack_3e8 = &pppppfStack_36c;
          ppppppfStack_60c = (float ******)DAT_0050b348;
          ppppppfStack_3f0 = (float ******)0x4002;
          ppppppfStack_614 = (float ******)0x4f18c2;
          Ordinal_536();
          ppppppfStack_614 = (float ******)0x4f18c9;
          ppppppfStack_614 = (float ******)__vbaStrMove();
          pppppppfVar24 = (float *******)__vbaStrCat_exref;
          ppppppfStack_618 = (float ******)0x4f18d2;
          __vbaStrCat();
          ppppppfStack_618 = (float ******)0x4f18d9;
          ppppppfStack_618 = (float ******)__vbaStrMove();
          ppppppfStack_61c = (float ******)&DAT_0040cc9c;
          ppppppfStack_620 = (float ******)0x4f18e1;
          __vbaStrCat();
          ppppppfStack_620 = (float ******)0x4f18ea;
          __vbaStrMove();
          ppppppfStack_620 = &pppppfStack_388;
          ppppppfStack_624 = (float ******)&ppppppfStack_384;
          ppppppfStack_628 = (float ******)0x2;
          ppppppfStack_62c = (float ******)0x4f18fa;
          __vbaFreeStrList();
          if ((short)uStack_35c == (short)pppppfStack_360) break;
          if ((DAT_0050b3c8 == (float *******)0x0) || (*(short *)DAT_0050b3c8 != 2)) {
            ppppppfStack_60c = (float ******)0x4f1970;
            iVar12 = __vbaGenerateBoundsError();
          }
          else {
            ppppppfStack_46c = (float ******)((int)(short)pppppfStack_36c - (int)DAT_0050b3c8[7]);
            if (DAT_0050b3c8[6] <= ppppppfStack_46c) {
              ppppppfStack_60c = (float ******)0x4f1937;
              __vbaGenerateBoundsError();
            }
            pppppppfVar24 = (float *******)((int)(short)pppppfStack_374 - (int)DAT_0050b3c8[5]);
            if (DAT_0050b3c8[4] <= pppppppfVar24) {
              ppppppfStack_60c = (float ******)0x4f1953;
              __vbaGenerateBoundsError();
            }
            iVar12 = (int)((int)DAT_0050b3c8[6] * (int)pppppppfVar24 + (int)ppppppfStack_46c) * 4;
          }
          ppppppfStack_37c =
               (float ******)((float)ppppppfStack_37c + *(float *)((int)DAT_0050b3c8[3] + iVar12));
          pppppppfVar14 = (float *******)ppppppfStack_608;
          if ((uVar27 & 0xd) != 0) goto LAB_004f2fd3;
          uVar25 = (uint)(ushort)((short)uStack_35c + 1);
          if (SCARRY2((short)uStack_35c,1)) goto LAB_004f2fd8;
        }
        ppppppfStack_60c = (float ******)DAT_0050b348;
        ppppppfStack_610 = (float ******)0x4f19b6;
        __vbaLenBstr();
        ppppppfStack_610 = (float ******)0x4f19be;
        sVar11 = __vbaI2I4();
        if (SBORROW2(sVar11,1)) break;
        ppppppfStack_3a8 = (float ******)CONCAT22(ppppppfStack_3a8._2_2_,sVar11 + -1);
        ppppppfStack_60c = &pppppfStack_3b0;
        ppppppfStack_610 = (float ******)&DAT_00000001;
        ppppppfStack_614 = (float ******)DAT_0050b348;
        pppppfStack_3b0 = (float *****)0x2;
        ppppppfStack_618 = (float ******)0x4f19e6;
        Ordinal_631();
        ppppppfStack_618 = (float ******)0x4f19ef;
        __vbaStrMove();
        ppppppfStack_618 = (float ******)0x4f19f8;
        __vbaFreeVar();
        ppppppfVar19 = (float ******)(int)(short)pppppfStack_358;
        ppppppfStack_3f0 = (float ******)0x3;
        ppppppfStack_410 = (float ******)0x3;
        ppppppfStack_624 = (float ******)0x3;
        ppppppfStack_620 = ppppppfStack_3ec;
        ppppppfStack_618 = ppppppfStack_3e4;
        ppppppfStack_634 = (float ******)0x3;
        ppppppfStack_630 = ppppppfStack_40c;
        ppppppfStack_648 = (float ******)0x2;
        ppppppfStack_64c = (float ******)0x41;
        ppppppfStack_62c = (float ******)0x1;
        ppppppfStack_628 = ppppppfStack_404;
        ppppppfStack_644 = (float ******)0x4008;
        uStack_640 = (double)CONCAT44(&DAT_0050b348,ppppppfStack_42c);
        ppppppfStack_638 = ppppppfStack_424;
        ppppppfStack_650 = ppppppfStack_48c;
        ppppppfStack_654 = (float ******)0x4f1a89;
        ppppppfStack_61c = ppppppfVar19;
        ppppppfStack_3e8 = ppppppfVar19;
        __vbaLateIdCallSt();
        ppppppfStack_618 = (float ******)0x4f1a91;
        FUN_0044fdc0();
        ppppppfStack_618 = (float ******)0x4f1a98;
        __vbaStrMove();
        ppppppfStack_3a8 = ppppppfStack_384;
        ppppppfStack_61c = &pppppfStack_380;
        ppppppfStack_618 = (float ******)DAT_0050b3d4;
        pppppfStack_400 = (float *****)0x3;
        ppppppfStack_384 = (float ******)0x0;
        pppppfStack_3b0 = (float *****)0x8;
        ppppppfStack_620 = (float ******)0x4f1acd;
        pppppfStack_3f8 = (float *****)ppppppfVar19;
        __vbaAryLock();
        if (((float ******)pppppfStack_380 == (float ******)0x0) || (*(short *)pppppfStack_380 != 1)
           ) {
          ppppppfStack_620 = (float ******)0x4f1b08;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfStack_468 = (float ******)((int)ppppppfVar19 - (int)pppppfStack_380[5]);
          if (pppppfStack_380[4] <= ppppppfStack_468) {
            ppppppfStack_620 = (float ******)0x4f1af4;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)ppppppfStack_468 << 2;
        }
        ppppppfStack_620 = (float ******)&DAT_00000001;
        ppppppfStack_3e8 = (float ******)((int)pppppfStack_380[3] + iVar12);
        ppppppfStack_628 = &pppppfStack_3b0;
        ppppppfStack_624 = (float ******)&DAT_00000001;
        ppppppfStack_62c = (float ******)&ppppppfStack_3f0;
        ppppppfStack_630 = apppppfStack_3c0;
        ppppppfStack_3f0 = (float ******)0x4004;
        ppppppfStack_634 = (float ******)0x4f1b39;
        Ordinal_660();
        ppppppfStack_634 = &pppppfStack_380;
        ppppppfStack_638 = (float ******)0x4f1b43;
        __vbaAryUnlock();
        ppppppfStack_638 = apppppfStack_3c0;
        uStack_640 = (double)CONCAT44(0x4f1b4d,(undefined4)uStack_640);
        ppppppfStack_660 = (float ******)__vbaStrVarMove();
        pppppfStack_3d0 = (float *****)0x8;
        ppppppfStack_648 = (float ******)pppppfStack_400;
        ppppppfStack_644 = (float ******)pppppfStack_3fc;
        uStack_640 = (double)CONCAT44(uStack_3f4,pppppfStack_3f8);
        ppppppfStack_658 = (float ******)0x3;
        ppppppfStack_654 = ppppppfStack_41c;
        ppppppfStack_650 = (float ******)0x2;
        ppppppfStack_64c = (float ******)pppppfStack_414;
        ppppppfStack_66c = (float ******)0x2;
        ppppppfStack_670 = (float ******)0x41;
        ppppppfStack_668 = (float ******)0x8;
        ppppppfStack_664 = (float ******)uStack_3cc;
        ppppppfStack_674 = ppppppfStack_48c;
        ppppppfStack_65c = ppppppfStack_3c4;
        ppppppfStack_678 = (float ******)0x4f1bd7;
        uStack_3c8 = ppppppfStack_660;
        __vbaLateIdCallSt();
        uStack_640 = (double)CONCAT44(0x4f1be3,(undefined4)uStack_640);
        __vbaFreeStr();
        ppppppfStack_644 = &pppppfStack_3b0;
        uStack_640 = (double)CONCAT44(&pppppfStack_3d0,apppppfStack_3c0);
        ppppppfStack_648 = (float ******)0x3;
        ppppppfStack_64c = (float ******)0x4f1bfa;
        __vbaFreeVarList();
        uStack_640 = (double)(float)ppppppfStack_37c;
        ppppppfStack_644 = (float ******)0x4f1c09;
        fVar28 = (float10)Ordinal_614();
        uStack_464 = (double)fVar28;
        ppppppfStack_644 = (float ******)0x4f1c14;
        FUN_0044fdc0();
        ppppppfStack_644 = (float ******)0x4f1c1b;
        __vbaStrMove();
        pppppfStack_3b8 = (float *****)ppppppfStack_384;
        pppppppfVar15 = (float *******)0x3;
        pppppfStack_400 = (float *****)0x3;
        ppppppfStack_384 = (float ******)0x0;
        ppppppfStack_3a8 = (float ******)(float *******)uStack_464;
        ppppppfStack_644 = (float ******)&DAT_00000001;
        ppppppfStack_64c = apppppfStack_3c0;
        ppppppfStack_3a4 = (float ******)uStack_464._4_4_;
        ppppppfStack_648 = (float ******)&DAT_00000001;
        ppppppfStack_650 = &pppppfStack_3b0;
        ppppppfStack_654 = &pppppfStack_3d0;
        apppppfStack_3c0[0] = (float *****)0x8;
        pppppfStack_3b0 = (float *****)0x5;
        ppppppfStack_658 = (float ******)0x4f1c74;
        pppppfStack_3f8 = (float *****)ppppppfVar19;
        Ordinal_660();
        ppppppfStack_658 = &pppppfStack_3d0;
        ppppppfStack_65c = (float ******)0x4f1c81;
        ppppppfStack_680 = (float ******)__vbaStrVarMove();
        pppppfStack_3e0 = (float *****)0x8;
        ppppppfStack_668 = (float ******)pppppfStack_400;
        ppppppfStack_664 = (float ******)pppppfStack_3fc;
        ppppppfStack_660 = (float ******)pppppfStack_3f8;
        ppppppfStack_65c = (float ******)uStack_3f4;
        ppppppfStack_678 = (float ******)0x3;
        ppppppfStack_674 = ppppppfStack_41c;
        ppppppfStack_670 = (float ******)0x3;
        ppppppfStack_66c = (float ******)pppppfStack_414;
        uStack_690 = 4.24399161404481e-314;
        ppppppfStack_688 = (float ******)0x8;
        ppppppfStack_684 = ppppppfStack_3dc;
        ppppppfStack_694 = ppppppfStack_48c;
        ppppppfStack_67c = (float ******)pppppfStack_3d4;
        uStack_69c = (double)CONCAT44(0x4f1d04,(undefined4)uStack_69c);
        ppppppfStack_3d8 = ppppppfStack_680;
        __vbaLateIdCallSt();
        ppppppfStack_65c = (float ******)0x4f1d10;
        __vbaFreeStr();
        ppppppfStack_65c = &pppppfStack_3e0;
        ppppppfStack_660 = &pppppfStack_3d0;
        ppppppfStack_664 = apppppfStack_3c0;
        ppppppfStack_668 = &pppppfStack_3b0;
        ppppppfStack_66c = (float ******)0x4;
        ppppppfStack_670 = (float ******)0x4f1d2e;
        __vbaFreeVarList();
        pppppppfVar14 = DAT_0050b3cc;
        pppppppfVar24 = (float *******)pppppfStack_358;
      }
    }
    ppppppfVar19 = (float ******)(uint)(ushort)((short)pppppppfVar24 + 1);
  } while (!SCARRY2((short)pppppppfVar24,1));
LAB_004f2fd8:
  ppppppfStack_60c = (float ******)0x4f2fde;
  __vbaErrorOverflow();
  ppppppfStack_618 = (float ******)&DAT_00402706;
  ppppppfStack_61c = ExceptionList;
  ppppppfStack_614 = (float ******)&pcStack_6c0;
  ppppppfStack_610 = (float ******)&DAT_004025b8;
  ppppppfStack_620 = (float ******)0x0;
  ppppppfStack_624 = (float ******)0x0;
  ppppppfStack_634 = (float ******)0x0;
  ppppppfStack_644 = (float ******)0x0;
  ppppppfStack_678 = (float ******)0x0;
  ppppppfStack_64c = (float ******)&DAT_0050b3c4;
  ppppppfStack_654 = (float ******)0x4002;
  ExceptionList = &ppppppfStack_61c;
  pcStack_6c0 = pcVar23;
  ppppppfStack_6bc = (float ******)pppppppfVar24;
  ppppppfStack_6b8 = (float ******)pppppppfVar15;
  ppppppfStack_60c = (float ******)&ppppppfStack_344;
  __vbaAryLock(&ppppppfStack_620,DAT_0050b3cc);
  if ((ppppppfStack_620 == (float ******)0x0) || (*(short *)ppppppfStack_620 != 2)) {
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    pppppfVar4 = ppppppfStack_620[7];
    if (ppppppfStack_620[6] <= (float *****)-(int)pppppfVar4) {
      __vbaGenerateBoundsError();
    }
    pppppfVar5 = ppppppfStack_620[5];
    if (ppppppfStack_620[4] <= (float *****)-(int)pppppfVar5) {
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)ppppppfStack_620[6] * -(int)pppppfVar5 + -(int)pppppfVar4) * 4;
  }
  uStack_640 = (double)CONCAT44((int)ppppppfStack_620[3] + iVar12,(undefined4)uStack_640);
  ppppppfStack_644 = (float ******)0x4004;
  FUN_0042af50(&ppppppfStack_634,&ppppppfStack_644,&ppppppfStack_654);
  __vbaAryUnlock(&ppppppfStack_620);
  pppppppfVar24 = &ppppppfStack_634;
  DAT_0050b27c = __vbaI2Var(pppppppfVar24);
  __vbaFreeVar();
  DAT_0050b280 = DAT_0050b27c;
  DAT_0050b1d4 = 1;
  if (10 < DAT_0050b27c) {
    ppppppfStack_688 = (float ******)(int)DAT_0050b27c;
    uStack_690 = (double)(int)ppppppfStack_688;
    if ((uVar27 & 0xd) != 0) goto LAB_004f3326;
    ppppppfStack_678 = (float ******)__vbaFpI2();
    DAT_0050b1d4 = FUN_00476930(&ppppppfStack_678);
  }
  ppppppfStack_694 = (float ******)(int)DAT_0050b27c;
  DAT_0050b27a = -DAT_0050b1d4;
  uStack_69c = (double)(int)ppppppfStack_694;
  ppppppfStack_6a0 = (float ******)(int)DAT_0050b1d4;
  uStack_6a8 = (double)(int)ppppppfStack_6a0;
  if (DAT_0050b000 != 0) {
    dVar29 = uStack_6a8;
    adj_fdiv_m64();
    pppppppfVar24 = SUB84(dVar29,0);
  }
  if ((uVar27 & 0xd) == 0) {
    __vbaFPInt(pppppppfVar24);
    iStack_6ac = (int)DAT_0050b1d4;
    uStack_6b4 = (double)iStack_6ac;
    if ((uVar27 & 0xd) == 0) {
      DAT_0050b27c = __vbaFpI2();
      DAT_0050b27e = DAT_0050b27a;
      DAT_0050b280 = DAT_0050b27c;
      if (DAT_0050b570 == (int *)0x0) {
        __vbaNew2(&DAT_004048dc,&DAT_0050b570);
      }
      uVar13 = (**(code **)(*DAT_0050b570 + 0x350))(DAT_0050b570);
      piVar16 = (int *)__vbaObjSet(&ppppppfStack_624,uVar13);
      ppppppfStack_66c = (float ******)CONCAT22(ppppppfStack_66c._2_2_,DAT_0050b27e);
      ppppppfStack_65c = (float ******)CONCAT22(ppppppfStack_65c._2_2_,DAT_0050b27c);
      ppppppfStack_64c = (float ******)CONCAT22(ppppppfStack_64c._2_2_,DAT_0050b280);
      ppppppfStack_654 = (float ******)0x2;
      ppppppfStack_644 = (float ******)0x2;
      uStack_640._0_6_ = CONCAT24(DAT_0050b27a,(undefined4)uStack_640);
      iVar12 = (**(code **)(*piVar16 + 0x28c))
                         (piVar16,4,2,(undefined4)uStack_640,uStack_640._4_4_,ppppppfStack_638,2,
                          ppppppfStack_650,ppppppfStack_64c,ppppppfStack_648,2,ppppppfStack_660,
                          ppppppfStack_65c,ppppppfStack_658,2,ppppppfStack_670,ppppppfStack_66c,
                          ppppppfStack_668);
      if (iVar12 < 0) {
        __vbaHresultCheckObj(iVar12,piVar16,&DAT_0040c908,0x28c);
      }
      __vbaFreeObj();
      return;
    }
  }
LAB_004f3326:
  __vbaFPException();
  return;
}


