/* entry 004d02a0 name FUN_004d02a0 size 9013 */
/* strings:
 * Maximum flow in network = 
 * :      Breakthrough flow = 
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d02a0(void)

{
  code *****pppppcVar1;
  code ****ppppcVar2;
  float fVar3;
  code ******ppppppcVar4;
  code *pcVar5;
  code *pcVar6;
  code ******ppppppcVar7;
  code ******ppppppcVar8;
  undefined1 *puVar9;
  short sVar10;
  int *piVar11;
  int iVar12;
  undefined4 uVar13;
  code ******ppppppcVar14;
  uint uVar15;
  undefined4 *puVar16;
  short sVar17;
  short sVar18;
  undefined2 extraout_var;
  code ******ppppppcVar19;
  code ******ppppppcVar20;
  code *pcVar21;
  bool bVar22;
  ushort uVar23;
  undefined *puVar24;
  code *pcStack_2b8;
  code *pcStack_2b4;
  code *****pppppcStack_2b0;
  undefined4 *puStack_2ac;
  code *****pppppcStack_2a8;
  code *****pppppcStack_2a4;
  undefined *puStack_2a0;
  code *****pppppcStack_29c;
  code *****pppppcStack_298;
  code *****pppppcStack_294;
  code *****pppppcStack_290;
  code *****pppppcStack_28c;
  code *****pppppcStack_288;
  code *****pppppcStack_284;
  code *****pppppcStack_280;
  code *****pppppcStack_27c;
  code *****pppppcStack_278;
  code *****pppppcStack_274;
  code *****pppppcStack_270;
  code *****pppppcStack_26c;
  code *****pppppcStack_268;
  code *****pppppcStack_264;
  code *****pppppcStack_260;
  code *****pppppcStack_25c;
  code *****pppppcStack_258;
  code *****pppppcStack_254;
  code *****pppppcStack_250;
  code *****pppppcStack_24c;
  code *****pppppcStack_248;
  code *****pppppcStack_244;
  code *****pppppcStack_240;
  code *****pppppcStack_23c;
  code *****pppppcStack_238;
  code *****pppppcStack_234;
  code *****pppppcStack_230;
  code *****pppppcStack_22c;
  code *****pppppcStack_228;
  code ****ppppcStack_224;
  code *****pppppcStack_220;
  code *****pppppcStack_21c;
  code *****pppppcStack_218;
  code *****pppppcStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  code *****pppppcStack_208;
  undefined4 uStack_204;
  code *****pppppcStack_200;
  code *****pppppcStack_1fc;
  undefined *puStack_1f8;
  int *piStack_1f4;
  int *piStack_1f0;
  undefined4 uStack_1ec;
  undefined4 *puStack_1e8;
  undefined *puStack_1e4;
  int *piStack_1e0;
  int local_1cc;
  code *****local_158;
  code ***local_154;
  code ***local_150;
  code ***local_14c;
  code ***local_148;
  code ****local_144;
  code ****local_140;
  code ****local_12c;
  code *****local_128;
  wchar_t *local_124;
  code *****local_120;
  code *****local_11c;
  code *****local_118;
  code *****local_114;
  code *****local_110;
  code *****local_10c;
  code *****local_108;
  code *****local_104;
  code *****local_100;
  code ****local_fc;
  undefined4 local_f8;
  code *****local_f4;
  code ****local_f0;
  code *****local_ec;
  code *****local_e8;
  code *****local_e4;
  code *****local_e0;
  code ****local_dc [4];
  code ****local_cc [4];
  code ****local_bc [2];
  undefined4 local_b4;
  code ****local_ac [4];
  code ****local_9c;
  code *****local_98;
  code *****local_94;
  code *****local_90;
  code ****local_8c;
  code *****local_88;
  code *****local_84;
  code *****local_80;
  code ****local_7c;
  code *****local_78;
  code *****local_74;
  code *****local_70;
  undefined4 local_6c;
  code *****local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  code *****local_3c;
  code *****local_38;
  code ****local_34;
  code ****local_30;
  code ****local_2c;
  undefined4 local_28;
  undefined4 local_24;
  code *****local_20;
  uint local_1c;
  uint local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffe24;
  local_8 = &DAT_004023d8;
  ppppppcVar19 = (code ******)0x0;
  local_18 = 0;
  local_2c = (code ****)0x0;
  local_30 = (code ****)0x0;
  local_34 = (code ****)0x0;
  local_38 = (code *****)0x0;
  local_3c = (code *****)0x0;
  local_40 = 0;
  local_44 = 0;
  local_48 = 0;
  local_4c = 0;
  local_50 = 0;
  local_54 = 0;
  local_58 = 0;
  local_5c = 0;
  local_60 = 0;
  local_64 = 0;
  local_68 = (code *****)0x0;
  local_6c = 0;
  local_7c = (code ****)0x0;
  local_8c = (code ****)0x0;
  local_9c = (code ****)0x0;
  local_ac[0] = (code ****)0x0;
  local_bc[0] = (code ****)0x0;
  local_cc[0] = (code ****)0x0;
  local_dc[0] = (code ****)0x0;
  local_ec = (code *****)0x0;
  local_fc = (code ****)0x0;
  local_10c = (code *****)0x0;
  local_11c = (code *****)0x0;
  local_12c = (code ****)0x0;
  local_158 = (code *****)0x0;
  ExceptionList = &pvStack_14;
  puVar9 = &stack0xfffffe24;
  if (DAT_0050b420 == (int *)0x0) {
    piStack_1e0 = (int *)&DAT_0050b420;
    puStack_1e4 = &DAT_00408c88;
    puStack_1e8 = (undefined4 *)0x4d0368;
    ExceptionList = &pvStack_14;
    __vbaNew2();
    puVar9 = local_c;
  }
  local_c = puVar9;
  piStack_1e0 = DAT_0050b420;
  puStack_1e4 = (undefined *)0x4d0376;
  puStack_1e4 = (undefined *)(**(code **)(*DAT_0050b420 + 0x36c))();
  pcVar21 = __vbaObjSet_exref;
  puStack_1e8 = &local_6c;
  uStack_1ec = 0x4d0383;
  piVar11 = (int *)__vbaObjSet();
  uStack_1ec = 0xffffffff;
  piStack_1f4 = (int *)0x4d0390;
  piStack_1f0 = piVar11;
  iVar12 = (**(code **)(*piVar11 + 0x9c))();
  if (iVar12 < 0) {
    piStack_1f4 = (int *)0x9c;
    puStack_1f8 = &DAT_0040c3dc;
    uStack_204 = 0x4d03a8;
    pppppcStack_200 = (code *****)iVar12;
    pppppcStack_1fc = (code *****)piVar11;
    __vbaHresultCheckObj();
  }
  piStack_1f4 = (int *)0x4d03b1;
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    piStack_1f4 = (int *)&DAT_0050b420;
    puStack_1f8 = &DAT_00408c88;
    pppppcStack_1fc = (code *****)0x4d03ca;
    __vbaNew2();
  }
  piStack_1f4 = DAT_0050b420;
  puStack_1f8 = (undefined *)0x4d03d8;
  puStack_1f8 = (undefined *)(**(code **)(*DAT_0050b420 + 0x3a8))();
  pppppcStack_1fc = (code *****)&local_158;
  pppppcStack_200 = (code *****)0x4d03e2;
  __vbaObjSet();
  pcVar5 = __vbaLateIdSt_exref;
  local_ec = (code *****)0x3;
  uStack_20c = 3;
  local_e4 = (code *****)0x2;
  uStack_210 = 7;
  pppppcStack_208 = local_e8;
  pppppcStack_214 = local_158;
  uStack_204 = 2;
  pppppcStack_200 = local_e0;
  pppppcStack_218 = (code *****)0x4d0425;
  __vbaLateIdSt();
  if (DAT_0050b338 == 1) {
    pppppcStack_218 = (code *****)0x4d1268;
    FUN_0044fdc0();
    pcVar21 = __vbaStrMove_exref;
    pppppcStack_218 = (code *****)0x4d1275;
    __vbaStrMove();
    local_74 = local_38;
    pppppcStack_21c = &local_2c;
    pppppcStack_218 = (code *****)DAT_0050b19c;
    local_f4 = (code *****)0x4133e0;
    local_fc = (code ****)0x8;
    local_38 = (code *****)0x0;
    local_7c = (code ****)0x8;
    pppppcStack_220 = (code *****)0x4d12ab;
    __vbaAryLock();
    if (((code *****)local_2c == (code *****)0x0) || (*(short *)local_2c != 2)) {
      pppppcStack_220 = (code *****)0x4d1310;
      iVar12 = __vbaGenerateBoundsError();
    }
    else {
      local_144 = (code ****)(1 - (int)local_2c[7]);
      if (local_2c[6] <= local_144) {
        pppppcStack_220 = (code *****)0x4d12d5;
        __vbaGenerateBoundsError();
      }
      local_140 = (code ****)-(int)local_2c[5];
      if (local_2c[4] <= local_140) {
        pppppcStack_220 = (code *****)0x4d12f0;
        __vbaGenerateBoundsError();
      }
      iVar12 = (int)((int)local_144 + (int)local_2c[6] * (int)local_140) * 4;
    }
    pppppcStack_220 = (code *****)&DAT_00000001;
    local_e4 = (code *****)((int)local_2c[3] + iVar12);
    pppppcStack_228 = &local_7c;
    ppppcStack_224 = (code ****)&DAT_00000001;
    pppppcStack_22c = (code *****)&local_ec;
    pppppcStack_230 = &local_8c;
    local_ec = (code *****)0x4004;
    pppppcStack_234 = (code *****)0x4d1344;
    Ordinal_660();
    pppppcStack_234 = &local_2c;
    pppppcStack_238 = (code *****)0x4d134e;
    __vbaAryUnlock();
    pppppcStack_238 = (code *****)&local_11c;
    local_104 = (code *****)0x41341c;
    local_10c = (code *****)0x8;
    local_114 = (code *****)&DAT_0050b244;
    local_11c = (code *****)0x4002;
    pppppcStack_23c = (code *****)0x4d137f;
    local_b4 = Ordinal_536();
    pppppcStack_23c = &local_fc;
    pppppcStack_240 = &local_8c;
    pppppcStack_244 = &local_9c;
    local_bc[0] = (code ****)0x8;
    local_12c = (code ****)0x8;
    local_124 = L" iterations)";
    pppppcStack_248 = (code *****)0x4d13b8;
    pppppcStack_248 = (code *****)__vbaVarCat();
    pppppcStack_24c = (code *****)&local_10c;
    pppppcStack_250 = local_ac;
    pppppcStack_254 = (code *****)0x4d13c9;
    pppppcStack_254 = (code *****)__vbaVarCat();
    pppppcStack_258 = local_bc;
    pppppcStack_25c = local_cc;
    pppppcStack_260 = (code *****)0x4d13da;
    pppppcStack_260 = (code *****)__vbaVarCat();
    pppppcStack_264 = &local_12c;
    pppppcStack_268 = local_dc;
    pppppcStack_26c = (code *****)0x4d13eb;
    pppppcStack_26c = (code *****)__vbaVarCat();
    pppppcStack_270 = (code *****)0x4d13f2;
    __vbaStrVarMove();
    pppppcStack_270 = (code *****)0x4d13fb;
    __vbaStrMove();
    pppppcStack_270 = (code *****)0x4d1404;
    __vbaFreeStr();
    pppppcStack_270 = local_dc;
    pppppcStack_274 = local_cc;
    pppppcStack_278 = local_bc;
    pppppcStack_27c = local_ac;
    pppppcStack_280 = &local_9c;
    pppppcStack_284 = &local_8c;
    pppppcStack_288 = &local_7c;
    pppppcStack_28c = (code *****)0x7;
    pppppcStack_290 = (code *****)0x4d143a;
    __vbaFreeVarList();
    local_e4 = (code *****)0x0;
    local_ec = (code *****)0x3;
    pppppcStack_280 = (code *****)0xa;
    pppppcStack_27c = (code *****)0x3;
    pppppcStack_278 = local_e8;
    pppppcStack_284 = local_158;
    pppppcStack_274 = (code *****)0x0;
    pppppcStack_270 = local_e0;
    pppppcStack_288 = (code *****)0x4d1474;
    __vbaLateIdSt();
    sVar17 = DAT_0050b332 + 1;
    ppppppcVar20 = (code ******)0x2;
    ppppppcVar19 = (code ******)0x2;
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    pppppcStack_22c = local_158;
    pppppcStack_220 = local_e8;
    sVar10 = DAT_0050b332;
    while (local_158 = pppppcStack_22c, !SCARRY2(sVar10,1)) {
      sVar10 = (short)ppppppcVar20;
      ppppppcVar19 = ppppppcVar20;
      pcVar6 = pcVar21;
      local_e8 = pppppcStack_220;
      if (sVar17 < sVar10) goto LAB_004d15a9;
      local_ec = (code *****)0x3;
      pppppcStack_21c = (code *****)(int)sVar10;
      ppppcStack_224 = (code ****)0x3;
      pppppcStack_228 = (code *****)0xb;
      pppppcStack_230 = (code *****)0x4d14d7;
      local_e4 = pppppcStack_21c;
      __vbaLateIdSt();
      local_ec = (code *****)0x2;
      pppppcStack_240 = (code *****)0x28;
      pppppcStack_23c = (code *****)0x2;
      local_e4 = (code *****)0x1;
      pppppcStack_238 = local_e8;
      pppppcStack_244 = local_158;
      pppppcStack_234 = (code *****)&DAT_00000001;
      pppppcStack_230 = local_e0;
      pppppcStack_248 = (code *****)0x4d1514;
      __vbaLateIdSt();
      local_ec = (code *****)0x3;
      pppppcStack_258 = (code *****)0x27;
      pppppcStack_254 = (code *****)0x3;
      local_e4 = (code *****)0xff0000;
      pppppcStack_250 = local_e8;
      pppppcStack_25c = local_158;
      pppppcStack_24c = (code *****)0xff0000;
      pppppcStack_248 = local_e0;
      pppppcStack_260 = (code *****)0x4d1551;
      __vbaLateIdSt();
      local_ec = (code *****)0x3;
      pppppcStack_270 = (code *****)0x26;
      pppppcStack_26c = (code *****)0x3;
      local_e4 = (code *****)0xffff;
      pppppcStack_268 = local_e8;
      pppppcStack_274 = local_158;
      pppppcStack_264 = (code *****)0xffff;
      pppppcStack_260 = local_e0;
      pppppcStack_278 = (code *****)0x4d158e;
      __vbaLateIdSt();
      ppppppcVar20 = (code ******)(uint)(ushort)(sVar10 + 1);
      ppppppcVar7 = (code ******)pppppcStack_22c;
      ppppppcVar8 = (code ******)pppppcStack_220;
      pppppcStack_22c = local_158;
      pppppcStack_220 = local_e8;
    }
  }
  else {
    pcVar6 = __vbaStrMove_exref;
    ppppppcVar7 = (code ******)pppppcStack_22c;
    if (DAT_0050b338 == 2) {
      if (DAT_0050b244 < 1) {
        pppppcStack_218 = (code *****)0x4d0661;
        __vbaStrCopy();
        pcVar21 = __vbaStrMove_exref;
      }
      else {
        pppppcStack_218 = (code *****)0x0;
        pppppcStack_21c = (code *****)0x4;
        ppppcStack_224 = (code ****)&local_7c;
        pppppcStack_220 = local_158;
        pppppcStack_228 = (code *****)0x4d045b;
        pppppcStack_218 = (code *****)__vbaLateIdCallLd();
        pppppcStack_21c = (code *****)0x4d0465;
        iVar12 = __vbaI4Var();
        ppppppcVar7 = (code ******)pppppcStack_22c;
        ppppppcVar8 = (code ******)pppppcStack_220;
        if (SCARRY4(iVar12,1)) goto LAB_004d266c;
        local_ec = (code *****)0x3;
        pppppcStack_228 = (code *****)0x4;
        ppppcStack_224 = (code ****)0x3;
        pppppcStack_220 = local_e8;
        pppppcStack_22c = local_158;
        pppppcStack_218 = local_e0;
        pppppcStack_230 = (code *****)0x4d04a6;
        pppppcStack_21c = (code *****)(iVar12 + 1);
        local_e4 = (code *****)(iVar12 + 1);
        __vbaLateIdSt();
        pppppcStack_230 = (code *****)0x4d04af;
        __vbaFreeVar();
        if ((DAT_0050b19c == (code ******)0x0) || (*(short *)DAT_0050b19c != 2)) {
          pppppcStack_230 = (code *****)0x4d050c;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          local_144 = (code ****)-(int)DAT_0050b19c[7];
          if (DAT_0050b19c[6] <= local_144) {
            pppppcStack_230 = (code *****)0x4d04d7;
            __vbaGenerateBoundsError();
          }
          pppppcVar1 = DAT_0050b19c[5];
          if (DAT_0050b19c[4] <= (code *****)-(int)pppppcVar1) {
            pppppcStack_230 = (code *****)0x4d04ef;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)local_144 + (int)DAT_0050b19c[6] * -(int)pppppcVar1) * 4;
        }
        if (*(float *)((int)DAT_0050b19c[3] + iVar12) == _DAT_00401bc0) {
code_r0x004d25aa:
          pppppcStack_230 = (code *****)&LAB_004d265b;
          pppppcStack_234 = (code *****)0x4d265a;
          __vbaFreeObj();
          return;
        }
        pppppcStack_230 = (code *****)0x4d052e;
        FUN_0044fdc0();
        pcVar21 = __vbaStrMove_exref;
        pppppcStack_230 = (code *****)0x4d053b;
        __vbaStrMove();
        local_74 = local_38;
        local_fc = (code ****)0x8;
        local_7c = (code ****)0x8;
        pppppcStack_234 = &local_2c;
        pppppcStack_230 = (code *****)DAT_0050b19c;
        local_f4 = (code *****)0x41344c;
        local_38 = (code *****)0x0;
        pppppcStack_238 = (code *****)0x4d056c;
        __vbaAryLock();
        if (((code *****)local_2c == (code *****)0x0) || (*(short *)local_2c != 2)) {
          pppppcStack_238 = (code *****)0x4d05c0;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          local_144 = (code ****)-(int)local_2c[7];
          if (local_2c[6] <= local_144) {
            pppppcStack_238 = (code *****)0x4d0591;
            __vbaGenerateBoundsError();
          }
          ppppppcVar19 = (code ******)-(int)local_2c[5];
          if (local_2c[4] <= ppppppcVar19) {
            pppppcStack_238 = (code *****)0x4d05a6;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)((int)local_144 + (int)local_2c[6] * (int)ppppppcVar19) * 4;
        }
        pppppcStack_238 = (code *****)&DAT_00000001;
        local_e4 = (code *****)((int)local_2c[3] + iVar12);
        pppppcStack_240 = &local_7c;
        pppppcStack_23c = (code *****)&DAT_00000001;
        pppppcStack_244 = (code *****)&local_ec;
        pppppcStack_248 = &local_8c;
        local_ec = (code *****)0x4004;
        pppppcStack_24c = (code *****)0x4d05f4;
        Ordinal_660();
        pppppcStack_24c = &local_2c;
        pppppcStack_250 = (code *****)0x4d05fe;
        __vbaAryUnlock();
        pppppcStack_250 = &local_fc;
        pppppcStack_254 = &local_8c;
        pppppcStack_258 = &local_9c;
        pppppcStack_25c = (code *****)0x4d0619;
        pppppcStack_25c = (code *****)__vbaVarCat();
        pppppcStack_260 = (code *****)0x4d0620;
        __vbaStrVarMove();
        pppppcStack_260 = (code *****)0x4d0629;
        __vbaStrMove();
        pppppcStack_260 = (code *****)0x4d0632;
        __vbaFreeStr();
        pppppcStack_260 = &local_9c;
        pppppcStack_264 = &local_8c;
        pppppcStack_268 = &local_7c;
        pppppcStack_26c = (code *****)0x3;
        pppppcStack_270 = (code *****)0x4d064c;
        __vbaFreeVarList();
      }
      pppppcStack_260 = (code *****)0x0;
      pppppcStack_264 = (code *****)0x4;
      pppppcStack_26c = &local_7c;
      pppppcStack_268 = local_158;
      pppppcStack_270 = (code *****)0x4d067c;
      pppppcStack_260 = (code *****)__vbaLateIdCallLd();
      pppppcStack_264 = (code *****)0x4d0686;
      iVar12 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_22c;
      ppppppcVar8 = (code ******)pppppcStack_220;
      if (!SBORROW4(iVar12,1)) {
        pppppcStack_218 = (code *****)0x4d0697;
        uVar13 = __vbaI2I4();
        pppppcStack_218 = (code *****)0x4d06a5;
        local_24 = uVar13;
        __vbaFreeVar();
        local_ec = (code *****)0x3;
        pppppcStack_21c = (code *****)(int)(short)uVar13;
        ppppcStack_224 = (code ****)0x3;
        pppppcStack_228 = (code *****)0xa;
        pppppcStack_220 = local_e8;
        pppppcStack_22c = local_158;
        pppppcStack_218 = local_e0;
        pppppcStack_230 = (code *****)0x4d06e0;
        local_e4 = pppppcStack_21c;
        __vbaLateIdSt();
        ppppppcVar20 = (code ******)0x0;
        do {
          ppppppcVar19 = ppppppcVar20;
          sVar10 = (short)ppppppcVar19;
          if (1 < sVar10) {
            ppppppcVar19 = (code ******)0x2;
            sVar10 = DAT_0050b332 + 1;
            ppppppcVar20 = ppppppcVar19;
            ppppppcVar7 = (code ******)pppppcStack_22c;
            ppppppcVar8 = (code ******)pppppcStack_220;
            if (!SCARRY2(DAT_0050b332,1)) goto LAB_004d07a4;
            break;
          }
          local_ec = (code *****)0x3;
          pppppcStack_21c = (code *****)(int)sVar10;
          ppppcStack_224 = (code ****)0x3;
          pppppcStack_228 = (code *****)0xb;
          pppppcStack_220 = local_e8;
          pppppcStack_22c = local_158;
          pppppcStack_218 = local_e0;
          pppppcStack_230 = (code *****)0x4d0735;
          local_e4 = pppppcStack_21c;
          __vbaLateIdSt();
          local_ec = (code *****)0x3;
          pppppcStack_240 = (code *****)0x26;
          pppppcStack_23c = (code *****)0x3;
          local_e4 = (code *****)0xffff;
          pppppcStack_238 = local_e8;
          pppppcStack_244 = local_158;
          pppppcStack_234 = (code *****)0xffff;
          pppppcStack_230 = local_e0;
          pppppcStack_248 = (code *****)0x4d0772;
          __vbaLateIdSt();
          ppppppcVar20 = (code ******)CONCAT22(extraout_var,sVar10 + 1);
          ppppppcVar7 = (code ******)pppppcStack_22c;
          ppppppcVar8 = (code ******)pppppcStack_220;
        } while (!SCARRY2(sVar10,1));
      }
    }
    else {
LAB_004d15a9:
      pppppcStack_22c = (code *****)ppppppcVar7;
      pcVar21 = pcVar6;
      pppppcStack_218 = (code *****)0x0;
      pppppcStack_21c = (code *****)0x4;
      ppppcStack_224 = (code ****)&local_7c;
      pppppcStack_220 = local_158;
      pppppcStack_228 = (code *****)0x4d15be;
      pppppcStack_218 = (code *****)__vbaLateIdCallLd();
      pppppcStack_21c = (code *****)0x4d15c8;
      iVar12 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_22c;
      ppppppcVar8 = (code ******)pppppcStack_220;
      if (!SBORROW4(iVar12,1)) {
        pppppcStack_218 = (code *****)0x4d15d9;
        sVar10 = __vbaI2I4();
        pppppcStack_218 = (code *****)0x4d15e4;
        __vbaFreeVar();
        local_ec = (code *****)0x3;
        ppppppcVar14 = (code ******)(int)sVar10;
        ppppcStack_224 = (code ****)0x3;
        pppppcStack_220 = local_e8;
        pppppcStack_228 = (code *****)0xa;
        pppppcStack_22c = local_158;
        pppppcStack_218 = local_e0;
        pppppcStack_230 = (code *****)0x4d1625;
        pppppcStack_21c = (code *****)ppppppcVar14;
        local_e4 = (code *****)ppppppcVar14;
        __vbaLateIdSt();
        local_ec = (code *****)0x3;
        pppppcStack_240 = (code *****)0xb;
        pppppcStack_23c = (code *****)0x3;
        local_e4 = (code *****)0x0;
        pppppcStack_238 = local_e8;
        pppppcStack_244 = local_158;
        pppppcStack_234 = (code *****)0x0;
        pppppcStack_230 = local_e0;
        pppppcStack_248 = (code *****)0x4d165f;
        __vbaLateIdSt();
        local_ec = (code *****)0x3;
        pppppcStack_258 = (code *****)0x27;
        pppppcStack_254 = (code *****)0x3;
        local_e4 = (code *****)0xff0000;
        pppppcStack_250 = local_e8;
        pppppcStack_25c = local_158;
        pppppcStack_24c = (code *****)0xff0000;
        pppppcStack_248 = local_e0;
        pppppcStack_260 = (code *****)0x4d169c;
        __vbaLateIdSt();
        local_ec = (code *****)0x3;
        pppppcStack_270 = (code *****)0x26;
        pppppcStack_26c = (code *****)0x3;
        local_e4 = (code *****)0xffff00;
        pppppcStack_268 = local_e8;
        pppppcStack_274 = local_158;
        pppppcStack_264 = (code *****)0xffff00;
        pppppcStack_260 = local_e0;
        pppppcStack_278 = (code *****)0x4d16d9;
        __vbaLateIdSt();
        sVar17 = DAT_0050b332 + 1;
        ppppppcVar20 = (code ******)0x2;
        ppppppcVar19 = (code ******)0x2;
        ppppppcVar7 = (code ******)pppppcStack_22c;
        ppppppcVar8 = (code ******)pppppcStack_220;
        pppppcStack_22c = local_158;
        pppppcStack_220 = local_e8;
        sVar10 = DAT_0050b332;
        while (ppppppcVar4 = ppppppcVar20, local_158 = pppppcStack_22c, !SCARRY2(sVar10,1)) {
          sVar10 = (short)ppppppcVar4;
          local_e8 = pppppcStack_220;
          if (sVar17 < sVar10) {
            local_ec = (code *****)0x3;
            pppppcStack_228 = (code *****)0x30;
            ppppcStack_224 = (code ****)0x3;
            local_e4 = (code *****)0x2;
            pppppcStack_21c = (code *****)0x2;
            pppppcStack_230 = (code *****)0x4d18d1;
            __vbaLateIdSt();
            local_ec = (code *****)0x3;
            pppppcStack_23c = (code *****)0x3;
            local_10c = (code *****)0xb;
            pppppcStack_238 = local_e8;
            pppppcStack_250 = (code *****)&DAT_00000001;
            local_104 = (code *****)0xffffffff;
            pppppcStack_254 = (code *****)0x3b;
            pppppcStack_230 = local_e0;
            pppppcStack_24c = (code *****)0xb;
            pppppcStack_248 = local_108;
            pppppcStack_258 = local_158;
            pppppcStack_244 = (code *****)0xffffffff;
            pppppcStack_240 = local_100;
            pppppcStack_25c = (code *****)0x4d194a;
            pppppcStack_234 = (code *****)ppppppcVar14;
            local_e4 = (code *****)ppppppcVar14;
            __vbaLateIdCallSt();
            uVar15 = 0;
            goto LAB_004d194f;
          }
          local_ec = (code *****)0x3;
          pppppcStack_21c = (code *****)(int)sVar10;
          ppppcStack_224 = (code ****)0x3;
          pppppcStack_228 = (code *****)0xb;
          pppppcStack_230 = (code *****)0x4d173c;
          local_e4 = pppppcStack_21c;
          __vbaLateIdSt();
          local_ec = (code *****)0x2;
          pppppcStack_240 = (code *****)0x28;
          pppppcStack_23c = (code *****)0x2;
          local_e4 = (code *****)0x1;
          pppppcStack_238 = local_e8;
          pppppcStack_244 = local_158;
          pppppcStack_234 = (code *****)&DAT_00000001;
          pppppcStack_230 = local_e0;
          pppppcStack_248 = (code *****)0x4d1779;
          __vbaLateIdSt();
          pppppcStack_24c = (code *****)0x41100000;
          if (DAT_0050b338 != 1) {
            pppppcStack_24c = (code *****)0x40f00000;
          }
          local_ec = (code *****)0x4;
          pppppcStack_258 = (code *****)0x4e;
          pppppcStack_254 = (code *****)0x4;
          pppppcStack_250 = local_e8;
          pppppcStack_25c = local_158;
          pppppcStack_248 = local_e0;
          pppppcStack_260 = (code *****)0x4d17c5;
          local_e4 = pppppcStack_24c;
          __vbaLateIdSt();
          pppppcStack_274 = (code *****)(int)sVar10;
          local_ec = (code *****)0x3;
          local_10c = (code *****)0x3;
          pppppcStack_26c = (code *****)0x3;
          local_12c = (code ****)0x4008;
          pppppcStack_268 = local_e8;
          local_124 = (wchar_t *)&DAT_0050b34c;
          pppppcStack_260 = local_e0;
          pppppcStack_27c = (code *****)0x3;
          pppppcStack_278 = local_108;
          pppppcStack_270 = local_100;
          pppppcStack_290 = (code *****)0x2;
          pppppcStack_294 = (code *****)0x41;
          pppppcStack_28c = (code *****)0x4008;
          pppppcStack_288 = local_128;
          pppppcStack_284 = (code *****)&DAT_0050b34c;
          pppppcStack_280 = local_120;
          pppppcStack_298 = local_158;
          pppppcStack_29c = (code *****)0x4d187c;
          pppppcStack_264 = (code *****)ppppppcVar14;
          local_104 = pppppcStack_274;
          local_e4 = (code *****)ppppppcVar14;
          __vbaLateIdCallSt();
          ppppppcVar20 = (code ******)(uint)(ushort)(sVar10 + 1);
          ppppppcVar19 = ppppppcVar4;
          ppppppcVar7 = (code ******)pppppcStack_22c;
          ppppppcVar8 = (code ******)pppppcStack_220;
          pppppcStack_22c = local_158;
          pppppcStack_220 = local_e8;
        }
      }
    }
  }
  goto LAB_004d266c;
LAB_004d0cb2:
  local_18 = uVar15;
  sVar10 = (short)local_18;
  if ((short)local_28 < sVar10) {
    pcVar6 = pcVar21;
    if (DAT_0050b244 == 0) {
      pppppcStack_218 = (code *****)0x4d121e;
      __vbaStrCopy();
      ppppppcVar7 = (code ******)pppppcStack_22c;
      goto LAB_004d15a9;
    }
    pppppcStack_218 = (code *****)DAT_0050b34c;
    pppppcStack_21c = (code *****)0x4d1230;
    __vbaLenBstr();
    pppppcStack_21c = (code *****)0x4d1238;
    local_18 = __vbaI2I4();
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    if (!SBORROW2((short)local_18,1)) {
      pppppcStack_218 = (code *****)(int)(short)((short)local_18 + -1);
      pppppcStack_21c = (code *****)DAT_0050b34c;
      pppppcStack_220 = (code *****)0x4d1255;
      Ordinal_616();
      pppppcStack_220 = (code *****)0x4d125e;
      (*pcVar21)();
      ppppppcVar7 = (code ******)pppppcStack_22c;
      goto LAB_004d15a9;
    }
    goto LAB_004d266c;
  }
  if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
    pppppcStack_218 = (code *****)0x4d0d2b;
    local_1cc = __vbaGenerateBoundsError();
  }
  else {
    local_144 = (code ****)(1 - (int)DAT_0050b1a0[7]);
    if (DAT_0050b1a0[6] <= local_144) {
      pppppcStack_218 = (code *****)0x4d0cdf;
      __vbaGenerateBoundsError();
      sVar10 = (short)local_18;
    }
    local_140 = (code ****)((int)sVar10 - (int)DAT_0050b1a0[5]);
    if (DAT_0050b1a0[4] <= local_140) {
      pppppcStack_218 = (code *****)0x4d0d03;
      __vbaGenerateBoundsError();
    }
    local_1cc = (int)((int)local_144 + (int)DAT_0050b1a0[6] * (int)local_140) * 2;
  }
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if ((((SBORROW2(DAT_0050b244,1)) || (SCARRY2(DAT_0050b332,4))) ||
      (iVar12 = (int)(short)(DAT_0050b244 + -1) * (int)(short)(DAT_0050b332 + 4),
      sVar10 = (short)iVar12, sVar10 != iVar12)) ||
     ((sVar17 = *(short *)((int)DAT_0050b1a0[3] + local_1cc) + 3,
      SCARRY2(*(short *)((int)DAT_0050b1a0[3] + local_1cc),3) || (SCARRY2(sVar10,sVar17)))))
  goto LAB_004d266c;
  local_ec = (code *****)0x3;
  pppppcStack_21c = (code *****)(int)(short)(sVar10 + sVar17);
  pppppcStack_228 = (code *****)0xa;
  ppppcStack_224 = (code ****)0x3;
  pppppcStack_220 = local_e8;
  pppppcStack_22c = local_158;
  pppppcStack_218 = local_e0;
  pppppcStack_230 = (code *****)0x4d0dbd;
  local_e4 = pppppcStack_21c;
  __vbaLateIdSt();
  if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
    pppppcStack_218 = (code *****)0x4d0e2e;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    local_144 = (code ****)(2 - (int)DAT_0050b1a0[7]);
    if (DAT_0050b1a0[6] <= local_144) {
      pppppcStack_218 = (code *****)0x4d0dea;
      __vbaGenerateBoundsError();
    }
    local_140 = (code ****)((int)(short)local_18 - (int)DAT_0050b1a0[5]);
    if (DAT_0050b1a0[4] <= local_140) {
      pppppcStack_218 = (code *****)0x4d0e0c;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)local_144 + (int)DAT_0050b1a0[6] * (int)local_140) * 2;
  }
  local_ec = (code *****)0x3;
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SCARRY2(*(short *)((int)DAT_0050b1a0[3] + iVar12),1)) goto LAB_004d266c;
  pppppcStack_21c = (code *****)(int)(short)(*(short *)((int)DAT_0050b1a0[3] + iVar12) + 1);
  ppppcStack_224 = (code ****)0x3;
  pppppcStack_228 = (code *****)0xb;
  pppppcStack_220 = local_e8;
  pppppcStack_22c = local_158;
  pppppcStack_218 = local_e0;
  pppppcStack_230 = (code *****)0x4d0e80;
  local_e4 = pppppcStack_21c;
  __vbaLateIdSt();
  local_ec = (code *****)0x3;
  pppppcStack_240 = (code *****)0x26;
  pppppcStack_23c = (code *****)0x3;
  local_e4 = (code *****)0xff;
  pppppcStack_238 = local_e8;
  pppppcStack_244 = local_158;
  pppppcStack_234 = (code *****)0xff;
  pppppcStack_230 = local_e0;
  pppppcStack_248 = (code *****)0x4d0ebd;
  __vbaLateIdSt();
  pppppcStack_248 = (code *****)0x4d0ec2;
  FUN_0044fdc0();
  pppppcStack_248 = (code *****)0x4d0ec9;
  (*pcVar21)();
  pppppcStack_24c = &local_2c;
  pppppcStack_248 = (code *****)DAT_0050b1a0;
  pppppcStack_250 = (code *****)0x4d0eda;
  __vbaAryLock();
  if (((code *****)local_2c == (code *****)0x0) || (*(short *)local_2c != 2)) {
    pppppcStack_250 = (code *****)0x4d0f42;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    local_144 = (code ****)(2 - (int)local_2c[7]);
    if (local_2c[6] <= local_144) {
      pppppcStack_250 = (code *****)0x4d0f04;
      __vbaGenerateBoundsError();
    }
    local_140 = (code ****)((int)(short)local_18 - (int)local_2c[5]);
    if (local_2c[4] <= local_140) {
      pppppcStack_250 = (code *****)0x4d0f23;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)local_144 + (int)local_2c[6] * (int)local_140) * 2;
  }
  pppppcStack_250 = (code *****)&local_ec;
  local_e4 = (code *****)((int)local_2c[3] + iVar12);
  local_ec = (code *****)0x4002;
  pppppcStack_254 = (code *****)0x4d0f67;
  Ordinal_536();
  pppppcStack_254 = (code *****)0x4d0f6e;
  (*pcVar21)();
  pppppcStack_254 = &local_2c;
  pppppcStack_258 = (code *****)0x4d0f78;
  __vbaAryUnlock();
  local_74 = local_68;
  pppppcStack_25c = &local_30;
  pppppcStack_258 = (code *****)DAT_0050b19c;
  local_68 = (code *****)0x0;
  local_7c = (code ****)0x8;
  pppppcStack_260 = (code *****)0x4d0f9d;
  __vbaAryLock();
  if (((code *****)local_30 == (code *****)0x0) || (*(short *)local_30 != 2)) {
    pppppcStack_260 = (code *****)0x4d1003;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    local_14c = (code ***)-(int)local_30[7];
    if (local_30[6] <= local_14c) {
      pppppcStack_260 = (code *****)0x4d0fc2;
      __vbaGenerateBoundsError();
    }
    local_148 = (code ***)((int)(short)local_18 - (int)local_30[5]);
    if (local_30[4] <= local_148) {
      pppppcStack_260 = (code *****)0x4d0fe3;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)local_14c + (int)local_30[6] * (int)local_148) * 4;
  }
  pppppcStack_260 = (code *****)&DAT_00000001;
  local_f4 = (code *****)((int)local_30[3] + iVar12);
  pppppcStack_268 = &local_7c;
  pppppcStack_264 = (code *****)&DAT_00000001;
  pppppcStack_26c = &local_fc;
  pppppcStack_270 = &local_8c;
  local_fc = (code ****)0x4004;
  pppppcStack_274 = (code *****)0x4d1037;
  Ordinal_660();
  pppppcStack_274 = &local_30;
  pppppcStack_278 = (code *****)0x4d1041;
  __vbaAryUnlock();
  pppppcStack_27c = &local_34;
  pppppcStack_278 = (code *****)DAT_0050b1a0;
  pppppcStack_280 = (code *****)0x4d1051;
  __vbaAryLock();
  if (((code *****)local_34 == (code *****)0x0) || (*(short *)local_34 != 2)) {
    pppppcStack_280 = (code *****)0x4d10b9;
    iVar12 = __vbaGenerateBoundsError();
  }
  else {
    local_154 = (code ***)(1 - (int)local_34[7]);
    if (local_34[6] <= local_154) {
      pppppcStack_280 = (code *****)0x4d107b;
      __vbaGenerateBoundsError();
    }
    local_150 = (code ***)((int)(short)local_18 - (int)local_34[5]);
    if (local_34[4] <= local_150) {
      pppppcStack_280 = (code *****)0x4d109a;
      __vbaGenerateBoundsError();
    }
    iVar12 = (int)((int)local_154 + (int)local_34[6] * (int)local_150) * 2;
  }
  local_10c = (code *****)0x4002;
  local_104 = (code *****)((int)local_34[3] + iVar12);
  pppppcStack_280 = (code *****)&local_10c;
  pppppcStack_284 = (code *****)0x4d10de;
  Ordinal_536();
  pppppcStack_284 = (code *****)0x4d10e5;
  (*pcVar21)();
  pppppcStack_284 = &local_34;
  pppppcStack_288 = (code *****)0x4d10ef;
  __vbaAryUnlock();
  pppppcStack_288 = (code *****)DAT_0050b34c;
  pppppcStack_28c = (code *****)&DAT_0040fd5c;
  pppppcStack_290 = (code *****)0x4d10fd;
  __vbaStrCat();
  pppppcStack_290 = (code *****)0x4d1104;
  pppppcStack_290 = (code *****)(*pcVar21)();
  pppppcStack_294 = local_38;
  pppppcStack_298 = (code *****)0x4d110f;
  Ordinal_519();
  pppppcStack_298 = (code *****)0x4d1116;
  pppppcStack_298 = (code *****)(*pcVar21)();
  pppppcStack_29c = (code *****)0x4d1119;
  __vbaStrCat();
  pppppcStack_29c = (code *****)0x4d1120;
  pppppcStack_29c = (code *****)(*pcVar21)();
  puStack_2a0 = &DAT_004134bc;
  pppppcStack_2a4 = (code *****)0x4d1128;
  __vbaStrCat();
  pppppcStack_2a4 = (code *****)0x4d112f;
  pppppcStack_2a4 = (code *****)(*pcVar21)();
  pppppcStack_2a8 = &local_8c;
  puStack_2ac = &local_48;
  pppppcStack_2b0 = (code *****)0x4d1141;
  pppppcStack_2b0 = (code *****)__vbaStrVarVal();
  pcStack_2b4 = (code *)0x4d1148;
  Ordinal_519();
  pcStack_2b4 = (code *)0x4d114f;
  pcStack_2b4 = (code *)(*pcVar21)();
  pcStack_2b8 = (code *)0x4d1152;
  __vbaStrCat();
  pcStack_2b8 = (code *)0x4d1159;
  pcStack_2b8 = (code *)(*pcVar21)();
  __vbaStrCat(&DAT_00411cc4);
  uVar13 = (*pcVar21)();
  Ordinal_519(local_58,uVar13);
  uVar13 = (*pcVar21)();
  __vbaStrCat(uVar13);
  uVar13 = (*pcVar21)();
  __vbaStrCat(&DAT_004134c8,uVar13);
  (*pcVar21)();
  __vbaFreeStrList(0xd,&local_38,&local_3c,&local_40,&local_44,&local_48,&local_4c,&local_50,
                   &local_54,&local_58,&local_5c,&local_60,&local_64,&local_68);
  __vbaFreeVarList(2,&local_7c,&local_8c);
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  uVar15 = (uint)(ushort)((short)local_18 + 1);
  if (SCARRY2((short)local_18,1)) goto LAB_004d266c;
  goto LAB_004d0cb2;
LAB_004d194f:
  local_18 = uVar15;
  if (1 < (short)uVar15) {
    local_ec = (code *****)0x3;
    pppppcStack_228 = (code *****)0xb;
    ppppcStack_224 = (code ****)0x3;
    local_e4 = (code *****)0x0;
    pppppcStack_220 = local_e8;
    pppppcStack_22c = local_158;
    pppppcStack_21c = (code *****)0x0;
    pppppcStack_218 = local_e0;
    pppppcStack_230 = (code *****)0x4d1de7;
    __vbaLateIdSt();
    local_ec = (code *****)0x3;
    pppppcStack_240 = (code *****)0x26;
    pppppcStack_23c = (code *****)0x3;
    local_e4 = (code *****)0xffff00;
    pppppcStack_238 = local_e8;
    pppppcStack_244 = local_158;
    pppppcStack_234 = (code *****)0xffff00;
    pppppcStack_230 = local_e0;
    pppppcStack_248 = (code *****)0x4d1e24;
    __vbaLateIdSt();
    sVar10 = DAT_0050b332;
    uVar15 = 1;
    goto LAB_004d1e37;
  }
  pppppcStack_218 = (code *****)0x0;
  pppppcStack_21c = (code *****)0x4;
  ppppcStack_224 = (code ****)&local_7c;
  pppppcStack_220 = local_158;
  pppppcStack_228 = (code *****)0x4d1975;
  pppppcStack_218 = (code *****)__vbaLateIdCallLd();
  ppppppcVar19 = (code ******)__vbaI4Var_exref;
  pppppcStack_21c = (code *****)0x4d1981;
  iVar12 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SCARRY4(iVar12,1)) goto LAB_004d266c;
  local_ec = (code *****)0x3;
  pppppcStack_228 = (code *****)0x4;
  ppppcStack_224 = (code ****)0x3;
  pppppcStack_220 = local_e8;
  pppppcStack_22c = local_158;
  pppppcStack_218 = local_e0;
  pppppcStack_230 = (code *****)0x4d19c2;
  pppppcStack_21c = (code *****)(iVar12 + 1);
  local_e4 = (code *****)(iVar12 + 1);
  __vbaLateIdSt();
  pppppcStack_230 = (code *****)0x4d19cb;
  __vbaFreeVar();
  pppppcStack_230 = (code *****)0x0;
  pppppcStack_234 = (code *****)0x4;
  pppppcStack_23c = &local_7c;
  pppppcStack_238 = local_158;
  pppppcStack_240 = (code *****)0x4d19e0;
  pppppcStack_230 = (code *****)__vbaLateIdCallLd();
  pppppcStack_234 = (code *****)0x4d19e6;
  iVar12 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SBORROW4(iVar12,1)) goto LAB_004d266c;
  local_ec = (code *****)0x3;
  pppppcStack_228 = (code *****)0xa;
  ppppcStack_224 = (code ****)0x3;
  pppppcStack_220 = local_e8;
  pppppcStack_22c = local_158;
  pppppcStack_218 = local_e0;
  pppppcStack_230 = (code *****)0x4d1a27;
  pppppcStack_21c = (code *****)(iVar12 + -1);
  local_e4 = (code *****)(iVar12 + -1);
  __vbaLateIdSt();
  pppppcStack_230 = (code *****)0x4d1a30;
  __vbaFreeVar();
  sVar10 = DAT_0050b332 + 1;
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SCARRY2(DAT_0050b332,1)) goto LAB_004d266c;
  ppppppcVar20 = (code ******)0x0;
  while( true ) {
    ppppppcVar19 = ppppppcVar20;
    sVar17 = (short)ppppppcVar19;
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    if (sVar10 < sVar17) break;
    if ((sVar17 < 0) || (1 < sVar17)) {
      if ((short)local_18 == 0) {
        pppppcStack_214 = (code *****)&DAT_0040de90;
        if (SBORROW2(sVar17,1)) goto LAB_004d266c;
        local_74 = (code *****)CONCAT22(local_74._2_2_,sVar17 + -1);
        local_7c = (code ****)0x2;
        pppppcStack_220 = (code *****)0x4d1bb2;
        pppppcStack_21c = &local_7c;
        Ordinal_536();
        pppppcStack_220 = (code *****)0x4d1bb9;
        pppppcStack_220 = (code *****)(*pcVar21)();
        ppppcStack_224 = (code ****)0x4d1bc0;
        Ordinal_519();
        ppppcStack_224 = (code ****)0x4d1bc7;
        ppppcStack_224 = (code ****)(*pcVar21)();
        pppppcStack_228 = (code *****)0x4d1bce;
        __vbaStrCat();
        pppppcStack_228 = (code *****)0x4d1bd7;
        (*pcVar21)();
        pppppcStack_228 = (code *****)&local_3c;
        pppppcStack_22c = (code *****)&local_38;
        pppppcStack_230 = (code *****)0x2;
        pppppcStack_234 = (code *****)0x4d1be7;
        __vbaFreeStrList();
        pppppcStack_228 = (code *****)0x4d1bf3;
        __vbaFreeVar();
      }
      else if ((short)local_18 == 1) {
        if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
          pppppcStack_218 = (code *****)0x4d1adc;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          if (SBORROW2(sVar17,1)) goto LAB_004d266c;
          local_140 = (code ****)((int)(short)(sVar17 + -1) - *(int *)(DAT_0050b394 + 10));
          if (*(code ******)(DAT_0050b394 + 8) <= local_140) {
            pppppcStack_218 = (code *****)0x4d1ac2;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)local_140 * 0x18;
        }
        pppppcStack_218 = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar12);
        pppppcStack_21c = (code *****)0xc;
        pppppcStack_220 = (code *****)0x4d1af0;
        __vbaStrFixstr();
        pppppcStack_220 = (code *****)0x4d1af7;
        pppppcStack_220 = (code *****)(*pcVar21)();
        ppppcStack_224 = (code ****)0x4d1afe;
        Ordinal_519();
        ppppcStack_224 = (code ****)0x4d1b05;
        (*pcVar21)();
        if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
          pppppcStack_218 = (code *****)0x4d1b57;
          iVar12 = __vbaGenerateBoundsError();
        }
        else {
          ppppppcVar7 = (code ******)pppppcStack_22c;
          ppppppcVar8 = (code ******)pppppcStack_220;
          if (SBORROW2(sVar17,1)) goto LAB_004d266c;
          local_144 = (code ****)((int)(short)(sVar17 + -1) - *(int *)(DAT_0050b394 + 10));
          if (*(code ******)(DAT_0050b394 + 8) <= local_144) {
            pppppcStack_218 = (code *****)0x4d1b3d;
            __vbaGenerateBoundsError();
          }
          iVar12 = (int)local_144 * 0x18;
        }
        pppppcStack_21c = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar12);
        pppppcStack_218 = local_38;
        pppppcStack_220 = (code *****)0xc;
        ppppcStack_224 = (code ****)0x4d1b6f;
        __vbaLsetFixstr();
        local_3c = (code *****)0x0;
        ppppcStack_224 = (code ****)0x4d1b80;
        (*pcVar21)();
        ppppcStack_224 = (code ****)0x4d1b89;
        __vbaFreeStr();
      }
    }
    else {
      pppppcStack_218 = (code *****)0x4d1a71;
      __vbaStrCopy();
    }
    local_ec = (code *****)0x3;
    pppppcStack_21c = (code *****)(int)sVar17;
    ppppcStack_224 = (code ****)0x3;
    pppppcStack_228 = (code *****)0xb;
    pppppcStack_220 = local_e8;
    pppppcStack_22c = local_158;
    pppppcStack_218 = local_e0;
    pppppcStack_230 = (code *****)0x4d1c2e;
    local_e4 = pppppcStack_21c;
    __vbaLateIdSt();
    local_ec = (code *****)0x3;
    pppppcStack_240 = (code *****)0x27;
    pppppcStack_23c = (code *****)0x3;
    local_e4 = (code *****)0xff0000;
    pppppcStack_238 = local_e8;
    pppppcStack_244 = local_158;
    pppppcStack_234 = (code *****)0xff0000;
    pppppcStack_230 = local_e0;
    pppppcStack_248 = (code *****)0x4d1c6b;
    __vbaLateIdSt();
    local_ec = (code *****)0x3;
    pppppcStack_258 = (code *****)0x26;
    pppppcStack_254 = (code *****)0x3;
    local_e4 = (code *****)0xffff00;
    pppppcStack_250 = local_e8;
    pppppcStack_25c = local_158;
    pppppcStack_24c = (code *****)0xffff00;
    pppppcStack_248 = local_e0;
    pppppcStack_260 = (code *****)0x4d1ca8;
    __vbaLateIdSt();
    pppppcStack_260 = (code *****)0x0;
    pppppcStack_264 = (code *****)0xa;
    pppppcStack_26c = &local_7c;
    pppppcStack_268 = local_158;
    pppppcStack_270 = (code *****)0x4d1cbd;
    pppppcStack_260 = (code *****)__vbaLateIdCallLd();
    pppppcStack_264 = (code *****)0x4d1cc7;
    pppppcStack_268 = (code *****)__vbaI4Var();
    pppppcStack_278 = (code *****)(int)sVar17;
    local_ec = (code *****)0x3;
    local_10c = (code *****)0x3;
    pppppcStack_270 = (code *****)0x3;
    pppppcStack_26c = local_e8;
    local_124 = (wchar_t *)&DAT_0050b34c;
    local_12c = (code ****)0x4008;
    pppppcStack_264 = local_e0;
    pppppcStack_280 = (code *****)0x3;
    pppppcStack_27c = local_108;
    pppppcStack_274 = local_100;
    pppppcStack_294 = (code *****)0x2;
    pppppcStack_298 = (code *****)0x41;
    pppppcStack_290 = (code *****)0x4008;
    pppppcStack_28c = local_128;
    pppppcStack_288 = (code *****)&DAT_0050b34c;
    pppppcStack_284 = local_120;
    pppppcStack_29c = local_158;
    puStack_2a0 = (undefined *)0x4d1d78;
    local_104 = pppppcStack_278;
    local_e4 = pppppcStack_268;
    __vbaLateIdCallSt();
    pppppcStack_264 = (code *****)0x4d1d84;
    __vbaFreeVar();
    ppppppcVar20 = (code ******)(uint)(ushort)(sVar17 + 1);
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    if (SCARRY2(sVar17,1)) goto LAB_004d266c;
  }
  uVar15 = (uint)(ushort)((short)local_18 + 1);
  if (SCARRY2((short)local_18,1)) goto LAB_004d266c;
  goto LAB_004d194f;
LAB_004d1e37:
  pppppcStack_218 = (code *****)0x0;
  local_18 = uVar15;
  if (sVar10 < (short)uVar15) {
    pppppcStack_21c = (code *****)&local_158;
    pppppcStack_220 = (code *****)0x4d25a9;
    __vbaObjSetAddref();
    goto code_r0x004d25aa;
  }
  pppppcStack_21c = (code *****)0x4;
  ppppcStack_224 = (code ****)&local_7c;
  pppppcStack_220 = local_158;
  pppppcStack_228 = (code *****)0x4d1e5c;
  pppppcStack_218 = (code *****)__vbaLateIdCallLd();
  ppppppcVar19 = (code ******)__vbaI4Var_exref;
  pppppcStack_21c = (code *****)0x4d1e68;
  iVar12 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SCARRY4(iVar12,1)) goto LAB_004d266c;
  local_ec = (code *****)0x3;
  pppppcStack_228 = (code *****)0x4;
  ppppcStack_224 = (code ****)0x3;
  pppppcStack_220 = local_e8;
  pppppcStack_22c = local_158;
  pppppcStack_218 = local_e0;
  pppppcStack_230 = (code *****)0x4d1ea9;
  pppppcStack_21c = (code *****)(iVar12 + 1);
  local_e4 = (code *****)(iVar12 + 1);
  __vbaLateIdSt();
  pppppcStack_230 = (code *****)0x4d1eb2;
  __vbaFreeVar();
  pppppcStack_230 = (code *****)0x0;
  pppppcStack_234 = (code *****)0x4;
  pppppcStack_23c = &local_7c;
  pppppcStack_238 = local_158;
  pppppcStack_240 = (code *****)0x4d1ec7;
  pppppcStack_230 = (code *****)__vbaLateIdCallLd();
  pppppcStack_234 = (code *****)0x4d1ecd;
  iVar12 = __vbaI4Var();
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SBORROW4(iVar12,1)) goto LAB_004d266c;
  pppppcStack_218 = (code *****)0x4d1ede;
  ppppppcVar19 = (code ******)__vbaI2I4();
  pppppcStack_218 = (code *****)0x4d1eec;
  local_20 = (code *****)ppppppcVar19;
  __vbaFreeVar();
  local_ec = (code *****)0x3;
  pppppcStack_21c = (code *****)(int)(short)ppppppcVar19;
  ppppcStack_224 = (code ****)0x3;
  pppppcStack_228 = (code *****)0xa;
  pppppcStack_220 = local_e8;
  pppppcStack_22c = local_158;
  pppppcStack_218 = local_e0;
  pppppcStack_230 = (code *****)0x4d1f27;
  local_e4 = pppppcStack_21c;
  __vbaLateIdSt();
  local_ec = (code *****)0x3;
  pppppcStack_240 = (code *****)0xb;
  pppppcStack_23c = (code *****)0x3;
  local_e4 = (code *****)0x0;
  pppppcStack_238 = local_e8;
  pppppcStack_244 = local_158;
  pppppcStack_234 = (code *****)0x0;
  pppppcStack_230 = local_e0;
  pppppcStack_248 = (code *****)0x4d1f61;
  __vbaLateIdSt();
  local_e4 = (code *****)0xff0000;
  local_ec = (code *****)0x3;
  pppppcStack_258 = (code *****)0x27;
  pppppcStack_254 = (code *****)0x3;
  pppppcStack_250 = local_e8;
  pppppcStack_25c = local_158;
  pppppcStack_24c = (code *****)0xff0000;
  pppppcStack_248 = local_e0;
  pppppcStack_260 = (code *****)0x4d1f9e;
  __vbaLateIdSt();
  local_ec = (code *****)0x3;
  pppppcStack_270 = (code *****)0x26;
  pppppcStack_26c = (code *****)0x3;
  local_e4 = (code *****)0xffff00;
  pppppcStack_268 = local_e8;
  pppppcStack_274 = local_158;
  pppppcStack_264 = (code *****)0xffff00;
  pppppcStack_260 = local_e0;
  pppppcStack_278 = (code *****)0x4d1fdb;
  __vbaLateIdSt();
  local_ec = (code *****)0x3;
  pppppcStack_288 = (code *****)0xb;
  pppppcStack_284 = (code *****)0x3;
  local_e4 = (code *****)0x1;
  pppppcStack_280 = local_e8;
  pppppcStack_28c = local_158;
  pppppcStack_27c = (code *****)&DAT_00000001;
  pppppcStack_278 = local_e0;
  pppppcStack_290 = (code *****)0x4d2018;
  __vbaLateIdSt();
  local_ec = (code *****)0x3;
  puStack_2a0 = (undefined *)0x27;
  pppppcStack_29c = (code *****)0x3;
  local_e4 = (code *****)0xff0000;
  pppppcStack_298 = local_e8;
  pppppcStack_2a4 = local_158;
  pppppcStack_294 = (code *****)0xff0000;
  pppppcStack_290 = local_e0;
  pppppcStack_2a8 = (code *****)0x4d2055;
  __vbaLateIdSt();
  local_ec = (code *****)0x3;
  pcStack_2b8 = (code *)0x26;
  pcStack_2b4 = (code *)0x3;
  local_e4 = (code *****)0xffff00;
  pppppcStack_2b0 = local_e8;
  puStack_2ac = (undefined4 *)0xffff00;
  pppppcStack_2a8 = local_e0;
  __vbaLateIdSt(local_158);
  sVar17 = DAT_0050b332;
  uVar15 = 1;
  while( true ) {
    local_1c = uVar15;
    if (sVar17 < (short)uVar15) break;
    if ((short)local_18 != (short)uVar15) {
      pppppcStack_21c = (code *****)&local_ec;
      local_e4 = (code *****)&local_18;
      pppppcStack_218 = (code *****)&DAT_0040de90;
      local_ec = (code *****)0x4002;
      pppppcStack_220 = (code *****)0x4d20e4;
      Ordinal_536();
      pppppcStack_220 = (code *****)0x4d20eb;
      pppppcStack_220 = (code *****)(*pcVar21)();
      ppppcStack_224 = (code ****)0x4d20f2;
      Ordinal_519();
      ppppcStack_224 = (code ****)0x4d20f9;
      ppppcStack_224 = (code ****)(*pcVar21)();
      pppppcStack_228 = (code *****)0x4d2100;
      __vbaStrCat();
      pppppcStack_228 = (code *****)0x4d2109;
      (*pcVar21)();
      pppppcStack_228 = (code *****)&local_3c;
      pppppcStack_22c = (code *****)&local_38;
      pppppcStack_230 = (code *****)0x2;
      pppppcStack_234 = (code *****)0x4d2119;
      __vbaFreeStrList();
      ppppppcVar19 = (code ******)(int)(short)local_20;
      pppppcStack_22c = (code *****)&local_ec;
      local_e4 = (code *****)&local_18;
      pppppcStack_228 = (code *****)&DAT_0040de90;
      local_fc = (code ****)0x3;
      local_114 = (code *****)0x0;
      local_11c = (code *****)0x3;
      local_ec = (code *****)0x4002;
      pppppcStack_230 = (code *****)0x4d2166;
      local_f4 = (code *****)ppppppcVar19;
      Ordinal_536();
      pppppcStack_230 = (code *****)0x4d216d;
      pppppcStack_230 = (code *****)(*pcVar21)();
      pppppcStack_234 = (code *****)0x4d2174;
      Ordinal_519();
      pppppcStack_234 = (code *****)0x4d217b;
      pppppcStack_234 = (code *****)(*pcVar21)();
      pppppcStack_238 = (code *****)0x4d2182;
      pppppcStack_25c = (code *****)__vbaStrCat();
      local_7c = (code ****)0x8;
      pppppcStack_244 = (code *****)local_fc;
      pppppcStack_240 = (code *****)local_f8;
      pppppcStack_23c = local_f4;
      pppppcStack_238 = (code *****)local_f0;
      pppppcStack_254 = local_11c;
      pppppcStack_250 = local_118;
      pppppcStack_24c = local_114;
      pppppcStack_248 = local_110;
      pppppcStack_264 = (code *****)0x8;
      pppppcStack_260 = local_78;
      pppppcStack_258 = local_70;
      pppppcStack_268 = (code *****)0x2;
      pppppcStack_26c = (code *****)0x41;
      pppppcStack_270 = local_158;
      pppppcStack_274 = (code *****)0x4d2206;
      local_74 = pppppcStack_25c;
      __vbaLateIdCallSt();
      pppppcStack_274 = (code *****)&local_3c;
      pppppcStack_278 = (code *****)&local_38;
      pppppcStack_27c = (code *****)0x2;
      pppppcStack_280 = (code *****)0x4d2216;
      __vbaFreeStrList();
      pppppcStack_238 = (code *****)0x4d2222;
      __vbaFreeVar();
      local_ec = (code *****)0x3;
      local_104 = (code *****)&DAT_00000001;
      local_10c = (code *****)0x3;
      local_e4 = (code *****)ppppppcVar19;
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppcStack_238 = (code *****)0x4d2289;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        local_140 = (code ****)((int)(short)local_18 - *(int *)(DAT_0050b394 + 10));
        if (*(code ******)(DAT_0050b394 + 8) <= local_140) {
          pppppcStack_238 = (code *****)0x4d226f;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)local_140 * 0x18;
      }
      pppppcStack_238 = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar12);
      pppppcStack_23c = (code *****)0xc;
      pppppcStack_240 = (code *****)0x4d229d;
      __vbaStrFixstr();
      pppppcStack_240 = (code *****)0x4d22a4;
      pppppcStack_240 = (code *****)(*pcVar21)();
      pppppcStack_244 = (code *****)0x4d22ab;
      Ordinal_519();
      pppppcStack_244 = (code *****)0x4d22b2;
      (*pcVar21)();
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppcStack_244 = (code *****)0x4d22f8;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        local_144 = (code ****)((int)(short)local_18 - *(int *)(DAT_0050b394 + 10));
        if (*(code ******)(DAT_0050b394 + 8) <= local_144) {
          pppppcStack_244 = (code *****)0x4d22de;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)local_144 * 0x18;
      }
      pppppcStack_248 = (code *****)(*(int *)(DAT_0050b394 + 6) + iVar12);
      pppppcStack_244 = local_38;
      pppppcStack_24c = (code *****)0xc;
      pppppcStack_250 = (code *****)0x4d2310;
      __vbaLsetFixstr();
      pppppcStack_274 = local_3c;
      local_7c = (code ****)0x8;
      pppppcStack_25c = local_ec;
      local_74 = local_3c;
      local_3c = (code *****)0x0;
      pppppcStack_258 = local_e8;
      pppppcStack_254 = local_e4;
      pppppcStack_250 = local_e0;
      pppppcStack_26c = local_10c;
      pppppcStack_268 = local_108;
      pppppcStack_264 = local_104;
      pppppcStack_260 = local_100;
      pppppcStack_280 = (code *****)0x2;
      pppppcStack_284 = (code *****)0x41;
      pppppcStack_27c = (code *****)0x8;
      pppppcStack_278 = local_78;
      pppppcStack_288 = local_158;
      pppppcStack_270 = local_70;
      pppppcStack_28c = (code *****)0x4d239e;
      __vbaLateIdCallSt();
      pppppcStack_250 = (code *****)0x4d23aa;
      __vbaFreeStr();
      pppppcStack_250 = (code *****)0x4d23b3;
      __vbaFreeVar();
      pppppcStack_250 = (code *****)0x4d23b8;
      FUN_0044fdc0();
      pppppcStack_250 = (code *****)0x4d23bf;
      (*pcVar21)();
      bVar22 = SCARRY2((short)local_1c,1);
      sVar18 = (short)local_1c + 1;
      local_fc = (code ****)0x3;
      local_11c = (code *****)0x3;
      ppppppcVar7 = (code ******)pppppcStack_22c;
      ppppppcVar8 = (code ******)pppppcStack_220;
      if (bVar22) goto LAB_004d266c;
      local_114 = (code *****)(int)sVar18;
      local_74 = local_38;
      pppppcStack_21c = &local_2c;
      pppppcStack_218 = (code *****)DAT_0050b19c;
      local_38 = (code *****)0x0;
      local_7c = (code ****)0x8;
      pppppcStack_220 = (code *****)0x4d2412;
      local_f4 = (code *****)ppppppcVar19;
      __vbaAryLock();
      if (((code *****)local_2c == (code *****)0x0) || (*(short *)local_2c != 2)) {
        pppppcStack_220 = (code *****)0x4d246e;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        local_144 = (code ****)((int)(short)local_18 - (int)local_2c[7]);
        if (local_2c[6] <= local_144) {
          pppppcStack_220 = (code *****)0x4d243b;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)(short)local_1c;
        ppppcVar2 = (code ****)local_2c[5];
        if (local_2c[4] <= (code ****)(iVar12 - (int)ppppcVar2)) {
          pppppcStack_220 = (code *****)0x4d2454;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)((int)local_144 + (int)local_2c[6] * (iVar12 - (int)ppppcVar2)) * 4;
      }
      pppppcStack_220 = (code *****)&DAT_00000001;
      local_e4 = (code *****)((int)local_2c[3] + iVar12);
      pppppcStack_228 = &local_7c;
      ppppcStack_224 = (code ****)&DAT_00000001;
      pppppcStack_22c = (code *****)&local_ec;
      pppppcStack_230 = &local_8c;
      local_ec = (code *****)0x4004;
      pppppcStack_234 = (code *****)0x4d24a2;
      Ordinal_660();
      pppppcStack_234 = &local_2c;
      pppppcStack_238 = (code *****)0x4d24ac;
      __vbaAryUnlock();
      pppppcStack_238 = &local_8c;
      pppppcStack_23c = (code *****)0x4d24b9;
      pppppcStack_260 = (code *****)__vbaStrVarMove();
      ppppppcVar19 = (code ******)local_110;
      pppppcStack_248 = (code *****)local_fc;
      local_9c = (code ****)0x8;
      pppppcStack_244 = (code *****)local_f8;
      pppppcStack_240 = local_f4;
      pppppcStack_23c = (code *****)local_f0;
      pppppcStack_258 = local_11c;
      pppppcStack_254 = local_118;
      pppppcStack_250 = local_114;
      pppppcStack_24c = local_110;
      pppppcStack_26c = (code *****)0x2;
      pppppcStack_270 = (code *****)0x41;
      pppppcStack_268 = (code *****)0x8;
      pppppcStack_264 = local_98;
      pppppcStack_274 = local_158;
      pppppcStack_25c = local_90;
      pppppcStack_278 = (code *****)0x4d2547;
      local_94 = pppppcStack_260;
      __vbaLateIdCallSt();
      pppppcStack_23c = (code *****)0x4d2553;
      __vbaFreeStr();
      pppppcStack_23c = &local_9c;
      pppppcStack_240 = &local_8c;
      pppppcStack_244 = &local_7c;
      pppppcStack_248 = (code *****)0x3;
      pppppcStack_24c = (code *****)0x4d256d;
      __vbaFreeVarList();
    }
    uVar15 = (uint)(ushort)((short)local_1c + 1);
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    if (SCARRY2((short)local_1c,1)) goto LAB_004d266c;
  }
  uVar15 = (uint)(ushort)((short)local_18 + 1);
  ppppppcVar7 = (code ******)pppppcStack_22c;
  ppppppcVar8 = (code ******)pppppcStack_220;
  if (SCARRY2((short)local_18,1)) goto LAB_004d266c;
  goto LAB_004d1e37;
  while( true ) {
    local_ec = (code *****)0x3;
    pppppcStack_21c = (code *****)(int)sVar17;
    ppppcStack_224 = (code ****)0x3;
    pppppcStack_228 = (code *****)0xb;
    pppppcStack_220 = local_e8;
    pppppcStack_22c = local_158;
    pppppcStack_218 = local_e0;
    pppppcStack_230 = (code *****)0x4d07e8;
    local_e4 = pppppcStack_21c;
    __vbaLateIdSt();
    local_ec = (code *****)0x2;
    pppppcStack_240 = (code *****)0x28;
    pppppcStack_23c = (code *****)0x2;
    local_e4 = (code *****)0x1;
    pppppcStack_238 = local_e8;
    pppppcStack_244 = local_158;
    pppppcStack_234 = (code *****)&DAT_00000001;
    pppppcStack_230 = local_e0;
    pppppcStack_248 = (code *****)0x4d0825;
    __vbaLateIdSt();
    local_ec = (code *****)0x3;
    pppppcStack_258 = (code *****)0x27;
    pppppcStack_254 = (code *****)0x3;
    local_e4 = (code *****)0xff0000;
    pppppcStack_250 = local_e8;
    pppppcStack_25c = local_158;
    pppppcStack_24c = (code *****)0xff0000;
    pppppcStack_248 = local_e0;
    pppppcStack_260 = (code *****)0x4d0862;
    __vbaLateIdSt();
    local_ec = (code *****)0x3;
    pppppcStack_270 = (code *****)0x26;
    pppppcStack_26c = (code *****)0x3;
    local_e4 = (code *****)0xffff;
    pppppcStack_268 = local_e8;
    pppppcStack_274 = local_158;
    pppppcStack_264 = (code *****)0xffff;
    pppppcStack_260 = local_e0;
    pppppcStack_278 = (code *****)0x4d089f;
    __vbaLateIdSt();
    local_114 = (code *****)(int)sVar17;
    local_fc = (code ****)0x3;
    local_11c = (code *****)0x3;
    pppppcStack_218 = &local_7c;
    pppppcStack_214 = (code *****)0x410eb0;
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    if (SCARRY2(DAT_0050b244,1)) break;
    local_74 = (code *****)CONCAT22(local_74._2_2_,DAT_0050b244 + 1);
    local_7c = (code ****)0x2;
    pppppcStack_21c = (code *****)0x4d08ed;
    local_f4 = (code *****)(int)(short)local_24;
    Ordinal_536();
    pppppcStack_21c = (code *****)0x4d08f4;
    pppppcStack_21c = (code *****)(*pcVar21)();
    pppppcStack_220 = (code *****)0x4d08fb;
    __vbaStrCat();
    pppppcStack_220 = (code *****)0x4d0902;
    pppppcStack_220 = (code *****)(*pcVar21)();
    ppppcStack_224 = (code ****)DAT_0050b348;
    pppppcStack_228 = (code *****)0x4d0910;
    pppppcStack_24c = (code *****)__vbaStrCat();
    local_8c = (code ****)0x8;
    pppppcStack_234 = (code *****)local_fc;
    pppppcStack_230 = (code *****)local_f8;
    pppppcStack_22c = local_f4;
    pppppcStack_228 = (code *****)local_f0;
    pppppcStack_244 = local_11c;
    pppppcStack_240 = local_118;
    pppppcStack_23c = local_114;
    pppppcStack_238 = local_110;
    pppppcStack_258 = (code *****)0x2;
    pppppcStack_25c = (code *****)0x41;
    pppppcStack_254 = (code *****)0x8;
    pppppcStack_250 = local_88;
    pppppcStack_248 = local_80;
    pppppcStack_260 = local_158;
    pppppcStack_264 = (code *****)0x4d099d;
    local_84 = pppppcStack_24c;
    __vbaLateIdCallSt();
    pppppcStack_264 = (code *****)&local_3c;
    pppppcStack_268 = (code *****)&local_38;
    pppppcStack_26c = (code *****)0x2;
    pppppcStack_270 = (code *****)0x4d09ad;
    __vbaFreeStrList();
    pppppcStack_228 = &local_8c;
    pppppcStack_22c = &local_7c;
    pppppcStack_230 = (code *****)0x2;
    pppppcStack_234 = (code *****)0x4d09c3;
    __vbaFreeVarList();
    ppppppcVar20 = (code ******)(uint)(ushort)(sVar17 + 1);
    ppppppcVar7 = (code ******)pppppcStack_22c;
    ppppppcVar8 = (code ******)pppppcStack_220;
    if (SCARRY2(sVar17,1)) break;
LAB_004d07a4:
    ppppppcVar19 = ppppppcVar20;
    sVar17 = (short)ppppppcVar19;
    if (sVar10 < sVar17) {
      local_ec = (code *****)0x3;
      pppppcStack_228 = (code *****)0x30;
      ppppcStack_224 = (code ****)0x3;
      local_e4 = (code *****)0x2;
      pppppcStack_220 = local_e8;
      pppppcStack_22c = local_158;
      pppppcStack_21c = (code *****)0x2;
      pppppcStack_218 = local_e0;
      pppppcStack_230 = (code *****)0x4d0a1e;
      __vbaLateIdSt();
      pppppcStack_234 = (code *****)(int)(short)local_24;
      local_ec = (code *****)0x3;
      pppppcStack_23c = (code *****)0x3;
      local_10c = (code *****)0xb;
      pppppcStack_238 = local_e8;
      local_104 = (code *****)0xffffffff;
      pppppcStack_250 = (code *****)&DAT_00000001;
      pppppcStack_254 = (code *****)0x3b;
      pppppcStack_230 = local_e0;
      pppppcStack_24c = (code *****)0xb;
      pppppcStack_248 = local_108;
      pppppcStack_258 = local_158;
      pppppcStack_244 = (code *****)0xffffffff;
      pppppcStack_240 = local_100;
      pppppcStack_25c = (code *****)0x4d0a95;
      local_e4 = pppppcStack_234;
      __vbaLateIdCallSt();
      pppppcStack_25c = (code *****)0x0;
      pppppcStack_260 = (code *****)0x4;
      pppppcStack_268 = &local_7c;
      pppppcStack_264 = local_158;
      pppppcStack_26c = (code *****)0x4d0aaa;
      pppppcStack_230 = (code *****)__vbaLateIdCallLd();
      ppppppcVar19 = (code ******)__vbaI4Var_exref;
      pppppcStack_234 = (code *****)0x4d0ab6;
      iVar12 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_22c;
      ppppppcVar8 = (code ******)pppppcStack_220;
      if (SCARRY4(iVar12,1)) break;
      local_ec = (code *****)0x3;
      pppppcStack_228 = (code *****)0x4;
      ppppcStack_224 = (code ****)0x3;
      pppppcStack_220 = local_e8;
      pppppcStack_22c = local_158;
      pppppcStack_218 = local_e0;
      pppppcStack_230 = (code *****)0x4d0af7;
      pppppcStack_21c = (code *****)(iVar12 + 1);
      local_e4 = (code *****)(iVar12 + 1);
      __vbaLateIdSt();
      pppppcStack_230 = (code *****)0x4d0b00;
      __vbaFreeVar();
      pppppcStack_230 = (code *****)0x0;
      pppppcStack_234 = (code *****)0x4;
      pppppcStack_23c = &local_7c;
      pppppcStack_238 = local_158;
      pppppcStack_240 = (code *****)0x4d0b15;
      pppppcStack_230 = (code *****)__vbaLateIdCallLd();
      pppppcStack_234 = (code *****)0x4d0b1b;
      iVar12 = __vbaI4Var();
      ppppppcVar7 = (code ******)pppppcStack_22c;
      ppppppcVar8 = (code ******)pppppcStack_220;
      if (SBORROW4(iVar12,1)) break;
      pppppcStack_218 = (code *****)0x4d0b2c;
      local_28 = __vbaI2I4();
      pppppcStack_218 = (code *****)0x4d0b38;
      __vbaFreeVar();
      if (1 < (short)local_28) {
        pppppcStack_218 = (code *****)0x0;
        pppppcStack_21c = (code *****)0x4;
        ppppcStack_224 = (code ****)&local_7c;
        pppppcStack_220 = local_158;
        pppppcStack_228 = (code *****)0x4d0b58;
        pppppcStack_218 = (code *****)__vbaLateIdCallLd();
        pppppcStack_21c = (code *****)0x4d0b5e;
        iVar12 = __vbaI4Var();
        ppppppcVar7 = (code ******)pppppcStack_22c;
        ppppppcVar8 = (code ******)pppppcStack_220;
        if (SBORROW4(iVar12,1)) break;
        local_ec = (code *****)0x3;
        local_10c = (code *****)0x3;
        ppppcStack_224 = (code ****)0x3;
        local_12c = (code ****)0x8;
        pppppcStack_220 = local_e8;
        local_104 = (code *****)&DAT_00000001;
        local_124 = L"Labels: ";
        pppppcStack_218 = local_e0;
        pppppcStack_234 = (code *****)0x3;
        pppppcStack_230 = local_108;
        pppppcStack_248 = (code *****)0x2;
        pppppcStack_24c = (code *****)0x41;
        pppppcStack_22c = (code *****)&DAT_00000001;
        pppppcStack_228 = local_100;
        pppppcStack_244 = (code *****)0x8;
        pppppcStack_240 = local_128;
        pppppcStack_23c = (code *****)0x413488;
        pppppcStack_238 = local_120;
        pppppcStack_250 = local_158;
        pppppcStack_254 = (code *****)0x4d0c14;
        pppppcStack_21c = (code *****)(iVar12 + -1);
        local_e4 = (code *****)(iVar12 + -1);
        __vbaLateIdCallSt();
        pppppcStack_218 = (code *****)0x4d0c20;
        __vbaFreeVar();
      }
      pppppcStack_218 = (code *****)0x4d0c30;
      __vbaStrCopy();
      if ((DAT_0050b1a0 == (code ******)0x0) || (*(short *)DAT_0050b1a0 != 2)) {
        pppppcStack_218 = (code *****)0x4d0c93;
        iVar12 = __vbaGenerateBoundsError();
      }
      else {
        pppppcVar1 = DAT_0050b1a0[7];
        if (DAT_0050b1a0[6] <= (code *****)(1U - (int)pppppcVar1)) {
          pppppcStack_218 = (code *****)0x4d0c57;
          __vbaGenerateBoundsError();
        }
        local_140 = (code ****)-(int)DAT_0050b1a0[5];
        if (DAT_0050b1a0[4] <= local_140) {
          pppppcStack_218 = (code *****)0x4d0c75;
          __vbaGenerateBoundsError();
        }
        iVar12 = (int)((int)(1U - (int)pppppcVar1) + (int)DAT_0050b1a0[6] * (int)local_140) * 2;
      }
      ppppppcVar19 = (code ******)__vbaStrCat_exref;
      local_28 = CONCAT22(local_28._2_2_,*(undefined2 *)((int)DAT_0050b1a0[3] + iVar12));
      local_18 = 1;
      uVar15 = local_18;
      goto LAB_004d0cb2;
    }
  }
LAB_004d266c:
  pppppcStack_220 = (code *****)ppppppcVar8;
  pppppcStack_22c = (code *****)ppppppcVar7;
  pppppcStack_218 = (code *****)0x4d2672;
  __vbaErrorOverflow();
  ppppcStack_224 = (code ****)&DAT_00402706;
  pppppcStack_228 = ExceptionList;
  pcStack_2b4 = pcVar5;
  pppppcStack_220 = (code *****)&pcStack_2b8;
  pppppcStack_21c = (code *****)&DAT_004023e8;
  pppppcStack_234 = (code *****)0x0;
  pppppcStack_238 = (code *****)0x0;
  pppppcStack_23c = (code *****)0x0;
  pppppcStack_260 = (code *****)0x0;
  pppppcStack_264 = (code *****)0x0;
  pppppcStack_268 = (code *****)0x0;
  pppppcStack_26c = (code *****)0x0;
  pppppcStack_290 = (code *****)0x0;
  ExceptionList = &pppppcStack_228;
  pcStack_2b8 = pcVar21;
  pppppcStack_2b0 = (code *****)ppppppcVar19;
  pppppcVar1 = (code *****)&pcStack_2b8;
  pppppcStack_218 = (code *****)&stack0xfffffffc;
  if (DAT_0050b420 == (int *)0x0) {
    ExceptionList = &pppppcStack_228;
    pppppcStack_218 = (code *****)&stack0xfffffffc;
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    pppppcVar1 = pppppcStack_220;
  }
  pppppcStack_220 = pppppcVar1;
  __vbaObjSetAddref(&pppppcStack_290,DAT_0050b420);
  uVar13 = (*(code *)(*pppppcStack_290)[0xdf])(pppppcStack_290);
  piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
  iVar12 = (**(code **)(*piVar11 + 0x9c))(piVar11,0);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_290)[0xd9])(pppppcStack_290);
  piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
  iVar12 = (**(code **)(*piVar11 + 0x9c))(piVar11,0xffffffff);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_290)[0xdb])(pppppcStack_290);
  piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
  iVar12 = (**(code **)(*piVar11 + 0x9c))(piVar11,0);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_290)[0xd3])(pppppcStack_290);
  piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
  iVar12 = (**(code **)(*piVar11 + 0x9c))(piVar11,0);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  uVar13 = (*(code *)(*pppppcStack_290)[0xda])(pppppcStack_290);
  piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
  iVar12 = (**(code **)(*piVar11 + 0xe8))(piVar11,&pppppcStack_260);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040dc58,0xe8);
  }
  bVar22 = (short)pppppcStack_260 == 0;
  __vbaFreeObj();
  ppppppcVar20 = (code ******)pppppcStack_240;
  ppppppcVar19 = (code ******)pppppcStack_248;
  if (bVar22) {
    uVar13 = (*(code *)(*pppppcStack_290)[0xda])(pppppcStack_290);
    puVar16 = (undefined4 *)__vbaObjSet(&pppppcStack_234,uVar13);
    ppppppcVar20 = (code ******)pppppcStack_240;
    ppppppcVar19 = (code ******)pppppcStack_248;
    pppppcStack_298 = (code *****)*puVar16;
    iVar12 = (*(code *)pppppcStack_298[0x7b])
                       (puVar16,L"Maximum flows",10,pppppcStack_248,0x80020004,pppppcStack_240);
    if (iVar12 < 0) {
      __vbaHresultCheckObj(iVar12,puVar16,&DAT_0040dc58,0x1ec);
    }
    __vbaFreeObj();
    uVar13 = (*(code *)(*pppppcStack_290)[0xda])(pppppcStack_290);
    piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
    pppppcStack_244 = (code *****)0x80020004;
    iVar12 = (**(code **)(*piVar11 + 0x1ec))
                       (piVar11,L"Iterations",10,ppppppcVar19,0x80020004,ppppppcVar20);
    if (iVar12 < 0) {
      __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040dc58,0x1ec);
    }
    __vbaFreeObj();
  }
  uVar13 = (*(code *)(*pppppcStack_290)[0xea])
                     (pppppcStack_290,0x80010007,0xb,ppppppcVar19,0,ppppppcVar20);
  uVar13 = __vbaObjSet(&pppppcStack_234,uVar13);
  __vbaLateIdSt(uVar13);
  __vbaFreeObj();
  iVar12 = (*(code *)(*pppppcStack_290)[0x92])(pppppcStack_290,&pppppcStack_234);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_234,0,8,ppppppcVar19,L"arial",ppppppcVar20);
  __vbaFreeObj();
  iVar12 = (*(code *)(*pppppcStack_290)[0x92])(pppppcStack_290,&pppppcStack_234);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_234,2,2,ppppppcVar19,6,ppppppcVar20);
  __vbaFreeObj();
  iVar12 = (*(code *)(*pppppcStack_290)[0x1b])(pppppcStack_290,0xffffff);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x6c);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  __vbaObjSetAddref(&pppppcStack_234,DAT_0050b420);
  FUN_0048c990(&pppppcStack_234);
  uVar13 = __vbaCastObj(pppppcStack_234,&DAT_0040b85c);
  __vbaObjSet(&DAT_0050b420,uVar13);
  __vbaFreeObj();
  iVar12 = (*(code *)(*pppppcStack_290)[0x92])(pppppcStack_290,&pppppcStack_234);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_234,3,0xb,ppppppcVar19,0xffffffff,ppppppcVar20);
  __vbaFreeObj();
  pppppcStack_244 = (code *****)0xa;
  iVar12 = (*(code *)(*pppppcStack_290)[0x92])(pppppcStack_290,&pppppcStack_234);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_234,2,2,ppppppcVar19,pppppcStack_244,ppppppcVar20);
  __vbaFreeObj();
  pppppcStack_24c = (code *****)0xb;
  iVar12 = (*(code *)(*pppppcStack_290)[0x92])(pppppcStack_290,&pppppcStack_234);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppcStack_234,3,pppppcStack_24c,ppppppcVar19,0xffffffff,ppppppcVar20);
  __vbaFreeObj();
  iVar12 = (*(code *)(*pppppcStack_290)[0x4b])(pppppcStack_290,1);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,300);
  }
  __vbaStrCopy();
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar11 = DAT_0050c53c;
  iVar12 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_234);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040b410,0x18);
  }
  pppppcVar1 = pppppcStack_234;
  iVar12 = (*(code *)(*pppppcStack_234)[0x26])(pppppcStack_234,&pppppcStack_264);
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcVar1,&DAT_0040bb5c,0x98);
  }
  iVar12 = (*(code *)(*pppppcStack_290)[0xb9])(pppppcStack_290,DAT_0050b34c,&pppppcStack_268);
  uVar23 = 0;
  if (iVar12 < 0) {
    __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0x2e4);
  }
  if ((uVar23 & 0xd) == 0) {
    ppppppcVar19 = (code ******)
                   (((float)pppppcStack_264 - (float)pppppcStack_268) * (float)_DAT_00401268);
    if ((uVar23 & 0xd) == 0) {
      pppppcStack_29c = (code *****)ppppppcVar19;
      iVar12 = (*(code *)(*pppppcStack_290)[0x39])(pppppcStack_290,ppppppcVar19);
      if (iVar12 < 0) {
        __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0xe4);
      }
      __vbaFreeObj();
      if (DAT_0050b420 == (int *)0x0) {
        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      }
      __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,DAT_0050b34c);
      iVar12 = (*(code *)(*pppppcStack_290)[0x3a])(pppppcStack_290,&pppppcStack_264);
      if (iVar12 < 0) {
        __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0xe8);
      }
      if (DAT_0050c53c == (int *)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      piVar11 = DAT_0050c53c;
      iVar12 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_234);
      if (iVar12 < 0) {
        __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040b410,0x18);
      }
      pppppcVar1 = pppppcStack_234;
      iVar12 = (*(code *)(*pppppcStack_234)[0x26])(pppppcStack_234,&pppppcStack_268);
      if (iVar12 < 0) {
        __vbaHresultCheckObj(iVar12,pppppcVar1,&DAT_0040bb5c,0x98);
      }
      iVar12 = (*(code *)(*pppppcStack_290)[0x3a])(pppppcStack_290,&pppppcStack_26c);
      uVar23 = 0;
      if (iVar12 < 0) {
        __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0xe8);
      }
      if (DAT_0050b420 == (int *)0x0) {
        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      }
      piVar11 = DAT_0050b420;
      if ((uVar23 & 0xd) == 0) {
        iVar12 = (**(code **)(*DAT_0050b420 + 0x2c8))
                           (DAT_0050b420,4,0x44960000,pppppcStack_264,
                            (float)pppppcStack_268 - _DAT_004020e0,pppppcStack_26c,0);
        if (iVar12 < 0) {
          __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040b430,0x2c8);
        }
        __vbaFreeObj();
        iVar12 = (*(code *)(*pppppcStack_290)[0x3a])(pppppcStack_290,&pppppcStack_264);
        uVar23 = 0;
        if (iVar12 < 0) {
          __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0xe8);
        }
        uVar13 = (*(code *)(*pppppcStack_290)[0xd9])(pppppcStack_290);
        piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
        puVar24 = (undefined *)((float)pppppcStack_264 * (float)_DAT_00401280);
        if ((uVar23 & 0xd) == 0) {
          puStack_2a0 = puVar24;
          iVar12 = (**(code **)(*piVar11 + 0x7c))(piVar11,puVar24);
          if (iVar12 < 0) {
            __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x7c);
          }
          __vbaFreeObj();
          if (DAT_0050c53c == (int *)0x0) {
            __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
          }
          piVar11 = DAT_0050c53c;
          iVar12 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_234);
          if (iVar12 < 0) {
            __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040b410,0x18);
          }
          pppppcVar1 = pppppcStack_234;
          iVar12 = (*(code *)(*pppppcStack_234)[0x26])(pppppcStack_234,&pppppcStack_264);
          if (iVar12 < 0) {
            __vbaHresultCheckObj(iVar12,pppppcVar1,&DAT_0040bb5c,0x98);
          }
          uVar13 = (*(code *)(*pppppcStack_290)[0xd9])(pppppcStack_290);
          piVar11 = (int *)__vbaObjSet(&pppppcStack_238,uVar13);
          iVar12 = (**(code **)(*piVar11 + 0x80))(piVar11,&pppppcStack_268);
          uVar23 = 0;
          if (iVar12 < 0) {
            __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x80);
          }
          uVar13 = (*(code *)(*pppppcStack_290)[0xd9])(pppppcStack_290);
          piVar11 = (int *)__vbaObjSet(&pppppcStack_23c,uVar13);
          if ((uVar23 & 0xd) == 0) {
            ppppppcVar19 = (code ******)
                           (((float)pppppcStack_264 - (float)pppppcStack_268) * (float)_DAT_00401268
                           );
            if ((uVar23 & 0xd) == 0) {
              pppppcStack_2a4 = (code *****)ppppppcVar19;
              iVar12 = (**(code **)(*piVar11 + 0x74))(piVar11,puVar24,ppppppcVar19);
              if (iVar12 < 0) {
                __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x74);
              }
              __vbaFreeObjList(3,&pppppcStack_234,&pppppcStack_238,&pppppcStack_23c);
              iVar12 = (*(code *)(*pppppcStack_290)[0x3a])(pppppcStack_290,&pppppcStack_264);
              uVar23 = 0;
              if (iVar12 < 0) {
                __vbaHresultCheckObj(iVar12,pppppcStack_290,&DAT_0040b430,0xe8);
              }
              if ((uVar23 & 0xd) == 0) {
                DAT_0050b32e = __vbaFpI2();
                __vbaObjSetAddref(&pppppcStack_290,0);
                if (DAT_0050c53c == (int *)0x0) {
                  __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                }
                piVar11 = DAT_0050c53c;
                iVar12 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_234);
                if (iVar12 < 0) {
                  __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040b410,0x18);
                }
                pppppcVar1 = pppppcStack_234;
                iVar12 = (*(code *)(*pppppcStack_234)[0x14])(pppppcStack_234,&pppppcStack_264);
                uVar23 = 0;
                if (iVar12 < 0) {
                  __vbaHresultCheckObj(iVar12,pppppcVar1,&DAT_0040bb5c,0x50);
                }
                if (DAT_0050b420 == (int *)0x0) {
                  __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                }
                uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                piVar11 = (int *)__vbaObjSet(&pppppcStack_238,uVar13);
                ppppppcVar19 = (code ******)((float)pppppcStack_264 * (float)_DAT_00401730);
                if ((uVar23 & 0xd) == 0) {
                  pppppcStack_2a8 = (code *****)ppppppcVar19;
                  iVar12 = (**(code **)(*piVar11 + 0x7c))(piVar11,ppppppcVar19);
                  if (iVar12 < 0) {
                    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x7c);
                  }
                  __vbaFreeObjList(2,&pppppcStack_234,&pppppcStack_238);
                  if (DAT_0050c53c == (int *)0x0) {
                    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                  }
                  piVar11 = DAT_0050c53c;
                  iVar12 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppcStack_234);
                  if (iVar12 < 0) {
                    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040b410,0x18);
                  }
                  pppppcVar1 = pppppcStack_234;
                  iVar12 = (*(code *)(*pppppcStack_234)[0x26])(pppppcStack_234,&pppppcStack_264);
                  if (iVar12 < 0) {
                    __vbaHresultCheckObj(iVar12,pppppcVar1,&DAT_0040bb5c,0x98);
                  }
                  if (DAT_0050b420 == (int *)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                  piVar11 = (int *)__vbaObjSet(&pppppcStack_238,uVar13);
                  iVar12 = (**(code **)(*piVar11 + 0x80))(piVar11,&pppppcStack_268);
                  uVar23 = 0;
                  if (iVar12 < 0) {
                    __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x80);
                  }
                  if (DAT_0050b420 == (int *)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                  piVar11 = (int *)__vbaObjSet(&pppppcStack_23c,uVar13);
                  if ((uVar23 & 0xd) == 0) {
                    fVar3 = ((float)pppppcStack_264 - (float)pppppcStack_268) * (float)_DAT_00401268
                    ;
                    if ((uVar23 & 0xd) == 0) {
                      puStack_2ac = (undefined4 *)fVar3;
                      iVar12 = (**(code **)(*piVar11 + 0x74))(piVar11,ppppppcVar19,fVar3);
                      if (iVar12 < 0) {
                        __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x74);
                      }
                      __vbaFreeObjList(3,&pppppcStack_234,&pppppcStack_238,&pppppcStack_23c);
                      if (DAT_0050b420 == (int *)0x0) {
                        __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                      }
                      uVar13 = (**(code **)(*DAT_0050b420 + 0x37c))(DAT_0050b420);
                      piVar11 = (int *)__vbaObjSet(&pppppcStack_234,uVar13);
                      iVar12 = (**(code **)(*piVar11 + 0x9c))(piVar11,0xffffffff);
                      if (iVar12 < 0) {
                        __vbaHresultCheckObj(iVar12,piVar11,&DAT_0040c3dc,0x9c);
                      }
                      __vbaFreeObj();
                      __vbaFreeObj(&LAB_004d3292);
                      return;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  __vbaFPException();
  return;
}


