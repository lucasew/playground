/* entry 00444410 name FUN_00444410 size 235 */

void FUN_00444410(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 local_58 [6];
  undefined4 local_40;
  undefined4 local_38;
  undefined4 local_34 [4];
  undefined4 local_24 [4];
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff98;
  local_8 = &DAT_00401c58;
  local_24[0] = 0;
  local_34[0] = 0;
  local_58[0] = 0;
  ExceptionList = &pvStack_14;
  __vbaObjSetAddref(local_58,*param_1);
  __vbaLateMemCall(local_58[0],L"SetFocus",0);
  __vbaLateMemSt(local_58[0],L"SelStart",2,local_40,0,local_38);
  uVar1 = __vbaLateMemCallLd(local_24,local_58[0],L"Text",0);
  puVar2 = (undefined4 *)__vbaLenVar(local_34,uVar1);
  __vbaLateMemSt(local_58[0],L"SelLength",*puVar2,puVar2[1],puVar2[2],puVar2[3]);
  __vbaFreeVar();
  __vbaObjSetAddref(local_58,0);
  __vbaFreeObj(&LAB_0044450f);
  return;
}


