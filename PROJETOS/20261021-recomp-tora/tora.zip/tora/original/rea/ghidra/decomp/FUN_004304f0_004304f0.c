/* entry 004304f0 name FUN_004304f0 size 5417 */
/* strings:
 * Dual Simplex not applicable directly.  All-slack will be used
 *  Dual simplex not applicable directly.  Two-phase method will be used; else click CANCEL to use M-method
 * Dual SImplex Error
 *  Dual simplex not applicable because a var has upper/lower bound or is unrestricted.  Two-phase method will be used; else click CANCEL to use M-method
 * Equations must be converted to inequalities before applying Dual Simplex
 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004304f0(uint param_1)

{
  int iVar1;
  bool bVar2;
  code *pcVar3;
  undefined4 uVar4;
  int *******pppppppiVar5;
  int *******pppppppiVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  int *******pppppppiVar10;
  undefined4 *puVar11;
  short *psVar12;
  wchar_t wVar13;
  short sVar14;
  short sVar15;
  undefined2 extraout_var;
  undefined2 uVar16;
  short sVar17;
  code *pcVar18;
  code *pcVar19;
  wchar_t wVar20;
  uint uVar21;
  undefined4 uVar22;
  int ******ppppppiVar23;
  undefined1 uVar24;
  ushort uVar25;
  float10 fVar26;
  int *******pppppppiStack_364;
  int *******pppppppiStack_360;
  int *******pppppppiStack_35c;
  int *******pppppppiStack_358;
  int *******pppppppiStack_354;
  int *******pppppppiStack_350;
  int *******pppppppiStack_34c;
  int ******ppppppiStack_348;
  int *******pppppppiStack_344;
  int *******pppppppiStack_340;
  int ******ppppppiStack_33c;
  int *******pppppppiStack_338;
  undefined1 *puStack_334;
  int *******pppppppiStack_330;
  int *****pppppiStack_32c;
  int *******pppppppiStack_328;
  code *pcStack_324;
  int *piStack_320;
  int ******ppppppiStack_31c;
  undefined *puStack_318;
  int *******pppppppiStack_314;
  int *piStack_310;
  undefined4 uStack_30c;
  int *piStack_308;
  code *pcStack_304;
  int ******ppppppiStack_300;
  float fStack_2fc;
  int *******apppppppiStack_2f0 [7];
  float fStack_2d4;
  int ******appppppiStack_2d0 [9];
  undefined4 uStack_2ac;
  int *******pppppppiStack_2a8;
  wchar_t *pwStack_2a4;
  int *******pppppppiStack_2a0;
  undefined4 uStack_29c;
  int *******pppppppiStack_298;
  wchar_t *pwStack_294;
  int *******pppppppiStack_290;
  int ****appppiStack_28c [2];
  undefined4 uStack_284;
  int *****apppppiStack_27c [2];
  undefined4 uStack_274;
  undefined4 uStack_26c;
  int iStack_268;
  int ******ppppppiStack_264;
  undefined *puStack_260;
  undefined4 uStack_25c;
  int *piStack_258;
  int *******pppppppiStack_254;
  int *******pppppppiStack_250;
  int ******ppppppiStack_24c;
  int *******pppppppiStack_248;
  int *******pppppppiStack_244;
  undefined1 *puStack_240;
  int *piStack_23c;
  int *****pppppiStack_238;
  int *****pppppiStack_234;
  int *piStack_230;
  int *piStack_22c;
  int *******pppppppiStack_228;
  undefined *puStack_224;
  int *******pppppppiStack_220;
  int *piStack_21c;
  code *pcStack_218;
  int *******pppppppiStack_214;
  code *pcStack_210;
  undefined4 uStack_204;
  undefined4 uStack_1d4;
  undefined4 uStack_1d0;
  wchar_t *pwStack_1cc;
  int ****ppppiStack_1c8;
  undefined4 uStack_1c4;
  int ******ppppppiStack_1c0;
  wchar_t *pwStack_1bc;
  undefined4 uStack_1b8;
  int *****apppppiStack_1b4 [2];
  undefined4 uStack_1ac;
  int *****apppppiStack_1a4 [2];
  undefined4 uStack_19c;
  undefined4 uStack_194;
  undefined4 uStack_190;
  int ******ppppppiStack_18c;
  int ******ppppppiStack_188;
  int *******pppppppiStack_184;
  int *******pppppppiStack_180;
  int *******pppppppiStack_17c;
  int *******pppppppiStack_178;
  int *******pppppppiStack_174;
  int *******pppppppiStack_170;
  int *******pppppppiStack_16c;
  int *******pppppppiStack_168;
  int *******pppppppiStack_164;
  int *******pppppppiStack_160;
  int *******pppppppiStack_15c;
  int *******pppppppiStack_158;
  int *******pppppppiStack_154;
  int *piStack_150;
  int *******pppppppiStack_14c;
  undefined *puStack_148;
  int *******pppppppiStack_144;
  int *******pppppppiStack_140;
  int *******local_d8;
  int *******local_d4 [7];
  int ******local_b8;
  int ******local_b4 [9];
  undefined4 local_90;
  int *******local_8c;
  wchar_t *local_88;
  int *******local_84;
  int ******local_80;
  int *******local_7c;
  wchar_t *local_78;
  int ******local_74;
  int ******local_70 [2];
  undefined4 local_68;
  int ******local_60 [2];
  undefined4 local_58;
  int ******local_50 [4];
  int ******local_40 [4];
  int *******local_30;
  undefined4 local_2c;
  int ******local_28;
  undefined4 local_24;
  wchar_t local_20 [2];
  int *******local_1c;
  void *pvStack_18;
  undefined *puStack_14;
  undefined1 *local_10;
  undefined *local_c;
  uint local_8;
  
  puStack_14 = &DAT_00402706;
  pvStack_18 = ExceptionList;
  local_10 = &stack0xfffffec4;
  local_c = &DAT_00401888;
  local_8 = param_1 & 1;
  pppppppiVar10 = (int *******)(param_1 & 0xfffffffe);
  pppppppiStack_144 = (int *******)0x430532;
  ExceptionList = &pvStack_18;
  pppppppiStack_140 = pppppppiVar10;
  (*(code *)(*pppppppiVar10)[1])();
  local_20[0] = L'\0';
  local_20[1] = L'\0';
  local_28 = (int ******)0x0;
  local_2c = 0;
  local_30 = (int *******)0x0;
  local_40[0] = (int ******)0x0;
  local_50[0] = (int ******)0x0;
  local_60[0] = (int ******)0x0;
  local_70[0] = (int ******)0x0;
  local_80 = (int ******)0x0;
  local_90 = 0;
  local_b4[0] = (int ******)0x0;
  local_b8 = (int ******)0x0;
  local_d4[0] = (int *******)0x0;
  local_d8 = (int *******)0x0;
  if (DAT_0050b46c == (int *******)0x0) {
    pppppppiStack_144 = (int *******)&DAT_0050b46c;
    puStack_148 = &DAT_004068ac;
    pppppppiStack_14c = (int *******)0x430586;
    __vbaNew2();
  }
  pppppppiStack_144 = DAT_0050b46c;
  puStack_148 = (undefined *)0x430594;
  puStack_148 = (undefined *)(*(code *)(*DAT_0050b46c)[199])();
  pppppppiStack_14c = (int *******)&local_30;
  piStack_150 = (int *)0x43059f;
  pppppppiVar5 = (int *******)__vbaObjSet();
  piStack_150 = (int *)0x0;
  pppppppiStack_158 = (int *******)0x4305ab;
  pppppppiStack_154 = pppppppiVar5;
  pppppppiVar6 = (int *******)(*(code *)(*pppppppiVar5)[0x27])();
  uVar25 = 0;
  if ((int)pppppppiVar6 < 0) {
    pppppppiStack_158 = (int *******)0x9c;
    pppppppiStack_15c = (int *******)&DAT_0040ba5c;
    pppppppiStack_168 = (int *******)0x4305c3;
    pppppppiStack_164 = pppppppiVar6;
    pppppppiStack_160 = pppppppiVar5;
    __vbaHresultCheckObj();
  }
  pppppppiStack_158 = (int *******)0x4305cc;
  __vbaFreeObj();
  wVar13 = DAT_0050b20a;
  pcVar19 = __vbaGenerateBoundsError_exref;
  DAT_0050b272 = 2;
  local_20[0] = L'\x01';
  uVar16 = extraout_var;
  wVar20 = local_20[0];
  do {
    local_20[0] = wVar20;
    local_20[1] = 0;
    if (wVar13 < local_20[0]) {
      if (0 < DAT_0050b248) {
        local_68 = 0x80020004;
        local_58 = 0x80020004;
        local_70[0] = (int ******)0xa;
        local_60[0] = (int ******)0xa;
        local_88 = L"Dual SImplex Error";
        local_90 = 8;
        pppppppiStack_158 = (int *******)0x431097;
        __vbaVarDup();
        local_78 = L"Equations must be converted to inequalities before applying Dual Simplex";
        local_80 = (int ******)0x8;
        pppppppiStack_158 = (int *******)0x4310a9;
        __vbaVarDup();
        pppppppiStack_158 = local_70;
        pppppppiStack_15c = local_60;
        pppppppiStack_160 = local_50;
        pppppppiStack_168 = local_40;
        pppppppiStack_164 = (int *******)0x0;
        pppppppiStack_16c = (int *******)0x4310c1;
        Ordinal_595();
        pppppppiStack_16c = local_70;
        pppppppiStack_170 = local_60;
        pppppppiStack_174 = local_50;
        pppppppiStack_178 = local_40;
        pppppppiStack_17c = (int *******)0x4;
        pppppppiStack_180 = (int *******)0x4310d9;
        __vbaFreeVarList();
        if (DAT_0050c53c == (int *******)0x0) {
          pppppppiStack_16c = (int *******)&DAT_0050c53c;
          pppppppiStack_170 = (int *******)&DAT_0040b420;
          pppppppiStack_174 = (int *******)0x4310f5;
          __vbaNew2();
        }
        pppppppiVar5 = DAT_0050c53c;
        pppppppiStack_170 = (int *******)&local_30;
        ppppppiVar23 = *DAT_0050c53c;
        pppppppiStack_174 = (int *******)0x43110b;
        pppppppiStack_16c = pppppppiVar10;
        pppppppiStack_174 = (int *******)__vbaObjSetAddref();
        pppppppiStack_178 = pppppppiVar5;
        pppppppiStack_17c = (int *******)0x431110;
        ppppppiVar23 = (int ******)(*(code *)ppppppiVar23[4])();
        if ((int)ppppppiVar23 < 0) {
          pppppppiStack_17c = (int *******)0x10;
          pppppppiStack_180 = (int *******)&DAT_0040b410;
          pppppppiStack_184 = pppppppiVar5;
          ppppppiStack_18c = (int ******)0x431125;
          ppppppiStack_188 = ppppppiVar23;
          __vbaHresultCheckObj();
        }
        pppppppiStack_17c = (int *******)0x43112e;
        __vbaFreeObj();
        pppppppiStack_174 = (int *******)0x431133;
        FUN_00444530();
        goto LAB_004319de;
      }
      DAT_0050b274 = 5;
      sVar14 = DAT_0050b20c + 2;
      local_1c = (int *******)0x3;
      pcVar18 = (code *)0x0;
      pppppppiVar5 = (int *******)0x3;
      pppppppiVar10 = local_1c;
      if (!SCARRY2(DAT_0050b20c,2)) goto LAB_00431163;
      break;
    }
    if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
      pppppppiStack_158 = (int *******)0x430652;
      __vbaGenerateBoundsError();
    }
    else {
      if (*(uint *)(DAT_0050b0cc + 0xc) <= 2U - *(int *)(DAT_0050b0cc + 0xe)) {
        pppppppiStack_158 = (int *******)0x430621;
        __vbaGenerateBoundsError();
      }
      pppppppiVar5 = (int *******)((int)local_20[0] - *(int *)(DAT_0050b0cc + 10));
      if (*(int ********)(DAT_0050b0cc + 8) <= pppppppiVar5) {
        pppppppiStack_158 = (int *******)0x43063b;
        __vbaGenerateBoundsError();
      }
    }
    pcVar18 = (code *)0x0;
    if ((uVar25 & 0xd) != 0) goto LAB_00431a5e;
    pppppppiStack_158 = (int *******)0x43068d;
    fVar26 = (float10)__vbaFpR8();
    if (fVar26 < (float10)_DAT_00401490) {
      pcVar19 = (code *)0x80020004;
      pcVar18 = (code *)0xa;
      pppppppiVar5 = (int *******)0x8;
      local_68 = 0x80020004;
      if (SCARRY2(DAT_0050b246,DAT_0050b248)) break;
      local_70[0] = (int ******)0xa;
      local_58 = 0x80020004;
      local_60[0] = (int ******)0xa;
      local_88 = L"Warning";
      local_90 = 8;
      if ((short)(DAT_0050b246 + DAT_0050b248) == 0) {
        pppppppiStack_158 = (int *******)0x4307a5;
        __vbaVarDup();
        local_78 = L"Dual Simplex not applicable directly.  All-slack will be used";
        local_80 = (int ******)0x8;
        pppppppiStack_158 = (int *******)0x4307bb;
        __vbaVarDup();
        pppppppiStack_158 = local_70;
        pppppppiStack_15c = local_60;
        pppppppiStack_160 = local_50;
        pppppppiStack_168 = local_40;
        pppppppiStack_164 = (int *******)0x10;
        pppppppiStack_16c = (int *******)0x4307d3;
        Ordinal_595();
        pppppppiStack_16c = local_70;
        pppppppiStack_170 = local_60;
        pppppppiStack_174 = local_50;
        pppppppiStack_178 = local_40;
        pppppppiStack_17c = (int *******)0x4;
        pppppppiStack_180 = (int *******)0x4307eb;
        __vbaFreeVarList();
        DAT_0050b274 = 2;
        uVar24 = SCARRY2(DAT_0050b20c,DAT_0050b20a);
        sVar14 = DAT_0050b20c + DAT_0050b20a;
      }
      else {
        pppppppiStack_158 = (int *******)0x430846;
        __vbaVarDup();
        local_78 = 
        L" Dual simplex not applicable directly.  Two-phase method will be used; else click CANCEL to use M-method"
        ;
        local_80 = (int ******)0x8;
        pppppppiStack_158 = (int *******)0x43085c;
        __vbaVarDup();
        pppppppiStack_158 = local_70;
        pppppppiStack_15c = local_60;
        pppppppiStack_160 = local_50;
        pppppppiStack_168 = local_40;
        pppppppiStack_164 = (int *******)0x11;
        pppppppiStack_16c = (int *******)0x430874;
        iVar7 = Ordinal_595();
        pppppppiStack_16c = local_70;
        pppppppiVar5 = (int *******)(uint)(ushort)-(ushort)(iVar7 == 2);
        pppppppiStack_170 = local_60;
        pppppppiStack_174 = local_50;
        pppppppiStack_178 = local_40;
        pppppppiStack_17c = (int *******)0x4;
        pppppppiStack_180 = (int *******)0x430899;
        __vbaFreeVarList();
        if ((ushort)-(ushort)(iVar7 == 2) != 0) {
          DAT_0050b274 = 3;
          if ((((!SCARRY2(DAT_0050b20c,DAT_0050b20a)) &&
               (sVar14 = DAT_0050b20c + DAT_0050b20a + DAT_0050b246,
               !SCARRY2(DAT_0050b20c + DAT_0050b20a,DAT_0050b246))) &&
              (sVar15 = sVar14 + 2, !SCARRY2(sVar14,2))) &&
             (DAT_0050b278 = sVar15, !SCARRY2(DAT_0050b20c,7))) {
            DAT_0050b276 = DAT_0050b20c + 7;
            if (DAT_0050b46c == (int *******)0x0) {
              pppppppiStack_158 = (int *******)&DAT_0050b46c;
              pppppppiStack_15c = (int *******)&DAT_004068ac;
              pppppppiStack_160 = (int *******)0x43090b;
              __vbaNew2();
            }
            pppppppiStack_158 = DAT_0050b46c;
            pppppppiStack_15c = (int *******)0x430919;
            pppppppiStack_15c = (int *******)(*(code *)(*DAT_0050b46c)[0xc3])();
            pppppppiStack_160 = (int *******)local_d4;
            pppppppiStack_164 = (int *******)0x430927;
            __vbaObjSet();
            pppppppiStack_164 = (int *******)0xffffffff;
            pppppppiStack_168 = local_d4[0];
            pppppppiStack_16c = (int *******)0x430938;
            pppppppiVar10 = (int *******)(*(code *)(*local_d4[0])[0x27])();
            if ((int)pppppppiVar10 < 0) {
              pppppppiStack_16c = (int *******)0x9c;
              pppppppiStack_170 = (int *******)&DAT_0040c3dc;
              pppppppiStack_174 = local_d4[0];
              pppppppiStack_17c = (int *******)0x430958;
              pppppppiStack_178 = pppppppiVar10;
              __vbaHresultCheckObj();
            }
            if (DAT_0050c53c == (int *******)0x0) {
              pppppppiStack_16c = (int *******)&DAT_0050c53c;
              pppppppiStack_170 = (int *******)&DAT_0040b420;
              pppppppiStack_174 = (int *******)0x430979;
              __vbaNew2();
            }
            pppppppiVar10 = DAT_0050c53c;
            pppppppiStack_16c = (int *******)&local_30;
            pppppppiStack_170 = DAT_0050c53c;
            pppppppiStack_174 = (int *******)0x430989;
            pppppppiVar5 = (int *******)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)pppppppiVar5 < 0) {
              pppppppiStack_174 = (int *******)0x18;
              pppppppiStack_178 = (int *******)&DAT_0040b410;
              pppppppiStack_17c = pppppppiVar10;
              pppppppiStack_184 = (int *******)0x43099a;
              pppppppiStack_180 = pppppppiVar5;
              __vbaHresultCheckObj();
            }
            pppppppiVar10 = local_30;
            pppppppiStack_174 = local_b4;
            pppppppiStack_178 = local_30;
            pppppppiStack_17c = (int *******)0x4309ac;
            ppppppiVar23 = (int ******)(*(code *)(*local_30)[0x14])();
            if ((int)ppppppiVar23 < 0) {
              pppppppiStack_17c = (int *******)0x50;
              pppppppiStack_180 = (int *******)&DAT_0040bb5c;
              pppppppiStack_184 = pppppppiVar10;
              ppppppiStack_18c = (int ******)0x4309bd;
              ppppppiStack_188 = ppppppiVar23;
              __vbaHresultCheckObj();
            }
            pppppppiStack_17c = &local_b8;
            pppppppiStack_180 = local_d4[0];
            pppppppiStack_184 = (int *******)0x4309d3;
            pppppppiVar10 = (int *******)(*(code *)(*local_d4[0])[0x22])();
            uVar25 = 0;
            if ((int)pppppppiVar10 < 0) {
              pppppppiStack_154 = (int *******)0x88;
              pppppppiStack_158 = (int *******)&DAT_0040c3dc;
              pppppppiStack_15c = local_d4[0];
              pppppppiStack_164 = (int *******)0x4309ed;
              pppppppiStack_160 = pppppppiVar10;
              __vbaHresultCheckObj();
            }
            pppppppiStack_154 = local_d4[0];
            if ((uVar25 & 0xd) == 0) {
              pppppppiStack_158 = local_d4[0];
              pppppppiStack_15c = (int *******)0x430a2d;
              pppppppiStack_154 =
                   (int *******)
                   ((float)local_b4[0] * (float)_DAT_00401858 -
                   (float)local_b8 * (float)_DAT_00401268);
              pppppppiVar10 = (int *******)(*(code *)(*local_d4[0])[0x1f])();
              if ((int)pppppppiVar10 < 0) {
                pppppppiStack_15c = (int *******)0x7c;
                pppppppiStack_160 = (int *******)&DAT_0040c3dc;
                pppppppiStack_164 = local_d4[0];
                pppppppiStack_16c = (int *******)0x430a44;
                pppppppiStack_168 = pppppppiVar10;
                __vbaHresultCheckObj();
              }
              pcVar19 = __vbaFreeObj_exref;
              pppppppiStack_15c = (int *******)0x430a4f;
              __vbaFreeObj();
              if (DAT_0050c53c == (int *******)0x0) {
                pppppppiStack_15c = (int *******)&DAT_0050c53c;
                pppppppiStack_160 = (int *******)&DAT_0040b420;
                pppppppiStack_164 = (int *******)0x430a68;
                __vbaNew2();
              }
              pppppppiVar10 = DAT_0050c53c;
              pppppppiStack_15c = (int *******)&local_30;
              pppppppiStack_160 = DAT_0050c53c;
              pppppppiStack_164 = (int *******)0x430a78;
              pppppppiVar5 = (int *******)(*(code *)(*DAT_0050c53c)[6])();
              if ((int)pppppppiVar5 < 0) {
                pppppppiStack_164 = (int *******)0x18;
                pppppppiStack_168 = (int *******)&DAT_0040b410;
                pppppppiStack_16c = pppppppiVar10;
                pppppppiStack_174 = (int *******)0x430a89;
                pppppppiStack_170 = pppppppiVar5;
                __vbaHresultCheckObj();
              }
              pppppppiVar10 = local_30;
              pppppppiStack_164 = local_b4;
              pppppppiStack_168 = local_30;
              pppppppiStack_16c = (int *******)0x430a9e;
              pppppppiVar5 = (int *******)(*(code *)(*local_30)[0x26])();
              if ((int)pppppppiVar5 < 0) {
                pppppppiStack_16c = (int *******)0x98;
                pppppppiStack_170 = (int *******)&DAT_0040bb5c;
                pppppppiStack_174 = pppppppiVar10;
                pppppppiStack_17c = (int *******)0x430ab2;
                pppppppiStack_178 = pppppppiVar5;
                __vbaHresultCheckObj();
              }
              pppppppiStack_16c = &local_b8;
              pppppppiStack_170 = local_d4[0];
              pppppppiStack_174 = (int *******)0x430ac8;
              pppppppiVar10 = (int *******)(*(code *)(*local_d4[0])[0x20])();
              uVar25 = 0;
              if ((int)pppppppiVar10 < 0) {
                pppppppiStack_154 = (int *******)0x80;
                pppppppiStack_158 = (int *******)&DAT_0040c3dc;
                pppppppiStack_15c = local_d4[0];
                pppppppiStack_164 = (int *******)0x430ae2;
                pppppppiStack_160 = pppppppiVar10;
                __vbaHresultCheckObj();
              }
              pppppppiStack_154 = local_d4[0];
              if ((uVar25 & 0xd) == 0) {
                pppppppiStack_158 = local_d4[0];
                pppppppiStack_15c = (int *******)0x430b22;
                pppppppiStack_154 =
                     (int *******)
                     ((float)local_b4[0] * (float)_DAT_00401268 -
                     (float)local_b8 * (float)_DAT_00401268);
                pppppppiVar10 = (int *******)(*(code *)(*local_d4[0])[0x1d])();
                if ((int)pppppppiVar10 < 0) {
                  pppppppiStack_15c = (int *******)0x74;
                  pppppppiStack_160 = (int *******)&DAT_0040c3dc;
                  pppppppiStack_164 = local_d4[0];
                  pppppppiStack_16c = (int *******)0x430b39;
                  pppppppiStack_168 = pppppppiVar10;
                  __vbaHresultCheckObj();
                }
                pppppppiStack_15c = (int *******)0x430b3e;
                __vbaFreeObj();
                pppppppiStack_160 = (int *******)local_d4;
                pppppppiStack_15c = (int *******)0x0;
                pppppppiStack_164 = (int *******)0x430b4d;
                __vbaObjSetAddref();
                goto joined_r0x00430b54;
              }
            }
            goto LAB_00431a5e;
          }
          break;
        }
        DAT_0050b274 = 4;
        DAT_0050b240 = 1;
        if (SCARRY2(DAT_0050b20c,DAT_0050b20a)) break;
        uVar24 = SCARRY2(DAT_0050b20c + DAT_0050b20a,DAT_0050b246);
        sVar14 = DAT_0050b20c + DAT_0050b20a + DAT_0050b246;
      }
joined_r0x00430807:
      pcVar18 = (code *)0xa;
      pcVar19 = (code *)0x80020004;
      if (!(bool)uVar24) {
        pcVar18 = (code *)0xa;
        pcVar19 = (code *)0x80020004;
        if (!SCARRY2(sVar14,2)) {
          DAT_0050b278 = sVar14 + 2;
          pcVar18 = (code *)0xa;
          pcVar19 = (code *)0x80020004;
          if (!SCARRY2(DAT_0050b20c,7)) {
            DAT_0050b276 = DAT_0050b20c + 7;
            if (DAT_0050b40c == (int ******)0x0) {
              pppppppiStack_158 = &DAT_0050b40c;
              pppppppiStack_15c = (int *******)&DAT_00403f84;
              pppppppiStack_160 = (int *******)0x430fe8;
              __vbaNew2();
            }
            ppppppiVar23 = DAT_0050b40c;
            local_80 = (int ******)0xa;
            local_90 = 10;
            pppppppiStack_164 = (int *******)0xa;
            local_88 = (wchar_t *)0x80020004;
            pppppppiStack_160 = local_8c;
            local_78 = (wchar_t *)0x80020004;
            pppppppiStack_15c = (int *******)0x80020004;
            pppppppiStack_178 = (int *******)DAT_0050b40c;
            pppppppiStack_158 = local_84;
            pppppppiStack_174 = (int *******)0xa;
            pppppppiStack_170 = local_7c;
            pppppppiStack_16c = (int *******)0x80020004;
            pppppppiStack_168 = (int *******)local_74;
            pppppppiStack_17c = (int *******)0x43103f;
            pppppppiStack_180 = (int *******)(*(code *)(*DAT_0050b40c)[0xac])();
            pppppppiStack_17c = (int *******)ppppppiVar23;
            goto joined_r0x004319ca;
          }
        }
      }
      break;
    }
    if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
      pppppppiStack_158 = (int *******)0x4306f0;
      iVar7 = __vbaGenerateBoundsError();
    }
    else {
      pcVar18 = (code *)((int)DAT_0050b2b2 - *(int *)(DAT_0050b0cc + 0xe));
      if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar18) {
        pppppppiStack_158 = (int *******)0x4306c3;
        __vbaGenerateBoundsError();
      }
      pppppppiVar5 = (int *******)((int)local_20[0] - *(int *)(DAT_0050b0cc + 10));
      if (*(int ********)(DAT_0050b0cc + 8) <= pppppppiVar5) {
        pppppppiStack_158 = (int *******)0x4306db;
        __vbaGenerateBoundsError();
      }
      iVar7 = (int)(pcVar18 + *(int *)(DAT_0050b0cc + 0xc) * (int)pppppppiVar5) * 8;
    }
    uVar25 = 0;
    uVar16 = (undefined2)((uint)*(int *)(DAT_0050b0cc + 6) >> 0x10);
    if (SCARRY2(DAT_0050b29e,DAT_0050b2a0)) break;
    bVar2 = (short)(DAT_0050b29e + DAT_0050b2a0) < 1;
    if (*(double *)(*(int *)(DAT_0050b0cc + 6) + iVar7) == _DAT_00401880 || !bVar2) {
      if (DAT_0050b46c == (int *******)0x0) {
        pppppppiStack_158 = (int *******)&DAT_0050b46c;
        pppppppiStack_15c = (int *******)&DAT_004068ac;
        pppppppiStack_160 = (int *******)0x430bac;
        __vbaNew2();
      }
      pppppppiStack_158 = DAT_0050b46c;
      pppppppiStack_15c = (int *******)0x430bba;
      pppppppiStack_15c = (int *******)(*(code *)(*DAT_0050b46c)[199])();
      pppppppiStack_160 = (int *******)&local_30;
      pppppppiStack_164 = (int *******)0x430bc5;
      pppppppiVar10 = (int *******)__vbaObjSet();
      pppppppiStack_164 = (int *******)0x0;
      pppppppiStack_16c = (int *******)0x430bd2;
      pppppppiStack_168 = pppppppiVar10;
      pppppppiVar5 = (int *******)(*(code *)(*pppppppiVar10)[0x27])();
      if ((int)pppppppiVar5 < 0) {
        pppppppiStack_16c = (int *******)0x9c;
        pppppppiStack_170 = (int *******)&DAT_0040ba5c;
        pppppppiStack_17c = (int *******)0x430bea;
        pppppppiStack_178 = pppppppiVar5;
        pppppppiStack_174 = pppppppiVar10;
        __vbaHresultCheckObj();
      }
      pppppppiStack_16c = (int *******)0x430bf3;
      __vbaFreeObj();
      pcVar19 = (code *)0x80020004;
      pcVar18 = (code *)0xa;
      local_68 = 0x80020004;
      local_70[0] = (int ******)0xa;
      local_58 = 0x80020004;
      local_60[0] = (int ******)0xa;
      local_88 = L"Warning";
      local_90 = 8;
      pppppppiStack_16c = (int *******)0x430c2d;
      __vbaVarDup();
      local_78 = 
      L" Dual simplex not applicable because a var has upper/lower bound or is unrestricted.  Two-phase method will be used; else click CANCEL to use M-method"
      ;
      local_80 = (int ******)0x8;
      pppppppiStack_16c = (int *******)0x430c43;
      __vbaVarDup();
      pppppppiStack_16c = local_70;
      pppppppiStack_170 = local_60;
      pppppppiStack_174 = local_50;
      pppppppiStack_17c = local_40;
      pppppppiStack_178 = (int *******)0x11;
      pppppppiStack_180 = (int *******)0x430c5b;
      iVar7 = Ordinal_595();
      pppppppiStack_180 = local_70;
      pppppppiVar5 = (int *******)(uint)(ushort)-(ushort)(iVar7 == 2);
      pppppppiStack_184 = local_60;
      ppppppiStack_188 = (int ******)local_50;
      ppppppiStack_18c = (int ******)local_40;
      uStack_190 = 4;
      uStack_194 = 0x430c80;
      __vbaFreeVarList();
      if ((ushort)-(ushort)(iVar7 == 2) == 0) {
        DAT_0050b274 = 4;
        DAT_0050b240 = 1;
        if (!SCARRY2(DAT_0050b20c,DAT_0050b20a)) {
          uVar24 = SCARRY2(DAT_0050b20c + DAT_0050b20a,DAT_0050b246);
          sVar14 = DAT_0050b20c + DAT_0050b20a + DAT_0050b246;
          goto joined_r0x00430807;
        }
      }
      else {
        DAT_0050b274 = 3;
        if (((!SCARRY2(DAT_0050b20c,DAT_0050b20a)) &&
            (sVar14 = DAT_0050b20c + DAT_0050b20a + DAT_0050b246,
            !SCARRY2(DAT_0050b20c + DAT_0050b20a,DAT_0050b246))) &&
           ((sVar15 = sVar14 + 2, !SCARRY2(sVar14,2) &&
            (DAT_0050b278 = sVar15, !SCARRY2(DAT_0050b20c,7))))) {
          DAT_0050b276 = DAT_0050b20c + 7;
          if (DAT_0050b46c == (int *******)0x0) {
            pppppppiStack_158 = (int *******)&DAT_0050b46c;
            pppppppiStack_15c = (int *******)&DAT_004068ac;
            pppppppiStack_160 = (int *******)0x430cf2;
            __vbaNew2();
          }
          pppppppiStack_158 = DAT_0050b46c;
          pppppppiStack_15c = (int *******)0x430d00;
          pppppppiStack_15c = (int *******)(*(code *)(*DAT_0050b46c)[0xc3])();
          pppppppiStack_160 = (int *******)&local_d8;
          pppppppiStack_164 = (int *******)0x430d0e;
          __vbaObjSet();
          pppppppiStack_164 = (int *******)0xffffffff;
          pppppppiStack_168 = local_d8;
          pppppppiStack_16c = (int *******)0x430d1f;
          pppppppiVar10 = (int *******)(*(code *)(*local_d8)[0x27])();
          if ((int)pppppppiVar10 < 0) {
            pppppppiStack_16c = (int *******)0x9c;
            pppppppiStack_170 = (int *******)&DAT_0040c3dc;
            pppppppiStack_174 = local_d8;
            pppppppiStack_17c = (int *******)0x430d3f;
            pppppppiStack_178 = pppppppiVar10;
            __vbaHresultCheckObj();
          }
          if (DAT_0050c53c == (int *******)0x0) {
            pppppppiStack_16c = (int *******)&DAT_0050c53c;
            pppppppiStack_170 = (int *******)&DAT_0040b420;
            pppppppiStack_174 = (int *******)0x430d60;
            __vbaNew2();
          }
          pppppppiVar10 = DAT_0050c53c;
          pppppppiStack_16c = (int *******)&local_30;
          pppppppiStack_170 = DAT_0050c53c;
          pppppppiStack_174 = (int *******)0x430d70;
          pppppppiVar5 = (int *******)(*(code *)(*DAT_0050c53c)[6])();
          if ((int)pppppppiVar5 < 0) {
            pppppppiStack_174 = (int *******)0x18;
            pppppppiStack_178 = (int *******)&DAT_0040b410;
            pppppppiStack_17c = pppppppiVar10;
            pppppppiStack_184 = (int *******)0x430d81;
            pppppppiStack_180 = pppppppiVar5;
            __vbaHresultCheckObj();
          }
          pppppppiVar10 = local_30;
          pppppppiStack_174 = local_b4;
          pppppppiStack_178 = local_30;
          pppppppiStack_17c = (int *******)0x430d93;
          ppppppiVar23 = (int ******)(*(code *)(*local_30)[0x14])();
          if ((int)ppppppiVar23 < 0) {
            pppppppiStack_17c = (int *******)0x50;
            pppppppiStack_180 = (int *******)&DAT_0040bb5c;
            pppppppiStack_184 = pppppppiVar10;
            ppppppiStack_18c = (int ******)0x430da4;
            ppppppiStack_188 = ppppppiVar23;
            __vbaHresultCheckObj();
          }
          pppppppiStack_17c = &local_b8;
          pppppppiStack_180 = local_d8;
          pppppppiStack_184 = (int *******)0x430dba;
          pppppppiVar10 = (int *******)(*(code *)(*local_d8)[0x22])();
          uVar25 = 0;
          if ((int)pppppppiVar10 < 0) {
            pppppppiStack_154 = (int *******)0x88;
            pppppppiStack_158 = (int *******)&DAT_0040c3dc;
            pppppppiStack_15c = local_d8;
            pppppppiStack_164 = (int *******)0x430dd4;
            pppppppiStack_160 = pppppppiVar10;
            __vbaHresultCheckObj();
          }
          pppppppiStack_154 = local_d8;
          if ((uVar25 & 0xd) != 0) goto LAB_00431a5e;
          pppppppiStack_158 = local_d8;
          pppppppiStack_15c = (int *******)0x430e14;
          pppppppiStack_154 =
               (int *******)
               ((float)local_b4[0] * (float)_DAT_00401858 - (float)local_b8 * (float)_DAT_00401268);
          pppppppiVar10 = (int *******)(*(code *)(*local_d8)[0x1f])();
          if ((int)pppppppiVar10 < 0) {
            pppppppiStack_15c = (int *******)0x7c;
            pppppppiStack_160 = (int *******)&DAT_0040c3dc;
            pppppppiStack_164 = local_d8;
            pppppppiStack_16c = (int *******)0x430e2b;
            pppppppiStack_168 = pppppppiVar10;
            __vbaHresultCheckObj();
          }
          pcVar19 = __vbaFreeObj_exref;
          pppppppiStack_15c = (int *******)0x430e36;
          __vbaFreeObj();
          if (DAT_0050c53c == (int *******)0x0) {
            pppppppiStack_15c = (int *******)&DAT_0050c53c;
            pppppppiStack_160 = (int *******)&DAT_0040b420;
            pppppppiStack_164 = (int *******)0x430e4f;
            __vbaNew2();
          }
          pppppppiVar10 = DAT_0050c53c;
          pppppppiStack_15c = (int *******)&local_30;
          pppppppiStack_160 = DAT_0050c53c;
          pppppppiStack_164 = (int *******)0x430e5f;
          pppppppiVar5 = (int *******)(*(code *)(*DAT_0050c53c)[6])();
          if ((int)pppppppiVar5 < 0) {
            pppppppiStack_164 = (int *******)0x18;
            pppppppiStack_168 = (int *******)&DAT_0040b410;
            pppppppiStack_16c = pppppppiVar10;
            pppppppiStack_174 = (int *******)0x430e70;
            pppppppiStack_170 = pppppppiVar5;
            __vbaHresultCheckObj();
          }
          pppppppiVar10 = local_30;
          pppppppiStack_164 = local_b4;
          pppppppiStack_168 = local_30;
          pppppppiStack_16c = (int *******)0x430e85;
          pppppppiVar5 = (int *******)(*(code *)(*local_30)[0x26])();
          if ((int)pppppppiVar5 < 0) {
            pppppppiStack_16c = (int *******)0x98;
            pppppppiStack_170 = (int *******)&DAT_0040bb5c;
            pppppppiStack_174 = pppppppiVar10;
            pppppppiStack_17c = (int *******)0x430e99;
            pppppppiStack_178 = pppppppiVar5;
            __vbaHresultCheckObj();
          }
          pppppppiStack_16c = &local_b8;
          pppppppiStack_170 = local_d8;
          pppppppiStack_174 = (int *******)0x430eaf;
          pppppppiVar10 = (int *******)(*(code *)(*local_d8)[0x20])();
          uVar25 = 0;
          if ((int)pppppppiVar10 < 0) {
            pppppppiStack_154 = (int *******)0x80;
            pppppppiStack_158 = (int *******)&DAT_0040c3dc;
            pppppppiStack_15c = local_d8;
            pppppppiStack_164 = (int *******)0x430ec9;
            pppppppiStack_160 = pppppppiVar10;
            __vbaHresultCheckObj();
          }
          pppppppiStack_154 = local_d8;
          if ((uVar25 & 0xd) != 0) {
LAB_00431a5e:
            __vbaFPException();
            return;
          }
          pppppppiStack_158 = local_d8;
          pppppppiStack_15c = (int *******)0x430f09;
          pppppppiStack_154 =
               (int *******)
               ((float)local_b4[0] * (float)_DAT_00401268 - (float)local_b8 * (float)_DAT_00401268);
          pppppppiVar10 = (int *******)(*(code *)(*local_d8)[0x1d])();
          if ((int)pppppppiVar10 < 0) {
            pppppppiStack_15c = (int *******)0x74;
            pppppppiStack_160 = (int *******)&DAT_0040c3dc;
            pppppppiStack_164 = local_d8;
            pppppppiStack_16c = (int *******)0x430f20;
            pppppppiStack_168 = pppppppiVar10;
            __vbaHresultCheckObj();
          }
          pppppppiStack_15c = (int *******)0x430f25;
          __vbaFreeObj();
          pppppppiStack_160 = (int *******)&local_d8;
          pppppppiStack_15c = (int *******)0x0;
          pppppppiStack_164 = (int *******)0x430f34;
          __vbaObjSetAddref();
joined_r0x00430b54:
          if (DAT_0050b46c == (int *******)0x0) {
            pppppppiStack_164 = (int *******)&DAT_0050b46c;
            pppppppiStack_168 = (int *******)&DAT_004068ac;
            pppppppiStack_16c = (int *******)0x430f4d;
            __vbaNew2();
          }
          pppppppiStack_168 = (int *******)0x430f5b;
          pppppppiStack_164 = DAT_0050b46c;
          pppppppiStack_168 = (int *******)(*(code *)(*DAT_0050b46c)[0xc5])();
          pppppppiStack_16c = (int *******)&local_30;
          pppppppiStack_170 = (int *******)0x430f66;
          __vbaObjSet();
          pppppppiStack_170 = (int *******)&local_30;
          pppppppiStack_174 = (int *******)0x430f6f;
          FUN_00444410();
          pppppppiStack_174 = (int *******)0x430f74;
          (*pcVar19)();
          goto LAB_004319de;
        }
      }
      break;
    }
    pcVar18 = (code *)(uint)bVar2;
    wVar20 = local_20[0] + L'\x01';
  } while (!SCARRY2(local_20[0],1));
LAB_00431a63:
  pppppppiStack_158 = (int *******)0x431a69;
  __vbaErrorOverflow();
  pppppppiStack_168 = (int *******)&DAT_00402706;
  pppppppiStack_16c = ExceptionList;
  pppppppiStack_164 = (int *******)&pcStack_218;
  pppppppiStack_160 = (int *******)&DAT_00401898;
  pppppppiStack_15c = (int *******)((uint)piStack_150 & 1);
  piStack_21c = (int *)((uint)piStack_150 & 0xfffffffe);
  pppppppiStack_220 = (int *******)0x431ab2;
  ExceptionList = &pppppppiStack_16c;
  pcStack_218 = pcVar19;
  pppppppiStack_214 = pppppppiVar5;
  pcStack_210 = pcVar18;
  pppppppiStack_158 = (int *******)&stack0xfffffffc;
  piStack_150 = piStack_21c;
  (**(code **)(*piStack_21c + 4))();
  uVar22 = 0;
  pppppppiStack_174 = (int *******)0x0;
  pppppppiStack_184 = (int *******)0x0;
  uStack_194 = 0;
  apppppiStack_1a4[0] = (int *****)0x0;
  apppppiStack_1b4[0] = (int *****)0x0;
  uStack_1c4 = 0;
  uStack_1d4 = 0;
  DAT_0050b1ea = 0;
  if (DAT_0050b46c == (int *******)0x0) {
    pppppppiStack_220 = (int *******)&DAT_0050b46c;
    puStack_224 = &DAT_004068ac;
    pppppppiStack_228 = (int *******)0x431ae9;
    __vbaNew2();
  }
  pppppppiStack_220 = DAT_0050b46c;
  puStack_224 = (undefined *)0x431af7;
  puStack_224 = (undefined *)(*(code *)(*DAT_0050b46c)[199])();
  pcVar19 = __vbaObjSet_exref;
  pppppppiStack_228 = (int *******)&pppppppiStack_174;
  piStack_22c = (int *)0x431b04;
  piVar9 = (int *)__vbaObjSet();
  piStack_22c = (int *)0x0;
  pppppiStack_234 = (int *****)0x431b10;
  piStack_230 = piVar9;
  iVar7 = (**(code **)(*piVar9 + 0x9c))();
  if (iVar7 < 0) {
    pppppiStack_234 = (int *****)0x9c;
    pppppiStack_238 = (int *****)&DAT_0040ba5c;
    pppppppiStack_244 = (int *******)0x431b28;
    puStack_240 = (undefined1 *)iVar7;
    piStack_23c = piVar9;
    __vbaHresultCheckObj();
  }
  pppppiStack_234 = (int *****)0x431b31;
  __vbaFreeObj();
  _DAT_0050b28a = 0;
  if ((!SCARRY2(DAT_0050b29e,DAT_0050b2a0)) && (!SCARRY2(DAT_0050b29e + DAT_0050b2a0,DAT_0050b2a2)))
  {
    if (0 < (short)(DAT_0050b29e + DAT_0050b2a0 + DAT_0050b2a2)) {
      pppppiStack_234 = (int *****)0x431b68;
      Ordinal_534();
      uStack_1ac = 0x80020004;
      apppppiStack_1b4[0] = (int *****)0xa;
      uStack_19c = 0x80020004;
      apppppiStack_1a4[0] = (int *****)0xa;
      pwStack_1cc = L"Graphical LP";
      uStack_1d4 = 8;
      pppppiStack_234 = (int *****)0x431b9b;
      __vbaVarDup();
      pwStack_1bc = 
      L"LPs with unrestricted vars and/or explicit upper/lower bounds are not supported by graphical method.                Click OK then click screen."
      ;
      uStack_1c4 = 8;
      pppppiStack_234 = (int *****)0x431bad;
      __vbaVarDup();
      pppppiStack_234 = (int *****)apppppiStack_1b4;
      pppppiStack_238 = (int *****)apppppiStack_1a4;
      piStack_23c = &uStack_194;
      pppppppiStack_244 = (int *******)&pppppppiStack_184;
      puStack_240 = (undefined1 *)0x10;
      pppppppiStack_248 = (int *******)0x431bc5;
      Ordinal_595();
      pppppppiStack_248 = (int *******)apppppiStack_1b4;
      ppppppiStack_24c = apppppiStack_1a4;
      pppppppiStack_250 = (int *******)&uStack_194;
      pppppppiStack_254 = (int *******)&pppppppiStack_184;
      piStack_258 = (int *)0x4;
      uStack_25c = 0x431bdd;
      __vbaFreeVarList();
      if (DAT_0050b46c == (int *******)0x0) {
        pppppppiStack_248 = (int *******)&DAT_0050b46c;
        ppppppiStack_24c = (int ******)&DAT_004068ac;
        pppppppiStack_250 = (int *******)0x431bf9;
        __vbaNew2();
      }
      pppppppiStack_248 = DAT_0050b46c;
      ppppppiStack_24c = (int ******)0x431c07;
      ppppppiStack_24c = (int ******)(*(code *)(*DAT_0050b46c)[199])();
      pppppppiStack_250 = (int *******)&pppppppiStack_174;
      pppppppiStack_254 = (int *******)0x431c0e;
      piVar9 = (int *)__vbaObjSet();
      pppppppiStack_254 = (int *******)0xffffffff;
      uStack_25c = 0x431c1b;
      piStack_258 = piVar9;
      iVar7 = (**(code **)(*piVar9 + 0x9c))();
      if (iVar7 < 0) {
        uStack_25c = 0x9c;
        puStack_260 = &DAT_0040ba5c;
        uStack_26c = 0x431c33;
        iStack_268 = iVar7;
        ppppppiStack_264 = (int ******)piVar9;
        __vbaHresultCheckObj();
      }
      uStack_25c = 0x431c3c;
      __vbaFreeObj();
      return;
    }
    DAT_0050b272 = 2;
    DAT_0050b274 = 1;
    DAT_0050b1ce = 2;
    uStack_204 = _DAT_0050b20c;
    pcVar19 = (code *)&DAT_00000001;
    uVar4 = 1;
    do {
      uVar22 = uVar4;
      sVar14 = (short)uVar22;
      if ((short)uStack_204 < sVar14) {
        pppppiStack_234 = (int *****)0x431ccf;
        FUN_0045bab0();
        if (DAT_0050b40c == (int ******)0x0) {
          pppppiStack_234 = (int *****)&DAT_0050b40c;
          pppppiStack_238 = (int *****)&DAT_00403f84;
          piStack_23c = (int *)0x431ce8;
          __vbaNew2();
        }
        ppppppiVar23 = DAT_0050b40c;
        uStack_1d4 = 10;
        uStack_1c4 = 10;
        puStack_240 = (undefined1 *)0xa;
        piStack_23c = (int *)uStack_1d0;
        pwStack_1cc = (wchar_t *)0x80020004;
        pppppiStack_238 = (int *****)0x80020004;
        pwStack_1bc = (wchar_t *)0x80020004;
        pppppiStack_234 = (int *****)ppppiStack_1c8;
        pppppppiStack_250 = (int *******)0xa;
        pppppppiStack_254 = (int *******)DAT_0050b40c;
        ppppppiStack_24c = ppppppiStack_1c0;
        pppppppiStack_248 = (int *******)0x80020004;
        pppppppiStack_244 = (int *******)uStack_1b8;
        piStack_258 = (int *)0x431d3e;
        iStack_268 = (*(code *)(*DAT_0050b40c)[0xac])();
        if (-1 < iStack_268) {
          return;
        }
        uStack_25c = 0x2b0;
        puStack_260 = &DAT_0040b2f0;
        ppppppiStack_264 = ppppppiVar23;
        uStack_26c = 0x431d56;
        __vbaHresultCheckObj();
        return;
      }
      if ((DAT_0050b1e4 == (short *)0x0) || (*DAT_0050b1e4 != 1)) {
        pppppiStack_234 = (int *****)0x431cab;
        iVar7 = __vbaGenerateBoundsError();
      }
      else {
        piVar9 = (int *)((int)sVar14 - *(int *)(DAT_0050b1e4 + 10));
        if (*(int **)(DAT_0050b1e4 + 8) <= piVar9) {
          pppppiStack_234 = (int *****)0x431c9a;
          __vbaGenerateBoundsError();
        }
        iVar7 = (int)piVar9 * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b1e4 + 6) + iVar7) = 0;
      uVar4 = CONCAT22((short)((uint)iVar7 >> 0x10),sVar14 + 1);
    } while (!SCARRY2(sVar14,1));
  }
  pppppiStack_234 = (int *****)0x431daf;
  __vbaErrorOverflow();
  pppppppiStack_244 = (int *******)&DAT_00402706;
  pppppppiStack_248 = ExceptionList;
  puStack_240 = (undefined1 *)&uStack_30c;
  piStack_23c = (int *)&DAT_004018a8;
  pppppiStack_238 = (int *****)((uint)piStack_22c & 1);
  piStack_310 = (int *)((uint)piStack_22c & 0xfffffffe);
  pppppppiStack_314 = (int *******)0x431df2;
  ExceptionList = &pppppppiStack_248;
  uStack_30c = uVar22;
  piStack_308 = piVar9;
  pcStack_304 = pcVar19;
  pppppiStack_234 = (int *****)&pppppppiStack_158;
  piStack_22c = piStack_310;
  (**(code **)(*piStack_310 + 4))();
  uVar22 = 0;
  ppppppiStack_24c = (int ******)0x0;
  uStack_25c = 0;
  uStack_26c = 0;
  apppppiStack_27c[0] = (int *****)0x0;
  appppiStack_28c[0] = (int ****)0x0;
  uStack_29c = 0;
  uStack_2ac = 0;
  appppppiStack_2d0[0] = (int ******)0x0;
  fStack_2d4 = 0.0;
  apppppppiStack_2f0[0] = (int *******)0x0;
  DAT_0050b272 = 2;
  if (DAT_0050b46c == (int *******)0x0) {
    pppppppiStack_314 = (int *******)&DAT_0050b46c;
    puStack_318 = &DAT_004068ac;
    ppppppiStack_31c = (int ******)0x431e3d;
    __vbaNew2();
  }
  pppppppiStack_314 = DAT_0050b46c;
  puStack_318 = (undefined *)0x431e4b;
  puStack_318 = (undefined *)(*(code *)(*DAT_0050b46c)[199])();
  ppppppiStack_31c = (int ******)&ppppppiStack_24c;
  piStack_320 = (int *)0x431e56;
  pcVar19 = (code *)__vbaObjSet();
  piStack_320 = (int *)0x0;
  pppppppiStack_328 = (int *******)0x431e62;
  pcStack_324 = pcVar19;
  iVar7 = (**(code **)(*(int *)pcVar19 + 0x9c))();
  ppppppiVar23 = (int ******)__vbaHresultCheckObj_exref;
  if (iVar7 < 0) {
    pppppppiStack_328 = (int *******)0x9c;
    pppppiStack_32c = (int *****)&DAT_0040ba5c;
    pppppppiStack_338 = (int *******)0x431e7c;
    puStack_334 = (undefined1 *)iVar7;
    pppppppiStack_330 = (int *******)pcVar19;
    __vbaHresultCheckObj();
  }
  pppppppiStack_328 = (int *******)0x431e8d;
  __vbaFreeObj();
  pcVar18 = __vbaVarDup_exref;
  if (!SCARRY2(DAT_0050b246,DAT_0050b248)) {
    if ((short)(DAT_0050b246 + DAT_0050b248) == 0) {
      uVar22 = 10;
      ppppppiVar23 = (int ******)0x8;
      uStack_284 = 0x80020004;
      appppiStack_28c[0] = (int ****)0xa;
      uStack_274 = 0x80020004;
      apppppiStack_27c[0] = (int *****)0xa;
      pwStack_2a4 = L"Warning";
      uStack_2ac = 8;
      pppppppiStack_328 = (int *******)0x431ee0;
      __vbaVarDup();
      pwStack_294 = L"Problem has all <= constraints.  All-Slack option will be used";
      uStack_29c = 8;
      pppppppiStack_328 = (int *******)0x431ef2;
      __vbaVarDup();
      pppppppiStack_328 = (int *******)appppiStack_28c;
      pppppiStack_32c = (int *****)apppppiStack_27c;
      pppppppiStack_330 = (int *******)&uStack_26c;
      pppppppiStack_338 = (int *******)&uStack_25c;
      puStack_334 = (undefined1 *)0x11;
      ppppppiStack_33c = (int ******)0x431f0a;
      Ordinal_595();
      ppppppiStack_33c = (int ******)appppiStack_28c;
      pppppppiStack_340 = (int *******)apppppiStack_27c;
      pppppppiStack_344 = (int *******)&uStack_26c;
      ppppppiStack_348 = (int ******)&uStack_25c;
      pppppppiStack_34c = (int *******)0x4;
      pppppppiStack_350 = (int *******)0x431f22;
      __vbaFreeVarList();
      DAT_0050b274 = 2;
      pcVar19 = pcVar18;
      if (((!SCARRY2(DAT_0050b20c,DAT_0050b20a)) &&
          (sVar14 = DAT_0050b20c + DAT_0050b20a + 2, !SCARRY2(DAT_0050b20c + DAT_0050b20a,2))) &&
         (DAT_0050b278 = sVar14, !SCARRY2(DAT_0050b20c,7))) {
        DAT_0050b276 = DAT_0050b20c + 7;
        if (DAT_0050b40c == (int ******)0x0) {
          pppppppiStack_328 = &DAT_0050b40c;
          pppppiStack_32c = (int *****)&DAT_00403f84;
          pppppppiStack_330 = (int *******)0x431f7e;
          __vbaNew2();
        }
        ppppppiVar23 = DAT_0050b40c;
        uStack_29c = 10;
        uStack_2ac = 10;
        puStack_334 = (undefined1 *)0xa;
        pwStack_2a4 = (wchar_t *)0x80020004;
        pppppppiStack_330 = pppppppiStack_2a8;
        pppppiStack_32c = (int *****)0x80020004;
        pwStack_294 = (wchar_t *)0x80020004;
        pppppppiStack_328 = pppppppiStack_2a0;
        pppppppiStack_344 = (int *******)0xa;
        ppppppiStack_348 = DAT_0050b40c;
        pppppppiStack_340 = pppppppiStack_298;
        ppppppiStack_33c = (int ******)0x80020004;
        pppppppiStack_338 = pppppppiStack_290;
        pppppppiStack_34c = (int *******)0x431fd1;
        pppppppiVar10 = (int *******)(*(code *)(*DAT_0050b40c)[0xac])();
        if ((int)pppppppiVar10 < 0) {
          pppppppiStack_34c = (int *******)0x2b0;
          pppppppiStack_350 = (int *******)&DAT_0040b2f0;
          pppppppiStack_354 = (int *******)ppppppiVar23;
          pppppppiStack_35c = (int *******)0x431fe9;
          pppppppiStack_358 = pppppppiVar10;
          __vbaHresultCheckObj();
        }
LAB_00431feb:
        pppppiStack_238 = (int *****)0x0;
        pppppppiStack_34c = (int *******)&LAB_00432309;
        pppppppiStack_350 = (int *******)0x432308;
        __vbaFreeObj();
        return;
      }
    }
    else {
      DAT_0050b274 = 3;
      if ((((!SCARRY2(DAT_0050b20c,DAT_0050b20a)) &&
           (sVar14 = DAT_0050b20c + DAT_0050b20a + DAT_0050b246,
           !SCARRY2(DAT_0050b20c + DAT_0050b20a,DAT_0050b246))) &&
          (sVar15 = sVar14 + 2, !SCARRY2(sVar14,2))) &&
         (DAT_0050b278 = sVar15, !SCARRY2(DAT_0050b20c,7))) {
        DAT_0050b276 = DAT_0050b20c + 7;
        if (DAT_0050b46c == (int *******)0x0) {
          pppppppiStack_328 = (int *******)&DAT_0050b46c;
          pppppiStack_32c = (int *****)&DAT_004068ac;
          pppppppiStack_330 = (int *******)0x43205b;
          __vbaNew2();
        }
        pppppppiStack_328 = DAT_0050b46c;
        pppppiStack_32c = (int *****)0x432069;
        pppppiStack_32c = (int *****)(*(code *)(*DAT_0050b46c)[0xc3])();
        pppppppiStack_330 = (int *******)apppppppiStack_2f0;
        puStack_334 = (undefined1 *)0x432077;
        __vbaObjSet();
        puStack_334 = (undefined1 *)0xffffffff;
        pppppppiStack_338 = apppppppiStack_2f0[0];
        ppppppiStack_33c = (int ******)0x432088;
        puVar11 = (undefined4 *)(*(code *)(*apppppppiStack_2f0[0])[0x27])();
        if ((int)puVar11 < 0) {
          ppppppiStack_33c = (int ******)0x9c;
          pppppppiStack_340 = (int *******)&DAT_0040c3dc;
          pppppppiStack_344 = apppppppiStack_2f0[0];
          pppppppiStack_34c = (int *******)0x4320a2;
          ppppppiStack_348 = (int ******)puVar11;
          __vbaHresultCheckObj();
        }
        if (DAT_0050c53c == (int *******)0x0) {
          ppppppiStack_33c = (int ******)&DAT_0050c53c;
          pppppppiStack_340 = (int *******)&DAT_0040b420;
          pppppppiStack_344 = (int *******)0x4320ba;
          __vbaNew2();
        }
        pppppppiVar10 = DAT_0050c53c;
        ppppppiStack_33c = (int ******)&ppppppiStack_24c;
        pppppppiStack_340 = DAT_0050c53c;
        pppppppiStack_344 = (int *******)0x4320ca;
        iVar7 = (*(code *)(*DAT_0050c53c)[6])();
        if (iVar7 < 0) {
          pppppppiStack_344 = (int *******)0x18;
          ppppppiStack_348 = (int ******)&DAT_0040b410;
          pppppppiStack_34c = pppppppiVar10;
          pppppppiStack_354 = (int *******)0x4320db;
          pppppppiStack_350 = (int *******)iVar7;
          __vbaHresultCheckObj();
        }
        ppppppiVar23 = ppppppiStack_24c;
        pppppppiStack_344 = appppppiStack_2d0;
        ppppppiStack_348 = ppppppiStack_24c;
        pppppppiStack_34c = (int *******)0x4320ed;
        pppppppiVar10 = (int *******)(*(code *)(*ppppppiStack_24c)[0x14])();
        if ((int)pppppppiVar10 < 0) {
          pppppppiStack_34c = (int *******)0x50;
          pppppppiStack_350 = (int *******)&DAT_0040bb5c;
          pppppppiStack_354 = (int *******)ppppppiVar23;
          pppppppiStack_35c = (int *******)0x4320fe;
          pppppppiStack_358 = pppppppiVar10;
          __vbaHresultCheckObj();
        }
        pppppppiStack_34c = (int *******)&fStack_2d4;
        pppppppiStack_350 = apppppppiStack_2f0[0];
        pppppppiStack_354 = (int *******)0x432114;
        pppppppiVar10 = (int *******)(*(code *)(*apppppppiStack_2f0[0])[0x22])();
        uVar25 = 0;
        if ((int)pppppppiVar10 < 0) {
          pppppppiStack_354 = (int *******)0x88;
          pppppppiStack_358 = (int *******)&DAT_0040c3dc;
          pppppppiStack_35c = apppppppiStack_2f0[0];
          pppppppiStack_364 = (int *******)0x43212e;
          pppppppiStack_360 = pppppppiVar10;
          __vbaHresultCheckObj();
        }
        pppppppiStack_354 =
             (int *******)
             ((float)appppppiStack_2d0[0] * (float)_DAT_00401858 - fStack_2d4 * (float)_DAT_00401268
             );
        if ((uVar25 & 0xd) == 0) {
          pppppppiStack_358 = apppppppiStack_2f0[0];
          pppppppiStack_35c = (int *******)0x43216e;
          fStack_2fc = (float)pppppppiStack_354;
          iVar7 = (*(code *)(*apppppppiStack_2f0[0])[0x1f])();
          if (iVar7 < 0) {
            pppppppiStack_35c = (int *******)0x7c;
            pppppppiStack_360 = (int *******)&DAT_0040c3dc;
            pppppppiStack_364 = apppppppiStack_2f0[0];
            __vbaHresultCheckObj(iVar7);
          }
          pppppppiStack_35c = (int *******)0x43218e;
          __vbaFreeObj();
          if (DAT_0050c53c == (int *******)0x0) {
            pppppppiStack_35c = (int *******)&DAT_0050c53c;
            pppppppiStack_360 = (int *******)&DAT_0040b420;
            pppppppiStack_364 = (int *******)0x4321a6;
            __vbaNew2();
          }
          pppppppiVar10 = DAT_0050c53c;
          pppppppiStack_35c = &ppppppiStack_24c;
          pppppppiStack_360 = DAT_0050c53c;
          pppppppiStack_364 = (int *******)0x4321b6;
          iVar7 = (*(code *)(*DAT_0050c53c)[6])();
          if (iVar7 < 0) {
            pppppppiStack_364 = (int *******)0x18;
            __vbaHresultCheckObj(iVar7,pppppppiVar10,&DAT_0040b410);
          }
          ppppppiVar23 = ppppppiStack_24c;
          pppppppiStack_364 = appppppiStack_2d0;
          iVar7 = (*(code *)(*ppppppiStack_24c)[0x26])(ppppppiStack_24c);
          if (iVar7 < 0) {
            __vbaHresultCheckObj(iVar7,ppppppiVar23,&DAT_0040bb5c,0x98);
          }
          pppppppiVar10 =
               (int *******)
               (*(code *)(*apppppppiStack_2f0[0])[0x20])(apppppppiStack_2f0[0],&fStack_2d4);
          uVar25 = 0;
          if ((int)pppppppiVar10 < 0) {
            pppppppiStack_354 = (int *******)0x80;
            pppppppiStack_358 = (int *******)&DAT_0040c3dc;
            pppppppiStack_35c = apppppppiStack_2f0[0];
            pppppppiStack_364 = (int *******)0x432220;
            pppppppiStack_360 = pppppppiVar10;
            __vbaHresultCheckObj();
          }
          if ((uVar25 & 0xd) == 0) {
            pppppppiStack_354 =
                 (int *******)(((float)appppppiStack_2d0[0] - fStack_2d4) * (float)_DAT_00401268);
            if ((uVar25 & 0xd) == 0) {
              pppppppiStack_358 = apppppppiStack_2f0[0];
              pppppppiStack_35c = (int *******)0x432262;
              ppppppiStack_300 = (int ******)pppppppiStack_354;
              iVar7 = (*(code *)(*apppppppiStack_2f0[0])[0x1d])();
              if (iVar7 < 0) {
                pppppppiStack_35c = (int *******)0x74;
                pppppppiStack_360 = (int *******)&DAT_0040c3dc;
                pppppppiStack_364 = apppppppiStack_2f0[0];
                __vbaHresultCheckObj(iVar7);
              }
              pppppppiStack_35c = (int *******)0x432284;
              __vbaFreeObj();
              pppppppiStack_360 = (int *******)apppppppiStack_2f0;
              pppppppiStack_35c = (int *******)0x0;
              pppppppiStack_364 = (int *******)0x432292;
              __vbaObjSetAddref();
              if (DAT_0050b46c == (int *******)0x0) {
                pppppppiStack_364 = (int *******)&DAT_0050b46c;
                __vbaNew2(&DAT_004068ac);
              }
              pppppppiStack_364 = DAT_0050b46c;
              uVar22 = (*(code *)(*DAT_0050b46c)[0xc5])();
              __vbaObjSet(&ppppppiStack_24c,uVar22);
              FUN_00444410(&ppppppiStack_24c);
              __vbaFreeObj();
              goto LAB_00431feb;
            }
          }
        }
        pppppppiStack_354 = apppppppiStack_2f0[0];
        __vbaFPException();
        return;
      }
    }
  }
  pppppppiStack_328 = (int *******)0x432333;
  __vbaErrorOverflow();
  pppppppiStack_338 = (int *******)&DAT_00402706;
  ppppppiStack_33c = ExceptionList;
  puStack_334 = (undefined1 *)&pppppppiStack_364;
  pppppppiStack_330 = (int *******)&DAT_004018b8;
  pppppiStack_32c = (int *****)((uint)piStack_320 & 1);
  piVar9 = (int *)((uint)piStack_320 & 0xfffffffe);
  ExceptionList = &ppppppiStack_33c;
  pppppppiStack_364 = (int *******)ppppppiVar23;
  pppppppiStack_360 = (int *******)pcVar19;
  pppppppiStack_35c = (int *******)uVar22;
  pppppppiStack_328 = (int *******)&pppppiStack_234;
  piStack_320 = piVar9;
  (**(code **)(*piVar9 + 4))(piVar9);
  pppppppiStack_340 = (int *******)0x0;
  if (DAT_0050c53c == (int *******)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  pppppppiVar10 = DAT_0050c53c;
  pppppppiStack_358 = (int *******)*DAT_0050c53c;
  uVar22 = __vbaObjSetAddref(&pppppppiStack_340,piVar9);
  iVar7 = (*(code *)pppppppiStack_358[4])(pppppppiVar10,uVar22);
  if (iVar7 < 0) {
    __vbaHresultCheckObj(iVar7,pppppppiVar10,&DAT_0040b410,0x10);
  }
  __vbaFreeObj();
  FUN_00444530();
  if ((DAT_0050b238 == 4) || (DAT_0050b238 == 7)) {
    DAT_0050b206 = 2;
  }
  else {
    DAT_0050b206 = 1;
  }
  DAT_0050b204 = 1;
  FUN_0044a9d0(&DAT_0050b204,&DAT_0050b206);
  return;
LAB_00431163:
  local_1c = pppppppiVar10;
  pcVar18 = (code *)0x0;
  pppppppiVar5 = local_1c;
  if (sVar14 < (short)local_1c) {
    pcVar18 = (code *)(uint)(ushort)DAT_0050b20a;
    wVar13 = DAT_0050b20c + DAT_0050b20a;
    if ((!SCARRY2(DAT_0050b20c,DAT_0050b20a)) && (sVar14 = wVar13 + L'\x01', !SCARRY2(wVar13,1))) {
      wVar20 = wVar13 + L'\x02';
      pppppppiVar5 = (int *******)(uint)(ushort)wVar20;
      DAT_0050b290 = sVar14;
      if ((!SCARRY2(sVar14,1)) &&
         ((DAT_0050b296 = wVar20, !SBORROW2(sVar14,1) &&
          (sVar14 = DAT_0050b20c, DAT_0050b292 = wVar13, wVar20 = DAT_0050b20a,
          !SCARRY2(DAT_0050b20a,1))))) goto LAB_004313ba;
    }
    goto LAB_00431a63;
  }
  if ((SCARRY2(DAT_0050b20c,DAT_0050b20a)) ||
     (wVar13 = DAT_0050b20c + DAT_0050b20a + L'\x01', SCARRY2(DAT_0050b20c + DAT_0050b20a,1)))
  goto LAB_00431a63;
  local_20[0] = wVar13;
  local_20[1] = uVar16;
  if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
    pppppppiStack_158 = (int *******)0x4311d5;
    iVar7 = (*pcVar19)();
  }
  else {
    pcVar18 = (code *)((int)(short)local_1c - *(int *)(DAT_0050b0cc + 0xe));
    if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar18) {
      pppppppiStack_158 = (int *******)0x4311a1;
      (*pcVar19)();
    }
    pcVar19 = (code *)((int)DAT_0050b290 - *(int *)(DAT_0050b0cc + 10));
    if (*(code **)(DAT_0050b0cc + 8) <= pcVar19) {
      pppppppiStack_158 = (int *******)0x4311c0;
      __vbaGenerateBoundsError();
    }
    iVar7 = (int)(pcVar18 + *(int *)(DAT_0050b0cc + 0xc) * (int)pcVar19) * 8;
  }
  if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
    pppppppiStack_158 = (int *******)0x431232;
    iVar8 = __vbaGenerateBoundsError();
  }
  else {
    pcVar18 = (code *)((int)(short)local_1c - *(int *)(DAT_0050b0cc + 0xe));
    if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar18) {
      pppppppiStack_158 = (int *******)0x4311fd;
      __vbaGenerateBoundsError();
    }
    pcVar19 = (code *)((int)local_20[0] - *(int *)(DAT_0050b0cc + 10));
    if (*(code **)(DAT_0050b0cc + 8) <= pcVar19) {
      pppppppiStack_158 = (int *******)0x431219;
      __vbaGenerateBoundsError();
    }
    iVar8 = (int)(pcVar18 + *(int *)(DAT_0050b0cc + 0xc) * (int)pcVar19) * 8;
  }
  iVar1 = *(int *)(DAT_0050b0cc + 6);
  *(undefined4 *)(iVar8 + iVar1) = *(undefined4 *)(iVar7 + iVar1);
  *(undefined4 *)(iVar8 + 4 + iVar1) = *(undefined4 *)(iVar7 + 4 + iVar1);
  if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
    pppppppiStack_158 = (int *******)0x4312a7;
    pppppppiVar5 = (int *******)__vbaGenerateBoundsError();
  }
  else {
    pcVar19 = (code *)((int)(short)local_1c - *(int *)(DAT_0050b0cc + 0xe));
    if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar19) {
      pppppppiStack_158 = (int *******)0x43126f;
      __vbaGenerateBoundsError();
    }
    pcVar18 = (code *)((int)DAT_0050b296 - *(int *)(DAT_0050b0cc + 10));
    if (*(code **)(DAT_0050b0cc + 8) <= pcVar18) {
      pppppppiStack_158 = (int *******)0x43128e;
      __vbaGenerateBoundsError();
    }
    pppppppiVar5 = (int *******)((int)(pcVar19 + *(int *)(DAT_0050b0cc + 0xc) * (int)pcVar18) * 8);
  }
  if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
    pppppppiStack_158 = (int *******)0x431311;
    iVar7 = __vbaGenerateBoundsError();
  }
  else {
    pcVar18 = (code *)((int)(short)local_1c - *(int *)(DAT_0050b0cc + 0xe));
    if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar18) {
      pppppppiStack_158 = (int *******)0x4312cf;
      __vbaGenerateBoundsError();
    }
    if (SCARRY2(local_20[0],1)) goto LAB_00431a63;
    uVar21 = (int)(short)(local_20[0] + L'\x01') - *(int *)(DAT_0050b0cc + 10);
    if (*(uint *)(DAT_0050b0cc + 8) <= uVar21) {
      pppppppiStack_158 = (int *******)0x4312f8;
      __vbaGenerateBoundsError();
    }
    iVar7 = (int)(pcVar18 + *(int *)(DAT_0050b0cc + 0xc) * uVar21) * 8;
  }
  pcVar19 = __vbaGenerateBoundsError_exref;
  iVar8 = *(int *)(DAT_0050b0cc + 6);
  *(undefined4 *)(iVar7 + iVar8) = *(undefined4 *)((int)pppppppiVar5 + iVar8);
  uVar22 = *(undefined4 *)((int)pppppppiVar5 + iVar8 + 4);
  *(undefined4 *)(iVar7 + 4 + iVar8) = uVar22;
  uVar16 = (undefined2)((uint)uVar22 >> 0x10);
  pppppppiVar10 = (int *******)(uint)(ushort)((short)local_1c + 1);
  if (SCARRY2((short)local_1c,1)) goto LAB_00431a63;
  goto LAB_00431163;
LAB_004313ba:
  local_20[0] = wVar20 + L'\x01';
  local_20[1] = 0;
  pcVar18 = __vbaStrMove_exref;
  if (wVar13 < local_20[0]) {
    sVar15 = sVar14 + 2;
    local_1c = (int *******)0x3;
    psVar12 = DAT_0050b0cc;
    pppppppiVar5 = (int *******)0x3;
    pppppppiVar10 = local_1c;
    if (!SCARRY2(sVar14,2)) goto LAB_00431756;
    goto LAB_00431a63;
  }
  if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
    pppppppiStack_158 = (int *******)0x431433;
    iVar7 = (*pcVar19)();
  }
  else {
    if ((SBORROW2(local_20[0],DAT_0050b20a)) || (SCARRY2(local_20[0] - DAT_0050b20a,2)))
    goto LAB_00431a63;
    pppppppiVar5 = (int *******)
                   ((int)(short)((local_20[0] - DAT_0050b20a) + 2) - *(int *)(DAT_0050b0cc + 0xe));
    if (*(int ********)(DAT_0050b0cc + 0xc) <= pppppppiVar5) {
      pppppppiStack_158 = (int *******)0x4313ff;
      (*pcVar19)();
    }
    iVar8 = (int)DAT_0050b296;
    iVar7 = *(int *)(DAT_0050b0cc + 10);
    if (*(uint *)(DAT_0050b0cc + 8) <= (uint)(iVar8 - iVar7)) {
      pppppppiStack_158 = (int *******)0x43141e;
      __vbaGenerateBoundsError();
    }
    iVar7 = (int)(*(int *)(DAT_0050b0cc + 0xc) * (iVar8 - iVar7) + (int)pppppppiVar5) * 8;
  }
  if (*(double *)(*(int *)(DAT_0050b0cc + 6) + iVar7) == _DAT_00401878) {
    pppppppiStack_15c = &local_80;
    local_78 = local_20;
    pppppppiStack_158 = (int *******)&DAT_0040d760;
    local_24 = 1;
    local_80 = (int ******)0x4002;
    pppppppiStack_160 = (int *******)0x43146f;
    Ordinal_536();
    pppppppiStack_160 = (int *******)0x431476;
    pppppppiStack_160 = (int *******)__vbaStrMove();
    pppppppiStack_164 = (int *******)0x43147d;
    Ordinal_519();
    pppppppiStack_164 = (int *******)0x431484;
    pppppppiStack_164 = (int *******)__vbaStrMove();
    pppppppiStack_168 = (int *******)0x43148b;
    __vbaStrCat();
    pppppppiStack_168 = (int *******)0x431494;
    __vbaStrMove();
  }
  else {
    pppppppiStack_15c = &local_80;
    local_78 = local_20;
    pppppppiStack_158 = (int *******)&DAT_0040d76c;
    local_24 = 0xffffffff;
    local_80 = (int ******)0x4002;
    pppppppiStack_160 = (int *******)0x4314c1;
    Ordinal_536();
    pppppppiStack_160 = (int *******)0x4314c8;
    pppppppiStack_160 = (int *******)__vbaStrMove();
    pppppppiStack_164 = (int *******)0x4314cf;
    Ordinal_519();
    pppppppiStack_164 = (int *******)0x4314d6;
    pppppppiStack_164 = (int *******)__vbaStrMove();
    pppppppiStack_168 = (int *******)0x4314dd;
    __vbaStrCat();
    pppppppiStack_168 = (int *******)0x4314e6;
    __vbaStrMove();
  }
  pppppppiStack_168 = (int *******)&local_2c;
  pppppppiStack_16c = &local_28;
  pppppppiStack_170 = (int *******)0x2;
  pppppppiStack_174 = (int *******)0x4314f6;
  __vbaFreeStrList();
  pcVar19 = __vbaGenerateBoundsError_exref;
  if ((DAT_0050b39c == (short *)0x0) || (*DAT_0050b39c != 1)) {
    pppppppiStack_168 = (int *******)0x431538;
    __vbaGenerateBoundsError();
  }
  else {
    pppppppiVar5 = (int *******)((int)local_20[0] - *(int *)(DAT_0050b39c + 10));
    if (*(int ********)(DAT_0050b39c + 8) <= pppppppiVar5) {
      pppppppiStack_168 = (int *******)0x431521;
      __vbaGenerateBoundsError();
    }
  }
  pppppppiStack_168 = (int *******)0x43154f;
  __vbaStrCopy();
  if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
    pppppppiStack_158 = (int *******)0x4315a3;
    iVar7 = __vbaGenerateBoundsError();
  }
  else {
    pppppppiVar5 = (int *******)(2 - *(int *)(DAT_0050b0cc + 0xe));
    if (*(int ********)(DAT_0050b0cc + 0xc) <= pppppppiVar5) {
      pppppppiStack_158 = (int *******)0x431572;
      __vbaGenerateBoundsError();
    }
    pcVar19 = (code *)((int)local_20[0] - *(int *)(DAT_0050b0cc + 10));
    if (*(code **)(DAT_0050b0cc + 8) <= pcVar19) {
      pppppppiStack_158 = (int *******)0x43158e;
      __vbaGenerateBoundsError();
    }
    iVar7 = (int)(*(int *)(DAT_0050b0cc + 0xc) * (int)pcVar19 + (int)pppppppiVar5) * 8;
  }
  iVar8 = *(int *)(DAT_0050b0cc + 6);
  *(undefined4 *)(iVar8 + iVar7) = 0;
  *(undefined4 *)(iVar8 + 4 + iVar7) = 0;
  sVar15 = DAT_0050b20c + 2;
  pcVar3 = (code *)0x3;
  pcVar18 = (code *)0x3;
  sVar14 = DAT_0050b20c;
  if (SCARRY2(DAT_0050b20c,2)) goto LAB_00431a63;
  while (pcVar18 = pcVar3, sVar17 = (short)pcVar18, sVar17 <= sVar15) {
    if ((SBORROW2(local_20[0],DAT_0050b20a)) || (SBORROW2(sVar17,2))) goto LAB_00431a63;
    if ((wchar_t)(local_20[0] - DAT_0050b20a) == (wchar_t)(sVar17 + -2)) {
      if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
        pppppppiStack_158 = (int *******)0x43166a;
        iVar7 = __vbaGenerateBoundsError();
      }
      else {
        pcVar19 = (code *)((int)sVar17 - *(int *)(DAT_0050b0cc + 0xe));
        if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar19) {
          pppppppiStack_158 = (int *******)0x431635;
          __vbaGenerateBoundsError();
        }
        pppppppiVar5 = (int *******)((int)local_20[0] - *(int *)(DAT_0050b0cc + 10));
        if (*(int ********)(DAT_0050b0cc + 8) <= pppppppiVar5) {
          pppppppiStack_158 = (int *******)0x431651;
          __vbaGenerateBoundsError();
        }
        iVar7 = (int)(pcVar19 + *(int *)(DAT_0050b0cc + 0xc) * (int)pppppppiVar5) * 8;
      }
      *(double *)(*(int *)(DAT_0050b0cc + 6) + iVar7) = (double)(int)(short)local_24;
    }
    else {
      if ((DAT_0050b0cc == (short *)0x0) || (*DAT_0050b0cc != 2)) {
        pppppppiStack_158 = (int *******)0x4316dc;
        iVar7 = __vbaGenerateBoundsError();
      }
      else {
        pcVar19 = (code *)((int)sVar17 - *(int *)(DAT_0050b0cc + 0xe));
        if (*(code **)(DAT_0050b0cc + 0xc) <= pcVar19) {
          pppppppiStack_158 = (int *******)0x4316a7;
          __vbaGenerateBoundsError();
        }
        pppppppiVar5 = (int *******)((int)local_20[0] - *(int *)(DAT_0050b0cc + 10));
        if (*(int ********)(DAT_0050b0cc + 8) <= pppppppiVar5) {
          pppppppiStack_158 = (int *******)0x4316c3;
          __vbaGenerateBoundsError();
        }
        iVar7 = (int)(pcVar19 + *(int *)(DAT_0050b0cc + 0xc) * (int)pppppppiVar5) * 8;
      }
      iVar8 = *(int *)(DAT_0050b0cc + 6);
      *(undefined4 *)(iVar8 + iVar7) = 0;
      *(undefined4 *)(iVar8 + 4 + iVar7) = 0;
    }
    pcVar3 = (code *)CONCAT22((short)((uint)iVar7 >> 0x10),sVar17 + 1);
    sVar14 = DAT_0050b20c;
    if (SCARRY2(sVar17,1)) goto LAB_00431a63;
  }
  pcVar19 = __vbaGenerateBoundsError_exref;
  wVar20 = local_20[0];
  if (SCARRY2(local_20[0],1)) goto LAB_00431a63;
  goto LAB_004313ba;
LAB_00431756:
  local_1c = pppppppiVar10;
  if (sVar15 < (short)local_1c) {
    pppppppiVar5 = local_1c;
    if (((!SCARRY2(sVar14,DAT_0050b20a)) &&
        (sVar15 = sVar14 + DAT_0050b20a + 2, !SCARRY2(sVar14 + DAT_0050b20a,2))) &&
       (DAT_0050b278 = sVar15, !SCARRY2(sVar14,7))) {
      DAT_0050b276 = sVar14 + 7;
      if (DAT_0050b40c == (int ******)0x0) {
        pppppppiStack_158 = &DAT_0050b40c;
        pppppppiStack_15c = (int *******)&DAT_00403f84;
        pppppppiStack_160 = (int *******)0x431965;
        __vbaNew2();
      }
      ppppppiVar23 = DAT_0050b40c;
      local_80 = (int ******)0xa;
      local_90 = 10;
      pppppppiStack_164 = (int *******)0xa;
      pppppppiStack_160 = local_8c;
      local_88 = (wchar_t *)0x80020004;
      local_78 = (wchar_t *)0x80020004;
      pppppppiStack_15c = (int *******)0x80020004;
      pppppppiStack_178 = (int *******)DAT_0050b40c;
      pppppppiStack_158 = local_84;
      pppppppiStack_174 = (int *******)0xa;
      pppppppiStack_170 = local_7c;
      pppppppiStack_16c = (int *******)0x80020004;
      pppppppiStack_168 = (int *******)local_74;
      pppppppiStack_17c = (int *******)0x4319c6;
      pppppppiStack_180 = (int *******)(*(code *)(*DAT_0050b40c)[0xac])();
      pppppppiStack_17c = (int *******)ppppppiVar23;
joined_r0x004319ca:
      if ((int)pppppppiStack_180 < 0) {
        pppppppiStack_174 = (int *******)0x2b0;
        pppppppiStack_178 = (int *******)&DAT_0040b2f0;
        pppppppiStack_184 = (int *******)0x4319de;
        __vbaHresultCheckObj();
      }
LAB_004319de:
      local_8 = 0;
      pppppppiStack_174 = (int *******)&LAB_00431a3f;
      pppppppiStack_178 = (int *******)&local_d8;
      pppppppiStack_17c = (int *******)local_d4;
      pppppppiStack_180 = (int *******)0x2;
      pppppppiStack_184 = (int *******)0x431a3b;
      __vbaFreeObjList();
      return;
    }
    goto LAB_00431a63;
  }
  if ((psVar12 == (short *)0x0) || (*psVar12 != 2)) {
    pppppppiStack_158 = (int *******)0x4317b6;
    iVar7 = (*pcVar19)();
    psVar12 = DAT_0050b0cc;
    sVar14 = DAT_0050b20c;
  }
  else {
    pcVar18 = (code *)((int)(short)local_1c - *(int *)(psVar12 + 0xe));
    if (*(code **)(psVar12 + 0xc) <= pcVar18) {
      pppppppiStack_158 = (int *******)0x431778;
      (*pcVar19)();
      psVar12 = DAT_0050b0cc;
      sVar14 = DAT_0050b20c;
    }
    iVar8 = (int)DAT_0050b296;
    iVar7 = *(int *)(psVar12 + 10);
    if (*(uint *)(psVar12 + 8) <= (uint)(iVar8 - iVar7)) {
      pppppppiStack_158 = (int *******)0x43179a;
      (*pcVar19)();
      psVar12 = DAT_0050b0cc;
      sVar14 = DAT_0050b20c;
    }
    iVar7 = (int)(pcVar18 + *(int *)(psVar12 + 0xc) * (iVar8 - iVar7)) * 8;
  }
  wVar13 = DAT_0050b296;
  pppppppiVar5 = *(int ********)(psVar12 + 6);
  uVar25 = 0;
  if (*(double *)((int)pppppppiVar5 + iVar7) == _DAT_00401880) {
    local_20[0] = L'\x01';
    wVar20 = local_20[0];
    while (local_20[0] = wVar20, local_20[1] = 0, local_20[0] <= wVar13) {
      if ((psVar12 == (short *)0x0) || (*psVar12 != 2)) {
        pppppppiStack_158 = (int *******)0x431852;
        pppppppiVar5 = (int *******)(*pcVar19)();
        psVar12 = DAT_0050b0cc;
      }
      else {
        pcVar18 = (code *)((int)(short)local_1c - *(int *)(psVar12 + 0xe));
        if (*(code **)(psVar12 + 0xc) <= pcVar18) {
          pppppppiStack_158 = (int *******)0x43181c;
          __vbaGenerateBoundsError();
          psVar12 = DAT_0050b0cc;
        }
        iVar7 = *(int *)(psVar12 + 10);
        iVar8 = (int)local_20[0];
        if (*(uint *)(psVar12 + 8) <= (uint)(iVar8 - iVar7)) {
          pppppppiStack_158 = (int *******)0x43183a;
          __vbaGenerateBoundsError();
          psVar12 = DAT_0050b0cc;
        }
        pppppppiVar5 = (int *******)((int)(pcVar18 + *(int *)(psVar12 + 0xc) * (iVar8 - iVar7)) * 8)
        ;
      }
      if ((psVar12 == (short *)0x0) || (*psVar12 != 2)) {
        pppppppiStack_158 = (int *******)0x4318b4;
        iVar7 = __vbaGenerateBoundsError();
        psVar12 = DAT_0050b0cc;
      }
      else {
        pcVar18 = (code *)((int)(short)local_1c - *(int *)(psVar12 + 0xe));
        if (*(code **)(psVar12 + 0xc) <= pcVar18) {
          pppppppiStack_158 = (int *******)0x43187d;
          __vbaGenerateBoundsError();
          psVar12 = DAT_0050b0cc;
        }
        iVar7 = *(int *)(psVar12 + 10);
        iVar8 = (int)local_20[0];
        if (*(uint *)(psVar12 + 8) <= (uint)(iVar8 - iVar7)) {
          pppppppiStack_158 = (int *******)0x43189b;
          __vbaGenerateBoundsError();
          psVar12 = DAT_0050b0cc;
        }
        iVar7 = (int)(pcVar18 + *(int *)(psVar12 + 0xc) * (iVar8 - iVar7)) * 8;
      }
      pcVar19 = __vbaGenerateBoundsError_exref;
      *(double *)(*(int *)(psVar12 + 6) + iVar7) =
           -*(double *)(*(int *)(psVar12 + 6) + (int)pppppppiVar5);
      if ((uVar25 & 0xd) != 0) goto LAB_00431a5e;
      psVar12 = DAT_0050b0cc;
      sVar14 = DAT_0050b20c;
      wVar20 = local_20[0] + L'\x01';
      if (SCARRY2(local_20[0],1)) goto LAB_00431a63;
    }
  }
  pppppppiVar10 = (int *******)(uint)(ushort)((short)local_1c + 1);
  if (SCARRY2((short)local_1c,1)) goto LAB_00431a63;
  goto LAB_00431756;
}


