/* entry 004ede00 name FUN_004ede00 size 3988 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ede00(void)

{
  float ****ppppfVar1;
  float ****ppppfVar2;
  float **ppfVar3;
  float *****pppppfVar4;
  code *pcVar5;
  code **ppcVar6;
  short sVar7;
  undefined4 uVar8;
  float *****pppppfVar9;
  float *******pppppppfVar10;
  float *******pppppppfVar11;
  int *piVar12;
  int iVar13;
  undefined2 extraout_var;
  undefined2 extraout_var_00;
  float *******extraout_EDX;
  undefined2 uVar14;
  undefined2 extraout_var_01;
  undefined2 extraout_var_02;
  undefined2 extraout_var_03;
  int iVar15;
  code *pcVar16;
  float ******ppppppfVar17;
  float *******pppppppfVar18;
  int iVar19;
  uint uVar20;
  float ******ppppppfVar21;
  code *pcVar22;
  ushort in_FPUStatusWord;
  ushort uVar23;
  float10 fVar24;
  double dVar25;
  code *pcStack_5b8;
  float ******ppppppfStack_5b4;
  float ******ppppppfStack_5b0;
  undefined8 uStack_5ac;
  int iStack_5a4;
  undefined8 uStack_5a0;
  float ******ppppppfStack_598;
  undefined8 uStack_594;
  float ******ppppppfStack_58c;
  undefined8 uStack_588;
  float ******ppppppfStack_580;
  float ******ppppppfStack_57c;
  float ******ppppppfStack_578;
  float ******ppppppfStack_574;
  float ******ppppppfStack_570;
  float ******ppppppfStack_56c;
  float ******ppppppfStack_568;
  float ******ppppppfStack_564;
  float ******ppppppfStack_560;
  float ******ppppppfStack_55c;
  float ******ppppppfStack_558;
  float ******ppppppfStack_554;
  float ******ppppppfStack_550;
  float ******ppppppfStack_54c;
  float ******ppppppfStack_548;
  float ******ppppppfStack_544;
  float ******ppppppfStack_540;
  float ******ppppppfStack_53c;
  undefined8 uStack_538;
  float ******ppppppfStack_530;
  float ******ppppppfStack_52c;
  float ******ppppppfStack_528;
  float ******ppppppfStack_524;
  float ******ppppppfStack_520;
  float ******ppppppfStack_51c;
  float ******ppppppfStack_518;
  float ******ppppppfStack_514;
  float ******ppppppfStack_510;
  float ******ppppppfStack_50c;
  float ******ppppppfStack_508;
  float ******ppppppfStack_504;
  float ******ppppppfStack_500;
  float ******ppppppfStack_4fc;
  float ******ppppppfStack_4f8;
  float ******ppppppfStack_4f4;
  undefined *puStack_4f0;
  float ******ppppppfStack_4ec;
  float ******ppppppfStack_4e8;
  undefined4 uStack_4e4;
  undefined4 uStack_4e0;
  float ******ppppppfStack_4dc;
  undefined4 uStack_4d8;
  float ******ppppppfStack_4d4;
  undefined4 uStack_4d0;
  int iStack_4cc;
  float ******ppppppfStack_4c8;
  undefined *puStack_4c4;
  float ******ppppppfStack_4c0;
  int *piStack_4bc;
  int iStack_4b8;
  float ******ppppppfStack_4b4;
  undefined *puStack_4b0;
  float ******ppppppfStack_4ac;
  float ******ppppppfStack_4a8;
  undefined4 uStack_4a4;
  float ******ppppppfStack_4a0;
  undefined4 uStack_49c;
  float *****pppppfStack_498;
  float ******ppppppfStack_494;
  undefined *puStack_490;
  float ******ppppppfStack_48c;
  float ******ppppppfStack_488;
  float ******ppppppfStack_484;
  float ******ppppppfStack_480;
  undefined4 uStack_47c;
  float *****pppppfStack_478;
  float ******ppppppfStack_474;
  undefined *puStack_470;
  float ******ppppppfStack_46c;
  float ******ppppppfStack_468;
  float ******ppppppfStack_464;
  float ******ppppppfStack_460;
  undefined4 uStack_45c;
  float ******ppppppfStack_458;
  undefined4 uStack_454;
  float *****pppppfStack_450;
  float ******ppppppfStack_44c;
  wchar_t *pwStack_448;
  float ******ppppppfStack_444;
  float ******ppppppfStack_440;
  float ******ppppppfStack_43c;
  float ******ppppppfStack_438;
  float ******ppppppfStack_434;
  code *pcStack_430;
  float *****pppppfStack_42c;
  float *****pppppfStack_428;
  int iStack_424;
  int iStack_420;
  float fStack_41c;
  float fStack_418;
  float *****pppppfStack_414;
  int iStack_410;
  float fStack_40c;
  float fStack_408;
  int iStack_404;
  short sStack_3e4;
  undefined4 uStack_3d4;
  undefined4 uStack_3d0;
  undefined4 uStack_3bc;
  undefined4 uStack_3b4;
  undefined4 uStack_3ac;
  undefined4 uStack_3a8;
  undefined4 uStack_394;
  float ******ppppppfStack_384;
  float ******appppppfStack_380 [6];
  float ******ppppppfStack_368;
  float ******ppppppfStack_364;
  float ******ppppppfStack_360;
  undefined8 uStack_35c;
  float ******ppppppfStack_354;
  float *****pppppfStack_350;
  float ******appppppfStack_34c [9];
  undefined4 uStack_328;
  float ******ppppppfStack_324;
  float ******ppppppfStack_31c;
  undefined4 uStack_318;
  float ******ppppppfStack_314;
  float *****pppppfStack_30c;
  float ******ppppppfStack_308;
  float ******ppppppfStack_304;
  undefined4 uStack_300;
  float ******ppppppfStack_2fc;
  float *****pppppfStack_2f8;
  float *****pppppfStack_2f4;
  float *****pppppfStack_2f0;
  undefined4 uStack_2ec;
  float ******ppppppfStack_2e8;
  float ******ppppppfStack_2e4;
  float ******ppppppfStack_2e0;
  float ******ppppppfStack_2dc;
  float *****pppppfStack_2d8;
  float ******ppppppfStack_2d4;
  float ******ppppppfStack_2d0;
  float *****pppppfStack_2cc;
  float *****pppppfStack_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  float ******ppppppfStack_2bc;
  float *****apppppfStack_2b8 [2];
  float *****pppppfStack_2b0;
  float *****pppppfStack_2a8;
  float ******ppppppfStack_2a4;
  float ******ppppppfStack_2a0;
  float ******ppppppfStack_29c;
  float *****pppppfStack_298;
  float *****pppppfStack_294;
  float ******ppppppfStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  float *****pppppfStack_280;
  float ******ppppppfStack_27c;
  float *****pppppfStack_278;
  float ******ppppppfStack_274;
  float ****ppppfStack_270;
  float *****pppppfStack_26c;
  float ******ppppppfStack_268;
  float *****pppppfStack_264;
  float ******ppppppfStack_260;
  float ******ppppppfStack_25c;
  float *****pppppfStack_258;
  uint uStack_254;
  float *****pppppfStack_250;
  float *****pppppfStack_24c;
  float *****pppppfStack_248;
  undefined4 *puStack_244;
  wchar_t *pwStack_240;
  float ******ppppppfStack_23c;
  code *pcStack_238;
  float *****pppppfStack_234;
  code *pcStack_230;
  float *****pppppfStack_22c;
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  float ****ppppfStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  float *****pppppfStack_20c;
  float *****pppppfStack_208;
  float ***pppfStack_204;
  undefined4 uStack_200;
  float *****pppppfStack_1fc;
  float *****pppppfStack_1f8;
  float *****pppppfStack_1f4;
  float ****ppppfStack_1f0;
  float ***pppfStack_1ec;
  float *****pppppfStack_1e8;
  float *****pppppfStack_1e4;
  float ****ppppfStack_1e0;
  undefined4 uStack_1dc;
  float ****ppppfStack_1d8;
  float ****ppppfStack_1d4;
  float *****pppppfStack_1d0;
  float ****ppppfStack_1cc;
  float ***pppfStack_1c8;
  float *****pppppfStack_1c4;
  float *****pppppfStack_1c0;
  float ****ppppfStack_1bc;
  undefined4 uStack_1b8;
  float *****pppppfStack_1b4;
  float ****ppppfStack_1b0;
  float *****pppppfStack_1ac;
  float ****ppppfStack_1a8;
  float ***pppfStack_1a4;
  float *****pppppfStack_1a0;
  float *****pppppfStack_19c;
  float ****ppppfStack_198;
  undefined4 uStack_194;
  float ****ppppfStack_190;
  float ****ppppfStack_18c;
  float *****pppppfStack_188;
  float ****ppppfStack_184;
  float ***pppfStack_180;
  float *****pppppfStack_17c;
  float ***pppfStack_178;
  float *****pppppfStack_174;
  float *****pppppfStack_170;
  float ****ppppfStack_16c;
  float *****pppppfStack_168;
  float ******ppppppfStack_164;
  float *****pppppfStack_160;
  float *****pppppfStack_15c;
  float *****pppppfStack_158;
  float *****pppppfStack_154;
  float *****pppppfStack_150;
  float *****pppppfStack_14c;
  float *****pppppfStack_148;
  float *****pppppfStack_144;
  float ******ppppppfStack_140;
  float *****pppppfStack_13c;
  float *****pppppfStack_138;
  float ******ppppppfStack_134;
  undefined4 uStack_130;
  float *****pppppfStack_12c;
  undefined *puStack_128;
  float ******ppppppfStack_124;
  float *****local_110;
  int local_10c;
  int local_100;
  float *****local_dc;
  float *****local_d8;
  float *****local_d4;
  uint local_d0;
  float ***local_c8;
  float ***local_c4;
  undefined4 local_b0;
  float *****local_ac;
  undefined4 local_a4;
  undefined4 local_a0;
  float *****local_9c;
  undefined4 local_98;
  float ***local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined4 local_84;
  undefined4 local_80;
  float ***local_7c;
  float *****local_74;
  float ***local_70;
  float *****local_6c;
  float *****local_68;
  float *****local_64;
  float ****local_60;
  float ****local_5c;
  float ****local_58;
  undefined4 local_54;
  float ****local_50 [4];
  float ****local_40 [2];
  undefined4 local_38;
  undefined4 local_30;
  float ***local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffee0;
  local_8 = &DAT_00402580;
  local_2c = (float ***)0x0;
  local_30 = 0;
  local_40[0] = (float ****)0x0;
  local_50[0] = (float ****)0x0;
  local_60 = (float ****)0x0;
  local_70 = (float ***)0x0;
  local_80 = 0;
  local_90 = 0;
  local_a0 = 0;
  local_b0 = 0;
  local_dc = (float *****)0x0;
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_124 = (float ******)0x4edeb7;
    ExceptionList = &pvStack_14;
    iVar19 = __vbaGenerateBoundsError();
  }
  else {
    local_d0 = -*(int *)(DAT_0050b19c + 0xe);
    ExceptionList = &pvStack_14;
    local_c = &stack0xfffffee0;
    if (*(uint *)(DAT_0050b19c + 0xc) <= local_d0) {
      ppppppfStack_124 = (float ******)0x4ede84;
      ExceptionList = &pvStack_14;
      local_c = &stack0xfffffee0;
      __vbaGenerateBoundsError();
    }
    iVar19 = *(int *)(DAT_0050b19c + 10);
    if (*(uint *)(DAT_0050b19c + 8) <= (uint)-iVar19) {
      ppppppfStack_124 = (float ******)0x4ede97;
      __vbaGenerateBoundsError();
    }
    iVar19 = (*(int *)(DAT_0050b19c + 0xc) * -iVar19 + local_d0) * 4;
  }
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_124 = (float ******)0x4edf07;
    iVar13 = __vbaGenerateBoundsError();
  }
  else {
    local_c8 = (float ***)-*(int *)(DAT_0050b19c + 0xe);
    if (*(float *****)(DAT_0050b19c + 0xc) <= local_c8) {
      ppppppfStack_124 = (float ******)0x4ededc;
      __vbaGenerateBoundsError();
    }
    iVar13 = *(int *)(DAT_0050b19c + 10);
    if (*(uint *)(DAT_0050b19c + 8) <= (uint)-iVar13) {
      ppppppfStack_124 = (float ******)0x4edeef;
      __vbaGenerateBoundsError();
    }
    iVar13 = (int)(*(int *)(DAT_0050b19c + 0xc) * -iVar13 + (int)local_c8) * 4;
  }
  *(float *)(*(int *)(DAT_0050b19c + 6) + iVar13) =
       *(float *)(*(int *)(DAT_0050b19c + 6) + iVar19) + _DAT_00402478;
  if ((in_FPUStatusWord & 0xd) != 0) {
LAB_004eedc1:
    __vbaFPException();
    return;
  }
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_124 = (float ******)0x4edf6e;
    __vbaGenerateBoundsError();
  }
  else {
    if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-*(int *)(DAT_0050b19c + 0xe)) {
      ppppppfStack_124 = (float ******)0x4edf45;
      __vbaGenerateBoundsError();
    }
    if (*(uint *)(DAT_0050b19c + 8) <= (uint)-*(int *)(DAT_0050b19c + 10)) {
      ppppppfStack_124 = (float ******)0x4edf59;
      __vbaGenerateBoundsError();
    }
  }
  ppppppfStack_124 = (float ******)0x4edf80;
  local_28 = __vbaFpI2();
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_124 = (float ******)0x4edfd2;
    __vbaGenerateBoundsError();
  }
  else {
    if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)((int)(short)local_28 - *(int *)(DAT_0050b19c + 0xe))
       ) {
      ppppppfStack_124 = (float ******)0x4edfa4;
      __vbaGenerateBoundsError();
    }
    if (*(uint *)(DAT_0050b19c + 8) <= 1U - *(int *)(DAT_0050b19c + 10)) {
      ppppppfStack_124 = (float ******)0x4edfbd;
      __vbaGenerateBoundsError();
    }
  }
  ppppppfStack_124 = (float ******)0x4edfe4;
  uVar8 = __vbaFpI2();
  local_20 = uVar8;
  if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
    ppppppfStack_124 = (float ******)0x4ee03c;
    __vbaGenerateBoundsError();
  }
  else {
    if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)((int)(short)local_28 - *(int *)(DAT_0050b19c + 0xe))
       ) {
      ppppppfStack_124 = (float ******)0x4ee00b;
      __vbaGenerateBoundsError();
    }
    uVar8 = local_20;
    if (*(uint *)(DAT_0050b19c + 8) <= 2U - *(int *)(DAT_0050b19c + 10)) {
      ppppppfStack_124 = (float ******)0x4ee024;
      __vbaGenerateBoundsError();
      uVar8 = local_20;
    }
  }
  ppppppfStack_124 = (float ******)0x4ee04e;
  local_24 = __vbaFpI2();
  if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
    ppppppfStack_124 = (float ******)0x4ee083;
    local_100 = __vbaGenerateBoundsError();
  }
  else {
    uVar20 = (int)(short)local_24 - *(int *)(DAT_0050b3d8 + 10);
    if (*(uint *)(DAT_0050b3d8 + 8) <= uVar20) {
      ppppppfStack_124 = (float ******)0x4ee072;
      __vbaGenerateBoundsError();
    }
    local_100 = uVar20 * 4;
  }
  if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
    ppppppfStack_124 = (float ******)0x4ee0b4;
    iVar19 = __vbaGenerateBoundsError();
  }
  else {
    ppppppfVar21 = (float ******)((int)(short)uVar8 - (int)DAT_0050b3d4[5]);
    if (DAT_0050b3d4[4] <= ppppppfVar21) {
      ppppppfStack_124 = (float ******)0x4ee0a9;
      __vbaGenerateBoundsError();
    }
    iVar19 = (int)ppppppfVar21 * 4;
  }
  if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
    ppppppfStack_124 = (float ******)0x4ee105;
    iVar13 = __vbaGenerateBoundsError();
  }
  else {
    ppppppfVar21 = (float ******)((int)(short)uVar8 - (int)DAT_0050b3cc[7]);
    if (DAT_0050b3cc[6] <= ppppppfVar21) {
      ppppppfStack_124 = (float ******)0x4ee0da;
      __vbaGenerateBoundsError();
    }
    iVar13 = (int)(short)local_24;
    ppppppfVar17 = DAT_0050b3cc[5];
    if (DAT_0050b3cc[4] <= (float ******)(iVar13 - (int)ppppppfVar17)) {
      ppppppfStack_124 = (float ******)0x4ee0f1;
      __vbaGenerateBoundsError();
    }
    iVar13 = (int)((int)DAT_0050b3cc[6] * (iVar13 - (int)ppppppfVar17) + (int)ppppppfVar21) * 4;
  }
  if ((DAT_0050b3e4 == (float *****)0x0) || (*(short *)DAT_0050b3e4 != 2)) {
    ppppppfStack_124 = (float ******)0x4ee15b;
    iVar15 = __vbaGenerateBoundsError();
  }
  else {
    iVar15 = (int)(short)local_28;
    ppppfVar1 = DAT_0050b3e4[7];
    if (DAT_0050b3e4[6] <= (float ****)(iVar15 - (int)ppppfVar1)) {
      ppppppfStack_124 = (float ******)0x4ee12d;
      __vbaGenerateBoundsError();
    }
    ppppfVar2 = DAT_0050b3e4[5];
    if (DAT_0050b3e4[4] <= (float ****)(1U - (int)ppppfVar2)) {
      ppppppfStack_124 = (float ******)0x4ee146;
      __vbaGenerateBoundsError();
    }
    iVar15 = (int)((int)DAT_0050b3e4[6] * (int)(1U - (int)ppppfVar2) + (iVar15 - (int)ppppfVar1)) *
             4;
  }
  *(float *)((int)DAT_0050b3e4[3] + iVar15) =
       (*(float *)(*(int *)(DAT_0050b3d8 + 6) + local_100) -
       *(float *)((int)DAT_0050b3d4[3] + iVar19)) - *(float *)((int)DAT_0050b3cc[3] + iVar13);
  if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004eedc1;
  if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
    ppppppfStack_124 = (float ******)0x4ee1de;
    local_10c = __vbaGenerateBoundsError();
  }
  else {
    iVar19 = (int)(short)local_24;
    ppppppfVar21 = DAT_0050b3d4[5];
    if (DAT_0050b3d4[4] <= (float ******)(iVar19 - (int)ppppppfVar21)) {
      ppppppfStack_124 = (float ******)0x4ee1c8;
      __vbaGenerateBoundsError();
    }
    local_10c = (iVar19 - (int)ppppppfVar21) * 4;
  }
  if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
    ppppppfStack_124 = (float ******)0x4ee216;
    local_110 = (float *****)__vbaGenerateBoundsError();
  }
  else {
    iVar19 = (int)(short)local_20;
    ppppppfVar21 = DAT_0050b3d4[5];
    if (DAT_0050b3d4[4] <= (float ******)(iVar19 - (int)ppppppfVar21)) {
      ppppppfStack_124 = (float ******)0x4ee205;
      __vbaGenerateBoundsError();
    }
    local_110 = (float *****)((iVar19 - (int)ppppppfVar21) * 4);
  }
  if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
    ppppppfStack_124 = (float ******)0x4ee281;
    iVar19 = __vbaGenerateBoundsError();
  }
  else {
    local_d8 = (float *****)((int)(short)local_20 - (int)DAT_0050b3cc[7]);
    if (DAT_0050b3cc[6] <= local_d8) {
      ppppppfStack_124 = (float ******)0x4ee244;
      __vbaGenerateBoundsError();
    }
    local_d4 = (float *****)((int)(short)local_24 - (int)DAT_0050b3cc[5]);
    if (DAT_0050b3cc[4] <= local_d4) {
      ppppppfStack_124 = (float ******)0x4ee262;
      __vbaGenerateBoundsError();
    }
    iVar19 = (int)((int)DAT_0050b3cc[6] * (int)local_d4 + (int)local_d8) * 4;
  }
  if ((DAT_0050b3e4 == (float *****)0x0) || (*(short *)DAT_0050b3e4 != 2)) {
    ppppppfStack_124 = (float ******)0x4ee2fd;
    iVar13 = __vbaGenerateBoundsError();
  }
  else {
    local_c8 = (float ***)((int)(short)local_28 - (int)DAT_0050b3e4[7]);
    if (DAT_0050b3e4[6] <= local_c8) {
      ppppppfStack_124 = (float ******)0x4ee2b1;
      __vbaGenerateBoundsError();
    }
    local_c4 = (float ***)(2 - (int)DAT_0050b3e4[5]);
    if (DAT_0050b3e4[4] <= local_c4) {
      ppppppfStack_124 = (float ******)0x4ee2d6;
      __vbaGenerateBoundsError();
    }
    iVar13 = (int)((int)DAT_0050b3e4[6] * (int)local_c4 + (int)local_c8) * 4;
  }
  *(float *)((int)DAT_0050b3e4[3] + iVar13) =
       (*(float *)(local_10c + (int)DAT_0050b3d4[3]) -
       *(float *)((int)local_110 + (int)DAT_0050b3d4[3])) -
       *(float *)((int)DAT_0050b3cc[3] + iVar19);
  if ((in_FPUStatusWord & 0xd) != 0) goto LAB_004eedc1;
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_124 = (float ******)&DAT_0050b420;
    puStack_128 = &DAT_00408c88;
    pppppfStack_12c = (float *****)0x4ee354;
    __vbaNew2();
  }
  ppppppfStack_124 = (float ******)DAT_0050b420;
  puStack_128 = (undefined *)0x4ee362;
  puStack_128 = (undefined *)(*(code *)(*DAT_0050b420)[0xea])();
  pppppfStack_12c = (float *****)&local_dc;
  uStack_130 = 0x4ee370;
  __vbaObjSet();
  pcVar22 = __vbaLateIdCallLd_exref;
  uStack_130 = 0;
  ppppppfStack_134 = (float ******)0x4;
  pppppfStack_13c = local_40;
  pppppfStack_138 = local_dc;
  ppppppfStack_140 = (float ******)0x4ee387;
  uStack_130 = __vbaLateIdCallLd();
  pcVar16 = __vbaI4Var_exref;
  ppppppfStack_134 = (float ******)0x4ee393;
  iVar19 = __vbaI4Var();
  pcVar5 = __vbaLateIdSt_exref;
  if (!SCARRY4(iVar19,1)) {
    local_70 = (float ***)0x3;
    pppppfStack_144 = (float *****)0x4;
    ppppppfStack_140 = (float ******)0x3;
    pppppfStack_13c = local_6c;
    pppppfStack_148 = local_dc;
    ppppppfStack_134 = (float ******)local_64;
    pppppfStack_14c = (float *****)0x4ee3ce;
    pppppfStack_138 = (float *****)(iVar19 + 1);
    local_68 = (float *****)(iVar19 + 1);
    __vbaLateIdSt();
    pppppfStack_14c = (float *****)0x4ee3d7;
    __vbaFreeVar();
    pppppfStack_14c = (float *****)0x0;
    pppppfStack_150 = (float *****)0x4;
    pppppfStack_158 = local_40;
    pppppfStack_154 = local_dc;
    pppppfStack_15c = (float *****)0x4ee3e8;
    pppppfStack_14c = (float *****)__vbaLateIdCallLd();
    pppppfStack_150 = (float *****)0x4ee3ee;
    iVar19 = __vbaI4Var();
    local_110 = (float *****)pcVar5;
    if (!SBORROW4(iVar19,1)) {
      local_70 = (float ***)0x3;
      pppppfStack_144 = (float *****)0xa;
      ppppppfStack_140 = (float ******)0x3;
      pppppfStack_13c = local_6c;
      pppppfStack_148 = local_dc;
      ppppppfStack_134 = (float ******)local_64;
      pppppfStack_14c = (float *****)0x4ee423;
      pppppfStack_138 = (float *****)(iVar19 + -1);
      local_68 = (float *****)(iVar19 + -1);
      __vbaLateIdSt();
      pppppfStack_14c = (float *****)0x4ee42c;
      __vbaFreeVar();
      pppppfStack_14c = (float *****)0x0;
      pppppfStack_150 = (float *****)0xa;
      pppppfStack_158 = local_40;
      pppppfStack_154 = local_dc;
      pppppfStack_15c = (float *****)0x4ee43d;
      pppppfStack_14c = (float *****)__vbaLateIdCallLd();
      pppppfStack_150 = (float *****)0x4ee443;
      __vbaI4Var();
      pppppfStack_150 = (float *****)0x4ee44b;
      local_18 = __vbaI2I4();
      pppppfStack_150 = (float *****)0x4ee457;
      __vbaFreeVar();
      local_70 = (float ***)0x3;
      pppppfStack_160 = (float *****)0xb;
      pppppfStack_15c = (float *****)0x3;
      local_68 = (float *****)0x0;
      pppppfStack_158 = local_6c;
      ppppppfStack_164 = (float ******)local_dc;
      pppppfStack_154 = (float *****)0x0;
      pppppfStack_150 = local_64;
      pppppfStack_168 = (float *****)0x4ee485;
      __vbaLateIdSt();
      local_70 = (float ***)0x2;
      pppfStack_178 = (float ***)0x28;
      pppppfStack_174 = (float *****)0x2;
      local_68 = (float *****)0x1;
      pppppfStack_170 = local_6c;
      pppppfStack_17c = local_dc;
      ppppfStack_16c = (float ****)0x1;
      pppppfStack_168 = local_64;
      pppfStack_180 = (float ***)0x4ee4b6;
      __vbaLateIdSt();
      if ((DAT_0050b3e4 == (float *****)0x0) || (*(short *)DAT_0050b3e4 != 2)) {
        ppppppfStack_134 = (float ******)0x4ee512;
        iVar19 = __vbaGenerateBoundsError();
      }
      else {
        iVar19 = (int)(short)local_28;
        ppppfVar1 = DAT_0050b3e4[7];
        if (DAT_0050b3e4[6] <= (float ****)(iVar19 - (int)ppppfVar1)) {
          ppppppfStack_134 = (float ******)0x4ee4dc;
          __vbaGenerateBoundsError();
        }
        ppppfVar2 = DAT_0050b3e4[5];
        if (DAT_0050b3e4[4] <= (float ****)(1U - (int)ppppfVar2)) {
          ppppppfStack_134 = (float ******)0x4ee4f9;
          __vbaGenerateBoundsError();
        }
        iVar19 = (int)((int)DAT_0050b3e4[6] * (int)(1U - (int)ppppfVar2) + (iVar19 - (int)ppppfVar1)
                      ) * 4;
      }
      if (*(float *)((int)DAT_0050b3e4[3] + iVar19) != _DAT_00401bc0) {
LAB_004ee5b0:
        pppppfVar9 = (float *****)(int)(short)local_18;
        pppppfStack_138 = (float *****)&local_2c;
        ppppppfStack_134 = (float ******)DAT_0050b3d0;
        local_70 = (float ***)0x3;
        pppppfStack_13c = (float *****)0x4ee5d7;
        local_68 = pppppfVar9;
        __vbaAryLock();
        if ((local_2c == (float ***)0x0) || (*(short *)local_2c != 1)) {
          pppppfStack_13c = (float *****)0x4ee60c;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          iVar19 = (int)(short)local_28;
          ppfVar3 = local_2c[5];
          if (local_2c[4] <= (float **)(iVar19 - (int)ppfVar3)) {
            pppppfStack_13c = (float *****)0x4ee5fa;
            __vbaGenerateBoundsError();
          }
          iVar19 = (iVar19 - (int)ppfVar3) * 4;
        }
        pppppfStack_148 = (float *****)local_70;
        pppppfStack_160 = (float *****)((int)local_2c[3] + iVar19);
        pppppfStack_144 = local_6c;
        ppppppfStack_140 = (float ******)local_68;
        pppppfStack_13c = local_64;
        pppppfStack_158 = (float *****)0x3;
        pppppfStack_154 = (float *****)local_8c;
        pppppfStack_150 = (float *****)0x0;
        pppppfStack_14c = (float *****)local_84;
        ppppfStack_16c = (float ****)0x2;
        pppppfStack_168 = (float *****)0x4008;
        pppppfStack_170 = (float *****)0x41;
        ppppppfStack_164 = (float ******)local_ac;
        pppppfStack_15c = (float *****)local_a4;
        pppppfStack_174 = local_dc;
        pppfStack_178 = (float ***)0x4ee67d;
        __vbaLateIdCallSt();
        pppppfStack_13c = (float *****)&local_2c;
        ppppppfStack_140 = (float ******)0x4ee68c;
        __vbaAryUnlock();
        ppppppfStack_140 = (float ******)0x4ee691;
        FUN_0044fdc0();
        ppppppfStack_140 = (float ******)0x4ee69c;
        __vbaStrMove();
        local_38 = local_30;
        pppppfStack_144 = (float *****)&local_2c;
        ppppppfStack_140 = (float ******)DAT_0050b3cc;
        local_30 = 0;
        local_40[0] = (float ****)0x8;
        pppppfStack_148 = (float *****)0x4ee6c1;
        __vbaAryLock();
        if ((local_2c == (float ***)0x0) || (*(short *)local_2c != 2)) {
          pppppfStack_148 = (float *****)0x4ee71d;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          local_c8 = (float ***)((int)(short)local_20 - (int)local_2c[7]);
          if (local_2c[6] <= local_c8) {
            pppppfStack_148 = (float *****)0x4ee6ea;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)(short)local_24;
          ppfVar3 = local_2c[5];
          if (local_2c[4] <= (float **)(iVar19 - (int)ppfVar3)) {
            pppppfStack_148 = (float *****)0x4ee703;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)((int)local_2c[6] * (iVar19 - (int)ppfVar3) + (int)local_c8) * 4;
        }
        local_68 = (float *****)((int)local_2c[3] + iVar19);
        pppppfStack_148 = (float *****)0x1;
        pppppfStack_150 = local_40;
        pppppfStack_14c = (float *****)0x1;
        pppppfStack_154 = (float *****)&local_70;
        pppppfStack_158 = local_50;
        local_70 = (float ***)0x4004;
        pppppfStack_15c = (float *****)0x4ee747;
        Ordinal_660();
        pppppfStack_15c = (float *****)&local_2c;
        pppppfStack_160 = (float *****)0x4ee74d;
        __vbaAryUnlock();
        pppppfStack_160 = local_50;
        ppppppfStack_164 = (float ******)0x4ee757;
        pppppfStack_188 = (float *****)__vbaStrVarMove();
        local_60 = (float ****)0x8;
        pppppfStack_170 = (float *****)0x3;
        ppppfStack_16c = (float ****)local_7c;
        ppppppfStack_164 = (float ******)local_74;
        pppfStack_180 = (float ***)0x3;
        pppppfStack_17c = local_9c;
        pppfStack_178 = (float ***)0x1;
        pppppfStack_174 = (float *****)local_94;
        uStack_194 = 2;
        ppppfStack_198 = (float ****)0x41;
        ppppfStack_190 = (float ****)0x8;
        ppppfStack_18c = local_5c;
        pppppfStack_19c = local_dc;
        ppppfStack_184 = (float ****)local_54;
        pppppfStack_1a0 = (float *****)0x4ee7ce;
        pppppfStack_168 = pppppfVar9;
        local_58 = (float ****)pppppfStack_188;
        __vbaLateIdCallSt();
        ppppppfStack_164 = (float ******)0x4ee7da;
        __vbaFreeStr();
        ppppppfStack_164 = (float ******)&local_60;
        pppppfStack_168 = local_50;
        ppppfStack_16c = (float ****)local_40;
        pppppfStack_170 = (float *****)0x3;
        pppppfStack_174 = (float *****)0x4ee7ee;
        __vbaFreeVarList();
        ppppppfStack_164 = (float ******)0x4ee7f6;
        FUN_0044fdc0();
        ppppppfStack_164 = (float ******)0x4ee801;
        __vbaStrMove();
        local_38 = local_30;
        pppppfStack_168 = (float *****)&local_2c;
        ppppppfStack_164 = (float ******)DAT_0050b3d4;
        local_30 = 0;
        local_40[0] = (float ****)0x8;
        ppppfStack_16c = (float ****)0x4ee826;
        __vbaAryLock();
        if ((local_2c == (float ***)0x0) || (*(short *)local_2c != 1)) {
          ppppfStack_16c = (float ****)0x4ee863;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          local_c4 = (float ***)((int)(short)local_20 - (int)local_2c[5]);
          if (local_2c[4] <= local_c4) {
            ppppfStack_16c = (float ****)0x4ee84f;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)local_c4 << 2;
        }
        ppppfStack_16c = (float ****)0x1;
        local_68 = (float *****)((int)local_2c[3] + iVar19);
        pppppfStack_174 = local_40;
        pppppfStack_170 = (float *****)0x1;
        pppfStack_178 = (float ***)&local_70;
        pppppfStack_17c = local_50;
        local_70 = (float ***)0x4004;
        pppfStack_180 = (float ***)0x4ee887;
        Ordinal_660();
        pppfStack_180 = (float ***)&local_2c;
        ppppfStack_184 = (float ****)0x4ee88d;
        __vbaAryUnlock();
        ppppfStack_184 = (float ****)local_50;
        pppppfStack_188 = (float *****)0x4ee897;
        pppppfStack_1ac = (float *****)__vbaStrVarMove();
        local_60 = (float ****)0x8;
        uStack_194 = 3;
        ppppfStack_190 = (float ****)local_7c;
        pppppfStack_188 = local_74;
        pppfStack_1a4 = (float ***)0x3;
        pppppfStack_1a0 = local_9c;
        pppppfStack_19c = (float *****)0x2;
        ppppfStack_198 = (float ****)local_94;
        uStack_1b8 = 2;
        ppppfStack_1bc = (float ****)0x41;
        pppppfStack_1b4 = (float *****)0x8;
        ppppfStack_1b0 = local_5c;
        pppppfStack_1c0 = local_dc;
        ppppfStack_1a8 = (float ****)local_54;
        pppppfStack_1c4 = (float *****)0x4ee90e;
        ppppfStack_18c = (float ****)pppppfVar9;
        local_58 = (float ****)pppppfStack_1ac;
        __vbaLateIdCallSt();
        pppppfStack_188 = (float *****)0x4ee91a;
        __vbaFreeStr();
        pppppfStack_188 = &local_60;
        ppppfStack_18c = (float ****)local_50;
        ppppfStack_190 = (float ****)local_40;
        uStack_194 = 3;
        ppppfStack_198 = (float ****)0x4ee92e;
        __vbaFreeVarList();
        pppppfStack_188 = (float *****)0x4ee936;
        FUN_0044fdc0();
        pppppfStack_188 = (float *****)0x4ee941;
        __vbaStrMove();
        local_38 = local_30;
        ppppfStack_18c = &local_2c;
        pppppfStack_188 = (float *****)DAT_0050b3d8;
        local_98 = 4;
        local_30 = 0;
        local_40[0] = (float ****)0x8;
        ppppfStack_190 = (float ****)0x4ee970;
        __vbaAryLock();
        if ((local_2c == (float ***)0x0) || (*(short *)local_2c != 1)) {
          ppppfStack_190 = (float ****)0x4ee9ad;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          local_c4 = (float ***)((int)(short)local_24 - (int)local_2c[5]);
          if (local_2c[4] <= local_c4) {
            ppppfStack_190 = (float ****)0x4ee999;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)local_c4 << 2;
        }
        ppppfStack_190 = (float ****)0x1;
        local_68 = (float *****)((int)local_2c[3] + iVar19);
        ppppfStack_198 = (float ****)local_40;
        uStack_194 = 1;
        pppppfStack_19c = (float *****)&local_70;
        pppppfStack_1a0 = local_50;
        local_70 = (float ***)0x4004;
        pppfStack_1a4 = (float ***)0x4ee9d1;
        Ordinal_660();
        pppfStack_1a4 = (float ***)&local_2c;
        ppppfStack_1a8 = (float ****)0x4ee9d7;
        __vbaAryUnlock();
        ppppfStack_1a8 = (float ****)local_50;
        pppppfStack_1ac = (float *****)0x4ee9e1;
        pppppfStack_1d0 = (float *****)__vbaStrVarMove();
        local_60 = (float ****)0x8;
        uStack_1b8 = 3;
        pppppfStack_1b4 = (float *****)local_7c;
        pppppfStack_1ac = local_74;
        pppfStack_1c8 = (float ***)0x3;
        pppppfStack_1c4 = local_9c;
        pppppfStack_1c0 = (float *****)local_98;
        ppppfStack_1bc = (float ****)local_94;
        uStack_1dc = 2;
        ppppfStack_1e0 = (float ****)0x41;
        ppppfStack_1d8 = (float ****)0x8;
        ppppfStack_1d4 = local_5c;
        pppppfStack_1e4 = local_dc;
        ppppfStack_1cc = (float ****)local_54;
        pppppfStack_1e8 = (float *****)0x4eea59;
        ppppfStack_1b0 = (float ****)pppppfVar9;
        local_58 = (float ****)pppppfStack_1d0;
        __vbaLateIdCallSt();
        pppppfStack_1ac = (float *****)0x4eea65;
        __vbaFreeStr();
        pppppfStack_1ac = &local_60;
        ppppfStack_1b0 = (float ****)local_50;
        pppppfStack_1b4 = local_40;
        uStack_1b8 = 3;
        ppppfStack_1bc = (float ****)0x4eea79;
        __vbaFreeVarList();
        pppppfStack_1ac = (float *****)0x4eea81;
        FUN_0044fdc0();
        pppppfStack_1ac = (float *****)0x4eea8c;
        __vbaStrMove();
        local_38 = local_30;
        ppppfStack_1b0 = &local_2c;
        pppppfStack_1ac = DAT_0050b3e4;
        local_30 = 0;
        local_40[0] = (float ****)0x8;
        pppppfStack_1b4 = (float *****)0x4eeab1;
        __vbaAryLock();
        if ((local_2c == (float ***)0x0) || (*(short *)local_2c != 2)) {
          pppppfStack_1b4 = (float *****)0x4eeb1c;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          local_c8 = (float ***)((int)(short)local_28 - (int)local_2c[7]);
          if (local_2c[6] <= local_c8) {
            pppppfStack_1b4 = (float *****)0x4eeada;
            __vbaGenerateBoundsError();
          }
          local_c4 = (float ***)(1 - (int)local_2c[5]);
          if (local_2c[4] <= local_c4) {
            pppppfStack_1b4 = (float *****)0x4eeafc;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)((int)local_2c[6] * (int)local_c4 + (int)local_c8) * 4;
        }
        pppppfStack_1b4 = (float *****)0x1;
        local_68 = (float *****)((int)local_2c[3] + iVar19);
        ppppfStack_1bc = (float ****)local_40;
        uStack_1b8 = 1;
        pppppfStack_1c0 = (float *****)&local_70;
        pppppfStack_1c4 = local_50;
        local_70 = (float ***)0x4004;
        pppfStack_1c8 = (float ***)0x4eeb40;
        Ordinal_660();
        pppfStack_1c8 = (float ***)&local_2c;
        ppppfStack_1cc = (float ****)0x4eeb46;
        __vbaAryUnlock();
        ppppfStack_1cc = (float ****)local_50;
        pppppfStack_1d0 = (float *****)0x4eeb50;
        pppppfStack_1f4 = (float *****)__vbaStrVarMove();
        local_60 = (float ****)0x8;
        uStack_1dc = 3;
        ppppfStack_1d8 = (float ****)local_7c;
        pppppfStack_1d0 = local_74;
        pppfStack_1ec = (float ***)0x3;
        pppppfStack_1e8 = local_9c;
        pppppfStack_1e4 = (float *****)0x5;
        ppppfStack_1e0 = (float ****)local_94;
        uStack_200 = 2;
        pppfStack_204 = (float ***)0x41;
        pppppfStack_1fc = (float *****)0x8;
        pppppfStack_1f8 = (float *****)local_5c;
        pppppfStack_208 = local_dc;
        ppppfStack_1f0 = (float ****)local_54;
        pppppfStack_20c = (float *****)0x4eebc7;
        ppppfStack_1d4 = (float ****)pppppfVar9;
        local_58 = (float ****)pppppfStack_1f4;
        __vbaLateIdCallSt();
        pppppfStack_1d0 = (float *****)0x4eebd3;
        __vbaFreeStr();
        pppppfStack_1d0 = &local_60;
        ppppfStack_1d4 = (float ****)local_50;
        ppppfStack_1d8 = (float ****)local_40;
        uStack_1dc = 3;
        ppppfStack_1e0 = (float ****)0x4eebe7;
        __vbaFreeVarList();
        pppppfStack_1d0 = (float *****)0x4eebef;
        FUN_0044fdc0();
        pppppfStack_1d0 = (float *****)0x4eebfa;
        __vbaStrMove();
        local_38 = local_30;
        ppppfStack_1d4 = &local_2c;
        pppppfStack_1d0 = DAT_0050b3e4;
        local_98 = 6;
        local_30 = 0;
        local_40[0] = (float ****)0x8;
        ppppfStack_1d8 = (float ****)0x4eec29;
        __vbaAryLock();
        if ((local_2c == (float ***)0x0) || (*(short *)local_2c != 2)) {
          ppppfStack_1d8 = (float ****)0x4eec94;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          local_c8 = (float ***)((int)(short)local_28 - (int)local_2c[7]);
          if (local_2c[6] <= local_c8) {
            ppppfStack_1d8 = (float ****)0x4eec52;
            __vbaGenerateBoundsError();
          }
          local_c4 = (float ***)(2 - (int)local_2c[5]);
          if (local_2c[4] <= local_c4) {
            ppppfStack_1d8 = (float ****)0x4eec74;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)((int)local_2c[6] * (int)local_c4 + (int)local_c8) * 4;
        }
        ppppfStack_1d8 = (float ****)0x1;
        local_68 = (float *****)((int)local_2c[3] + iVar19);
        ppppfStack_1e0 = (float ****)local_40;
        uStack_1dc = 1;
        pppppfStack_1e4 = (float *****)&local_70;
        pppppfStack_1e8 = local_50;
        local_70 = (float ***)0x4004;
        pppfStack_1ec = (float ***)0x4eecb8;
        Ordinal_660();
        pppfStack_1ec = (float ***)&local_2c;
        ppppfStack_1f0 = (float ****)0x4eecbe;
        __vbaAryUnlock();
        ppppfStack_1f0 = (float ****)local_50;
        pppppfStack_1f4 = (float *****)0x4eecc8;
        uStack_218 = __vbaStrVarMove();
        uStack_200 = 3;
        local_60 = (float ****)0x8;
        pppppfStack_1fc = (float *****)local_7c;
        pppppfStack_1f4 = local_74;
        uStack_210 = 3;
        pppppfStack_20c = local_9c;
        pppppfStack_208 = (float *****)local_98;
        pppfStack_204 = local_94;
        uStack_224 = 2;
        uStack_228 = 0x41;
        uStack_220 = 8;
        ppppfStack_21c = local_5c;
        pppppfStack_22c = local_dc;
        uStack_214 = local_54;
        pcStack_230 = (code *)0x4eed3e;
        pppppfStack_1f8 = pppppfVar9;
        local_58 = (float ****)uStack_218;
        __vbaLateIdCallSt();
        pppppfStack_1f4 = (float *****)0x4eed4a;
        __vbaFreeStr();
        pppppfStack_1f4 = &local_60;
        pppppfStack_1f8 = local_50;
        pppppfStack_1fc = local_40;
        uStack_200 = 3;
        pppfStack_204 = (float ***)0x4eed5e;
        __vbaFreeVarList();
        pppppfStack_1f8 = (float *****)&local_dc;
        pppppfStack_1f4 = (float *****)0x0;
        pppppfStack_1fc = (float *****)0x4eed70;
        __vbaObjSetAddref();
        pppppfStack_1fc = (float *****)&LAB_004eedb0;
        uStack_200 = 0x4eedaf;
        __vbaFreeObj();
        return;
      }
      pcVar16 = (code *)&DAT_00000001;
      pcVar5 = (code *)0x0;
      do {
        pcVar22 = pcVar5;
        sVar7 = (short)pcVar22;
        if (6 < sVar7) goto LAB_004ee5b0;
        local_70 = (float ***)0x3;
        pppppfStack_138 = (float *****)(int)sVar7;
        ppppppfStack_140 = (float ******)0x3;
        pppppfStack_144 = (float *****)0xb;
        pppppfStack_13c = local_6c;
        pppppfStack_148 = local_dc;
        ppppppfStack_134 = (float ******)local_64;
        pppppfStack_14c = (float *****)0x4ee56f;
        local_68 = pppppfStack_138;
        __vbaLateIdSt();
        local_70 = (float ***)0x3;
        pppppfStack_15c = (float *****)0x27;
        pppppfStack_158 = (float *****)0x3;
        local_68 = (float *****)0xff;
        pppppfStack_154 = local_6c;
        pppppfStack_160 = local_dc;
        pppppfStack_150 = (float *****)0xff;
        pppppfStack_14c = local_64;
        ppppppfStack_164 = (float ******)0x4ee5a0;
        __vbaLateIdSt();
        pcVar5 = (code *)CONCAT22(extraout_var_00,sVar7 + 1);
      } while (!SCARRY2(sVar7,1));
    }
  }
  ppppppfStack_134 = (float ******)0x4eedcc;
  __vbaErrorOverflow();
  pcVar5 = __vbaGenerateBoundsError_exref;
  ppppppfStack_140 = (float ******)&DAT_00402706;
  pppppfStack_144 = ExceptionList;
  pppppfStack_13c = (float *****)&pcStack_238;
  pppppfStack_138 = (float *****)&DAT_00402590;
  pppppfStack_160 = (float *****)0x0;
  ppppppfStack_164 = (float ******)0x0;
  pppppfStack_168 = (float *****)0x0;
  ppppfStack_16c = (float ****)0x0;
  pppppfStack_17c = (float *****)0x0;
  ppppfStack_18c = (float ****)0x0;
  pppppfStack_19c = (float *****)0x0;
  pppppfStack_1ac = (float *****)0x0;
  ppppfStack_1bc = (float ****)0x0;
  ppppfStack_1cc = (float ****)0x0;
  uStack_200 = 0;
  DAT_0050b3c2 = 0;
  pppppfStack_208 = (float *****)CONCAT22(pppppfStack_208._2_2_,DAT_0050b332);
  pppppfStack_148 = (float *****)0x1;
  pppppppfVar18 = DAT_0050b3cc;
  ExceptionList = &pppppfStack_144;
  pcStack_238 = pcVar22;
  pppppfStack_234 = local_110;
  pcStack_230 = pcVar16;
  pppppfVar9 = pppppfStack_148;
  ppppppfStack_134 = (float ******)&stack0xfffffffc;
  do {
    pppppfStack_148 = pppppfVar9;
    ppppppfVar21 = (float ******)0x0;
    if ((short)pppppfStack_208 < (short)pppppfStack_148) {
      pppppfStack_154 = (float *****)0x0;
      goto LAB_004eefe5;
    }
    if ((pppppppfVar18 == (float *******)0x0) || (*(short *)pppppppfVar18 != 2)) {
      ppppppfStack_23c = (float ******)0x4eeea5;
      iVar19 = __vbaGenerateBoundsError();
      pppppppfVar18 = DAT_0050b3cc;
    }
    else {
      ppppppfVar21 = (float ******)-(int)pppppppfVar18[7];
      if (pppppppfVar18[6] <= ppppppfVar21) {
        ppppppfStack_23c = (float ******)0x4eee78;
        __vbaGenerateBoundsError();
        pppppppfVar18 = DAT_0050b3cc;
      }
      local_110 = (float *****)((int)(short)pppppfStack_148 - (int)pppppppfVar18[5]);
      if (pppppppfVar18[4] <= local_110) {
        ppppppfStack_23c = (float ******)0x4eee90;
        __vbaGenerateBoundsError();
        pppppppfVar18 = DAT_0050b3cc;
      }
      iVar19 = (int)((int)pppppppfVar18[6] * (int)local_110 + (int)ppppppfVar21) * 4;
    }
    if (*(float *)((int)pppppppfVar18[3] + iVar19) == _DAT_00401488) {
      DAT_0050b3c2 = 1;
      if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
        ppppppfStack_23c = (float ******)0x4eeefe;
        iVar19 = __vbaGenerateBoundsError();
      }
      else {
        local_110 = (float *****)((int)(short)pppppfStack_148 - (int)DAT_0050b3d4[5]);
        if (DAT_0050b3d4[4] <= local_110) {
          ppppppfStack_23c = (float ******)0x4eeeed;
          __vbaGenerateBoundsError();
        }
        iVar19 = (int)local_110 * 4;
      }
      *(undefined4 *)((int)DAT_0050b3d4[3] + iVar19) = 0;
      if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
        ppppppfStack_23c = (float ******)0x4eef5d;
        iVar19 = __vbaGenerateBoundsError();
      }
      else {
        ppppppfVar21 = (float ******)((int)(short)pppppfStack_148 - *(int *)(DAT_0050b3e8 + 0xe));
        if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar21) {
          ppppppfStack_23c = (float ******)0x4eef30;
          __vbaGenerateBoundsError();
        }
        local_110 = (float *****)(1 - *(int *)(DAT_0050b3e8 + 10));
        if (*(float *******)(DAT_0050b3e8 + 8) <= local_110) {
          ppppppfStack_23c = (float ******)0x4eef49;
          __vbaGenerateBoundsError();
        }
        iVar19 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)local_110 + (int)ppppppfVar21) * 2;
      }
      *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar19) = (short)pppppfStack_148;
      if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
        ppppppfStack_23c = (float ******)0x4eefb4;
        iVar19 = __vbaGenerateBoundsError();
      }
      else {
        local_110 = (float *****)((int)(short)pppppfStack_148 - *(int *)(DAT_0050b3e8 + 0xe));
        if (*(float *******)(DAT_0050b3e8 + 0xc) <= local_110) {
          ppppppfStack_23c = (float ******)0x4eef8c;
          __vbaGenerateBoundsError();
        }
        ppppppfVar21 = (float ******)-*(int *)(DAT_0050b3e8 + 10);
        if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar21) {
          ppppppfStack_23c = (float ******)0x4eefa0;
          __vbaGenerateBoundsError();
        }
        iVar19 = (int)((int)local_110 + *(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar21) * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar19) = 1;
      pppppppfVar18 = DAT_0050b3cc;
    }
    pppppfVar9 = (float *****)(uint)(ushort)((short)pppppfStack_148 + 1);
  } while (!SCARRY2((short)pppppfStack_148,1));
LAB_004ef9a0:
  ppppppfStack_23c = (float ******)0x4ef9a6;
  __vbaErrorOverflow();
  pppppfStack_248 = (float *****)&DAT_00402706;
  pppppfStack_24c = ExceptionList;
  puStack_244 = &pcStack_430;
  pcStack_430 = pcVar5;
  pwStack_240 = L"\x06\x04";
  pppppfStack_264 = (float *****)0x0;
  pppppfStack_26c = (float *****)0x0;
  pppppfStack_278 = (float *****)0x0;
  ppppppfStack_27c = (float ******)0x0;
  pppppfStack_280 = (float *****)0x0;
  uStack_284 = 0;
  uStack_288 = 0;
  uStack_28c = 0;
  ppppppfStack_290 = (float ******)0x0;
  pppppfStack_294 = (float *****)0x0;
  pppppfStack_298 = (float *****)0x0;
  pppppfStack_2a8 = (float *****)0x0;
  apppppfStack_2b8[0] = (float *****)0x0;
  pppppfStack_2c8 = (float *****)0x0;
  pppppfStack_2d8 = (float *****)0x0;
  ppppppfStack_2e8 = (float ******)0x0;
  pppppfStack_2f8 = (float *****)0x0;
  ppppppfStack_308 = (float ******)0x0;
  uStack_318 = 0;
  uStack_328 = 0;
  appppppfStack_34c[0] = (float ******)0x0;
  pppppfStack_350 = (float *****)0x0;
  ppppppfStack_354 = (float ******)0x0;
  appppppfStack_380[0] = (float ******)0x0;
  ppppppfStack_384 = (float ******)0x0;
  DAT_0050b1fe = 2;
  ExceptionList = &pppppfStack_24c;
  pppppfStack_42c = local_110;
  pppppfStack_428 = (float *****)ppppppfVar21;
  ppcVar6 = &pcStack_430;
  ppppppfStack_23c = (float ******)&ppppppfStack_134;
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_434 = (float ******)&DAT_0050b420;
    ppppppfStack_438 = (float ******)&DAT_00408c88;
    ppppppfStack_43c = (float ******)0x4efa6f;
    ExceptionList = &pppppfStack_24c;
    ppppppfStack_23c = (float ******)&ppppppfStack_134;
    __vbaNew2();
    ppcVar6 = (code **)puStack_244;
  }
  puStack_244 = ppcVar6;
  ppppppfStack_438 = (float ******)appppppfStack_380;
  ppppppfStack_434 = (float ******)DAT_0050b420;
  ppppppfStack_43c = (float ******)0x4efa82;
  __vbaObjSetAddref();
  ppppppfStack_43c = (float ******)&ppppppfStack_290;
  ppppppfStack_2e0 = (float ******)0x40c3f0;
  ppppppfStack_2e8 = (float ******)0x8;
  ppppppfStack_440 = appppppfStack_380[0];
  ppppppfStack_444 = (float ******)0x4efaa9;
  pppppfStack_450 = (float *****)(*(code *)(*appppppfStack_380[0])[0x92])();
  if ((int)pppppfStack_450 < 0) {
    ppppppfStack_444 = (float ******)0x248;
    pwStack_448 = L"믲㢺毡䞍྽닦\xf724㶱䞙缔횱䙏䆙赘鄽쭖䉂片摩";
    ppppppfStack_44c = appppppfStack_380[0];
    uStack_454 = 0x4efac9;
    __vbaHresultCheckObj();
  }
  pppppppfVar18 = (float *******)__vbaLateIdSt_exref;
  uStack_454 = 0;
  pppppfStack_450 = (float *****)ppppppfStack_2e8;
  ppppppfStack_44c = ppppppfStack_2e4;
  pwStack_448 = (wchar_t *)ppppppfStack_2e0;
  ppppppfStack_444 = ppppppfStack_2dc;
  ppppppfStack_458 = ppppppfStack_290;
  uStack_45c = 0x4efb07;
  __vbaLateIdSt();
  uStack_45c = 0x4efb12;
  __vbaFreeObj();
  uStack_45c = 0xffffff;
  ppppppfStack_460 = appppppfStack_380[0];
  ppppppfStack_464 = (float ******)0x4efb23;
  iVar19 = (*(code *)(*appppppfStack_380[0])[0x1b])();
  if (iVar19 < 0) {
    ppppppfStack_464 = (float ******)0x6c;
    ppppppfStack_468 = (float ******)&DAT_0040b430;
    ppppppfStack_46c = appppppfStack_380[0];
    ppppppfStack_474 = (float ******)0x4efb3a;
    puStack_470 = (undefined *)iVar19;
    __vbaHresultCheckObj();
  }
  ppppppfStack_464 = (float ******)&ppppppfStack_290;
  ppppppfStack_2e0 = (float ******)0xa;
  ppppppfStack_2e8 = (float ******)0x2;
  ppppppfStack_468 = appppppfStack_380[0];
  ppppppfStack_46c = (float ******)0x4efb61;
  pppppfStack_478 = (float *****)(*(code *)(*appppppfStack_380[0])[0x92])();
  if ((int)pppppfStack_478 < 0) {
    ppppppfStack_46c = (float ******)0x248;
    puStack_470 = &DAT_0040b430;
    ppppppfStack_474 = appppppfStack_380[0];
    uStack_47c = 0x4efb7b;
    __vbaHresultCheckObj();
  }
  uStack_47c = 2;
  pppppfStack_478 = (float *****)ppppppfStack_2e8;
  ppppppfStack_474 = ppppppfStack_2e4;
  puStack_470 = (undefined *)ppppppfStack_2e0;
  ppppppfStack_46c = ppppppfStack_2dc;
  ppppppfStack_480 = ppppppfStack_290;
  ppppppfStack_484 = (float ******)0x4efbab;
  __vbaLateIdSt();
  ppppppfStack_484 = (float ******)0x4efbb0;
  __vbaFreeObj();
  ppppppfStack_484 = (float ******)&ppppppfStack_290;
  ppppppfStack_2e0 = (float ******)0xffffffff;
  ppppppfStack_2e8 = (float ******)0xb;
  ppppppfStack_488 = appppppfStack_380[0];
  ppppppfStack_48c = (float ******)0x4efbd7;
  pppppfStack_498 = (float *****)(*(code *)(*appppppfStack_380[0])[0x92])();
  if ((int)pppppfStack_498 < 0) {
    ppppppfStack_48c = (float ******)0x248;
    puStack_490 = &DAT_0040b430;
    ppppppfStack_494 = appppppfStack_380[0];
    uStack_49c = 0x4efbf1;
    __vbaHresultCheckObj();
  }
  uStack_49c = 3;
  pppppfStack_498 = (float *****)ppppppfStack_2e8;
  ppppppfStack_494 = ppppppfStack_2e4;
  puStack_490 = (undefined *)ppppppfStack_2e0;
  ppppppfStack_48c = ppppppfStack_2dc;
  ppppppfStack_4a0 = ppppppfStack_290;
  uStack_4a4 = 0x4efc21;
  __vbaLateIdSt();
  uStack_4a4 = 0x4efc26;
  __vbaFreeObj();
  uStack_4a4 = 1;
  ppppppfStack_4a8 = appppppfStack_380[0];
  ppppppfStack_4ac = (float ******)0x4efc37;
  iVar19 = (*(code *)(*appppppfStack_380[0])[0x4b])();
  if (iVar19 < 0) {
    ppppppfStack_4ac = (float ******)0x12c;
    puStack_4b0 = &DAT_0040b430;
    ppppppfStack_4b4 = appppppfStack_380[0];
    piStack_4bc = (int *)0x4efc51;
    iStack_4b8 = iVar19;
    __vbaHresultCheckObj();
  }
  ppppppfStack_4ac = appppppfStack_380[0];
  puStack_4b0 = (undefined *)0x4efc60;
  puStack_4b0 = (undefined *)(*(code *)(*appppppfStack_380[0])[0xd1])();
  ppppppfStack_4b4 = (float ******)&ppppppfStack_290;
  iStack_4b8 = 0x4efc6b;
  piStack_4bc = (int *)__vbaObjSet();
  iStack_4b8 = 0;
  ppppppfStack_4c0 = (float ******)0x4efc7c;
  ppppppfStack_360 = (float ******)piStack_4bc;
  iVar19 = (**(code **)(*piStack_4bc + 0x9c))();
  if (iVar19 < 0) {
    ppppppfStack_4c0 = (float ******)0x9c;
    puStack_4c4 = &DAT_0040c3dc;
    ppppppfStack_4c8 = ppppppfStack_360;
    uStack_4d0 = 0x4efc96;
    iStack_4cc = iVar19;
    __vbaHresultCheckObj();
  }
  ppppppfStack_4c0 = (float ******)0x4efc9b;
  __vbaFreeObj();
  ppppppfStack_2e8 = (float ******)0xb;
  uStack_4d0 = 0x80010007;
  iStack_4cc = 0xb;
  ppppppfStack_2e0 = (float ******)0xffffffff;
  ppppppfStack_4c8 = ppppppfStack_2e4;
  puStack_4c4 = (undefined *)0xffffffff;
  ppppppfStack_4c0 = ppppppfStack_2dc;
  ppppppfStack_4d4 = appppppfStack_380[0];
  uStack_4d8 = 0x4efcdf;
  uStack_4d8 = (*(code *)(*appppppfStack_380[0])[0xea])();
  ppppppfStack_4dc = (float ******)&ppppppfStack_290;
  uStack_4e0 = 0x4efcea;
  uStack_4e0 = __vbaObjSet();
  uStack_4e4 = 0x4efced;
  __vbaLateIdSt();
  uStack_4e4 = 0x4efcf2;
  __vbaFreeObj();
  uStack_4e4 = 0x44960000;
  ppppppfStack_4e8 = appppppfStack_380[0];
  ppppppfStack_4ec = (float ******)0x4efd06;
  iVar19 = (*(code *)(*appppppfStack_380[0])[0x39])();
  if (iVar19 < 0) {
    ppppppfStack_4ec = (float ******)0xe4;
    puStack_4f0 = &DAT_0040b430;
    ppppppfStack_4f4 = appppppfStack_380[0];
    ppppppfStack_4fc = (float ******)0x4efd20;
    ppppppfStack_4f8 = (float ******)iVar19;
    __vbaHresultCheckObj();
  }
  ppppppfStack_4ec = appppppfStack_380[0];
  puStack_4f0 = (undefined *)0x4efd2f;
  puStack_4f0 = (undefined *)(*(code *)(*appppppfStack_380[0])[0xd9])();
  ppppppfStack_4f4 = (float ******)&ppppppfStack_290;
  ppppppfStack_4f8 = (float ******)0x4efd3a;
  ppppppfStack_4fc = (float ******)__vbaObjSet();
  ppppppfStack_4f8 = (float ******)appppppfStack_34c;
  ppppppfStack_500 = (float ******)0x4efd50;
  ppppppfStack_360 = ppppppfStack_4fc;
  pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_4fc)[0x22])();
  uVar23 = 0;
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_500 = (float ******)0x88;
    ppppppfStack_504 = (float ******)&DAT_0040c3dc;
    ppppppfStack_508 = ppppppfStack_360;
    ppppppfStack_510 = (float ******)0x4efd6a;
    ppppppfStack_50c = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  iStack_404 = (int)DAT_0050b32e;
  fStack_408 = (float)iStack_404;
  ppppppfStack_500 = appppppfStack_380[0];
  pppppppfVar10 = (float *******)ppppppfStack_500;
  if ((uVar23 & 0xd) != 0) {
LAB_004f2fd3:
    ppppppfStack_500 = (float ******)pppppppfVar10;
    __vbaFPException();
    return;
  }
  ppppppfStack_504 = appppppfStack_380[0];
  ppppppfStack_508 = (float ******)0x4efdac;
  ppppppfStack_500 = (float ******)(fStack_408 + (float)appppppfStack_34c[0]);
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3b])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_508 = (float ******)0xec;
    ppppppfStack_50c = (float ******)&DAT_0040b430;
    ppppppfStack_510 = appppppfStack_380[0];
    ppppppfStack_518 = (float ******)0x4efdc6;
    ppppppfStack_514 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_508 = (float ******)0x4efdcb;
  __vbaFreeObj();
  ppppppfStack_508 = appppppfStack_380[0];
  ppppppfStack_50c = (float ******)0x4efdda;
  ppppppfStack_50c = (float ******)(*(code *)(*appppppfStack_380[0])[0xdc])();
  ppppppfStack_510 = (float ******)&ppppppfStack_290;
  ppppppfStack_514 = (float ******)0x4efde5;
  ppppppfStack_518 = (float ******)__vbaObjSet();
  ppppppfStack_514 = (float ******)0x0;
  ppppppfStack_51c = (float ******)0x4efdf6;
  ppppppfStack_360 = ppppppfStack_518;
  pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_518)[0x23])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_51c = (float ******)0x8c;
    ppppppfStack_520 = (float ******)&DAT_0040bb6c;
    ppppppfStack_524 = ppppppfStack_360;
    ppppppfStack_52c = (float ******)0x4efe10;
    ppppppfStack_528 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_51c = (float ******)0x4efe15;
  __vbaFreeObj();
  ppppppfStack_51c = appppppfStack_380[0];
  ppppppfStack_520 = (float ******)0x4efe24;
  ppppppfStack_520 = (float ******)(*(code *)(*appppppfStack_380[0])[0xdd])();
  ppppppfStack_524 = (float ******)&ppppppfStack_290;
  ppppppfStack_528 = (float ******)0x4efe2f;
  ppppppfStack_52c = (float ******)__vbaObjSet();
  ppppppfStack_528 = (float ******)0x0;
  ppppppfStack_530 = (float ******)0x4efe40;
  ppppppfStack_360 = ppppppfStack_52c;
  pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_52c)[0x23])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_530 = (float ******)0x8c;
    uStack_538 = (double)CONCAT44(&DAT_0040bb6c,ppppppfStack_360);
    ppppppfStack_540 = (float ******)0x4efe5a;
    ppppppfStack_53c = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_530 = (float ******)0x4efe5f;
  __vbaFreeObj();
  ppppppfStack_530 = appppppfStack_380[0];
  uStack_538 = (double)CONCAT44(0x4efe6e,(undefined4)uStack_538);
  uVar8 = (*(code *)(*appppppfStack_380[0])[0xdb])();
  uStack_538 = (double)CONCAT44(uVar8,&ppppppfStack_290);
  ppppppfStack_53c = (float ******)0x4efe79;
  ppppppfStack_364 = (float ******)__vbaObjSet();
  ppppppfStack_53c = (float ******)appppppfStack_34c;
  ppppppfStack_540 = appppppfStack_380[0];
  ppppppfStack_544 = (float ******)0x4efe95;
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3a])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_544 = (float ******)0xe8;
    ppppppfStack_548 = (float ******)&DAT_0040b430;
    ppppppfStack_54c = appppppfStack_380[0];
    ppppppfStack_554 = (float ******)0x4efeaf;
    ppppppfStack_550 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_544 = appppppfStack_34c[0];
  ppppppfStack_548 = ppppppfStack_364;
  ppppppfStack_54c = (float ******)0x4efec2;
  pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_364)[0x1f])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_54c = (float ******)0x7c;
    ppppppfStack_550 = (float ******)&DAT_0040c3dc;
    ppppppfStack_554 = ppppppfStack_364;
    ppppppfStack_55c = (float ******)0x4efed9;
    ppppppfStack_558 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_54c = (float ******)0x4efede;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *******)0x0) {
    ppppppfStack_54c = (float ******)&DAT_0050c53c;
    ppppppfStack_550 = (float ******)&DAT_0040b420;
    ppppppfStack_554 = (float ******)0x4efef7;
    __vbaNew2();
  }
  pppppppfVar10 = DAT_0050c53c;
  ppppppfStack_54c = (float ******)&ppppppfStack_290;
  ppppppfStack_550 = (float ******)DAT_0050c53c;
  ppppppfStack_554 = (float ******)0x4eff07;
  pppppppfVar11 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_554 = (float ******)0x18;
    ppppppfStack_558 = (float ******)&DAT_0040b410;
    ppppppfStack_55c = (float ******)pppppppfVar10;
    ppppppfStack_564 = (float ******)0x4eff18;
    ppppppfStack_560 = (float ******)pppppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppppfVar21 = ppppppfStack_290;
  ppppppfStack_554 = (float ******)appppppfStack_34c;
  ppppppfStack_558 = ppppppfStack_290;
  ppppppfStack_55c = (float ******)0x4eff2d;
  pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_290)[0x26])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_55c = (float ******)0x98;
    ppppppfStack_560 = (float ******)&DAT_0040bb5c;
    ppppppfStack_564 = ppppppfVar21;
    ppppppfStack_56c = (float ******)0x4eff41;
    ppppppfStack_568 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_55c = appppppfStack_380[0];
  ppppppfStack_560 = (float ******)0x4eff50;
  ppppppfStack_560 = (float ******)(*(code *)(*appppppfStack_380[0])[0xdb])();
  ppppppfStack_564 = &pppppfStack_294;
  ppppppfStack_568 = (float ******)0x4eff5b;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_568 = &pppppfStack_350;
  ppppppfStack_570 = (float ******)0x4eff6d;
  ppppppfStack_56c = (float ******)pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x20])();
  uVar23 = 0;
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_570 = (float ******)0x80;
    ppppppfStack_574 = (float ******)&DAT_0040c3dc;
    ppppppfStack_580 = (float ******)0x4eff81;
    ppppppfStack_57c = (float ******)pppppppfVar11;
    ppppppfStack_578 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_570 = appppppfStack_380[0];
  ppppppfStack_574 = (float ******)0x4eff90;
  ppppppfStack_574 = (float ******)(*(code *)(*appppppfStack_380[0])[0xdb])();
  ppppppfStack_578 = &pppppfStack_298;
  ppppppfStack_57c = (float ******)0x4eff9b;
  pppppppfVar11 = (float *******)__vbaObjSet();
  pppppppfVar10 = (float *******)ppppppfStack_500;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_500 =
       (float ******)(((float)appppppfStack_34c[0] - (float)pppppfStack_350) * (float)_DAT_00401268)
  ;
  pppppppfVar10 = (float *******)*pppppppfVar11;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_50c = (float ******)0x4effd9;
  ppppppfStack_508 = (float ******)pppppppfVar11;
  fStack_40c = (float)ppppppfStack_500;
  ppppppfStack_518 = (float ******)(*(code *)(*pppppppfVar11)[0x1d])();
  if ((int)ppppppfStack_518 < 0) {
    ppppppfStack_50c = (float ******)0x74;
    ppppppfStack_510 = (float ******)&DAT_0040c3dc;
    ppppppfStack_51c = (float ******)0x4effea;
    ppppppfStack_514 = (float ******)pppppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppppfStack_50c = &pppppfStack_298;
  ppppppfStack_510 = &pppppfStack_294;
  ppppppfStack_514 = (float ******)&ppppppfStack_290;
  ppppppfStack_518 = (float ******)0x3;
  ppppppfStack_51c = (float ******)0x4efffe;
  __vbaFreeObjList();
  ppppppfStack_50c = appppppfStack_380[0];
  ppppppfStack_510 = (float ******)0x4f0010;
  ppppppfStack_510 = (float ******)(*(code *)(*appppppfStack_380[0])[0xdb])();
  ppppppfStack_514 = (float ******)&ppppppfStack_290;
  ppppppfStack_518 = (float ******)0x4f001b;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_518 = (float ******)0xffffffff;
  ppppppfStack_520 = (float ******)0x4f0028;
  ppppppfStack_51c = (float ******)pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x27])();
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_520 = (float ******)0x9c;
    ppppppfStack_524 = (float ******)&DAT_0040c3dc;
    ppppppfStack_530 = (float ******)0x4f003c;
    ppppppfStack_52c = (float ******)pppppppfVar11;
    ppppppfStack_528 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_520 = (float ******)0x4f0045;
  __vbaFreeObj();
  ppppppfStack_520 = appppppfStack_380[0];
  ppppppfStack_524 = (float ******)0x4f0054;
  ppppppfStack_524 = (float ******)(*(code *)(*appppppfStack_380[0])[0xdb])();
  ppppppfStack_528 = (float ******)&ppppppfStack_290;
  ppppppfStack_52c = (float ******)0x4f005f;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_52c = &pppppfStack_350;
  uStack_538 = (double)CONCAT44(0x4f0071,(undefined4)uStack_538);
  ppppppfStack_530 = (float ******)pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x22])();
  if ((int)pppppppfVar11 < 0) {
    uStack_538 = 2.88593524605243e-312;
    ppppppfStack_544 = (float ******)0x4f0085;
    ppppppfStack_540 = (float ******)pppppppfVar11;
    ppppppfStack_53c = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  uStack_538 = (double)CONCAT44(appppppfStack_34c,appppppfStack_380[0]);
  ppppppfStack_53c = (float ******)0x4f009b;
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3a])();
  uVar23 = 0;
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_500 = (float ******)0xe8;
    ppppppfStack_504 = (float ******)&DAT_0040b430;
    ppppppfStack_508 = appppppfStack_380[0];
    ppppppfStack_510 = (float ******)0x4f00b5;
    ppppppfStack_50c = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_500 = appppppfStack_380[0];
  pppppppfVar10 = (float *******)ppppppfStack_500;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_504 = appppppfStack_380[0];
  ppppppfStack_508 = (float ******)0x4f00de;
  ppppppfStack_500 = (float ******)((float)pppppfStack_350 + (float)appppppfStack_34c[0]);
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3b])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_508 = (float ******)0xec;
    ppppppfStack_50c = (float ******)&DAT_0040b430;
    ppppppfStack_510 = appppppfStack_380[0];
    ppppppfStack_518 = (float ******)0x4f00f8;
    ppppppfStack_514 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_508 = (float ******)0x4f0101;
  __vbaFreeObj();
  ppppppfStack_508 = (float ******)appppppfStack_34c;
  ppppppfStack_50c = appppppfStack_380[0];
  ppppppfStack_510 = (float ******)0x4f0117;
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3a])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_510 = (float ******)0xe8;
    ppppppfStack_514 = (float ******)&DAT_0040b430;
    ppppppfStack_518 = appppppfStack_380[0];
    ppppppfStack_520 = (float ******)0x4f0131;
    ppppppfStack_51c = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  if (DAT_0050c53c == (float *******)0x0) {
    ppppppfStack_510 = (float ******)&DAT_0050c53c;
    ppppppfStack_514 = (float ******)&DAT_0040b420;
    ppppppfStack_518 = (float ******)0x4f014a;
    __vbaNew2();
  }
  pppppppfVar10 = DAT_0050c53c;
  ppppppfStack_510 = (float ******)&ppppppfStack_290;
  ppppppfStack_514 = (float ******)DAT_0050c53c;
  ppppppfStack_518 = (float ******)0x4f015a;
  pppppppfVar11 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_518 = (float ******)0x18;
    ppppppfStack_51c = (float ******)&DAT_0040b410;
    ppppppfStack_520 = (float ******)pppppppfVar10;
    ppppppfStack_528 = (float ******)0x4f016b;
    ppppppfStack_524 = (float ******)pppppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppppfVar21 = ppppppfStack_290;
  ppppppfStack_518 = &pppppfStack_350;
  ppppppfStack_51c = ppppppfStack_290;
  ppppppfStack_520 = (float ******)0x4f0180;
  pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_290)[0x26])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_520 = (float ******)0x98;
    ppppppfStack_524 = (float ******)&DAT_0040bb5c;
    ppppppfStack_528 = ppppppfVar21;
    ppppppfStack_530 = (float ******)0x4f0194;
    ppppppfStack_52c = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_520 = (float ******)&ppppppfStack_354;
  ppppppfStack_524 = appppppfStack_380[0];
  ppppppfStack_528 = (float ******)0x4f01aa;
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3a])();
  uVar23 = 0;
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_4f8 = (float ******)0xe8;
    ppppppfStack_4fc = (float ******)&DAT_0040b430;
    ppppppfStack_500 = appppppfStack_380[0];
    ppppppfStack_508 = (float ******)0x4f01c4;
    ppppppfStack_504 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_4f8 = (float ******)&DAT_0050b420;
    ppppppfStack_4fc = (float ******)&DAT_00408c88;
    ppppppfStack_500 = (float ******)0x4f01dd;
    __vbaNew2();
  }
  pppppppfVar11 = DAT_0050b420;
  ppppppfStack_500 = (float ******)((float)pppppfStack_350 - _DAT_004020e0);
  ppppppfStack_4f8 = (float ******)0x0;
  ppppppfStack_4fc = ppppppfStack_354;
  pppppppfVar10 = (float *******)*DAT_0050b420;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_504 = appppppfStack_34c[0];
  ppppppfStack_508 = (float ******)0x44960000;
  ppppppfStack_50c = (float ******)0x4;
  ppppppfStack_510 = (float ******)DAT_0050b420;
  ppppppfStack_514 = (float ******)0x4f021d;
  pppppppfVar10 = (float *******)(*(code *)(*DAT_0050b420)[0xb2])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_514 = (float ******)0x2c8;
    ppppppfStack_518 = (float ******)&DAT_0040b430;
    ppppppfStack_51c = (float ******)pppppppfVar11;
    ppppppfStack_524 = (float ******)0x4f0231;
    ppppppfStack_520 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_514 = (float ******)0x4f023a;
  __vbaFreeObj();
  ppppppfStack_514 = (float ******)0x44960000;
  ppppppfStack_518 = appppppfStack_380[0];
  ppppppfStack_51c = (float ******)0x4f024e;
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x39])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_51c = (float ******)0xe4;
    ppppppfStack_520 = (float ******)&DAT_0040b430;
    ppppppfStack_524 = appppppfStack_380[0];
    ppppppfStack_52c = (float ******)0x4f0268;
    ppppppfStack_528 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_51c = (float ******)&DAT_0050b420;
    ppppppfStack_520 = (float ******)&DAT_00408c88;
    ppppppfStack_524 = (float ******)0x4f0281;
    __vbaNew2();
  }
  ppppppfStack_51c = (float ******)0x40f6d0;
  ppppppfStack_520 = *(float *******)(DAT_0050b37c + 4);
  ppppppfStack_524 = (float ******)0x4f0295;
  __vbaStrCat();
  ppppppfStack_524 = (float ******)0x4f02a0;
  ppppppfStack_524 = (float ******)__vbaStrMove();
  ppppppfStack_528 = (float ******)DAT_0050b420;
  ppppppfStack_52c = (float ******)&DAT_0040bf08;
  ppppppfStack_530 = (float ******)0x4f02b3;
  __vbaPrintObj();
  ppppppfStack_524 = (float ******)0x4f02bf;
  __vbaFreeStr();
  if ((DAT_0050b338 == 1) || (DAT_0050b338 == 2)) {
    ppppppfStack_524 = (float ******)0x4f02e3;
    __vbaStrCopy();
  }
  ppppppfStack_524 = appppppfStack_380[0];
  ppppppfStack_528 = (float ******)0x4f02f2;
  ppppppfStack_528 = (float ******)(*(code *)(*appppppfStack_380[0])[0xdc])();
  ppppppfStack_52c = (float ******)&ppppppfStack_290;
  ppppppfStack_530 = (float ******)0x4f02fd;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_530 = (float ******)0x0;
  uStack_538._0_4_ = 0x4f030a;
  uStack_538._4_4_ = pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x23])();
  if ((int)pppppppfVar11 < 0) {
    uStack_538._0_4_ = 0x8c;
    ppppppfStack_53c = (float ******)&DAT_0040bb6c;
    ppppppfStack_548 = (float ******)0x4f031e;
    ppppppfStack_544 = (float ******)pppppppfVar11;
    ppppppfStack_540 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  uStack_538._0_4_ = 0x4f0327;
  __vbaFreeObj();
  uStack_538 = (double)CONCAT44(uStack_538._4_4_,appppppfStack_380[0]);
  ppppppfStack_53c = (float ******)0x4f0336;
  ppppppfStack_53c = (float ******)(*(code *)(*appppppfStack_380[0])[0xdd])();
  ppppppfStack_540 = (float ******)&ppppppfStack_290;
  ppppppfStack_544 = (float ******)0x4f0341;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_544 = (float ******)0x0;
  ppppppfStack_54c = (float ******)0x4f034e;
  ppppppfStack_548 = (float ******)pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x23])();
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_54c = (float ******)0x8c;
    ppppppfStack_550 = (float ******)&DAT_0040bb6c;
    ppppppfStack_55c = (float ******)0x4f0362;
    ppppppfStack_558 = (float ******)pppppppfVar11;
    ppppppfStack_554 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_54c = (float ******)0x4f036b;
  __vbaFreeObj();
  ppppppfStack_54c = appppppfStack_380[0];
  ppppppfStack_550 = (float ******)0x4f037a;
  ppppppfStack_550 = (float ******)(*(code *)(*appppppfStack_380[0])[0xe8])();
  ppppppfStack_554 = (float ******)&ppppppfStack_290;
  ppppppfStack_558 = (float ******)0x4f0385;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_558 = (float ******)DAT_0050b34c;
  ppppppfStack_560 = (float ******)0x4f0394;
  ppppppfStack_55c = (float ******)pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x15])();
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_560 = (float ******)0x54;
    ppppppfStack_564 = (float ******)&DAT_0040ba5c;
    ppppppfStack_570 = (float ******)0x4f03a5;
    ppppppfStack_56c = (float ******)pppppppfVar11;
    ppppppfStack_568 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_560 = (float ******)0x4f03ae;
  __vbaFreeObj();
  ppppppfStack_560 = (float ******)appppppfStack_34c;
  ppppppfStack_564 = appppppfStack_380[0];
  ppppppfStack_568 = (float ******)0x4f03c4;
  ppppppfVar21 = (float ******)(*(code *)(*appppppfStack_380[0])[0x3a])();
  if ((int)ppppppfVar21 < 0) {
    ppppppfStack_568 = (float ******)0xe8;
    ppppppfStack_56c = (float ******)&DAT_0040b430;
    ppppppfStack_570 = appppppfStack_380[0];
    ppppppfStack_578 = (float ******)0x4f03de;
    ppppppfStack_574 = ppppppfVar21;
    __vbaHresultCheckObj();
  }
  ppppppfStack_568 = (float ******)0x4f03ea;
  ppppppfStack_25c = (float ******)__vbaFpI2();
  ppppppfStack_568 = appppppfStack_380[0];
  ppppppfStack_56c = (float ******)0x4f03fc;
  ppppppfStack_56c = (float ******)(*(code *)(*appppppfStack_380[0])[0xe8])();
  ppppppfStack_570 = (float ******)&ppppppfStack_290;
  ppppppfStack_574 = (float ******)0x4f0407;
  pppppppfVar10 = (float *******)__vbaObjSet();
  iStack_410 = (int)(short)ppppppfStack_25c;
  ppppppfStack_574 = (float ******)(float)iStack_410;
  ppppppfStack_57c = (float ******)0x4f042c;
  ppppppfStack_578 = (float ******)pppppppfVar10;
  pppppfStack_414 = (float *****)ppppppfStack_574;
  iVar19 = (*(code *)(*pppppppfVar10)[0x1f])();
  if (iVar19 < 0) {
    ppppppfStack_57c = (float ******)0x7c;
    ppppppfStack_580 = (float ******)&DAT_0040ba5c;
    uStack_588 = (double)CONCAT44(pppppppfVar10,iVar19);
    ppppppfStack_58c = (float ******)0x4f043d;
    __vbaHresultCheckObj();
  }
  ppppppfStack_57c = (float ******)0x4f0446;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *******)0x0) {
    ppppppfStack_57c = (float ******)&DAT_0050c53c;
    ppppppfStack_580 = (float ******)&DAT_0040b420;
    uStack_588 = (double)CONCAT44(0x4f045f,(undefined4)uStack_588);
    __vbaNew2();
  }
  pppppppfVar10 = DAT_0050c53c;
  ppppppfStack_57c = (float ******)&ppppppfStack_290;
  ppppppfStack_580 = (float ******)DAT_0050c53c;
  uStack_588 = (double)CONCAT44(0x4f046f,(undefined4)uStack_588);
  iVar19 = (*(code *)(*DAT_0050c53c)[6])();
  if (iVar19 < 0) {
    uStack_588 = 5.09299940191312e-313;
    ppppppfStack_58c = (float ******)pppppppfVar10;
    uStack_594 = (double)CONCAT44(iVar19,0x4f0480);
    __vbaHresultCheckObj();
  }
  ppppppfVar21 = ppppppfStack_290;
  uStack_588 = (double)CONCAT44(appppppfStack_34c,ppppppfStack_290);
  ppppppfStack_58c = (float ******)0x4f0495;
  ppppppfStack_598 = (float ******)(*(code *)(*ppppppfStack_290)[0x26])();
  if ((int)ppppppfStack_598 < 0) {
    ppppppfStack_58c = (float ******)0x98;
    uStack_594 = (double)CONCAT44(&DAT_0040bb5c,ppppppfVar21);
    uStack_5a0 = (double)CONCAT44(0x4f04a9,(undefined4)uStack_5a0);
    __vbaHresultCheckObj();
  }
  ppppppfStack_58c = &pppppfStack_350;
  uStack_594 = (double)CONCAT44(DAT_0050b34c,appppppfStack_380[0]);
  ppppppfStack_598 = (float ******)0x4f04c6;
  iVar19 = (*(code *)(*appppppfStack_380[0])[0xb9])();
  uVar23 = 0;
  if (iVar19 < 0) {
    ppppppfStack_598 = (float ******)0x2e4;
    uStack_5a0 = (double)CONCAT44(&DAT_0040b430,appppppfStack_380[0]);
    uStack_5ac = (double)CONCAT44(0x4f04e0,(undefined4)uStack_5ac);
    iStack_5a4 = iVar19;
    __vbaHresultCheckObj();
  }
  ppppppfStack_598 = appppppfStack_380[0];
  uStack_5a0 = (double)CONCAT44(0x4f04ef,(undefined4)uStack_5a0);
  uVar8 = (*(code *)(*appppppfStack_380[0])[0xe8])();
  uStack_5a0 = (double)CONCAT44(uVar8,&pppppfStack_294);
  iStack_5a4 = 0x4f04fa;
  pppppppfVar11 = (float *******)__vbaObjSet();
  pppppppfVar10 = (float *******)ppppppfStack_500;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_500 =
       (float ******)(((float)appppppfStack_34c[0] - (float)pppppfStack_350) * (float)_DAT_00401268)
  ;
  pppppppfVar10 = (float *******)*pppppppfVar11;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_50c = (float ******)0x4f0538;
  ppppppfStack_508 = (float ******)pppppppfVar11;
  fStack_418 = (float)ppppppfStack_500;
  ppppppfStack_518 = (float ******)(*(code *)(*pppppppfVar11)[0x1d])();
  if ((int)ppppppfStack_518 < 0) {
    ppppppfStack_50c = (float ******)0x74;
    ppppppfStack_510 = (float ******)&DAT_0040ba5c;
    ppppppfStack_51c = (float ******)0x4f0549;
    ppppppfStack_514 = (float ******)pppppppfVar11;
    __vbaHresultCheckObj();
  }
  ppppppfStack_50c = &pppppfStack_294;
  ppppppfStack_510 = (float ******)&ppppppfStack_290;
  ppppppfStack_514 = (float ******)0x2;
  ppppppfStack_518 = (float ******)0x4f0559;
  __vbaFreeObjList();
  ppppppfStack_50c = appppppfStack_380[0];
  ppppppfStack_510 = (float ******)0x4f056b;
  ppppppfStack_510 = (float ******)(*(code *)(*appppppfStack_380[0])[0xe8])();
  ppppppfStack_514 = (float ******)&ppppppfStack_290;
  ppppppfStack_518 = (float ******)0x4f0576;
  pppppppfVar10 = (float *******)__vbaObjSet();
  ppppppfStack_518 = (float ******)appppppfStack_34c;
  ppppppfStack_520 = (float ******)0x4f0588;
  ppppppfStack_51c = (float ******)pppppppfVar10;
  pppppppfVar11 = (float *******)(*(code *)(*pppppppfVar10)[0x22])();
  uVar23 = 0;
  if ((int)pppppppfVar11 < 0) {
    ppppppfStack_500 = (float ******)0x88;
    ppppppfStack_504 = (float ******)&DAT_0040ba5c;
    ppppppfStack_510 = (float ******)0x4f059c;
    ppppppfStack_50c = (float ******)pppppppfVar11;
    ppppppfStack_508 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  fStack_41c = (float)iStack_410;
  ppppppfStack_500 = appppppfStack_380[0];
  pppppppfVar10 = (float *******)ppppppfStack_500;
  if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
  ppppppfStack_504 = appppppfStack_380[0];
  ppppppfStack_508 = (float ******)0x4f05d1;
  ppppppfStack_500 = (float ******)(fStack_41c + (float)appppppfStack_34c[0]);
  pppppppfVar10 = (float *******)(*(code *)(*appppppfStack_380[0])[0x3b])();
  if ((int)pppppppfVar10 < 0) {
    ppppppfStack_508 = (float ******)0xec;
    ppppppfStack_50c = (float ******)&DAT_0040b430;
    ppppppfStack_510 = appppppfStack_380[0];
    ppppppfStack_518 = (float ******)0x4f05eb;
    ppppppfStack_514 = (float ******)pppppppfVar10;
    __vbaHresultCheckObj();
  }
  ppppppfStack_508 = (float ******)0x4f05f4;
  __vbaFreeObj();
  ppppppfStack_50c = (float ******)appppppfStack_380;
  ppppppfStack_508 = (float ******)0x0;
  ppppppfStack_510 = (float ******)0x4f0603;
  __vbaObjSetAddref();
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_510 = (float ******)&DAT_0050b420;
    ppppppfStack_514 = (float ******)&DAT_00408c88;
    ppppppfStack_518 = (float ******)0x4f061c;
    __vbaNew2();
  }
  ppppppfStack_510 = (float ******)DAT_0050b420;
  ppppppfStack_514 = (float ******)0x4f062a;
  ppppppfStack_514 = (float ******)(*(code *)(*DAT_0050b420)[0xea])();
  ppppppfStack_518 = (float ******)&ppppppfStack_384;
  ppppppfStack_51c = (float ******)0x4f063a;
  __vbaObjSet();
  ppppppfStack_2e8 = (float ******)0x3;
  ppppppfStack_2e0 = (float ******)0x3;
  ppppppfStack_528 = (float ******)0x3;
  ppppppfStack_52c = (float ******)0x1a;
  ppppppfStack_524 = ppppppfStack_2e4;
  ppppppfStack_530 = ppppppfStack_384;
  ppppppfStack_520 = (float ******)0x3;
  ppppppfStack_51c = ppppppfStack_2dc;
  uStack_538 = (double)CONCAT44(0x4f0674,(undefined4)uStack_538);
  __vbaLateIdSt();
  ppppppfStack_2e8 = (float ******)0x3;
  ppppppfStack_544 = (float ******)0xfffffe0b;
  ppppppfStack_540 = (float ******)0x3;
  ppppppfStack_2e0 = (float ******)0xff0000;
  ppppppfStack_53c = ppppppfStack_2e4;
  ppppppfStack_548 = ppppppfStack_384;
  uStack_538 = (double)CONCAT44(ppppppfStack_2dc,0xff0000);
  ppppppfStack_54c = (float ******)0x4f06b4;
  __vbaLateIdSt();
  ppppppfStack_2e8 = (float ******)0x3;
  ppppppfStack_55c = (float ******)0xfffffdff;
  ppppppfStack_558 = (float ******)0x3;
  ppppppfStack_2e0 = (float ******)0xffffff;
  ppppppfStack_554 = ppppppfStack_2e4;
  ppppppfStack_560 = ppppppfStack_384;
  ppppppfStack_550 = (float ******)0xffffff;
  ppppppfStack_54c = ppppppfStack_2dc;
  ppppppfStack_564 = (float ******)0x4f06f4;
  __vbaLateIdSt();
  pppppppfVar11 = (float *******)__vbaLateIdCallLd_exref;
  ppppppfStack_2e8 = (float ******)0x8;
  ppppppfStack_570 = (float ******)0x8;
  ppppppfStack_2e0 = (float ******)0x40c3f0;
  ppppppfStack_574 = (float ******)0x0;
  ppppppfStack_56c = ppppppfStack_2e4;
  ppppppfStack_578 = (float ******)&DAT_0040eb6c;
  ppppppfStack_57c = (float ******)0x0;
  ppppppfStack_568 = (float ******)0x40c3f0;
  ppppppfStack_580 = (float ******)0xfffffe00;
  ppppppfStack_564 = ppppppfStack_2dc;
  uStack_588 = (double)CONCAT44(ppppppfStack_384,&pppppfStack_2a8);
  ppppppfStack_58c = (float ******)0x4f0747;
  ppppppfStack_57c = (float ******)__vbaLateIdCallLd();
  ppppppfStack_580 = (float ******)0x4f0751;
  ppppppfStack_580 = (float ******)__vbaCastObjVar();
  uStack_588._4_4_ = &ppppppfStack_290;
  uStack_588._0_4_ = 0x4f0758;
  uVar8 = __vbaObjSet();
  uStack_588 = (double)CONCAT44(uStack_588._4_4_,uVar8);
  ppppppfStack_58c = (float ******)0x4f075b;
  __vbaLateIdSt();
  ppppppfStack_58c = (float ******)0x4f0764;
  __vbaFreeObj();
  pcVar22 = __vbaFreeVar_exref;
  ppppppfStack_58c = (float ******)0x4f076f;
  __vbaFreeVar();
  ppppppfStack_2e8 = (float ******)0x2;
  ppppppfStack_598 = (float ******)0x2;
  ppppppfStack_2e0 = (float ******)0x9;
  uStack_5a0 = 4.2460936197935e-314;
  iStack_5a4 = 0;
  uStack_594 = (double)CONCAT44(9,ppppppfStack_2e4);
  uStack_5ac = (double)CONCAT44(0xfffffe00,ppppppfStack_384);
  ppppppfStack_58c = ppppppfStack_2dc;
  ppppppfStack_5b0 = &pppppfStack_2a8;
  ppppppfStack_5b4 = (float ******)0x4f07bc;
  iStack_5a4 = __vbaLateIdCallLd();
  uStack_5ac = (double)CONCAT44(0x4f07c6,(undefined4)uStack_5ac);
  uVar8 = __vbaCastObjVar();
  uStack_5ac = (double)CONCAT44(uVar8,&ppppppfStack_290);
  ppppppfStack_5b0 = (float ******)0x4f07d1;
  ppppppfStack_5b0 = (float ******)__vbaObjSet();
  ppppppfStack_5b4 = (float ******)0x4f07d4;
  __vbaLateIdSt();
  ppppppfStack_5b4 = (float ******)0x4f07dd;
  __vbaFreeObj();
  ppppppfStack_5b4 = (float ******)0x4f07e2;
  __vbaFreeVar();
  ppppppfStack_2e8 = (float ******)0xb;
  ppppppfStack_2e0 = (float ******)0xffffffff;
  pcStack_5b8 = (code *)0xffffffff;
  ppppppfStack_5b4 = ppppppfStack_2dc;
  uVar8 = __vbaLateIdCallLd(&pppppfStack_2a8,ppppppfStack_384,0xfffffe00,0,&DAT_0040eb6c,3,0xb,
                            ppppppfStack_2e4);
  uVar8 = __vbaCastObjVar(uVar8);
  uVar8 = __vbaObjSet(&ppppppfStack_290,uVar8);
  __vbaLateIdSt(uVar8);
  __vbaFreeObj();
  __vbaFreeVar();
  if (DAT_0050b420 == (float *******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppfStack_360 = (float ******)DAT_0050b420;
  iVar19 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,appppppfStack_34c);
  uVar23 = 0;
  if (iVar19 < 0) {
    __vbaHresultCheckObj(iVar19,ppppppfStack_360,&DAT_0040b430,0xe8);
  }
  ppppppfStack_2e8 = (float ******)0x4;
  ppppppfStack_2e0 = appppppfStack_34c[0];
  __vbaLateIdSt(ppppppfStack_384,0x80010004,4,ppppppfStack_2e4,appppppfStack_34c[0],ppppppfStack_2dc
               );
  if (DAT_0050b338 == 1) {
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_514 = (float ******)0x5;
    ppppppfStack_510 = (float ******)0x3;
    ppppppfStack_2e0 = (float ******)0x4;
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_518 = ppppppfStack_384;
    ppppppfStack_508 = (float ******)0x4;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_51c = (float ******)0x4f1d8f;
    __vbaLateIdSt();
    ppppppfStack_2e8 = (float ******)0x3;
    if (!SCARRY2((short)DAT_0050b3c4,3)) {
      ppppppfStack_508 = (float ******)(int)(short)((short)DAT_0050b3c4 + 3);
      ppppppfStack_514 = (float ******)0x4;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f1ddb;
      ppppppfStack_2e0 = ppppppfStack_508;
      __vbaLateIdSt();
      ppppppfStack_51c = (float ******)0x0;
      ppppppfStack_520 = (float ******)0x4;
      ppppppfStack_528 = &pppppfStack_2a8;
      ppppppfStack_524 = ppppppfStack_384;
      ppppppfStack_52c = (float ******)0x4f1dec;
      ppppppfStack_51c = (float ******)__vbaLateIdCallLd();
      ppppppfStack_520 = (float ******)0x4f1df6;
      iVar19 = __vbaI4Var();
      if (!SBORROW4(iVar19,1)) {
        ppppppfStack_504 = (float ******)0x4f1e07;
        uStack_394 = __vbaI2I4();
        pppppfStack_250 = (float *****)0x0;
        ppppppfStack_504 = (float ******)0x4f1e19;
        __vbaFreeVar();
        pcVar22 = __vbaLateIdCallSt_exref;
        ppppppfVar21 = (float ******)pppppfStack_250;
        do {
          pppppfStack_250 = (float *****)ppppppfVar21;
          if ((short)uStack_394 < (short)pppppfStack_250) {
            ppppppfStack_2e8 = (float ******)0x3;
            ppppppfStack_514 = (float ******)0x22;
            ppppppfStack_510 = (float ******)0x3;
            ppppppfStack_2e0 = (float ******)0x0;
            ppppppfStack_50c = ppppppfStack_2e4;
            ppppppfStack_518 = ppppppfStack_384;
            ppppppfStack_508 = (float ******)0x0;
            ppppppfStack_504 = ppppppfStack_2dc;
            ppppppfStack_51c = (float ******)0x4f1f41;
            __vbaLateIdSt();
            ppppppfStack_2e8 = (float ******)0x3;
            ppppppfStack_52c = (float ******)0x1a;
            ppppppfStack_528 = (float ******)0x3;
            ppppppfStack_2e0 = (float ******)0x2;
            ppppppfStack_524 = ppppppfStack_2e4;
            ppppppfStack_530 = ppppppfStack_384;
            ppppppfStack_520 = (float ******)0x2;
            ppppppfStack_51c = ppppppfStack_2dc;
            uStack_538 = (double)CONCAT44(0x4f1f7e,(undefined4)uStack_538);
            __vbaLateIdSt();
            if (DAT_0050c53c == (float *******)0x0) {
              uStack_538 = 3.731548275327462e-307;
              ppppppfStack_53c = (float ******)0x4f1f97;
              __vbaNew2();
            }
            uStack_538 = (double)CONCAT44(&ppppppfStack_290,DAT_0050c53c);
            ppppppfStack_360 = (float ******)DAT_0050c53c;
            ppppppfStack_53c = (float ******)0x4f1fac;
            pppppppfVar10 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)pppppppfVar10 < 0) {
              ppppppfStack_53c = (float ******)0x18;
              ppppppfStack_540 = (float ******)&DAT_0040b410;
              ppppppfStack_544 = ppppppfStack_360;
              ppppppfStack_54c = (float ******)0x4f1fc7;
              ppppppfStack_548 = (float ******)pppppppfVar10;
              __vbaHresultCheckObj();
            }
            ppppppfStack_53c = (float ******)appppppfStack_34c;
            ppppppfStack_540 = ppppppfStack_290;
            ppppppfStack_368 = ppppppfStack_290;
            ppppppfStack_544 = (float ******)0x4f1fe0;
            pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_290)[0x26])();
            uVar23 = 0;
            if ((int)pppppppfVar10 < 0) {
              ppppppfStack_504 = (float ******)0x98;
              ppppppfStack_508 = (float ******)&DAT_0040bb5c;
              ppppppfStack_50c = ppppppfStack_368;
              ppppppfStack_514 = (float ******)0x4f1ffe;
              ppppppfStack_510 = (float ******)pppppppfVar10;
              __vbaHresultCheckObj();
            }
            ppppppfStack_2e0 = (float ******)((float)appppppfStack_34c[0] * (float)_DAT_00401370);
            pppppppfVar10 = (float *******)ppppppfStack_500;
            if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
            ppppppfStack_2e8 = (float ******)0x4;
            ppppppfStack_514 = (float ******)0x80010005;
            ppppppfStack_510 = (float ******)0x4;
            ppppppfStack_50c = ppppppfStack_2e4;
            ppppppfStack_518 = ppppppfStack_384;
            ppppppfStack_504 = ppppppfStack_2dc;
            ppppppfStack_51c = (float ******)0x4f2055;
            ppppppfStack_508 = ppppppfStack_2e0;
            __vbaLateIdSt();
            ppppppfStack_51c = (float ******)0x4f205e;
            __vbaFreeObj();
            pppppfStack_250 = (float *****)0x0;
            ppppppfVar21 = (float ******)pppppfStack_250;
            goto LAB_004f2065;
          }
          pppppppfVar10 = (float *******)&DAT_00000001;
          while( true ) {
            sVar7 = (short)pppppppfVar10;
            if (3 < sVar7) break;
            ppppppfStack_508 = (float ******)(int)(short)pppppfStack_250;
            ppppppfStack_2e8 = (float ******)0x3;
            ppppppfStack_308 = (float ******)0x3;
            ppppppfStack_510 = (float ******)0x3;
            ppppppfStack_50c = ppppppfStack_2e4;
            ppppppfStack_504 = ppppppfStack_2dc;
            ppppppfStack_520 = (float ******)0x3;
            ppppppfStack_51c = ppppppfStack_304;
            ppppppfStack_518 = (float ******)(int)sVar7;
            ppppppfStack_514 = ppppppfStack_2fc;
            uStack_538 = 4.24399161404481e-314;
            ppppppfStack_530 = (float ******)0x8;
            ppppppfStack_52c = ppppppfStack_324;
            ppppppfStack_528 = (float ******)&DAT_0040ca6c;
            ppppppfStack_524 = ppppppfStack_31c;
            ppppppfStack_53c = ppppppfStack_384;
            ppppppfStack_540 = (float ******)0x4f1ed2;
            ppppppfStack_2e0 = ppppppfStack_508;
            __vbaLateIdCallSt();
            pppppppfVar11 = pppppppfVar10;
            pppppppfVar10 = (float *******)(uint)(ushort)(sVar7 + 1);
            if (SCARRY2(sVar7,1)) goto LAB_004f2fd8;
          }
          pppppppfVar11 = (float *******)__vbaLateIdCallLd_exref;
          ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppfStack_250 + 1);
        } while (!SCARRY2((short)pppppfStack_250,1));
      }
    }
  }
  else {
    if (DAT_0050b338 != 2) {
LAB_004f2f35:
      ppppppfStack_508 = (float ******)&ppppppfStack_384;
      ppppppfStack_504 = (float ******)0x0;
      ppppppfStack_50c = (float ******)0x4f2f44;
      __vbaObjSetAddref();
      ppppppfStack_50c = (float ******)&LAB_004f2fc2;
      ppppppfStack_510 = (float ******)&ppppppfStack_384;
      ppppppfStack_514 = (float ******)appppppfStack_380;
      ppppppfStack_518 = (float ******)0x2;
      ppppppfStack_51c = (float ******)0x4f2fbe;
      __vbaFreeObjList();
      return;
    }
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_514 = (float ******)0x5;
    ppppppfStack_510 = (float ******)0x3;
    ppppppfStack_2e0 = (float ******)0x4;
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_518 = ppppppfStack_384;
    ppppppfStack_508 = (float ******)0x4;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_51c = (float ******)0x4f0938;
    __vbaLateIdSt();
    ppppppfStack_2e8 = (float ******)0x3;
    if (!SCARRY2(DAT_0050b332,2)) {
      ppppppfStack_508 = (float ******)(int)(short)(DAT_0050b332 + 2);
      ppppppfStack_514 = (float ******)0x4;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f0984;
      ppppppfStack_2e0 = ppppppfStack_508;
      __vbaLateIdSt();
      ppppppfStack_51c = (float ******)0x0;
      ppppppfStack_520 = (float ******)0x4;
      ppppppfStack_528 = &pppppfStack_2a8;
      ppppppfStack_524 = ppppppfStack_384;
      ppppppfStack_52c = (float ******)0x4f0995;
      ppppppfStack_51c = (float ******)__vbaLateIdCallLd();
      ppppppfStack_520 = (float ******)0x4f099f;
      iVar19 = __vbaI4Var();
      if (!SBORROW4(iVar19,1)) {
        ppppppfStack_504 = (float ******)0x4f09b0;
        uStack_3bc = __vbaI2I4();
        pppppfStack_250 = (float *****)0x0;
        ppppppfStack_504 = (float ******)0x4f09c2;
        __vbaFreeVar();
        pcVar22 = __vbaLateIdCallSt_exref;
        ppppppfVar21 = (float ******)pppppfStack_250;
        do {
          pppppfStack_250 = (float *****)ppppppfVar21;
          if ((short)uStack_3bc < (short)pppppfStack_250) {
            ppppppfStack_2e8 = (float ******)0x3;
            ppppppfStack_514 = (float ******)0x22;
            ppppppfStack_510 = (float ******)0x3;
            ppppppfStack_2e0 = (float ******)0x0;
            ppppppfStack_50c = ppppppfStack_2e4;
            ppppppfStack_518 = ppppppfStack_384;
            ppppppfStack_508 = (float ******)0x0;
            ppppppfStack_504 = ppppppfStack_2dc;
            ppppppfStack_51c = (float ******)0x4f0ae7;
            __vbaLateIdSt();
            ppppppfStack_2e8 = (float ******)0x3;
            ppppppfStack_52c = (float ******)0x1a;
            ppppppfStack_528 = (float ******)0x3;
            ppppppfStack_2e0 = (float ******)0x2;
            ppppppfStack_524 = ppppppfStack_2e4;
            ppppppfStack_530 = ppppppfStack_384;
            ppppppfStack_520 = (float ******)0x2;
            ppppppfStack_51c = ppppppfStack_2dc;
            uStack_538 = (double)CONCAT44(0x4f0b24,(undefined4)uStack_538);
            __vbaLateIdSt();
            if (DAT_0050c53c == (float *******)0x0) {
              uStack_538 = 3.731548275327462e-307;
              ppppppfStack_53c = (float ******)0x4f0b3d;
              __vbaNew2();
            }
            uStack_538 = (double)CONCAT44(&ppppppfStack_290,DAT_0050c53c);
            ppppppfStack_360 = (float ******)DAT_0050c53c;
            ppppppfStack_53c = (float ******)0x4f0b52;
            pppppppfVar10 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
            if ((int)pppppppfVar10 < 0) {
              ppppppfStack_53c = (float ******)0x18;
              ppppppfStack_540 = (float ******)&DAT_0040b410;
              ppppppfStack_544 = ppppppfStack_360;
              ppppppfStack_54c = (float ******)0x4f0b6d;
              ppppppfStack_548 = (float ******)pppppppfVar10;
              __vbaHresultCheckObj();
            }
            ppppppfStack_53c = (float ******)appppppfStack_34c;
            ppppppfStack_540 = ppppppfStack_290;
            ppppppfStack_368 = ppppppfStack_290;
            ppppppfStack_544 = (float ******)0x4f0b86;
            pppppppfVar10 = (float *******)(*(code *)(*ppppppfStack_290)[0x26])();
            uVar23 = 0;
            if ((int)pppppppfVar10 < 0) {
              ppppppfStack_504 = (float ******)0x98;
              ppppppfStack_508 = (float ******)&DAT_0040bb5c;
              ppppppfStack_50c = ppppppfStack_368;
              ppppppfStack_514 = (float ******)0x4f0ba4;
              ppppppfStack_510 = (float ******)pppppppfVar10;
              __vbaHresultCheckObj();
            }
            ppppppfStack_2e0 = (float ******)((float)appppppfStack_34c[0] * (float)_DAT_00401730);
            pppppppfVar10 = (float *******)ppppppfStack_500;
            if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
            ppppppfStack_2e8 = (float ******)0x4;
            ppppppfStack_514 = (float ******)0x80010005;
            ppppppfStack_510 = (float ******)0x4;
            ppppppfStack_50c = ppppppfStack_2e4;
            ppppppfStack_518 = ppppppfStack_384;
            ppppppfStack_504 = ppppppfStack_2dc;
            ppppppfStack_51c = (float ******)0x4f0bfb;
            ppppppfStack_508 = ppppppfStack_2e0;
            __vbaLateIdSt();
            ppppppfStack_51c = (float ******)0x4f0c04;
            __vbaFreeObj();
            pppppfStack_250 = (float *****)0x0;
            ppppppfVar21 = (float ******)pppppfStack_250;
            goto LAB_004f0c0b;
          }
          pppppppfVar10 = (float *******)0x0;
          while( true ) {
            sVar7 = (short)pppppppfVar10;
            if (3 < sVar7) break;
            ppppppfStack_508 = (float ******)(int)(short)pppppfStack_250;
            ppppppfStack_2e8 = (float ******)0x3;
            ppppppfStack_308 = (float ******)0x3;
            ppppppfStack_510 = (float ******)0x3;
            ppppppfStack_50c = ppppppfStack_2e4;
            ppppppfStack_504 = ppppppfStack_2dc;
            ppppppfStack_520 = (float ******)0x3;
            ppppppfStack_51c = ppppppfStack_304;
            ppppppfStack_518 = (float ******)(int)sVar7;
            ppppppfStack_514 = ppppppfStack_2fc;
            uStack_538 = 4.24399161404481e-314;
            ppppppfStack_530 = (float ******)0x8;
            ppppppfStack_52c = ppppppfStack_324;
            ppppppfStack_528 = (float ******)&DAT_0040ca6c;
            ppppppfStack_524 = ppppppfStack_31c;
            ppppppfStack_53c = ppppppfStack_384;
            ppppppfStack_540 = (float ******)0x4f0a78;
            ppppppfStack_2e0 = ppppppfStack_508;
            __vbaLateIdCallSt();
            pppppppfVar11 = pppppppfVar10;
            pppppppfVar10 = (float *******)(uint)(ushort)(sVar7 + 1);
            if (SCARRY2(sVar7,1)) goto LAB_004f2fd8;
          }
          pppppppfVar11 = (float *******)__vbaLateIdCallLd_exref;
          ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppfStack_250 + 1);
        } while (!SCARRY2((short)pppppfStack_250,1));
      }
    }
  }
  goto LAB_004f2fd8;
LAB_004eefe5:
  if (DAT_0050b420 == (float *******)0x0) {
    ppppppfStack_23c = (float ******)&DAT_0050b420;
    pwStack_240 = L"\x01\aꙴ@";
    puStack_244 = (undefined4 *)0x4eeffe;
    __vbaNew2();
  }
  ppppppfStack_23c = (float ******)DAT_0050b420;
  pwStack_240 = L"閍Ｔ\xffff剐ᗿ႐@ꅦ댲Pඋ돌Pƾ";
  pwStack_240 = (wchar_t *)(*(code *)(*DAT_0050b420)[0xea])();
  puStack_244 = &uStack_200;
  pppppfStack_248 = (float *****)0x4ef01a;
  __vbaObjSet();
  uStack_210 = CONCAT22(uStack_210._2_2_,DAT_0050b332);
  pppppfStack_14c = (float *****)&DAT_00000001;
  pppppppfVar18 = DAT_0050b3cc;
  ppppppfVar17 = (float ******)pppppfStack_14c;
  while( true ) {
    pppppfStack_14c = (float *****)ppppppfVar17;
    local_110 = pppppfStack_14c;
    ppppppfVar21 = (float ******)0x0;
    sVar7 = (short)pppppfStack_14c;
    if ((short)uStack_210 < sVar7) break;
    if ((pppppppfVar18 == (float *******)0x0) || (*(short *)pppppppfVar18 != 2)) {
      ppppppfStack_23c = (float ******)0x4ef086;
      iVar19 = __vbaGenerateBoundsError();
      pppppppfVar18 = DAT_0050b3cc;
    }
    else {
      ppppppfVar21 = (float ******)-(int)pppppppfVar18[7];
      if (pppppppfVar18[6] <= ppppppfVar21) {
        ppppppfStack_23c = (float ******)0x4ef05a;
        __vbaGenerateBoundsError();
        pppppppfVar18 = DAT_0050b3cc;
      }
      local_110 = (float *****)((int)sVar7 - (int)pppppppfVar18[5]);
      if (pppppppfVar18[4] <= local_110) {
        ppppppfStack_23c = (float ******)0x4ef071;
        __vbaGenerateBoundsError();
        pppppppfVar18 = DAT_0050b3cc;
      }
      iVar19 = (int)((int)pppppppfVar18[6] * (int)local_110 + (int)ppppppfVar21) * 4;
    }
    if (*(float *)((int)pppppppfVar18[3] + iVar19) != _DAT_00402558) {
      pppppfStack_15c = (float *****)-(float)_DAT_0050b134;
      uStack_218 = CONCAT22(uStack_218._2_2_,DAT_0050b332);
      pppppfStack_148 = (float *****)0x1;
      pppppfVar9 = pppppfStack_148;
      while( true ) {
        pppppfStack_148 = pppppfVar9;
        if ((short)uStack_218 < (short)pppppfStack_148) break;
        if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
          ppppppfStack_23c = (float ******)0x4ef10c;
          iVar19 = __vbaGenerateBoundsError();
          pppppppfVar18 = DAT_0050b3cc;
        }
        else {
          ppppppfVar21 = DAT_0050b3d4[5];
          ppppppfVar17 = (float ******)((int)(short)pppppfStack_148 - (int)ppppppfVar21);
          if (DAT_0050b3d4[4] <= ppppppfVar17) {
            ppppppfStack_23c = (float ******)0x4ef0fb;
            __vbaGenerateBoundsError();
            pppppppfVar18 = DAT_0050b3cc;
          }
          iVar19 = (int)ppppppfVar17 * 4;
        }
        local_110 = (float *****)DAT_0050b3d4[3];
        if (*(float *)((int)local_110 + iVar19) == _DAT_00401488) {
          if ((pppppppfVar18 == (float *******)0x0) || (*(short *)pppppppfVar18 != 2)) {
            ppppppfStack_23c = (float ******)0x4ef178;
            iVar19 = __vbaGenerateBoundsError();
            pppppppfVar18 = DAT_0050b3cc;
          }
          else {
            ppppppfVar21 = (float ******)((int)(short)pppppfStack_148 - (int)pppppppfVar18[7]);
            if (pppppppfVar18[6] <= ppppppfVar21) {
              ppppppfStack_23c = (float ******)0x4ef14b;
              __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            local_110 = (float *****)((int)(short)pppppfStack_14c - (int)pppppppfVar18[5]);
            if (pppppppfVar18[4] <= local_110) {
              ppppppfStack_23c = (float ******)0x4ef163;
              __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            iVar19 = (int)((int)pppppppfVar18[6] * (int)local_110 + (int)ppppppfVar21) * 4;
          }
          if (*(float *)((int)pppppppfVar18[3] + iVar19) != _DAT_00401488) {
            if ((pppppppfVar18 == (float *******)0x0) || (*(short *)pppppppfVar18 != 2)) {
              ppppppfStack_23c = (float ******)0x4ef1de;
              iVar19 = __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            else {
              ppppppfVar21 = (float ******)((int)(short)pppppfStack_148 - (int)pppppppfVar18[7]);
              if (pppppppfVar18[6] <= ppppppfVar21) {
                ppppppfStack_23c = (float ******)0x4ef1b1;
                __vbaGenerateBoundsError();
                pppppppfVar18 = DAT_0050b3cc;
              }
              local_110 = (float *****)((int)(short)pppppfStack_14c - (int)pppppppfVar18[5]);
              if (pppppppfVar18[4] <= local_110) {
                ppppppfStack_23c = (float ******)0x4ef1c9;
                __vbaGenerateBoundsError();
                pppppppfVar18 = DAT_0050b3cc;
              }
              iVar19 = (int)((int)pppppppfVar18[6] * (int)local_110 + (int)ppppppfVar21) * 4;
            }
            if (*(float *)((int)pppppppfVar18[3] + iVar19) == _DAT_00401488) goto LAB_004ef201;
            goto LAB_004ef7c1;
          }
        }
        else {
LAB_004ef201:
          if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
            ppppppfStack_23c = (float ******)0x4ef22e;
            iVar19 = __vbaGenerateBoundsError();
            pppppppfVar18 = DAT_0050b3cc;
          }
          else {
            iVar19 = (int)(short)pppppfStack_148;
            ppppppfVar21 = DAT_0050b3d4[5];
            if (DAT_0050b3d4[4] <= (float ******)(iVar19 - (int)ppppppfVar21)) {
              ppppppfStack_23c = (float ******)0x4ef21d;
              __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            iVar19 = (iVar19 - (int)ppppppfVar21) * 4;
          }
          local_110 = (float *****)DAT_0050b3d4[3];
          if (*(float *)((int)local_110 + iVar19) != _DAT_00401488) {
            if ((pppppppfVar18 == (float *******)0x0) || (*(short *)pppppppfVar18 != 2)) {
              ppppppfStack_23c = (float ******)0x4ef296;
              iVar19 = __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            else {
              ppppppfVar21 = (float ******)((int)(short)pppppfStack_148 - (int)pppppppfVar18[7]);
              if (pppppppfVar18[6] <= ppppppfVar21) {
                ppppppfStack_23c = (float ******)0x4ef269;
                __vbaGenerateBoundsError();
                pppppppfVar18 = DAT_0050b3cc;
              }
              local_110 = (float *****)((int)(short)pppppfStack_14c - (int)pppppppfVar18[5]);
              if (pppppppfVar18[4] <= local_110) {
                ppppppfStack_23c = (float ******)0x4ef281;
                __vbaGenerateBoundsError();
                pppppppfVar18 = DAT_0050b3cc;
              }
              iVar19 = (int)((int)pppppppfVar18[6] * (int)local_110 + (int)ppppppfVar21) * 4;
            }
            if (*(float *)((int)pppppppfVar18[3] + iVar19) == _DAT_00401488) goto LAB_004ef38d;
          }
          uVar23 = 0;
          if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
            ppppppfStack_23c = (float ******)0x4ef2ec;
            pppppfStack_22c = (float *****)__vbaGenerateBoundsError();
            pppppppfVar18 = DAT_0050b3cc;
          }
          else {
            iVar19 = (int)(short)pppppfStack_148;
            ppppppfVar21 = DAT_0050b3d4[5];
            if (DAT_0050b3d4[4] <= (float ******)(iVar19 - (int)ppppppfVar21)) {
              ppppppfStack_23c = (float ******)0x4ef2d5;
              __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            pppppfStack_22c = (float *****)((iVar19 - (int)ppppppfVar21) * 4);
          }
          if ((pppppppfVar18 == (float *******)0x0) || (*(short *)pppppppfVar18 != 2)) {
            ppppppfStack_23c = (float ******)0x4ef341;
            iVar19 = __vbaGenerateBoundsError();
            pppppppfVar18 = DAT_0050b3cc;
          }
          else {
            iVar19 = (int)(short)pppppfStack_148;
            ppppppfVar21 = pppppppfVar18[7];
            if (pppppppfVar18[6] <= (float ******)(iVar19 - (int)ppppppfVar21)) {
              ppppppfStack_23c = (float ******)0x4ef314;
              __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            iVar13 = (int)(short)pppppfStack_14c;
            ppppppfVar17 = pppppppfVar18[5];
            if (pppppppfVar18[4] <= (float ******)(iVar13 - (int)ppppppfVar17)) {
              ppppppfStack_23c = (float ******)0x4ef32c;
              __vbaGenerateBoundsError();
              pppppppfVar18 = DAT_0050b3cc;
            }
            iVar19 = (int)((int)pppppppfVar18[6] * (iVar13 - (int)ppppppfVar17) +
                          (iVar19 - (int)ppppppfVar21)) * 4;
          }
          local_110 = (float *****)pppppppfVar18[3];
          ppppppfVar21 = DAT_0050b3d4[3];
          pppppfStack_158 =
               (float *****)
               (*(float *)((int)local_110 + iVar19) +
               *(float *)((int)ppppppfVar21 + (int)pppppfStack_22c));
          if ((uVar23 & 0xd) != 0) {
            __vbaFPException();
            return;
          }
          if ((float)pppppfStack_15c < (float)pppppfStack_158) {
            pppppfStack_160 = pppppfStack_148;
            pppppfStack_15c = pppppfStack_158;
          }
        }
LAB_004ef38d:
        pppppfVar9 = (float *****)(uint)(ushort)((short)pppppfStack_148 + 1);
        if (SCARRY2((short)pppppfStack_148,1)) goto LAB_004ef9a0;
      }
      if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
        ppppppfStack_23c = (float ******)0x4ef3d1;
        iVar19 = __vbaGenerateBoundsError();
        pppppppfVar18 = DAT_0050b3cc;
      }
      else {
        iVar19 = (int)(short)pppppfStack_14c;
        ppppppfVar21 = DAT_0050b3d4[5];
        if (DAT_0050b3d4[4] <= (float ******)(iVar19 - (int)ppppppfVar21)) {
          ppppppfStack_23c = (float ******)0x4ef3c0;
          __vbaGenerateBoundsError();
          pppppppfVar18 = DAT_0050b3cc;
        }
        iVar19 = (iVar19 - (int)ppppppfVar21) * 4;
      }
      local_110 = (float *****)DAT_0050b3d4[3];
      if (*(float *)((int)local_110 + iVar19) == _DAT_00401488) {
        DAT_0050b3c2 = 1;
        if ((DAT_0050b3d4 == (float *******)0x0) || (*(short *)DAT_0050b3d4 != 1)) {
          ppppppfStack_23c = (float ******)0x4ef424;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          iVar19 = (int)(short)pppppfStack_14c;
          ppppppfVar17 = DAT_0050b3d4[5];
          if (DAT_0050b3d4[4] <= (float ******)(iVar19 - (int)ppppppfVar17)) {
            ppppppfStack_23c = (float ******)0x4ef419;
            __vbaGenerateBoundsError();
          }
          iVar19 = (iVar19 - (int)ppppppfVar17) * 4;
        }
        *(float ******)((int)DAT_0050b3d4[3] + iVar19) = pppppfStack_15c;
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_23c = (float ******)0x4ef47d;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          iVar13 = (int)(short)pppppfStack_160;
          iVar19 = *(int *)(DAT_0050b3e8 + 0xe);
          if (*(uint *)(DAT_0050b3e8 + 0xc) <= (uint)(iVar13 - iVar19)) {
            ppppppfStack_23c = (float ******)0x4ef455;
            __vbaGenerateBoundsError();
          }
          ppppppfVar21 = (float ******)-*(int *)(DAT_0050b3e8 + 10);
          if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar21) {
            ppppppfStack_23c = (float ******)0x4ef469;
            __vbaGenerateBoundsError();
          }
          iVar19 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar21 + (iVar13 - iVar19)) * 2;
        }
        pppppfStack_150 = (float *****)&DAT_00000001;
        uStack_220 = CONCAT22(uStack_220._2_2_,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar19))
        ;
        ppppppfVar17 = (float ******)pppppfStack_150;
        while( true ) {
          pppppfStack_150 = (float *****)ppppppfVar17;
          sVar7 = (short)pppppfStack_150;
          if ((short)uStack_220 < sVar7) break;
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_23c = (float ******)0x4ef4f9;
            local_110 = (float *****)__vbaGenerateBoundsError();
          }
          else {
            pppppfStack_1fc =
                 (float *****)((int)(short)pppppfStack_160 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(float *******)(DAT_0050b3e8 + 0xc) <= pppppfStack_1fc) {
              ppppppfStack_23c = (float ******)0x4ef4c8;
              __vbaGenerateBoundsError();
            }
            ppppppfVar21 = (float ******)((int)sVar7 - *(int *)(DAT_0050b3e8 + 10));
            if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar21) {
              ppppppfStack_23c = (float ******)0x4ef4df;
              __vbaGenerateBoundsError();
            }
            local_110 = (float *****)
                        ((int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar21 +
                              (int)pppppfStack_1fc) * 2);
          }
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_23c = (float ******)0x4ef553;
            iVar19 = __vbaGenerateBoundsError();
          }
          else {
            pppppfStack_1f4 =
                 (float *****)((int)(short)pppppfStack_14c - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(uint *)(DAT_0050b3e8 + 0xc) <= pppppfStack_1f4) {
              ppppppfStack_23c = (float ******)0x4ef523;
              __vbaGenerateBoundsError();
            }
            ppppppfVar21 = (float ******)((int)(short)pppppfStack_150 - *(int *)(DAT_0050b3e8 + 10))
            ;
            if (*(float *******)(DAT_0050b3e8 + 8) <= ppppppfVar21) {
              ppppppfStack_23c = (float ******)0x4ef53b;
              __vbaGenerateBoundsError();
            }
            iVar19 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppppfVar21 + (int)pppppfStack_1f4) * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar19) =
               *(undefined2 *)((int)local_110 + *(int *)(DAT_0050b3e8 + 6));
          ppppppfVar17 = (float ******)(uint)(ushort)((short)pppppfStack_150 + 1);
          if (SCARRY2((short)pppppfStack_150,1)) goto LAB_004ef9a0;
        }
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_23c = (float ******)0x4ef5d1;
          local_110 = (float *****)__vbaGenerateBoundsError();
        }
        else {
          ppppppfVar21 = (float ******)((int)(short)pppppfStack_160 - *(int *)(DAT_0050b3e8 + 0xe));
          if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar21) {
            ppppppfStack_23c = (float ******)0x4ef59f;
            __vbaGenerateBoundsError();
          }
          pppppfStack_1f8 = (float *****)-*(int *)(DAT_0050b3e8 + 10);
          if (*(uint *)(DAT_0050b3e8 + 8) <= pppppfStack_1f8) {
            ppppppfStack_23c = (float ******)0x4ef5b9;
            __vbaGenerateBoundsError();
          }
          local_110 = (float *****)
                      ((int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)pppppfStack_1f8 + (int)ppppppfVar21
                            ) * 2);
        }
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_23c = (float ******)0x4ef629;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfVar21 = (float ******)((int)(short)pppppfStack_14c - *(int *)(DAT_0050b3e8 + 0xe));
          if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar21) {
            ppppppfStack_23c = (float ******)0x4ef5f5;
            __vbaGenerateBoundsError();
          }
          ppppfStack_1f0 = (float ****)-*(int *)(DAT_0050b3e8 + 10);
          if (*(uint *)(DAT_0050b3e8 + 8) <= ppppfStack_1f0) {
            ppppppfStack_23c = (float ******)0x4ef60f;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)ppppfStack_1f0 + (int)ppppppfVar21) * 2
          ;
        }
        sVar7 = *(short *)((int)local_110 + *(int *)(DAT_0050b3e8 + 6));
        if (SCARRY2(sVar7,1)) goto LAB_004ef9a0;
        *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar19) = sVar7 + 1;
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_23c = (float ******)0x4ef6f3;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          iVar19 = (int)(short)pppppfStack_14c;
          ppppppfVar21 = (float ******)(iVar19 - *(int *)(DAT_0050b3e8 + 0xe));
          pppppfStack_1fc = (float *****)ppppppfVar21;
          if (*(float *******)(DAT_0050b3e8 + 0xc) <= ppppppfVar21) {
            ppppppfStack_23c = (float ******)0x4ef676;
            __vbaGenerateBoundsError();
          }
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_23c = (float ******)0x4ef6c4;
            iVar19 = __vbaGenerateBoundsError();
          }
          else {
            uVar20 = iVar19 - *(int *)(DAT_0050b3e8 + 0xe);
            if (*(uint *)(DAT_0050b3e8 + 0xc) <= uVar20) {
              ppppppfStack_23c = (float ******)0x4ef696;
              __vbaGenerateBoundsError();
            }
            iVar19 = *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= (uint)-iVar19) {
              ppppppfStack_23c = (float ******)0x4ef6aa;
              __vbaGenerateBoundsError();
            }
            iVar19 = (*(int *)(DAT_0050b3e8 + 0xc) * -iVar19 + uVar20) * 2;
            ppppppfVar21 = (float ******)pppppfStack_1fc;
          }
          local_110 = (float *****)
                      ((int)*(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar19) -
                      *(int *)(DAT_0050b3e8 + 10));
          if (*(float *******)(DAT_0050b3e8 + 8) <= local_110) {
            ppppppfStack_23c = (float ******)0x4ef6df;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (int)local_110 + (int)ppppppfVar21) * 2;
        }
        *(short *)(*(int *)(DAT_0050b3e8 + 6) + iVar19) = (short)pppppfStack_14c;
        if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
          ppppppfStack_23c = (float ******)0x4ef74b;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          local_110 = (float *****)((int)(short)pppppfStack_14c - (int)DAT_0050b3cc[7]);
          if (DAT_0050b3cc[6] <= local_110) {
            ppppppfStack_23c = (float ******)0x4ef722;
            __vbaGenerateBoundsError();
          }
          ppppppfVar21 = (float ******)-(int)DAT_0050b3cc[5];
          if (DAT_0050b3cc[4] <= ppppppfVar21) {
            ppppppfStack_23c = (float ******)0x4ef736;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)((int)local_110 + (int)DAT_0050b3cc[6] * (int)ppppppfVar21) * 4;
        }
        if (*(float *)((int)DAT_0050b3cc[3] + iVar19) == _DAT_00401488) {
          pppppfStack_154 = (float *****)&DAT_00000001;
        }
        if ((DAT_0050b3cc == (float *******)0x0) || (*(short *)DAT_0050b3cc != 2)) {
          ppppppfStack_23c = (float ******)0x4ef7ac;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfVar21 = (float ******)-(int)DAT_0050b3cc[7];
          if (DAT_0050b3cc[6] <= ppppppfVar21) {
            ppppppfStack_23c = (float ******)0x4ef783;
            __vbaGenerateBoundsError();
          }
          local_110 = (float *****)-(int)DAT_0050b3cc[5];
          if (DAT_0050b3cc[4] <= local_110) {
            ppppppfStack_23c = (float ******)0x4ef797;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)((int)DAT_0050b3cc[6] * (int)local_110 + (int)ppppppfVar21) * 4;
        }
        *(float ******)((int)DAT_0050b3cc[3] + iVar19) = pppppfStack_15c;
        pppppppfVar18 = DAT_0050b3cc;
      }
    }
LAB_004ef7c1:
    ppppppfVar17 = (float ******)(uint)(ushort)((short)pppppfStack_14c + 1);
    if (SCARRY2((short)pppppfStack_14c,1)) goto LAB_004ef9a0;
  }
  if (DAT_0050b3c2 == 0) {
    ppppppfStack_23c = (float ******)&ppppfStack_1bc;
    pppppfStack_1b4 = (float *****)&pppppfStack_160;
    ppppfStack_1bc = (float ****)0x4002;
    pwStack_240 = L"㖋መ@킋䶍ￌ맖\x04耂સ";
    Ordinal_536();
    pwStack_240 = L"ҹȀ뢀\n";
    __vbaStrMove();
    pppfStack_1a4 = (float ***)0x80020004;
    uStack_194 = 0x80020004;
    pppppfStack_1ac = (float *****)0xa;
    pppppfStack_19c = (float *****)0xa;
    pppppfStack_1c4 = (float *****)0x40c860;
    ppppfStack_1cc = (float ****)0x8;
    pwStack_240 = L"喋棌䫐A䶍쟐책";
    __vbaVarDup();
    pwStack_240 = L"Loop detected.  Forward Pass cannot proceed past node";
    pppppfStack_168 = (float *****)0x0;
    puStack_244 = (undefined4 *)0x4ef87a;
    puStack_244 = (undefined4 *)__vbaStrMove();
    pppppfStack_248 = (float *****)0x4ef881;
    pppppfStack_174 = (float *****)__vbaStrCat();
    pppppfStack_248 = (float *****)&pppppfStack_1ac;
    pppppfStack_24c = (float *****)&pppppfStack_19c;
    pppppfStack_250 = &ppppfStack_18c;
    pppppfStack_258 = (float *****)&pppppfStack_17c;
    uStack_254 = 0x10;
    pppppfStack_17c = (float *****)0x8;
    ppppppfStack_25c = (float ******)0x4ef89f;
    Ordinal_595();
    ppppppfStack_25c = &pppppfStack_168;
    ppppppfStack_260 = (float ******)&ppppppfStack_164;
    pppppfStack_264 = (float *****)0x2;
    ppppppfStack_268 = (float ******)0x4ef8af;
    __vbaFreeStrList();
    ppppppfStack_268 = &pppppfStack_1ac;
    pppppfStack_26c = (float *****)&pppppfStack_19c;
    ppppfStack_270 = (float ****)&ppppfStack_18c;
    ppppppfStack_274 = &pppppfStack_17c;
    pppppfStack_278 = (float *****)0x4;
    ppppppfStack_27c = (float ******)0x4ef8c7;
    __vbaFreeVarList();
    if (DAT_0050c53c == (float *******)0x0) {
      ppppppfStack_25c = (float ******)&DAT_0050c53c;
      ppppppfStack_260 = (float ******)&DAT_0040b420;
      pppppfStack_264 = (float *****)0x4ef8e3;
      __vbaNew2();
    }
    pppppppfVar18 = DAT_0050c53c;
    if (DAT_0050b420 == (float *******)0x0) {
      ppppppfStack_25c = (float ******)&DAT_0050b420;
      ppppppfStack_260 = (float ******)&DAT_00408c88;
      pppppfStack_264 = (float *****)0x4ef902;
      __vbaNew2();
    }
    ppppppfVar21 = *pppppppfVar18;
    ppppppfStack_260 = (float ******)&ppppfStack_16c;
    ppppppfStack_25c = (float ******)DAT_0050b420;
    pppppfStack_264 = (float *****)0x4ef915;
    pppppfStack_264 = (float *****)__vbaObjSetAddref();
    ppppppfStack_268 = (float ******)pppppppfVar18;
    pppppfStack_26c = (float *****)0x4ef91a;
    ppppppfVar21 = (float ******)(*(code *)ppppppfVar21[4])();
    if ((int)ppppppfVar21 < 0) {
      pppppfStack_26c = (float *****)0x10;
      ppppfStack_270 = (float ****)&DAT_0040b410;
      ppppppfStack_274 = (float ******)pppppppfVar18;
      ppppppfStack_27c = (float ******)0x4ef92f;
      pppppfStack_278 = (float *****)ppppppfVar21;
      __vbaHresultCheckObj();
    }
    pppppfStack_26c = (float *****)0x4ef938;
    __vbaFreeObj();
    ppppppfStack_23c = (float ******)0x4ef93d;
    FUN_00444530();
    goto code_r0x004ef93e;
  }
  pwStack_240 = (wchar_t *)&uStack_200;
  ppppppfStack_23c = (float ******)0x0;
  puStack_244 = (undefined4 *)0x4ef7f3;
  __vbaObjSetAddref();
  if ((short)pppppfStack_154 != 0) {
code_r0x004ef93e:
    ppppppfStack_23c = (float ******)&LAB_004ef98a;
    pwStack_240 = L"诃\xf04d幟襤\r";
    __vbaFreeObj();
    return;
  }
  goto LAB_004eefe5;
  while( true ) {
    ppppppfStack_2e0 = (float ******)(int)(short)pppppfStack_250;
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_504 = (float ******)0x0;
    ppppppfStack_508 = (float ******)0x80010005;
    ppppppfStack_510 = &pppppfStack_2a8;
    ppppppfStack_50c = ppppppfStack_384;
    ppppppfStack_514 = (float ******)0x4f2098;
    ppppppfStack_504 = (float ******)(*(code *)pppppppfVar11)();
    ppppppfStack_508 = (float ******)0x4f20a2;
    __vbaR4Var();
    pppppppfVar10 = (float *******)ppppppfStack_500;
    if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
    ppppppfStack_504 = (float ******)0x4f20b8;
    iVar19 = __vbaFpI4();
    ppppppfStack_308 = (float ******)0x3;
    ppppppfStack_510 = ppppppfStack_2e8;
    ppppppfStack_518 = (float ******)((int)(iVar19 + (iVar19 >> 0x1f & 3U)) >> 2);
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_508 = ppppppfStack_2e0;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_524 = (float ******)&DAT_00000001;
    ppppppfStack_528 = (float ******)0x39;
    ppppppfStack_520 = (float ******)0x3;
    ppppppfStack_51c = ppppppfStack_304;
    ppppppfStack_52c = ppppppfStack_384;
    ppppppfStack_514 = ppppppfStack_2fc;
    ppppppfStack_530 = (float ******)0x4f2122;
    __vbaLateIdCallSt();
    ppppppfStack_504 = (float ******)0x4f212e;
    __vbaFreeVar();
    ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppfStack_250 + 1);
    if (SCARRY2((short)pppppfStack_250,1)) break;
LAB_004f2065:
    pppppfStack_250 = (float *****)ppppppfVar21;
    if (3 < (short)pppppfStack_250) {
      ppppppfStack_504 = (float ******)0x4f214a;
      iStack_424 = FUN_0042b130();
      ppppppfStack_508 = (float ******)(float)iStack_424;
      ppppppfStack_2e8 = (float ******)0x4;
      ppppppfStack_514 = (float ******)0x80010006;
      ppppppfStack_510 = (float ******)0x4;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f2197;
      ppppppfStack_2e0 = ppppppfStack_508;
      __vbaLateIdSt();
      if (DAT_0050c53c == (float *******)0x0) {
        ppppppfStack_51c = (float ******)&DAT_0050c53c;
        ppppppfStack_520 = (float ******)&DAT_0040b420;
        ppppppfStack_524 = (float ******)0x4f21b0;
        __vbaNew2();
      }
      ppppppfStack_51c = (float ******)&ppppppfStack_290;
      ppppppfStack_520 = (float ******)DAT_0050c53c;
      ppppppfStack_360 = (float ******)DAT_0050c53c;
      ppppppfStack_524 = (float ******)0x4f21c5;
      pppppppfVar10 = (float *******)(*(code *)(*DAT_0050c53c)[6])();
      if ((int)pppppppfVar10 < 0) {
        ppppppfStack_524 = (float ******)0x18;
        ppppppfStack_528 = (float ******)&DAT_0040b410;
        ppppppfStack_52c = ppppppfStack_360;
        uStack_538 = (double)CONCAT44(0x4f21e0,(undefined4)uStack_538);
        ppppppfStack_530 = (float ******)pppppppfVar10;
        __vbaHresultCheckObj();
      }
      ppppppfStack_524 = (float ******)appppppfStack_34c;
      ppppppfStack_528 = ppppppfStack_290;
      ppppppfStack_368 = ppppppfStack_290;
      ppppppfStack_52c = (float ******)0x4f21f9;
      iVar19 = (*(code *)(*ppppppfStack_290)[0x26])();
      uVar23 = 0;
      if (iVar19 < 0) {
        ppppppfStack_52c = (float ******)0x98;
        ppppppfStack_530 = (float ******)&DAT_0040bb5c;
        uStack_538 = (double)CONCAT44(ppppppfStack_368,iVar19);
        ppppppfStack_53c = (float ******)0x4f2217;
        __vbaHresultCheckObj();
      }
      ppppppfStack_52c = (float ******)0x0;
      ppppppfStack_530 = (float ******)0x80010005;
      uStack_538 = (double)CONCAT44(ppppppfStack_384,&pppppfStack_2a8);
      ppppppfStack_53c = (float ******)0x4f222b;
      (*(code *)pppppppfVar11)();
      ppppppfStack_52c = &pppppfStack_2a8;
      ppppppfStack_530 = (float ******)0x4f2238;
      fVar24 = (float10)__vbaR4Var();
      pppppppfVar10 = (float *******)ppppppfStack_500;
      if (((uVar23 & 0xd) != 0) ||
         (ppppppfStack_2e0 =
               (float ******)
               (float)(((float10)(float)appppppfStack_34c[0] - fVar24) * (float10)_DAT_00401268),
         (uVar23 & 0xd) != 0)) goto LAB_004f2fd3;
      ppppppfStack_2e8 = (float ******)0x4;
      ppppppfStack_514 = (float ******)0x80010003;
      ppppppfStack_510 = (float ******)0x4;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f2299;
      ppppppfStack_508 = ppppppfStack_2e0;
      __vbaLateIdSt();
      ppppppfStack_51c = (float ******)0x4f22a2;
      __vbaFreeObj();
      ppppppfStack_51c = (float ******)0x4f22ab;
      __vbaFreeVar();
      ppppppfVar21 = ppppppfStack_2fc;
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_53c = (float ******)0x1;
      ppppppfStack_540 = (float ******)0x38;
      ppppppfStack_520 = (float ******)0x0;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(ppppppfStack_304,2);
      ppppppfStack_530 = (float ******)0x4;
      ppppppfStack_52c = ppppppfStack_2fc;
      ppppppfStack_544 = ppppppfStack_384;
      ppppppfStack_548 = (float ******)0x4f230d;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x1;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_520 = (float ******)0x1;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(ppppppfStack_304,2);
      ppppppfStack_53c = (float ******)0x1;
      ppppppfStack_540 = (float ******)0x38;
      ppppppfStack_530 = (float ******)0x1;
      ppppppfStack_544 = ppppppfStack_384;
      ppppppfStack_52c = ppppppfVar21;
      ppppppfStack_548 = (float ******)0x4f236b;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x2;
      ppppppfStack_308 = (float ******)0x2;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_53c = (float ******)0x1;
      ppppppfStack_540 = (float ******)0x38;
      ppppppfStack_520 = (float ******)0x2;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(ppppppfStack_304,2);
      ppppppfStack_530 = (float ******)0x7;
      ppppppfStack_52c = ppppppfVar21;
      ppppppfStack_544 = ppppppfStack_384;
      ppppppfStack_548 = (float ******)0x4f23d1;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_53c = (float ******)&DAT_00000001;
      ppppppfStack_540 = (float ******)0x38;
      ppppppfStack_520 = (float ******)0x3;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(ppppppfStack_304,2);
      ppppppfStack_530 = (float ******)0x7;
      ppppppfStack_544 = ppppppfStack_384;
      ppppppfStack_52c = ppppppfVar21;
      ppppppfStack_548 = (float ******)0x4f242d;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_52c = (float ******)0xa;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_530 = ppppppfStack_384;
      ppppppfStack_520 = (float ******)0x0;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(0x4f2467,(undefined4)uStack_538);
      __vbaLateIdSt();
      uStack_3ac = 3;
      uStack_3a8 = 1;
      pppppppfVar10 = (float *******)0x0;
      goto LAB_004f247d;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_508 = (float ******)(int)sVar7;
    ppppppfStack_510 = (float ******)0x3;
    ppppppfStack_514 = (float ******)0xb;
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_518 = ppppppfStack_384;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_51c = (float ******)0x4f24c5;
    ppppppfStack_2e0 = ppppppfStack_508;
    __vbaLateIdSt();
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_52c = (float ******)0x26;
    ppppppfStack_528 = (float ******)0x3;
    ppppppfStack_2e0 = (float ******)0xffff;
    ppppppfStack_524 = ppppppfStack_2e4;
    ppppppfStack_530 = ppppppfStack_384;
    ppppppfStack_520 = (float ******)0xffff;
    ppppppfStack_51c = ppppppfStack_2dc;
    uStack_538 = (double)CONCAT44(0x4f2502,(undefined4)uStack_538);
    __vbaLateIdSt();
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_544 = (float ******)0x27;
    ppppppfStack_540 = (float ******)0x3;
    ppppppfStack_2e0 = (float ******)0xff0000;
    ppppppfStack_53c = ppppppfStack_2e4;
    ppppppfStack_548 = ppppppfStack_384;
    uStack_538 = (double)CONCAT44(ppppppfStack_2dc,0xff0000);
    ppppppfStack_54c = (float ******)0x4f253f;
    __vbaLateIdSt();
    pppppppfVar10 = (float *******)CONCAT22(extraout_var_03,(short)uStack_3a8 + sVar7);
    if (SCARRY2((short)uStack_3a8,sVar7)) break;
LAB_004f247d:
    pppppppfVar11 = pppppppfVar10;
    sVar7 = (short)pppppppfVar11;
    if ((short)uStack_3ac < sVar7) {
      pppppppfVar11 = &ppppppfStack_510;
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_508 = (float ******)0x0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_520 = (float ******)0x3;
      ppppppfStack_51c = ppppppfStack_304;
      ppppppfStack_518 = (float ******)0x0;
      ppppppfStack_514 = ppppppfStack_2fc;
      uStack_538 = 4.24399161404481e-314;
      ppppppfStack_530 = (float ******)0x8;
      ppppppfStack_52c = ppppppfStack_324;
      ppppppfStack_528 = (float ******)0x40e0dc;
      ppppppfStack_524 = ppppppfStack_31c;
      ppppppfStack_53c = ppppppfStack_384;
      ppppppfStack_540 = (float ******)0x4f25db;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_514 = (float ******)0xa;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_508 = (float ******)0x0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f2615;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_52c = (float ******)0xb;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x1;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_530 = ppppppfStack_384;
      ppppppfStack_520 = (float ******)&DAT_00000001;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(0x4f2652,(undefined4)uStack_538);
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x2;
      ppppppfStack_540 = (float ******)0x2;
      ppppppfStack_2e0 = (float ******)0x4;
      ppppppfStack_53c = ppppppfStack_2e4;
      uStack_538 = (double)CONCAT44(ppppppfStack_2dc,4);
      ppppppfStack_544 = (float ******)0x28;
      ppppppfStack_548 = ppppppfStack_384;
      ppppppfStack_54c = (float ******)0x4f268f;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x8;
      ppppppfStack_55c = (float ******)0x0;
      ppppppfStack_558 = (float ******)0x8;
      ppppppfStack_2e0 = (float ******)0x40ef38;
      ppppppfStack_554 = ppppppfStack_2e4;
      ppppppfStack_560 = ppppppfStack_384;
      ppppppfStack_550 = (float ******)0x40ef38;
      ppppppfStack_54c = ppppppfStack_2dc;
      ppppppfStack_564 = (float ******)0x4f26cc;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_574 = (float ******)0xa;
      ppppppfStack_570 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_56c = ppppppfStack_2e4;
      ppppppfStack_578 = ppppppfStack_384;
      ppppppfStack_568 = (float ******)0x0;
      ppppppfStack_564 = ppppppfStack_2dc;
      ppppppfStack_57c = (float ******)0x4f2706;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_58c = (float ******)0xb;
      ppppppfStack_2e0 = (float ******)0x2;
      uStack_588 = (double)CONCAT44(ppppppfStack_2e4,3);
      ppppppfStack_580 = (float ******)0x2;
      ppppppfStack_57c = ppppppfStack_2dc;
      uStack_594._4_4_ = (float *******)ppppppfStack_384;
      uStack_594._0_4_ = 0x4f2743;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x2;
      iStack_5a4 = 0x28;
      ppppppfStack_2e0 = (float ******)0x4;
      uStack_5a0 = (double)CONCAT44(ppppppfStack_2e4,2);
      ppppppfStack_598 = (float ******)0x4;
      uStack_594 = (double)CONCAT44(uStack_594._4_4_,ppppppfStack_2dc);
      uStack_5ac._4_4_ = (float *******)ppppppfStack_384;
      uStack_5ac._0_4_ = 0x4f2780;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x8;
      pcStack_5b8 = (code *)0x8;
      ppppppfStack_2e0 = (float ******)0x414bd8;
      ppppppfStack_5b4 = ppppppfStack_2e4;
      ppppppfStack_5b0 = (float ******)0x414bd8;
      uStack_5ac = (double)CONCAT44(uStack_5ac._4_4_,ppppppfStack_2dc);
      __vbaLateIdSt(ppppppfStack_384,0);
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      __vbaLateIdSt(ppppppfStack_384,10,3,ppppppfStack_2e4,0,ppppppfStack_2dc);
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x3;
      __vbaLateIdSt(ppppppfStack_384,0xb,3,ppppppfStack_2e4,3,ppppppfStack_2dc);
      ppppppfStack_2e8 = (float ******)0x2;
      ppppppfStack_2e0 = (float ******)0x4;
      __vbaLateIdSt(ppppppfStack_384,0x28,2,ppppppfStack_2e4,4,ppppppfStack_2dc);
      ppppppfStack_2e8 = (float ******)0x8;
      ppppppfStack_2e0 = (float ******)0x414bf8;
      __vbaLateIdSt(ppppppfStack_384,0,8,ppppppfStack_2e4,L"Variance",ppppppfStack_2dc);
      uStack_3b4 = DAT_0050b3c4;
      pppppfStack_250 = (float *****)&DAT_00000001;
      ppppppfVar21 = (float ******)pppppfStack_250;
      goto LAB_004f28bf;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
      ppppppfStack_504 = (float ******)0x4f293e;
      __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_364 = (float ******)((int)sVar7 - *(int *)(DAT_0050b19c + 0xe));
      if (*(float ********)(DAT_0050b19c + 0xc) <= ppppppfStack_364) {
        ppppppfStack_504 = (float ******)0x4f2904;
        __vbaGenerateBoundsError();
      }
      if (*(uint *)(DAT_0050b19c + 8) <= 1U - *(int *)(DAT_0050b19c + 10)) {
        ppppppfStack_504 = (float ******)0x4f2921;
        __vbaGenerateBoundsError();
      }
    }
    ppppppfStack_504 = (float ******)0x4f2952;
    pppppfStack_264 = (float *****)__vbaFpI2();
    if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
      ppppppfStack_504 = (float ******)0x4f29c7;
      __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_364 = (float ******)((int)(short)pppppfStack_250 - *(int *)(DAT_0050b19c + 0xe));
      if (*(float ********)(DAT_0050b19c + 0xc) <= ppppppfStack_364) {
        ppppppfStack_504 = (float ******)0x4f2981;
        __vbaGenerateBoundsError();
      }
      ppppppfStack_360 = (float ******)(2 - *(int *)(DAT_0050b19c + 10));
      if (*(float ********)(DAT_0050b19c + 8) <= ppppppfStack_360) {
        ppppppfStack_504 = (float ******)0x4f29a4;
        __vbaGenerateBoundsError();
      }
    }
    ppppppfStack_504 = (float ******)0x4f29d5;
    pppppfStack_26c = (float *****)__vbaFpI2();
    ppppppfStack_2e0 = &pppppfStack_264;
    ppppppfStack_504 = (float ******)&ppppppfStack_2e8;
    pppppfStack_2f0 = (float *****)&pppppfStack_26c;
    ppppppfStack_2e8 = (float ******)0x4002;
    ppppppfVar21 = (float ******)(int)(short)(sVar7 + 1);
    pppppfStack_2f8 = (float *****)0x4002;
    ppppppfStack_508 = (float ******)0x4f2a0b;
    Ordinal_536();
    ppppppfStack_508 = (float ******)0x4f2a18;
    ppppppfStack_508 = (float ******)__vbaStrMove();
    ppppppfStack_50c = (float ******)0x4f2a1f;
    Ordinal_519();
    ppppppfStack_50c = (float ******)0x4f2a26;
    ppppppfStack_50c = (float ******)__vbaStrMove();
    ppppppfStack_510 = (float ******)&DAT_0040cc9c;
    ppppppfStack_514 = (float ******)0x4f2a32;
    __vbaStrCat();
    ppppppfStack_514 = (float ******)0x4f2a39;
    ppppppfStack_514 = (float ******)__vbaStrMove();
    ppppppfStack_518 = &pppppfStack_2f8;
    ppppppfStack_51c = (float ******)0x4f2a47;
    Ordinal_536();
    ppppppfStack_51c = (float ******)0x4f2a4e;
    ppppppfStack_51c = (float ******)__vbaStrMove();
    ppppppfStack_520 = (float ******)0x4f2a55;
    Ordinal_519();
    ppppppfStack_520 = (float ******)0x4f2a5c;
    ppppppfStack_520 = (float ******)__vbaStrMove();
    ppppppfStack_524 = (float ******)0x4f2a63;
    ppppppfStack_548 = (float ******)__vbaStrCat();
    pppppfStack_2a8 = (float *****)0x8;
    ppppppfStack_530 = (float ******)0x3;
    ppppppfStack_52c = ppppppfStack_304;
    ppppppfStack_524 = ppppppfStack_2fc;
    ppppppfStack_540 = (float ******)0x3;
    ppppppfStack_53c = ppppppfStack_324;
    uStack_538 = (double)(ZEXT48(ppppppfStack_31c) << 0x20);
    ppppppfStack_554 = (float ******)0x2;
    ppppppfStack_558 = (float ******)0x41;
    ppppppfStack_550 = (float ******)0x8;
    ppppppfStack_54c = ppppppfStack_2a4;
    ppppppfStack_55c = ppppppfStack_384;
    ppppppfStack_544 = ppppppfStack_29c;
    ppppppfStack_560 = (float ******)0x4f2ad7;
    ppppppfStack_528 = ppppppfVar21;
    ppppppfStack_2a0 = ppppppfStack_548;
    __vbaLateIdCallSt();
    ppppppfStack_560 = (float ******)&uStack_28c;
    ppppppfStack_564 = (float ******)&uStack_288;
    ppppppfStack_568 = (float ******)&uStack_284;
    ppppppfStack_56c = &pppppfStack_280;
    ppppppfStack_570 = (float ******)&ppppppfStack_27c;
    ppppppfStack_574 = (float ******)0x5;
    ppppppfStack_578 = (float ******)0x4f2af3;
    __vbaFreeStrList();
    ppppppfStack_524 = (float ******)0x4f2aff;
    __vbaFreeVar();
    ppppppfStack_528 = &pppppfStack_278;
    ppppppfStack_524 = (float ******)DAT_0050b3d0;
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_52c = (float ******)0x4f2b20;
    ppppppfStack_2e0 = ppppppfVar21;
    __vbaAryLock();
    if (((float ******)pppppfStack_278 == (float ******)0x0) || (*(short *)pppppfStack_278 != 1)) {
      ppppppfStack_52c = (float ******)0x4f2b5d;
      iVar19 = __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_360 = (float ******)((int)(short)pppppfStack_250 - (int)pppppfStack_278[5]);
      if (pppppfStack_278[4] <= ppppppfStack_360) {
        ppppppfStack_52c = (float ******)0x4f2b49;
        __vbaGenerateBoundsError();
      }
      iVar19 = (int)ppppppfStack_360 << 2;
    }
    ppppppfStack_550 = (float ******)((int)pppppfStack_278[3] + iVar19);
    uStack_538 = (double)CONCAT44(ppppppfStack_2e4,ppppppfStack_2e8);
    ppppppfStack_530 = ppppppfStack_2e0;
    ppppppfStack_52c = ppppppfStack_2dc;
    ppppppfStack_548 = (float ******)0x3;
    ppppppfStack_544 = ppppppfStack_304;
    ppppppfStack_540 = (float ******)0x1;
    ppppppfStack_53c = ppppppfStack_2fc;
    ppppppfStack_55c = (float ******)0x2;
    ppppppfStack_558 = (float ******)0x4008;
    ppppppfStack_560 = (float ******)0x41;
    ppppppfStack_554 = ppppppfStack_324;
    ppppppfStack_54c = ppppppfStack_31c;
    ppppppfStack_564 = ppppppfStack_384;
    ppppppfStack_568 = (float ******)0x4f2be1;
    __vbaLateIdCallSt();
    ppppppfStack_52c = &pppppfStack_278;
    ppppppfStack_530 = (float ******)0x4f2bee;
    __vbaAryUnlock();
    ppppppfStack_530 = (float ******)0x4f2bf3;
    FUN_0044fdc0();
    ppppppfStack_530 = (float ******)0x4f2bfa;
    __vbaStrMove();
    ppppppfStack_2a0 = ppppppfStack_27c;
    uStack_538._4_4_ = (float *******)&pppppfStack_278;
    ppppppfStack_530 = (float ******)DAT_0050b3cc;
    pppppfStack_2f8 = (float *****)0x3;
    ppppppfStack_27c = (float ******)0x0;
    pppppfStack_2a8 = (float *****)0x8;
    uStack_538._0_4_ = 0x4f2c2f;
    pppppfStack_2f0 = (float *****)ppppppfVar21;
    __vbaAryLock();
    if (((float ******)pppppfStack_278 == (float ******)0x0) || (*(short *)pppppfStack_278 != 2)) {
      uStack_538._0_4_ = 0x4f2c99;
      iVar19 = __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_364 = (float ******)((int)(short)pppppfStack_264 - (int)pppppfStack_278[7]);
      if (pppppfStack_278[6] <= ppppppfStack_364) {
        uStack_538._0_4_ = 0x4f2c58;
        __vbaGenerateBoundsError();
      }
      ppppppfStack_360 = (float ******)((int)(short)pppppfStack_26c - (int)pppppfStack_278[5]);
      if (pppppfStack_278[4] <= ppppppfStack_360) {
        uStack_538._0_4_ = 0x4f2c79;
        __vbaGenerateBoundsError();
      }
      iVar19 = (int)((int)pppppfStack_278[6] * (int)ppppppfStack_360 + (int)ppppppfStack_364) * 4;
    }
    uStack_538 = (double)CONCAT44(uStack_538._4_4_,1);
    ppppppfStack_2e0 = (float ******)((int)pppppfStack_278[3] + iVar19);
    ppppppfStack_540 = &pppppfStack_2a8;
    ppppppfStack_53c = (float ******)&DAT_00000001;
    ppppppfStack_544 = (float ******)&ppppppfStack_2e8;
    ppppppfStack_548 = apppppfStack_2b8;
    ppppppfStack_2e8 = (float ******)0x4004;
    ppppppfStack_54c = (float ******)0x4f2cca;
    Ordinal_660();
    ppppppfStack_54c = &pppppfStack_278;
    ppppppfStack_550 = (float ******)0x4f2cd4;
    __vbaAryUnlock();
    ppppppfStack_550 = apppppfStack_2b8;
    ppppppfStack_554 = (float ******)0x4f2cde;
    ppppppfStack_578 = (float ******)__vbaStrVarMove();
    pppppfStack_2c8 = (float *****)0x8;
    ppppppfStack_560 = (float ******)pppppfStack_2f8;
    ppppppfStack_55c = (float ******)pppppfStack_2f4;
    ppppppfStack_558 = (float ******)pppppfStack_2f0;
    ppppppfStack_554 = (float ******)uStack_2ec;
    ppppppfStack_570 = (float ******)0x3;
    ppppppfStack_56c = ppppppfStack_314;
    ppppppfStack_568 = (float ******)0x2;
    ppppppfStack_564 = (float ******)pppppfStack_30c;
    uStack_588 = 4.24399161404481e-314;
    ppppppfStack_580 = (float ******)0x8;
    ppppppfStack_57c = (float ******)uStack_2c4;
    ppppppfStack_58c = ppppppfStack_384;
    ppppppfStack_574 = ppppppfStack_2bc;
    uStack_594 = (double)CONCAT44(0x4f2d68,(undefined4)uStack_594);
    uStack_2c0 = ppppppfStack_578;
    __vbaLateIdCallSt();
    ppppppfStack_554 = (float ******)0x4f2d74;
    __vbaFreeStr();
    ppppppfStack_554 = &pppppfStack_2c8;
    ppppppfStack_558 = apppppfStack_2b8;
    ppppppfStack_55c = &pppppfStack_2a8;
    ppppppfStack_560 = (float ******)0x3;
    ppppppfStack_564 = (float ******)0x4f2d8b;
    __vbaFreeVarList();
    ppppppfStack_554 = (float ******)0x4f2d93;
    FUN_0044fdc0();
    ppppppfStack_554 = (float ******)0x4f2d9a;
    __vbaStrMove();
    ppppppfStack_2a0 = ppppppfStack_27c;
    pppppfStack_2f8 = (float *****)0x3;
    uStack_318 = 3;
    ppppppfStack_27c = (float ******)0x0;
    pppppfStack_2a8 = (float *****)0x8;
    ppppppfStack_554 = (float ******)DAT_0050b3c8;
    ppppppfStack_558 = &pppppfStack_278;
    ppppppfStack_55c = (float ******)0x4f2dd6;
    pppppfStack_2f0 = (float *****)ppppppfVar21;
    __vbaAryLock();
    if (((float ******)pppppfStack_278 == (float ******)0x0) || (*(short *)pppppfStack_278 != 2)) {
      ppppppfStack_55c = (float ******)0x4f2e32;
      iVar19 = __vbaGenerateBoundsError();
    }
    else {
      ppppppfStack_364 = (float ******)((int)(short)pppppfStack_264 - (int)pppppfStack_278[7]);
      if (pppppfStack_278[6] <= ppppppfStack_364) {
        ppppppfStack_55c = (float ******)0x4f2dff;
        __vbaGenerateBoundsError();
      }
      iVar19 = (int)(short)pppppfStack_26c;
      pppppfVar9 = (float *****)pppppfStack_278[5];
      if (pppppfStack_278[4] <= (float *****)(iVar19 - (int)pppppfVar9)) {
        ppppppfStack_55c = (float ******)0x4f2e18;
        __vbaGenerateBoundsError();
      }
      iVar19 = (int)((int)pppppfStack_278[6] * (iVar19 - (int)pppppfVar9) + (int)ppppppfStack_364) *
               4;
    }
    ppppppfStack_55c = (float ******)&DAT_00000001;
    ppppppfStack_2e0 = (float ******)((int)pppppfStack_278[3] + iVar19);
    ppppppfStack_564 = &pppppfStack_2a8;
    ppppppfStack_560 = (float ******)&DAT_00000001;
    ppppppfStack_568 = (float ******)&ppppppfStack_2e8;
    ppppppfStack_56c = apppppfStack_2b8;
    ppppppfStack_2e8 = (float ******)0x4004;
    ppppppfStack_570 = (float ******)0x4f2e63;
    Ordinal_660();
    ppppppfStack_570 = &pppppfStack_278;
    ppppppfStack_574 = (float ******)0x4f2e6d;
    __vbaAryUnlock();
    ppppppfStack_574 = apppppfStack_2b8;
    ppppppfStack_578 = (float ******)0x4f2e77;
    uStack_2c0 = __vbaStrVarMove();
    pppppppfVar18 = (float *******)pppppfStack_30c;
    pppppppfVar11 = (float *******)ppppppfStack_314;
    pppppfStack_2c8 = (float *****)0x8;
    ppppppfStack_580 = (float ******)pppppfStack_2f4;
    ppppppfStack_57c = (float ******)pppppfStack_2f0;
    ppppppfStack_578 = (float ******)uStack_2ec;
    uStack_594 = (double)CONCAT44(ppppppfStack_314,uStack_318);
    ppppppfStack_58c = (float ******)0x3;
    uStack_588 = (double)CONCAT44(pppppfStack_2f8,pppppfStack_30c);
    uStack_5ac = 4.24399161404481e-314;
    iStack_5a4 = 8;
    ppppppfStack_5b0 = ppppppfStack_384;
    uStack_5a0 = (double)CONCAT44(uStack_2c0,uStack_2c4);
    ppppppfStack_598 = ppppppfStack_2bc;
    ppppppfStack_5b4 = (float ******)0x4f2ef8;
    __vbaLateIdCallSt();
    ppppppfStack_578 = (float ******)0x4f2f04;
    __vbaFreeStr();
    ppppppfStack_578 = &pppppfStack_2c8;
    ppppppfStack_57c = apppppfStack_2b8;
    ppppppfStack_580 = &pppppfStack_2a8;
    uStack_588 = 6.36855127864054e-314;
    __vbaFreeVarList();
    ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppfStack_250 + 1);
    if (SCARRY2((short)pppppfStack_250,1)) break;
LAB_004f28bf:
    pppppfStack_250 = (float *****)ppppppfVar21;
    sVar7 = (short)pppppfStack_250;
    if ((short)uStack_3b4 < sVar7) goto LAB_004f2f35;
    pppppppfVar18 = (float *******)CONCAT22((short)((uint)pppppppfVar18 >> 0x10),sVar7 + 1);
    if (SCARRY2(sVar7,1)) break;
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_2e0 = (float ******)(int)(short)pppppfStack_250;
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_504 = (float ******)0x0;
    ppppppfStack_508 = (float ******)0x80010005;
    ppppppfStack_510 = &pppppfStack_2a8;
    ppppppfStack_50c = ppppppfStack_384;
    ppppppfStack_514 = (float ******)0x4f0c3e;
    ppppppfStack_504 = (float ******)(*(code *)pppppppfVar11)();
    ppppppfStack_508 = (float ******)0x4f0c48;
    __vbaR4Var();
    pppppppfVar10 = (float *******)ppppppfStack_500;
    if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
    ppppppfStack_504 = (float ******)0x4f0c5e;
    ppppppfStack_518 = (float ******)__vbaFpI4();
    ppppppfStack_510 = ppppppfStack_2e8;
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_508 = ppppppfStack_2e0;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_524 = (float ******)&DAT_00000001;
    ppppppfStack_520 = (float ******)0x3;
    ppppppfStack_528 = (float ******)0x39;
    ppppppfStack_51c = ppppppfStack_304;
    ppppppfStack_52c = ppppppfStack_384;
    ppppppfStack_514 = ppppppfStack_2fc;
    ppppppfStack_530 = (float ******)0x4f0cb4;
    __vbaLateIdCallSt();
    ppppppfStack_504 = (float ******)0x4f0cc0;
    __vbaFreeVar();
    ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppfStack_250 + 1);
    if (SCARRY2((short)pppppfStack_250,1)) break;
LAB_004f0c0b:
    pppppfStack_250 = (float *****)ppppppfVar21;
    if (3 < (short)pppppfStack_250) {
      ppppppfStack_504 = (float ******)0x0;
      ppppppfStack_508 = (float ******)0x80010005;
      ppppppfStack_510 = &pppppfStack_2a8;
      ppppppfStack_50c = ppppppfStack_384;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_514 = (float ******)0x4f0cff;
      ppppppfStack_504 = (float ******)(*(code *)pppppppfVar11)();
      ppppppfStack_508 = (float ******)0x4f0d09;
      __vbaR4Var();
      pppppppfVar10 = (float *******)ppppppfStack_500;
      if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
      ppppppfStack_504 = (float ******)0x4f0d1f;
      ppppppfStack_518 = (float ******)__vbaFpI4();
      ppppppfStack_510 = ppppppfStack_2e8;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_508 = ppppppfStack_2e0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_524 = (float ******)&DAT_00000001;
      ppppppfStack_520 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x39;
      ppppppfStack_51c = ppppppfStack_304;
      ppppppfStack_52c = ppppppfStack_384;
      ppppppfStack_514 = ppppppfStack_2fc;
      ppppppfStack_530 = (float ******)0x4f0d75;
      __vbaLateIdCallSt();
      ppppppfStack_504 = (float ******)0x4f0d81;
      __vbaFreeVar();
      ppppppfStack_504 = (float ******)0x0;
      ppppppfStack_508 = (float ******)0x80010005;
      ppppppfStack_510 = &pppppfStack_2a8;
      ppppppfStack_50c = ppppppfStack_384;
      ppppppfStack_2e0 = (float ******)&DAT_00000001;
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_514 = (float ******)0x4f0da9;
      ppppppfStack_504 = (float ******)(*(code *)pppppppfVar11)();
      ppppppfStack_508 = (float ******)0x4f0db3;
      __vbaR4Var();
      pppppppfVar10 = (float *******)ppppppfStack_500;
      if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
      ppppppfStack_504 = (float ******)0x4f0dc9;
      ppppppfStack_518 = (float ******)__vbaFpI4();
      ppppppfStack_510 = ppppppfStack_2e8;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_508 = ppppppfStack_2e0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_524 = (float ******)0x1;
      ppppppfStack_520 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x39;
      ppppppfStack_51c = ppppppfStack_304;
      ppppppfStack_514 = ppppppfStack_2fc;
      ppppppfStack_52c = ppppppfStack_384;
      ppppppfStack_530 = (float ******)0x4f0e1f;
      __vbaLateIdCallSt();
      ppppppfStack_504 = (float ******)0x4f0e2b;
      __vbaFreeVar();
      ppppppfStack_504 = (float ******)0x4f0e30;
      iStack_420 = FUN_0042b130();
      ppppppfStack_508 = (float ******)(float)iStack_420;
      ppppppfStack_2e8 = (float ******)0x4;
      ppppppfStack_514 = (float ******)0x80010006;
      ppppppfStack_510 = (float ******)0x4;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f0e7d;
      ppppppfStack_2e0 = ppppppfStack_508;
      __vbaLateIdSt();
      if (DAT_0050c53c == (float *******)0x0) {
        ppppppfStack_51c = (float ******)&DAT_0050c53c;
        ppppppfStack_520 = (float ******)&DAT_0040b420;
        ppppppfStack_524 = (float ******)0x4f0e96;
        __vbaNew2();
      }
      ppppppfStack_51c = (float ******)&ppppppfStack_290;
      ppppppfStack_520 = (float ******)DAT_0050c53c;
      ppppppfStack_360 = (float ******)DAT_0050c53c;
      ppppppfStack_524 = (float ******)0x4f0eab;
      iVar19 = (*(code *)(*DAT_0050c53c)[6])();
      if (iVar19 < 0) {
        ppppppfStack_524 = (float ******)0x18;
        ppppppfStack_528 = (float ******)&DAT_0040b410;
        ppppppfStack_52c = ppppppfStack_360;
        uStack_538 = (double)CONCAT44(0x4f0ec6,(undefined4)uStack_538);
        ppppppfStack_530 = (float ******)iVar19;
        __vbaHresultCheckObj();
      }
      ppppppfStack_524 = (float ******)appppppfStack_34c;
      ppppppfStack_528 = ppppppfStack_290;
      ppppppfStack_368 = ppppppfStack_290;
      ppppppfStack_52c = (float ******)0x4f0edf;
      iVar19 = (*(code *)(*ppppppfStack_290)[0x26])();
      uVar23 = 0;
      if (iVar19 < 0) {
        ppppppfStack_52c = (float ******)0x98;
        ppppppfStack_530 = (float ******)&DAT_0040bb5c;
        uStack_538 = (double)CONCAT44(ppppppfStack_368,iVar19);
        ppppppfStack_53c = (float ******)0x4f0efd;
        __vbaHresultCheckObj();
      }
      ppppppfStack_52c = (float ******)0x0;
      ppppppfStack_530 = (float ******)0x80010005;
      uStack_538 = (double)CONCAT44(ppppppfStack_384,&pppppfStack_2a8);
      ppppppfStack_53c = (float ******)0x4f0f11;
      (*(code *)pppppppfVar11)();
      ppppppfStack_52c = &pppppfStack_2a8;
      ppppppfStack_530 = (float ******)0x4f0f1e;
      fVar24 = (float10)__vbaR4Var();
      pppppppfVar10 = (float *******)ppppppfStack_500;
      if (((uVar23 & 0xd) != 0) ||
         (ppppppfStack_2e0 =
               (float ******)
               (float)(((float10)(float)appppppfStack_34c[0] - fVar24) * (float10)_DAT_00401268),
         (uVar23 & 0xd) != 0)) goto LAB_004f2fd3;
      ppppppfStack_2e8 = (float ******)0x4;
      ppppppfStack_514 = (float ******)0x80010003;
      ppppppfStack_510 = (float ******)0x4;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f0f7f;
      ppppppfStack_508 = ppppppfStack_2e0;
      __vbaLateIdSt();
      ppppppfStack_51c = (float ******)0x4f0f88;
      __vbaFreeObj();
      ppppppfStack_51c = (float ******)0x4f0f91;
      __vbaFreeVar();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_53c = (float ******)0x1;
      ppppppfStack_540 = (float ******)0x38;
      ppppppfStack_520 = (float ******)0x0;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(ppppppfStack_304,2);
      ppppppfStack_544 = ppppppfStack_384;
      ppppppfStack_530 = (float ******)0x1;
      ppppppfStack_52c = ppppppfStack_2fc;
      ppppppfStack_548 = (float ******)0x4f0ff3;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x1;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_520 = (float ******)&DAT_00000001;
      ppppppfStack_51c = ppppppfStack_2dc;
      ppppppfStack_53c = (float ******)&DAT_00000001;
      ppppppfStack_540 = (float ******)0x38;
      uStack_538 = (double)CONCAT44(ppppppfStack_304,2);
      ppppppfStack_544 = ppppppfStack_384;
      ppppppfStack_530 = (float ******)&DAT_00000001;
      ppppppfStack_52c = ppppppfStack_2fc;
      ppppppfStack_548 = (float ******)0x4f1055;
      __vbaLateIdCallSt();
      pppppppfVar11 = (float *******)ppppppfStack_2fc;
      uStack_3d4 = 3;
      uStack_3d0 = 1;
      pppppfStack_250 = (float *****)0x2;
      ppppppfVar21 = (float ******)pppppfStack_250;
      goto LAB_004f1079;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_508 = (float ******)(int)(short)pppppfStack_250;
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_510 = (float ******)0x3;
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_524 = (float ******)&DAT_00000001;
    ppppppfStack_528 = (float ******)0x38;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_520 = (float ******)0x2;
    ppppppfStack_51c = ppppppfStack_304;
    ppppppfStack_518 = (float ******)0x7;
    ppppppfStack_52c = ppppppfStack_384;
    ppppppfStack_514 = (float ******)pppppppfVar11;
    ppppppfStack_530 = (float ******)0x4f10e4;
    ppppppfStack_2e0 = ppppppfStack_508;
    __vbaLateIdCallSt();
    ppppppfVar21 = (float ******)CONCAT22(extraout_var,(short)uStack_3d0 + (short)pppppfStack_250);
    if (SCARRY2((short)uStack_3d0,(short)pppppfStack_250)) break;
LAB_004f1079:
    pppppfStack_250 = (float *****)ppppppfVar21;
    if ((short)uStack_3d4 < (short)pppppfStack_250) {
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_514 = (float ******)0xa;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_508 = (float ******)0x0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f113a;
      __vbaLateIdSt();
      pppppfStack_250 = (float *****)0x0;
      ppppppfVar21 = (float ******)pppppfStack_250;
      goto LAB_004f1141;
    }
  }
  goto LAB_004f2fd8;
  while( true ) {
    ppppppfStack_508 = (float ******)(int)(short)pppppfStack_250;
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_514 = (float ******)0xb;
    ppppppfStack_510 = (float ******)0x3;
    ppppppfStack_50c = ppppppfStack_2e4;
    ppppppfStack_518 = ppppppfStack_384;
    ppppppfStack_504 = ppppppfStack_2dc;
    ppppppfStack_51c = (float ******)0x4f118c;
    ppppppfStack_2e0 = ppppppfStack_508;
    __vbaLateIdSt();
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_52c = (float ******)0x26;
    ppppppfStack_528 = (float ******)0x3;
    ppppppfStack_2e0 = (float ******)0xffff;
    ppppppfStack_524 = ppppppfStack_2e4;
    ppppppfStack_530 = ppppppfStack_384;
    ppppppfStack_520 = (float ******)0xffff;
    ppppppfStack_51c = ppppppfStack_2dc;
    uStack_538 = (double)CONCAT44(0x4f11c9,(undefined4)uStack_538);
    __vbaLateIdSt();
    ppppppfStack_2e8 = (float ******)0x3;
    ppppppfStack_544 = (float ******)0x27;
    ppppppfStack_540 = (float ******)0x3;
    ppppppfStack_2e0 = (float ******)0xff0000;
    ppppppfStack_53c = ppppppfStack_2e4;
    ppppppfStack_548 = ppppppfStack_384;
    uStack_538 = (double)CONCAT44(ppppppfStack_2dc,0xff0000);
    ppppppfStack_54c = (float ******)0x4f1206;
    __vbaLateIdSt();
    ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppfStack_250 + 1);
    if (SCARRY2((short)pppppfStack_250,1)) break;
LAB_004f1141:
    pppppfStack_250 = (float *****)ppppppfVar21;
    if (3 < (short)pppppfStack_250) {
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_308 = (float ******)0x3;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      uStack_300 = 0;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_508 = (float ******)0x0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_520 = (float ******)0x3;
      ppppppfStack_51c = ppppppfStack_304;
      ppppppfStack_518 = (float ******)0x0;
      ppppppfStack_514 = (float ******)pppppppfVar11;
      uStack_538 = 4.24399161404481e-314;
      ppppppfStack_530 = (float ******)0x8;
      ppppppfStack_52c = ppppppfStack_324;
      ppppppfStack_528 = (float ******)0x413078;
      ppppppfStack_524 = ppppppfStack_31c;
      ppppppfStack_53c = ppppppfStack_384;
      ppppppfStack_540 = (float ******)0x4f12ad;
      __vbaLateIdCallSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_308 = (float ******)0x3;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_508 = (float ******)0x0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_520 = (float ******)0x3;
      ppppppfStack_51c = ppppppfStack_304;
      ppppppfStack_518 = (float ******)0x1;
      ppppppfStack_514 = (float ******)pppppppfVar11;
      uStack_538 = 4.24399161404481e-314;
      ppppppfStack_530 = (float ******)0x8;
      ppppppfStack_52c = ppppppfStack_324;
      ppppppfStack_528 = (float ******)0x414c10;
      ppppppfStack_524 = ppppppfStack_31c;
      ppppppfStack_53c = ppppppfStack_384;
      ppppppfStack_540 = (float ******)0x4f1336;
      __vbaLateIdCallSt();
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_510 = (float ******)0x3;
      ppppppfStack_514 = (float ******)0xa;
      ppppppfStack_50c = ppppppfStack_2e4;
      ppppppfStack_518 = ppppppfStack_384;
      ppppppfStack_508 = (float ******)0x0;
      ppppppfStack_504 = ppppppfStack_2dc;
      ppppppfStack_51c = (float ******)0x4f1370;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_52c = (float ******)0xb;
      ppppppfStack_528 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x2;
      ppppppfStack_524 = ppppppfStack_2e4;
      ppppppfStack_530 = ppppppfStack_384;
      ppppppfStack_520 = (float ******)0x2;
      ppppppfStack_51c = ppppppfStack_2dc;
      uStack_538 = (double)CONCAT44(0x4f13ad,(undefined4)uStack_538);
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x2;
      ppppppfStack_544 = (float ******)0x28;
      ppppppfStack_540 = (float ******)0x2;
      ppppppfStack_2e0 = (float ******)0x4;
      ppppppfStack_53c = ppppppfStack_2e4;
      ppppppfStack_548 = ppppppfStack_384;
      uStack_538 = (double)CONCAT44(ppppppfStack_2dc,4);
      ppppppfStack_54c = (float ******)0x4f13ea;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_308 = (float ******)0x3;
      ppppppfStack_558 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_554 = ppppppfStack_2e4;
      ppppppfStack_550 = (float ******)0x0;
      ppppppfStack_54c = ppppppfStack_2dc;
      ppppppfStack_568 = (float ******)0x3;
      ppppppfStack_564 = ppppppfStack_304;
      ppppppfStack_560 = (float ******)0x2;
      ppppppfStack_55c = (float ******)pppppppfVar11;
      ppppppfStack_57c = (float ******)0x2;
      ppppppfStack_580 = (float ******)0x41;
      ppppppfStack_578 = (float ******)0x8;
      ppppppfStack_574 = ppppppfStack_324;
      ppppppfStack_570 = (float ******)0x414bd8;
      ppppppfStack_56c = ppppppfStack_31c;
      uStack_588 = (double)CONCAT44(ppppppfStack_384,0x4f1473);
      __vbaLateIdCallSt();
      ppppppfStack_2e0 = (float ******)0x0;
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_55c = (float ******)0xa;
      ppppppfStack_558 = (float ******)0x3;
      ppppppfStack_554 = ppppppfStack_2e4;
      ppppppfStack_560 = ppppppfStack_384;
      ppppppfStack_550 = (float ******)0x0;
      ppppppfStack_54c = ppppppfStack_2dc;
      ppppppfStack_564 = (float ******)0x4f14ad;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x3;
      ppppppfStack_2e0 = (float ******)0x3;
      ppppppfStack_570 = (float ******)0x3;
      ppppppfStack_574 = (float ******)0xb;
      ppppppfStack_56c = ppppppfStack_2e4;
      ppppppfStack_578 = ppppppfStack_384;
      ppppppfStack_568 = (float ******)0x3;
      ppppppfStack_564 = ppppppfStack_2dc;
      ppppppfStack_57c = (float ******)0x4f14e7;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x2;
      ppppppfStack_58c = (float ******)0x28;
      ppppppfStack_2e0 = (float ******)0x4;
      uStack_588 = (double)CONCAT44(ppppppfStack_2e4,2);
      ppppppfStack_580 = (float ******)0x4;
      ppppppfStack_57c = ppppppfStack_2dc;
      uStack_594._4_4_ = (float *******)ppppppfStack_384;
      uStack_594._0_4_ = 0x4f1524;
      __vbaLateIdSt();
      ppppppfStack_2e8 = (float ******)0x8;
      iStack_5a4 = 0;
      ppppppfStack_2e0 = (float ******)0x414c60;
      uStack_5a0 = (double)CONCAT44(ppppppfStack_2e4,8);
      ppppppfStack_598 = (float ******)0x414c60;
      uStack_594 = (double)CONCAT44(uStack_594._4_4_,ppppppfStack_2dc);
      uStack_5ac = (double)CONCAT44(ppppppfStack_384,0x4f1561);
      __vbaLateIdSt();
      sStack_3e4 = DAT_0050b332;
      pppppfStack_250 = (float *****)&DAT_00000001;
      pppppppfVar10 = DAT_0050b3cc;
      ppppppfVar21 = (float ******)pppppfStack_250;
      goto LAB_004f157d;
    }
  }
  goto LAB_004f2fd8;
LAB_004f157d:
  do {
    pppppfStack_250 = (float *****)ppppppfVar21;
    pppppppfVar18 = (float *******)pppppfStack_250;
    sVar7 = (short)pppppfStack_250;
    if (sStack_3e4 < sVar7) goto LAB_004f2f35;
    if ((pppppppfVar10 == (float *******)0x0) || (*(short *)pppppppfVar10 != 2)) {
      ppppppfStack_504 = (float ******)0x4f15e6;
      iVar19 = __vbaGenerateBoundsError();
      pppppppfVar10 = DAT_0050b3cc;
    }
    else {
      pppppppfVar11 = (float *******)((int)sVar7 - (int)pppppppfVar10[7]);
      if (pppppppfVar10[6] <= pppppppfVar11) {
        ppppppfStack_504 = (float ******)0x4f15a9;
        __vbaGenerateBoundsError();
        pppppppfVar10 = DAT_0050b3cc;
      }
      ppppppfStack_360 = (float ******)-(int)pppppppfVar10[5];
      if (pppppppfVar10[4] <= ppppppfStack_360) {
        ppppppfStack_504 = (float ******)0x4f15c7;
        __vbaGenerateBoundsError();
        pppppppfVar10 = DAT_0050b3cc;
      }
      iVar19 = (int)((int)pppppppfVar10[6] * (int)ppppppfStack_360 + (int)pppppppfVar11) * 4;
    }
    uVar23 = 0;
    if (*(float *)((int)pppppppfVar10[3] + iVar19) != _DAT_00402558) {
      if ((pppppppfVar10 == (float *******)0x0) || (*(short *)pppppppfVar10 != 2)) {
        ppppppfStack_504 = (float ******)0x4f165d;
        iVar19 = __vbaGenerateBoundsError();
        pppppppfVar10 = DAT_0050b3cc;
      }
      else {
        ppppppfStack_364 = (float ******)-(int)pppppppfVar10[7];
        if (pppppppfVar10[6] <= ppppppfStack_364) {
          ppppppfStack_504 = (float ******)0x4f1625;
          __vbaGenerateBoundsError();
          pppppppfVar10 = DAT_0050b3cc;
        }
        pppppppfVar11 = (float *******)((int)sVar7 - (int)pppppppfVar10[5]);
        if (pppppppfVar10[4] <= pppppppfVar11) {
          ppppppfStack_504 = (float ******)0x4f1640;
          __vbaGenerateBoundsError();
          pppppppfVar10 = DAT_0050b3cc;
        }
        iVar19 = (int)((int)pppppppfVar10[6] * (int)pppppppfVar11 + (int)ppppppfStack_364) * 4;
      }
      uVar23 = 0;
      if (*(float *)((int)pppppppfVar10[3] + iVar19) != _DAT_00401488) {
        ppppppfStack_2e8 = (float ******)0x3;
        ppppppfStack_308 = (float ******)0x3;
        ppppppfStack_508 = (float ******)0x4f169b;
        ppppppfStack_504 = (float ******)pppppppfVar18;
        ppppppfStack_2e0 = (float ******)(int)sVar7;
        ppppppfStack_52c = (float ******)__vbaStrI2();
        pppppppfVar18 = &ppppppfStack_524;
        ppppppfStack_514 = ppppppfStack_2e8;
        pppppfStack_2a8 = (float *****)0x8;
        ppppppfStack_510 = ppppppfStack_2e4;
        ppppppfStack_50c = ppppppfStack_2e0;
        ppppppfStack_508 = ppppppfStack_2dc;
        ppppppfStack_524 = ppppppfStack_308;
        ppppppfStack_520 = ppppppfStack_304;
        ppppppfStack_51c = (float ******)0x0;
        ppppppfStack_518 = ppppppfStack_2fc;
        ppppppfStack_53c = (float ******)0x41;
        uStack_538 = 1.69759663287103e-313;
        ppppppfStack_530 = ppppppfStack_2a4;
        ppppppfStack_540 = ppppppfStack_384;
        ppppppfStack_528 = ppppppfStack_29c;
        ppppppfStack_544 = (float ******)0x4f1715;
        ppppppfStack_2a0 = ppppppfStack_52c;
        __vbaLateIdCallSt();
        ppppppfStack_508 = (float ******)0x4f1721;
        __vbaFreeVar();
        ppppppfStack_274 = (float ******)0x0;
        ppppppfStack_508 = (float ******)0x4f1738;
        __vbaStrCopy();
        if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
          ppppppfStack_504 = (float ******)0x4f178a;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          uVar20 = (int)(int)sVar7 - *(int *)(DAT_0050b3e8 + 0xe);
          if (*(uint *)(DAT_0050b3e8 + 0xc) <= uVar20) {
            ppppppfStack_504 = (float ******)0x4f175a;
            __vbaGenerateBoundsError();
          }
          pppppppfVar18 = (float *******)-*(int *)(DAT_0050b3e8 + 10);
          if (*(float *******)(DAT_0050b3e8 + 8) <= pppppppfVar18) {
            ppppppfStack_504 = (float ******)0x4f1772;
            __vbaGenerateBoundsError();
          }
          iVar19 = (*(int *)(DAT_0050b3e8 + 0xc) * (int)pppppppfVar18 + uVar20) * 2;
        }
        pppppppfVar11 = (float *******)__vbaStrMove_exref;
        uStack_254 = 1;
        pppppfStack_258 =
             (float *****)
             CONCAT22(pppppfStack_258._2_2_,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar19));
        uVar20 = uStack_254;
        while( true ) {
          uStack_254 = uVar20;
          if ((short)pppppfStack_258 < (short)uStack_254) break;
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_504 = (float ******)0x4f1812;
            iVar19 = __vbaGenerateBoundsError();
          }
          else {
            ppppppfStack_364 =
                 (float ******)((int)(short)pppppfStack_250 - *(int *)(DAT_0050b3e8 + 0xe));
            if (*(float ********)(DAT_0050b3e8 + 0xc) <= ppppppfStack_364) {
              ppppppfStack_504 = (float ******)0x4f17de;
              __vbaGenerateBoundsError();
            }
            iVar13 = (int)(short)uStack_254;
            iVar19 = *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= (uint)(iVar13 - iVar19)) {
              ppppppfStack_504 = (float ******)0x4f17fa;
              __vbaGenerateBoundsError();
            }
            iVar19 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * (iVar13 - iVar19) + (int)ppppppfStack_364)
                     * 2;
          }
          pppppfStack_264 =
               (float *****)
               CONCAT22((short)((uint)iVar19 >> 0x10),
                        *(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar19));
          if ((DAT_0050b3e8 == (short *)0x0) || (*DAT_0050b3e8 != 2)) {
            ppppppfStack_504 = (float ******)0x4f188b;
            iVar19 = __vbaGenerateBoundsError();
            uVar14 = extraout_var_02;
          }
          else {
            pppppppfVar18 = *(float ********)(DAT_0050b3e8 + 0xe);
            pppppppfVar10 = *(float ********)(DAT_0050b3e8 + 0xc);
            ppppppfStack_364 = (float ******)((int)(short)pppppfStack_250 - (int)pppppppfVar18);
            if (pppppppfVar10 <= ppppppfStack_364) {
              ppppppfStack_504 = (float ******)0x4f1848;
              __vbaGenerateBoundsError();
              pppppppfVar10 = extraout_EDX;
            }
            uVar14 = (undefined2)((uint)pppppppfVar10 >> 0x10);
            if (SCARRY2((short)uStack_254,1)) goto LAB_004f2fd8;
            uVar20 = (int)(short)((short)uStack_254 + 1) - *(int *)(DAT_0050b3e8 + 10);
            if (*(uint *)(DAT_0050b3e8 + 8) <= uVar20) {
              ppppppfStack_504 = (float ******)0x4f186f;
              __vbaGenerateBoundsError();
              uVar14 = extraout_var_01;
            }
            iVar19 = (int)(*(int *)(DAT_0050b3e8 + 0xc) * uVar20 + (int)ppppppfStack_364) * 2;
          }
          pppppfStack_26c =
               (float *****)CONCAT22(uVar14,*(undefined2 *)(*(int *)(DAT_0050b3e8 + 6) + iVar19));
          ppppppfStack_508 = (float ******)&ppppppfStack_2e8;
          ppppppfStack_2e0 = &pppppfStack_264;
          ppppppfStack_504 = (float ******)DAT_0050b348;
          ppppppfStack_2e8 = (float ******)0x4002;
          ppppppfStack_50c = (float ******)0x4f18c2;
          Ordinal_536();
          ppppppfStack_50c = (float ******)0x4f18c9;
          ppppppfStack_50c = (float ******)__vbaStrMove();
          pppppppfVar18 = (float *******)__vbaStrCat_exref;
          ppppppfStack_510 = (float ******)0x4f18d2;
          __vbaStrCat();
          ppppppfStack_510 = (float ******)0x4f18d9;
          ppppppfStack_510 = (float ******)__vbaStrMove();
          ppppppfStack_514 = (float ******)&DAT_0040cc9c;
          ppppppfStack_518 = (float ******)0x4f18e1;
          __vbaStrCat();
          ppppppfStack_518 = (float ******)0x4f18ea;
          __vbaStrMove();
          ppppppfStack_518 = &pppppfStack_280;
          ppppppfStack_51c = (float ******)&ppppppfStack_27c;
          ppppppfStack_520 = (float ******)0x2;
          ppppppfStack_524 = (float ******)0x4f18fa;
          __vbaFreeStrList();
          if ((short)uStack_254 == (short)pppppfStack_258) break;
          if ((DAT_0050b3c8 == (float *******)0x0) || (*(short *)DAT_0050b3c8 != 2)) {
            ppppppfStack_504 = (float ******)0x4f1970;
            iVar19 = __vbaGenerateBoundsError();
          }
          else {
            ppppppfStack_364 = (float ******)((int)(short)pppppfStack_264 - (int)DAT_0050b3c8[7]);
            if (DAT_0050b3c8[6] <= ppppppfStack_364) {
              ppppppfStack_504 = (float ******)0x4f1937;
              __vbaGenerateBoundsError();
            }
            pppppppfVar18 = (float *******)((int)(short)pppppfStack_26c - (int)DAT_0050b3c8[5]);
            if (DAT_0050b3c8[4] <= pppppppfVar18) {
              ppppppfStack_504 = (float ******)0x4f1953;
              __vbaGenerateBoundsError();
            }
            iVar19 = (int)((int)DAT_0050b3c8[6] * (int)pppppppfVar18 + (int)ppppppfStack_364) * 4;
          }
          ppppppfStack_274 =
               (float ******)((float)ppppppfStack_274 + *(float *)((int)DAT_0050b3c8[3] + iVar19));
          pppppppfVar10 = (float *******)ppppppfStack_500;
          if ((uVar23 & 0xd) != 0) goto LAB_004f2fd3;
          uVar20 = (uint)(ushort)((short)uStack_254 + 1);
          if (SCARRY2((short)uStack_254,1)) goto LAB_004f2fd8;
        }
        ppppppfStack_504 = (float ******)DAT_0050b348;
        ppppppfStack_508 = (float ******)0x4f19b6;
        __vbaLenBstr();
        ppppppfStack_508 = (float ******)0x4f19be;
        sVar7 = __vbaI2I4();
        if (SBORROW2(sVar7,1)) break;
        ppppppfStack_2a0 = (float ******)CONCAT22(ppppppfStack_2a0._2_2_,sVar7 + -1);
        ppppppfStack_504 = &pppppfStack_2a8;
        ppppppfStack_508 = (float ******)&DAT_00000001;
        ppppppfStack_50c = (float ******)DAT_0050b348;
        pppppfStack_2a8 = (float *****)0x2;
        ppppppfStack_510 = (float ******)0x4f19e6;
        Ordinal_631();
        ppppppfStack_510 = (float ******)0x4f19ef;
        __vbaStrMove();
        ppppppfStack_510 = (float ******)0x4f19f8;
        __vbaFreeVar();
        ppppppfVar21 = (float ******)(int)(short)pppppfStack_250;
        ppppppfStack_2e8 = (float ******)0x3;
        ppppppfStack_308 = (float ******)0x3;
        ppppppfStack_51c = (float ******)0x3;
        ppppppfStack_518 = ppppppfStack_2e4;
        ppppppfStack_510 = ppppppfStack_2dc;
        ppppppfStack_52c = (float ******)0x3;
        ppppppfStack_528 = ppppppfStack_304;
        ppppppfStack_540 = (float ******)0x2;
        ppppppfStack_544 = (float ******)0x41;
        ppppppfStack_524 = (float ******)0x1;
        ppppppfStack_520 = ppppppfStack_2fc;
        ppppppfStack_53c = (float ******)0x4008;
        uStack_538 = (double)CONCAT44(&DAT_0050b348,ppppppfStack_324);
        ppppppfStack_530 = ppppppfStack_31c;
        ppppppfStack_548 = ppppppfStack_384;
        ppppppfStack_54c = (float ******)0x4f1a89;
        ppppppfStack_514 = ppppppfVar21;
        ppppppfStack_2e0 = ppppppfVar21;
        __vbaLateIdCallSt();
        ppppppfStack_510 = (float ******)0x4f1a91;
        FUN_0044fdc0();
        ppppppfStack_510 = (float ******)0x4f1a98;
        __vbaStrMove();
        ppppppfStack_2a0 = ppppppfStack_27c;
        ppppppfStack_514 = &pppppfStack_278;
        ppppppfStack_510 = (float ******)DAT_0050b3d4;
        pppppfStack_2f8 = (float *****)0x3;
        ppppppfStack_27c = (float ******)0x0;
        pppppfStack_2a8 = (float *****)0x8;
        ppppppfStack_518 = (float ******)0x4f1acd;
        pppppfStack_2f0 = (float *****)ppppppfVar21;
        __vbaAryLock();
        if (((float ******)pppppfStack_278 == (float ******)0x0) || (*(short *)pppppfStack_278 != 1)
           ) {
          ppppppfStack_518 = (float ******)0x4f1b08;
          iVar19 = __vbaGenerateBoundsError();
        }
        else {
          ppppppfStack_360 = (float ******)((int)ppppppfVar21 - (int)pppppfStack_278[5]);
          if (pppppfStack_278[4] <= ppppppfStack_360) {
            ppppppfStack_518 = (float ******)0x4f1af4;
            __vbaGenerateBoundsError();
          }
          iVar19 = (int)ppppppfStack_360 << 2;
        }
        ppppppfStack_518 = (float ******)&DAT_00000001;
        ppppppfStack_2e0 = (float ******)((int)pppppfStack_278[3] + iVar19);
        ppppppfStack_520 = &pppppfStack_2a8;
        ppppppfStack_51c = (float ******)&DAT_00000001;
        ppppppfStack_524 = (float ******)&ppppppfStack_2e8;
        ppppppfStack_528 = apppppfStack_2b8;
        ppppppfStack_2e8 = (float ******)0x4004;
        ppppppfStack_52c = (float ******)0x4f1b39;
        Ordinal_660();
        ppppppfStack_52c = &pppppfStack_278;
        ppppppfStack_530 = (float ******)0x4f1b43;
        __vbaAryUnlock();
        ppppppfStack_530 = apppppfStack_2b8;
        uStack_538 = (double)CONCAT44(0x4f1b4d,(undefined4)uStack_538);
        ppppppfStack_558 = (float ******)__vbaStrVarMove();
        pppppfStack_2c8 = (float *****)0x8;
        ppppppfStack_540 = (float ******)pppppfStack_2f8;
        ppppppfStack_53c = (float ******)pppppfStack_2f4;
        uStack_538 = (double)CONCAT44(uStack_2ec,pppppfStack_2f0);
        ppppppfStack_550 = (float ******)0x3;
        ppppppfStack_54c = ppppppfStack_314;
        ppppppfStack_548 = (float ******)0x2;
        ppppppfStack_544 = (float ******)pppppfStack_30c;
        ppppppfStack_564 = (float ******)0x2;
        ppppppfStack_568 = (float ******)0x41;
        ppppppfStack_560 = (float ******)0x8;
        ppppppfStack_55c = (float ******)uStack_2c4;
        ppppppfStack_56c = ppppppfStack_384;
        ppppppfStack_554 = ppppppfStack_2bc;
        ppppppfStack_570 = (float ******)0x4f1bd7;
        uStack_2c0 = ppppppfStack_558;
        __vbaLateIdCallSt();
        uStack_538 = (double)CONCAT44(0x4f1be3,(undefined4)uStack_538);
        __vbaFreeStr();
        ppppppfStack_53c = &pppppfStack_2a8;
        uStack_538 = (double)CONCAT44(&pppppfStack_2c8,apppppfStack_2b8);
        ppppppfStack_540 = (float ******)0x3;
        ppppppfStack_544 = (float ******)0x4f1bfa;
        __vbaFreeVarList();
        uStack_538 = (double)(float)ppppppfStack_274;
        ppppppfStack_53c = (float ******)0x4f1c09;
        fVar24 = (float10)Ordinal_614();
        uStack_35c = (double)fVar24;
        ppppppfStack_53c = (float ******)0x4f1c14;
        FUN_0044fdc0();
        ppppppfStack_53c = (float ******)0x4f1c1b;
        __vbaStrMove();
        pppppfStack_2b0 = (float *****)ppppppfStack_27c;
        pppppppfVar11 = (float *******)0x3;
        pppppfStack_2f8 = (float *****)0x3;
        ppppppfStack_27c = (float ******)0x0;
        ppppppfStack_2a0 = (float ******)(float *******)uStack_35c;
        ppppppfStack_53c = (float ******)&DAT_00000001;
        ppppppfStack_544 = apppppfStack_2b8;
        ppppppfStack_29c = (float ******)uStack_35c._4_4_;
        ppppppfStack_540 = (float ******)&DAT_00000001;
        ppppppfStack_548 = &pppppfStack_2a8;
        ppppppfStack_54c = &pppppfStack_2c8;
        apppppfStack_2b8[0] = (float *****)0x8;
        pppppfStack_2a8 = (float *****)0x5;
        ppppppfStack_550 = (float ******)0x4f1c74;
        pppppfStack_2f0 = (float *****)ppppppfVar21;
        Ordinal_660();
        ppppppfStack_550 = &pppppfStack_2c8;
        ppppppfStack_554 = (float ******)0x4f1c81;
        ppppppfStack_578 = (float ******)__vbaStrVarMove();
        pppppfStack_2d8 = (float *****)0x8;
        ppppppfStack_560 = (float ******)pppppfStack_2f8;
        ppppppfStack_55c = (float ******)pppppfStack_2f4;
        ppppppfStack_558 = (float ******)pppppfStack_2f0;
        ppppppfStack_554 = (float ******)uStack_2ec;
        ppppppfStack_570 = (float ******)0x3;
        ppppppfStack_56c = ppppppfStack_314;
        ppppppfStack_568 = (float ******)0x3;
        ppppppfStack_564 = (float ******)pppppfStack_30c;
        uStack_588 = 4.24399161404481e-314;
        ppppppfStack_580 = (float ******)0x8;
        ppppppfStack_57c = ppppppfStack_2d4;
        ppppppfStack_58c = ppppppfStack_384;
        ppppppfStack_574 = (float ******)pppppfStack_2cc;
        uStack_594 = (double)CONCAT44(0x4f1d04,(undefined4)uStack_594);
        ppppppfStack_2d0 = ppppppfStack_578;
        __vbaLateIdCallSt();
        ppppppfStack_554 = (float ******)0x4f1d10;
        __vbaFreeStr();
        ppppppfStack_554 = &pppppfStack_2d8;
        ppppppfStack_558 = &pppppfStack_2c8;
        ppppppfStack_55c = apppppfStack_2b8;
        ppppppfStack_560 = &pppppfStack_2a8;
        ppppppfStack_564 = (float ******)0x4;
        ppppppfStack_568 = (float ******)0x4f1d2e;
        __vbaFreeVarList();
        pppppppfVar10 = DAT_0050b3cc;
        pppppppfVar18 = (float *******)pppppfStack_250;
      }
    }
    ppppppfVar21 = (float ******)(uint)(ushort)((short)pppppppfVar18 + 1);
  } while (!SCARRY2((short)pppppppfVar18,1));
LAB_004f2fd8:
  ppppppfStack_504 = (float ******)0x4f2fde;
  __vbaErrorOverflow();
  ppppppfStack_510 = (float ******)&DAT_00402706;
  ppppppfStack_514 = ExceptionList;
  ppppppfStack_50c = (float ******)&pcStack_5b8;
  ppppppfStack_508 = (float ******)&DAT_004025b8;
  ppppppfStack_518 = (float ******)0x0;
  ppppppfStack_51c = (float ******)0x0;
  ppppppfStack_52c = (float ******)0x0;
  ppppppfStack_53c = (float ******)0x0;
  ppppppfStack_570 = (float ******)0x0;
  ppppppfStack_544 = (float ******)&DAT_0050b3c4;
  ppppppfStack_54c = (float ******)0x4002;
  ExceptionList = &ppppppfStack_514;
  pcStack_5b8 = pcVar22;
  ppppppfStack_5b4 = (float ******)pppppppfVar18;
  ppppppfStack_5b0 = (float ******)pppppppfVar11;
  ppppppfStack_504 = (float ******)&ppppppfStack_23c;
  __vbaAryLock(&ppppppfStack_518,DAT_0050b3cc);
  if ((ppppppfStack_518 == (float ******)0x0) || (*(short *)ppppppfStack_518 != 2)) {
    iVar19 = __vbaGenerateBoundsError();
  }
  else {
    pppppfVar9 = ppppppfStack_518[7];
    if (ppppppfStack_518[6] <= (float *****)-(int)pppppfVar9) {
      __vbaGenerateBoundsError();
    }
    pppppfVar4 = ppppppfStack_518[5];
    if (ppppppfStack_518[4] <= (float *****)-(int)pppppfVar4) {
      __vbaGenerateBoundsError();
    }
    iVar19 = (int)((int)ppppppfStack_518[6] * -(int)pppppfVar4 + -(int)pppppfVar9) * 4;
  }
  uStack_538 = (double)CONCAT44((int)ppppppfStack_518[3] + iVar19,(undefined4)uStack_538);
  ppppppfStack_53c = (float ******)0x4004;
  FUN_0042af50(&ppppppfStack_52c,&ppppppfStack_53c,&ppppppfStack_54c);
  __vbaAryUnlock(&ppppppfStack_518);
  pppppppfVar18 = &ppppppfStack_52c;
  DAT_0050b27c = __vbaI2Var(pppppppfVar18);
  __vbaFreeVar();
  DAT_0050b280 = DAT_0050b27c;
  DAT_0050b1d4 = 1;
  if (10 < DAT_0050b27c) {
    ppppppfStack_580 = (float ******)(int)DAT_0050b27c;
    uStack_588 = (double)(int)ppppppfStack_580;
    if ((uVar23 & 0xd) != 0) goto LAB_004f3326;
    ppppppfStack_570 = (float ******)__vbaFpI2();
    DAT_0050b1d4 = FUN_00476930(&ppppppfStack_570);
  }
  ppppppfStack_58c = (float ******)(int)DAT_0050b27c;
  DAT_0050b27a = -DAT_0050b1d4;
  uStack_594 = (double)(int)ppppppfStack_58c;
  ppppppfStack_598 = (float ******)(int)DAT_0050b1d4;
  uStack_5a0 = (double)(int)ppppppfStack_598;
  if (DAT_0050b000 != 0) {
    dVar25 = uStack_5a0;
    adj_fdiv_m64();
    pppppppfVar18 = SUB84(dVar25,0);
  }
  if ((uVar23 & 0xd) == 0) {
    __vbaFPInt(pppppppfVar18);
    iStack_5a4 = (int)DAT_0050b1d4;
    uStack_5ac = (double)iStack_5a4;
    if ((uVar23 & 0xd) == 0) {
      DAT_0050b27c = __vbaFpI2();
      DAT_0050b27e = DAT_0050b27a;
      DAT_0050b280 = DAT_0050b27c;
      if (DAT_0050b570 == (int *)0x0) {
        __vbaNew2(&DAT_004048dc,&DAT_0050b570);
      }
      uVar8 = (**(code **)(*DAT_0050b570 + 0x350))(DAT_0050b570);
      piVar12 = (int *)__vbaObjSet(&ppppppfStack_51c,uVar8);
      ppppppfStack_564 = (float ******)CONCAT22(ppppppfStack_564._2_2_,DAT_0050b27e);
      ppppppfStack_554 = (float ******)CONCAT22(ppppppfStack_554._2_2_,DAT_0050b27c);
      ppppppfStack_544 = (float ******)CONCAT22(ppppppfStack_544._2_2_,DAT_0050b280);
      ppppppfStack_54c = (float ******)0x2;
      ppppppfStack_53c = (float ******)0x2;
      uStack_538._0_6_ = CONCAT24(DAT_0050b27a,(undefined4)uStack_538);
      iVar19 = (**(code **)(*piVar12 + 0x28c))
                         (piVar12,4,2,(undefined4)uStack_538,uStack_538._4_4_,ppppppfStack_530,2,
                          ppppppfStack_548,ppppppfStack_544,ppppppfStack_540,2,ppppppfStack_558,
                          ppppppfStack_554,ppppppfStack_550,2,ppppppfStack_568,ppppppfStack_564,
                          ppppppfStack_560);
      if (iVar19 < 0) {
        __vbaHresultCheckObj(iVar19,piVar12,&DAT_0040c908,0x28c);
      }
      __vbaFreeObj();
      return;
    }
  }
LAB_004f3326:
  __vbaFPException();
  return;
}


