/* entry 00482b00 name FUN_00482b00 size 3351 */
/* strings:
 * Optimal Tableau
 *  is optimal.  Alternative soltuion(s)detected: Click a nonbasic var with zj-cj=0 in last tableau, then click NEXT ITERATION button.  Output Summary cannot be used to view alternati
 */

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482b00(void)

{
  int iVar1;
  code *****pppppcVar2;
  float fVar3;
  code *******pppppppcVar4;
  undefined2 uVar5;
  code ******ppppppcVar6;
  code ******ppppppcVar7;
  code ******ppppppcVar8;
  code ******ppppppcVar9;
  int iVar10;
  code *******pppppppcVar11;
  undefined4 uVar12;
  int *piVar13;
  undefined2 extraout_var;
  short *psVar14;
  undefined2 extraout_var_00;
  short *extraout_EDX;
  short *psVar15;
  undefined2 extraout_var_01;
  undefined2 extraout_var_02;
  short sVar16;
  short sVar17;
  short sVar18;
  uint uVar19;
  code *******pppppppcVar20;
  code *****pppppcVar21;
  code *pcVar22;
  code *******pppppppcVar23;
  code *******pppppppcVar24;
  uint uVar25;
  int iVar26;
  int iVar27;
  undefined4 *unaff_EDI;
  code *******pppppppcVar28;
  bool bVar29;
  ushort in_FPUStatusWord;
  ushort uVar30;
  float10 fVar31;
  code *******pppppppcStack_374;
  code *******pppppppcStack_370;
  code *******pppppppcStack_36c;
  float fStack_368;
  float fStack_364;
  undefined4 uStack_360;
  int iStack_35c;
  float fStack_358;
  float fStack_354;
  float fStack_350;
  int *apiStack_344 [5];
  undefined4 uStack_330;
  code ******ppppppcStack_32c;
  code *******pppppppcStack_328;
  undefined4 uStack_324;
  undefined4 uStack_320;
  code *******pppppppcStack_31c;
  code ******ppppppcStack_318;
  float fStack_314;
  code *******pppppppcStack_310;
  undefined4 uStack_30c;
  code *******pppppppcStack_308;
  code *******pppppppcStack_304;
  code *******pppppppcStack_300;
  undefined4 uStack_2fc;
  code *******pppppppcStack_2f8;
  undefined4 uStack_2f4;
  code *******pppppppcStack_2f0;
  code *******pppppppcStack_2ec;
  code *******pppppppcStack_2e8;
  code ******ppppppcStack_2e4;
  code *******pppppppcStack_2e0;
  code *******pppppppcStack_2dc;
  code *******pppppppcStack_2d8;
  code *******pppppppcStack_2d4;
  code *******pppppppcStack_2d0;
  code *******pppppppcStack_2cc;
  code *******pppppppcStack_2c8;
  code *******pppppppcStack_2c4;
  code *******pppppppcStack_2c0;
  code *******pppppppcStack_2bc;
  code ******ppppppcStack_2b8;
  code ******ppppppcStack_2b4;
  code *pcStack_2b0;
  code *******pppppppcStack_2ac;
  uint uStack_2a8;
  int iStack_2a4;
  int iStack_2a0;
  int iStack_29c;
  int iStack_298;
  int iStack_294;
  int iStack_290;
  int iStack_28c;
  short sStack_26c;
  undefined4 uStack_264;
  short sStack_25c;
  undefined4 uStack_254;
  undefined4 uStack_24c;
  undefined4 uStack_244;
  undefined4 uStack_22c;
  undefined4 uStack_224;
  undefined4 uStack_21c;
  undefined4 uStack_214;
  undefined4 uStack_208;
  code *******apppppppcStack_1f8 [7];
  code *****pppppcStack_1dc;
  uint uStack_1d8;
  int iStack_1d4;
  undefined4 uStack_1c0;
  code *******pppppppcStack_1bc;
  code *******pppppppcStack_1b4;
  undefined4 uStack_1b0;
  code *******pppppppcStack_1ac;
  code ******ppppppcStack_1a4;
  undefined4 uStack_1a0;
  code *******pppppppcStack_19c;
  code *******pppppppcStack_194;
  undefined4 uStack_190;
  code ******ppppppcStack_18c;
  undefined4 uStack_184;
  code *******pppppppcStack_180;
  code *******pppppppcStack_17c;
  code *******pppppppcStack_178;
  code *******pppppppcStack_174;
  code ******ppppppcStack_170;
  code *******pppppppcStack_16c;
  undefined4 uStack_168;
  code *******pppppppcStack_164;
  code ******appppppcStack_160 [4];
  code ******ppppppcStack_150;
  undefined4 uStack_14c;
  code ******ppppppcStack_148;
  code ******ppppppcStack_144;
  code ******ppppppcStack_140;
  code ******ppppppcStack_13c;
  code ******ppppppcStack_138;
  code ******ppppppcStack_134;
  code ******ppppppcStack_130;
  code *******pppppppcStack_12c;
  code ******ppppppcStack_128;
  code *******pppppppcStack_124;
  code *******pppppppcStack_120;
  code *******pppppppcStack_11c;
  code *******pppppppcStack_118;
  wchar_t *pwStack_114;
  code ******ppppppcStack_110;
  code ******ppppppcStack_10c;
  code ******ppppppcStack_108;
  wchar_t *pwStack_104;
  short local_f0;
  short local_d4;
  code *****local_7c [2];
  undefined4 local_74;
  code ******local_6c [2];
  undefined4 local_64;
  code ******local_5c [4];
  code ******local_4c [2];
  undefined4 local_44;
  code *****local_3c;
  code ******local_38;
  code *****local_34 [2];
  undefined8 local_2c;
  uint local_24;
  undefined8 local_20;
  code *******local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff00;
  local_8 = &DAT_004020c0;
  local_34[0] = (code *****)0x0;
  local_38 = (code ******)0x0;
  local_3c = (code *****)0x0;
  local_4c[0] = (code ******)0x0;
  local_5c[0] = (code ******)0x0;
  local_6c[0] = (code ******)0x0;
  local_7c[0] = (code *****)0x0;
  pwStack_104 = L"둨傰\xe800ം";
  ExceptionList = &pvStack_14;
  FUN_00486d30();
  pwStack_104 = (wchar_t *)&DAT_0050b0b4;
  ppppppcStack_108 = (code ******)0x482b5e;
  FUN_00483860();
  uVar12 = _DAT_0050b20c;
  pcVar22 = __vbaGenerateBoundsError_exref;
  local_2c._0_4_ = (code *******)0x0;
  local_2c._4_4_ = 0;
  DAT_0050b260._0_2_ = 0;
  psVar14 = DAT_0050b0f4;
  uVar25 = 1;
  do {
    uVar19 = uVar25;
    sVar17 = DAT_0050b292;
    pppppppcVar23 = (code *******)0x0;
    local_d4 = (short)uVar12;
    sVar18 = (short)uVar19;
    if (local_d4 < sVar18) {
      DAT_0050b210 = 0;
      psVar14 = DAT_0050b1f8;
      psVar15 = DAT_0050b0f0;
      uVar25 = 1;
      goto LAB_00482caf;
    }
    if ((psVar14 == (short *)0x0) || (*psVar14 != 1)) {
      ppppppcStack_108 = (code ******)0x482bc0;
      iVar10 = __vbaGenerateBoundsError();
      psVar14 = DAT_0050b0f4;
    }
    else {
      pppppppcVar23 = (code *******)((int)sVar18 - *(int *)(psVar14 + 10));
      if (*(code ********)(psVar14 + 8) <= pppppppcVar23) {
        ppppppcStack_108 = (code ******)0x482baf;
        __vbaGenerateBoundsError();
        psVar14 = DAT_0050b0f4;
      }
      iVar10 = (int)pppppppcVar23 * 8;
    }
    in_FPUStatusWord = 0;
    if (*(double *)(*(int *)(psVar14 + 6) + iVar10) <
        (double)CONCAT44(local_2c._4_4_,(code *******)local_2c)) {
      if ((psVar14 == (short *)0x0) || (*psVar14 != 1)) {
        ppppppcStack_108 = (code ******)0x482c06;
        iVar10 = __vbaGenerateBoundsError();
        psVar14 = DAT_0050b0f4;
      }
      else {
        iVar10 = *(int *)(psVar14 + 10);
        if (*(uint *)(psVar14 + 8) <= (uint)(sVar18 - iVar10)) {
          ppppppcStack_108 = (code ******)0x482bf5;
          __vbaGenerateBoundsError();
          psVar14 = DAT_0050b0f4;
        }
        iVar10 = (sVar18 - iVar10) * 8;
      }
      pppppppcVar23 = *(code ********)(*(int *)(psVar14 + 6) + iVar10);
      local_2c._4_4_ = *(undefined4 *)(*(int *)(psVar14 + 6) + 4 + iVar10);
      local_2c._0_4_ = pppppppcVar23;
      if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
        ppppppcStack_108 = (code ******)0x482c50;
        iVar10 = __vbaGenerateBoundsError();
        psVar14 = DAT_0050b0f4;
      }
      else {
        pppppppcVar23 = (code *******)((int)sVar18 - *(int *)(DAT_0050b1f0 + 10));
        if (*(code ********)(DAT_0050b1f0 + 8) <= pppppppcVar23) {
          ppppppcStack_108 = (code ******)0x482c3d;
          __vbaGenerateBoundsError();
          psVar14 = DAT_0050b0f4;
        }
        iVar10 = (int)pppppppcVar23 * 2;
      }
      DAT_0050b260._0_2_ = *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar10);
      DAT_0050b260._2_2_ = sVar18;
    }
    uVar25 = (uint)(ushort)(sVar18 + 1);
  } while (!SCARRY2(sVar18,1));
  goto LAB_00483852;
  while( true ) {
    if ((psVar14 == (short *)0x0) || (*psVar14 != 1)) {
      ppppppcStack_108 = (code ******)0x482cea;
      iVar10 = __vbaGenerateBoundsError();
      psVar14 = DAT_0050b1f8;
      psVar15 = DAT_0050b0f0;
    }
    else {
      iVar10 = *(int *)(psVar14 + 10);
      if (*(uint *)(psVar14 + 8) <= (uint)(sVar16 - iVar10)) {
        ppppppcStack_108 = (code ******)0x482cd7;
        __vbaGenerateBoundsError();
        psVar14 = DAT_0050b1f8;
        psVar15 = DAT_0050b0f0;
      }
      iVar10 = (sVar16 - iVar10) * 2;
    }
    pppppppcVar23 = *(code ********)(psVar14 + 6);
    if (0 < *(short *)((int)pppppppcVar23 + iVar10)) {
      if ((psVar15 == (short *)0x0) || (*psVar15 != 1)) {
        ppppppcStack_108 = (code ******)0x482d32;
        iVar10 = __vbaGenerateBoundsError();
        psVar14 = DAT_0050b1f8;
        psVar15 = DAT_0050b0f0;
      }
      else {
        iVar10 = *(int *)(psVar15 + 10);
        if (*(uint *)(psVar15 + 8) <= (uint)(sVar16 - iVar10)) {
          ppppppcStack_108 = (code ******)0x482d1b;
          __vbaGenerateBoundsError();
          psVar14 = DAT_0050b1f8;
          psVar15 = DAT_0050b0f0;
        }
        iVar10 = (sVar16 - iVar10) * 8;
      }
      pppppppcVar23 = *(code ********)(psVar15 + 6);
      in_FPUStatusWord = 0;
      if (*(double *)((int)pppppppcVar23 + iVar10) == _DAT_00401490) {
        DAT_0050b210 = 1;
        uVar19 = (uint)(ushort)(DAT_0050b292 + 1);
        if (SCARRY2(DAT_0050b292,1)) break;
      }
    }
    uVar25 = (uint)(ushort)((short)uVar19 + 1);
    if (SCARRY2((short)uVar19,1)) break;
LAB_00482caf:
    uVar19 = uVar25;
    sVar18 = DAT_0050b292;
    sVar16 = (short)uVar19;
    if (sVar17 < sVar16) {
      if ((short)DAT_0050b260 != 0) {
        DAT_0050b25e = 0;
        local_2c = (double)CONCAT44(DAT_0050b138,DAT_0050b134);
        local_24 = 1;
        uVar25 = local_24;
        goto LAB_0048300d;
      }
      if (DAT_0050b1e0 == 0) {
        if (DAT_0050b210 == 0) {
          local_74 = 0x80020004;
          local_64 = 0x80020004;
          pppppppcVar23 = (code *******)0x8;
          local_7c[0] = (code *****)0xa;
          local_6c[0] = (code ******)0xa;
          ppppppcStack_108 = (code ******)0x482ea6;
          __vbaVarDup();
          pwStack_104 = L"Iteration ";
          ppppppcStack_108 = (code ******)CONCAT22(extraout_var,DAT_0050b244 + 1);
          if (SCARRY2(DAT_0050b244,1)) break;
          ppppppcStack_10c = (code ******)0x482ec3;
          __vbaStrI2();
          ppppppcStack_10c = (code ******)0x482ed0;
          ppppppcStack_10c = (code ******)__vbaStrMove();
          ppppppcStack_110 = (code ******)0x482ed9;
          __vbaStrCat();
          ppppppcStack_110 = (code ******)0x482ee0;
          ppppppcStack_110 = (code ******)__vbaStrMove();
          pwStack_114 = L" is optimal";
          pppppppcStack_118 = (code *******)0x482ee8;
          local_44 = __vbaStrCat();
          pppppppcStack_118 = (code *******)local_7c;
          pppppppcStack_11c = local_6c;
          pppppppcStack_120 = local_5c;
          ppppppcStack_128 = (code ******)local_4c;
          pppppppcStack_124 = (code *******)0x40;
          local_4c[0] = (code ******)0x8;
          pppppppcStack_12c = (code *******)0x482f06;
          Ordinal_595();
          pppppppcStack_12c = &local_38;
          ppppppcStack_130 = local_34;
          ppppppcStack_134 = (code ******)0x2;
          ppppppcStack_138 = (code ******)0x482f16;
          __vbaFreeStrList();
        }
        else {
          if (DAT_0050b210 != 1) goto LAB_00482f31;
          local_74 = 0x80020004;
          local_64 = 0x80020004;
          pppppppcVar23 = (code *******)0x8;
          local_7c[0] = (code *****)0xa;
          local_6c[0] = (code ******)0xa;
          ppppppcStack_108 = (code ******)0x482dea;
          __vbaVarDup();
          pwStack_104 = L"Iteration ";
          ppppppcStack_108 = (code ******)CONCAT22(extraout_var_00,DAT_0050b244 + 1);
          if (SCARRY2(DAT_0050b244,1)) break;
          ppppppcStack_10c = (code ******)0x482e07;
          __vbaStrI2();
          ppppppcStack_10c = (code ******)0x482e14;
          ppppppcStack_10c = (code ******)__vbaStrMove();
          ppppppcStack_110 = (code ******)0x482e1d;
          __vbaStrCat();
          ppppppcStack_110 = (code ******)0x482e24;
          ppppppcStack_110 = (code ******)__vbaStrMove();
          pwStack_114 = 
          L" is optimal.  Alternative soltuion(s)detected: Click a nonbasic var with zj-cj=0 in last tableau, then click NEXT ITERATION button.  Output Summary cannot be used to view alternative optima solution "
          ;
          pppppppcStack_118 = (code *******)0x482e2c;
          local_44 = __vbaStrCat();
          pppppppcStack_118 = (code *******)local_7c;
          pppppppcStack_11c = local_6c;
          pppppppcStack_120 = local_5c;
          ppppppcStack_128 = (code ******)local_4c;
          pppppppcStack_124 = (code *******)0x40;
          local_4c[0] = (code ******)0x8;
          pppppppcStack_12c = (code *******)0x482e4a;
          Ordinal_595();
          pppppppcStack_12c = &local_38;
          ppppppcStack_130 = local_34;
          ppppppcStack_134 = (code ******)0x2;
          ppppppcStack_138 = (code ******)0x482e5a;
          __vbaFreeStrList();
        }
        ppppppcStack_138 = local_7c;
        ppppppcStack_13c = (code ******)local_6c;
        ppppppcStack_140 = (code ******)local_5c;
        ppppppcStack_144 = (code ******)local_4c;
        ppppppcStack_148 = (code ******)0x4;
        uStack_14c = 0x482f2e;
        __vbaFreeVarList();
      }
LAB_00482f31:
      if (DAT_0050b420 == (code ******)0x0) {
        ppppppcStack_108 = (code ******)&DAT_0050b420;
        ppppppcStack_10c = (code ******)&DAT_00408c88;
        ppppppcStack_110 = (code ******)0x482f4a;
        __vbaNew2();
      }
      ppppppcStack_108 = DAT_0050b420;
      ppppppcStack_10c = (code ******)0x482f58;
      ppppppcStack_10c = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      ppppppcStack_110 = &local_3c;
      pwStack_114 = L"\xf08bj譖＆貐";
      pppppppcVar23 = (code *******)__vbaObjSet();
      pwStack_114 = (wchar_t *)0x0;
      pppppppcStack_11c = (code *******)0x482f72;
      pppppppcStack_118 = pppppppcVar23;
      ppppppcVar6 = (code ******)(*(code *)(*pppppppcVar23)[0x23])();
      if ((int)ppppppcVar6 < 0) {
        pppppppcStack_11c = (code *******)0x8c;
        pppppppcStack_120 = (code *******)&DAT_0040bb6c;
        pppppppcStack_12c = (code *******)0x482f8a;
        ppppppcStack_128 = ppppppcVar6;
        pppppppcStack_124 = pppppppcVar23;
        __vbaHresultCheckObj();
      }
      pcVar22 = __vbaFreeObj_exref;
      pppppppcStack_11c = (code *******)0x482f95;
      __vbaFreeObj();
      if (DAT_0050b420 == (code ******)0x0) {
        pppppppcStack_11c = &DAT_0050b420;
        pppppppcStack_120 = (code *******)&DAT_00408c88;
        pppppppcStack_124 = (code *******)0x482fae;
        __vbaNew2();
      }
      pppppppcStack_11c = (code *******)DAT_0050b420;
      pppppppcStack_120 = (code *******)0x482fbc;
      pppppppcStack_120 = (code *******)(*(code *)(*DAT_0050b420)[0xdd])();
      pppppppcStack_124 = (code *******)&local_3c;
      ppppppcStack_128 = (code ******)0x482fc3;
      ppppppcVar7 = (code ******)__vbaObjSet();
      ppppppcStack_128 = (code ******)0x0;
      ppppppcStack_130 = (code ******)0x482fd0;
      pppppppcStack_12c = (code *******)ppppppcVar7;
      ppppppcVar8 = (code ******)(*(code *)(*ppppppcVar7)[0x23])();
      ppppppcVar6 = ppppppcStack_13c;
      ppppppcVar9 = ppppppcStack_138;
      goto joined_r0x0048341e;
    }
  }
  goto LAB_00483852;
LAB_00484054:
  pppppppcStack_11c = pppppppcVar4;
  pppppppcVar24 = pppppppcVar23;
  sVar17 = (short)pppppppcVar24;
  if ((short)uStack_224 < sVar17) {
    pppppppcStack_2c0 = (code *******)0x0;
    pppppppcStack_2c4 = (code *******)0x4;
    pppppppcStack_2cc = &ppppppcStack_150;
    pppppppcStack_2c8 = apppppppcStack_1f8[0];
    pppppppcStack_2d0 = (code *******)0x484bec;
    pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
    pppppppcStack_2c4 = (code *******)0x484bf2;
    iVar10 = (*(code *)pppppppcVar28)();
    if (!SBORROW4(iVar10,5)) {
      pppppppcStack_2c0 = (code *******)0x484c03;
      uStack_244 = __vbaI2I4();
      pppppppcStack_11c = _DAT_0050b298;
      pppppppcStack_2c0 = (code *******)0x484c17;
      (*(code *)pppppppcVar20)();
      pppppppcVar20 = (code *******)__vbaLateIdCallSt_exref;
      pppppppcVar23 = pppppppcStack_11c;
      goto LAB_00484c1d;
    }
    goto LAB_00485a28;
  }
  pppppppcStack_2c0 = (code *******)0x0;
  pppppppcStack_2c4 = (code *******)0x5;
  pppppppcStack_2bc = &ppppppcStack_150;
  pppppppcStack_2c8 = apppppppcStack_1f8[0];
  if (SBORROW2(sVar17,DAT_0050b298)) goto LAB_00485a28;
  pppppppcStack_2d0 = (code *******)0x484089;
  pppppppcStack_12c =
       (code *******)CONCAT22((short)((uint)pppppppcVar11 >> 0x10),sVar17 - DAT_0050b298);
  pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
  pppppppcStack_2c4 = (code *******)0x484093;
  iVar10 = __vbaI4Var();
  if (SBORROW4(iVar10,1)) goto LAB_00485a28;
  pppppppcStack_2c0 = (code *******)0x4840a4;
  uStack_22c = __vbaI2I4();
  pppppppcStack_120 = (code *******)0x0;
  pppppppcStack_2c0 = (code *******)0x4840b4;
  (*(code *)pppppppcVar20)();
  pppppppcVar23 = (code *******)0x0;
  pppppppcVar4 = pppppppcStack_120;
  while( true ) {
    pppppppcStack_120 = pppppppcVar4;
    pppppppcVar28 = pppppppcVar23;
    pcVar22 = __vbaLateIdCallLd_exref;
    sVar18 = (short)pppppppcVar28;
    sVar17 = (short)pppppppcVar24;
    if ((short)uStack_22c < sVar18) break;
    if (SCARRY2(DAT_0050b298,1)) goto LAB_00485a28;
    if ((short)(DAT_0050b298 + 1) < sVar17) {
      if (sVar18 == 0) {
LAB_004843d2:
        if (sVar17 == DAT_0050b298) {
          pppppppcStack_2bc = &ppppppcStack_150;
          pppppppcStack_2c0 = (code *******)ppppppcStack_128;
          if (SCARRY2(DAT_0050b244,1)) goto LAB_00485a28;
          ppppppcStack_148 = (code ******)CONCAT22(ppppppcStack_148._2_2_,DAT_0050b244 + 1);
          ppppppcStack_150 = (code ******)0x2;
          pppppppcStack_2c8 = (code *******)0x484400;
          Ordinal_536();
          pppppppcStack_2c8 = (code *******)0x48440b;
          pppppppcStack_2c8 = (code *******)__vbaStrMove();
          pppppppcStack_2cc = (code *******)0x484412;
          __vbaStrCat();
          pppppppcStack_2cc = (code *******)0x48441f;
          __vbaStrMove();
          pppppppcStack_2cc = (code *******)0x484428;
          __vbaFreeStr();
          pppppppcStack_2cc = (code *******)0x48442d;
          (*(code *)pppppppcVar20)();
        }
        else {
          if (SCARRY2(DAT_0050b298,1)) goto LAB_00485a28;
          if (sVar17 != (short)(DAT_0050b298 + 1)) goto LAB_00484457;
          pppppppcStack_2c0 = (code *******)0x484451;
          __vbaStrCopy();
        }
        goto LAB_00484457;
      }
      pppppppcVar24 = (code *******)(int)(short)pppppppcStack_120;
      pppppppcStack_2c0 = (code *******)0x0;
      pppppppcStack_2c4 = (code *******)0x5;
      pppppppcStack_2cc = appppppcStack_160;
      pppppppcStack_2c8 = apppppppcStack_1f8[0];
      pppppppcStack_2d0 = (code *******)0x484101;
      pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
      pppppppcVar28 = (code *******)__vbaI4Var_exref;
      pppppppcStack_2c4 = (code *******)0x48410d;
      iVar10 = __vbaI4Var();
      pppppppcStack_2bc = (code *******)0x0;
      pppppppcVar20 = (code *******)pcVar22;
      if (SBORROW4(iVar10,1)) goto LAB_00485a28;
      pppppppcStack_2bc = (code *******)0x5;
      if (SBORROW4(iVar10 + -1,(int)DAT_0050b20c)) goto LAB_00485a28;
      pppppppcStack_2c4 = &ppppppcStack_150;
      iStack_28c = -(uint)((iVar10 + -1) - (int)DAT_0050b20c <= (int)pppppppcVar24);
      pppppppcStack_2c0 = apppppppcStack_1f8[0];
      pppppppcStack_2c8 = (code *******)0x484145;
      ppppppcStack_2b8 = (code ******)__vbaLateIdCallLd();
      pppppppcStack_2bc = (code *******)0x48414b;
      iVar10 = __vbaI4Var();
      if (SBORROW4(iVar10,2)) goto LAB_00485a28;
      uVar30 = (ushort)iStack_28c;
      if (SCARRY2(DAT_0050b298,2)) goto LAB_00485a28;
      if (SCARRY2(DAT_0050b298 + 2,DAT_0050b20c)) goto LAB_00485a28;
      pppppppcVar20 =
           (code *******)
           -(uint)((short)pppppppcStack_11c <= (short)(DAT_0050b298 + 2 + DAT_0050b20c));
      if (SCARRY2(DAT_0050b298,2)) goto LAB_00485a28;
      pppppppcStack_2c0 = appppppcStack_160;
      bVar29 = (short)(DAT_0050b298 + 2) < (short)pppppppcStack_11c;
      pppppppcStack_2c4 = &ppppppcStack_150;
      pppppppcStack_2c8 = (code *******)0x2;
      pppppppcStack_2cc = (code *******)0x4841bc;
      __vbaFreeVarList();
      pcVar22 = __vbaLateIdSt_exref;
      if ((ushort)(uVar30 & -(ushort)((int)pppppppcVar24 <= iVar10 + -2) & (ushort)pppppppcVar20 &
                  -(ushort)bVar29) != 0) {
        pppppppcStack_2c4 = (code *******)(int)(short)pppppppcStack_11c;
        pppppppcStack_180 = (code *******)0x3;
        pppppppcStack_2cc = (code *******)0x3;
        pppppppcStack_2d0 = (code *******)0xa;
        pppppppcStack_2c8 = pppppppcStack_17c;
        pppppppcStack_2d4 = apppppppcStack_1f8[0];
        pppppppcStack_2c0 = pppppppcStack_174;
        pppppppcStack_2d8 = (code *******)0x4841fe;
        pppppppcStack_178 = pppppppcStack_2c4;
        __vbaLateIdSt();
        pppppppcStack_180 = (code *******)0x3;
        pppppppcStack_2e8 = (code *******)0xb;
        ppppppcStack_2e4 = (code ******)0x3;
        pppppppcStack_2e0 = pppppppcStack_17c;
        pppppppcStack_2d8 = pppppppcStack_174;
        pppppppcStack_2ec = apppppppcStack_1f8[0];
        pppppppcStack_2f0 = (code *******)0x48422a;
        pppppppcStack_2dc = pppppppcVar24;
        pppppppcStack_178 = pppppppcVar24;
        __vbaLateIdSt();
        pppppppcStack_180 = (code *******)0x3;
        pppppppcStack_300 = (code *******)0x27;
        uStack_2fc = 3;
        pppppppcStack_178 = (code *******)0xff0000;
        pppppppcStack_2f8 = pppppppcStack_17c;
        pppppppcStack_304 = apppppppcStack_1f8[0];
        uStack_2f4 = 0xff0000;
        pppppppcStack_2f0 = pppppppcStack_174;
        pppppppcStack_308 = (code *******)0x48425b;
        __vbaLateIdSt();
        pppppppcStack_180 = (code *******)0x3;
        ppppppcStack_318 = (code ******)0x26;
        fStack_314 = 4.2039e-45;
        pppppppcStack_178 = (code *******)0xffffff;
        pppppppcStack_310 = pppppppcStack_17c;
        pppppppcStack_31c = apppppppcStack_1f8[0];
        uStack_30c = 0xffffff;
        pppppppcStack_308 = pppppppcStack_174;
        uStack_320 = 0x48428c;
        __vbaLateIdSt();
      }
      pppppppcStack_180 = (code *******)0x3;
      pppppppcStack_2d0 = (code *******)0xfffffdff;
      pppppppcStack_2cc = (code *******)0x3;
      pppppppcStack_178 = (code *******)0xffffff;
      pppppppcStack_2c8 = pppppppcStack_17c;
      pppppppcStack_2d4 = apppppppcStack_1f8[0];
      pppppppcStack_2c4 = (code *******)0xffffff;
      pppppppcStack_2c0 = pppppppcStack_174;
      pppppppcStack_2d8 = (code *******)0x4842c8;
      __vbaLateIdSt();
      pppppppcStack_2d8 = (code *******)0x4842cd;
      FUN_0044fdc0();
      pppppppcVar28 = (code *******)__vbaStrMove_exref;
      pppppppcStack_2d8 = (code *******)0x4842da;
      __vbaStrMove();
      ppppppcStack_148 = ppppppcStack_138;
      pppppppcStack_2dc = &ppppppcStack_134;
      pppppppcStack_2d8 = (code *******)*unaff_EDI;
      ppppppcStack_138 = (code ******)0x0;
      ppppppcStack_150 = (code ******)0x8;
      pppppppcStack_2e0 = (code *******)0x4842fe;
      __vbaAryLock();
      if ((ppppppcStack_134 == (code ******)0x0) || (*(short *)ppppppcStack_134 != 2)) {
        pppppppcStack_2c0 = (code *******)0x48435a;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        pppppppcVar20 = (code *******)pcVar22;
        if (SBORROW2((short)pppppppcStack_11c,DAT_0050b298)) goto LAB_00485a28;
        pppppcVar21 = (code *****)
                      ((int)(short)((short)pppppppcStack_11c - DAT_0050b298) -
                      (int)ppppppcStack_134[7]);
        if (ppppppcStack_134[6] <= pppppcVar21) {
          pppppppcStack_2c0 = (code *******)0x48432f;
          __vbaGenerateBoundsError();
        }
        pppppcVar2 = ppppppcStack_134[5];
        if (ppppppcStack_134[4] <= (code *****)((int)pppppppcVar24 - (int)pppppcVar2)) {
          pppppppcStack_2c0 = (code *******)0x484344;
          __vbaGenerateBoundsError();
        }
        iVar10 = (int)((int)pppppcVar21 +
                      (int)ppppppcStack_134[6] * ((int)pppppppcVar24 - (int)pppppcVar2)) * 8;
      }
      pppppppcStack_2c0 = (code *******)0x1;
      pppppppcStack_178 = (code *******)((int)ppppppcStack_134[3] + iVar10);
      pppppppcStack_2c8 = &ppppppcStack_150;
      pppppppcStack_2c4 = (code *******)&DAT_00000001;
      pppppppcStack_2cc = (code *******)&pppppppcStack_180;
      pppppppcStack_2d0 = appppppcStack_160;
      pppppppcStack_180 = (code *******)0x4005;
      pppppppcStack_2d4 = (code *******)0x484382;
      Ordinal_660();
      pppppppcStack_2d4 = &ppppppcStack_134;
      pppppppcStack_2d8 = (code *******)0x48438c;
      __vbaAryUnlock();
      pppppppcStack_2d8 = appppppcStack_160;
      pppppppcStack_2dc = (code *******)0x484396;
      __vbaStrVarMove();
      pppppppcStack_2dc = (code *******)0x48439f;
      __vbaStrMove();
      pppppppcStack_2dc = (code *******)0x4843a8;
      __vbaFreeStr();
      pppppppcStack_2dc = appppppcStack_160;
      pppppppcStack_2e0 = &ppppppcStack_150;
      ppppppcStack_2e4 = (code ******)0x2;
      pppppppcStack_2e8 = (code *******)0x4843b8;
      __vbaFreeVarList();
      pcVar22 = __vbaGenerateBoundsError_exref;
      pppppppcVar28 = pppppppcStack_120;
    }
    else {
      if (sVar18 == 0) goto LAB_004843d2;
LAB_00484457:
      if (SCARRY2(DAT_0050b298,1)) goto LAB_00485a28;
      sVar16 = DAT_0050b298;
      if ((sVar17 <= (short)(DAT_0050b298 + 1)) && (0 < sVar18)) {
        if ((short)pppppppcStack_11c == DAT_0050b298) {
          if (DAT_0050b20a < sVar18) {
LAB_00484719:
            pppppppcStack_2c0 = (code *******)0x484724;
            __vbaStrCopy();
          }
          else {
            if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
              pppppppcStack_2c0 = (code *******)0x4844c0;
              iVar10 = __vbaGenerateBoundsError();
            }
            else {
              iVar10 = *(int *)(DAT_0050b394 + 10);
              if (*(uint *)(DAT_0050b394 + 8) <= (uint)(sVar18 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x4844ac;
                __vbaGenerateBoundsError();
              }
              iVar10 = (sVar18 - iVar10) * 0x18;
            }
            pppppppcStack_2c0 = (code *******)(*(int *)(DAT_0050b394 + 6) + iVar10);
            pppppppcStack_2c4 = (code *******)0xc;
            pppppppcStack_2c8 = (code *******)0x4844d4;
            __vbaStrFixstr();
            pppppppcStack_2c8 = (code *******)0x4844e1;
            __vbaStrMove();
          }
LAB_00484724:
          sVar16 = DAT_0050b298;
        }
        else {
          if (SCARRY2(DAT_0050b298,1)) goto LAB_00485a28;
          if ((short)pppppppcStack_11c == (short)(DAT_0050b298 + 1)) {
            pppppppcStack_2c0 = (code *******)0x0;
            pppppppcStack_2c4 = (code *******)0x5;
            pppppppcStack_2cc = &ppppppcStack_150;
            pppppppcStack_2c8 = apppppppcStack_1f8[0];
            pppppppcVar24 = (code *******)(int)sVar18;
            pppppppcStack_2d0 = (code *******)0x48451e;
            pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
            pppppppcStack_2c4 = (code *******)0x484528;
            iVar10 = __vbaI4Var();
            if (SBORROW4(iVar10,1)) goto LAB_00485a28;
            pppppppcVar20 = (code *******)-(uint)((int)pppppppcVar24 < iVar10 + -1);
            pppppppcStack_2c0 = (code *******)0x48454e;
            __vbaFreeVar();
            if ((short)pppppppcVar20 == 0) {
              pppppppcStack_2c0 = (code *******)0x0;
              pppppppcStack_2c4 = (code *******)0x5;
              pppppppcStack_2cc = &ppppppcStack_150;
              pppppppcStack_2c8 = apppppppcStack_1f8[0];
              pppppppcStack_2d0 = (code *******)0x4846dd;
              pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
              pppppppcStack_2c4 = (code *******)0x4846e7;
              iVar10 = __vbaI4Var();
              if (!SBORROW4(iVar10,1)) {
                pppppppcStack_2c0 = (code *******)0x48470f;
                __vbaFreeVar();
                if (pppppppcVar24 == (code *******)(iVar10 + -1)) goto LAB_00484719;
                goto LAB_00484724;
              }
              goto LAB_00485a28;
            }
            if ((DAT_0050b3a8 == (short *)0x0) || (*DAT_0050b3a8 != 1)) {
              pppppppcStack_2c0 = (code *******)0x48458d;
              iStack_290 = __vbaGenerateBoundsError();
            }
            else {
              iVar10 = *(int *)(DAT_0050b3a8 + 10);
              if (*(uint *)(DAT_0050b3a8 + 8) <= (uint)((int)pppppppcVar24 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x48457c;
                __vbaGenerateBoundsError();
              }
              iStack_290 = ((int)pppppppcVar24 - iVar10) * 4;
            }
            if ((DAT_0050b3a4 == (short *)0x0) || (*DAT_0050b3a4 != 1)) {
              pppppppcStack_2c0 = (code *******)0x4845c3;
              iStack_294 = __vbaGenerateBoundsError();
            }
            else {
              iVar10 = *(int *)(DAT_0050b3a4 + 10);
              if (*(uint *)(DAT_0050b3a4 + 8) <= (uint)((int)pppppppcVar24 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x4845b2;
                __vbaGenerateBoundsError();
              }
              iStack_294 = ((int)pppppppcVar24 - iVar10) * 4;
            }
            if ((DAT_0050b39c == (short *)0x0) || (*DAT_0050b39c != 1)) {
              pppppppcStack_2c0 = (code *******)0x4845f9;
              iStack_298 = __vbaGenerateBoundsError();
            }
            else {
              iVar10 = *(int *)(DAT_0050b39c + 10);
              if (*(uint *)(DAT_0050b39c + 8) <= (uint)((int)pppppppcVar24 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x4845e8;
                __vbaGenerateBoundsError();
              }
              iStack_298 = ((int)pppppppcVar24 - iVar10) * 4;
            }
            if ((DAT_0050b3ac == (short *)0x0) || (*DAT_0050b3ac != 1)) {
              pppppppcStack_2c0 = (code *******)0x484627;
              iVar10 = __vbaGenerateBoundsError();
            }
            else {
              iVar10 = *(int *)(DAT_0050b3ac + 10);
              if (*(uint *)(DAT_0050b3ac + 8) <= (uint)((int)pppppppcVar24 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x48461c;
                __vbaGenerateBoundsError();
              }
              iVar10 = ((int)pppppppcVar24 - iVar10) * 4;
            }
            pppppppcStack_2c0 = *(code ********)(*(int *)(DAT_0050b3a8 + 6) + iStack_290);
            pppppppcStack_2c4 = *(code ********)(*(int *)(DAT_0050b3a4 + 6) + iStack_294);
            pppppppcStack_2c8 = (code *******)0x484656;
            __vbaStrCat();
            pppppppcStack_2c8 = (code *******)0x484663;
            pppppppcStack_2c8 = (code *******)__vbaStrMove();
            pppppppcStack_2cc = (code *******)0x48466a;
            Ordinal_519();
            pppppppcStack_2cc = (code *******)0x484671;
            pppppppcStack_2cc = (code *******)__vbaStrMove();
            pppppppcStack_2d0 = *(code ********)(*(int *)(DAT_0050b39c + 6) + iStack_298);
            pppppppcStack_2d4 = (code *******)0x484687;
            __vbaStrCat();
            pppppppcStack_2d4 = (code *******)0x48468e;
            pppppppcStack_2d4 = (code *******)__vbaStrMove();
            pppppppcStack_2d8 = *(code ********)(*(int *)(DAT_0050b3ac + 6) + iVar10);
            pppppppcStack_2dc = (code *******)0x48469d;
            __vbaStrCat();
            pppppppcStack_2dc = (code *******)0x4846a6;
            __vbaStrMove();
            pppppppcStack_2dc = &ppppppcStack_140;
            pppppppcStack_2e0 = &ppppppcStack_13c;
            ppppppcStack_2e4 = (code ******)&ppppppcStack_138;
            pppppppcStack_2e8 = (code *******)0x3;
            pppppppcStack_2ec = (code *******)0x4846ba;
            __vbaFreeStrList();
            pppppppcVar28 = pppppppcStack_120;
            sVar16 = DAT_0050b298;
          }
        }
      }
      pppppppcVar20 = pppppppcStack_11c;
      pppppppcVar24 = (code *******)-(uint)((short)pppppppcVar28 == 0);
      if (SCARRY2(sVar16,2)) goto LAB_00485a28;
      sVar17 = (short)pppppppcStack_11c;
      if ((ushort)(-(ushort)(sVar17 == (short)(sVar16 + 2)) & (ushort)pppppppcVar24) == 0xffff) {
        pppppppcStack_2c0 = (code *******)0x48476b;
        __vbaStrCopy();
        pcVar22 = __vbaGenerateBoundsError_exref;
        if (DAT_0050b23c == 1) {
          pppppppcStack_2c0 = (code *******)0x484781;
          __vbaStrCopy();
          pcVar22 = __vbaGenerateBoundsError_exref;
        }
      }
      else {
        pppppppcStack_2c0 = (code *******)0x0;
        pppppppcStack_2c4 = (code *******)0x4;
        pppppppcStack_2cc = &ppppppcStack_150;
        pppppppcStack_2c8 = apppppppcStack_1f8[0];
        pppppppcStack_2d0 = (code *******)0x4847f4;
        pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
        pppppppcStack_2c4 = (code *******)0x4847fe;
        iVar10 = __vbaI4Var();
        if (SBORROW4(iVar10,4)) goto LAB_00485a28;
        if (SCARRY2(DAT_0050b298,2)) goto LAB_00485a28;
        pppppppcVar24 =
             (code *******)
             -(uint)((ushort)(-(ushort)((short)(DAT_0050b298 + 2) < sVar17 &&
                                       (int)sVar17 <= iVar10 + -4) & (ushort)pppppppcVar24) ==
                    0xffff);
        pppppppcStack_2c0 = (code *******)0x484848;
        __vbaFreeVar();
        pcVar22 = __vbaGenerateBoundsError_exref;
        if ((short)pppppppcVar24 != 0) {
          uVar5 = (undefined2)((uint)pppppppcVar20 >> 0x10);
          sVar18 = sVar17 + -2;
          pppppppcVar20 = (code *******)CONCAT22(uVar5,sVar18);
          if (SBORROW2(sVar17,2)) goto LAB_00485a28;
          pppppppcVar20 = (code *******)CONCAT22(uVar5,sVar18 - DAT_0050b298);
          if (SBORROW2(sVar18,DAT_0050b298)) goto LAB_00485a28;
          pppppppcStack_124 = pppppppcVar20;
          if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
            pppppppcStack_2c0 = (code *******)0x48489e;
            iVar10 = __vbaGenerateBoundsError();
          }
          else {
            uVar25 = (int)(short)(sVar18 - DAT_0050b298) - *(int *)(DAT_0050b1f0 + 10);
            if (*(uint *)(DAT_0050b1f0 + 8) <= uVar25) {
              pppppppcStack_2c0 = (code *******)0x484891;
              __vbaGenerateBoundsError();
            }
            iVar10 = uVar25 * 2;
          }
          if ((DAT_0050b1ec == (short *)0x0) || (*DAT_0050b1ec != 1)) {
            pppppppcStack_2c0 = (code *******)0x4848cf;
            iVar27 = __vbaGenerateBoundsError();
          }
          else {
            iVar26 = (int)(short)pppppppcStack_124;
            iVar27 = *(int *)(DAT_0050b1ec + 10);
            if (*(uint *)(DAT_0050b1ec + 8) <= (uint)(iVar26 - iVar27)) {
              pppppppcStack_2c0 = (code *******)0x4848c2;
              __vbaGenerateBoundsError();
            }
            iVar27 = (iVar26 - iVar27) * 2;
          }
          *(undefined2 *)(*(int *)(DAT_0050b1ec + 6) + iVar27) =
               *(undefined2 *)(*(int *)(DAT_0050b1f0 + 6) + iVar10);
          if ((DAT_0050b3a8 == (short *)0x0) || (*DAT_0050b3a8 != 1)) {
            pppppppcStack_2c0 = (code *******)0x484966;
            iStack_29c = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              pppppppcStack_2c0 = (code *******)0x48492e;
              iVar10 = __vbaGenerateBoundsError();
            }
            else {
              iVar27 = (int)(short)pppppppcStack_124;
              iVar10 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar27 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x48491b;
                __vbaGenerateBoundsError();
              }
              iVar10 = (iVar27 - iVar10) * 2;
            }
            uVar25 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar10) -
                     *(int *)(DAT_0050b3a8 + 10);
            if (*(uint *)(DAT_0050b3a8 + 8) <= uVar25) {
              pppppppcStack_2c0 = (code *******)0x48494f;
              __vbaGenerateBoundsError();
            }
            iStack_29c = uVar25 * 4;
          }
          if ((DAT_0050b3a4 == (short *)0x0) || (*DAT_0050b3a4 != 1)) {
            pppppppcStack_2c0 = (code *******)0x4849e3;
            iVar10 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              pppppppcStack_2c0 = (code *******)0x4849b1;
              iVar10 = __vbaGenerateBoundsError();
            }
            else {
              iVar27 = (int)(short)pppppppcStack_124;
              iVar10 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar27 - iVar10)) {
                pppppppcStack_2c0 = (code *******)0x48499e;
                __vbaGenerateBoundsError();
              }
              iVar10 = (iVar27 - iVar10) * 2;
            }
            uVar25 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar10) -
                     *(int *)(DAT_0050b3a4 + 10);
            if (*(uint *)(DAT_0050b3a4 + 8) <= uVar25) {
              pppppppcStack_2c0 = (code *******)0x4849d2;
              __vbaGenerateBoundsError();
            }
            iVar10 = uVar25 * 4;
          }
          if ((DAT_0050b39c == (short *)0x0) || (*DAT_0050b39c != 1)) {
            pppppppcStack_2c0 = (code *******)0x484a62;
            iStack_2a0 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              pppppppcStack_2c0 = (code *******)0x484a2a;
              iVar27 = __vbaGenerateBoundsError();
            }
            else {
              iVar26 = (int)(short)pppppppcStack_124;
              iVar27 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar26 - iVar27)) {
                pppppppcStack_2c0 = (code *******)0x484a17;
                __vbaGenerateBoundsError();
              }
              iVar27 = (iVar26 - iVar27) * 2;
            }
            uVar25 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar27) -
                     *(int *)(DAT_0050b39c + 10);
            if (*(uint *)(DAT_0050b39c + 8) <= uVar25) {
              pppppppcStack_2c0 = (code *******)0x484a4b;
              __vbaGenerateBoundsError();
            }
            iStack_2a0 = uVar25 * 4;
          }
          if ((DAT_0050b3ac == (short *)0x0) || (*DAT_0050b3ac != 1)) {
            pppppppcStack_2c0 = (code *******)0x484adf;
            iStack_2a4 = __vbaGenerateBoundsError();
          }
          else {
            if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
              pppppppcStack_2c0 = (code *******)0x484aad;
              iVar27 = __vbaGenerateBoundsError();
            }
            else {
              iVar26 = (int)(short)pppppppcStack_124;
              iVar27 = *(int *)(DAT_0050b1f0 + 10);
              if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar26 - iVar27)) {
                pppppppcStack_2c0 = (code *******)0x484a9a;
                __vbaGenerateBoundsError();
              }
              iVar27 = (iVar26 - iVar27) * 2;
            }
            uVar25 = (int)*(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar27) -
                     *(int *)(DAT_0050b3ac + 10);
            if (*(uint *)(DAT_0050b3ac + 8) <= uVar25) {
              pppppppcStack_2c0 = (code *******)0x484ace;
              __vbaGenerateBoundsError();
            }
            iStack_2a4 = uVar25 * 4;
          }
          pppppppcStack_2c0 = *(code ********)(*(int *)(DAT_0050b3a8 + 6) + iStack_29c);
          pppppppcStack_2c4 = *(code ********)(*(int *)(DAT_0050b3a4 + 6) + iVar10);
          pppppppcStack_2c8 = (code *******)0x484b0c;
          __vbaStrCat();
          pppppppcStack_2c8 = (code *******)0x484b19;
          pppppppcStack_2c8 = (code *******)__vbaStrMove();
          pppppppcStack_2cc = (code *******)0x484b20;
          Ordinal_519();
          pppppppcStack_2cc = (code *******)0x484b27;
          pppppppcStack_2cc = (code *******)__vbaStrMove();
          pppppppcStack_2d0 = *(code ********)(*(int *)(DAT_0050b39c + 6) + iStack_2a0);
          pppppppcStack_2d4 = (code *******)0x484b3d;
          __vbaStrCat();
          pppppppcStack_2d4 = (code *******)0x484b44;
          pppppppcStack_2d4 = (code *******)__vbaStrMove();
          pppppppcStack_2d8 = *(code ********)(*(int *)(DAT_0050b3ac + 6) + iStack_2a4);
          pppppppcStack_2dc = (code *******)0x484b5a;
          __vbaStrCat();
          pppppppcStack_2dc = (code *******)0x484b63;
          __vbaStrMove();
          pppppppcStack_2dc = &ppppppcStack_140;
          pppppppcStack_2e0 = &ppppppcStack_13c;
          ppppppcStack_2e4 = (code ******)&ppppppcStack_138;
          pppppppcStack_2e8 = (code *******)0x3;
          pppppppcStack_2ec = (code *******)0x484b77;
          __vbaFreeStrList();
          pppppppcVar28 = pppppppcStack_120;
        }
      }
    }
    sVar17 = (short)pppppppcVar28;
    if ((ppppppcStack_130 == (code ******)0x0) || (*(short *)ppppppcStack_130 != 2)) {
      pppppppcStack_2c0 = (code *******)0x484b84;
      (*pcVar22)();
    }
    else {
      pppppcStack_1dc = (code *****)((int)(short)pppppppcStack_12c - (int)ppppppcStack_130[7]);
      if (ppppppcStack_130[6] <= pppppcStack_1dc) {
        pppppppcStack_2c0 = (code *******)0x4847b4;
        (*pcVar22)();
      }
      if (ppppppcStack_130[4] <= (code *****)((int)sVar17 - (int)ppppppcStack_130[5])) {
        pppppppcStack_2c0 = (code *******)0x4847c8;
        (*pcVar22)();
      }
    }
    pppppppcStack_2c0 = (code *******)0x484b98;
    __vbaStrCopy();
    pppppppcVar20 = (code *******)__vbaFreeVar_exref;
    pppppppcVar24 = pppppppcStack_11c;
    pppppppcVar23 = (code *******)(uint)(ushort)(sVar17 + 1);
    pppppppcVar4 = (code *******)(uint)(ushort)(sVar17 + 1);
    if (SCARRY2(sVar17,1)) goto LAB_00485a28;
  }
  pppppppcVar11 = (code *******)(uint)(ushort)(sVar17 + 1);
  pppppppcVar23 = pppppppcVar11;
  pppppppcVar28 = (code *******)__vbaI4Var_exref;
  pppppppcVar4 = pppppppcVar11;
  if (SCARRY2(sVar17,1)) goto LAB_00485a28;
  goto LAB_00484054;
LAB_00484c1d:
  pppppppcStack_11c = pppppppcVar23;
  if ((short)uStack_244 < (short)pppppppcStack_11c) {
    pppppppcStack_2c0 = (code *******)0x0;
    pppppppcStack_2c4 = (code *******)0x4;
    pppppppcStack_2cc = &ppppppcStack_150;
    pppppppcStack_2c8 = apppppppcStack_1f8[0];
    pppppppcStack_2d0 = (code *******)0x484dcb;
    pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
    pppppppcStack_2c4 = (code *******)0x484dd5;
    iVar10 = __vbaI4Var();
    if (!SBORROW4(iVar10,5)) {
      pppppppcStack_2c0 = (code *******)0x484de6;
      uStack_254 = __vbaI2I4();
      pppppppcVar23 = _DAT_0050b298;
      pppppppcStack_2c0 = (code *******)0x484dfb;
      __vbaFreeVar();
      goto LAB_00484dfb;
    }
    goto LAB_00485a28;
  }
  pppppppcVar28 =
       (code *******)
       CONCAT22((short)((uint)pppppppcVar28 >> 0x10),(short)pppppppcStack_11c - DAT_0050b298);
  pppppppcStack_2c0 = (code *******)0x0;
  pppppppcStack_2c4 = (code *******)0x5;
  pppppppcStack_2bc = &ppppppcStack_150;
  pppppppcStack_2c8 = apppppppcStack_1f8[0];
  if (SBORROW2((short)pppppppcStack_11c,DAT_0050b298)) goto LAB_00485a28;
  pppppppcStack_2d0 = (code *******)0x484c57;
  pppppppcStack_12c = pppppppcVar28;
  pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
  pppppppcStack_2c4 = (code *******)0x484c61;
  iVar10 = __vbaI4Var();
  if (SBORROW4(iVar10,1)) goto LAB_00485a28;
  pppppppcStack_2c0 = (code *******)0x484c72;
  uStack_24c = __vbaI2I4();
  pppppppcStack_2c0 = (code *******)0x484c83;
  __vbaFreeVar();
  pppppppcVar23 = (code *******)0x0;
  while( true ) {
    pppppppcVar24 = pppppppcVar23;
    sVar17 = (short)pppppppcVar24;
    if ((short)uStack_24c < sVar17) break;
    pppppppcStack_178 = (code *******)(int)(short)pppppppcStack_11c;
    pppppppcStack_2c4 = &ppppppcStack_134;
    pppppppcStack_2c0 = (code *******)ppppppcStack_130;
    pppppppcStack_180 = (code *******)0x3;
    pppppppcStack_2c8 = (code *******)0x484cac;
    __vbaAryLock();
    if ((ppppppcStack_134 == (code ******)0x0) || (*(short *)ppppppcStack_134 != 2)) {
      pppppppcStack_2c8 = (code *******)0x484d04;
      iVar10 = __vbaGenerateBoundsError();
    }
    else {
      pppppcStack_1dc = (code *****)((int)(short)pppppppcVar28 - (int)ppppppcStack_134[7]);
      if (ppppppcStack_134[6] <= pppppcStack_1dc) {
        pppppppcStack_2c8 = (code *******)0x484cd2;
        __vbaGenerateBoundsError();
      }
      pppppcVar21 = ppppppcStack_134[5];
      if (ppppppcStack_134[4] <= (code *****)((int)sVar17 - (int)pppppcVar21)) {
        pppppppcStack_2c8 = (code *******)0x484cea;
        __vbaGenerateBoundsError();
      }
      iVar10 = (int)((int)pppppcStack_1dc +
                    (int)ppppppcStack_134[6] * ((int)sVar17 - (int)pppppcVar21)) * 4;
    }
    pppppppcStack_2d4 = pppppppcStack_180;
    pppppppcStack_2ec = (code *******)((int)ppppppcStack_134[3] + iVar10);
    pppppppcStack_2d0 = pppppppcStack_17c;
    pppppppcStack_2cc = pppppppcStack_178;
    pppppppcStack_2c8 = pppppppcStack_174;
    ppppppcStack_2e4 = (code ******)0x3;
    pppppppcStack_2e0 = pppppppcStack_19c;
    pppppppcStack_2dc = (code *******)(int)sVar17;
    pppppppcStack_2d8 = pppppppcStack_194;
    pppppppcStack_2f8 = (code *******)0x2;
    uStack_2fc = 0x41;
    uStack_2f4 = 0x4008;
    pppppppcStack_2f0 = pppppppcStack_1bc;
    pppppppcStack_2e8 = pppppppcStack_1b4;
    pppppppcStack_300 = apppppppcStack_1f8[0];
    pppppppcStack_304 = (code *******)0x484d7a;
    __vbaLateIdCallSt();
    pppppppcStack_2c8 = &ppppppcStack_134;
    pppppppcStack_2cc = (code *******)0x484d87;
    __vbaAryUnlock();
    pppppppcVar23 = (code *******)(uint)(ushort)(sVar17 + 1);
    pppppppcVar28 = pppppppcStack_12c;
    if (SCARRY2(sVar17,1)) goto LAB_00485a28;
  }
  pppppppcVar23 = (code *******)(uint)(ushort)((short)pppppppcStack_11c + 1);
  if (SCARRY2((short)pppppppcStack_11c,1)) goto LAB_00485a28;
  goto LAB_00484c1d;
  while( true ) {
    pppppppcStack_180 = (code *******)0x3;
    pppppppcStack_2d0 = (code *******)0xa;
    pppppppcStack_2cc = (code *******)0x3;
    pppppppcStack_2c4 = (code *******)(int)sVar17;
    pppppppcStack_2c8 = pppppppcStack_17c;
    pppppppcStack_2d4 = apppppppcStack_1f8[0];
    pppppppcStack_2c0 = pppppppcStack_174;
    pppppppcStack_2d8 = (code *******)0x484e3d;
    pppppppcStack_178 = pppppppcStack_2c4;
    __vbaLateIdSt();
    pppppppcStack_180 = (code *******)0x3;
    pppppppcStack_2e8 = (code *******)0xb;
    ppppppcStack_2e4 = (code ******)0x3;
    pppppppcStack_178 = (code *******)0x0;
    pppppppcStack_2e0 = pppppppcStack_17c;
    pppppppcStack_2ec = apppppppcStack_1f8[0];
    pppppppcStack_2dc = (code *******)0x0;
    pppppppcStack_2d8 = pppppppcStack_174;
    pppppppcStack_2f0 = (code *******)0x484e6b;
    __vbaLateIdSt();
    pppppppcStack_180 = (code *******)0x3;
    pppppppcStack_300 = (code *******)0x26;
    uStack_2fc = 3;
    pppppppcStack_178 = (code *******)0xffff00;
    pppppppcStack_2f8 = pppppppcStack_17c;
    pppppppcStack_304 = apppppppcStack_1f8[0];
    uStack_2f4 = 0xffff00;
    pppppppcStack_2f0 = pppppppcStack_174;
    pppppppcStack_308 = (code *******)0x484e9c;
    __vbaLateIdSt();
    pppppppcStack_180 = (code *******)0x3;
    ppppppcStack_318 = (code ******)0x27;
    fStack_314 = 4.2039e-45;
    pppppppcStack_178 = (code *******)0xff0000;
    pppppppcStack_310 = pppppppcStack_17c;
    pppppppcStack_31c = apppppppcStack_1f8[0];
    uStack_30c = 0xff0000;
    pppppppcStack_308 = pppppppcStack_174;
    uStack_320 = 0x484ecd;
    __vbaLateIdSt();
    pppppppcVar23 = (code *******)(uint)(ushort)(sVar17 + 1);
    if (SCARRY2(sVar17,1)) break;
LAB_00484dfb:
    pppppppcVar24 = pppppppcVar23;
    pppppppcVar28 = (code *******)__vbaLateIdSt_exref;
    sVar17 = (short)pppppppcVar24;
    if ((short)uStack_254 < sVar17) goto LAB_00484ee8;
  }
  goto LAB_00485a28;
LAB_0048300d:
  do {
    local_24 = uVar25;
    if (sVar18 < (short)local_24) {
      if (DAT_0050b25e == 0) {
        local_74 = 0x80020004;
        local_64 = 0x80020004;
        local_7c[0] = (code *****)0xa;
        local_6c[0] = (code ******)0xa;
        ppppppcStack_108 = (code ******)0x483330;
        __vbaVarDup();
        ppppppcStack_108 = (code ******)0x483348;
        __vbaVarDup();
        ppppppcStack_108 = local_7c;
        ppppppcStack_10c = (code ******)local_6c;
        ppppppcStack_110 = (code ******)local_5c;
        pppppppcStack_118 = local_4c;
        pwStack_114 = (wchar_t *)0x40;
        pppppppcStack_11c = (code *******)0x483360;
        Ordinal_595();
        pppppppcStack_11c = (code *******)local_7c;
        pppppppcStack_120 = local_6c;
        pppppppcStack_124 = local_5c;
        ppppppcStack_128 = (code ******)local_4c;
        pppppppcStack_12c = (code *******)0x4;
        ppppppcStack_130 = (code ******)0x483378;
        __vbaFreeVarList();
        if (DAT_0050b420 == (code ******)0x0) {
          pppppppcStack_11c = &DAT_0050b420;
          pppppppcStack_120 = (code *******)&DAT_00408c88;
          pppppppcStack_124 = (code *******)0x483394;
          __vbaNew2();
        }
        pppppppcStack_11c = (code *******)DAT_0050b420;
        pppppppcStack_120 = (code *******)0x4833a2;
        pppppppcStack_120 = (code *******)(*(code *)(*DAT_0050b420)[0xdc])();
        pppppppcStack_124 = (code *******)&local_3c;
        ppppppcStack_128 = (code ******)0x4833af;
        ppppppcVar6 = (code ******)__vbaObjSet();
        ppppppcStack_128 = (code ******)0x0;
        ppppppcStack_130 = (code ******)0x4833bc;
        pppppppcStack_12c = (code *******)ppppppcVar6;
        ppppppcVar9 = (code ******)(*(code *)(*ppppppcVar6)[0x23])();
        if ((int)ppppppcVar9 < 0) {
          ppppppcStack_130 = (code ******)0x8c;
          ppppppcStack_134 = (code ******)&DAT_0040bb6c;
          ppppppcStack_140 = (code ******)0x4833d4;
          ppppppcStack_13c = ppppppcVar9;
          ppppppcStack_138 = ppppppcVar6;
          __vbaHresultCheckObj();
        }
        pcVar22 = __vbaFreeObj_exref;
        ppppppcStack_130 = (code ******)0x4833df;
        __vbaFreeObj();
        if (DAT_0050b420 == (code ******)0x0) {
          ppppppcStack_130 = (code ******)&DAT_0050b420;
          ppppppcStack_134 = (code ******)&DAT_00408c88;
          ppppppcStack_138 = (code ******)0x4833f8;
          __vbaNew2();
        }
        ppppppcStack_130 = DAT_0050b420;
        ppppppcStack_134 = (code ******)0x483406;
        ppppppcStack_134 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
        ppppppcStack_138 = &local_3c;
        ppppppcStack_13c = (code ******)0x48340d;
        ppppppcVar7 = (code ******)__vbaObjSet();
        ppppppcStack_13c = (code ******)0x0;
        ppppppcStack_144 = (code ******)0x48341a;
        ppppppcStack_140 = ppppppcVar7;
        ppppppcVar8 = (code ******)(*(code *)(*ppppppcVar7)[0x23])();
        ppppppcVar6 = ppppppcStack_13c;
        ppppppcVar9 = ppppppcStack_138;
joined_r0x0048341e:
        ppppppcStack_13c = ppppppcVar8;
        ppppppcStack_138 = ppppppcVar7;
        if ((int)ppppppcStack_13c < 0) {
          ppppppcStack_130 = (code ******)0x8c;
          ppppppcStack_134 = (code ******)&DAT_0040bb6c;
          ppppppcStack_140 = (code ******)0x483432;
          __vbaHresultCheckObj();
          ppppppcVar6 = ppppppcStack_13c;
          ppppppcVar9 = ppppppcStack_138;
        }
        ppppppcStack_138 = ppppppcVar9;
        ppppppcStack_13c = ppppppcVar6;
        ppppppcStack_130 = (code ******)0x483437;
        (*pcVar22)();
        return;
      }
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        ppppppcStack_108 = (code ******)0x48348d;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
        if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar23) {
          ppppppcStack_108 = (code ******)0x483465;
          __vbaGenerateBoundsError();
        }
        uVar19 = -*(int *)(DAT_0050b1a4 + 10);
        if (*(uint *)(DAT_0050b1a4 + 8) <= uVar19) {
          ppppppcStack_108 = (code ******)0x483479;
          __vbaGenerateBoundsError();
        }
        iVar10 = (int)((int)pppppppcVar23 + *(int *)(DAT_0050b1a4 + 0xc) * uVar19) * 2;
      }
      *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) = DAT_0050b25e;
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        ppppppcStack_108 = (code ******)0x4834ec;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        pppppppcVar23 = (code *******)(2 - *(int *)(DAT_0050b1a4 + 0xe));
        if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar23) {
          ppppppcStack_108 = (code ******)0x4834c4;
          __vbaGenerateBoundsError();
        }
        uVar19 = -*(int *)(DAT_0050b1a4 + 10);
        if (*(uint *)(DAT_0050b1a4 + 8) <= uVar19) {
          ppppppcStack_108 = (code ******)0x4834d8;
          __vbaGenerateBoundsError();
        }
        iVar10 = (int)((int)pppppppcVar23 + *(int *)(DAT_0050b1a4 + 0xc) * uVar19) * 2;
      }
      *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) = (short)DAT_0050b260;
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        ppppppcStack_108 = (code ******)0x483550;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        uVar19 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= uVar19) {
          ppppppcStack_108 = (code ******)0x483523;
          __vbaGenerateBoundsError();
        }
        pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
        if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar23) {
          ppppppcStack_108 = (code ******)0x48353c;
          __vbaGenerateBoundsError();
        }
        iVar10 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar23 + uVar19) * 2;
      }
      *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) = DAT_0050b298;
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        ppppppcStack_108 = (code ******)0x4835b4;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        uVar19 = 2 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= uVar19) {
          ppppppcStack_108 = (code ******)0x483587;
          __vbaGenerateBoundsError();
        }
        pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
        if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar23) {
          ppppppcStack_108 = (code ******)0x4835a0;
          __vbaGenerateBoundsError();
        }
        iVar10 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar23 + uVar19) * 2;
      }
      *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) = DAT_0050b25e;
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        ppppppcStack_108 = (code ******)0x483618;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        uVar19 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
        if (*(uint *)(DAT_0050b1a4 + 0xc) <= uVar19) {
          ppppppcStack_108 = (code ******)0x4835eb;
          __vbaGenerateBoundsError();
        }
        pppppppcVar23 = (code *******)(2 - *(int *)(DAT_0050b1a4 + 10));
        if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar23) {
          ppppppcStack_108 = (code ******)0x483604;
          __vbaGenerateBoundsError();
        }
        iVar10 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar23 + uVar19) * 2;
      }
      if ((!SCARRY2(DAT_0050b298,DAT_0050b260._2_2_)) &&
         (!SCARRY2(DAT_0050b298 + DAT_0050b260._2_2_,2))) {
        *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) = DAT_0050b298 + DAT_0050b260._2_2_ + 2;
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          ppppppcStack_108 = (code ******)0x483693;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          iVar10 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 2U - iVar10) {
            ppppppcStack_108 = (code ******)0x483666;
            __vbaGenerateBoundsError();
          }
          iVar27 = *(int *)(DAT_0050b1a4 + 10);
          if (*(uint *)(DAT_0050b1a4 + 8) <= 2U - iVar27) {
            ppppppcStack_108 = (code ******)0x48367f;
            __vbaGenerateBoundsError();
          }
          iVar10 = (*(int *)(DAT_0050b1a4 + 0xc) * (2U - iVar27) + (2U - iVar10)) * 2;
        }
        *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) = 0;
        if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
          ppppppcStack_108 = (code ******)0x4836d4;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          iVar27 = (int)DAT_0050b25e;
          iVar10 = *(int *)(DAT_0050b1f8 + 10);
          if (*(uint *)(DAT_0050b1f8 + 8) <= (uint)(iVar27 - iVar10)) {
            ppppppcStack_108 = (code ******)0x4836c7;
            __vbaGenerateBoundsError();
          }
          iVar10 = (iVar27 - iVar10) * 2;
        }
        *(undefined2 *)(*(int *)(DAT_0050b1f8 + 6) + iVar10) = 0;
        if ((DAT_0050b1f8 == (short *)0x0) || (*DAT_0050b1f8 != 1)) {
          ppppppcStack_108 = (code ******)0x483715;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          iVar27 = (int)(short)DAT_0050b260;
          iVar10 = *(int *)(DAT_0050b1f8 + 10);
          if (*(uint *)(DAT_0050b1f8 + 8) <= (uint)(iVar27 - iVar10)) {
            ppppppcStack_108 = (code ******)0x483708;
            __vbaGenerateBoundsError();
          }
          iVar10 = (iVar27 - iVar10) * 2;
        }
        *(short *)(*(int *)(DAT_0050b1f8 + 6) + iVar10) = (short)DAT_0050b260;
        if ((DAT_0050b1f0 == (short *)0x0) || (*DAT_0050b1f0 != 1)) {
          ppppppcStack_108 = (code ******)0x48375b;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          iVar27 = (int)DAT_0050b260._2_2_;
          iVar10 = *(int *)(DAT_0050b1f0 + 10);
          if (*(uint *)(DAT_0050b1f0 + 8) <= (uint)(iVar27 - iVar10)) {
            ppppppcStack_108 = (code ******)0x48374e;
            __vbaGenerateBoundsError();
          }
          iVar10 = (iVar27 - iVar10) * 2;
        }
        *(short *)(*(int *)(DAT_0050b1f0 + 6) + iVar10) = DAT_0050b25e;
        if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
          ppppppcStack_108 = (code ******)0x48379e;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          iVar27 = (int)DAT_0050b25e;
          iVar10 = *(int *)(DAT_0050b0e8 + 10);
          if (*(uint *)(DAT_0050b0e8 + 8) <= (uint)(iVar27 - iVar10)) {
            ppppppcStack_108 = (code ******)0x483793;
            __vbaGenerateBoundsError();
          }
          iVar10 = (iVar27 - iVar10) * 8;
        }
        if ((DAT_0050b0d8 == (short *)0x0) || (*DAT_0050b0d8 != 1)) {
          ppppppcStack_108 = (code ******)0x4837d6;
          iVar27 = __vbaGenerateBoundsError();
        }
        else {
          iVar26 = (int)DAT_0050b260._2_2_;
          iVar27 = *(int *)(DAT_0050b0d8 + 10);
          if (*(uint *)(DAT_0050b0d8 + 8) <= (uint)(iVar26 - iVar27)) {
            ppppppcStack_108 = (code ******)0x4837c5;
            __vbaGenerateBoundsError();
          }
          iVar27 = (iVar26 - iVar27) * 8;
        }
        iVar26 = *(int *)(DAT_0050b0d8 + 6);
        iVar1 = *(int *)(DAT_0050b0e8 + 6);
        *(undefined4 *)(iVar26 + iVar27) = *(undefined4 *)(iVar1 + iVar10);
        *(undefined4 *)(iVar26 + 4 + iVar27) = *(undefined4 *)(iVar1 + 4 + iVar10);
        ppppppcStack_108 = (code ******)0x4837fb;
        FUN_0045b720();
        return;
      }
      break;
    }
    if ((psVar14 == (short *)0x0) || (*psVar14 != 1)) {
      ppppppcStack_108 = (code ******)0x483048;
      iVar10 = __vbaGenerateBoundsError();
      psVar14 = DAT_0050b1f8;
      psVar15 = DAT_0050b0f0;
    }
    else {
      uVar25 = (int)(short)local_24 - *(int *)(psVar14 + 10);
      if (*(uint *)(psVar14 + 8) <= uVar25) {
        ppppppcStack_108 = (code ******)0x483035;
        __vbaGenerateBoundsError();
        psVar14 = DAT_0050b1f8;
        psVar15 = DAT_0050b0f0;
      }
      iVar10 = uVar25 * 2;
    }
    pppppppcVar23 = *(code ********)(psVar14 + 6);
    if (0 < *(short *)((int)pppppppcVar23 + iVar10)) {
      if ((psVar15 == (short *)0x0) || (*psVar15 != 1)) {
        ppppppcStack_108 = (code ******)0x483090;
        iVar10 = __vbaGenerateBoundsError();
        psVar15 = DAT_0050b0f0;
      }
      else {
        iVar27 = (int)(short)local_24;
        iVar10 = *(int *)(psVar15 + 10);
        if (*(uint *)(psVar15 + 8) <= (uint)(iVar27 - iVar10)) {
          ppppppcStack_108 = (code ******)0x48307f;
          __vbaGenerateBoundsError();
          psVar15 = DAT_0050b0f0;
        }
        iVar10 = (iVar27 - iVar10) * 8;
      }
      uVar12 = _DAT_0050b20c;
      in_FPUStatusWord = 0;
      if (*(double *)(*(int *)(psVar15 + 6) + iVar10) == _DAT_00401490) {
        DAT_0050b210 = 1;
      }
      local_20 = 0.0;
      local_18 = (code *******)&DAT_00000001;
      psVar14 = DAT_0050b0cc;
      pppppppcVar20 = local_18;
      while( true ) {
        local_18 = pppppppcVar20;
        pppppppcVar23 = local_18;
        uVar19 = 0;
        local_f0 = (short)uVar12;
        sVar17 = (short)local_18;
        if (local_f0 < sVar17) break;
        if ((DAT_0050b0c4 == (short *)0x0) || (*DAT_0050b0c4 != 2)) {
          ppppppcStack_108 = (code ******)0x483144;
          pppppppcVar23 = (code *******)__vbaGenerateBoundsError();
          psVar14 = DAT_0050b0cc;
        }
        else {
          iVar27 = (int)DAT_0050b260._2_2_;
          iVar10 = *(int *)(DAT_0050b0c4 + 0xe);
          if (*(uint *)(DAT_0050b0c4 + 0xc) <= (uint)(iVar27 - iVar10)) {
            ppppppcStack_108 = (code ******)0x48310a;
            __vbaGenerateBoundsError();
            psVar14 = DAT_0050b0cc;
          }
          uVar19 = (int)sVar17 - *(int *)(DAT_0050b0c4 + 10);
          if (*(uint *)(DAT_0050b0c4 + 8) <= uVar19) {
            ppppppcStack_108 = (code ******)0x483125;
            __vbaGenerateBoundsError();
            psVar14 = DAT_0050b0cc;
          }
          pppppppcVar23 =
               (code *******)((*(int *)(DAT_0050b0c4 + 0xc) * uVar19 + (iVar27 - iVar10)) * 8);
        }
        if ((psVar14 == (short *)0x0) || (*psVar14 != 2)) {
          ppppppcStack_108 = (code ******)0x4831ba;
          iVar10 = __vbaGenerateBoundsError();
          psVar14 = DAT_0050b0cc;
        }
        else {
          if (SCARRY2((short)local_18,2)) goto LAB_00483852;
          uVar25 = (int)(short)((short)local_18 + 2) - *(int *)(psVar14 + 0xe);
          if (*(uint *)(psVar14 + 0xc) <= uVar25) {
            ppppppcStack_108 = (code ******)0x48317b;
            __vbaGenerateBoundsError();
            psVar14 = DAT_0050b0cc;
          }
          iVar27 = (int)(short)local_24;
          iVar10 = *(int *)(psVar14 + 10);
          if (*(uint *)(psVar14 + 8) <= (uint)(iVar27 - iVar10)) {
            ppppppcStack_108 = (code ******)0x48319b;
            __vbaGenerateBoundsError();
            psVar14 = DAT_0050b0cc;
          }
          iVar10 = (*(int *)(psVar14 + 0xc) * (iVar27 - iVar10) + uVar25) * 8;
        }
        uVar19 = *(uint *)(psVar14 + 6);
        local_20 = *(double *)((int)pppppppcVar23 + *(int *)(DAT_0050b0c4 + 6)) *
                   *(double *)(uVar19 + iVar10) + local_20;
        if ((in_FPUStatusWord & 0xd) != 0) goto LAB_0048384d;
        pppppppcVar20 = (code *******)(uint)(ushort)((short)local_18 + 1);
        if (SCARRY2((short)local_18,1)) goto LAB_00483852;
      }
      if ((in_FPUStatusWord & 0xd) != 0) {
LAB_0048384d:
        __vbaFPException();
        return;
      }
      ppppppcStack_108 = (code ******)0x483218;
      fVar31 = (float10)__vbaFpR8();
      if (fVar31 < (float10)_DAT_0050b12c) {
        local_20 = 0.0;
      }
      uVar30 = 0;
      psVar15 = DAT_0050b0f0;
      if (local_20 < _DAT_00401490) {
        if ((DAT_0050b0f0 == (short *)0x0) || (*DAT_0050b0f0 != 1)) {
          ppppppcStack_108 = (code ******)0x483272;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar23 = (code *******)((int)(short)local_24 - *(int *)(DAT_0050b0f0 + 10));
          if (*(code ********)(DAT_0050b0f0 + 8) <= pppppppcVar23) {
            ppppppcStack_108 = (code ******)0x483261;
            __vbaGenerateBoundsError();
          }
          iVar10 = (int)pppppppcVar23 * 8;
        }
        if (DAT_0050b000 == 0) {
          fVar31 = (float10)*(double *)(*(int *)(DAT_0050b0f0 + 6) + iVar10) / (float10)local_20;
          psVar15 = DAT_0050b0f0;
        }
        else {
          ppppppcStack_108 = (code ******)local_20._4_4_;
          pwStack_104 = (wchar_t *)local_20;
          ppppppcStack_110 = (code ******)0x483297;
          fVar31 = (float10)adj_fdiv_m64();
          psVar15 = extraout_EDX;
        }
        local_20 = (double)ABS(fVar31);
        if ((uVar30 & 0xd) != 0) goto LAB_0048384d;
        if (local_20 < local_2c) {
          DAT_0050b25e = (short)local_24;
          local_2c = local_20;
        }
      }
      in_FPUStatusWord = 0;
      psVar14 = DAT_0050b1f8;
    }
    uVar19 = 0;
    uVar25 = (uint)(ushort)((short)local_24 + 1);
  } while (!SCARRY2((short)local_24,1));
LAB_00483852:
  ppppppcStack_108 = (code ******)0x483858;
  __vbaErrorOverflow();
  pwStack_114 = 
  L"◿ᄸ@◿ᅜ@◿႔@◿ၰ@◿ᆠ@◿၀@◿ᇄ@◿ႜ@◿ᆸ@◿ᆤ@◿ᅌ@◿ᄐ@◿ᅈ@◿၌@◿တ@◿ሌ@◿ဌ@◿ሼ@◿ᆈ@◿Ⴠ@◿ᄨ@◿ረ@◿ሠ@◿ဤ@◿ሸ@◿ჸ@◿ᇔ@◿წ@◿ႀ@◿ᇠ@◿ᄔ@◿ᇼ@◿ဘ@◿ဴ@◿መ@◿რ@◿ᆨ@◿ြ@◿ቄ@◿ᅘ@◿ᅴ@◿ᅨ@◿၄@◿႐@◿ሤ@◿ቀ@◿ၨ@◿႘@◿ᆜ@◿ၤ@◿ሴ@◿ᇜ@◿ၔ@◿Ⴄ@◿ሔ@◿ᄠ@◿ᅠ@◿ა@◿ᄀ@◿Ⴜ@◿ᆘ@◿ၠ@◿ᇸ@◿ᅰ@◿ᄬ@◿ფ@◿჈@◿Ⴤ@◿ᆴ@◿ᆄ@◿ၐ@◿ဈ@◿ᆀ@◿ቈ@◿Ⴘ@◿ᇤ@◿ႌ@◿ᄘ@◿ሐ@◿ᆌ@◿ᇰ@◿ူ@◿ჴ@◿ၘ@◿ჰ@◿င@◿ᄌ@◿ᄜ@◿ᆰ@◿ဠ@◿ᆬ@◿က@◿ᄴ@◿ለ@◿ჼ@◿ᇘ@◿ၸ@◿ᇴ@◿Ⴔ@◿ᇐ@◿ᅤ@◿း@◿Ⴈ@◿Ⴀ@◿ሰ@◿ၬ@◿ᇨ@◿ᅄ@◿ᄄ@◿ာ@◿ၴ@◿ᅀ@◿ၼ@◿ᇈ@◿ი@◿ၜ@◿ᆐ@◿ᆔ@◿ဨ@◿ႈ@◿Ⴐ@◿ᇀ@◿ᄼ@◿ሄ@◿ᆼ@◿ሀ@◿ᅼ@◿ᅬ@◿ᅸ@◿შ@◿ሬ@◿လ@◿Ⴌ@◿ႄ@◿ᅔ@◿ᄈ@◿န@◿ሜ@◿჌@◿ᅐ@◿ᇬ@◿၈@◿ᄰ@◿ნ@◿ᄤ@◿ᇌ@"
  ;
  pppppppcStack_118 = ExceptionList;
  ppppppcStack_110 = (code ******)&pcStack_2b0;
  pcStack_2b0 = pcVar22;
  ppppppcStack_10c = (code ******)&DAT_004020d0;
  ppppppcStack_128 = (code ******)0x0;
  ppppppcStack_130 = (code ******)0x0;
  ppppppcStack_134 = (code ******)0x0;
  ppppppcStack_138 = (code ******)0x0;
  ppppppcStack_13c = (code ******)0x0;
  ppppppcStack_140 = (code ******)0x0;
  ppppppcStack_150 = (code ******)0x0;
  appppppcStack_160[0] = (code ******)0x0;
  ppppppcStack_170 = (code ******)0x0;
  pppppppcStack_180 = (code *******)0x0;
  uStack_190 = 0;
  uStack_1a0 = 0;
  uStack_1b0 = 0;
  uStack_1c0 = 0;
  apppppppcStack_1f8[0] = (code *******)0x0;
  ppppppcStack_2b4 = (code ******)0x4838d8;
  ExceptionList = &pppppppcStack_118;
  pppppppcStack_2ac = pppppppcVar23;
  uStack_2a8 = uVar19;
  ppppppcStack_108 = (code ******)&stack0xfffffffc;
  __vbaStrCopy();
  if (DAT_0050b274 == 4) {
    ppppppcStack_2b4 = (code ******)0x4838ee;
    uVar5 = __vbaI2Abs();
    ppppppcStack_148 = (code ******)CONCAT22(ppppppcStack_148._2_2_,uVar5);
    ppppppcStack_2b8 = (code ******)&ppppppcStack_150;
    ppppppcStack_2b4 = (code ******)0x410ec8;
    ppppppcStack_150 = (code ******)0x2;
    pppppppcStack_2bc = (code *******)0x483908;
    Ordinal_536();
    pppppppcStack_2bc = (code *******)0x483915;
    pppppppcStack_2bc = (code *******)__vbaStrMove();
    pppppppcVar23 = (code *******)__vbaStrCat_exref;
    pppppppcStack_2c0 = (code *******)0x48391e;
    __vbaStrCat();
    pppppppcStack_2c0 = (code *******)0x483925;
    pppppppcStack_2c0 = (code *******)__vbaStrMove();
    pppppppcStack_2c4 = (code *******)0x410ed8;
    pppppppcStack_2c8 = (code *******)0x48392d;
    __vbaStrCat();
    pppppppcStack_2c8 = (code *******)0x483934;
    __vbaStrMove();
    pppppppcStack_2c8 = &ppppppcStack_13c;
    pppppppcStack_2cc = &ppppppcStack_138;
    pppppppcStack_2d0 = (code *******)0x2;
    pppppppcStack_2d4 = (code *******)0x483944;
    __vbaFreeStrList();
    pppppppcStack_2c8 = (code *******)0x483950;
    __vbaFreeVar();
  }
  if (DAT_0050b420 == (code ******)0x0) {
    ppppppcStack_2b4 = (code ******)&DAT_0050b420;
    ppppppcStack_2b8 = (code ******)&DAT_00408c88;
    pppppppcStack_2bc = (code *******)0x483969;
    __vbaNew2();
  }
  ppppppcStack_2b4 = DAT_0050b420;
  ppppppcStack_2b8 = (code ******)0x483977;
  ppppppcStack_2b8 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
  pppppppcStack_2bc = (code *******)apppppppcStack_1f8;
  pppppppcStack_2c0 = (code *******)0x483985;
  __vbaObjSet();
  pppppppcVar20 = (code *******)__vbaGenerateBoundsError_exref;
  if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
    pppppppcStack_2c0 = (code *******)0x4839da;
    iVar10 = __vbaGenerateBoundsError();
    pppppppcVar20 = (code *******)__vbaGenerateBoundsError_exref;
  }
  else {
    pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
    if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar23) {
      pppppppcStack_2c0 = (code *******)0x4839ae;
      __vbaGenerateBoundsError();
    }
    iVar10 = *(int *)(DAT_0050b1a4 + 10);
    if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)-iVar10) {
      pppppppcStack_2c0 = (code *******)0x4839c2;
      __vbaGenerateBoundsError();
    }
    iVar10 = (int)((int)pppppppcVar23 + *(int *)(DAT_0050b1a4 + 0xc) * -iVar10) * 2;
  }
  pppppppcVar28 = (code *******)__vbaLateIdSt_exref;
  if (*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) < 1) {
LAB_00483be5:
    if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
      pppppppcStack_2c0 = (code *******)0x483c36;
      iVar10 = __vbaGenerateBoundsError();
    }
    else {
      pppppppcVar20 = (code *******)(2 - *(int *)(DAT_0050b1a4 + 0xe));
      if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar20) {
        pppppppcStack_2c0 = (code *******)0x483c06;
        __vbaGenerateBoundsError();
      }
      pppppppcVar23 = (code *******)-*(int *)(DAT_0050b1a4 + 10);
      if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar23) {
        pppppppcStack_2c0 = (code *******)0x483c1e;
        __vbaGenerateBoundsError();
      }
      iVar10 = (int)((int)pppppppcVar20 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar23) * 2;
    }
    if (*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) < -0x2b66) {
LAB_00483da2:
      pcVar22 = __vbaFreeVar_exref;
      pppppppcStack_2c0 = (code *******)0x0;
      pppppppcStack_2c4 = (code *******)0x4;
      pppppppcStack_2cc = &ppppppcStack_150;
      pppppppcStack_2c8 = apppppppcStack_1f8[0];
      pppppppcStack_2d0 = (code *******)0x483dbd;
      pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
      pppppppcStack_2c4 = (code *******)0x483dc7;
      iVar10 = __vbaI4Var();
      pppppppcVar20 = (code *******)pcVar22;
      pppppppcVar24 = pppppppcVar23;
      if (((!SBORROW4(iVar10,1)) && (!SCARRY2(DAT_0050b20c,5))) &&
         (!SBORROW4(iVar10 + -1,(int)(short)(DAT_0050b20c + 5)))) {
        pppppppcStack_2c0 = (code *******)0x483df4;
        DAT_0050b212 = __vbaI2I4();
        pppppppcStack_2c0 = (code *******)0x483dff;
        __vbaFreeVar();
        pppppppcVar20 = (code *******)__vbaLateIdCallSt_exref;
        if ((DAT_0050b274 < 2) || (5 < DAT_0050b274)) {
LAB_00484ee8:
          if (DAT_0050b240 == 2) {
            sStack_25c = DAT_0050b292;
            pppppppcVar23 = (code *******)&DAT_00000001;
            do {
              pppppppcVar28 = pppppppcVar23;
              sVar17 = (short)pppppppcVar28;
              pppppppcStack_120 = pppppppcVar28;
              if (sStack_25c < sVar17) goto LAB_0048503a;
              if ((DAT_0050b39c == (short *)0x0) || (*DAT_0050b39c != 1)) {
                pppppppcStack_2c0 = (code *******)0x484f50;
                iVar10 = __vbaGenerateBoundsError();
              }
              else {
                iVar10 = *(int *)(DAT_0050b39c + 10);
                if (*(uint *)(DAT_0050b39c + 8) <= (uint)(sVar17 - iVar10)) {
                  pppppppcStack_2c0 = (code *******)0x484f3f;
                  __vbaGenerateBoundsError();
                }
                iVar10 = (sVar17 - iVar10) * 4;
              }
              pppppppcStack_2c0 = (code *******)0x1;
              pppppppcStack_2c4 = *(code ********)(*(int *)(DAT_0050b39c + 6) + iVar10);
              pppppppcStack_2c8 = (code *******)0x484f65;
              Ordinal_616();
              pppppppcStack_2c8 = (code *******)0x484f70;
              pppppppcStack_2c8 = (code *******)__vbaStrMove();
              pppppppcStack_2cc = (code *******)&DAT_0040d3ec;
              pppppppcStack_2d0 = (code *******)0x484f7c;
              iVar10 = __vbaStrCmp();
              pppppppcVar24 = (code *******)-(uint)(iVar10 == 0);
              pppppppcStack_2d0 = (code *******)0x484f8e;
              __vbaFreeStr();
              if ((short)pppppppcVar24 != 0) {
                pppppppcStack_180 = (code *******)0x3;
                if (SCARRY2(DAT_0050b298,2)) break;
                pppppppcVar24 = (code *******)0x3;
                pppppppcStack_2d4 = (code *******)(int)sVar17;
                pppppppcStack_2c4 = (code *******)(int)(short)(DAT_0050b298 + 2);
                pppppppcStack_2cc = (code *******)0x3;
                pppppppcStack_2c8 = pppppppcStack_17c;
                pppppppcStack_2c0 = pppppppcStack_174;
                pppppppcStack_2dc = (code *******)0x3;
                pppppppcStack_2d8 = pppppppcStack_19c;
                pppppppcStack_2d0 = pppppppcStack_194;
                pppppppcStack_2f0 = (code *******)0x2;
                uStack_2f4 = 0x41;
                pppppppcStack_2ec = (code *******)0x8;
                pppppppcStack_2e8 = pppppppcStack_1bc;
                ppppppcStack_2e4 = (code ******)0x410f3c;
                pppppppcStack_2e0 = pppppppcStack_1b4;
                pppppppcStack_2f8 = apppppppcStack_1f8[0];
                uStack_2fc = 0x48501f;
                pppppppcStack_178 = pppppppcStack_2c4;
                (*(code *)pppppppcVar20)();
                pppppppcVar28 = pppppppcStack_120;
              }
              pppppppcVar23 = (code *******)(uint)(ushort)((short)pppppppcVar28 + 1);
            } while (!SCARRY2((short)pppppppcVar28,1));
          }
          else {
LAB_0048503a:
            pppppppcStack_2c0 = (code *******)0x0;
            pppppppcStack_2c4 = (code *******)0x4;
            pppppppcStack_2cc = appppppcStack_160;
            pppppppcStack_2c8 = apppppppcStack_1f8[0];
            pppppppcStack_2d0 = (code *******)0x48504f;
            pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
            pppppppcVar28 = (code *******)__vbaI4Var_exref;
            pppppppcStack_2c4 = (code *******)0x48505b;
            iVar10 = __vbaI4Var();
            pppppppcVar24 = (code *******)__vbaI2I4_exref;
            if (!SBORROW4(iVar10,2)) {
              pppppppcStack_2c0 = (code *******)0x48506e;
              uStack_264 = __vbaI2I4();
              pppppppcStack_2c0 = (code *******)0x0;
              pppppppcStack_2c4 = (code *******)0x4;
              pppppppcStack_2cc = &ppppppcStack_150;
              pppppppcStack_2c8 = apppppppcStack_1f8[0];
              pppppppcStack_2d0 = (code *******)0x485089;
              pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
              pppppppcStack_2c4 = (code *******)0x48508f;
              iVar10 = __vbaI4Var();
              if (!SBORROW4(iVar10,4)) {
                pppppppcStack_2c0 = (code *******)0x48509c;
                pppppppcVar23 = (code *******)__vbaI2I4();
                pppppppcStack_2c0 = appppppcStack_160;
                pppppppcStack_2c4 = &ppppppcStack_150;
                pppppppcStack_2c8 = (code *******)0x2;
                pppppppcStack_2cc = (code *******)0x4850ae;
                __vbaFreeVarList();
                do {
                  pppppppcVar24 = pppppppcVar23;
                  sVar17 = (short)pppppppcVar24;
                  if ((short)uStack_264 < sVar17) {
                    pppppppcStack_2c4 = (code *******)apppppppcStack_1f8;
                    pppppppcStack_2c0 = (code *******)0x0;
                    pppppppcStack_2c8 = (code *******)0x4859b0;
                    __vbaObjSetAddref();
                    pppppppcStack_2c8 = (code *******)&LAB_00485a10;
                    pppppppcStack_2cc = (code *******)0x4859fa;
                    __vbaFreeObj();
                    pppppppcStack_2cc = (code *******)0x485a03;
                    __vbaFreeStr();
                    pppppppcStack_2cc = &ppppppcStack_130;
                    pppppppcStack_2d0 = (code *******)0x0;
                    pppppppcStack_2d4 = (code *******)0x485a0f;
                    __vbaAryDestruct();
                    return;
                  }
                  pppppppcVar23 = (code *******)0x0;
                  sStack_26c = DAT_0050b20a;
                  while (pppppppcStack_120 = pppppppcVar23, (short)pppppppcVar23 <= sStack_26c) {
                    pppppppcVar28 = (code *******)(int)(short)pppppppcVar23;
                    if (pppppppcVar28 == (code *******)0x0) {
                      pppppppcStack_180 = (code *******)0x3;
                      pppppppcVar28 = (code *******)(int)sVar17;
                      pppppppcStack_2cc = (code *******)0x3;
                      pppppppcStack_2d0 = (code *******)0xa;
                      pppppppcStack_2c8 = pppppppcStack_17c;
                      pppppppcStack_2d4 = apppppppcStack_1f8[0];
                      pppppppcStack_2c0 = pppppppcStack_174;
                      pppppppcStack_2d8 = (code *******)0x4856a3;
                      pppppppcStack_2c4 = pppppppcVar28;
                      pppppppcStack_178 = pppppppcVar28;
                      __vbaLateIdSt();
                      pppppppcStack_180 = (code *******)0x3;
                      pppppppcStack_2e8 = (code *******)0xb;
                      ppppppcStack_2e4 = (code ******)0x3;
                      pppppppcStack_178 = (code *******)0x0;
                      pppppppcStack_2e0 = pppppppcStack_17c;
                      pppppppcStack_2ec = apppppppcStack_1f8[0];
                      pppppppcStack_2dc = (code *******)0x0;
                      pppppppcStack_2d8 = pppppppcStack_174;
                      pppppppcStack_2f0 = (code *******)0x4856d5;
                      __vbaLateIdSt();
                      pppppppcStack_180 = (code *******)0x3;
                      pppppppcStack_300 = (code *******)0x26;
                      uStack_2fc = 3;
                      pppppppcStack_178 = (code *******)0xffff00;
                      pppppppcStack_2f8 = pppppppcStack_17c;
                      pppppppcStack_304 = apppppppcStack_1f8[0];
                      uStack_2f4 = 0xffff00;
                      pppppppcStack_2f0 = pppppppcStack_174;
                      pppppppcStack_308 = (code *******)0x48570a;
                      __vbaLateIdSt();
                      pppppppcStack_180 = (code *******)0x3;
                      ppppppcStack_318 = (code ******)0x27;
                      fStack_314 = 4.2039e-45;
                      pppppppcStack_178 = (code *******)0xff0000;
                      pppppppcStack_310 = pppppppcStack_17c;
                      pppppppcStack_31c = apppppppcStack_1f8[0];
                      uStack_30c = 0xff0000;
                      pppppppcStack_308 = pppppppcStack_174;
                      uStack_320 = 0x48573f;
                      __vbaLateIdSt();
                      uStack_320 = 0;
                      uStack_324 = 4;
                      ppppppcStack_32c = (code ******)&ppppppcStack_150;
                      pppppppcStack_328 = apppppppcStack_1f8[0];
                      uStack_330 = 0x485754;
                      uStack_320 = __vbaLateIdCallLd();
                      uStack_324 = 0x48575e;
                      iVar10 = __vbaI4Var();
                      if (SBORROW4(iVar10,4)) goto LAB_00485a28;
                      pppppppcStack_2c0 = (code *******)0x48576f;
                      sVar18 = __vbaI2I4();
                      iStack_1d4 = -(uint)(sVar17 == sVar18);
                      pppppppcStack_2c0 = (code *******)0x485788;
                      __vbaFreeVar();
                      if ((short)iStack_1d4 == 0) {
                        pppppppcStack_2c0 = (code *******)0x0;
                        pppppppcStack_2c4 = (code *******)0x4;
                        pppppppcStack_2cc = &ppppppcStack_150;
                        pppppppcStack_2c8 = apppppppcStack_1f8[0];
                        pppppppcStack_2d0 = (code *******)0x48580a;
                        pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
                        pppppppcStack_2c4 = (code *******)0x485814;
                        iVar10 = __vbaI4Var();
                        if (SBORROW4(iVar10,3)) goto LAB_00485a28;
                        pppppppcStack_2c0 = (code *******)0x485825;
                        sVar18 = __vbaI2I4();
                        iStack_1d4 = -(uint)(sVar17 == sVar18);
                        pppppppcStack_2c0 = (code *******)0x48583e;
                        __vbaFreeVar();
                        if ((short)iStack_1d4 == 0) {
                          pppppppcStack_2c0 = (code *******)0x0;
                          pppppppcStack_2c4 = (code *******)0x4;
                          pppppppcStack_2cc = &ppppppcStack_150;
                          pppppppcStack_2c8 = apppppppcStack_1f8[0];
                          pppppppcStack_2d0 = (code *******)0x4858c0;
                          pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
                          pppppppcStack_2c4 = (code *******)0x4858ca;
                          iVar10 = __vbaI4Var();
                          if (SBORROW4(iVar10,2)) goto LAB_00485a28;
                          pppppppcStack_2c0 = (code *******)0x4858db;
                          sVar18 = __vbaI2I4();
                          iStack_1d4 = -(uint)(sVar17 == sVar18);
                          pppppppcStack_2c0 = (code *******)0x4858f4;
                          __vbaFreeVar();
                          if ((short)iStack_1d4 == 0) goto LAB_00485978;
                          ppppppcStack_2e4 = (code ******)0x410f50;
                        }
                        else {
                          ppppppcStack_2e4 = (code ******)0x40f110;
                        }
                      }
                      else {
                        ppppppcStack_2e4 = (code ******)0x40f0f4;
                      }
                      pppppppcStack_2d4 = (code *******)0x0;
LAB_00485973:
                      pppppppcStack_2c4 = (code *******)(int)sVar17;
                      pppppppcStack_180 = (code *******)0x3;
                      pppppppcStack_2cc = (code *******)0x3;
                      pppppppcStack_2dc = (code *******)0x3;
                      pppppppcStack_2ec = (code *******)0x8;
                      pppppppcStack_2f0 = (code *******)0x2;
                      uStack_2f4 = 0x41;
                      uStack_2fc = 0x485975;
                      pppppppcStack_2f8 = apppppppcStack_1f8[0];
                      pppppppcStack_2e8 = pppppppcStack_1bc;
                      pppppppcStack_2e0 = pppppppcStack_1b4;
                      pppppppcStack_2d8 = pppppppcStack_19c;
                      pppppppcStack_2d0 = pppppppcStack_194;
                      pppppppcStack_2c8 = pppppppcStack_17c;
                      pppppppcStack_178 = pppppppcStack_2c4;
                      (*(code *)pppppppcVar20)();
                    }
                    else {
                      pppppppcStack_2c0 = (code *******)0x0;
                      pppppppcStack_2c4 = (code *******)0x4;
                      pppppppcStack_2cc = &ppppppcStack_150;
                      pppppppcStack_2c8 = apppppppcStack_1f8[0];
                      pppppppcStack_2d0 = (code *******)0x4850fe;
                      pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
                      pppppppcStack_2c4 = (code *******)0x485108;
                      iVar10 = __vbaI4Var();
                      if (SBORROW4(iVar10,4)) goto LAB_00485a28;
                      pppppppcStack_2c0 = (code *******)0x485119;
                      sVar18 = __vbaI2I4();
                      iStack_1d4 = -(uint)(sVar17 == sVar18);
                      pppppppcStack_2c0 = (code *******)0x485132;
                      __vbaFreeVar();
                      if ((short)iStack_1d4 == 0) {
                        pppppppcStack_2c0 = (code *******)0x0;
                        pppppppcStack_2c4 = (code *******)0x4;
                        pppppppcStack_2cc = &ppppppcStack_150;
                        pppppppcStack_2c8 = apppppppcStack_1f8[0];
                        pppppppcStack_2d0 = (code *******)0x485278;
                        pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
                        pppppppcStack_2c4 = (code *******)0x485282;
                        iVar10 = __vbaI4Var();
                        if (!SBORROW4(iVar10,3)) {
                          pppppppcStack_2c0 = (code *******)0x485293;
                          sVar18 = __vbaI2I4();
                          iStack_1d4 = -(uint)(sVar17 == sVar18);
                          pppppppcStack_2c0 = (code *******)0x4852ac;
                          __vbaFreeVar();
                          if ((short)iStack_1d4 == 0) {
                            pppppppcStack_2c0 = (code *******)0x0;
                            pppppppcStack_2c4 = (code *******)0x4;
                            pppppppcStack_2cc = &ppppppcStack_150;
                            pppppppcStack_2c8 = apppppppcStack_1f8[0];
                            pppppppcStack_2d0 = (code *******)0x4854c9;
                            pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
                            pppppppcStack_2c4 = (code *******)0x4854d3;
                            iVar10 = __vbaI4Var();
                            if (SBORROW4(iVar10,2)) goto LAB_00485a28;
                            pppppppcStack_2c0 = (code *******)0x4854e4;
                            sVar18 = __vbaI2I4();
                            iStack_1d4 = -(uint)(sVar17 == sVar18);
                            pppppppcStack_2c0 = (code *******)0x4854fd;
                            __vbaFreeVar();
                            if ((short)iStack_1d4 == 0) goto LAB_00485978;
                            if ((DAT_0050b0b8 == (short *)0x0) || (*DAT_0050b0b8 != 2)) {
                              pppppppcStack_2c0 = (code *******)0x48557f;
                              iVar10 = __vbaGenerateBoundsError();
                            }
                            else {
                              pppppcStack_1dc =
                                   (code *****)((int)DAT_0050b2b2 - *(int *)(DAT_0050b0b8 + 0xe));
                              if (*(code ******)(DAT_0050b0b8 + 0xc) <= pppppcStack_1dc) {
                                pppppppcStack_2c0 = (code *******)0x48553a;
                                __vbaGenerateBoundsError();
                              }
                              uStack_1d8 = (int)pppppppcVar28 - *(int *)(DAT_0050b0b8 + 10);
                              if (*(uint *)(DAT_0050b0b8 + 8) <= uStack_1d8) {
                                pppppppcStack_2c0 = (code *******)0x48555c;
                                __vbaGenerateBoundsError();
                              }
                              iVar10 = (int)((int)pppppcStack_1dc +
                                            *(int *)(DAT_0050b0b8 + 0xc) * uStack_1d8) * 8;
                            }
                            if (*(double *)(*(int *)(DAT_0050b0b8 + 6) + iVar10) == _DAT_00401490) {
                              ppppppcStack_2e4 = (code ******)&DAT_0040cc94;
                            }
                            else {
                              ppppppcStack_2e4 = (code ******)&DAT_0040cb68;
                            }
                          }
                          else {
                            if ((DAT_0050b0b8 == (short *)0x0) || (*DAT_0050b0b8 != 2)) {
                              pppppppcStack_2c0 = (code *******)0x48532e;
                              iVar10 = __vbaGenerateBoundsError();
                            }
                            else {
                              pppppcStack_1dc =
                                   (code *****)((int)DAT_0050b2b0 - *(int *)(DAT_0050b0b8 + 0xe));
                              if (*(code ******)(DAT_0050b0b8 + 0xc) <= pppppcStack_1dc) {
                                pppppppcStack_2c0 = (code *******)0x4852e9;
                                __vbaGenerateBoundsError();
                              }
                              uStack_1d8 = (int)pppppppcVar28 - *(int *)(DAT_0050b0b8 + 10);
                              if (*(uint *)(DAT_0050b0b8 + 8) <= uStack_1d8) {
                                pppppppcStack_2c0 = (code *******)0x48530b;
                                __vbaGenerateBoundsError();
                              }
                              iVar10 = (int)((int)pppppcStack_1dc +
                                            *(int *)(DAT_0050b0b8 + 0xc) * uStack_1d8) * 8;
                            }
                            DAT_0050b13c = *(undefined4 *)(*(int *)(DAT_0050b0b8 + 6) + iVar10);
                            DAT_0050b140 = *(undefined4 *)(*(int *)(DAT_0050b0b8 + 6) + 4 + iVar10);
                            if ((double)CONCAT44(DAT_0050b140,DAT_0050b13c) !=
                                (double)CONCAT44(DAT_0050b138,DAT_0050b134)) goto LAB_004853c8;
                            ppppppcStack_2e4 = (code ******)0x40cc7c;
                          }
LAB_00485652:
                          uStack_1a0 = 3;
                          in_FPUStatusWord = 0;
                          pppppppcStack_2d4 = pppppppcVar28;
                          goto LAB_00485973;
                        }
                        goto LAB_00485a28;
                      }
                      if ((DAT_0050b0b8 == (short *)0x0) || (*DAT_0050b0b8 != 2)) {
                        pppppppcStack_2c0 = (code *******)0x4851b4;
                        iVar10 = __vbaGenerateBoundsError();
                      }
                      else {
                        pppppcStack_1dc =
                             (code *****)((int)DAT_0050b2ac._2_2_ - *(int *)(DAT_0050b0b8 + 0xe));
                        if (*(code ******)(DAT_0050b0b8 + 0xc) <= pppppcStack_1dc) {
                          pppppppcStack_2c0 = (code *******)0x48516f;
                          __vbaGenerateBoundsError();
                        }
                        uStack_1d8 = (int)pppppppcVar28 - *(int *)(DAT_0050b0b8 + 10);
                        if (*(uint *)(DAT_0050b0b8 + 8) <= uStack_1d8) {
                          pppppppcStack_2c0 = (code *******)0x485191;
                          __vbaGenerateBoundsError();
                        }
                        iVar10 = (int)((int)pppppcStack_1dc +
                                      *(int *)(DAT_0050b0b8 + 0xc) * uStack_1d8) * 8;
                      }
                      DAT_0050b13c = *(undefined4 *)(*(int *)(DAT_0050b0b8 + 6) + iVar10);
                      DAT_0050b140 = *(undefined4 *)(*(int *)(DAT_0050b0b8 + 6) + 4 + iVar10);
                      if ((in_FPUStatusWord & 0xd) != 0) {
                        __vbaFPException();
                        return;
                      }
                      pppppppcStack_2c0 = (code *******)0x4851e7;
                      fVar31 = (float10)__vbaFpR8();
                      if (fVar31 == (float10)(double)CONCAT44(DAT_0050b140,DAT_0050b13c)) {
                        ppppppcStack_2e4 = (code ******)0x40cb50;
                        goto LAB_00485652;
                      }
LAB_004853c8:
                      in_FPUStatusWord = 0;
                      pppppppcStack_2c0 = (code *******)0x4853cd;
                      FUN_0044fdc0();
                      pppppppcStack_2c0 = (code *******)0x4853d8;
                      __vbaStrMove();
                      pppppppcStack_2c0 = (code *******)0x1;
                      ppppppcStack_148 = ppppppcStack_138;
                      pppppppcStack_2c8 = &ppppppcStack_150;
                      pppppppcStack_2c4 = (code *******)&DAT_00000001;
                      pppppppcStack_2cc = (code *******)&pppppppcStack_180;
                      pppppppcStack_2d0 = appppppcStack_160;
                      ppppppcStack_138 = (code ******)0x0;
                      ppppppcStack_150 = (code ******)0x8;
                      pppppppcStack_178 = (code *******)&DAT_0050b13c;
                      pppppppcStack_180 = (code *******)0x4005;
                      pppppppcStack_2d4 = (code *******)0x485410;
                      Ordinal_660();
                      pppppppcStack_2d4 = appppppcStack_160;
                      pppppppcStack_2d8 = (code *******)0x48541a;
                      uStack_2fc = __vbaStrVarMove();
                      ppppppcStack_170 = (code ******)0x8;
                      ppppppcStack_2e4 = (code ******)0x3;
                      pppppppcStack_2e0 = (code *******)ppppppcStack_18c;
                      pppppppcStack_2dc = (code *******)(int)sVar17;
                      pppppppcStack_2d8 = (code *******)uStack_184;
                      uStack_2f4 = 3;
                      pppppppcStack_2f0 = pppppppcStack_1ac;
                      pppppppcStack_2e8 = (code *******)ppppppcStack_1a4;
                      pppppppcStack_308 = (code *******)0x2;
                      uStack_30c = 0x41;
                      pppppppcStack_304 = (code *******)0x8;
                      pppppppcStack_300 = pppppppcStack_16c;
                      pppppppcStack_310 = apppppppcStack_1f8[0];
                      pppppppcStack_2f8 = pppppppcStack_164;
                      fStack_314 = 6.642485e-39;
                      pppppppcStack_2ec = pppppppcVar28;
                      uStack_168 = uStack_2fc;
                      (*(code *)pppppppcVar20)();
                      pppppppcStack_2d8 = (code *******)0x485498;
                      __vbaFreeStr();
                      pppppppcStack_2d8 = &ppppppcStack_170;
                      pppppppcStack_2dc = appppppcStack_160;
                      pppppppcStack_2e0 = &ppppppcStack_150;
                      ppppppcStack_2e4 = (code ******)0x3;
                      pppppppcStack_2e8 = (code *******)0x4854ac;
                      __vbaFreeVarList();
                    }
LAB_00485978:
                    bVar29 = SCARRY2((short)pppppppcStack_120,1);
                    pppppppcVar23 = (code *******)(uint)(ushort)((short)pppppppcStack_120 + 1);
                    if (bVar29) goto LAB_00485a28;
                  }
                  pppppppcVar23 = (code *******)(uint)(ushort)(sVar17 + 1);
                } while (!SCARRY2(sVar17,1));
              }
            }
          }
        }
        else {
          pppppppcVar20 = (code *******)pcVar22;
          pppppppcVar28 = _DAT_0050b298;
          pppppppcVar4 = _DAT_0050b298;
          uVar12 = CONCAT22(DAT_0050b274 >> 0xf,DAT_0050b298 + 1);
          if (!SCARRY2(DAT_0050b298,1)) {
            while( true ) {
              uStack_214 = uVar12;
              pppppppcVar28 = pppppppcVar4;
              pppppppcVar24 = (code *******)__vbaLateIdCallLd_exref;
              sVar17 = (short)pppppppcVar28;
              pppppppcStack_2c0 = (code *******)0x0;
              if ((short)uStack_214 < sVar17) break;
              pppppppcStack_2c4 = (code *******)0x5;
              pppppppcStack_2cc = &ppppppcStack_150;
              pppppppcStack_2c8 = apppppppcStack_1f8[0];
              pppppppcStack_2d0 = (code *******)0x483e52;
              pppppppcStack_2c0 = (code *******)__vbaLateIdCallLd();
              pppppppcStack_2c4 = (code *******)0x483e5c;
              iVar10 = __vbaI4Var();
              pppppppcVar24 = pppppppcVar23;
              if (SBORROW4(iVar10,1)) goto LAB_00485a28;
              pppppppcStack_2c0 = (code *******)0x483e6d;
              uStack_21c = __vbaI2I4();
              pppppppcStack_2c0 = (code *******)0x483e83;
              __vbaFreeVar();
              pppppppcVar23 = (code *******)0x0;
              while( true ) {
                sVar18 = (short)pppppppcVar23;
                pppppppcVar24 = pppppppcVar23;
                if ((short)uStack_21c < sVar18) break;
                pppppppcStack_180 = (code *******)0x3;
                pppppppcStack_2c4 = (code *******)(int)sVar17;
                pppppppcStack_2cc = (code *******)0x3;
                pppppppcStack_2d0 = (code *******)0xa;
                pppppppcStack_2c8 = pppppppcStack_17c;
                pppppppcStack_2d4 = apppppppcStack_1f8[0];
                pppppppcStack_2c0 = pppppppcStack_174;
                pppppppcStack_2d8 = (code *******)0x483ec3;
                pppppppcStack_178 = pppppppcStack_2c4;
                __vbaLateIdSt();
                pppppppcStack_180 = (code *******)0x3;
                pppppppcStack_2dc = (code *******)(int)sVar18;
                ppppppcStack_2e4 = (code ******)0x3;
                pppppppcStack_2e8 = (code *******)0xb;
                pppppppcStack_2e0 = pppppppcStack_17c;
                pppppppcStack_2ec = apppppppcStack_1f8[0];
                pppppppcStack_2d8 = pppppppcStack_174;
                pppppppcStack_2f0 = (code *******)0x483ef6;
                pppppppcStack_178 = pppppppcStack_2dc;
                __vbaLateIdSt();
                pppppppcStack_180 = (code *******)0x3;
                pppppppcStack_300 = (code *******)0x26;
                uStack_2fc = 3;
                pppppppcStack_178 = (code *******)0xffff00;
                pppppppcStack_2f8 = pppppppcStack_17c;
                pppppppcStack_304 = apppppppcStack_1f8[0];
                uStack_2f4 = 0xffff00;
                pppppppcStack_2f0 = pppppppcStack_174;
                pppppppcStack_308 = (code *******)0x483f2b;
                __vbaLateIdSt();
                pppppppcStack_180 = (code *******)0x3;
                ppppppcStack_318 = (code ******)0x27;
                fStack_314 = 4.2039e-45;
                pppppppcStack_178 = (code *******)0xff0000;
                pppppppcStack_310 = pppppppcStack_17c;
                pppppppcStack_31c = apppppppcStack_1f8[0];
                uStack_30c = 0xff0000;
                pppppppcStack_308 = pppppppcStack_174;
                uStack_320 = 0x483f60;
                __vbaLateIdSt();
                pppppppcVar20 = (code *******)&DAT_00000001;
                pppppppcVar23 = (code *******)CONCAT22(extraout_var_02,sVar18 + 1);
                if (SCARRY2(sVar18,1)) goto LAB_00485a28;
              }
              pppppppcVar20 = (code *******)__vbaFreeVar_exref;
              pppppppcVar4 = (code *******)(uint)(ushort)(sVar17 + 1);
              uVar12 = uStack_214;
              if (SCARRY2(sVar17,1)) goto LAB_00485a28;
            }
            pppppppcStack_2c4 = (code *******)0x0;
            pppppppcStack_2c8 = (code *******)0x4;
            pppppppcStack_2d0 = &ppppppcStack_150;
            pppppppcStack_2cc = apppppppcStack_1f8[0];
            pppppppcStack_2d4 = (code *******)0x483fab;
            pppppppcStack_2c4 = (code *******)__vbaLateIdCallLd();
            pppppppcVar28 = (code *******)__vbaI4Var_exref;
            pppppppcStack_2c8 = (code *******)0x483fb7;
            iVar10 = __vbaI4Var();
            if ((!SBORROW4(iVar10,4)) &&
               (pppppppcStack_2c0 = (code *******)(iVar10 + -4 + (int)DAT_0050b298),
               !SCARRY4(iVar10 + -4,(int)DAT_0050b298))) {
              pppppppcStack_2c4 = (code *******)0x0;
              pppppppcStack_2c8 = (code *******)0x0;
              pppppppcStack_2cc = (code *******)0x5;
              pppppppcStack_2d0 = apppppppcStack_1f8[0];
              pppppppcStack_2d8 = (code *******)0x483fe3;
              pppppppcStack_2d4 = appppppcStack_160;
              pppppppcStack_2c8 = (code *******)__vbaLateIdCallLd();
              pppppppcStack_2cc = (code *******)0x483fe9;
              iVar10 = __vbaI4Var();
              pppppppcStack_2c0 = (code *******)(iVar10 + -1);
              if (!SBORROW4(iVar10,1)) {
                pppppppcStack_2c4 = (code *******)0x2;
                pppppppcStack_2c8 = (code *******)0x8;
                pppppppcStack_2d0 = (code *******)0x4;
                pppppppcStack_2d4 = (code *******)0x180;
                pppppppcStack_2d8 = (code *******)0x484008;
                pppppppcStack_2cc = &ppppppcStack_130;
                __vbaRedim();
                pppppppcStack_2d8 = appppppcStack_160;
                pppppppcStack_2dc = &ppppppcStack_150;
                pppppppcStack_2e0 = (code *******)0x2;
                ppppppcStack_2e4 = (code ******)0x484018;
                __vbaFreeVarList();
                ppppppcStack_2e4 = (code ******)0x0;
                pppppppcStack_2e8 = (code *******)0x4;
                pppppppcStack_2f0 = &ppppppcStack_150;
                pppppppcStack_2ec = apppppppcStack_1f8[0];
                uStack_2f4 = 0x484029;
                ppppppcStack_2b4 = (code ******)__vbaLateIdCallLd();
                ppppppcStack_2b8 = (code ******)0x48402f;
                iVar10 = __vbaI4Var();
                if (!SBORROW4(iVar10,5)) {
                  pppppppcStack_2c0 = (code *******)0x484040;
                  uStack_224 = __vbaI2I4();
                  pppppppcVar23 = _DAT_0050b298;
                  pppppppcStack_11c = _DAT_0050b298;
                  pppppppcStack_2c0 = (code *******)0x484054;
                  pppppppcVar11 = (code *******)(*(code *)pppppppcVar20)();
                  pppppppcVar4 = pppppppcStack_11c;
                  goto LAB_00484054;
                }
              }
            }
          }
        }
      }
    }
    else {
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        pppppppcStack_2c0 = (code *******)0x483ca1;
        __vbaGenerateBoundsError();
      }
      else {
        pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
        if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar23) {
          pppppppcStack_2c0 = (code *******)0x483c6c;
          __vbaGenerateBoundsError();
        }
        pppppppcVar20 = (code *******)(2 - *(int *)(DAT_0050b1a4 + 10));
        if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar20) {
          pppppppcStack_2c0 = (code *******)0x483c89;
          __vbaGenerateBoundsError();
        }
      }
      pppppppcStack_2c0 = (code *******)0x483cb4;
      sVar17 = __vbaI2Abs();
      pppppppcStack_180 = (code *******)0x3;
      pppppppcStack_2c4 = (code *******)(int)sVar17;
      pppppppcStack_2cc = (code *******)0x3;
      pppppppcStack_2d0 = (code *******)0xa;
      pppppppcStack_2c8 = pppppppcStack_17c;
      pppppppcStack_2d4 = apppppppcStack_1f8[0];
      pppppppcStack_2c0 = pppppppcStack_174;
      pppppppcStack_2d8 = (code *******)0x483ce3;
      pppppppcStack_178 = pppppppcStack_2c4;
      (*(code *)pppppppcVar28)();
      pppppppcStack_2d8 = (code *******)0x0;
      pppppppcStack_2dc = (code *******)0x5;
      ppppppcStack_2e4 = (code ******)&ppppppcStack_150;
      pppppppcStack_2e0 = apppppppcStack_1f8[0];
      pppppppcStack_2e8 = (code *******)0x483cf8;
      pppppppcStack_2d8 = (code *******)__vbaLateIdCallLd();
      pppppppcStack_2dc = (code *******)0x483d02;
      iVar10 = __vbaI4Var();
      pppppppcVar24 = pppppppcVar23;
      if (!SBORROW4(iVar10,1)) {
        pppppppcStack_2c0 = (code *******)0x483d13;
        uStack_208 = __vbaI2I4();
        pppppppcStack_2c0 = (code *******)0x483d29;
        __vbaFreeVar();
        pppppppcVar23 = (code *******)0x0;
        do {
          sVar17 = (short)pppppppcVar23;
          if ((short)uStack_208 < sVar17) goto LAB_00483da2;
          pppppppcStack_180 = (code *******)0x3;
          pppppppcStack_2c4 = (code *******)(int)sVar17;
          pppppppcStack_2cc = (code *******)0x3;
          pppppppcStack_2d0 = (code *******)0xb;
          pppppppcStack_2c8 = pppppppcStack_17c;
          pppppppcStack_2d4 = apppppppcStack_1f8[0];
          pppppppcStack_2c0 = pppppppcStack_174;
          pppppppcStack_2d8 = (code *******)0x483d61;
          pppppppcStack_178 = pppppppcStack_2c4;
          (*(code *)pppppppcVar28)();
          pppppppcStack_180 = (code *******)0x3;
          pppppppcStack_2e8 = (code *******)0x26;
          ppppppcStack_2e4 = (code ******)0x3;
          pppppppcStack_178 = (code *******)0xff;
          pppppppcStack_2e0 = pppppppcStack_17c;
          pppppppcStack_2ec = apppppppcStack_1f8[0];
          pppppppcStack_2dc = (code *******)0xff;
          pppppppcStack_2d8 = pppppppcStack_174;
          pppppppcStack_2f0 = (code *******)0x483d92;
          (*(code *)pppppppcVar28)();
          pppppppcVar20 = (code *******)&DAT_00000001;
          pppppppcVar24 = pppppppcVar23;
          pppppppcVar23 = (code *******)CONCAT22(extraout_var_01,sVar17 + 1);
        } while (!SCARRY2(sVar17,1));
      }
    }
  }
  else {
    if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
      pppppppcStack_2c0 = (code *******)0x483a3e;
      iVar10 = (*(code *)pppppppcVar20)();
    }
    else {
      pppppppcVar23 = (code *******)(2 - *(int *)(DAT_0050b1a4 + 0xe));
      if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar23) {
        pppppppcStack_2c0 = (code *******)0x483a11;
        (*(code *)pppppppcVar20)();
      }
      iVar10 = *(int *)(DAT_0050b1a4 + 10);
      if (*(uint *)(DAT_0050b1a4 + 8) <= 1U - iVar10) {
        pppppppcStack_2c0 = (code *******)0x483a2a;
        (*(code *)pppppppcVar20)();
      }
      iVar10 = (int)((int)pppppppcVar23 + *(int *)(DAT_0050b1a4 + 0xc) * (1U - iVar10)) * 2;
    }
    pppppppcVar28 = (code *******)__vbaLateIdSt_exref;
    pppppppcStack_2c4 = (code *******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10);
    pppppppcStack_180 = (code *******)0x3;
    pppppppcStack_2cc = (code *******)0x3;
    pppppppcStack_2d0 = (code *******)0xb;
    pppppppcStack_2c8 = pppppppcStack_17c;
    pppppppcStack_2d4 = apppppppcStack_1f8[0];
    pppppppcStack_2c0 = pppppppcStack_174;
    pppppppcStack_2d8 = (code *******)0x483a7d;
    pppppppcStack_178 = pppppppcStack_2c4;
    __vbaLateIdSt();
    if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
      pppppppcStack_2c0 = (code *******)0x483ad1;
      iVar10 = (*(code *)pppppppcVar20)();
    }
    else {
      pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
      if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar23) {
        pppppppcStack_2c0 = (code *******)0x483aa0;
        (*(code *)pppppppcVar20)();
      }
      pppppppcVar20 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
      if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar20) {
        pppppppcStack_2c0 = (code *******)0x483abd;
        __vbaGenerateBoundsError();
      }
      iVar10 = (int)((int)pppppppcVar23 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar20) * 2;
    }
    uVar5 = (undefined2)((uint)pppppppcVar20 >> 0x10);
    sVar17 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10) + DAT_0050b20c;
    pppppppcVar20 = (code *******)CONCAT22(uVar5,sVar17);
    pppppppcVar24 = pppppppcVar23;
    if (!SCARRY2(*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar10),DAT_0050b20c)) {
      pppppppcVar20 = (code *******)CONCAT22(uVar5,sVar17 + 5);
      if (!SCARRY2(sVar17,5)) {
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          pppppppcStack_2c0 = (code *******)0x483b55;
          iVar10 = __vbaGenerateBoundsError();
        }
        else {
          pppppcStack_1dc = (code *****)(1 - *(int *)(DAT_0050b1a4 + 0xe));
          if (*(code ******)(DAT_0050b1a4 + 0xc) <= pppppcStack_1dc) {
            pppppppcStack_2c0 = (code *******)0x483b1c;
            __vbaGenerateBoundsError();
          }
          pppppppcVar23 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
          if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar23) {
            pppppppcStack_2c0 = (code *******)0x483b39;
            __vbaGenerateBoundsError();
          }
          iVar10 = (int)((int)pppppcStack_1dc + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar23) *
                   2;
        }
        pppppppcVar23 =
             (code *******)
             CONCAT22((short)((uint)pppppppcVar23 >> 0x10),
                      *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar10));
        do {
          sVar18 = (short)pppppppcVar23;
          if ((short)(sVar17 + 5) < sVar18) goto LAB_00483be5;
          pppppppcStack_180 = (code *******)0x3;
          pppppppcStack_2c4 = (code *******)(int)sVar18;
          pppppppcStack_2cc = (code *******)0x3;
          pppppppcStack_2d0 = (code *******)0xa;
          pppppppcStack_2c8 = pppppppcStack_17c;
          pppppppcStack_2d4 = apppppppcStack_1f8[0];
          pppppppcStack_2c0 = pppppppcStack_174;
          pppppppcStack_2d8 = (code *******)0x483b96;
          pppppppcStack_178 = pppppppcStack_2c4;
          __vbaLateIdSt();
          pppppppcStack_180 = (code *******)0x3;
          pppppppcStack_2e8 = (code *******)0x26;
          ppppppcStack_2e4 = (code ******)0x3;
          pppppppcStack_178 = (code *******)0xff00;
          pppppppcStack_2e0 = pppppppcStack_17c;
          pppppppcStack_2ec = apppppppcStack_1f8[0];
          pppppppcStack_2dc = (code *******)0xff00;
          pppppppcStack_2d8 = pppppppcStack_174;
          pppppppcStack_2f0 = (code *******)0x483bc7;
          __vbaLateIdSt();
          pppppppcVar24 = pppppppcVar23;
          pppppppcVar23 = (code *******)(uint)(ushort)(sVar18 + 1);
        } while (!SCARRY2(sVar18,1));
      }
    }
  }
LAB_00485a28:
  pppppppcStack_2c0 = (code *******)0x485a2e;
  __vbaErrorOverflow();
  pppppppcStack_2cc = (code *******)&DAT_00402706;
  pppppppcStack_2d0 = ExceptionList;
  pppppppcStack_2c8 = (code *******)&pppppppcStack_374;
  pppppppcStack_2c4 = (code *******)&DAT_004020e8;
  pppppppcStack_2d8 = (code *******)0x0;
  pppppppcStack_2e0 = (code *******)0x0;
  ppppppcStack_2e4 = (code ******)0x0;
  pppppppcStack_2e8 = (code *******)0x0;
  uStack_30c = 0;
  pppppppcStack_310 = (code *******)0x0;
  fStack_314 = 0.0;
  ppppppcStack_318 = (code ******)0x0;
  apiStack_344[0] = (int *)0x0;
  ExceptionList = &pppppppcStack_2d0;
  pppppppcStack_374 = pppppppcVar28;
  pppppppcStack_370 = pppppppcVar24;
  pppppppcStack_36c = pppppppcVar20;
  pppppppcVar23 = (code *******)&pppppppcStack_374;
  pppppppcStack_2c0 = &ppppppcStack_108;
  if (DAT_0050b420 == (code ******)0x0) {
    ExceptionList = &pppppppcStack_2d0;
    pppppppcStack_2c0 = &ppppppcStack_108;
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    pppppppcVar23 = pppppppcStack_2c8;
  }
  pppppppcStack_2c8 = pppppppcVar23;
  __vbaObjSetAddref(apiStack_344,DAT_0050b420);
  iVar10 = (**(code **)(*apiStack_344[0] + 0x248))(apiStack_344[0],&pppppppcStack_2e8);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,apiStack_344[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppppcStack_2e8,0,8,uStack_2f4,L"arial",pppppppcStack_2ec);
  __vbaFreeObj();
  iVar10 = (**(code **)(*apiStack_344[0] + 0x248))(apiStack_344[0],&pppppppcStack_2e8);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,apiStack_344[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppppcStack_2e8,2,2,uStack_2f4,6,pppppppcStack_2ec);
  __vbaFreeObj();
  iVar10 = (**(code **)(*apiStack_344[0] + 0x6c))(apiStack_344[0],0xffffff);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,apiStack_344[0],&DAT_0040b430,0x6c);
  }
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  __vbaObjSetAddref(&pppppppcStack_2e8,DAT_0050b420);
  FUN_0048c990(&pppppppcStack_2e8);
  uVar12 = __vbaCastObj(pppppppcStack_2e8,&DAT_0040b85c);
  __vbaObjSet(&DAT_0050b420,uVar12);
  __vbaFreeObj();
  iVar10 = (**(code **)(*apiStack_344[0] + 0x248))(apiStack_344[0],&pppppppcStack_2e8);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,apiStack_344[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppppcStack_2e8,3,0xb,uStack_2f4,0xffffffff,pppppppcStack_2ec);
  __vbaFreeObj();
  __vbaObjSetAddref(apiStack_344,0);
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  uVar12 = (*(code *)(*DAT_0050b420)[0xd9])(DAT_0050b420);
  piVar13 = (int *)__vbaObjSet(&pppppppcStack_2e8,uVar12);
  iVar10 = (**(code **)(*piVar13 + 0x9c))(piVar13,0);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040c3dc,0x9c);
  }
  __vbaFreeObj();
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  uVar12 = (*(code *)(*DAT_0050b420)[0xec])
                     (DAT_0050b420,0x80010007,0xb,uStack_2f4,0,pppppppcStack_2ec);
  uVar12 = __vbaObjSet(&pppppppcStack_2e8,uVar12);
  __vbaLateIdSt(uVar12);
  __vbaFreeObj();
  switch(DAT_0050b274) {
  case 2:
    break;
  case 3:
    break;
  case 4:
    break;
  case 5:
    break;
  case 6:
    break;
  case 7:
    break;
  default:
    goto switchD_00485d2a_default;
  }
  __vbaStrCopy();
switchD_00485d2a_default:
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppcVar6 = DAT_0050b420;
  iVar10 = (*(code *)(*DAT_0050b420)[0x92])(DAT_0050b420,&pppppppcStack_2e8);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppppcStack_2e8,2,2,uStack_2f4,10,pppppppcStack_2ec);
  __vbaFreeObj();
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppcVar6 = DAT_0050b420;
  iVar10 = (*(code *)(*DAT_0050b420)[0x92])(DAT_0050b420,&pppppppcStack_2e8);
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(pppppppcStack_2e8,3,0xb,uStack_2f4,0xffffffff,pppppppcStack_2ec);
  __vbaFreeObj();
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppcVar6 = DAT_0050b420;
  iVar10 = (*(code *)(*DAT_0050b420)[0x4b])(DAT_0050b420,1);
  pcVar22 = __vbaHresultCheckObj_exref;
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,300);
  }
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppcVar6 = DAT_0050b420;
  pppppppcVar23 = (code *******)&pppppppcStack_310;
  ppppppcVar9 = DAT_0050b420;
  iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,pppppppcVar23);
  uVar30 = 0;
  if (iVar10 < 0) {
    __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
  }
  if (DAT_0050b420 == (code ******)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  ppppppcVar6 = DAT_0050b420;
  fVar3 = _DAT_0050b028 * (float)_DAT_004016e0 * (float)pppppppcStack_310;
  if ((uVar30 & 0xd) == 0) {
    fStack_350 = fVar3;
    iVar10 = (*(code *)(*DAT_0050b420)[0x3b])(DAT_0050b420,fVar3);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0xec);
    }
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar13 = DAT_0050c53c;
    iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppppcStack_2e8);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040b410,0x18);
    }
    pppppppcVar20 = pppppppcStack_2e8;
    iVar10 = (*(code *)(*pppppppcStack_2e8)[0x26])(pppppppcStack_2e8,&pppppppcStack_310);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppppcVar20,&DAT_0040bb5c,0x98);
    }
    if (DAT_0050b420 == (code ******)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    ppppppcVar6 = DAT_0050b420;
    pppppcVar21 = *DAT_0050b420;
    __vbaStrCat(pppppppcStack_2d8,L"SIMPLEX TABLEAU - ",&fStack_314);
    uVar12 = __vbaStrMove();
    iVar10 = (*(code *)pppppcVar21[0xb9])(ppppppcVar6,uVar12);
    uVar30 = 0;
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0x2e4);
    }
    if (DAT_0050b420 == (code ******)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    ppppppcVar6 = DAT_0050b420;
    if ((uVar30 & 0xd) == 0) {
      fVar3 = DAT_0050b024 * (float)_DAT_00401268 * ((float)pppppppcStack_310 - fStack_314);
      if ((uVar30 & 0xd) == 0) {
        fStack_354 = fVar3;
        iVar10 = (*(code *)(*DAT_0050b420)[0x39])(DAT_0050b420,fVar3);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0xe4);
        }
        __vbaFreeStr();
        __vbaFreeObj();
        if (DAT_0050b420 == (code ******)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        __vbaStrCat(pppppppcStack_2d8,L"SIMPLEX TABLEAU - ");
        uVar12 = __vbaStrMove();
        __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,uVar12);
        __vbaFreeStr();
        if (DAT_0050b420 == (code ******)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        ppppppcVar6 = DAT_0050b420;
        iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
        }
        if (DAT_0050c53c == (int *)0x0) {
          __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
        }
        piVar13 = DAT_0050c53c;
        iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppppcStack_2e8);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040b410,0x18);
        }
        pppppppcVar23 = pppppppcStack_2e8;
        iVar10 = (*(code *)(*pppppppcStack_2e8)[0x26])(pppppppcStack_2e8,&fStack_314);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,pppppppcVar23,&DAT_0040bb5c,0x98);
        }
        if (DAT_0050b420 == (code ******)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        ppppppcVar6 = DAT_0050b420;
        iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&ppppppcStack_318);
        uVar30 = 0;
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
        }
        if (DAT_0050b420 == (code ******)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        ppppppcVar6 = DAT_0050b420;
        pppppppcVar23 = (code *******)0x0;
        ppppppcVar9 = ppppppcStack_318;
        if ((uVar30 & 0xd) == 0) {
          iVar10 = (*(code *)(*DAT_0050b420)[0xb2])
                             (DAT_0050b420,4,0x44960000,pppppppcStack_310,
                              (fStack_314 - _DAT_004020e0) * DAT_0050b024,ppppppcStack_318,0);
          if (iVar10 < 0) {
            __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0x2c8);
          }
          __vbaFreeObj();
          if (DAT_0050b420 == (code ******)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          uVar12 = (*(code *)(*DAT_0050b420)[0xda])(DAT_0050b420);
          piVar13 = (int *)__vbaObjSet(&pppppppcStack_2e8,uVar12);
          iVar10 = (**(code **)(*piVar13 + 0xe8))(piVar13,&uStack_30c);
          if (iVar10 < 0) {
            __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040dc58,0xe8);
          }
          bVar29 = (short)uStack_30c == 0;
          __vbaFreeObj();
          if (bVar29) {
            if (DAT_0050b420 == (code ******)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            uVar12 = (*(code *)(*DAT_0050b420)[0xda])(DAT_0050b420);
            piVar13 = (int *)__vbaObjSet(&pppppppcStack_2e8,uVar12);
            iVar10 = (**(code **)(*piVar13 + 0x1ec))
                               (piVar13,L"Output summary",10,uStack_2f4,0x80020004,pppppppcStack_2ec
                               );
            if (iVar10 < 0) {
              __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040dc58,0x1ec);
            }
            __vbaFreeObj();
            if (DAT_0050b420 == (code ******)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            uVar12 = (*(code *)(*DAT_0050b420)[0xda])(DAT_0050b420);
            piVar13 = (int *)__vbaObjSet(&pppppppcStack_2e8,uVar12);
            iVar10 = (**(code **)(*piVar13 + 0x1ec))
                               (piVar13,L"Iterations",10,uStack_2f4,0x80020004,pppppppcStack_2ec);
            if (iVar10 < 0) {
              __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040dc58,0x1ec);
            }
            __vbaFreeObj();
            pcVar22 = __vbaHresultCheckObj_exref;
          }
          if (DAT_0050b420 == (code ******)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          ppppppcVar6 = DAT_0050b420;
          iVar10 = (*(code *)(*DAT_0050b420)[0x39])(DAT_0050b420,0x44960000);
          if (iVar10 < 0) {
            (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe4);
          }
          if (DAT_0050b420 == (code ******)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          ppppppcVar6 = DAT_0050b420;
          iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
          uVar30 = 0;
          if (iVar10 < 0) {
            (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
          }
          if (DAT_0050b420 == (code ******)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          ppppppcVar6 = DAT_0050b420;
          if ((uVar30 & 0xd) == 0) {
            fStack_358 = (float)pppppppcStack_310 * (float)_DAT_00401280;
            iVar10 = (*(code *)(*DAT_0050b420)[0x3b])
                               (DAT_0050b420,(float)pppppppcStack_310 * (float)_DAT_00401280);
            if (iVar10 < 0) {
              (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xec);
            }
            __vbaStrCopy();
            if (DAT_0050b23c == 1) {
              __vbaStrCopy();
            }
            if (DAT_0050b420 == (code ******)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            __vbaStrCat(*(undefined4 *)(DAT_0050b37c + 4),L"Title: ");
            uVar12 = __vbaStrMove();
            __vbaStrCat(pppppppcStack_2d8,uVar12);
            uVar12 = __vbaStrMove();
            __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,uVar12);
            __vbaFreeStrList(2,&pppppppcStack_2e0,&ppppppcStack_2e4);
            if (DAT_0050b420 == (code ******)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            ppppppcVar6 = DAT_0050b420;
            iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
            if (iVar10 < 0) {
              (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
            }
            if (DAT_0050c53c == (int *)0x0) {
              __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
            }
            piVar13 = DAT_0050c53c;
            iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppppcStack_2e8);
            if (iVar10 < 0) {
              (*pcVar22)(iVar10,piVar13,&DAT_0040b410,0x18);
            }
            pppppppcVar23 = pppppppcStack_2e8;
            iVar10 = (*(code *)(*pppppppcStack_2e8)[0x26])(pppppppcStack_2e8,&fStack_314);
            if (iVar10 < 0) {
              (*pcVar22)(iVar10,pppppppcVar23,&DAT_0040bb5c,0x98);
            }
            if (DAT_0050b420 == (code ******)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            ppppppcVar6 = DAT_0050b420;
            iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&ppppppcStack_318);
            uVar30 = 0;
            if (iVar10 < 0) {
              (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
            }
            if (DAT_0050b420 == (code ******)0x0) {
              __vbaNew2(&DAT_00408c88,&DAT_0050b420);
            }
            ppppppcVar6 = DAT_0050b420;
            pppppppcVar23 = (code *******)0x0;
            ppppppcVar9 = ppppppcStack_318;
            if ((uVar30 & 0xd) == 0) {
              iVar10 = (*(code *)(*DAT_0050b420)[0xb2])
                                 (DAT_0050b420,4,0x44960000,pppppppcStack_310,
                                  (fStack_314 - _DAT_004020e0) * DAT_0050b024,ppppppcStack_318,0);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0x2c8);
              }
              __vbaFreeObj();
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x92])(DAT_0050b420,&pppppppcStack_2e8);
              if (iVar10 < 0) {
                __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0x248);
              }
              __vbaLateIdSt(pppppppcStack_2e8,2,2,uStack_2f4,8,pppppppcStack_2ec);
              __vbaFreeObj();
              if (DAT_0050c53c == (int *)0x0) {
                __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
              }
              piVar13 = DAT_0050c53c;
              iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppppcStack_2e8);
              pcVar22 = __vbaHresultCheckObj_exref;
              if (iVar10 < 0) {
                __vbaHresultCheckObj(iVar10,piVar13,&DAT_0040b410,0x18);
              }
              pppppppcVar23 = pppppppcStack_2e8;
              iVar10 = (*(code *)(*pppppppcStack_2e8)[0x26])(pppppppcStack_2e8,&pppppppcStack_310);
              if (iVar10 < 0) {
                __vbaHresultCheckObj(iVar10,pppppppcVar23,&DAT_0040bb5c,0x98);
              }
              bVar29 = pppppppcStack_310 == (code *******)0x46160000;
              __vbaFreeObj();
              if (bVar29) {
                if (DAT_0050b420 == (code ******)0x0) {
                  __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                }
                ppppppcVar6 = DAT_0050b420;
                iVar10 = (*(code *)(*DAT_0050b420)[0x92])(DAT_0050b420,&pppppppcStack_2e8);
                if (iVar10 < 0) {
                  __vbaHresultCheckObj(iVar10,ppppppcVar6,&DAT_0040b430,0x248);
                }
                __vbaLateIdSt(pppppppcStack_2e8,2,2,uStack_2f4,6,pppppppcStack_2ec);
                __vbaFreeObj();
                pcVar22 = __vbaHresultCheckObj_exref;
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x39])(DAT_0050b420,0x44960000);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"Steps for generating NEXT tableau from CURRENT one:");
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              iStack_35c = 0x640;
              uStack_360 = 0x44c80000;
              iVar10 = (*(code *)(*DAT_0050b420)[0x39])(DAT_0050b420,0x44c80000);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar9 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar9,&DAT_0040b430,0xe8);
              }
              iVar10 = (*(code *)(*ppppppcVar6)[0x3b])(ppppppcVar6,pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xec);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"1.  ENTERING variable: Click a NONBASIC variable (if correct, column turns green)"
                           );
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              fStack_364 = (float)iStack_35c;
              iVar10 = (*(code *)(*DAT_0050b420)[0x39])(DAT_0050b420,fStack_364);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar9 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar9,&DAT_0040b430,0xe8);
              }
              iVar10 = (*(code *)(*ppppppcVar6)[0x3b])(ppppppcVar6,pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xec);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"2.  LEAVING variable: Click a BASIC variable (if correct, row turns red)"
                           );
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              fStack_368 = (float)iStack_35c;
              iVar10 = (*(code *)(*DAT_0050b420)[0x39])(DAT_0050b420,fStack_368);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe4);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar9 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar9,&DAT_0040b430,0xe8);
              }
              iVar10 = (*(code *)(*ppppppcVar6)[0x3b])(ppppppcVar6,pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xec);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                            L"3.  Click command button NEXT ITERATION (or ALL ITERATIONS) -- This step may be executed without Steps 1 and/or 2."
                           );
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&pppppppcStack_310);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
              }
              if (DAT_0050c53c == (int *)0x0) {
                __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
              }
              piVar13 = DAT_0050c53c;
              iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&pppppppcStack_2e8);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,piVar13,&DAT_0040b410,0x18);
              }
              pppppppcVar23 = pppppppcStack_2e8;
              iVar10 = (*(code *)(*pppppppcStack_2e8)[0x26])(pppppppcStack_2e8,&fStack_314);
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,pppppppcVar23,&DAT_0040bb5c,0x98);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              iVar10 = (*(code *)(*DAT_0050b420)[0x3a])(DAT_0050b420,&ppppppcStack_318);
              uVar30 = 0;
              if (iVar10 < 0) {
                (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0xe8);
              }
              if (DAT_0050b420 == (code ******)0x0) {
                __vbaNew2(&DAT_00408c88,&DAT_0050b420);
              }
              ppppppcVar6 = DAT_0050b420;
              pppppppcVar23 = (code *******)0x0;
              ppppppcVar9 = ppppppcStack_318;
              if ((uVar30 & 0xd) == 0) {
                iVar10 = (*(code *)(*DAT_0050b420)[0xb2])
                                   (DAT_0050b420,4,0x44960000,pppppppcStack_310,
                                    (fStack_314 - _DAT_004020e0) * DAT_0050b024);
                if (iVar10 < 0) {
                  (*pcVar22)(iVar10,ppppppcVar6,&DAT_0040b430,0x2c8);
                }
                __vbaFreeObj();
                __vbaFreeObj(&LAB_00486ced);
                __vbaFreeStr();
                return;
              }
            }
          }
        }
      }
    }
  }
  __vbaFPException(ppppppcVar9,pppppppcVar23);
  return;
}


