/* entry 00479150 name FUN_00479150 size 22631 */
/* strings:
 * Optimum solution is unbounded
 *  Value of the game  = 
 * CRITICAL PATH METHOD SCHEDULE
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00479150(uint param_1)

{
  float ***pppfVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  float *****pppppfVar5;
  float *****pppppfVar6;
  float *****pppppfVar7;
  float *****pppppfVar8;
  float *****pppppfVar9;
  undefined2 extraout_var;
  undefined4 uVar10;
  int iVar11;
  float ****ppppfVar12;
  undefined4 uVar13;
  float *****extraout_ECX;
  float *****extraout_ECX_00;
  undefined2 extraout_var_00;
  float *****extraout_ECX_01;
  float *****extraout_ECX_02;
  float *****extraout_ECX_03;
  float *****extraout_ECX_04;
  float *****extraout_ECX_05;
  short sVar14;
  code *pcVar15;
  float ***pppfVar16;
  ushort uVar17;
  float10 fVar18;
  float10 extraout_ST0;
  float ***pppfStack_4dc;
  float ****ppppfStack_4d8;
  float ****ppppfStack_4d4;
  float ****ppppfStack_4d0;
  float ****ppppfStack_4cc;
  float ****ppppfStack_4c8;
  float ****ppppfStack_4c4;
  float ****ppppfStack_4c0;
  float ****ppppfStack_4bc;
  float ****ppppfStack_4b8;
  float ****ppppfStack_4b4;
  float ****ppppfStack_4b0;
  float ****ppppfStack_4ac;
  float ***pppfStack_4a8;
  float ****ppppfStack_4a4;
  float ****ppppfStack_4a0;
  float ***pppfStack_49c;
  float ****ppppfStack_498;
  float ****ppppfStack_494;
  float ****ppppfStack_490;
  float ****ppppfStack_48c;
  float ****ppppfStack_488;
  float ****ppppfStack_484;
  float ****ppppfStack_480;
  float ****ppppfStack_47c;
  float ****ppppfStack_478;
  float ****ppppfStack_474;
  float ****ppppfStack_470;
  float ****ppppfStack_46c;
  float ****ppppfStack_468;
  float ****ppppfStack_464;
  float ****ppppfStack_460;
  float ****ppppfStack_45c;
  float ****ppppfStack_458;
  float ****ppppfStack_454;
  float ****ppppfStack_450;
  float ****ppppfStack_44c;
  float ****ppppfStack_448;
  float ****ppppfStack_444;
  float ****ppppfStack_440;
  float ****ppppfStack_43c;
  float ****ppppfStack_438;
  float ****ppppfStack_434;
  float ****ppppfStack_430;
  float ****ppppfStack_42c;
  float ****ppppfStack_428;
  float ****ppppfStack_424;
  float ****ppppfStack_420;
  float ****ppppfStack_41c;
  float ****ppppfStack_418;
  float ****ppppfStack_414;
  float ****ppppfStack_410;
  float ****ppppfStack_40c;
  float ****ppppfStack_408;
  float ****ppppfStack_404;
  float ****ppppfStack_400;
  float ****ppppfStack_3fc;
  float ****ppppfStack_3f8;
  undefined *puStack_3f4;
  float ****ppppfStack_3f0;
  float ****ppppfStack_3ec;
  float ****ppppfStack_3e8;
  float ****ppppfStack_3e4;
  float ****ppppfStack_3e0;
  int *piStack_3dc;
  undefined4 uStack_3d8;
  float ****ppppfStack_3d4;
  int iStack_3d0;
  float ****ppppfStack_3cc;
  float ****ppppfStack_3c8;
  float ****ppppfStack_3c4;
  int *piStack_3c0;
  undefined4 uStack_3bc;
  float ****ppppfStack_3b8;
  undefined4 uStack_3b4;
  undefined *puStack_3b0;
  wchar_t *pwStack_3ac;
  int *piStack_3a8;
  int local_348;
  short local_294;
  short local_274;
  short local_264;
  float ****local_254;
  float ****local_250;
  float ****local_24c;
  float ****local_248;
  float ****local_244 [3];
  float ***local_238;
  float ***local_234;
  float ***local_230;
  float ****local_22c;
  float **local_224;
  float ***local_220;
  float ***local_21c;
  float ****local_218;
  undefined4 local_214;
  float ****local_210;
  float ****local_208;
  float ***local_204 [2];
  undefined4 *local_1fc;
  float ***local_1f4 [2];
  int local_1ec;
  float ***local_1e4 [2];
  float ****local_1dc;
  float ***local_1d4 [2];
  undefined *local_1cc;
  float ****local_1c4;
  float ****local_1c0;
  float ****local_1bc;
  float ****local_1b8;
  float ****local_1b4;
  float ****local_1b0;
  float ***local_1ac;
  float ****local_1a8;
  float ***local_1a4 [2];
  wchar_t *local_19c;
  float ****local_194;
  float ****local_190;
  float ****local_18c;
  float ****local_188;
  float ***local_184;
  float ****local_180;
  wchar_t *local_17c;
  float ****local_178;
  float ****local_174;
  float ****local_170;
  float ****local_16c;
  float ****local_168;
  float ***local_164 [4];
  float ***local_154 [4];
  float ***local_144 [4];
  float ***local_134 [2];
  float ***local_12c;
  float ***local_124 [4];
  float ***local_114 [4];
  float ***local_104 [4];
  float ***local_f4 [4];
  float ***local_e4 [4];
  float ***local_d4 [2];
  float ***local_cc;
  float ***local_c4 [2];
  double local_bc;
  float ***local_b4 [4];
  float ***local_a4 [2];
  undefined4 local_9c;
  float ***local_94 [2];
  undefined4 local_8c;
  float ***local_84 [4];
  float ***local_74 [2];
  float ***local_6c;
  float ***local_64;
  float ***local_60;
  float ***local_5c;
  float ****local_58;
  float ***local_54;
  float ***local_50;
  float ***local_4c;
  float ***local_48;
  float ***local_44;
  float ***local_40;
  float ***local_3c;
  float ***local_38;
  float ***local_34;
  float ***local_30;
  undefined4 local_2c;
  float ***local_20;
  int local_1c;
  void *pvStack_18;
  undefined *puStack_14;
  undefined1 *local_10;
  undefined *local_c;
  uint local_8;
  
  puStack_14 = &DAT_00402706;
  pvStack_18 = ExceptionList;
  local_10 = &stack0xfffffc5c;
  local_c = &DAT_00401fd0;
  local_8 = param_1 & 1;
  piVar4 = (int *)(param_1 & 0xfffffffe);
  pwStack_3ac = (wchar_t *)0x479192;
  ExceptionList = &pvStack_18;
  piStack_3a8 = piVar4;
  (**(code **)(*piVar4 + 4))();
  local_20 = (float ***)0x0;
  local_30 = (float ***)0x0;
  local_34 = (float ***)0x0;
  local_38 = (float ***)0x0;
  local_3c = (float ***)0x0;
  local_40 = (float ***)0x0;
  local_44 = (float ***)0x0;
  local_48 = (float ***)0x0;
  local_4c = (float ***)0x0;
  local_50 = (float ***)0x0;
  local_54 = (float ***)0x0;
  local_58 = (float ****)0x0;
  local_5c = (float ***)0x0;
  local_60 = (float ***)0x0;
  local_64 = (float ***)0x0;
  local_74[0] = (float ***)0x0;
  local_84[0] = (float ***)0x0;
  local_94[0] = (float ***)0x0;
  local_a4[0] = (float ***)0x0;
  local_b4[0] = (float ***)0x0;
  local_c4[0] = (float ***)0x0;
  local_d4[0] = (float ***)0x0;
  local_e4[0] = (float ***)0x0;
  local_f4[0] = (float ***)0x0;
  local_104[0] = (float ***)0x0;
  local_114[0] = (float ***)0x0;
  local_124[0] = (float ***)0x0;
  local_134[0] = (float ***)0x0;
  local_144[0] = (float ***)0x0;
  local_154[0] = (float ***)0x0;
  local_164[0] = (float ***)0x0;
  local_174 = (float ****)0x0;
  local_184 = (float ***)0x0;
  local_194 = (float ****)0x0;
  local_1a4[0] = (float ***)0x0;
  local_1b4 = (float ****)0x0;
  local_1c4 = (float ****)0x0;
  local_1d4[0] = (float ***)0x0;
  local_1e4[0] = (float ***)0x0;
  local_1f4[0] = (float ***)0x0;
  local_204[0] = (float ***)0x0;
  local_214 = 0;
  local_218 = (float ****)0x0;
  local_21c = (float ***)0x0;
  local_220 = (float ***)0x0;
  local_244[0] = (float ****)0x0;
  local_248 = (float ****)0x0;
  local_24c = (float ****)0x0;
  local_250 = (float ****)0x0;
  local_254 = (float ****)0x0;
  DAT_0050b1fc = 0;
  if (DAT_0050b570 == (float *****)0x0) {
    pwStack_3ac = (wchar_t *)&DAT_0050b570;
    puStack_3b0 = &DAT_004048dc;
    uStack_3b4 = 0x4792ad;
    __vbaNew2();
  }
  pppppfVar6 = DAT_0050b570;
  pwStack_3ac = L"TORA ";
  puStack_3b0 = (undefined *)DAT_0050b350;
  ppppfVar12 = *DAT_0050b570;
  uStack_3b4 = 0x4792c6;
  __vbaStrCat();
  uStack_3b4 = 0x4792d1;
  uStack_3b4 = __vbaStrMove();
  ppppfStack_3b8 = (float ****)pppppfVar6;
  uStack_3bc = 0x4792d6;
  iVar3 = (*(code *)ppppfVar12[0x15])();
  if (iVar3 < 0) {
    uStack_3bc = 0x54;
    piStack_3c0 = (int *)&DAT_0040d7a4;
    ppppfStack_3c4 = (float ****)pppppfVar6;
    ppppfStack_3cc = (float ****)0x4792ed;
    ppppfStack_3c8 = (float ****)iVar3;
    __vbaHresultCheckObj();
  }
  uStack_3bc = 0x4792fe;
  __vbaFreeStr();
  uStack_3bc = 1;
  ppppfStack_3c4 = (float ****)0x47930c;
  piStack_3c0 = piVar4;
  iVar3 = (**(code **)(*piVar4 + 0x114))();
  if (iVar3 < 0) {
    ppppfStack_3c4 = (float ****)0x114;
    ppppfStack_3c8 = (float ****)&DAT_0040d7a4;
    ppppfStack_3d4 = (float ****)0x479320;
    iStack_3d0 = iVar3;
    ppppfStack_3cc = (float ****)piVar4;
    __vbaHresultCheckObj();
  }
  if (DAT_0050b570 == (float *****)0x0) {
    ppppfStack_3c4 = (float ****)&DAT_0050b570;
    ppppfStack_3c8 = (float ****)&DAT_004048dc;
    ppppfStack_3cc = (float ****)0x479338;
    __vbaNew2();
  }
  ppppfStack_3c8 = (float ****)local_244;
  ppppfStack_3c4 = (float ****)DAT_0050b570;
  ppppfStack_3cc = (float ****)0x47934c;
  __vbaObjSetAddref();
  ppppfStack_3cc = local_244[0];
  iStack_3d0 = 0x47935b;
  iStack_3d0 = (*(code *)(*local_244[0])[0xbf])();
  ppppfStack_3d4 = (float ****)&local_58;
  uStack_3d8 = 0x479366;
  piVar4 = (int *)__vbaObjSet();
  uStack_3d8 = 0;
  ppppfStack_3e0 = (float ****)0x479372;
  piStack_3dc = piVar4;
  iVar3 = (**(code **)(*piVar4 + 0x9c))();
  if (iVar3 < 0) {
    ppppfStack_3e0 = (float ****)0x9c;
    ppppfStack_3e4 = (float ****)&DAT_0040c3dc;
    ppppfStack_3f0 = (float ****)0x479386;
    ppppfStack_3ec = (float ****)iVar3;
    ppppfStack_3e8 = (float ****)piVar4;
    __vbaHresultCheckObj();
  }
  ppppfStack_3e0 = (float ****)0x47938f;
  __vbaFreeObj();
  if (DAT_0050c53c == (float *****)0x0) {
    ppppfStack_3e0 = (float ****)&DAT_0050c53c;
    ppppfStack_3e4 = (float ****)&DAT_0040b420;
    ppppfStack_3e8 = (float ****)0x4793a7;
    __vbaNew2();
  }
  pppppfVar6 = DAT_0050c53c;
  ppppfStack_3e0 = (float ****)&local_58;
  ppppfStack_3e4 = (float ****)DAT_0050c53c;
  ppppfStack_3e8 = (float ****)0x4793b7;
  iVar3 = (*(code *)(*DAT_0050c53c)[6])();
  if (iVar3 < 0) {
    ppppfStack_3e8 = (float ****)0x18;
    ppppfStack_3ec = (float ****)&DAT_0040b410;
    ppppfStack_3f0 = (float ****)pppppfVar6;
    ppppfStack_3f8 = (float ****)0x4793c8;
    puStack_3f4 = (undefined *)iVar3;
    __vbaHresultCheckObj();
  }
  ppppfVar12 = local_58;
  ppppfStack_3e8 = (float ****)&local_218;
  ppppfStack_3ec = local_58;
  ppppfStack_3f0 = (float ****)0x4793dd;
  iVar3 = (*(code *)(*local_58)[0x26])();
  uVar17 = 0;
  if (iVar3 < 0) {
    ppppfStack_3f0 = (float ****)0x98;
    puStack_3f4 = &DAT_0040bb5c;
    ppppfStack_3f8 = ppppfVar12;
    ppppfStack_400 = (float ****)0x4793f1;
    ppppfStack_3fc = (float ****)iVar3;
    __vbaHresultCheckObj();
  }
  ppppfStack_3f0 = local_244[0];
  puStack_3f4 = (undefined *)0x479400;
  puStack_3f4 = (undefined *)(*(code *)(*local_244[0])[0xd4])();
  ppppfStack_3f8 = &local_5c;
  ppppfStack_3fc = (float ****)0x47940b;
  pppppfVar5 = (float *****)__vbaObjSet();
  ppppfStack_3fc = (float ****)(DAT_0050b024 * (float)_DAT_00401268 * (float)local_218);
  pppppfVar6 = (float *****)*pppppfVar5;
  if ((uVar17 & 0xd) == 0) {
    ppppfStack_404 = (float ****)0x479442;
    ppppfStack_400 = (float ****)pppppfVar5;
    ppppfStack_410 = (float ****)(*(code *)(*pppppfVar5)[0x21])();
    if ((int)ppppfStack_410 < 0) {
      ppppfStack_404 = (float ****)0x84;
      ppppfStack_408 = (float ****)&DAT_0040c908;
      ppppfStack_414 = (float ****)0x479456;
      ppppfStack_40c = (float ****)pppppfVar5;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = &local_5c;
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)0x2;
    ppppfStack_410 = (float ****)0x479466;
    __vbaFreeObjList();
    ppppfStack_404 = local_244[0];
    ppppfStack_408 = (float ****)0x479478;
    ppppfStack_408 = (float ****)(*(code *)(*local_244[0])[0xd4])();
    ppppfStack_40c = &local_5c;
    ppppfStack_410 = (float ****)0x479485;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_410 = local_244[0];
    ppppfStack_414 = (float ****)0x479496;
    ppppfStack_414 = (float ****)(*(code *)(*local_244[0])[0xd4])();
    ppppfStack_418 = (float ****)&local_58;
    ppppfStack_41c = (float ****)0x47949d;
    pppppfVar5 = (float *****)__vbaObjSet();
    ppppfStack_41c = (float ****)&local_218;
    ppppfStack_424 = (float ****)0x4794af;
    ppppfStack_420 = (float ****)pppppfVar5;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar5)[0x20])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_424 = (float ****)0x80;
      ppppfStack_428 = (float ****)&DAT_0040c908;
      ppppfStack_434 = (float ****)0x4794c3;
      ppppfStack_430 = (float ****)pppppfVar7;
      ppppfStack_42c = (float ****)pppppfVar5;
      __vbaHresultCheckObj();
    }
    ppppfStack_424 = local_218;
    ppppfStack_42c = (float ****)0x4794d3;
    ppppfStack_428 = (float ****)pppppfVar6;
    ppppfStack_438 = (float ****)(*(code *)(*pppppfVar6)[0x23])();
    if ((int)ppppfStack_438 < 0) {
      ppppfStack_42c = (float ****)0x8c;
      ppppfStack_430 = (float ****)&DAT_0040c908;
      ppppfStack_43c = (float ****)0x4794e7;
      ppppfStack_434 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_42c = &local_5c;
    ppppfStack_430 = (float ****)&local_58;
    ppppfStack_434 = (float ****)0x2;
    ppppfStack_438 = (float ****)0x4794f7;
    __vbaFreeObjList();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_42c = (float ****)&DAT_0050c53c;
      ppppfStack_430 = (float ****)&DAT_0040b420;
      ppppfStack_434 = (float ****)0x479513;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050c53c;
    ppppfStack_42c = (float ****)&local_58;
    ppppfStack_430 = (float ****)DAT_0050c53c;
    ppppfStack_434 = (float ****)0x479523;
    pppppfVar5 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)pppppfVar5 < 0) {
      ppppfStack_434 = (float ****)0x18;
      ppppfStack_438 = (float ****)&DAT_0040b410;
      ppppfStack_43c = (float ****)pppppfVar6;
      ppppfStack_444 = (float ****)0x479534;
      ppppfStack_440 = (float ****)pppppfVar5;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_58;
    ppppfStack_434 = (float ****)&local_218;
    ppppfStack_438 = local_58;
    ppppfStack_43c = (float ****)0x479549;
    pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
    uVar17 = 0;
    if ((int)pppppfVar6 < 0) {
      ppppfStack_43c = (float ****)0x98;
      ppppfStack_440 = (float ****)&DAT_0040bb5c;
      ppppfStack_444 = ppppfVar12;
      ppppfStack_44c = (float ****)0x47955d;
      ppppfStack_448 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_43c = local_244[0];
    ppppfStack_440 = (float ****)0x47956c;
    ppppfStack_440 = (float ****)(*(code *)(*local_244[0])[0xd4])();
    ppppfStack_444 = &local_5c;
    ppppfStack_448 = (float ****)0x479579;
    pppppfVar5 = (float *****)__vbaObjSet();
    ppppfStack_3fc = (float ****)(DAT_0050b024 * (float)_DAT_00401910 * (float)local_218);
    pppppfVar6 = (float *****)*pppppfVar5;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_404 = (float ****)0x4795ad;
    ppppfStack_400 = (float ****)pppppfVar5;
    ppppfStack_410 = (float ****)(*(code *)(*pppppfVar5)[0x1d])();
    if ((int)ppppfStack_410 < 0) {
      ppppfStack_404 = (float ****)0x74;
      ppppfStack_408 = (float ****)&DAT_0040c908;
      ppppfStack_414 = (float ****)0x4795be;
      ppppfStack_40c = (float ****)pppppfVar5;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = &local_5c;
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)0x2;
    ppppfStack_410 = (float ****)0x4795ce;
    __vbaFreeObjList();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_404 = (float ****)&DAT_0050c53c;
      ppppfStack_408 = (float ****)&DAT_0040b420;
      ppppfStack_40c = (float ****)0x4795ea;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050c53c;
    ppppfStack_404 = (float ****)&local_58;
    ppppfStack_408 = (float ****)DAT_0050c53c;
    ppppfStack_40c = (float ****)0x4795fa;
    pppppfVar5 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)pppppfVar5 < 0) {
      ppppfStack_40c = (float ****)0x18;
      ppppfStack_410 = (float ****)&DAT_0040b410;
      ppppfStack_414 = (float ****)pppppfVar6;
      ppppfStack_41c = (float ****)0x47960b;
      ppppfStack_418 = (float ****)pppppfVar5;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_58;
    ppppfStack_40c = (float ****)&local_218;
    ppppfStack_410 = local_58;
    ppppfStack_414 = (float ****)0x47961d;
    pppppfVar6 = (float *****)(*(code *)(*local_58)[0x14])();
    uVar17 = 0;
    if ((int)pppppfVar6 < 0) {
      ppppfStack_414 = (float ****)0x50;
      ppppfStack_418 = (float ****)&DAT_0040bb5c;
      ppppfStack_41c = ppppfVar12;
      ppppfStack_424 = (float ****)0x47962e;
      ppppfStack_420 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_414 = local_244[0];
    ppppfStack_418 = (float ****)0x47963d;
    ppppfStack_418 = (float ****)(*(code *)(*local_244[0])[0xd4])();
    ppppfStack_41c = &local_5c;
    ppppfStack_420 = (float ****)0x479644;
    pppppfVar5 = (float *****)__vbaObjSet();
    if (DAT_0050b000 == 0) {
      fVar18 = (float10)_DAT_00401d20 / (float10)(double)CONCAT44(DAT_0050b170,DAT_0050b16c);
    }
    else {
      ppppfStack_3fc = (float ****)DAT_0050b170;
      ppppfStack_3f8 = DAT_0050b16c;
      ppppfStack_404 = (float ****)0x47966c;
      pppppfVar5 = (float *****)adj_fdiv_m64();
      fVar18 = extraout_ST0;
    }
    pppppfVar6 = (float *****)*pppppfVar5;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_3fc =
         (float ****)(float)(fVar18 * (float10)_DAT_0050b028 * (float10)(float)local_218);
    ppppfStack_404 = (float ****)0x47969a;
    ppppfStack_400 = (float ****)pppppfVar5;
    ppppfStack_410 = (float ****)(*(code *)(*pppppfVar5)[0x1f])();
    if ((int)ppppfStack_410 < 0) {
      ppppfStack_404 = (float ****)0x7c;
      ppppfStack_408 = (float ****)&DAT_0040c908;
      ppppfStack_414 = (float ****)0x4796ab;
      ppppfStack_40c = (float ****)pppppfVar5;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = &local_5c;
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)0x2;
    ppppfStack_410 = (float ****)0x4796bb;
    __vbaFreeObjList();
    ppppfStack_404 = (float ****)&local_58;
    local_16c = (float ****)0x8;
    local_174 = (float ****)0x2;
    ppppfStack_408 = local_244[0];
    ppppfStack_40c = (float ****)0x4796e5;
    ppppfStack_418 = (float ****)(*(code *)(*local_244[0])[0x92])();
    if ((int)ppppfStack_418 < 0) {
      ppppfStack_40c = (float ****)0x248;
      ppppfStack_410 = (float ****)&DAT_0040d7a4;
      ppppfStack_414 = local_244[0];
      ppppfStack_41c = (float ****)0x4796ff;
      __vbaHresultCheckObj();
    }
    pppppfVar5 = (float *****)__vbaLateIdSt_exref;
    ppppfStack_41c = (float ****)0x2;
    ppppfStack_418 = local_174;
    ppppfStack_414 = local_170;
    ppppfStack_410 = local_16c;
    ppppfStack_40c = local_168;
    ppppfStack_420 = local_58;
    ppppfStack_424 = (float ****)0x479735;
    __vbaLateIdSt();
    ppppfStack_424 = (float ****)0x47973e;
    __vbaFreeObj();
    ppppfStack_424 = (float ****)&local_218;
    ppppfStack_428 = (float ****)0x4102d8;
    ppppfStack_42c = local_244[0];
    ppppfStack_430 = (float ****)0x479759;
    pppppfVar6 = (float *****)(*(code *)(*local_244[0])[0xba])();
    uVar17 = 0;
    if ((int)pppppfVar6 < 0) {
      ppppfStack_400 = (float ****)0x2e8;
      ppppfStack_404 = (float ****)&DAT_0040d7a4;
      ppppfStack_408 = local_244[0];
      ppppfStack_410 = (float ****)0x479773;
      ppppfStack_40c = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    pppppfVar6 = (float *****)ppppfStack_3fc;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_400 = (float ****)0x47978f;
    local_1c = __vbaFpI4();
    ppppfStack_400 = local_244[0];
    ppppfStack_404 = (float ****)0x4797a1;
    ppppfStack_404 = (float ****)(*(code *)(*local_244[0])[0xd3])();
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)0x4797ac;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_40c = (float ****)(float)local_1c;
    ppppfStack_414 = (float ****)0x4797c7;
    ppppfStack_410 = (float ****)pppppfVar6;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x21])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_414 = (float ****)0x84;
      ppppfStack_418 = (float ****)&DAT_0040bb6c;
      ppppfStack_424 = (float ****)0x4797db;
      ppppfStack_420 = (float ****)pppppfVar7;
      ppppfStack_41c = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_414 = (float ****)0x4797e4;
    __vbaFreeObj();
    ppppfStack_414 = local_244[0];
    ppppfStack_418 = (float ****)0x4797f3;
    ppppfStack_418 = (float ****)(*(code *)(*local_244[0])[0xd2])();
    ppppfStack_41c = (float ****)&local_58;
    ppppfStack_420 = (float ****)0x4797fe;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_420 = (float ****)(float)local_1c;
    ppppfStack_428 = (float ****)0x479819;
    ppppfStack_424 = (float ****)pppppfVar6;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x21])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_428 = (float ****)0x84;
      ppppfStack_42c = (float ****)&DAT_0040bb6c;
      ppppfStack_438 = (float ****)0x47982d;
      ppppfStack_434 = (float ****)pppppfVar7;
      ppppfStack_430 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_428 = (float ****)0x479836;
    __vbaFreeObj();
    ppppfStack_428 = local_244[0];
    ppppfStack_42c = (float ****)0x479845;
    ppppfStack_42c = (float ****)(*(code *)(*local_244[0])[0xd1])();
    ppppfStack_430 = (float ****)&local_58;
    ppppfStack_434 = (float ****)0x479850;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_434 = (float ****)(float)local_1c;
    ppppfStack_43c = (float ****)0x47986b;
    ppppfStack_438 = (float ****)pppppfVar6;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x21])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_43c = (float ****)0x84;
      ppppfStack_440 = (float ****)&DAT_0040bb6c;
      ppppfStack_44c = (float ****)0x47987f;
      ppppfStack_448 = (float ****)pppppfVar7;
      ppppfStack_444 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_43c = (float ****)0x479888;
    __vbaFreeObj();
    ppppfStack_43c = (float ****)&local_218;
    ppppfStack_440 = (float ****)0x4102d8;
    ppppfStack_444 = local_244[0];
    ppppfStack_448 = (float ****)0x4798a3;
    pppppfVar6 = (float *****)(*(code *)(*local_244[0])[0xba])();
    uVar17 = 0;
    if ((int)pppppfVar6 < 0) {
      ppppfStack_448 = (float ****)0x2e8;
      ppppfStack_44c = (float ****)&DAT_0040d7a4;
      ppppfStack_450 = local_244[0];
      ppppfStack_458 = (float ****)0x4798bd;
      ppppfStack_454 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_448 = local_244[0];
    ppppfStack_44c = (float ****)0x4798cc;
    ppppfStack_44c = (float ****)(*(code *)(*local_244[0])[0xd0])();
    ppppfStack_450 = (float ****)&local_58;
    ppppfStack_454 = (float ****)0x4798d7;
    pppppfVar7 = (float *****)__vbaObjSet();
    ppppfStack_3fc = (float ****)((float)local_218 + (float)local_218);
    pppppfVar6 = (float *****)*pppppfVar7;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_404 = (float ****)0x4798f8;
    ppppfStack_400 = (float ****)pppppfVar7;
    pppppfVar6 = (float *****)(*(code *)(*pppppfVar7)[0x23])();
    if ((int)pppppfVar6 < 0) {
      ppppfStack_404 = (float ****)0x8c;
      ppppfStack_408 = (float ****)&DAT_0040c3dc;
      ppppfStack_414 = (float ****)0x47990c;
      ppppfStack_410 = (float ****)pppppfVar6;
      ppppfStack_40c = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = (float ****)0x479915;
    __vbaFreeObj();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_404 = (float ****)&DAT_0050c53c;
      ppppfStack_408 = (float ****)&DAT_0040b420;
      ppppfStack_40c = (float ****)0x47992e;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050c53c;
    ppppfStack_404 = (float ****)&local_58;
    ppppfStack_408 = (float ****)DAT_0050c53c;
    ppppfStack_40c = (float ****)0x47993e;
    pppppfVar7 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_40c = (float ****)0x18;
      ppppfStack_410 = (float ****)&DAT_0040b410;
      ppppfStack_414 = (float ****)pppppfVar6;
      ppppfStack_41c = (float ****)0x47994f;
      ppppfStack_418 = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_58;
    ppppfStack_40c = (float ****)&local_218;
    ppppfStack_410 = local_58;
    ppppfStack_414 = (float ****)0x479964;
    pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
    if ((int)pppppfVar6 < 0) {
      ppppfStack_414 = (float ****)0x98;
      ppppfStack_418 = (float ****)&DAT_0040bb5c;
      ppppfStack_41c = ppppfVar12;
      ppppfStack_424 = (float ****)0x479978;
      ppppfStack_420 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_414 = local_244[0];
    ppppfStack_418 = (float ****)0x479987;
    ppppfStack_418 = (float ****)(*(code *)(*local_244[0])[0xd0])();
    ppppfStack_41c = &local_5c;
    ppppfStack_420 = (float ****)0x479992;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_420 = &local_21c;
    ppppfStack_428 = (float ****)0x4799a4;
    ppppfStack_424 = (float ****)pppppfVar6;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
    uVar17 = 0;
    if ((int)pppppfVar7 < 0) {
      ppppfStack_428 = (float ****)0x80;
      ppppfStack_42c = (float ****)&DAT_0040c3dc;
      ppppfStack_438 = (float ****)0x4799b8;
      ppppfStack_434 = (float ****)pppppfVar7;
      ppppfStack_430 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_428 = local_244[0];
    ppppfStack_42c = (float ****)0x4799c7;
    ppppfStack_42c = (float ****)(*(code *)(*local_244[0])[0xd0])();
    ppppfStack_430 = &local_60;
    ppppfStack_434 = (float ****)0x4799d2;
    pppppfVar7 = (float *****)__vbaObjSet();
    ppppfStack_3fc =
         (float ****)
         (((float)local_218 * (float)_DAT_00401d08 - (float)local_21c * (float)_DAT_00401268) *
         DAT_0050b024);
    pppppfVar6 = (float *****)*pppppfVar7;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_404 = (float ****)0x479a14;
    ppppfStack_400 = (float ****)pppppfVar7;
    ppppfStack_410 = (float ****)(*(code *)(*pppppfVar7)[0x1d])();
    if ((int)ppppfStack_410 < 0) {
      ppppfStack_404 = (float ****)0x74;
      ppppfStack_408 = (float ****)&DAT_0040c3dc;
      ppppfStack_414 = (float ****)0x479a25;
      ppppfStack_40c = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = &local_60;
    ppppfStack_408 = &local_5c;
    ppppfStack_40c = (float ****)&local_58;
    ppppfStack_410 = (float ****)0x3;
    ppppfStack_414 = (float ****)0x479a39;
    __vbaFreeObjList();
    ppppfStack_404 = local_244[0];
    ppppfStack_408 = (float ****)0x479a4b;
    ppppfStack_408 = (float ****)(*(code *)(*local_244[0])[0xd0])();
    ppppfStack_40c = &local_5c;
    ppppfStack_410 = (float ****)0x479a56;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_410 = &local_21c;
    ppppfStack_418 = (float ****)0x479a68;
    ppppfStack_414 = (float ****)pppppfVar6;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_418 = (float ****)0x88;
      ppppfStack_41c = (float ****)&DAT_0040c3dc;
      ppppfStack_428 = (float ****)0x479a7c;
      ppppfStack_424 = (float ****)pppppfVar7;
      ppppfStack_420 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_418 = local_244[0];
    ppppfStack_41c = (float ****)0x479a8b;
    ppppfStack_41c = (float ****)(*(code *)(*local_244[0])[0xd0])();
    ppppfStack_420 = &local_60;
    ppppfStack_424 = (float ****)0x479a98;
    pppppfVar7 = (float *****)__vbaObjSet();
    ppppfStack_424 = local_244[0];
    ppppfStack_428 = (float ****)0x479aa9;
    ppppfStack_428 = (float ****)(*(code *)(*local_244[0])[0xd4])();
    ppppfStack_42c = (float ****)&local_58;
    ppppfStack_430 = (float ****)0x479ab0;
    pppppfVar8 = (float *****)__vbaObjSet();
    ppppfStack_430 = (float ****)&local_218;
    ppppfStack_438 = (float ****)0x479abf;
    ppppfStack_434 = (float ****)pppppfVar8;
    pppppfVar9 = (float *****)(*(code *)(*pppppfVar8)[0x1e])();
    uVar17 = 0;
    pppppfVar6 = extraout_ECX;
    if ((int)pppppfVar9 < 0) {
      ppppfStack_3fc = (float ****)0x78;
      ppppfStack_400 = (float ****)&DAT_0040c908;
      ppppfStack_40c = (float ****)0x479ad4;
      ppppfStack_408 = (float ****)pppppfVar9;
      ppppfStack_404 = (float ****)pppppfVar8;
      __vbaHresultCheckObj();
      pppppfVar6 = extraout_ECX_00;
    }
    ppppfStack_3fc = (float ****)((float)local_218 - (float)local_21c);
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_404 = (float ****)0x479af4;
    ppppfStack_400 = (float ****)pppppfVar7;
    ppppfStack_410 = (float ****)(*(code *)(*pppppfVar7)[0x1f])();
    if ((int)ppppfStack_410 < 0) {
      ppppfStack_404 = (float ****)0x7c;
      ppppfStack_408 = (float ****)&DAT_0040c3dc;
      ppppfStack_414 = (float ****)0x479b09;
      ppppfStack_40c = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = &local_60;
    ppppfStack_408 = &local_5c;
    ppppfStack_40c = (float ****)&local_58;
    ppppfStack_410 = (float ****)0x3;
    ppppfStack_414 = (float ****)0x479b1d;
    __vbaFreeObjList();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_404 = (float ****)&DAT_0050c53c;
      ppppfStack_408 = (float ****)&DAT_0040b420;
      ppppfStack_40c = (float ****)0x479b39;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050c53c;
    ppppfStack_404 = (float ****)&local_58;
    ppppfStack_408 = (float ****)DAT_0050c53c;
    ppppfStack_40c = (float ****)0x479b49;
    pppppfVar7 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_40c = (float ****)0x18;
      ppppfStack_410 = (float ****)&DAT_0040b410;
      ppppfStack_414 = (float ****)pppppfVar6;
      ppppfStack_41c = (float ****)0x479b60;
      ppppfStack_418 = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_58;
    ppppfStack_40c = (float ****)&local_218;
    ppppfStack_410 = local_58;
    ppppfStack_414 = (float ****)0x479b7d;
    pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
    if ((int)pppppfVar6 < 0) {
      ppppfStack_414 = (float ****)0x98;
      ppppfStack_418 = (float ****)&DAT_0040bb5c;
      ppppfStack_41c = ppppfVar12;
      ppppfStack_424 = (float ****)0x479b91;
      ppppfStack_420 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_414 = local_244[0];
    ppppfStack_418 = (float ****)0x479ba0;
    ppppfStack_418 = (float ****)(*(code *)(*local_244[0])[0xcb])();
    ppppfStack_41c = &local_5c;
    ppppfStack_420 = (float ****)0x479bab;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_420 = &local_21c;
    ppppfStack_428 = (float ****)0x479bbd;
    ppppfStack_424 = (float ****)pppppfVar6;
    pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
    uVar17 = 0;
    if ((int)pppppfVar7 < 0) {
      ppppfStack_428 = (float ****)0x80;
      ppppfStack_42c = (float ****)&DAT_0040c3dc;
      ppppfStack_438 = (float ****)0x479bd1;
      ppppfStack_434 = (float ****)pppppfVar7;
      ppppfStack_430 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_428 = local_244[0];
    ppppfStack_42c = (float ****)0x479be0;
    ppppfStack_42c = (float ****)(*(code *)(*local_244[0])[0xcb])();
    ppppfStack_430 = &local_60;
    ppppfStack_434 = (float ****)0x479beb;
    pppppfVar7 = (float *****)__vbaObjSet();
    pppppfVar6 = (float *****)ppppfStack_3fc;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_3fc =
         (float ****)(DAT_0050b024 * (float)_DAT_00401268 * ((float)local_218 - (float)local_21c));
    pppppfVar6 = (float *****)*pppppfVar7;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_408 = (float ****)0x479c31;
    ppppfStack_404 = (float ****)pppppfVar7;
    ppppfStack_414 = (float ****)(*(code *)(*pppppfVar7)[0x1d])();
    if ((int)ppppfStack_414 < 0) {
      ppppfStack_408 = (float ****)0x74;
      ppppfStack_40c = (float ****)&DAT_0040c3dc;
      ppppfStack_418 = (float ****)0x479c42;
      ppppfStack_410 = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfStack_408 = &local_60;
    ppppfStack_40c = &local_5c;
    ppppfStack_410 = (float ****)&local_58;
    ppppfStack_414 = (float ****)0x3;
    ppppfStack_418 = (float ****)0x479c56;
    __vbaFreeObjList();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_408 = (float ****)&DAT_0050c53c;
      ppppfStack_40c = (float ****)&DAT_0040b420;
      ppppfStack_410 = (float ****)0x479c72;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050c53c;
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)DAT_0050c53c;
    ppppfStack_410 = (float ****)0x479c82;
    pppppfVar7 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)pppppfVar7 < 0) {
      ppppfStack_410 = (float ****)0x18;
      ppppfStack_414 = (float ****)&DAT_0040b410;
      ppppfStack_418 = (float ****)pppppfVar6;
      ppppfStack_420 = (float ****)0x479c93;
      ppppfStack_41c = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_58;
    ppppfStack_410 = (float ****)&local_218;
    ppppfStack_414 = local_58;
    ppppfStack_418 = (float ****)0x479ca5;
    pppppfVar6 = (float *****)(*(code *)(*local_58)[0x14])();
    uVar17 = 0;
    if ((int)pppppfVar6 < 0) {
      ppppfStack_418 = (float ****)0x50;
      ppppfStack_41c = (float ****)&DAT_0040bb5c;
      ppppfStack_420 = ppppfVar12;
      ppppfStack_428 = (float ****)0x479cb6;
      ppppfStack_424 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_418 = local_244[0];
    ppppfStack_41c = (float ****)0x479cc5;
    ppppfStack_41c = (float ****)(*(code *)(*local_244[0])[0xcb])();
    ppppfStack_420 = &local_5c;
    ppppfStack_424 = (float ****)0x479cd0;
    pppppfVar7 = (float *****)__vbaObjSet();
    ppppfStack_3fc = (float ****)(_DAT_0050b028 * (float)_DAT_00401fc0 * (float)local_218);
    pppppfVar6 = (float *****)*pppppfVar7;
    if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
    ppppfStack_404 = (float ****)0x479d04;
    ppppfStack_400 = (float ****)pppppfVar7;
    ppppfStack_410 = (float ****)(*(code *)(*pppppfVar7)[0x1f])();
    if ((int)ppppfStack_410 < 0) {
      ppppfStack_404 = (float ****)0x7c;
      ppppfStack_408 = (float ****)&DAT_0040c3dc;
      ppppfStack_414 = (float ****)0x479d15;
      ppppfStack_40c = (float ****)pppppfVar7;
      __vbaHresultCheckObj();
    }
    ppppfStack_404 = &local_5c;
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)0x2;
    ppppfStack_410 = (float ****)0x479d25;
    __vbaFreeObjList();
    ppppfStack_408 = (float ****)local_244;
    ppppfStack_404 = (float ****)0x0;
    ppppfStack_40c = (float ****)0x479d37;
    __vbaObjSetAddref();
    if (DAT_0050b238 != 3) {
      if (DAT_0050b238 == 8) {
        if ((DAT_0050b3bc == (float ****)0x0) || (*(short *)DAT_0050b3bc != 1)) {
          ppppfStack_40c = (float ****)0x479d93;
          __vbaGenerateBoundsError();
        }
        else if (DAT_0050b3bc[4] <= (float ***)-(int)DAT_0050b3bc[5]) {
          ppppfStack_40c = (float ****)0x479d7c;
          __vbaGenerateBoundsError();
        }
        ppppfStack_40c = (float ****)0x479da9;
        __vbaStrCopy();
        if ((DAT_0050b3bc == (float ****)0x0) || (*(short *)DAT_0050b3bc != 1)) {
          ppppfStack_40c = (float ****)0x479ddd;
          __vbaGenerateBoundsError();
        }
        else if (DAT_0050b3bc[4] <= (float ***)(1 - (int)DAT_0050b3bc[5])) {
          ppppfStack_40c = (float ****)0x479dcc;
          __vbaGenerateBoundsError();
        }
        ppppfStack_40c = (float ****)0x479df3;
        __vbaStrCopy();
        if ((DAT_0050b3bc == (float ****)0x0) || (*(short *)DAT_0050b3bc != 1)) {
          ppppfStack_40c = (float ****)0x479e27;
          __vbaGenerateBoundsError();
        }
        else if (DAT_0050b3bc[4] <= (float ***)(2 - (int)DAT_0050b3bc[5])) {
          ppppfStack_40c = (float ****)0x479e16;
          __vbaGenerateBoundsError();
        }
        ppppfStack_40c = (float ****)0x479e3d;
        __vbaStrCopy();
        if ((DAT_0050b3bc == (float ****)0x0) || (*(short *)DAT_0050b3bc != 1)) {
          ppppfStack_40c = (float ****)0x479e71;
          __vbaGenerateBoundsError();
        }
        else if (DAT_0050b3bc[4] <= (float ***)(3 - (int)DAT_0050b3bc[5])) {
          ppppfStack_40c = (float ****)0x479e60;
          __vbaGenerateBoundsError();
        }
        ppppfStack_40c = (float ****)0x479e87;
        __vbaStrCopy();
        if ((DAT_0050b3bc == (float ****)0x0) || (*(short *)DAT_0050b3bc != 1)) {
          ppppfStack_40c = (float ****)0x479ebb;
          __vbaGenerateBoundsError();
        }
        else if (DAT_0050b3bc[4] <= (float ***)(4 - (int)DAT_0050b3bc[5])) {
          ppppfStack_40c = (float ****)0x479eaa;
          __vbaGenerateBoundsError();
        }
        ppppfStack_40c = (float ****)0x479ed1;
        __vbaStrCopy();
        if ((DAT_0050b3bc == (float ****)0x0) || (*(short *)DAT_0050b3bc != 1)) {
          ppppfStack_40c = (float ****)0x479f05;
          __vbaGenerateBoundsError();
        }
        else if (DAT_0050b3bc[4] <= (float ***)(5 - (int)DAT_0050b3bc[5])) {
          ppppfStack_40c = (float ****)0x479ef4;
          __vbaGenerateBoundsError();
        }
        ppppfStack_40c = (float ****)0x479f1b;
        __vbaStrCopy();
        if (DAT_0050b570 == (float *****)0x0) {
          ppppfStack_40c = (float ****)&DAT_0050b570;
          ppppfStack_410 = (float ****)&DAT_004048dc;
          ppppfStack_414 = (float ****)0x479f34;
          __vbaNew2();
        }
        ppppfStack_40c = (float ****)DAT_0050b570;
        ppppfStack_410 = (float ****)0x479f42;
        ppppfStack_410 = (float ****)(*(code *)(*DAT_0050b570)[0xc3])();
        ppppfStack_414 = (float ****)&local_58;
        ppppfStack_418 = (float ****)0x479f4d;
        pppppfVar6 = (float *****)__vbaObjSet();
        ppppfStack_418 = (float ****)0xffffffff;
        ppppfStack_420 = (float ****)0x479f5a;
        ppppfStack_41c = (float ****)pppppfVar6;
        pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x27])();
        if ((int)pppppfVar7 < 0) {
          ppppfStack_420 = (float ****)0x9c;
          ppppfStack_424 = (float ****)&DAT_0040c3dc;
          ppppfStack_430 = (float ****)0x479f72;
          ppppfStack_42c = (float ****)pppppfVar7;
          ppppfStack_428 = (float ****)pppppfVar6;
          __vbaHresultCheckObj();
        }
        ppppfStack_420 = (float ****)0x479f7d;
        __vbaFreeObj();
        if (DAT_0050b570 == (float *****)0x0) {
          ppppfStack_420 = (float ****)&DAT_0050b570;
          ppppfStack_424 = (float ****)&DAT_004048dc;
          ppppfStack_428 = (float ****)0x479f96;
          __vbaNew2();
        }
        ppppfStack_420 = (float ****)DAT_0050b570;
        ppppfStack_424 = (float ****)0x479fa4;
        ppppfStack_424 = (float ****)(*(code *)(*DAT_0050b570)[0xd7])();
        ppppfStack_428 = (float ****)&local_250;
        ppppfStack_42c = (float ****)0x479fb2;
        __vbaObjSet();
        if (DAT_0050b570 == (float *****)0x0) {
          ppppfStack_42c = (float ****)&DAT_0050b570;
          ppppfStack_430 = (float ****)&DAT_004048dc;
          ppppfStack_434 = (float ****)0x479fcb;
          __vbaNew2();
        }
        ppppfStack_42c = (float ****)DAT_0050b570;
        ppppfStack_430 = (float ****)0x479fd9;
        ppppfStack_430 = (float ****)(*(code *)(*DAT_0050b570)[0xcf])();
        ppppfStack_434 = (float ****)&local_58;
        ppppfStack_438 = (float ****)0x479fe4;
        pppppfVar6 = (float *****)__vbaObjSet();
        ppppfStack_438 = (float ****)0x0;
        ppppfStack_440 = (float ****)0x479ff1;
        ppppfStack_43c = (float ****)pppppfVar6;
        pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x25])();
        if ((int)pppppfVar7 < 0) {
          ppppfStack_440 = (float ****)0x94;
          ppppfStack_444 = (float ****)&DAT_0040c8f8;
          ppppfStack_450 = (float ****)0x47a009;
          ppppfStack_44c = (float ****)pppppfVar7;
          ppppfStack_448 = (float ****)pppppfVar6;
          __vbaHresultCheckObj();
        }
        ppppfStack_440 = (float ****)0x47a00e;
        __vbaFreeObj();
        local_174 = (float ****)0xb;
        ppppfStack_450 = (float ****)0x80010007;
        ppppfStack_44c = (float ****)0xb;
        local_16c = (float ****)0xffffffff;
        ppppfStack_448 = local_170;
        ppppfStack_454 = local_250;
        ppppfStack_444 = (float ****)0xffffffff;
        ppppfStack_440 = local_168;
        ppppfStack_458 = (float ****)0x47a04c;
        __vbaLateIdSt();
        local_174 = (float ****)0x3;
        ppppfStack_468 = (float ****)0x6;
        ppppfStack_464 = (float ****)0x3;
        local_16c = (float ****)0x1;
        ppppfStack_460 = local_170;
        ppppfStack_46c = local_250;
        ppppfStack_45c = (float ****)&DAT_00000001;
        ppppfStack_458 = local_168;
        ppppfStack_470 = (float ****)0x47a089;
        __vbaLateIdSt();
        local_174 = (float ****)0x3;
        ppppfStack_480 = (float ****)0x7;
        ppppfStack_47c = (float ****)0x3;
        local_16c = (float ****)0x1;
        ppppfStack_478 = local_170;
        ppppfStack_484 = local_250;
        ppppfStack_474 = (float ****)&DAT_00000001;
        ppppfStack_470 = local_168;
        ppppfStack_488 = (float ****)0x47a0c6;
        __vbaLateIdSt();
        if (DAT_0050b570 == (float *****)0x0) {
          ppppfStack_488 = (float ****)&DAT_0050b570;
          ppppfStack_48c = (float ****)&DAT_004048dc;
          ppppfStack_490 = (float ****)0x47a0df;
          __vbaNew2();
        }
        ppppfStack_488 = (float ****)DAT_0050b570;
        ppppfStack_48c = (float ****)0x47a0ed;
        ppppfStack_48c = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
        ppppfStack_490 = (float ****)&local_58;
        ppppfStack_494 = (float ****)0x47a0f8;
        pppppfVar6 = (float *****)__vbaObjSet();
        ppppfStack_494 = (float ****)&local_218;
        pppfStack_49c = (float ***)0x47a107;
        ppppfStack_498 = (float ****)pppppfVar6;
        pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x1c])();
        uVar17 = 0;
        if ((int)pppppfVar7 < 0) {
          ppppfStack_400 = (float ****)0x70;
          ppppfStack_404 = (float ****)&DAT_0040c908;
          ppppfStack_410 = (float ****)0x47a11c;
          ppppfStack_40c = (float ****)pppppfVar7;
          ppppfStack_408 = (float ****)pppppfVar6;
          __vbaHresultCheckObj();
        }
        local_16c = (float ****)((float)local_218 * (float)_DAT_00401fb8);
        pppppfVar6 = (float *****)ppppfStack_3fc;
        if ((uVar17 & 0xd) == 0) {
          local_174 = (float ****)0x4;
          ppppfStack_410 = (float ****)0x80010005;
          ppppfStack_40c = (float ****)0x4;
          ppppfStack_408 = local_170;
          ppppfStack_414 = local_250;
          ppppfStack_400 = local_168;
          ppppfStack_418 = (float ****)0x47a173;
          ppppfStack_404 = local_16c;
          __vbaLateIdSt();
          ppppfStack_418 = (float ****)0x47a178;
          __vbaFreeObj();
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_418 = (float ****)&DAT_0050b570;
            ppppfStack_41c = (float ****)&DAT_004048dc;
            ppppfStack_420 = (float ****)0x47a191;
            __vbaNew2();
          }
          ppppfStack_418 = (float ****)DAT_0050b570;
          ppppfStack_41c = (float ****)0x47a19f;
          ppppfStack_41c = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
          ppppfStack_420 = (float ****)&local_58;
          ppppfStack_424 = (float ****)0x47a1aa;
          pppppfVar6 = (float *****)__vbaObjSet();
          ppppfStack_424 = (float ****)&local_218;
          ppppfStack_42c = (float ****)0x47a1b9;
          ppppfStack_428 = (float ****)pppppfVar6;
          pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x1c])();
          uVar17 = 0;
          if ((int)pppppfVar7 < 0) {
            ppppfStack_400 = (float ****)0x70;
            ppppfStack_404 = (float ****)&DAT_0040c908;
            ppppfStack_410 = (float ****)0x47a1ce;
            ppppfStack_40c = (float ****)pppppfVar7;
            ppppfStack_408 = (float ****)pppppfVar6;
            __vbaHresultCheckObj();
          }
          local_16c = (float ****)((float)local_218 * (float)_DAT_00401e88);
          pppppfVar6 = (float *****)ppppfStack_3fc;
          if ((uVar17 & 0xd) == 0) {
            local_174 = (float ****)0x4;
            ppppfStack_410 = (float ****)0x80010003;
            ppppfStack_40c = (float ****)0x4;
            ppppfStack_408 = local_170;
            ppppfStack_414 = local_250;
            ppppfStack_400 = local_168;
            ppppfStack_418 = (float ****)0x47a225;
            ppppfStack_404 = local_16c;
            __vbaLateIdSt();
            ppppfStack_418 = (float ****)0x47a22a;
            __vbaFreeObj();
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_418 = (float ****)&DAT_0050b570;
              ppppfStack_41c = (float ****)&DAT_004048dc;
              ppppfStack_420 = (float ****)0x47a243;
              __vbaNew2();
            }
            ppppfStack_418 = (float ****)DAT_0050b570;
            ppppfStack_41c = (float ****)0x47a251;
            ppppfStack_41c = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
            ppppfStack_420 = (float ****)&local_58;
            ppppfStack_424 = (float ****)0x47a25c;
            pppppfVar6 = (float *****)__vbaObjSet();
            ppppfStack_424 = (float ****)&local_218;
            ppppfStack_42c = (float ****)0x47a26b;
            ppppfStack_428 = (float ****)pppppfVar6;
            ppppfStack_438 = (float ****)(*(code *)(*pppppfVar6)[0x1e])();
            if ((int)ppppfStack_438 < 0) {
              ppppfStack_42c = (float ****)0x78;
              ppppfStack_430 = (float ****)&DAT_0040c908;
              ppppfStack_43c = (float ****)0x47a280;
              ppppfStack_434 = (float ****)pppppfVar6;
              __vbaHresultCheckObj();
            }
            local_174 = (float ****)0x4;
            local_16c = local_218;
            ppppfStack_438 = (float ****)0x4;
            ppppfStack_43c = (float ****)0x80010004;
            ppppfStack_434 = local_170;
            ppppfStack_440 = local_250;
            ppppfStack_430 = local_218;
            ppppfStack_42c = local_168;
            ppppfStack_444 = (float ****)0x47a2c1;
            __vbaLateIdSt();
            ppppfStack_444 = (float ****)0x47a2c6;
            __vbaFreeObj();
            ppppfStack_444 = (float ****)0x47a2d6;
            __vbaStrCopy();
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_444 = (float ****)&DAT_0050b570;
              ppppfStack_448 = (float ****)&DAT_004048dc;
              ppppfStack_44c = (float ****)0x47a2ef;
              __vbaNew2();
            }
            pppppfVar6 = DAT_0050b570;
            ppppfStack_444 = (float ****)&local_218;
            ppppfStack_448 = (float ****)DAT_0050b34c;
            ppppfStack_44c = (float ****)DAT_0050b570;
            ppppfStack_450 = (float ****)0x47a30c;
            pppppfVar7 = (float *****)(*(code *)(*DAT_0050b570)[0xb9])();
            uVar17 = 0;
            if ((int)pppppfVar7 < 0) {
              ppppfStack_450 = (float ****)0x2e4;
              ppppfStack_454 = (float ****)&DAT_0040d7a4;
              ppppfStack_458 = (float ****)pppppfVar6;
              ppppfStack_460 = (float ****)0x47a324;
              ppppfStack_45c = (float ****)pppppfVar7;
              __vbaHresultCheckObj();
            }
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_450 = (float ****)&DAT_0050b570;
              ppppfStack_454 = (float ****)&DAT_004048dc;
              ppppfStack_458 = (float ****)0x47a33d;
              __vbaNew2();
            }
            ppppfStack_450 = (float ****)DAT_0050b570;
            ppppfStack_454 = (float ****)0x47a34b;
            ppppfStack_454 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
            ppppfStack_458 = (float ****)&local_58;
            ppppfStack_45c = (float ****)0x47a356;
            pppppfVar7 = (float *****)__vbaObjSet();
            pppppfVar6 = (float *****)ppppfStack_3fc;
            if ((uVar17 & 0xd) == 0) {
              ppppfStack_408 = (float ****)0x47a387;
              ppppfStack_404 = (float ****)pppppfVar7;
              ppppfStack_400 = (float ****)((float)local_218 * (float)_DAT_00401418);
              pppppfVar6 = (float *****)(*(code *)(*pppppfVar7)[0x21])();
              if ((int)pppppfVar6 < 0) {
                ppppfStack_408 = (float ****)0x84;
                ppppfStack_40c = (float ****)&DAT_0040ba5c;
                ppppfStack_418 = (float ****)0x47a39f;
                ppppfStack_414 = (float ****)pppppfVar6;
                ppppfStack_410 = (float ****)pppppfVar7;
                __vbaHresultCheckObj();
              }
              ppppfStack_408 = (float ****)0x47a3a4;
              __vbaFreeObj();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_408 = (float ****)&DAT_0050b570;
                ppppfStack_40c = (float ****)&DAT_004048dc;
                ppppfStack_410 = (float ****)0x47a3bd;
                __vbaNew2();
              }
              ppppfStack_408 = (float ****)DAT_0050b570;
              ppppfStack_40c = (float ****)0x47a3cb;
              ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd0])();
              ppppfStack_410 = (float ****)&local_58;
              ppppfStack_414 = (float ****)0x47a3d8;
              pppppfVar6 = (float *****)__vbaObjSet();
              ppppfStack_414 = (float ****)&local_218;
              ppppfStack_41c = (float ****)0x47a3e7;
              ppppfStack_418 = (float ****)pppppfVar6;
              pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
              uVar17 = 0;
              if ((int)pppppfVar7 < 0) {
                ppppfStack_41c = (float ****)0x78;
                ppppfStack_420 = (float ****)&DAT_0040c3dc;
                ppppfStack_42c = (float ****)0x47a3fc;
                ppppfStack_428 = (float ****)pppppfVar7;
                ppppfStack_424 = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_41c = (float ****)&DAT_0050b570;
                ppppfStack_420 = (float ****)&DAT_004048dc;
                ppppfStack_424 = (float ****)0x47a415;
                __vbaNew2();
              }
              ppppfStack_41c = (float ****)DAT_0050b570;
              ppppfStack_420 = (float ****)0x47a423;
              ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
              ppppfStack_424 = &local_5c;
              ppppfStack_428 = (float ****)0x47a42a;
              pppppfVar7 = (float *****)__vbaObjSet();
              ppppfVar12 = *pppppfVar7;
              pppppfVar6 = (float *****)ppppfStack_3fc;
              if ((uVar17 & 0xd) == 0) {
                ppppfStack_400 = (float ****)0x47a44a;
                iVar3 = __vbaFpI4();
                ppppfStack_400 = (float ****)(float)(iVar3 / 2);
                ppppfStack_408 = (float ****)0x47a46c;
                ppppfStack_404 = (float ****)pppppfVar7;
                ppppfStack_414 = (float ****)(*(code *)ppppfVar12[0x1f])();
                if ((int)ppppfStack_414 < 0) {
                  ppppfStack_408 = (float ****)0x7c;
                  ppppfStack_40c = (float ****)&DAT_0040ba5c;
                  ppppfStack_418 = (float ****)0x47a481;
                  ppppfStack_410 = (float ****)pppppfVar7;
                  __vbaHresultCheckObj();
                }
                ppppfStack_408 = &local_5c;
                ppppfStack_40c = (float ****)&local_58;
                ppppfStack_410 = (float ****)0x2;
                ppppfStack_414 = (float ****)0x47a491;
                __vbaFreeObjList();
                if (DAT_0050b570 == (float *****)0x0) {
                  ppppfStack_408 = (float ****)&DAT_0050b570;
                  ppppfStack_40c = (float ****)&DAT_004048dc;
                  ppppfStack_410 = (float ****)0x47a4ad;
                  __vbaNew2();
                }
                ppppfStack_408 = (float ****)DAT_0050b570;
                ppppfStack_40c = (float ****)0x47a4bb;
                ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                ppppfStack_410 = &local_5c;
                ppppfStack_414 = (float ****)0x47a4c6;
                pppppfVar6 = (float *****)__vbaObjSet();
                ppppfStack_414 = &local_21c;
                ppppfStack_41c = (float ****)0x47a4d8;
                ppppfStack_418 = (float ****)pppppfVar6;
                pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
                if ((int)pppppfVar7 < 0) {
                  ppppfStack_41c = (float ****)0x80;
                  ppppfStack_420 = (float ****)&DAT_0040ba5c;
                  ppppfStack_42c = (float ****)0x47a4f0;
                  ppppfStack_428 = (float ****)pppppfVar7;
                  ppppfStack_424 = (float ****)pppppfVar6;
                  __vbaHresultCheckObj();
                }
                if (DAT_0050b570 == (float *****)0x0) {
                  ppppfStack_41c = (float ****)&DAT_0050b570;
                  ppppfStack_420 = (float ****)&DAT_004048dc;
                  ppppfStack_424 = (float ****)0x47a509;
                  __vbaNew2();
                }
                ppppfStack_41c = (float ****)DAT_0050b570;
                ppppfStack_420 = (float ****)0x47a517;
                ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                ppppfStack_424 = &local_60;
                ppppfStack_428 = (float ****)0x47a522;
                pppppfVar7 = (float *****)__vbaObjSet();
                if (DAT_0050c53c == (float *****)0x0) {
                  ppppfStack_428 = (float ****)&DAT_0050c53c;
                  ppppfStack_42c = (float ****)&DAT_0040b420;
                  ppppfStack_430 = (float ****)0x47a53d;
                  __vbaNew2();
                }
                pppppfVar6 = DAT_0050c53c;
                ppppfStack_428 = (float ****)&local_58;
                ppppfStack_42c = (float ****)DAT_0050c53c;
                ppppfStack_430 = (float ****)0x47a54d;
                pppppfVar8 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
                if ((int)pppppfVar8 < 0) {
                  ppppfStack_430 = (float ****)0x18;
                  ppppfStack_434 = (float ****)&DAT_0040b410;
                  ppppfStack_438 = (float ****)pppppfVar6;
                  ppppfStack_440 = (float ****)0x47a562;
                  ppppfStack_43c = (float ****)pppppfVar8;
                  __vbaHresultCheckObj();
                }
                ppppfVar12 = local_58;
                ppppfStack_430 = (float ****)&local_218;
                ppppfStack_434 = local_58;
                ppppfStack_438 = (float ****)0x47a577;
                pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
                uVar17 = 0;
                if ((int)pppppfVar6 < 0) {
                  ppppfStack_400 = (float ****)0x98;
                  ppppfStack_404 = (float ****)&DAT_0040bb5c;
                  ppppfStack_408 = ppppfVar12;
                  ppppfStack_410 = (float ****)0x47a58f;
                  ppppfStack_40c = (float ****)pppppfVar6;
                  __vbaHresultCheckObj();
                }
                ppppfVar12 = *pppppfVar7;
                pppppfVar6 = (float *****)ppppfStack_3fc;
                if ((uVar17 & 0xd) == 0) {
                  ppppfStack_400 = (float ****)0x47a5ad;
                  iVar3 = __vbaFpI4();
                  ppppfStack_400 = (float ****)(float)(iVar3 / 2);
                  ppppfStack_408 = (float ****)0x47a5cf;
                  ppppfStack_404 = (float ****)pppppfVar7;
                  ppppfStack_414 = (float ****)(*(code *)ppppfVar12[0x1d])();
                  if ((int)ppppfStack_414 < 0) {
                    ppppfStack_408 = (float ****)0x74;
                    ppppfStack_40c = (float ****)&DAT_0040ba5c;
                    ppppfStack_418 = (float ****)0x47a5e4;
                    ppppfStack_410 = (float ****)pppppfVar7;
                    __vbaHresultCheckObj();
                  }
                  ppppfStack_408 = &local_60;
                  ppppfStack_40c = &local_5c;
                  ppppfStack_410 = (float ****)&local_58;
                  ppppfStack_414 = (float ****)0x3;
                  ppppfStack_418 = (float ****)0x47a5f8;
                  __vbaFreeObjList();
                  if (DAT_0050b570 == (float *****)0x0) {
                    ppppfStack_408 = (float ****)&DAT_0050b570;
                    ppppfStack_40c = (float ****)&DAT_004048dc;
                    ppppfStack_410 = (float ****)0x47a614;
                    __vbaNew2();
                  }
                  ppppfStack_408 = (float ****)DAT_0050b570;
                  ppppfStack_40c = (float ****)0x47a622;
                  ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                  ppppfStack_410 = (float ****)&local_58;
                  ppppfStack_414 = (float ****)0x47a62d;
                  pppppfVar6 = (float *****)__vbaObjSet();
                  ppppfStack_414 = (float ****)DAT_0050b34c;
                  ppppfStack_41c = (float ****)0x47a63c;
                  ppppfStack_418 = (float ****)pppppfVar6;
                  pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
                  if ((int)pppppfVar7 < 0) {
                    ppppfStack_41c = (float ****)0x54;
                    ppppfStack_420 = (float ****)&DAT_0040ba5c;
                    ppppfStack_42c = (float ****)0x47a651;
                    ppppfStack_428 = (float ****)pppppfVar7;
                    ppppfStack_424 = (float ****)pppppfVar6;
                    __vbaHresultCheckObj();
                  }
                  pppppfVar7 = (float *****)__vbaFreeObj_exref;
                  ppppfStack_41c = (float ****)0x47a65c;
                  __vbaFreeObj();
                  if (DAT_0050b570 == (float *****)0x0) {
                    ppppfStack_41c = (float ****)&DAT_0050b570;
                    ppppfStack_420 = (float ****)&DAT_004048dc;
                    ppppfStack_424 = (float ****)0x47a675;
                    __vbaNew2();
                  }
                  ppppfStack_41c = (float ****)DAT_0050b570;
                  ppppfStack_420 = (float ****)0x47a683;
                  ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
                  ppppfStack_424 = (float ****)&local_58;
                  ppppfStack_428 = (float ****)0x47a68e;
                  pppppfVar8 = (float *****)__vbaObjSet();
                  ppppfStack_428 = (float ****)&local_218;
                  ppppfStack_430 = (float ****)0x47a6a0;
                  ppppfStack_42c = (float ****)pppppfVar8;
                  pppppfVar6 = (float *****)(*(code *)(*pppppfVar8)[0x22])();
                  uVar17 = 0;
                  if ((int)pppppfVar6 < 0) {
                    ppppfStack_430 = (float ****)0x88;
                    ppppfStack_434 = (float ****)&DAT_0040c908;
                    ppppfStack_440 = (float ****)0x47a6b8;
                    ppppfStack_43c = (float ****)pppppfVar6;
                    ppppfStack_438 = (float ****)pppppfVar8;
                    __vbaHresultCheckObj();
                  }
                  ppppfStack_430 = (float ****)0x47a6c4;
                  iVar3 = __vbaFpI4();
                  ppppfStack_434 = (float ****)(float)(iVar3 / 2);
                  local_174 = (float ****)0x4;
                  ppppfStack_440 = (float ****)0x80010006;
                  ppppfStack_43c = (float ****)0x4;
                  ppppfStack_438 = local_170;
                  ppppfStack_444 = local_250;
                  ppppfStack_430 = local_168;
                  ppppfStack_448 = (float ****)0x47a716;
                  local_16c = ppppfStack_434;
                  __vbaLateIdSt();
                  ppppfStack_448 = (float ****)0x47a71b;
                  __vbaFreeObj();
                  if (!SCARRY2((short)DAT_0050b3c4,2)) {
                    ppppfStack_404 = (float ****)(int)(short)((short)DAT_0050b3c4 + 2);
                    local_174 = (float ****)0x3;
                    ppppfStack_40c = (float ****)0x3;
                    ppppfStack_410 = (float ****)0x4;
                    ppppfStack_408 = local_170;
                    ppppfStack_414 = local_250;
                    ppppfStack_400 = local_168;
                    ppppfStack_418 = (float ****)0x47a767;
                    local_16c = ppppfStack_404;
                    __vbaLateIdSt();
                    local_174 = (float ****)0x3;
                    ppppfStack_428 = (float ****)0x5;
                    ppppfStack_424 = (float ****)0x3;
                    local_16c = (float ****)0x6;
                    ppppfStack_420 = local_170;
                    ppppfStack_42c = local_250;
                    ppppfStack_41c = (float ****)0x6;
                    ppppfStack_418 = local_168;
                    ppppfStack_430 = (float ****)0x47a7a4;
                    __vbaLateIdSt();
                    pppppfVar7 = (float *****)&DAT_00000001;
                    local_20 = (float ***)0x0;
                    pcVar15 = (code *)pppppfVar5;
                    pppppfVar8 = (float *****)__vbaLateIdCallSt_exref;
                    ppppfVar12 = (float ****)local_20;
                    do {
                      local_20 = (float ***)ppppfVar12;
                      pppppfVar5 = (float *****)pcVar15;
                      if (5 < (short)local_20) {
                        pppppfVar7 = &ppppfStack_40c;
                        local_174 = (float ****)0x3;
                        ppppfStack_40c = (float ****)0x3;
                        local_16c = (float ****)0x0;
                        local_194 = (float ****)0x2;
                        ppppfStack_408 = local_170;
                        ppppfStack_420 = (float ****)&DAT_00000001;
                        ppppfStack_404 = (float ****)0x0;
                        local_18c = (float ****)&DAT_00000001;
                        ppppfStack_424 = (float ****)0x38;
                        ppppfStack_400 = local_168;
                        ppppfStack_41c = (float ****)0x2;
                        ppppfStack_418 = local_190;
                        ppppfStack_428 = local_250;
                        ppppfStack_414 = (float ****)0x1;
                        ppppfStack_410 = local_188;
                        ppppfStack_42c = (float ****)0x47a9a0;
                        (*(code *)pppppfVar8)();
                        ppppfVar12 = (float ****)0x0;
                        goto LAB_0047a9a5;
                      }
                      local_16c = (float ****)(int)(short)local_20;
                      ppppfStack_400 = (float ****)0x0;
                      ppppfStack_404 = (float ****)0x80010005;
                      ppppfStack_40c = local_74;
                      ppppfStack_408 = local_250;
                      local_174 = (float ****)0x3;
                      ppppfStack_410 = (float ****)0x47a7ed;
                      ppppfStack_400 = (float ****)__vbaLateIdCallLd();
                      ppppfStack_404 = (float ****)0x47a7f7;
                      __vbaR4Var();
                      if (DAT_0050b000 != 0) {
                        ppppfStack_400 = (float ****)DAT_00401fac;
                        ppppfStack_3fc = (float ****)DAT_00401fa8;
                        ppppfStack_408 = (float ****)0x47a819;
                        adj_fdiv_m64();
                      }
                      pppppfVar6 = (float *****)ppppfStack_3fc;
                      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
                      ppppfStack_400 = (float ****)0x47a829;
                      ppppfStack_414 = (float ****)__vbaFpI4();
                      ppppfStack_40c = local_174;
                      local_194 = (float ****)0x3;
                      ppppfStack_408 = local_170;
                      ppppfStack_404 = local_16c;
                      ppppfStack_400 = local_168;
                      ppppfStack_420 = (float ****)0x1;
                      ppppfStack_424 = (float ****)0x39;
                      ppppfStack_41c = (float ****)0x3;
                      ppppfStack_418 = local_190;
                      ppppfStack_428 = local_250;
                      ppppfStack_410 = local_188;
                      ppppfStack_42c = (float ****)0x47a88b;
                      local_18c = ppppfStack_414;
                      (*(code *)pppppfVar8)();
                      ppppfStack_400 = (float ****)0x47a897;
                      __vbaFreeVar();
                      pppppfVar8 = (float *****)__vbaLateIdCallSt_exref;
                      ppppfStack_404 = (float ****)(int)(short)local_20;
                      pppppfVar5 = &ppppfStack_40c;
                      local_174 = (float ****)0x3;
                      ppppfStack_40c = (float ****)0x3;
                      ppppfStack_408 = local_170;
                      local_18c = (float ****)0x7;
                      ppppfStack_420 = (float ****)&DAT_00000001;
                      local_194 = (float ****)0x2;
                      ppppfStack_424 = (float ****)0x38;
                      ppppfStack_400 = local_168;
                      ppppfStack_41c = (float ****)0x2;
                      ppppfStack_418 = local_190;
                      ppppfStack_428 = local_250;
                      ppppfStack_414 = (float ****)0x7;
                      ppppfStack_410 = local_188;
                      ppppfStack_42c = (float ****)0x47a90d;
                      local_16c = ppppfStack_404;
                      __vbaLateIdCallSt();
                      pcVar15 = __vbaLateIdSt_exref;
                      ppppfVar12 = (float ****)CONCAT22(extraout_var_00,(short)local_20 + 1);
                    } while (!SCARRY2((short)local_20,1));
                  }
                  goto LAB_0047ea95;
                }
              }
            }
          }
        }
        goto LAB_0047ea90;
      }
      if (DAT_0050b238 != 9) goto LAB_0047e966;
    }
    if (DAT_0050b570 == (float *****)0x0) {
      ppppfStack_40c = (float ****)&DAT_0050b570;
      ppppfStack_410 = (float ****)&DAT_004048dc;
      ppppfStack_414 = (float ****)0x47b59d;
      __vbaNew2();
    }
    ppppfStack_410 = (float ****)&local_248;
    ppppfStack_40c = (float ****)DAT_0050b570;
    ppppfStack_414 = (float ****)0x47b5b0;
    __vbaObjSetAddref();
    local_174 = (float ****)0xb;
    ppppfStack_424 = (float ****)0x80010007;
    ppppfStack_420 = (float ****)0xb;
    local_16c = (float ****)0x0;
    ppppfStack_41c = local_170;
    ppppfStack_418 = (float ****)0x0;
    ppppfStack_414 = local_168;
    ppppfStack_428 = local_248;
    ppppfStack_42c = (float ****)0x47b5f3;
    ppppfStack_42c = (float ****)(*(code *)(*local_248)[0xd7])();
    pppppfVar7 = (float *****)__vbaObjSet_exref;
    ppppfStack_430 = (float ****)&local_58;
    ppppfStack_434 = (float ****)0x47b600;
    ppppfStack_434 = (float ****)__vbaObjSet();
    ppppfStack_438 = (float ****)0x47b603;
    __vbaLateIdSt();
    ppppfStack_438 = (float ****)0x47b60c;
    __vbaFreeObj();
    ppppfStack_438 = local_248;
    ppppfStack_43c = (float ****)0x47b61b;
    ppppfStack_43c = (float ****)(*(code *)(*local_248)[0xc3])();
    ppppfStack_440 = (float ****)&local_58;
    ppppfStack_444 = (float ****)0x47b622;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_444 = (float ****)0x0;
    ppppfStack_44c = (float ****)0x47b62f;
    ppppfStack_448 = (float ****)pppppfVar6;
    pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x27])();
    if ((int)pppppfVar8 < 0) {
      ppppfStack_44c = (float ****)0x9c;
      ppppfStack_450 = (float ****)&DAT_0040c3dc;
      ppppfStack_45c = (float ****)0x47b647;
      ppppfStack_458 = (float ****)pppppfVar8;
      ppppfStack_454 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_44c = (float ****)0x47b650;
    __vbaFreeObj();
    ppppfStack_44c = local_248;
    ppppfStack_450 = (float ****)0x47b65f;
    ppppfStack_450 = (float ****)(*(code *)(*local_248)[0xcf])();
    ppppfStack_454 = (float ****)&local_58;
    ppppfStack_458 = (float ****)0x47b666;
    pppppfVar8 = (float *****)__vbaObjSet();
    ppppfStack_458 = (float ****)0xffffffff;
    ppppfStack_460 = (float ****)0x47b673;
    ppppfStack_45c = (float ****)pppppfVar8;
    pppppfVar6 = (float *****)(*(code *)(*pppppfVar8)[0x25])();
    if ((int)pppppfVar6 < 0) {
      ppppfStack_460 = (float ****)0x94;
      ppppfStack_464 = (float ****)&DAT_0040c8f8;
      ppppfStack_470 = (float ****)0x47b68b;
      ppppfStack_46c = (float ****)pppppfVar6;
      ppppfStack_468 = (float ****)pppppfVar8;
      __vbaHresultCheckObj();
    }
    ppppfStack_460 = (float ****)0x47b694;
    __vbaFreeObj();
    local_16c = (float ****)&DAT_0040f1c0;
    local_174 = (float ****)0x8;
    ppppfStack_460 = (float ****)0x47b6b7;
    __vbaVarDup();
    ppppfStack_3fc = local_74;
    if (((SCARRY2(DAT_0050b22a,DAT_0050b228)) ||
        (iVar3 = (short)(DAT_0050b22a + DAT_0050b228) * 3, sVar14 = (short)iVar3, sVar14 != iVar3))
       || (SCARRY2(sVar14,0xb))) goto LAB_0047ea95;
    ppppfStack_400 = (float ****)(int)(short)(sVar14 + 0xb);
    ppppfStack_404 = (float ****)0x47b6ed;
    Ordinal_606();
    ppppfStack_404 = (float ****)0x47b6f8;
    __vbaStrMove();
    ppppfStack_404 = local_248;
    ppppfStack_408 = (float ****)0x47b707;
    ppppfStack_408 = (float ****)(*(code *)(*local_248)[0xcf])();
    ppppfStack_40c = (float ****)&local_58;
    ppppfStack_410 = (float ****)0x47b70e;
    local_22c = (float ****)__vbaObjSet();
    if (DAT_0050b570 == (float *****)0x0) {
      ppppfStack_410 = (float ****)&DAT_0050b570;
      ppppfStack_414 = (float ****)&DAT_004048dc;
      ppppfStack_418 = (float ****)0x47b72d;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050b570;
    ppppfStack_410 = (float ****)&local_218;
    local_194 = (float ****)0x3;
    local_184 = (float ***)0x3;
    local_18c = (float ****)&DAT_00000001;
    ppppfStack_420 = (float ****)0x3;
    local_17c = (wchar_t *)0x4;
    ppppfStack_41c = local_190;
    local_40 = (float ***)0x0;
    ppppfVar12 = *DAT_0050b570;
    ppppfStack_418 = (float ****)&DAT_00000001;
    ppppfStack_414 = local_188;
    ppppfStack_430 = (float ****)0x3;
    ppppfStack_42c = local_180;
    ppppfStack_428 = (float ****)0x4;
    ppppfStack_424 = local_178;
    ppppfStack_434 = (float ****)0x47b7c5;
    ppppfStack_434 = (float ****)__vbaStrMove();
    ppppfStack_438 = (float ****)0x47b7cc;
    iVar3 = __vbaLenBstr();
    ppppfStack_438 = (float ****)(float)iVar3;
    ppppfStack_43c = (float ****)pppppfVar6;
    ppppfStack_440 = (float ****)0x47b7ec;
    pppppfVar8 = (float *****)(*(code *)ppppfVar12[0xb7])();
    pppppfVar7 = (float *****)__vbaHresultCheckObj_exref;
    if ((int)pppppfVar8 < 0) {
      ppppfStack_440 = (float ****)0x2dc;
      ppppfStack_444 = (float ****)&DAT_0040d7a4;
      ppppfStack_448 = (float ****)pppppfVar6;
      ppppfStack_450 = (float ****)0x47b806;
      ppppfStack_44c = (float ****)pppppfVar8;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_22c;
    ppppfStack_440 = local_218;
    ppppfStack_444 = local_22c;
    ppppfStack_448 = (float ****)0x47b821;
    ppppfStack_454 = (float ****)(*(code *)(*local_22c)[0x1f])();
    if ((int)ppppfStack_454 < 0) {
      ppppfStack_448 = (float ****)0x7c;
      ppppfStack_44c = (float ****)&DAT_0040c8f8;
      ppppfStack_450 = ppppfVar12;
      ppppfStack_458 = (float ****)0x47b832;
      __vbaHresultCheckObj();
    }
    ppppfStack_448 = &local_40;
    ppppfStack_44c = &local_3c;
    ppppfStack_450 = (float ****)0x2;
    ppppfStack_454 = (float ****)0x47b842;
    __vbaFreeStrList();
    ppppfStack_448 = (float ****)0x47b84e;
    __vbaFreeObj();
    ppppfStack_448 = (float ****)0x47b857;
    __vbaFreeVar();
    if (DAT_0050c53c == (float *****)0x0) {
      ppppfStack_448 = (float ****)&DAT_0050c53c;
      ppppfStack_44c = (float ****)&DAT_0040b420;
      ppppfStack_450 = (float ****)0x47b870;
      __vbaNew2();
    }
    pppppfVar6 = DAT_0050c53c;
    ppppfStack_448 = (float ****)&local_58;
    ppppfStack_44c = (float ****)DAT_0050c53c;
    ppppfStack_450 = (float ****)0x47b880;
    pppppfVar8 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
    if ((int)pppppfVar8 < 0) {
      ppppfStack_450 = (float ****)0x18;
      ppppfStack_454 = (float ****)&DAT_0040b410;
      ppppfStack_458 = (float ****)pppppfVar6;
      ppppfStack_460 = (float ****)0x47b891;
      ppppfStack_45c = (float ****)pppppfVar8;
      __vbaHresultCheckObj();
    }
    ppppfVar12 = local_58;
    ppppfStack_450 = (float ****)&local_218;
    ppppfStack_454 = local_58;
    ppppfStack_458 = (float ****)0x47b8a6;
    pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
    if ((int)pppppfVar6 < 0) {
      ppppfStack_458 = (float ****)0x98;
      ppppfStack_45c = (float ****)&DAT_0040bb5c;
      ppppfStack_460 = ppppfVar12;
      ppppfStack_468 = (float ****)0x47b8ba;
      ppppfStack_464 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_458 = local_248;
    ppppfStack_45c = (float ****)0x47b8c9;
    ppppfStack_45c = (float ****)(*(code *)(*local_248)[0xcf])();
    ppppfStack_460 = &local_5c;
    ppppfStack_464 = (float ****)0x47b8d4;
    pppppfVar6 = (float *****)__vbaObjSet();
    ppppfStack_464 = &local_21c;
    ppppfStack_46c = (float ****)0x47b8e3;
    ppppfStack_468 = (float ****)pppppfVar6;
    pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
    uVar17 = 0;
    if ((int)pppppfVar8 < 0) {
      ppppfStack_46c = (float ****)0x78;
      ppppfStack_470 = (float ****)&DAT_0040c8f8;
      ppppfStack_47c = (float ****)0x47b8f4;
      ppppfStack_478 = (float ****)pppppfVar8;
      ppppfStack_474 = (float ****)pppppfVar6;
      __vbaHresultCheckObj();
    }
    ppppfStack_46c = local_248;
    ppppfStack_470 = (float ****)0x47b903;
    ppppfStack_470 = (float ****)(*(code *)(*local_248)[0xcf])();
    ppppfStack_474 = &local_60;
    ppppfStack_478 = (float ****)0x47b90e;
    pppppfVar8 = (float *****)__vbaObjSet();
    ppppfStack_3fc =
         (float ****)
         (((float)local_218 * (float)_DAT_00401d20 - (float)local_21c * (float)_DAT_00401268) *
         DAT_0050b024);
    pppppfVar6 = (float *****)*pppppfVar8;
    if ((uVar17 & 0xd) == 0) {
      ppppfStack_404 = (float ****)0x47b950;
      ppppfStack_400 = (float ****)pppppfVar8;
      ppppfStack_410 = (float ****)(*(code *)(*pppppfVar8)[0x1b])();
      if ((int)ppppfStack_410 < 0) {
        ppppfStack_404 = (float ****)0x6c;
        ppppfStack_408 = (float ****)&DAT_0040c8f8;
        ppppfStack_414 = (float ****)0x47b961;
        ppppfStack_40c = (float ****)pppppfVar8;
        __vbaHresultCheckObj();
      }
      ppppfStack_404 = &local_60;
      ppppfStack_408 = &local_5c;
      ppppfStack_40c = (float ****)&local_58;
      ppppfStack_410 = (float ****)0x3;
      ppppfStack_414 = (float ****)0x47b975;
      __vbaFreeObjList();
      if (DAT_0050b570 == (float *****)0x0) {
        ppppfStack_404 = (float ****)&DAT_0050b570;
        ppppfStack_408 = (float ****)&DAT_004048dc;
        ppppfStack_40c = (float ****)0x47b991;
        __vbaNew2();
      }
      pppppfVar6 = DAT_0050b570;
      ppppfStack_404 = (float ****)&local_218;
      ppppfStack_408 = (float ****)&PTR_u_HAN__00410014_0x2d_0040cf18;
      ppppfStack_40c = (float ****)DAT_0050b570;
      ppppfStack_410 = (float ****)0x47b9ac;
      pppppfVar8 = (float *****)(*(code *)(*DAT_0050b570)[0xba])();
      uVar17 = 0;
      if ((int)pppppfVar8 < 0) {
        ppppfStack_400 = (float ****)0x2e8;
        ppppfStack_404 = (float ****)&DAT_0040d7a4;
        ppppfStack_408 = (float ****)pppppfVar6;
        ppppfStack_410 = (float ****)0x47b9c0;
        ppppfStack_40c = (float ****)pppppfVar8;
        __vbaHresultCheckObj();
      }
      pppppfVar6 = (float *****)ppppfStack_3fc;
      if ((uVar17 & 0xd) == 0) {
        ppppfStack_400 = (float ****)0x47b9dc;
        local_1c = __vbaFpI4();
        ppppfStack_404 = (float ****)&local_248;
        ppppfStack_400 = (float ****)0x0;
        ppppfStack_408 = (float ****)0x47b9ee;
        __vbaObjSetAddref();
        pppppfVar8 = (float *****)__vbaNew2_exref;
        if (DAT_0050b570 == (float *****)0x0) {
          ppppfStack_408 = (float ****)&DAT_0050b570;
          ppppfStack_40c = (float ****)&DAT_004048dc;
          ppppfStack_410 = (float ****)0x47ba09;
          __vbaNew2();
        }
        ppppfStack_408 = (float ****)DAT_0050b570;
        ppppfStack_40c = (float ****)0x47ba1f;
        ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xcf])();
        ppppfStack_410 = (float ****)&local_24c;
        ppppfStack_414 = (float ****)0x47ba2d;
        __vbaObjSet();
        uVar2 = DAT_0050b150;
        uVar13 = DAT_0050b14c;
        if ((SCARRY2(DAT_0050b22a,DAT_0050b228)) ||
           (uVar10 = CONCAT22(extraout_var,DAT_0050b22a + DAT_0050b228 + 1),
           SCARRY2(DAT_0050b22a + DAT_0050b228,1))) goto LAB_0047ea95;
        local_2c = uVar10;
        if (DAT_0050b238 == 3) {
          if ((double)CONCAT44(DAT_0050b150,DAT_0050b14c) == _DAT_0050b134) {
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_400 = (float ****)&DAT_0050b570;
              ppppfStack_404 = (float ****)&DAT_004048dc;
              ppppfStack_408 = (float ****)0x47ce56;
              __vbaNew2();
            }
            ppppfStack_400 = (float ****)DAT_0050b570;
            ppppfStack_404 = (float ****)0x47ce64;
            ppppfStack_404 = (float ****)(*(code *)(*DAT_0050b570)[0xc2])();
            ppppfStack_408 = (float ****)&local_58;
            ppppfStack_40c = (float ****)0x47ce6f;
            pppppfVar6 = (float *****)__vbaObjSet();
            ppppfStack_40c = (float ****)&DAT_0040ca6c;
            ppppfStack_414 = (float ****)0x47ce7c;
            ppppfStack_410 = (float ****)pppppfVar6;
            pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
            if ((int)pppppfVar5 < 0) {
              ppppfStack_414 = (float ****)0x54;
              ppppfStack_418 = (float ****)&DAT_0040ba5c;
              ppppfStack_424 = (float ****)0x47ce8d;
              ppppfStack_420 = (float ****)pppppfVar5;
              ppppfStack_41c = (float ****)pppppfVar6;
              __vbaHresultCheckObj();
            }
            ppppfStack_414 = (float ****)0x47ce96;
            __vbaFreeObj();
            pcVar15 = __vbaNew2_exref;
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_414 = (float ****)&DAT_0050b570;
              ppppfStack_418 = (float ****)&DAT_004048dc;
              ppppfStack_41c = (float ****)0x47ceb1;
              __vbaNew2();
            }
            ppppfStack_414 = (float ****)DAT_0050b570;
            ppppfStack_418 = (float ****)0x47cec7;
            ppppfStack_418 = (float ****)(*(code *)(*DAT_0050b570)[0xc1])();
            ppppfStack_41c = (float ****)&local_58;
            ppppfStack_420 = (float ****)0x47ced2;
            pppppfVar6 = (float *****)__vbaObjSet();
            ppppfStack_420 = (float ****)0x40f71c;
            ppppfStack_428 = (float ****)0x47cedf;
            ppppfStack_424 = (float ****)pppppfVar6;
            pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
            if ((int)pppppfVar5 < 0) {
              ppppfStack_428 = (float ****)0x54;
              ppppfStack_42c = (float ****)&DAT_0040ba5c;
              ppppfStack_438 = (float ****)0x47cef0;
              ppppfStack_434 = (float ****)pppppfVar5;
              ppppfStack_430 = (float ****)pppppfVar6;
              __vbaHresultCheckObj();
            }
            ppppfStack_428 = (float ****)0x47cef9;
            __vbaFreeObj();
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_428 = (float ****)&DAT_0050b570;
              ppppfStack_42c = (float ****)&DAT_004048dc;
              ppppfStack_430 = (float ****)0x47cf0e;
              __vbaNew2();
            }
            ppppfStack_428 = (float ****)DAT_0050b570;
            ppppfStack_42c = (float ****)0x47cf1c;
            ppppfStack_42c = (float ****)(*(code *)(*DAT_0050b570)[0xc0])();
            ppppfStack_430 = (float ****)&local_58;
            ppppfStack_434 = (float ****)0x47cf27;
            pppppfVar6 = (float *****)__vbaObjSet();
            ppppfStack_434 = (float ****)&DAT_0040ca6c;
            ppppfStack_43c = (float ****)0x47cf34;
            ppppfStack_438 = (float ****)pppppfVar6;
            pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
            if ((int)pppppfVar5 < 0) {
              ppppfStack_43c = (float ****)0x54;
              ppppfStack_440 = (float ****)&DAT_0040ba5c;
              ppppfStack_44c = (float ****)0x47cf45;
              ppppfStack_448 = (float ****)pppppfVar5;
              ppppfStack_444 = (float ****)pppppfVar6;
              __vbaHresultCheckObj();
            }
            ppppfStack_43c = (float ****)0x47cf4e;
            __vbaFreeObj();
          }
          else {
            ppppfStack_400 = (float ****)0x47cf6b;
            fVar18 = (float10)__vbaFpR8();
            if (fVar18 == (float10)(double)CONCAT44(uVar2,uVar13)) {
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_400 = (float ****)&DAT_0050b570;
                ppppfStack_404 = (float ****)&DAT_004048dc;
                ppppfStack_408 = (float ****)0x47cf91;
                __vbaNew2();
              }
              ppppfStack_400 = (float ****)DAT_0050b570;
              ppppfStack_404 = (float ****)0x47cf9f;
              ppppfStack_404 = (float ****)(*(code *)(*DAT_0050b570)[0xc2])();
              ppppfStack_408 = (float ****)&local_58;
              ppppfStack_40c = (float ****)0x47cfac;
              pppppfVar6 = (float *****)__vbaObjSet();
              ppppfStack_40c = (float ****)&DAT_0040ca6c;
              ppppfStack_414 = (float ****)0x47cfb9;
              ppppfStack_410 = (float ****)pppppfVar6;
              pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
              if ((int)pppppfVar5 < 0) {
                ppppfStack_414 = (float ****)0x54;
                ppppfStack_418 = (float ****)&DAT_0040ba5c;
                ppppfStack_424 = (float ****)0x47cfca;
                ppppfStack_420 = (float ****)pppppfVar5;
                ppppfStack_41c = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              ppppfStack_414 = (float ****)0x47cfd3;
              __vbaFreeObj();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_414 = (float ****)&DAT_0050b570;
                ppppfStack_418 = (float ****)&DAT_004048dc;
                ppppfStack_41c = (float ****)0x47cfec;
                __vbaNew2();
              }
              ppppfStack_414 = (float ****)DAT_0050b570;
              ppppfStack_418 = (float ****)0x47cffa;
              ppppfStack_418 = (float ****)(*(code *)(*DAT_0050b570)[0xc1])();
              ppppfStack_41c = (float ****)&local_58;
              ppppfStack_420 = (float ****)0x47d001;
              pppppfVar6 = (float *****)__vbaObjSet();
              ppppfStack_420 = (float ****)0x40f75c;
              ppppfStack_428 = (float ****)0x47d00e;
              ppppfStack_424 = (float ****)pppppfVar6;
              pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
              if ((int)pppppfVar5 < 0) {
                ppppfStack_428 = (float ****)0x54;
                ppppfStack_42c = (float ****)&DAT_0040ba5c;
                ppppfStack_438 = (float ****)0x47d01f;
                ppppfStack_434 = (float ****)pppppfVar5;
                ppppfStack_430 = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              ppppfStack_428 = (float ****)0x47d028;
              __vbaFreeObj();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_428 = (float ****)&DAT_0050b570;
                ppppfStack_42c = (float ****)&DAT_004048dc;
                ppppfStack_430 = (float ****)0x47d041;
                __vbaNew2();
              }
              ppppfStack_428 = (float ****)DAT_0050b570;
              ppppfStack_42c = (float ****)0x47d04f;
              ppppfStack_42c = (float ****)(*(code *)(*DAT_0050b570)[0xc0])();
              ppppfStack_430 = (float ****)&local_58;
              ppppfStack_434 = (float ****)0x47d056;
              pppppfVar6 = (float *****)__vbaObjSet();
              ppppfStack_434 = (float ****)&DAT_0040ca6c;
              ppppfStack_43c = (float ****)0x47d063;
              ppppfStack_438 = (float ****)pppppfVar6;
              pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
              if ((int)pppppfVar5 < 0) {
                ppppfStack_43c = (float ****)0x54;
                ppppfStack_440 = (float ****)&DAT_0040ba5c;
                ppppfStack_44c = (float ****)0x47d074;
                ppppfStack_448 = (float ****)pppppfVar5;
                ppppfStack_444 = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              ppppfStack_43c = (float ****)0x47d07d;
              __vbaFreeObj();
              pcVar15 = __vbaNew2_exref;
            }
            else {
              ppppfStack_400 = (float ****)0x47d087;
              FUN_0044fdc0();
              ppppfStack_400 = (float ****)0x47d092;
              __vbaStrMove();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_400 = (float ****)&DAT_0050b570;
                ppppfStack_404 = (float ****)&DAT_004048dc;
                ppppfStack_408 = (float ****)0x47d0a7;
                __vbaNew2();
              }
              ppppfStack_400 = (float ****)DAT_0050b570;
              ppppfStack_404 = (float ****)0x47d0b5;
              ppppfStack_404 = (float ****)(*(code *)(*DAT_0050b570)[0xc2])();
              ppppfStack_408 = (float ****)&local_58;
              ppppfStack_40c = (float ****)0x47d0c0;
              pppppfVar6 = (float *****)__vbaObjSet();
              ppppfStack_40c = (float ****)&DAT_00000001;
              ppppfStack_414 = local_74;
              local_6c = local_40;
              ppppfStack_410 = (float ****)&DAT_00000001;
              ppppfStack_418 = (float ****)&local_174;
              ppppfStack_41c = local_84;
              local_17c = L"Objective value = ";
              local_184 = (float ***)0x8;
              local_40 = (float ***)0x0;
              local_74[0] = (float ***)0x8;
              local_16c = (float ****)&DAT_0050b14c;
              local_174 = (float ****)0x4005;
              ppppfStack_420 = (float ****)0x47d114;
              Ordinal_660();
              ppppfVar12 = *pppppfVar6;
              ppppfStack_420 = &local_184;
              ppppfStack_424 = local_84;
              ppppfStack_428 = local_94;
              ppppfStack_42c = (float ****)0x47d12e;
              ppppfStack_42c = (float ****)__vbaVarCat();
              ppppfStack_430 = &local_3c;
              ppppfStack_434 = (float ****)0x47d139;
              ppppfStack_434 = (float ****)__vbaStrVarVal();
              ppppfStack_43c = (float ****)0x47d13e;
              ppppfStack_438 = (float ****)pppppfVar6;
              ppppfStack_448 = (float ****)(*(code *)ppppfVar12[0x15])();
              if ((int)ppppfStack_448 < 0) {
                ppppfStack_43c = (float ****)0x54;
                ppppfStack_440 = (float ****)&DAT_0040ba5c;
                ppppfStack_44c = (float ****)0x47d153;
                ppppfStack_444 = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              ppppfStack_43c = &local_40;
              ppppfStack_440 = &local_3c;
              ppppfStack_444 = (float ****)0x2;
              ppppfStack_448 = (float ****)0x47d163;
              __vbaFreeStrList();
              ppppfStack_43c = (float ****)0x47d16f;
              __vbaFreeObj();
              ppppfStack_43c = local_94;
              ppppfStack_440 = local_84;
              ppppfStack_444 = local_74;
              ppppfStack_448 = (float ****)0x3;
              ppppfStack_44c = (float ****)0x47d186;
              __vbaFreeVarList();
              ppppfStack_43c = (float ****)0x47d18e;
              FUN_0044fdc0();
              ppppfStack_43c = (float ****)0x47d199;
              __vbaStrMove();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_43c = (float ****)&DAT_0050b570;
                ppppfStack_440 = (float ****)&DAT_004048dc;
                ppppfStack_444 = (float ****)0x47d1b2;
                __vbaNew2();
              }
              ppppfStack_43c = (float ****)DAT_0050b570;
              ppppfStack_440 = (float ****)0x47d1c0;
              ppppfStack_440 = (float ****)(*(code *)(*DAT_0050b570)[0xc1])();
              ppppfStack_444 = (float ****)&local_58;
              ppppfStack_448 = (float ****)0x47d1cb;
              pppppfVar6 = (float *****)__vbaObjSet();
              local_6c = local_40;
              ppppfStack_44c = &local_30;
              ppppfStack_448 = (float ****)DAT_0050b0ec;
              local_17c = L"x1 = ";
              local_184 = (float ***)0x8;
              local_40 = (float ***)0x0;
              local_74[0] = (float ***)0x8;
              ppppfStack_450 = (float ****)0x47d1fd;
              __vbaAryLock();
              if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 1)) {
                ppppfStack_450 = (float ****)0x47d233;
                iVar3 = __vbaGenerateBoundsError();
              }
              else {
                pppfVar16 = (float ***)local_30[5];
                if (local_30[4] <= (float ***)(1U - (int)pppfVar16)) {
                  ppppfStack_450 = (float ****)0x47d221;
                  __vbaGenerateBoundsError();
                }
                iVar3 = (int)(1U - (int)pppfVar16) * 8;
              }
              ppppfStack_450 = (float ****)&DAT_00000001;
              local_16c = (float ****)((int)local_30[3] + iVar3);
              ppppfStack_458 = local_74;
              ppppfStack_454 = (float ****)&DAT_00000001;
              ppppfStack_45c = (float ****)&local_174;
              ppppfStack_460 = local_84;
              local_174 = (float ****)0x4005;
              ppppfStack_464 = (float ****)0x47d264;
              Ordinal_660();
              ppppfStack_464 = &local_30;
              ppppfStack_468 = (float ****)0x47d270;
              __vbaAryUnlock();
              ppppfVar12 = *pppppfVar6;
              ppppfStack_468 = &local_184;
              ppppfStack_46c = local_84;
              ppppfStack_470 = local_94;
              ppppfStack_474 = (float ****)0x47d28a;
              ppppfStack_474 = (float ****)__vbaVarCat();
              ppppfStack_478 = &local_3c;
              ppppfStack_47c = (float ****)0x47d295;
              ppppfStack_47c = (float ****)__vbaStrVarVal();
              ppppfStack_484 = (float ****)0x47d29a;
              ppppfStack_480 = (float ****)pppppfVar6;
              ppppfStack_490 = (float ****)(*(code *)ppppfVar12[0x15])();
              if ((int)ppppfStack_490 < 0) {
                ppppfStack_484 = (float ****)0x54;
                ppppfStack_488 = (float ****)&DAT_0040ba5c;
                ppppfStack_494 = (float ****)0x47d2af;
                ppppfStack_48c = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              ppppfStack_484 = &local_40;
              ppppfStack_488 = &local_3c;
              ppppfStack_48c = (float ****)0x2;
              ppppfStack_490 = (float ****)0x47d2bf;
              __vbaFreeStrList();
              ppppfStack_484 = (float ****)0x47d2cb;
              __vbaFreeObj();
              ppppfStack_484 = local_94;
              ppppfStack_488 = local_84;
              ppppfStack_48c = local_74;
              ppppfStack_490 = (float ****)0x3;
              ppppfStack_494 = (float ****)0x47d2e2;
              __vbaFreeVarList();
              ppppfStack_484 = (float ****)0x47d2ea;
              FUN_0044fdc0();
              ppppfStack_484 = (float ****)0x47d2f5;
              __vbaStrMove();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_484 = (float ****)&DAT_0050b570;
                ppppfStack_488 = (float ****)&DAT_004048dc;
                ppppfStack_48c = (float ****)0x47d30e;
                __vbaNew2();
              }
              ppppfStack_484 = (float ****)DAT_0050b570;
              ppppfStack_488 = (float ****)0x47d31c;
              ppppfStack_488 = (float ****)(*(code *)(*DAT_0050b570)[0xc0])();
              ppppfStack_48c = (float ****)&local_58;
              ppppfStack_490 = (float ****)0x47d327;
              ppppfVar12 = (float ****)__vbaObjSet();
              local_6c = local_40;
              local_184 = (float ***)0x8;
              local_74[0] = (float ***)0x8;
              ppppfStack_494 = &local_30;
              ppppfStack_490 = (float ****)DAT_0050b0ec;
              local_17c = L"x2 = ";
              local_40 = (float ***)0x0;
              ppppfStack_498 = (float ****)0x47d35e;
              __vbaAryLock();
              if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 1)) {
                ppppfStack_498 = (float ****)0x47d394;
                iVar3 = __vbaGenerateBoundsError();
              }
              else {
                pppfVar16 = (float ***)local_30[5];
                if (local_30[4] <= (float ***)(2U - (int)pppfVar16)) {
                  ppppfStack_498 = (float ****)0x47d382;
                  __vbaGenerateBoundsError();
                }
                iVar3 = (int)(2U - (int)pppfVar16) * 8;
              }
              ppppfStack_498 = (float ****)&DAT_00000001;
              local_16c = (float ****)((int)local_30[3] + iVar3);
              ppppfStack_4a0 = local_74;
              pppfStack_49c = (float ***)&DAT_00000001;
              ppppfStack_4a4 = (float ****)&local_174;
              pppfStack_4a8 = (float ***)local_84;
              local_174 = (float ****)0x4005;
              ppppfStack_4ac = (float ****)0x47d3c5;
              Ordinal_660();
              ppppfStack_4ac = &local_30;
              ppppfStack_4b0 = (float ****)0x47d3cb;
              __vbaAryUnlock();
              pppfVar16 = *ppppfVar12;
              ppppfStack_4b0 = &local_184;
              ppppfStack_4b4 = local_84;
              ppppfStack_4b8 = local_94;
              ppppfStack_4bc = (float ****)0x47d3e5;
              ppppfStack_4bc = (float ****)__vbaVarCat();
              ppppfStack_4c0 = &local_3c;
              ppppfStack_4c4 = (float ****)0x47d3f0;
              ppppfStack_4c4 = (float ****)__vbaStrVarVal();
              ppppfStack_4cc = (float ****)0x47d3f5;
              ppppfStack_4c8 = ppppfVar12;
              ppppfStack_4d8 = (float ****)(*(code *)pppfVar16[0x15])();
              if ((int)ppppfStack_4d8 < 0) {
                ppppfStack_4cc = (float ****)0x54;
                ppppfStack_4d0 = (float ****)&DAT_0040ba5c;
                pppfStack_4dc = (float ***)0x47d40a;
                ppppfStack_4d4 = ppppfVar12;
                __vbaHresultCheckObj();
              }
              ppppfStack_4cc = &local_40;
              ppppfStack_4d0 = &local_3c;
              ppppfStack_4d4 = (float ****)0x2;
              ppppfStack_4d8 = (float ****)0x47d41a;
              __vbaFreeStrList();
              ppppfStack_4cc = (float ****)0x47d426;
              __vbaFreeObj();
              ppppfStack_4cc = local_94;
              ppppfStack_4d0 = local_84;
              ppppfStack_4d4 = local_74;
              ppppfStack_4d8 = (float ****)0x3;
              pppfStack_4dc = (float ***)0x47d43d;
              __vbaFreeVarList();
              pcVar15 = __vbaNew2_exref;
              pppppfVar7 = (float *****)__vbaHresultCheckObj_exref;
            }
          }
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_43c = (float ****)&DAT_0050b570;
            ppppfStack_440 = (float ****)&DAT_004048dc;
            ppppfStack_444 = (float ****)0x47d461;
            (*pcVar15)();
          }
          ppppfStack_43c = (float ****)DAT_0050b570;
          ppppfStack_440 = (float ****)0x47d46f;
          ppppfStack_440 = (float ****)(*(code *)(*DAT_0050b570)[0xbf])();
          ppppfStack_444 = (float ****)&local_58;
          ppppfStack_448 = (float ****)0x47d47a;
          pppppfVar6 = (float *****)__vbaObjSet();
          ppppfStack_448 = (float ****)0xffffffff;
          ppppfStack_450 = (float ****)0x47d487;
          ppppfStack_44c = (float ****)pppppfVar6;
          pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x27])();
          if ((int)pppppfVar5 < 0) {
            ppppfStack_450 = (float ****)0x9c;
            ppppfStack_454 = (float ****)&DAT_0040c3dc;
            ppppfStack_460 = (float ****)0x47d49b;
            ppppfStack_45c = (float ****)pppppfVar5;
            ppppfStack_458 = (float ****)pppppfVar6;
            (*(code *)pppppfVar7)();
          }
          ppppfStack_450 = (float ****)0x47d4a4;
          __vbaFreeObj();
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_450 = (float ****)&DAT_0050b570;
            ppppfStack_454 = (float ****)&DAT_004048dc;
            ppppfStack_458 = (float ****)0x47d4b9;
            (*pcVar15)();
          }
          pppppfVar6 = DAT_0050b570;
          ppppfStack_450 = (float ****)&local_218;
          ppppfStack_454 = (float ****)&DAT_004100b8;
          ppppfStack_458 = (float ****)DAT_0050b570;
          ppppfStack_45c = (float ****)0x47d4d4;
          pppppfVar5 = (float *****)(*(code *)(*DAT_0050b570)[0xba])();
          uVar17 = 0;
          if ((int)pppppfVar5 < 0) {
            ppppfStack_45c = (float ****)0x2e8;
            ppppfStack_460 = (float ****)&DAT_0040d7a4;
            ppppfStack_464 = (float ****)pppppfVar6;
            ppppfStack_46c = (float ****)0x47d4e8;
            ppppfStack_468 = (float ****)pppppfVar5;
            (*(code *)pppppfVar7)();
          }
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_45c = (float ****)&DAT_0050b570;
            ppppfStack_460 = (float ****)&DAT_004048dc;
            ppppfStack_464 = (float ****)0x47d4fd;
            (*pcVar15)();
          }
          ppppfStack_45c = (float ****)DAT_0050b570;
          ppppfStack_460 = (float ****)0x47d50b;
          ppppfStack_460 = (float ****)(*(code *)(*DAT_0050b570)[0xbf])();
          ppppfStack_464 = (float ****)&local_58;
          ppppfStack_468 = (float ****)0x47d516;
          pppppfVar5 = (float *****)__vbaObjSet();
          pppppfVar6 = (float *****)ppppfStack_3fc;
          if ((uVar17 & 0xd) == 0) {
            ppppfStack_408 = (float ****)0x47d547;
            ppppfStack_404 = (float ****)pppppfVar5;
            ppppfStack_400 = (float ****)((float)local_218 * (float)_DAT_00401f80);
            pppppfVar6 = (float *****)(*(code *)(*pppppfVar5)[0x23])();
            if ((int)pppppfVar6 < 0) {
              ppppfStack_408 = (float ****)0x8c;
              ppppfStack_40c = (float ****)&DAT_0040c3dc;
              ppppfStack_418 = (float ****)0x47d55b;
              ppppfStack_414 = (float ****)pppppfVar6;
              ppppfStack_410 = (float ****)pppppfVar5;
              (*(code *)pppppfVar7)();
            }
            ppppfStack_408 = (float ****)0x47d564;
            __vbaFreeObj();
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_408 = (float ****)&DAT_0050b570;
              ppppfStack_40c = (float ****)&DAT_004048dc;
              ppppfStack_410 = (float ****)0x47d579;
              (*pcVar15)();
            }
            ppppfStack_408 = (float ****)DAT_0050b570;
            ppppfStack_40c = (float ****)0x47d587;
            ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
            ppppfStack_410 = (float ****)&local_58;
            ppppfStack_414 = (float ****)0x47d592;
            pppppfVar6 = (float *****)__vbaObjSet();
            ppppfStack_414 = (float ****)&local_218;
            ppppfStack_41c = (float ****)0x47d5a1;
            ppppfStack_418 = (float ****)pppppfVar6;
            pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
            uVar17 = 0;
            if ((int)pppppfVar5 < 0) {
              ppppfStack_3fc = (float ****)0x78;
              ppppfStack_400 = (float ****)&DAT_0040c908;
              ppppfStack_40c = (float ****)0x47d5b2;
              ppppfStack_408 = (float ****)pppppfVar5;
              ppppfStack_404 = (float ****)pppppfVar6;
              (*(code *)pppppfVar7)();
            }
            ppppfStack_3fc = local_24c;
            pppppfVar6 = (float *****)ppppfStack_3fc;
            if ((uVar17 & 0xd) == 0) {
              ppppfStack_400 = local_24c;
              ppppfStack_404 = (float ****)0x47d5ed;
              ppppfStack_3fc = (float ****)((float)local_218 + (float)local_1c);
              pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x1d])();
              if ((int)pppppfVar6 < 0) {
                ppppfStack_404 = (float ****)0x74;
                ppppfStack_408 = (float ****)&DAT_0040c8f8;
                ppppfStack_40c = local_24c;
                ppppfStack_414 = (float ****)0x47d604;
                ppppfStack_410 = (float ****)pppppfVar6;
                (*(code *)pppppfVar7)();
              }
              ppppfStack_404 = (float ****)0x47d60d;
              __vbaFreeObj();
              ppppfStack_404 = (float ****)0x47d61d;
              __vbaStrCopy();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_404 = (float ****)&DAT_0050b570;
                ppppfStack_408 = (float ****)&DAT_004048dc;
                ppppfStack_40c = (float ****)0x47d632;
                (*pcVar15)();
              }
              pppppfVar6 = DAT_0050b570;
              ppppfStack_404 = (float ****)&local_218;
              ppppfStack_408 = (float ****)DAT_0050b34c;
              ppppfStack_40c = (float ****)DAT_0050b570;
              ppppfStack_410 = (float ****)0x47d64f;
              pppppfVar5 = (float *****)(*(code *)(*DAT_0050b570)[0xb9])();
              uVar17 = 0;
              if ((int)pppppfVar5 < 0) {
                ppppfStack_410 = (float ****)0x2e4;
                ppppfStack_414 = (float ****)&DAT_0040d7a4;
                ppppfStack_418 = (float ****)pppppfVar6;
                ppppfStack_420 = (float ****)0x47d663;
                ppppfStack_41c = (float ****)pppppfVar5;
                (*(code *)pppppfVar7)();
              }
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_410 = (float ****)&DAT_0050b570;
                ppppfStack_414 = (float ****)&DAT_004048dc;
                ppppfStack_418 = (float ****)0x47d678;
                (*pcVar15)();
              }
              ppppfStack_410 = (float ****)DAT_0050b570;
              ppppfStack_414 = (float ****)0x47d686;
              ppppfStack_414 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
              ppppfStack_418 = (float ****)&local_58;
              ppppfStack_41c = (float ****)0x47d691;
              pppppfVar5 = (float *****)__vbaObjSet();
              pppppfVar6 = (float *****)ppppfStack_3fc;
              if ((uVar17 & 0xd) == 0) {
                ppppfStack_408 = (float ****)0x47d6c2;
                ppppfStack_404 = (float ****)pppppfVar5;
                ppppfStack_400 = (float ****)((float)local_218 * (float)_DAT_00401418);
                pppppfVar6 = (float *****)(*(code *)(*pppppfVar5)[0x21])();
                if ((int)pppppfVar6 < 0) {
                  ppppfStack_408 = (float ****)0x84;
                  ppppfStack_40c = (float ****)&DAT_0040ba5c;
                  ppppfStack_418 = (float ****)0x47d6d6;
                  ppppfStack_414 = (float ****)pppppfVar6;
                  ppppfStack_410 = (float ****)pppppfVar5;
                  (*(code *)pppppfVar7)();
                }
                ppppfStack_408 = (float ****)0x47d6df;
                __vbaFreeObj();
                if (DAT_0050b570 == (float *****)0x0) {
                  ppppfStack_408 = (float ****)&DAT_0050b570;
                  ppppfStack_40c = (float ****)&DAT_004048dc;
                  ppppfStack_410 = (float ****)0x47d6f4;
                  (*pcVar15)();
                }
                ppppfStack_408 = (float ****)DAT_0050b570;
                ppppfStack_40c = (float ****)0x47d702;
                ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd0])();
                ppppfStack_410 = (float ****)&local_58;
                ppppfStack_414 = (float ****)0x47d70d;
                pppppfVar6 = (float *****)__vbaObjSet();
                ppppfStack_414 = (float ****)&local_218;
                ppppfStack_41c = (float ****)0x47d71c;
                ppppfStack_418 = (float ****)pppppfVar6;
                pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
                uVar17 = 0;
                if ((int)pppppfVar5 < 0) {
                  ppppfStack_41c = (float ****)0x78;
                  ppppfStack_420 = (float ****)&DAT_0040c3dc;
                  ppppfStack_42c = (float ****)0x47d72d;
                  ppppfStack_428 = (float ****)pppppfVar5;
                  ppppfStack_424 = (float ****)pppppfVar6;
                  (*(code *)pppppfVar7)();
                }
                if (DAT_0050b570 == (float *****)0x0) {
                  ppppfStack_41c = (float ****)&DAT_0050b570;
                  ppppfStack_420 = (float ****)&DAT_004048dc;
                  ppppfStack_424 = (float ****)0x47d742;
                  (*pcVar15)();
                }
                ppppfStack_41c = (float ****)DAT_0050b570;
                ppppfStack_420 = (float ****)0x47d750;
                ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                ppppfStack_424 = &local_5c;
                ppppfStack_428 = (float ****)0x47d75b;
                pppppfVar5 = (float *****)__vbaObjSet();
                ppppfVar12 = *pppppfVar5;
                pppppfVar6 = (float *****)ppppfStack_3fc;
                if ((uVar17 & 0xd) == 0) {
                  ppppfStack_400 = (float ****)0x47d781;
                  iVar3 = __vbaFpI4();
                  ppppfStack_400 = (float ****)(float)(iVar3 / 2);
                  ppppfStack_408 = (float ****)0x47d7a3;
                  ppppfStack_404 = (float ****)pppppfVar5;
                  ppppfStack_414 = (float ****)(*(code *)ppppfVar12[0x1f])();
                  if ((int)ppppfStack_414 < 0) {
                    ppppfStack_408 = (float ****)0x7c;
                    ppppfStack_40c = (float ****)&DAT_0040ba5c;
                    ppppfStack_418 = (float ****)0x47d7b4;
                    ppppfStack_410 = (float ****)pppppfVar5;
                    (*(code *)pppppfVar7)();
                  }
                  ppppfStack_408 = &local_5c;
                  ppppfStack_40c = (float ****)&local_58;
                  ppppfStack_410 = (float ****)0x2;
                  ppppfStack_414 = (float ****)0x47d7c4;
                  __vbaFreeObjList();
                  if (DAT_0050c53c == (float *****)0x0) {
                    ppppfStack_408 = (float ****)&DAT_0050c53c;
                    ppppfStack_40c = (float ****)&DAT_0040b420;
                    ppppfStack_410 = (float ****)0x47d7e0;
                    __vbaNew2();
                  }
                  pppppfVar6 = DAT_0050c53c;
                  ppppfStack_408 = (float ****)&local_58;
                  ppppfStack_40c = (float ****)DAT_0050c53c;
                  ppppfStack_410 = (float ****)0x47d7f0;
                  pppppfVar5 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
                  if ((int)pppppfVar5 < 0) {
                    ppppfStack_410 = (float ****)0x18;
                    ppppfStack_414 = (float ****)&DAT_0040b410;
                    ppppfStack_418 = (float ****)pppppfVar6;
                    ppppfStack_420 = (float ****)0x47d801;
                    ppppfStack_41c = (float ****)pppppfVar5;
                    (*(code *)pppppfVar7)();
                  }
                  ppppfVar12 = local_58;
                  ppppfStack_410 = (float ****)&local_218;
                  ppppfStack_414 = local_58;
                  ppppfStack_418 = (float ****)0x47d816;
                  pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
                  if ((int)pppppfVar6 < 0) {
                    ppppfStack_418 = (float ****)0x98;
                    ppppfStack_41c = (float ****)&DAT_0040bb5c;
                    ppppfStack_420 = ppppfVar12;
                    ppppfStack_428 = (float ****)0x47d82a;
                    ppppfStack_424 = (float ****)pppppfVar6;
                    (*(code *)pppppfVar7)();
                  }
                  if (DAT_0050b570 == (float *****)0x0) {
                    ppppfStack_418 = (float ****)&DAT_0050b570;
                    ppppfStack_41c = (float ****)&DAT_004048dc;
                    ppppfStack_420 = (float ****)0x47d843;
                    __vbaNew2();
                  }
                  ppppfStack_418 = (float ****)DAT_0050b570;
                  ppppfStack_41c = (float ****)0x47d851;
                  ppppfStack_41c = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                  ppppfStack_420 = &local_5c;
                  ppppfStack_424 = (float ****)0x47d85e;
                  pppppfVar6 = (float *****)__vbaObjSet();
                  ppppfStack_424 = &local_21c;
                  ppppfStack_42c = (float ****)0x47d870;
                  ppppfStack_428 = (float ****)pppppfVar6;
                  pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
                  uVar17 = 0;
                  if ((int)pppppfVar5 < 0) {
                    ppppfStack_42c = (float ****)0x80;
                    ppppfStack_430 = (float ****)&DAT_0040ba5c;
                    ppppfStack_43c = (float ****)0x47d884;
                    ppppfStack_438 = (float ****)pppppfVar5;
                    ppppfStack_434 = (float ****)pppppfVar6;
                    (*(code *)pppppfVar7)();
                  }
                  if (DAT_0050b570 == (float *****)0x0) {
                    ppppfStack_42c = (float ****)&DAT_0050b570;
                    ppppfStack_430 = (float ****)&DAT_004048dc;
                    ppppfStack_434 = (float ****)0x47d89d;
                    __vbaNew2();
                  }
                  ppppfStack_42c = (float ****)DAT_0050b570;
                  ppppfStack_430 = (float ****)0x47d8ab;
                  ppppfStack_430 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                  ppppfStack_434 = &local_60;
                  ppppfStack_438 = (float ****)0x47d8b2;
                  pppppfVar5 = (float *****)__vbaObjSet();
                  ppppfVar12 = *pppppfVar5;
                  pppppfVar6 = (float *****)ppppfStack_3fc;
                  if ((uVar17 & 0xd) == 0) {
                    ppppfStack_400 = (float ****)0x47d8d8;
                    iVar3 = __vbaFpI4();
                    ppppfStack_400 = (float ****)(float)(iVar3 / 2);
                    ppppfStack_408 = (float ****)0x47d8fa;
                    ppppfStack_404 = (float ****)pppppfVar5;
                    ppppfStack_414 = (float ****)(*(code *)ppppfVar12[0x1d])();
                    if ((int)ppppfStack_414 < 0) {
                      ppppfStack_408 = (float ****)0x74;
                      ppppfStack_40c = (float ****)&DAT_0040ba5c;
                      ppppfStack_418 = (float ****)0x47d90b;
                      ppppfStack_410 = (float ****)pppppfVar5;
                      (*(code *)pppppfVar7)();
                    }
                    ppppfStack_408 = &local_60;
                    ppppfStack_40c = &local_5c;
                    ppppfStack_410 = (float ****)&local_58;
                    ppppfStack_414 = (float ****)0x3;
                    ppppfStack_418 = (float ****)0x47d91f;
                    __vbaFreeObjList();
                    if (DAT_0050b570 == (float *****)0x0) {
                      ppppfStack_408 = (float ****)&DAT_0050b570;
                      ppppfStack_40c = (float ****)&DAT_004048dc;
                      ppppfStack_410 = (float ****)0x47d93b;
                      __vbaNew2();
                    }
                    ppppfStack_408 = (float ****)DAT_0050b570;
                    ppppfStack_40c = (float ****)0x47d949;
                    ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                    ppppfStack_410 = (float ****)&local_58;
                    ppppfStack_414 = (float ****)0x47d956;
                    pppppfVar6 = (float *****)__vbaObjSet();
                    ppppfStack_414 = (float ****)DAT_0050b34c;
                    ppppfStack_41c = (float ****)0x47d965;
                    ppppfStack_418 = (float ****)pppppfVar6;
                    pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
                    if ((int)pppppfVar5 < 0) {
                      ppppfStack_41c = (float ****)0x54;
                      ppppfStack_420 = (float ****)&DAT_0040ba5c;
                      ppppfStack_42c = (float ****)0x47d976;
                      ppppfStack_428 = (float ****)pppppfVar5;
                      ppppfStack_424 = (float ****)pppppfVar6;
                      (*(code *)pppppfVar7)();
                    }
                    ppppfStack_41c = (float ****)0x47d97f;
                    __vbaFreeObj();
                    if (DAT_0050b570 == (float *****)0x0) {
                      ppppfStack_41c = (float ****)&DAT_0050b570;
                      ppppfStack_420 = (float ****)&DAT_004048dc;
                      ppppfStack_424 = (float ****)0x47d998;
                      __vbaNew2();
                    }
                    ppppfStack_41c = (float ****)DAT_0050b570;
                    ppppfStack_420 = (float ****)0x47d9a6;
                    ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xbf])();
                    ppppfStack_424 = &local_5c;
                    ppppfStack_428 = (float ****)0x47d9ad;
                    pppppfVar6 = (float *****)__vbaObjSet();
                    ppppfStack_428 = &local_21c;
                    ppppfStack_430 = (float ****)0x47d9bf;
                    ppppfStack_42c = (float ****)pppppfVar6;
                    pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
                    if ((int)pppppfVar5 < 0) {
                      ppppfStack_430 = (float ****)0x88;
                      ppppfStack_434 = (float ****)&DAT_0040c3dc;
                      ppppfStack_440 = (float ****)0x47d9d3;
                      ppppfStack_43c = (float ****)pppppfVar5;
                      ppppfStack_438 = (float ****)pppppfVar6;
                      (*(code *)pppppfVar7)();
                    }
                    if (DAT_0050b570 == (float *****)0x0) {
                      ppppfStack_430 = (float ****)&DAT_0050b570;
                      ppppfStack_434 = (float ****)&DAT_004048dc;
                      ppppfStack_438 = (float ****)0x47d9ec;
                      __vbaNew2();
                    }
                    ppppfStack_430 = (float ****)DAT_0050b570;
                    ppppfStack_434 = (float ****)0x47d9fa;
                    ppppfStack_434 = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
                    ppppfStack_438 = (float ****)&local_58;
                    ppppfStack_43c = (float ****)0x47da01;
                    pppppfVar6 = (float *****)__vbaObjSet();
                    ppppfStack_43c = (float ****)&local_218;
                    ppppfStack_444 = (float ****)0x47da13;
                    ppppfStack_440 = (float ****)pppppfVar6;
                    pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
                    uVar17 = 0;
                    if ((int)pppppfVar5 < 0) {
                      ppppfStack_3fc = (float ****)0x88;
                      ppppfStack_400 = (float ****)&DAT_0040c908;
                      ppppfStack_40c = (float ****)0x47da27;
                      ppppfStack_408 = (float ****)pppppfVar5;
                      ppppfStack_404 = (float ****)pppppfVar6;
                      (*(code *)pppppfVar7)();
                    }
                    ppppfStack_3fc = local_24c;
                    pppppfVar6 = (float *****)ppppfStack_3fc;
                    if ((uVar17 & 0xd) == 0) {
                      ppppfStack_400 = local_24c;
                      ppppfStack_404 = (float ****)0x47da73;
                      ppppfStack_3fc =
                           (float ****)
                           (((float)local_218 - (float)local_1c) -
                           (float)local_21c * (float)_DAT_004016e0);
                      ppppfStack_410 = (float ****)(*(code *)(*local_24c)[0x21])();
                      if ((int)ppppfStack_410 < 0) {
                        ppppfStack_404 = (float ****)0x84;
                        ppppfStack_408 = (float ****)&DAT_0040c8f8;
                        ppppfStack_40c = local_24c;
                        ppppfStack_414 = (float ****)0x47da8d;
                        (*(code *)pppppfVar7)();
                      }
                      ppppfStack_404 = &local_5c;
                      ppppfStack_408 = (float ****)&local_58;
                      ppppfStack_40c = (float ****)0x2;
                      ppppfStack_410 = (float ****)0x47da9d;
                      __vbaFreeObjList();
                      ppppfStack_404 = &local_21c;
                      ppppfStack_408 = local_24c;
                      ppppfStack_40c = (float ****)0x47dab6;
                      pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x20])();
                      if ((int)pppppfVar6 < 0) {
                        ppppfStack_40c = (float ****)0x80;
                        ppppfStack_410 = (float ****)&DAT_0040c8f8;
                        ppppfStack_414 = local_24c;
                        ppppfStack_41c = (float ****)0x47dad0;
                        ppppfStack_418 = (float ****)pppppfVar6;
                        (*(code *)pppppfVar7)();
                      }
                      if (DAT_0050b570 == (float *****)0x0) {
                        ppppfStack_40c = (float ****)&DAT_0050b570;
                        ppppfStack_410 = (float ****)&DAT_004048dc;
                        ppppfStack_414 = (float ****)0x47dae9;
                        __vbaNew2();
                      }
                      ppppfStack_40c = (float ****)DAT_0050b570;
                      ppppfStack_410 = (float ****)0x47daf7;
                      ppppfStack_410 = (float ****)(*(code *)(*DAT_0050b570)[0xbf])();
                      ppppfStack_414 = (float ****)&local_58;
                      ppppfStack_418 = (float ****)0x47dafe;
                      pppppfVar5 = (float *****)__vbaObjSet();
                      ppppfStack_418 = (float ****)&local_218;
                      ppppfStack_41c = local_24c;
                      ppppfStack_420 = (float ****)0x47db13;
                      pppppfVar8 = (float *****)(*(code *)(*local_24c)[0x1c])();
                      uVar17 = 0;
                      pppppfVar6 = extraout_ECX_04;
                      if ((int)pppppfVar8 < 0) {
                        ppppfStack_3fc = (float ****)0x70;
                        ppppfStack_400 = (float ****)&DAT_0040c8f8;
                        ppppfStack_404 = local_24c;
                        ppppfStack_40c = (float ****)0x47db2a;
                        ppppfStack_408 = (float ****)pppppfVar8;
                        (*(code *)pppppfVar7)();
                        pppppfVar6 = extraout_ECX_05;
                      }
                      ppppfStack_3fc = (float ****)((float)local_21c + (float)local_218);
                      if ((uVar17 & 0xd) == 0) {
                        ppppfStack_404 = (float ****)0x47db4a;
                        ppppfStack_400 = (float ****)pppppfVar5;
                        pppppfVar6 = (float *****)(*(code *)(*pppppfVar5)[0x1f])();
                        if ((int)pppppfVar6 < 0) {
                          ppppfStack_404 = (float ****)0x7c;
                          ppppfStack_408 = (float ****)&DAT_0040c3dc;
                          ppppfStack_414 = (float ****)0x47db5b;
                          ppppfStack_410 = (float ****)pppppfVar6;
                          ppppfStack_40c = (float ****)pppppfVar5;
                          (*(code *)pppppfVar7)();
                        }
                        ppppfStack_404 = (float ****)0x47db64;
                        __vbaFreeObj();
                        if (DAT_0050b570 == (float *****)0x0) {
                          ppppfStack_404 = (float ****)&DAT_0050b570;
                          ppppfStack_408 = (float ****)&DAT_004048dc;
                          ppppfStack_40c = (float ****)0x47db7d;
                          __vbaNew2();
                        }
                        ppppfStack_404 = (float ****)DAT_0050b570;
                        ppppfStack_408 = (float ****)0x47db8b;
                        ppppfStack_408 = (float ****)(*(code *)(*DAT_0050b570)[0xbf])();
                        ppppfStack_40c = (float ****)&local_58;
                        ppppfStack_410 = (float ****)0x47db92;
                        pppppfVar6 = (float *****)__vbaObjSet();
                        ppppfStack_410 = (float ****)&local_218;
                        ppppfStack_414 = local_24c;
                        ppppfStack_418 = (float ****)0x47dba7;
                        pppppfVar5 = (float *****)(*(code *)(*local_24c)[0x1e])();
                        if ((int)pppppfVar5 < 0) {
                          ppppfStack_418 = (float ****)0x78;
                          ppppfStack_41c = (float ****)&DAT_0040c8f8;
                          ppppfStack_420 = local_24c;
                          ppppfStack_428 = (float ****)0x47dbbe;
                          ppppfStack_424 = (float ****)pppppfVar5;
                          (*(code *)pppppfVar7)();
                        }
                        ppppfStack_418 = local_218;
                        ppppfStack_420 = (float ****)0x47dbce;
                        ppppfStack_41c = (float ****)pppppfVar6;
                        pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x21])();
                        if ((int)pppppfVar5 < 0) {
                          ppppfStack_420 = (float ****)0x84;
                          ppppfStack_424 = (float ****)&DAT_0040c3dc;
                          ppppfStack_430 = (float ****)0x47dbe2;
                          ppppfStack_42c = (float ****)pppppfVar5;
                          ppppfStack_428 = (float ****)pppppfVar6;
                          (*(code *)pppppfVar7)();
                        }
                        ppppfStack_420 = (float ****)0x47dbeb;
                        __vbaFreeObj();
                        if (DAT_0050b570 == (float *****)0x0) {
                          ppppfStack_420 = (float ****)&DAT_0050b570;
                          ppppfStack_424 = (float ****)&DAT_004048dc;
                          ppppfStack_428 = (float ****)0x47dc04;
                          __vbaNew2();
                        }
                        ppppfStack_420 = (float ****)DAT_0050b570;
                        ppppfStack_424 = (float ****)0x47dc12;
                        ppppfStack_424 = (float ****)(*(code *)(*DAT_0050b570)[0xbf])();
                        ppppfStack_428 = (float ****)&local_58;
                        ppppfStack_42c = (float ****)0x47dc19;
                        pppppfVar6 = (float *****)__vbaObjSet();
                        ppppfStack_42c = (float ****)&local_218;
                        ppppfStack_430 = local_24c;
                        ppppfStack_434 = (float ****)0x47dc2e;
                        pppppfVar5 = (float *****)(*(code *)(*local_24c)[0x1a])();
                        if ((int)pppppfVar5 < 0) {
                          ppppfStack_434 = (float ****)0x68;
                          ppppfStack_438 = (float ****)&DAT_0040c8f8;
                          ppppfStack_43c = local_24c;
                          ppppfStack_444 = (float ****)0x47dc45;
                          ppppfStack_440 = (float ****)pppppfVar5;
                          (*(code *)pppppfVar7)();
                        }
                        ppppfStack_434 = local_218;
                        ppppfStack_43c = (float ****)0x47dc52;
                        ppppfStack_438 = (float ****)pppppfVar6;
                        pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x1d])();
                        if ((int)pppppfVar5 < 0) {
                          ppppfStack_43c = (float ****)0x74;
                          ppppfStack_440 = (float ****)&DAT_0040c3dc;
                          ppppfStack_44c = (float ****)0x47dc63;
                          ppppfStack_448 = (float ****)pppppfVar5;
                          ppppfStack_444 = (float ****)pppppfVar6;
                          (*(code *)pppppfVar7)();
                        }
                        ppppfStack_43c = (float ****)0x47dc6c;
                        __vbaFreeObj();
                        local_174 = (float ****)0xa;
                        ppppfStack_448 = (float ****)0xa;
                        local_16c = (float ****)0x80020004;
                        ppppfStack_444 = local_170;
                        ppppfStack_440 = (float ****)0x80020004;
                        ppppfStack_43c = local_168;
                        ppppfStack_44c = *(float *****)(DAT_0050b37c + 4);
                        ppppfStack_450 = local_24c;
                        ppppfStack_454 = (float ****)0x47dcb7;
                        ppppfStack_460 = (float ****)(*(code *)(*local_24c)[0x7b])();
                        if ((int)ppppfStack_460 < 0) {
                          ppppfStack_454 = (float ****)0x1ec;
                          ppppfStack_458 = (float ****)&DAT_0040c8f8;
                          ppppfStack_45c = local_24c;
                          ppppfStack_464 = (float ****)0x47dcd1;
                          (*(code *)pppppfVar7)();
                        }
                        local_174 = (float ****)0xa;
                        ppppfStack_460 = (float ****)0xa;
                        local_16c = (float ****)0x80020004;
                        ppppfStack_45c = local_170;
                        ppppfStack_464 = (float ****)&DAT_0040ca6c;
                        ppppfStack_468 = local_24c;
                        ppppfStack_458 = (float ****)0x80020004;
                        ppppfStack_454 = local_168;
                        ppppfStack_46c = (float ****)0x47dd17;
                        pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x7b])();
                        if ((int)pppppfVar6 < 0) {
                          ppppfStack_46c = (float ****)0x1ec;
                          ppppfStack_470 = (float ****)&DAT_0040c8f8;
                          ppppfStack_474 = local_24c;
                          ppppfStack_47c = (float ****)0x47dd31;
                          ppppfStack_478 = (float ****)pppppfVar6;
                          (*(code *)pppppfVar7)();
                        }
                        ppppfStack_46c = (float ****)0x47dd36;
                        FUN_0044fdc0();
                        ppppfStack_46c = (float ****)0x47dd41;
                        __vbaStrMove();
                        local_6c = local_48;
                        ppppfStack_470 = &local_30;
                        ppppfStack_46c = (float ****)DAT_0050b0b8;
                        local_48 = (float ***)0x0;
                        local_74[0] = (float ***)0x8;
                        ppppfStack_474 = (float ****)0x47dd66;
                        __vbaAryLock();
                        if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 2))
                        {
                          ppppfStack_474 = (float ****)0x47ddba;
                          iVar3 = __vbaGenerateBoundsError();
                        }
                        else {
                          pppfVar16 = (float ***)local_30[7];
                          if (local_30[6] <= (float ***)(2U - (int)pppfVar16)) {
                            ppppfStack_474 = (float ****)0x47dd8a;
                            __vbaGenerateBoundsError();
                          }
                          pppfVar1 = (float ***)local_30[5];
                          if (local_30[4] <= (float ***)(1U - (int)pppfVar1)) {
                            ppppfStack_474 = (float ****)0x47dda4;
                            __vbaGenerateBoundsError();
                          }
                          iVar3 = (int)((int)local_30[6] * (int)(1U - (int)pppfVar1) +
                                       (int)(2U - (int)pppfVar16)) * 8;
                        }
                        ppppfStack_474 = (float ****)&DAT_00000001;
                        local_16c = (float ****)((int)local_30[3] + iVar3);
                        ppppfStack_47c = local_74;
                        ppppfStack_478 = (float ****)&DAT_00000001;
                        ppppfStack_480 = (float ****)&local_174;
                        ppppfStack_484 = local_84;
                        local_174 = (float ****)0x4005;
                        ppppfStack_488 = (float ****)0x47ddeb;
                        Ordinal_660();
                        ppppfStack_488 = &local_30;
                        ppppfStack_48c = (float ****)0x47ddf5;
                        __vbaAryUnlock();
                        ppppfStack_48c = (float ****)0x47ddfa;
                        FUN_0044fdc0();
                        ppppfStack_48c = (float ****)0x47de05;
                        __vbaStrMove();
                        ppppfStack_490 = &local_34;
                        local_bc = (double)CONCAT44(local_bc._4_4_,local_4c);
                        ppppfStack_48c = (float ****)DAT_0050b0b8;
                        local_4c = (float ***)0x0;
                        local_c4[0] = (float ***)0x8;
                        ppppfStack_494 = (float ****)0x47de2f;
                        __vbaAryLock();
                        if (((float ****)local_34 == (float ****)0x0) || (*(short *)local_34 != 2))
                        {
                          ppppfStack_494 = (float ****)0x47de83;
                          iVar3 = __vbaGenerateBoundsError();
                        }
                        else {
                          pppfVar16 = (float ***)local_34[7];
                          if (local_34[6] <= (float ***)(2U - (int)pppfVar16)) {
                            ppppfStack_494 = (float ****)0x47de53;
                            __vbaGenerateBoundsError();
                          }
                          pppfVar1 = (float ***)local_34[5];
                          if (local_34[4] <= (float ***)(2U - (int)pppfVar1)) {
                            ppppfStack_494 = (float ****)0x47de6d;
                            __vbaGenerateBoundsError();
                          }
                          iVar3 = (int)((int)local_34[6] * (int)(2U - (int)pppfVar1) +
                                       (int)(2U - (int)pppfVar16)) * 8;
                        }
                        ppppfStack_494 = (float ****)&DAT_00000001;
                        local_18c = (float ****)((int)local_34[3] + iVar3);
                        pppfStack_49c = (float ***)local_c4;
                        ppppfStack_498 = (float ****)&DAT_00000001;
                        ppppfStack_4a0 = (float ****)&local_194;
                        ppppfStack_4a4 = local_d4;
                        local_194 = (float ****)0x4005;
                        pppfStack_4a8 = (float ***)0x47deba;
                        Ordinal_660();
                        pppfStack_4a8 = (float ***)&local_34;
                        ppppfStack_4ac = (float ****)0x47dec4;
                        __vbaAryUnlock();
                        ppppfStack_4ac = (float ****)&DAT_0040c80c;
                        ppppfStack_4b0 = (float ****)&DAT_0050b354;
                        ppppfStack_4b4 = (float ****)0x8;
                        local_1ac = (float ***)0x80020004;
                        local_1b4 = (float ****)0xa;
                        ppppfStack_4b8 = (float ****)0x47deea;
                        __vbaStrFixstr();
                        ppppfStack_4b8 = (float ****)0x47def7;
                        ppppfStack_4b8 = (float ****)__vbaStrMove();
                        pppppfVar5 = (float *****)__vbaStrCat_exref;
                        ppppfStack_4bc = (float ****)0x47df00;
                        __vbaStrCat();
                        ppppfStack_4bc = (float ****)0x47df07;
                        ppppfStack_4bc = (float ****)__vbaStrMove();
                        ppppfStack_4c0 = (float ****)0x410114;
                        ppppfStack_4c4 = (float ****)0x47df0f;
                        local_8c = __vbaStrCat();
                        local_94[0] = (float ***)0x8;
                        local_184 = (float ***)0x8;
                        local_1a4[0] = (float ***)0x8;
                        local_17c = L"x1 +";
                        local_19c = L"x2";
                        ppppfVar12 = (float ****)*local_24c;
                        ppppfStack_4d0 = local_1b4;
                        ppppfStack_4cc = local_1b0;
                        ppppfStack_4c8 = (float ****)local_1ac;
                        ppppfStack_4d8 = local_84;
                        ppppfStack_4c4 = local_1a8;
                        ppppfStack_4d4 = local_94;
                        pppfStack_4dc = (float ***)local_a4;
                        uVar13 = __vbaVarCat();
                        uVar13 = __vbaVarCat(local_b4,&local_184,uVar13);
                        uVar13 = __vbaVarCat(local_e4,local_d4,uVar13);
                        uVar13 = __vbaVarCat(local_f4,local_1a4,uVar13);
                        uVar13 = __vbaStrVarVal(&local_44,uVar13);
                        iVar3 = (*(code *)ppppfVar12[0x7b])(local_24c,uVar13);
                        if (iVar3 < 0) {
                          (*(code *)pppppfVar7)(iVar3,local_24c,&DAT_0040c8f8,0x1ec);
                        }
                        __vbaFreeStrList(5,&local_3c,&local_40,&local_44,&local_48,&local_4c);
                        __vbaFreeVarList(9,local_74,local_94,local_84,local_a4,local_c4,local_b4,
                                         local_d4,local_e4,local_f4);
                        local_174 = (float ****)0xa;
                        local_16c = (float ****)0x80020004;
                        iVar3 = (*(code *)(*local_24c)[0x7b])
                                          (local_24c,&DAT_0040c80c,10,local_170,0x80020004,local_168
                                          );
                        if (iVar3 < 0) {
                          __vbaHresultCheckObj(iVar3,local_24c,&DAT_0040c8f8,0x1ec);
                        }
                        local_174 = (float ****)0xa;
                        local_16c = (float ****)0x80020004;
                        iVar3 = (*(code *)(*local_24c)[0x7b])
                                          (local_24c,L" subject to",10,local_170,0x80020004,
                                           local_168);
                        if (iVar3 < 0) {
                          __vbaHresultCheckObj(iVar3,local_24c,&DAT_0040c8f8,0x1ec);
                        }
                        local_174 = (float ****)0xa;
                        local_16c = (float ****)0x80020004;
                        iVar3 = (*(code *)(*local_24c)[0x7b])
                                          (local_24c,&DAT_0040c80c,10,local_170,0x80020004,local_168
                                          );
                        pppppfVar6 = (float *****)__vbaHresultCheckObj_exref;
                        if (iVar3 < 0) {
                          __vbaHresultCheckObj(iVar3,local_24c,&DAT_0040c8f8,0x1ec);
                        }
                        local_16c = (float ****)&DAT_0040facc;
                        local_174 = (float ****)0x8;
                        __vbaVarDup();
                        Ordinal_606((int)(short)local_2c,local_74);
                        pppppfVar7 = (float *****)__vbaStrMove_exref;
                        __vbaStrMove();
                        __vbaFreeVar();
                        uVar13 = _DAT_0050b20c;
                        local_20 = (float ***)0x1;
                        ppppfVar12 = (float ****)local_20;
                        do {
                          local_20 = (float ***)ppppfVar12;
                          local_264 = (short)uVar13;
                          if (local_264 < (short)local_20) {
                            local_174 = (float ****)0xa;
                            ppppfStack_40c = (float ****)0xa;
                            local_16c = (float ****)0x80020004;
                            ppppfStack_408 = local_170;
                            ppppfStack_410 = (float ****)&DAT_0040c80c;
                            ppppfStack_414 = local_24c;
                            ppppfStack_404 = (float ****)0x80020004;
                            ppppfStack_400 = local_168;
                            ppppfStack_418 = (float ****)0x47e81d;
                            ppppfStack_424 = (float ****)(*(code *)(*local_24c)[0x7b])();
                            if ((int)ppppfStack_424 < 0) {
                              ppppfStack_418 = (float ****)0x1ec;
                              ppppfStack_41c = (float ****)&DAT_0040c8f8;
                              ppppfStack_420 = local_24c;
                              ppppfStack_428 = (float ****)0x47e837;
                              (*(code *)pppppfVar6)();
                            }
                            local_174 = (float ****)0xa;
                            ppppfStack_424 = (float ****)0xa;
                            local_16c = (float ****)0x80020004;
                            ppppfStack_420 = local_170;
                            ppppfStack_428 = (float ****)0x410324;
                            ppppfStack_42c = local_24c;
                            ppppfStack_41c = (float ****)0x80020004;
                            ppppfStack_418 = local_168;
                            ppppfStack_430 = (float ****)0x47e87d;
                            ppppfStack_43c = (float ****)(*(code *)(*local_24c)[0x7b])();
                            if ((int)ppppfStack_43c < 0) {
                              ppppfStack_430 = (float ****)0x1ec;
                              ppppfStack_434 = (float ****)&DAT_0040c8f8;
                              ppppfStack_438 = local_24c;
                              ppppfStack_440 = (float ****)0x47e897;
                              (*(code *)pppppfVar6)();
                            }
                            local_174 = (float ****)0xa;
                            ppppfStack_43c = (float ****)0xa;
                            local_16c = (float ****)0x80020004;
                            ppppfStack_438 = local_170;
                            ppppfStack_440 = (float ****)&DAT_0040ca6c;
                            ppppfStack_444 = local_24c;
                            ppppfStack_434 = (float ****)0x80020004;
                            ppppfStack_430 = local_168;
                            ppppfStack_448 = (float ****)0x47e8dd;
                            ppppfStack_454 = (float ****)(*(code *)(*local_24c)[0x7b])();
                            if ((int)ppppfStack_454 < 0) {
                              ppppfStack_448 = (float ****)0x1ec;
                              ppppfStack_44c = (float ****)&DAT_0040c8f8;
                              ppppfStack_450 = local_24c;
                              ppppfStack_458 = (float ****)0x47e8f7;
                              (*(code *)pppppfVar6)();
                            }
                            local_174 = (float ****)0xa;
                            ppppfStack_454 = (float ****)0xa;
                            local_16c = (float ****)0x80020004;
                            ppppfStack_450 = local_170;
                            ppppfStack_458 = (float ****)0x410354;
                            ppppfStack_45c = local_24c;
                            ppppfStack_44c = (float ****)0x80020004;
                            ppppfStack_448 = local_168;
                            ppppfStack_460 = (float ****)0x47e93d;
                            pppppfVar5 = (float *****)(*(code *)(*local_24c)[0x7b])();
                            if ((int)pppppfVar5 < 0) {
                              ppppfStack_400 = (float ****)0x1ec;
                              ppppfStack_404 = (float ****)&DAT_0040c8f8;
                              ppppfStack_408 = local_24c;
                              ppppfStack_410 = (float ****)0x47e957;
                              ppppfStack_40c = (float ****)pppppfVar5;
                              (*(code *)pppppfVar6)();
                            }
                            goto LAB_0047e957;
                          }
                          if ((DAT_0050b398 == (short *)0x0) || (*DAT_0050b398 != 1)) {
                            ppppfStack_400 = (float ****)0x47e231;
                            iVar3 = __vbaGenerateBoundsError();
                          }
                          else {
                            pppppfVar6 = (float *****)
                                         ((int)(short)local_20 - *(int *)(DAT_0050b398 + 10));
                            if (*(float ******)(DAT_0050b398 + 8) <= pppppfVar6) {
                              ppppfStack_400 = (float ****)0x47e220;
                              __vbaGenerateBoundsError();
                            }
                            iVar3 = (int)pppppfVar6 * 2;
                          }
                          ppppfStack_400 = (float ****)(*(int *)(DAT_0050b398 + 6) + iVar3);
                          ppppfStack_404 = (float ****)&DAT_00000001;
                          ppppfStack_408 = (float ****)0x47e245;
                          __vbaStrFixstr();
                          ppppfStack_408 = (float ****)0x47e24e;
                          (*(code *)pppppfVar7)();
                          ppppfStack_408 = (float ****)DAT_0050b34c;
                          ppppfStack_40c = (float ****)&DAT_0040cb48;
                          ppppfStack_410 = (float ****)0x47e25f;
                          iVar3 = __vbaStrCmp();
                          if (iVar3 == 0) {
                            ppppfStack_414 = (float ****)&DAT_0040c80c;
                          }
                          else {
                            ppppfStack_414 = (float ****)&DAT_0040cb48;
                          }
                          ppppfStack_410 = (float ****)DAT_0050b34c;
                          ppppfStack_418 = (float ****)0x47e27f;
                          (*(code *)pppppfVar5)();
                          ppppfStack_418 = (float ****)0x47e288;
                          (*(code *)pppppfVar7)();
                          ppppfStack_418 = (float ****)&local_174;
                          local_16c = &local_20;
                          local_174 = (float ****)0x4002;
                          ppppfStack_41c = (float ****)0x47e2a8;
                          Ordinal_536();
                          ppppfStack_41c = (float ****)0x47e2af;
                          (*(code *)pppppfVar7)();
                          ppppfStack_41c = (float ****)0x47e2b4;
                          FUN_0044fdc0();
                          ppppfStack_41c = (float ****)0x47e2bb;
                          (*(code *)pppppfVar7)();
                          local_6c = local_4c;
                          ppppfStack_420 = &local_30;
                          ppppfStack_41c = (float ****)DAT_0050b0b8;
                          local_4c = (float ***)0x0;
                          local_74[0] = (float ***)0x8;
                          ppppfStack_424 = (float ****)0x47e2e0;
                          __vbaAryLock();
                          if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 2)
                             ) {
                            ppppfStack_400 = (float ****)0x47e344;
                            iVar3 = __vbaGenerateBoundsError();
                          }
                          else {
                            pppppfVar8 = pppppfVar6;
                            if (SCARRY2((short)local_20,2)) break;
                            pppfVar16 = (float ***)
                                        ((int)(short)((short)local_20 + 2) - (int)local_30[7]);
                            if (local_30[6] <= pppfVar16) {
                              ppppfStack_400 = (float ****)0x47e30e;
                              __vbaGenerateBoundsError();
                            }
                            pppppfVar6 = (float *****)(1 - (int)local_30[5]);
                            if (local_30[4] <= pppppfVar6) {
                              ppppfStack_400 = (float ****)0x47e328;
                              __vbaGenerateBoundsError();
                            }
                            iVar3 = (int)((int)local_30[6] * (int)pppppfVar6 + (int)pppfVar16) * 8;
                            pppppfVar7 = (float *****)__vbaStrMove_exref;
                          }
                          pppppfVar5 = (float *****)Ordinal_660_exref;
                          local_17c = (wchar_t *)((int)local_30[3] + iVar3);
                          ppppfStack_400 = (float ****)0x1;
                          ppppfStack_408 = local_74;
                          ppppfStack_404 = (float ****)&DAT_00000001;
                          ppppfStack_40c = &local_184;
                          ppppfStack_410 = local_84;
                          local_184 = (float ***)0x4005;
                          ppppfStack_414 = (float ****)0x47e377;
                          Ordinal_660();
                          ppppfStack_414 = &local_30;
                          ppppfStack_418 = (float ****)0x47e381;
                          __vbaAryUnlock();
                          ppppfStack_418 = (float ****)&DAT_00000001;
                          ppppfStack_420 = (float ****)&local_194;
                          ppppfStack_41c = (float ****)&DAT_00000001;
                          ppppfStack_424 = local_84;
                          ppppfStack_428 = local_94;
                          local_18c = (float ****)&DAT_0050b348;
                          local_194 = (float ****)0x4008;
                          ppppfStack_42c = (float ****)0x47e3ad;
                          Ordinal_660();
                          ppppfStack_42c = (float ****)0x47e3b2;
                          FUN_0044fdc0();
                          ppppfStack_42c = (float ****)0x47e3b9;
                          (*(code *)pppppfVar7)();
                          ppppfStack_430 = &local_34;
                          local_cc = local_50;
                          ppppfStack_42c = (float ****)DAT_0050b0b8;
                          local_50 = (float ***)0x0;
                          local_d4[0] = (float ***)0x8;
                          ppppfStack_434 = (float ****)0x47e3e3;
                          __vbaAryLock();
                          pppppfVar8 = (float *****)__vbaGenerateBoundsError_exref;
                          if (((float ****)local_34 == (float ****)0x0) || (*(short *)local_34 != 2)
                             ) {
                            ppppfStack_400 = (float ****)0x47e44f;
                            iVar3 = __vbaGenerateBoundsError();
                          }
                          else {
                            pppppfVar8 = pppppfVar6;
                            if (SCARRY2((short)local_20,2)) break;
                            pppfVar16 = (float ***)
                                        ((int)(short)((short)local_20 + 2) - (int)local_34[7]);
                            if (local_34[6] <= pppfVar16) {
                              ppppfStack_400 = (float ****)0x47e411;
                              __vbaGenerateBoundsError();
                            }
                            pppfVar1 = (float ***)local_34[5];
                            if (local_34[4] <= (float ***)(2U - (int)pppfVar1)) {
                              ppppfStack_400 = (float ****)0x47e42b;
                              __vbaGenerateBoundsError();
                            }
                            iVar3 = (int)((int)local_34[6] * (int)(2U - (int)pppfVar1) +
                                         (int)pppfVar16) * 8;
                            pppppfVar8 = (float *****)__vbaGenerateBoundsError_exref;
                            pppppfVar7 = (float *****)__vbaStrMove_exref;
                          }
                          ppppfStack_400 = (float ****)0x1;
                          local_1ac = (float ***)((int)local_34[3] + iVar3);
                          ppppfStack_408 = local_d4;
                          ppppfStack_404 = (float ****)&DAT_00000001;
                          ppppfStack_40c = (float ****)&local_1b4;
                          ppppfStack_410 = local_e4;
                          local_1b4 = (float ****)0x4005;
                          ppppfStack_414 = (float ****)0x47e482;
                          Ordinal_660();
                          ppppfStack_414 = &local_34;
                          ppppfStack_418 = (float ****)0x47e48c;
                          __vbaAryUnlock();
                          ppppfStack_418 = (float ****)&DAT_00000001;
                          ppppfStack_420 = (float ****)&local_1c4;
                          ppppfStack_41c = (float ****)&DAT_00000001;
                          ppppfStack_424 = local_e4;
                          ppppfStack_428 = local_f4;
                          local_1bc = (float ****)&DAT_0050b348;
                          local_1c4 = (float ****)0x4008;
                          ppppfStack_42c = (float ****)0x47e4bb;
                          Ordinal_660();
                          ppppfStack_42c = (float ****)0x47e4c0;
                          FUN_0044fdc0();
                          ppppfStack_42c = (float ****)0x47e4c7;
                          (*(code *)pppppfVar7)();
                          ppppfStack_430 = &local_38;
                          local_12c = local_54;
                          ppppfStack_42c = (float ****)DAT_0050b0b8;
                          local_54 = (float ***)0x0;
                          local_134[0] = (float ***)0x8;
                          ppppfStack_434 = (float ****)0x47e4f1;
                          __vbaAryLock();
                          if (((float ****)local_38 == (float ****)0x0) || (*(short *)local_38 != 2)
                             ) {
                            ppppfStack_400 = (float ****)0x47e555;
                            local_1ec = (*(code *)pppppfVar8)();
                          }
                          else {
                            if (SCARRY2((short)local_20,2)) break;
                            pppppfVar7 = (float *****)
                                         ((int)(short)((short)local_20 + 2) - (int)local_38[7]);
                            if (local_38[6] <= pppppfVar7) {
                              ppppfStack_400 = (float ****)0x47e51b;
                              (*(code *)pppppfVar8)();
                            }
                            if (SCARRY2(DAT_0050b20a,2)) break;
                            pppfVar16 = (float ***)
                                        ((int)(short)(DAT_0050b20a + 2) - (int)local_38[5]);
                            if (local_38[4] <= pppfVar16) {
                              ppppfStack_400 = (float ****)0x47e543;
                              __vbaGenerateBoundsError();
                            }
                            local_1ec = (int)((int)pppppfVar7 + (int)local_38[6] * (int)pppfVar16) *
                                        8;
                          }
                          local_1ec = (int)local_38[3] + local_1ec;
                          ppppfStack_400 = (float ****)0x1;
                          ppppfStack_408 = local_134;
                          ppppfStack_404 = (float ****)&DAT_00000001;
                          ppppfStack_40c = local_1f4;
                          ppppfStack_410 = local_144;
                          local_1f4[0] = (float ***)0x4005;
                          ppppfStack_414 = (float ****)0x47e58e;
                          Ordinal_660();
                          ppppfStack_414 = &local_38;
                          ppppfStack_418 = (float ****)0x47e598;
                          __vbaAryUnlock();
                          ppppfStack_418 = (float ****)&DAT_00000001;
                          ppppfStack_420 = local_204;
                          ppppfStack_41c = (float ****)&DAT_00000001;
                          ppppfStack_424 = local_144;
                          ppppfStack_428 = local_154;
                          local_1fc = &DAT_0050b348;
                          local_204[0] = (float ***)0x4008;
                          ppppfStack_42c = (float ****)0x47e5c7;
                          Ordinal_660();
                          ppppfStack_42c = (float ****)&DAT_0040f99c;
                          local_48 = (float ***)0x0;
                          ppppfStack_430 = (float ****)0x47e5e9;
                          ppppfStack_430 = (float ****)__vbaStrMove();
                          ppppfStack_434 = (float ****)0x47e5f2;
                          __vbaStrCat();
                          ppppfStack_434 = (float ****)0x47e5fd;
                          ppppfStack_434 = (float ****)__vbaStrMove();
                          ppppfStack_438 = (float ****)&DAT_0040ca64;
                          ppppfStack_43c = (float ****)0x47e605;
                          local_9c = __vbaStrCat();
                          local_a4[0] = (float ***)0x8;
                          local_1a4[0] = (float ***)0x8;
                          local_1d4[0] = (float ***)0x8;
                          local_1e4[0] = (float ***)0x8;
                          local_1dc = (float ****)DAT_0050b34c;
                          ppppfStack_448 = (float ****)0xa;
                          local_19c = L"x1 +";
                          local_1cc = &DAT_00410134;
                          ppppfVar12 = (float ****)*local_24c;
                          ppppfStack_444 = local_210;
                          ppppfStack_450 = local_94;
                          ppppfStack_440 = (float ****)0x80020004;
                          ppppfStack_43c = local_208;
                          ppppfStack_44c = local_a4;
                          ppppfStack_454 = local_b4;
                          ppppfStack_458 = (float ****)0x47e689;
                          ppppfStack_458 = (float ****)__vbaVarCat();
                          ppppfStack_45c = local_1a4;
                          ppppfStack_460 = local_c4;
                          ppppfStack_464 = (float ****)0x47e69a;
                          ppppfStack_464 = (float ****)__vbaVarCat();
                          ppppfStack_468 = local_f4;
                          ppppfStack_46c = local_104;
                          ppppfStack_470 = (float ****)0x47e6ab;
                          ppppfStack_470 = (float ****)__vbaVarCat();
                          ppppfStack_474 = local_1d4;
                          ppppfStack_478 = local_114;
                          ppppfStack_47c = (float ****)0x47e6bc;
                          ppppfStack_47c = (float ****)__vbaVarCat();
                          ppppfStack_480 = local_1e4;
                          ppppfStack_484 = local_124;
                          ppppfStack_488 = (float ****)0x47e6cd;
                          ppppfStack_488 = (float ****)__vbaVarCat();
                          ppppfStack_48c = local_154;
                          ppppfStack_490 = local_164;
                          ppppfStack_494 = (float ****)0x47e6de;
                          ppppfStack_494 = (float ****)__vbaVarCat();
                          ppppfStack_498 = &local_44;
                          pppfStack_49c = (float ***)0x47e6e9;
                          pppfStack_49c = (float ***)__vbaStrVarVal();
                          ppppfStack_4a0 = local_24c;
                          ppppfStack_4a4 = (float ****)0x47e6f7;
                          ppppfStack_4b0 = (float ****)(*(code *)ppppfVar12[0x7b])();
                          if ((int)ppppfStack_4b0 < 0) {
                            ppppfStack_4a4 = (float ****)0x1ec;
                            pppfStack_4a8 = (float ***)&DAT_0040c8f8;
                            ppppfStack_4ac = local_24c;
                            ppppfStack_4b4 = (float ****)0x47e715;
                            __vbaHresultCheckObj();
                          }
                          ppppfStack_4a4 = &local_54;
                          pppfStack_4a8 = (float ***)&local_50;
                          ppppfStack_4ac = &local_4c;
                          ppppfStack_4b0 = &local_48;
                          ppppfStack_4b4 = &local_44;
                          ppppfStack_4b8 = &local_40;
                          ppppfStack_4bc = &local_3c;
                          ppppfStack_4c0 = (float ****)0x7;
                          ppppfStack_4c4 = (float ****)0x47e739;
                          __vbaFreeStrList();
                          ppppfStack_4c4 = local_164;
                          ppppfStack_4c8 = local_154;
                          ppppfStack_4cc = local_124;
                          ppppfStack_4d0 = local_144;
                          ppppfStack_4d4 = local_134;
                          ppppfStack_4d8 = local_114;
                          pppfStack_4dc = (float ***)local_104;
                          __vbaFreeVarList(0x10,local_74,local_84,local_a4,local_94,local_b4,
                                           local_d4,local_e4,local_c4,local_f4);
                          pppppfVar5 = (float *****)__vbaStrCat_exref;
                          pppppfVar8 = (float *****)__vbaHresultCheckObj_exref;
                          pppppfVar6 = (float *****)__vbaHresultCheckObj_exref;
                          pppppfVar7 = (float *****)__vbaStrMove_exref;
                          ppppfVar12 = (float ****)(uint)(ushort)((short)local_20 + 1);
                        } while (!SCARRY2((short)local_20,1));
                        goto LAB_0047ea95;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        else {
          if (DAT_0050b238 != 9) {
LAB_0047e957:
            ppppfStack_404 = (float ****)&local_24c;
LAB_0047e95f:
            ppppfStack_400 = (float ****)0x0;
            ppppfStack_408 = (float ****)0x47e966;
            __vbaObjSetAddref();
LAB_0047e966:
            local_8 = 0;
            ppppfStack_40c = (float ****)&LAB_0047ea71;
            ppppfStack_410 = (float ****)&local_254;
            ppppfStack_414 = (float ****)&local_250;
            ppppfStack_418 = (float ****)&local_24c;
            ppppfStack_41c = (float ****)&local_248;
            ppppfStack_420 = (float ****)local_244;
            ppppfStack_424 = (float ****)0x5;
            ppppfStack_428 = (float ****)0x47ea6d;
            __vbaFreeObjList();
            return;
          }
          local_16c = (float ****)0x0;
          local_174 = (float ****)0xb;
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_400 = (float ****)&DAT_0050b570;
            ppppfStack_404 = (float ****)&DAT_004048dc;
            ppppfStack_408 = (float ****)0x47ba8f;
            __vbaNew2();
          }
          ppppfStack_410 = (float ****)0x80010007;
          ppppfStack_414 = (float ****)DAT_0050b570;
          ppppfStack_40c = local_174;
          ppppfStack_408 = local_170;
          ppppfStack_404 = local_16c;
          ppppfStack_400 = local_168;
          ppppfStack_418 = (float ****)0x47baca;
          ppppfStack_418 = (float ****)(*(code *)(*DAT_0050b570)[0xd7])();
          ppppfStack_41c = (float ****)&local_58;
          ppppfStack_420 = (float ****)0x47bad5;
          ppppfStack_420 = (float ****)__vbaObjSet();
          ppppfStack_424 = (float ****)0x47bad8;
          __vbaLateIdSt();
          ppppfStack_424 = (float ****)0x47bae1;
          __vbaFreeObj();
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_424 = (float ****)&DAT_0050b570;
            ppppfStack_428 = (float ****)&DAT_004048dc;
            ppppfStack_42c = (float ****)0x47baf6;
            __vbaNew2();
          }
          ppppfStack_424 = (float ****)DAT_0050b570;
          ppppfStack_428 = (float ****)0x47bb04;
          ppppfStack_428 = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
          ppppfStack_42c = (float ****)&local_58;
          ppppfStack_430 = (float ****)0x47bb0f;
          pppppfVar6 = (float *****)__vbaObjSet();
          ppppfStack_430 = (float ****)&local_218;
          ppppfStack_438 = (float ****)0x47bb1e;
          ppppfStack_434 = (float ****)pppppfVar6;
          pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
          if ((int)pppppfVar5 < 0) {
            ppppfStack_438 = (float ****)0x78;
            ppppfStack_43c = (float ****)&DAT_0040c908;
            ppppfStack_448 = (float ****)0x47bb2f;
            ppppfStack_444 = (float ****)pppppfVar5;
            ppppfStack_440 = (float ****)pppppfVar6;
            __vbaHresultCheckObj();
          }
          ppppfStack_438 = local_218;
          ppppfStack_43c = local_24c;
          ppppfStack_440 = (float ****)0x47bb42;
          pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x1d])();
          if ((int)pppppfVar6 < 0) {
            ppppfStack_440 = (float ****)0x74;
            ppppfStack_444 = (float ****)&DAT_0040c8f8;
            ppppfStack_448 = local_24c;
            ppppfStack_450 = (float ****)0x47bb59;
            ppppfStack_44c = (float ****)pppppfVar6;
            __vbaHresultCheckObj();
          }
          ppppfStack_440 = (float ****)0x47bb62;
          __vbaFreeObj();
          ppppfStack_440 = (float ****)0x47bb72;
          __vbaStrCopy();
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_440 = (float ****)&DAT_0050b570;
            ppppfStack_444 = (float ****)&DAT_004048dc;
            ppppfStack_448 = (float ****)0x47bb8d;
            __vbaNew2();
          }
          pppppfVar6 = DAT_0050b570;
          ppppfStack_440 = (float ****)&local_218;
          ppppfStack_444 = (float ****)DAT_0050b34c;
          ppppfStack_448 = (float ****)DAT_0050b570;
          ppppfStack_44c = (float ****)0x47bbb2;
          pppppfVar5 = (float *****)(*(code *)(*DAT_0050b570)[0xb9])();
          uVar17 = 0;
          if ((int)pppppfVar5 < 0) {
            ppppfStack_44c = (float ****)0x2e4;
            ppppfStack_450 = (float ****)&DAT_0040d7a4;
            ppppfStack_454 = (float ****)pppppfVar6;
            ppppfStack_45c = (float ****)0x47bbc6;
            ppppfStack_458 = (float ****)pppppfVar5;
            __vbaHresultCheckObj();
          }
          if (DAT_0050b570 == (float *****)0x0) {
            ppppfStack_44c = (float ****)&DAT_0050b570;
            ppppfStack_450 = (float ****)&DAT_004048dc;
            ppppfStack_454 = (float ****)0x47bbdb;
            __vbaNew2();
          }
          ppppfStack_44c = (float ****)DAT_0050b570;
          ppppfStack_450 = (float ****)0x47bbe9;
          ppppfStack_450 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
          ppppfStack_454 = (float ****)&local_58;
          ppppfStack_458 = (float ****)0x47bbf4;
          pppppfVar5 = (float *****)__vbaObjSet();
          pppppfVar6 = (float *****)ppppfStack_3fc;
          if ((uVar17 & 0xd) == 0) {
            ppppfStack_408 = (float ****)0x47bc25;
            ppppfStack_404 = (float ****)pppppfVar5;
            ppppfStack_400 = (float ****)((float)local_218 * (float)_DAT_00401418);
            pppppfVar6 = (float *****)(*(code *)(*pppppfVar5)[0x21])();
            if ((int)pppppfVar6 < 0) {
              ppppfStack_408 = (float ****)0x84;
              ppppfStack_40c = (float ****)&DAT_0040ba5c;
              ppppfStack_418 = (float ****)0x47bc39;
              ppppfStack_414 = (float ****)pppppfVar6;
              ppppfStack_410 = (float ****)pppppfVar5;
              __vbaHresultCheckObj();
            }
            ppppfStack_408 = (float ****)0x47bc42;
            __vbaFreeObj();
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_408 = (float ****)&DAT_0050b570;
              ppppfStack_40c = (float ****)&DAT_004048dc;
              ppppfStack_410 = (float ****)0x47bc57;
              __vbaNew2();
            }
            ppppfStack_408 = (float ****)DAT_0050b570;
            ppppfStack_40c = (float ****)0x47bc65;
            ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd0])();
            ppppfStack_410 = (float ****)&local_58;
            ppppfStack_414 = (float ****)0x47bc70;
            pppppfVar6 = (float *****)__vbaObjSet();
            ppppfStack_414 = (float ****)&local_218;
            ppppfStack_41c = (float ****)0x47bc7f;
            ppppfStack_418 = (float ****)pppppfVar6;
            pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
            uVar17 = 0;
            if ((int)pppppfVar5 < 0) {
              ppppfStack_41c = (float ****)0x78;
              ppppfStack_420 = (float ****)&DAT_0040c3dc;
              ppppfStack_42c = (float ****)0x47bc90;
              ppppfStack_428 = (float ****)pppppfVar5;
              ppppfStack_424 = (float ****)pppppfVar6;
              __vbaHresultCheckObj();
            }
            if (DAT_0050b570 == (float *****)0x0) {
              ppppfStack_41c = (float ****)&DAT_0050b570;
              ppppfStack_420 = (float ****)&DAT_004048dc;
              ppppfStack_424 = (float ****)0x47bca5;
              __vbaNew2();
            }
            ppppfStack_41c = (float ****)DAT_0050b570;
            ppppfStack_420 = (float ****)0x47bcb3;
            ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
            ppppfStack_424 = &local_5c;
            ppppfStack_428 = (float ****)0x47bcbe;
            pppppfVar5 = (float *****)__vbaObjSet();
            ppppfVar12 = *pppppfVar5;
            pppppfVar6 = (float *****)ppppfStack_3fc;
            if ((uVar17 & 0xd) == 0) {
              ppppfStack_400 = (float ****)0x47bcde;
              iVar3 = __vbaFpI4();
              ppppfStack_400 = (float ****)(float)(iVar3 / 2);
              ppppfStack_408 = (float ****)0x47bd00;
              ppppfStack_404 = (float ****)pppppfVar5;
              ppppfStack_414 = (float ****)(*(code *)ppppfVar12[0x1f])();
              if ((int)ppppfStack_414 < 0) {
                ppppfStack_408 = (float ****)0x7c;
                ppppfStack_40c = (float ****)&DAT_0040ba5c;
                ppppfStack_418 = (float ****)0x47bd11;
                ppppfStack_410 = (float ****)pppppfVar5;
                __vbaHresultCheckObj();
              }
              ppppfStack_408 = &local_5c;
              ppppfStack_40c = (float ****)&local_58;
              ppppfStack_410 = (float ****)0x2;
              ppppfStack_414 = (float ****)0x47bd21;
              __vbaFreeObjList();
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_408 = (float ****)&DAT_0050b570;
                ppppfStack_40c = (float ****)&DAT_004048dc;
                ppppfStack_410 = (float ****)0x47bd3d;
                __vbaNew2();
              }
              ppppfStack_408 = (float ****)DAT_0050b570;
              ppppfStack_40c = (float ****)0x47bd4b;
              ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
              ppppfStack_410 = &local_5c;
              ppppfStack_414 = (float ****)0x47bd56;
              pppppfVar6 = (float *****)__vbaObjSet();
              ppppfStack_414 = &local_21c;
              ppppfStack_41c = (float ****)0x47bd68;
              ppppfStack_418 = (float ****)pppppfVar6;
              pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
              if ((int)pppppfVar5 < 0) {
                ppppfStack_41c = (float ****)0x80;
                ppppfStack_420 = (float ****)&DAT_0040ba5c;
                ppppfStack_42c = (float ****)0x47bd7c;
                ppppfStack_428 = (float ****)pppppfVar5;
                ppppfStack_424 = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              if (DAT_0050b570 == (float *****)0x0) {
                ppppfStack_41c = (float ****)&DAT_0050b570;
                ppppfStack_420 = (float ****)&DAT_004048dc;
                ppppfStack_424 = (float ****)0x47bd95;
                __vbaNew2();
              }
              ppppfStack_41c = (float ****)DAT_0050b570;
              ppppfStack_420 = (float ****)0x47bda3;
              ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
              ppppfStack_424 = &local_60;
              ppppfStack_428 = (float ****)0x47bdae;
              piVar4 = (int *)__vbaObjSet();
              if (DAT_0050c53c == (float *****)0x0) {
                ppppfStack_428 = (float ****)&DAT_0050c53c;
                ppppfStack_42c = (float ****)&DAT_0040b420;
                ppppfStack_430 = (float ****)0x47bdc9;
                __vbaNew2();
              }
              pppppfVar6 = DAT_0050c53c;
              ppppfStack_428 = (float ****)&local_58;
              ppppfStack_42c = (float ****)DAT_0050c53c;
              ppppfStack_430 = (float ****)0x47bdd9;
              pppppfVar5 = (float *****)(*(code *)(*DAT_0050c53c)[6])();
              if ((int)pppppfVar5 < 0) {
                ppppfStack_430 = (float ****)0x18;
                ppppfStack_434 = (float ****)&DAT_0040b410;
                ppppfStack_438 = (float ****)pppppfVar6;
                ppppfStack_440 = (float ****)0x47bdea;
                ppppfStack_43c = (float ****)pppppfVar5;
                __vbaHresultCheckObj();
              }
              ppppfVar12 = local_58;
              ppppfStack_430 = (float ****)&local_218;
              ppppfStack_434 = local_58;
              ppppfStack_438 = (float ****)0x47bdff;
              pppppfVar6 = (float *****)(*(code *)(*local_58)[0x26])();
              uVar17 = 0;
              if ((int)pppppfVar6 < 0) {
                ppppfStack_400 = (float ****)0x98;
                ppppfStack_404 = (float ****)&DAT_0040bb5c;
                ppppfStack_408 = ppppfVar12;
                ppppfStack_410 = (float ****)0x47be13;
                ppppfStack_40c = (float ****)pppppfVar6;
                __vbaHresultCheckObj();
              }
              iVar3 = *piVar4;
              pppppfVar6 = (float *****)ppppfStack_3fc;
              if ((uVar17 & 0xd) == 0) {
                ppppfStack_400 = (float ****)0x47be31;
                iVar11 = __vbaFpI4();
                ppppfStack_400 = (float ****)(float)(iVar11 / 2);
                ppppfStack_408 = (float ****)0x47be53;
                ppppfStack_404 = (float ****)piVar4;
                ppppfStack_414 = (float ****)(**(code **)(iVar3 + 0x74))();
                if ((int)ppppfStack_414 < 0) {
                  ppppfStack_408 = (float ****)0x74;
                  ppppfStack_40c = (float ****)&DAT_0040ba5c;
                  ppppfStack_418 = (float ****)0x47be64;
                  ppppfStack_410 = (float ****)piVar4;
                  __vbaHresultCheckObj();
                }
                ppppfStack_408 = &local_60;
                ppppfStack_40c = &local_5c;
                ppppfStack_410 = (float ****)&local_58;
                ppppfStack_414 = (float ****)0x3;
                ppppfStack_418 = (float ****)0x47be78;
                __vbaFreeObjList();
                if (DAT_0050b570 == (float *****)0x0) {
                  ppppfStack_408 = (float ****)&DAT_0050b570;
                  ppppfStack_40c = (float ****)&DAT_004048dc;
                  ppppfStack_410 = (float ****)0x47be94;
                  __vbaNew2();
                }
                ppppfStack_408 = (float ****)DAT_0050b570;
                ppppfStack_40c = (float ****)0x47bea2;
                ppppfStack_40c = (float ****)(*(code *)(*DAT_0050b570)[0xd5])();
                ppppfStack_410 = (float ****)&local_58;
                ppppfStack_414 = (float ****)0x47beaf;
                pppppfVar6 = (float *****)__vbaObjSet();
                ppppfStack_414 = (float ****)DAT_0050b34c;
                ppppfStack_41c = (float ****)0x47bebe;
                ppppfStack_418 = (float ****)pppppfVar6;
                pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x15])();
                if ((int)pppppfVar5 < 0) {
                  ppppfStack_41c = (float ****)0x54;
                  ppppfStack_420 = (float ****)&DAT_0040ba5c;
                  ppppfStack_42c = (float ****)0x47becf;
                  ppppfStack_428 = (float ****)pppppfVar5;
                  ppppfStack_424 = (float ****)pppppfVar6;
                  __vbaHresultCheckObj();
                }
                ppppfStack_41c = (float ****)0x47bed8;
                __vbaFreeObj();
                if (DAT_0050b570 == (float *****)0x0) {
                  ppppfStack_41c = (float ****)&DAT_0050b570;
                  ppppfStack_420 = (float ****)&DAT_004048dc;
                  ppppfStack_424 = (float ****)0x47bef1;
                  __vbaNew2();
                }
                ppppfStack_41c = (float ****)DAT_0050b570;
                ppppfStack_420 = (float ****)0x47beff;
                ppppfStack_420 = (float ****)(*(code *)(*DAT_0050b570)[0xd4])();
                ppppfStack_424 = (float ****)&local_58;
                ppppfStack_428 = (float ****)0x47bf06;
                pppppfVar6 = (float *****)__vbaObjSet();
                ppppfStack_428 = (float ****)&local_218;
                ppppfStack_430 = (float ****)0x47bf18;
                ppppfStack_42c = (float ****)pppppfVar6;
                pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
                if ((int)pppppfVar5 < 0) {
                  ppppfStack_430 = (float ****)0x88;
                  ppppfStack_434 = (float ****)&DAT_0040c908;
                  ppppfStack_440 = (float ****)0x47bf2c;
                  ppppfStack_43c = (float ****)pppppfVar5;
                  ppppfStack_438 = (float ****)pppppfVar6;
                  __vbaHresultCheckObj();
                }
                ppppfStack_430 = local_218;
                ppppfStack_434 = local_24c;
                ppppfStack_438 = (float ****)0x47bf42;
                pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x21])();
                if ((int)pppppfVar6 < 0) {
                  ppppfStack_438 = (float ****)0x84;
                  ppppfStack_43c = (float ****)&DAT_0040c8f8;
                  ppppfStack_440 = local_24c;
                  ppppfStack_448 = (float ****)0x47bf5c;
                  ppppfStack_444 = (float ****)pppppfVar6;
                  __vbaHresultCheckObj();
                }
                ppppfStack_438 = (float ****)0x47bf65;
                __vbaFreeObj();
                local_174 = (float ****)0xa;
                ppppfStack_444 = (float ****)0xa;
                local_16c = (float ****)0x80020004;
                ppppfStack_440 = local_170;
                ppppfStack_43c = (float ****)0x80020004;
                ppppfStack_438 = local_168;
                ppppfStack_448 = *(float *****)(DAT_0050b37c + 4);
                ppppfStack_44c = local_24c;
                ppppfStack_450 = (float ****)0x47bfb0;
                ppppfStack_45c = (float ****)(*(code *)(*local_24c)[0x7b])();
                if ((int)ppppfStack_45c < 0) {
                  ppppfStack_450 = (float ****)0x1ec;
                  ppppfStack_454 = (float ****)&DAT_0040c8f8;
                  ppppfStack_458 = local_24c;
                  ppppfStack_460 = (float ****)0x47bfca;
                  __vbaHresultCheckObj();
                }
                local_174 = (float ****)0xa;
                ppppfStack_45c = (float ****)0xa;
                local_16c = (float ****)0x80020004;
                ppppfStack_458 = local_170;
                ppppfStack_460 = (float ****)&DAT_0040ca6c;
                ppppfStack_464 = local_24c;
                ppppfStack_454 = (float ****)0x80020004;
                ppppfStack_450 = local_168;
                ppppfStack_468 = (float ****)0x47c010;
                ppppfStack_474 = (float ****)(*(code *)(*local_24c)[0x7b])();
                if ((int)ppppfStack_474 < 0) {
                  ppppfStack_468 = (float ****)0x1ec;
                  ppppfStack_46c = (float ****)&DAT_0040c8f8;
                  ppppfStack_470 = local_24c;
                  ppppfStack_478 = (float ****)0x47c02a;
                  __vbaHresultCheckObj();
                }
                local_174 = (float ****)0xa;
                ppppfStack_474 = (float ****)0xa;
                local_16c = (float ****)0x80020004;
                ppppfStack_470 = local_170;
                ppppfStack_478 = (float ****)0x410404;
                ppppfStack_47c = local_24c;
                ppppfStack_46c = (float ****)0x80020004;
                ppppfStack_468 = local_168;
                ppppfStack_480 = (float ****)0x47c070;
                ppppfStack_48c = (float ****)(*(code *)(*local_24c)[0x7b])();
                if ((int)ppppfStack_48c < 0) {
                  ppppfStack_480 = (float ****)0x1ec;
                  ppppfStack_484 = (float ****)&DAT_0040c8f8;
                  ppppfStack_488 = local_24c;
                  ppppfStack_490 = (float ****)0x47c08a;
                  __vbaHresultCheckObj();
                }
                local_174 = (float ****)0xa;
                ppppfStack_48c = (float ****)0xa;
                local_16c = (float ****)0x80020004;
                ppppfStack_488 = local_170;
                ppppfStack_490 = (float ****)&DAT_0040c80c;
                ppppfStack_494 = local_24c;
                ppppfStack_484 = (float ****)0x80020004;
                ppppfStack_480 = local_168;
                ppppfStack_498 = (float ****)0x47c0d0;
                pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x7b])();
                uVar17 = 0;
                if ((int)pppppfVar6 < 0) {
                  ppppfStack_400 = (float ****)0x1ec;
                  ppppfStack_404 = (float ****)&DAT_0040c8f8;
                  ppppfStack_408 = local_24c;
                  ppppfStack_410 = (float ****)0x47c0ea;
                  ppppfStack_40c = (float ****)pppppfVar6;
                  __vbaHresultCheckObj();
                }
                pppppfVar5 = (float *****)__vbaStrMove_exref;
                pppppfVar7 = (float *****)__vbaVarCat_exref;
                sVar14 = DAT_0050b3f2;
                local_20 = (float ***)0x1;
                ppppfVar12 = (float ****)local_20;
                do {
                  local_20 = (float ***)ppppfVar12;
                  pcVar15 = __vbaGenerateBoundsError_exref;
                  if (sVar14 < (short)local_20) {
                    local_174 = (float ****)0xa;
                    ppppfStack_40c = (float ****)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_408 = local_170;
                    ppppfStack_410 = (float ****)&DAT_0040ca6c;
                    ppppfStack_414 = local_24c;
                    ppppfStack_404 = (float ****)0x80020004;
                    ppppfStack_400 = local_168;
                    ppppfStack_418 = (float ****)0x47c564;
                    ppppfStack_424 = (float ****)(*(code *)(*local_24c)[0x7b])();
                    if ((int)ppppfStack_424 < 0) {
                      ppppfStack_418 = (float ****)0x1ec;
                      ppppfStack_41c = (float ****)&DAT_0040c8f8;
                      ppppfStack_420 = local_24c;
                      ppppfStack_428 = (float ****)0x47c582;
                      __vbaHresultCheckObj();
                    }
                    local_174 = (float ****)0xa;
                    ppppfStack_424 = (float ****)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_420 = local_170;
                    ppppfStack_428 = (float ****)&DAT_0040ca6c;
                    ppppfStack_42c = local_24c;
                    ppppfStack_41c = (float ****)0x80020004;
                    ppppfStack_418 = local_168;
                    ppppfStack_430 = (float ****)0x47c5ce;
                    ppppfStack_43c = (float ****)(*(code *)(*local_24c)[0x7b])();
                    if ((int)ppppfStack_43c < 0) {
                      ppppfStack_430 = (float ****)0x1ec;
                      ppppfStack_434 = (float ****)&DAT_0040c8f8;
                      ppppfStack_438 = local_24c;
                      ppppfStack_440 = (float ****)0x47c5ec;
                      __vbaHresultCheckObj();
                    }
                    local_174 = (float ****)0xa;
                    ppppfStack_43c = (float ****)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_438 = local_170;
                    ppppfStack_440 = (float ****)&DAT_0040ca6c;
                    ppppfStack_444 = local_24c;
                    ppppfStack_434 = (float ****)0x80020004;
                    ppppfStack_430 = local_168;
                    ppppfStack_448 = (float ****)0x47c638;
                    ppppfStack_454 = (float ****)(*(code *)(*local_24c)[0x7b])();
                    if ((int)ppppfStack_454 < 0) {
                      ppppfStack_448 = (float ****)0x1ec;
                      ppppfStack_44c = (float ****)&DAT_0040c8f8;
                      ppppfStack_450 = local_24c;
                      ppppfStack_458 = (float ****)0x47c656;
                      __vbaHresultCheckObj();
                    }
                    local_174 = (float ****)0xa;
                    ppppfStack_454 = (float ****)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_450 = local_170;
                    ppppfStack_458 = (float ****)0x410478;
                    ppppfStack_45c = local_24c;
                    ppppfStack_44c = (float ****)0x80020004;
                    ppppfStack_448 = local_168;
                    ppppfStack_460 = (float ****)0x47c6a2;
                    ppppfStack_46c = (float ****)(*(code *)(*local_24c)[0x7b])();
                    if ((int)ppppfStack_46c < 0) {
                      ppppfStack_460 = (float ****)0x1ec;
                      ppppfStack_464 = (float ****)&DAT_0040c8f8;
                      ppppfStack_468 = local_24c;
                      ppppfStack_470 = (float ****)0x47c6c0;
                      __vbaHresultCheckObj();
                    }
                    local_174 = (float ****)0xa;
                    ppppfStack_46c = (float ****)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_468 = local_170;
                    ppppfStack_470 = (float ****)&DAT_0040ca6c;
                    ppppfStack_474 = local_24c;
                    ppppfStack_464 = (float ****)0x80020004;
                    ppppfStack_460 = local_168;
                    ppppfStack_478 = (float ****)0x47c70c;
                    pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x7b])();
                    if ((int)pppppfVar6 < 0) {
                      ppppfStack_478 = (float ****)0x1ec;
                      ppppfStack_47c = (float ****)&DAT_0040c8f8;
                      ppppfStack_480 = local_24c;
                      ppppfStack_488 = (float ****)0x47c72a;
                      ppppfStack_484 = (float ****)pppppfVar6;
                      __vbaHresultCheckObj();
                    }
                    ppppfStack_478 = (float ****)0x47c72f;
                    FUN_0044fdc0();
                    ppppfStack_478 = (float ****)0x47c736;
                    __vbaStrMove();
                    ppppfStack_478 = (float ****)&DAT_00000001;
                    local_6c = local_40;
                    ppppfStack_480 = local_74;
                    ppppfStack_47c = (float ****)&DAT_00000001;
                    ppppfStack_484 = (float ****)&local_174;
                    ppppfStack_488 = local_84;
                    local_40 = (float ***)0x0;
                    local_74[0] = (float ***)0x8;
                    local_16c = (float ****)&DAT_0050b14c;
                    local_174 = (float ****)0x4005;
                    ppppfStack_48c = (float ****)0x47c778;
                    Ordinal_660();
                    local_18c = (float ****)0x80020004;
                    local_194 = (float ****)0xa;
                    local_17c = L" Value of the game  = ";
                    local_184 = (float ***)0x8;
                    ppppfVar12 = (float ****)*local_24c;
                    ppppfStack_498 = (float ****)0xa;
                    ppppfStack_494 = local_190;
                    pppfStack_49c = (float ***)&local_184;
                    ppppfStack_490 = (float ****)0x80020004;
                    ppppfStack_48c = local_188;
                    ppppfStack_4a0 = local_84;
                    ppppfStack_4a4 = local_94;
                    pppfStack_4a8 = (float ***)0x47c7d6;
                    pppfStack_4a8 = (float ***)__vbaVarCat();
                    ppppfStack_4ac = &local_3c;
                    ppppfStack_4b0 = (float ****)0x47c7e1;
                    ppppfStack_4b0 = (float ****)__vbaStrVarVal();
                    ppppfStack_4b4 = local_24c;
                    ppppfStack_4b8 = (float ****)0x47c7ef;
                    ppppfStack_4c4 = (float ****)(*(code *)ppppfVar12[0x7b])();
                    if ((int)ppppfStack_4c4 < 0) {
                      ppppfStack_4b8 = (float ****)0x1ec;
                      ppppfStack_4bc = (float ****)&DAT_0040c8f8;
                      ppppfStack_4c0 = local_24c;
                      ppppfStack_4c8 = (float ****)0x47c80d;
                      __vbaHresultCheckObj();
                    }
                    ppppfStack_4b8 = &local_40;
                    ppppfStack_4bc = &local_3c;
                    ppppfStack_4c0 = (float ****)0x2;
                    ppppfStack_4c4 = (float ****)0x47c81d;
                    __vbaFreeStrList();
                    ppppfStack_4c4 = local_94;
                    ppppfStack_4c8 = local_84;
                    ppppfStack_4cc = local_74;
                    ppppfStack_4d0 = (float ****)0x3;
                    ppppfStack_4d4 = (float ****)0x47c834;
                    __vbaFreeVarList();
                    local_174 = (float ****)0xa;
                    ppppfStack_4c4 = (float ****)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_4c0 = local_170;
                    ppppfStack_4c8 = (float ****)&DAT_0040ca6c;
                    ppppfStack_4cc = local_24c;
                    ppppfStack_4bc = (float ****)0x80020004;
                    ppppfStack_4b8 = local_168;
                    ppppfStack_4d0 = (float ****)0x47c880;
                    pppfStack_4dc = (float ***)(*(code *)(*local_24c)[0x7b])();
                    if ((int)pppfStack_4dc < 0) {
                      ppppfStack_4d0 = (float ****)0x1ec;
                      ppppfStack_4d4 = (float ****)&DAT_0040c8f8;
                      ppppfStack_4d8 = local_24c;
                      __vbaHresultCheckObj();
                    }
                    pppppfVar8 = (float *****)&pppfStack_4dc;
                    local_174 = (float ****)0xa;
                    pppfStack_4dc = (float ***)0xa;
                    local_16c = (float ****)0x80020004;
                    ppppfStack_4d8 = local_170;
                    ppppfStack_4d4 = (float ****)0x80020004;
                    ppppfStack_4d0 = local_168;
                    pppppfVar6 = (float *****)
                                 (*(code *)(*local_24c)[0x7b])(local_24c,L" Player A\'s mix:");
                    if ((int)pppppfVar6 < 0) {
                      ppppfStack_400 = (float ****)0x1ec;
                      ppppfStack_404 = (float ****)&DAT_0040c8f8;
                      ppppfStack_408 = local_24c;
                      ppppfStack_410 = (float ****)0x47c908;
                      ppppfStack_40c = (float ****)pppppfVar6;
                      __vbaHresultCheckObj();
                    }
                    uVar13 = _DAT_0050b3f0;
                    ppppfVar12 = (float ****)0x1;
                    goto LAB_0047c918;
                  }
                  ppppfStack_400 = (float ****)&local_174;
                  local_16c = &local_20;
                  local_174 = (float ****)0x4002;
                  ppppfStack_404 = (float ****)0x47c13f;
                  Ordinal_536();
                  ppppfStack_404 = (float ****)0x47c146;
                  ppppfStack_404 = (float ****)__vbaStrMove();
                  ppppfStack_408 = (float ****)0x47c14d;
                  Ordinal_521();
                  ppppfStack_408 = (float ****)0x47c154;
                  __vbaStrMove();
                  ppppfStack_408 = (float ****)0x47c159;
                  FUN_0044fdc0();
                  ppppfStack_408 = (float ****)0x47c160;
                  __vbaStrMove();
                  local_6c = local_50;
                  ppppfStack_40c = &local_30;
                  ppppfStack_408 = (float ****)DAT_0050b3f4;
                  local_50 = (float ***)0x0;
                  local_74[0] = (float ***)0x8;
                  ppppfStack_410 = (float ****)0x47c185;
                  __vbaAryLock();
                  if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 2)) {
                    ppppfStack_410 = (float ****)0x47c1e6;
                    iVar3 = __vbaGenerateBoundsError();
                  }
                  else {
                    pppfVar16 = (float ***)local_30[7];
                    if (local_30[6] <= (float ***)(2U - (int)pppfVar16)) {
                      ppppfStack_410 = (float ****)0x47c1a9;
                      __vbaGenerateBoundsError();
                    }
                    local_224 = (float **)((int)(short)local_20 - (int)local_30[5]);
                    if (local_30[4] <= local_224) {
                      ppppfStack_410 = (float ****)0x47c1c8;
                      __vbaGenerateBoundsError();
                    }
                    iVar3 = (int)((int)local_30[6] * (int)local_224 + (int)(2U - (int)pppfVar16)) *
                            8;
                    pcVar15 = __vbaGenerateBoundsError_exref;
                  }
                  ppppfStack_410 = (float ****)&DAT_00000001;
                  local_17c = (wchar_t *)((int)local_30[3] + iVar3);
                  ppppfStack_418 = local_74;
                  ppppfStack_414 = (float ****)&DAT_00000001;
                  ppppfStack_41c = &local_184;
                  ppppfStack_420 = local_84;
                  local_184 = (float ***)0x4005;
                  ppppfStack_424 = (float ****)0x47c217;
                  Ordinal_660();
                  ppppfStack_424 = &local_30;
                  ppppfStack_428 = (float ****)0x47c221;
                  __vbaAryUnlock();
                  ppppfStack_428 = (float ****)0x47c226;
                  FUN_0044fdc0();
                  ppppfStack_428 = (float ****)0x47c22d;
                  __vbaStrMove();
                  local_cc = local_54;
                  local_54 = (float ***)0x0;
                  local_d4[0] = (float ***)0x8;
                  if ((DAT_0050b3f4 == (float *****)0x0) || (*(short *)DAT_0050b3f4 != 2)) {
                    ppppfStack_3f8 = (float ****)0x47c2b1;
                    iVar3 = __vbaGenerateBoundsError();
                  }
                  else {
                    local_230 = (float ***)(1 - (int)DAT_0050b3f4[7]);
                    if (DAT_0050b3f4[6] <= local_230) {
                      ppppfStack_3f8 = (float ****)0x47c270;
                      (*pcVar15)();
                    }
                    local_22c = (float ****)((int)(short)local_20 - (int)DAT_0050b3f4[5]);
                    if (DAT_0050b3f4[4] <= local_22c) {
                      ppppfStack_3f8 = (float ****)0x47c28e;
                      (*pcVar15)();
                    }
                    iVar3 = (int)((int)DAT_0050b3f4[6] * (int)local_22c + (int)local_230) * 8;
                  }
                  if ((DAT_0050b3f4 == (float *****)0x0) || (*(short *)DAT_0050b3f4 != 2)) {
                    ppppfStack_3f8 = (float ****)0x47c325;
                    iVar11 = __vbaGenerateBoundsError();
                  }
                  else {
                    local_238 = (float ***)(2 - (int)DAT_0050b3f4[7]);
                    if (DAT_0050b3f4[6] <= local_238) {
                      ppppfStack_3f8 = (float ****)0x47c2e0;
                      __vbaGenerateBoundsError();
                    }
                    local_234 = (float ***)((int)(short)local_20 - (int)DAT_0050b3f4[5]);
                    if (DAT_0050b3f4[4] <= local_234) {
                      ppppfStack_3f8 = (float ****)0x47c302;
                      __vbaGenerateBoundsError();
                    }
                    iVar11 = (int)((int)DAT_0050b3f4[6] * (int)local_234 + (int)local_238) * 8;
                  }
                  ppppfStack_3f8 = (float ****)&DAT_00000001;
                  ppppfStack_3fc = (float ****)&DAT_00000001;
                  local_bc = *(double *)(iVar3 + (int)DAT_0050b3f4[3]) -
                             *(double *)(iVar11 + (int)DAT_0050b3f4[3]);
                  local_c4[0] = (float ***)0x5;
                  pppppfVar6 = (float *****)ppppfStack_3fc;
                  if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
                  ppppfStack_400 = local_d4;
                  ppppfStack_40c = (float ****)0x47c36d;
                  ppppfStack_408 = local_e4;
                  ppppfStack_404 = local_c4;
                  Ordinal_660();
                  ppppfStack_40c = (float ****)0x410444;
                  local_1bc = (float ****)0x80020004;
                  local_1c4 = (float ****)0xa;
                  local_4c = (float ***)0x0;
                  ppppfStack_410 = (float ****)0x47c395;
                  ppppfStack_410 = (float ****)__vbaStrMove();
                  ppppfStack_414 = (float ****)0x47c39e;
                  __vbaStrCat();
                  ppppfStack_414 = (float ****)0x47c3a5;
                  ppppfStack_414 = (float ****)__vbaStrMove();
                  ppppfStack_418 = (float ****)&DAT_00410460;
                  ppppfStack_41c = (float ****)0x47c3ad;
                  local_8c = __vbaStrCat();
                  local_94[0] = (float ***)0x8;
                  local_194 = (float ****)0x8;
                  local_1b4 = (float ****)0x8;
                  local_18c = (float ****)&DAT_0041046c;
                  local_1ac = (float ***)&DAT_0040c894;
                  ppppfVar12 = (float ****)*local_24c;
                  ppppfStack_428 = local_1c4;
                  ppppfStack_424 = local_1c0;
                  ppppfStack_420 = local_1bc;
                  ppppfStack_430 = local_84;
                  ppppfStack_41c = local_1b8;
                  ppppfStack_42c = local_94;
                  ppppfStack_434 = local_a4;
                  ppppfStack_438 = (float ****)0x47c422;
                  ppppfStack_438 = (float ****)__vbaVarCat();
                  ppppfStack_43c = (float ****)&local_194;
                  ppppfStack_440 = local_b4;
                  ppppfStack_444 = (float ****)0x47c433;
                  ppppfStack_444 = (float ****)__vbaVarCat();
                  ppppfStack_448 = local_e4;
                  ppppfStack_44c = local_f4;
                  ppppfStack_450 = (float ****)0x47c444;
                  ppppfStack_450 = (float ****)__vbaVarCat();
                  ppppfStack_454 = (float ****)&local_1b4;
                  ppppfStack_458 = local_104;
                  ppppfStack_45c = (float ****)0x47c455;
                  ppppfStack_45c = (float ****)__vbaVarCat();
                  ppppfStack_460 = &local_48;
                  ppppfStack_464 = (float ****)0x47c460;
                  ppppfStack_464 = (float ****)__vbaStrVarVal();
                  ppppfStack_468 = local_24c;
                  ppppfStack_46c = (float ****)0x47c46e;
                  ppppfStack_478 = (float ****)(*(code *)ppppfVar12[0x7b])();
                  uVar17 = 0;
                  if ((int)ppppfStack_478 < 0) {
                    ppppfStack_46c = (float ****)0x1ec;
                    ppppfStack_470 = (float ****)&DAT_0040c8f8;
                    ppppfStack_474 = local_24c;
                    ppppfStack_47c = (float ****)0x47c48c;
                    __vbaHresultCheckObj();
                  }
                  ppppfStack_46c = &local_54;
                  ppppfStack_470 = &local_50;
                  ppppfStack_474 = &local_4c;
                  ppppfStack_478 = &local_48;
                  ppppfStack_47c = &local_44;
                  ppppfStack_480 = &local_40;
                  ppppfStack_484 = &local_3c;
                  ppppfStack_488 = (float ****)0x7;
                  ppppfStack_48c = (float ****)0x47c4b0;
                  __vbaFreeStrList();
                  ppppfStack_48c = local_104;
                  ppppfStack_490 = local_f4;
                  ppppfStack_494 = local_e4;
                  ppppfStack_498 = local_b4;
                  pppfStack_49c = (float ***)local_d4;
                  ppppfStack_4a0 = local_c4;
                  ppppfStack_4a4 = local_a4;
                  pppfStack_4a8 = (float ***)local_84;
                  ppppfStack_4ac = local_94;
                  ppppfStack_4b0 = local_74;
                  ppppfStack_4b4 = (float ****)0xa;
                  ppppfStack_4b8 = (float ****)0x47c4f8;
                  __vbaFreeVarList();
                  pppppfVar8 = (float *****)__vbaGenerateBoundsError_exref;
                  ppppfVar12 = (float ****)(uint)(ushort)((short)local_20 + 1);
                } while (!SCARRY2((short)local_20,1));
                goto LAB_0047ea95;
              }
            }
          }
        }
      }
    }
  }
LAB_0047ea90:
  ppppfStack_3fc = (float ****)pppppfVar6;
  __vbaFPException();
  return;
  while( true ) {
    ppppfStack_400 = (float ****)0x1;
    local_17c = (wchar_t *)((int)local_30[3] + iVar3);
    ppppfStack_408 = local_74;
    ppppfStack_404 = (float ****)&DAT_00000001;
    ppppfStack_40c = &local_184;
    ppppfStack_410 = local_84;
    local_184 = (float ***)0x4005;
    ppppfStack_414 = (float ****)0x47c9fe;
    Ordinal_660();
    ppppfStack_414 = &local_30;
    ppppfStack_418 = (float ****)0x47ca08;
    __vbaAryUnlock();
    ppppfStack_418 = (float ****)0x410520;
    local_18c = (float ****)0x80020004;
    local_194 = (float ****)0xa;
    local_4c = (float ***)0x0;
    ppppfStack_41c = (float ****)0x47ca30;
    ppppfStack_41c = (float ****)__vbaStrMove();
    ppppfStack_420 = (float ****)0x47ca39;
    __vbaStrCat();
    ppppfStack_420 = (float ****)0x47ca40;
    ppppfStack_420 = (float ****)__vbaStrMove();
    ppppfStack_424 = (float ****)&DAT_00410460;
    ppppfStack_428 = (float ****)0x47ca48;
    local_8c = __vbaStrCat();
    local_94[0] = (float ***)0x8;
    pppppfVar8 = (float *****)*local_24c;
    ppppfStack_434 = local_194;
    ppppfStack_430 = local_190;
    ppppfStack_42c = local_18c;
    ppppfStack_43c = local_84;
    ppppfStack_428 = local_188;
    ppppfStack_438 = local_94;
    ppppfStack_440 = local_a4;
    ppppfStack_444 = (float ****)0x47ca9c;
    ppppfStack_444 = (float ****)__vbaVarCat();
    ppppfStack_448 = &local_48;
    ppppfStack_44c = (float ****)0x47caa7;
    ppppfStack_44c = (float ****)__vbaStrVarVal();
    ppppfStack_450 = local_24c;
    ppppfStack_454 = (float ****)0x47cab5;
    ppppfStack_460 = (float ****)(*(code *)pppppfVar8[0x7b])();
    if ((int)ppppfStack_460 < 0) {
      ppppfStack_454 = (float ****)0x1ec;
      ppppfStack_458 = (float ****)&DAT_0040c8f8;
      ppppfStack_45c = local_24c;
      ppppfStack_464 = (float ****)0x47cad3;
      __vbaHresultCheckObj();
    }
    ppppfStack_454 = &local_50;
    ppppfStack_458 = &local_4c;
    ppppfStack_45c = &local_48;
    ppppfStack_460 = &local_44;
    ppppfStack_464 = &local_40;
    ppppfStack_468 = &local_3c;
    ppppfStack_46c = (float ****)0x6;
    ppppfStack_470 = (float ****)0x47caf3;
    __vbaFreeStrList();
    ppppfStack_470 = local_a4;
    ppppfStack_474 = local_84;
    ppppfStack_478 = local_94;
    ppppfStack_47c = local_74;
    ppppfStack_480 = (float ****)0x4;
    ppppfStack_484 = (float ****)0x47cb11;
    __vbaFreeVarList();
    ppppfVar12 = (float ****)(uint)(ushort)((short)local_20 + 1);
    if (SCARRY2((short)local_20,1)) break;
LAB_0047c918:
    local_274 = (short)uVar13;
    local_20 = (float ***)ppppfVar12;
    if (local_274 < (short)ppppfVar12) {
      local_174 = (float ****)0xa;
      ppppfStack_40c = (float ****)0xa;
      local_16c = (float ****)0x80020004;
      ppppfStack_408 = local_170;
      ppppfStack_410 = (float ****)&DAT_0040ca6c;
      ppppfStack_414 = local_24c;
      ppppfStack_404 = (float ****)0x80020004;
      ppppfStack_400 = local_168;
      ppppfStack_418 = (float ****)0x47cb74;
      ppppfStack_424 = (float ****)(*(code *)(*local_24c)[0x7b])();
      if ((int)ppppfStack_424 < 0) {
        ppppfStack_418 = (float ****)0x1ec;
        ppppfStack_41c = (float ****)&DAT_0040c8f8;
        ppppfStack_420 = local_24c;
        ppppfStack_428 = (float ****)0x47cb92;
        __vbaHresultCheckObj();
      }
      local_174 = (float ****)0xa;
      ppppfStack_424 = (float ****)0xa;
      local_16c = (float ****)0x80020004;
      ppppfStack_420 = local_170;
      ppppfStack_428 = (float ****)0x41053c;
      ppppfStack_42c = local_24c;
      ppppfStack_41c = (float ****)0x80020004;
      ppppfStack_418 = local_168;
      ppppfStack_430 = (float ****)0x47cbde;
      pppppfVar6 = (float *****)(*(code *)(*local_24c)[0x7b])();
      if ((int)pppppfVar6 < 0) {
        ppppfStack_400 = (float ****)0x1ec;
        ppppfStack_404 = (float ****)&DAT_0040c8f8;
        ppppfStack_408 = local_24c;
        ppppfStack_410 = (float ****)0x47cbfc;
        ppppfStack_40c = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      sVar14 = DAT_0050b3f2;
      ppppfVar12 = (float ****)0x1;
      goto LAB_0047cc0e;
    }
    ppppfStack_400 = (float ****)&local_174;
    local_16c = &local_20;
    local_174 = (float ****)0x4002;
    ppppfStack_404 = (float ****)0x47c948;
    Ordinal_536();
    ppppfStack_404 = (float ****)0x47c94f;
    ppppfStack_404 = (float ****)__vbaStrMove();
    ppppfStack_408 = (float ****)0x47c956;
    Ordinal_521();
    ppppfStack_408 = (float ****)0x47c95d;
    __vbaStrMove();
    ppppfStack_408 = (float ****)0x47c962;
    FUN_0044fdc0();
    ppppfStack_408 = (float ****)0x47c969;
    __vbaStrMove();
    ppppfStack_40c = &local_30;
    local_6c = local_50;
    ppppfStack_408 = (float ****)DAT_0050b0ec;
    local_50 = (float ***)0x0;
    local_74[0] = (float ***)0x8;
    ppppfStack_410 = (float ****)0x47c98d;
    __vbaAryLock();
    if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 1)) {
      ppppfStack_400 = (float ****)0x47c9cd;
      iVar3 = __vbaGenerateBoundsError();
    }
    else {
      if (SCARRY2((short)local_20,1)) break;
      pppfVar16 = (float ***)((int)(short)((short)local_20 + 1) - (int)local_30[5]);
      if (local_30[4] <= pppfVar16) {
        ppppfStack_400 = (float ****)0x47c9bb;
        __vbaGenerateBoundsError();
      }
      iVar3 = (int)pppfVar16 * 8;
    }
  }
  goto LAB_0047ea95;
  while( true ) {
    ppppfStack_400 = (float ****)&local_174;
    local_16c = &local_20;
    local_174 = (float ****)0x4002;
    ppppfStack_404 = (float ****)0x47cc3e;
    Ordinal_536();
    ppppfStack_404 = (float ****)0x47cc45;
    ppppfStack_404 = (float ****)__vbaStrMove();
    ppppfStack_408 = (float ****)0x47cc4c;
    Ordinal_521();
    ppppfStack_408 = (float ****)0x47cc53;
    __vbaStrMove();
    ppppfStack_408 = (float ****)0x47cc58;
    FUN_0044fdc0();
    ppppfStack_408 = (float ****)0x47cc5f;
    __vbaStrMove();
    ppppfStack_40c = &local_30;
    local_6c = local_50;
    ppppfStack_408 = (float ****)DAT_0050b0dc;
    local_50 = (float ***)0x0;
    local_74[0] = (float ***)0x8;
    ppppfStack_410 = (float ****)0x47cc83;
    __vbaAryLock();
    if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 1)) {
      ppppfStack_410 = (float ****)0x47ccb8;
      iVar3 = __vbaGenerateBoundsError();
    }
    else {
      iVar3 = (int)(short)local_20;
      pppfVar16 = (float ***)local_30[5];
      if (local_30[4] <= (float ***)(iVar3 - (int)pppfVar16)) {
        ppppfStack_410 = (float ****)0x47cca6;
        __vbaGenerateBoundsError();
      }
      iVar3 = (iVar3 - (int)pppfVar16) * 8;
    }
    ppppfStack_410 = (float ****)&DAT_00000001;
    local_17c = (wchar_t *)((int)local_30[3] + iVar3);
    ppppfStack_418 = local_74;
    ppppfStack_414 = (float ****)&DAT_00000001;
    ppppfStack_41c = &local_184;
    ppppfStack_420 = local_84;
    local_184 = (float ***)0x4005;
    ppppfStack_424 = (float ****)0x47cce9;
    Ordinal_660();
    ppppfStack_424 = &local_30;
    ppppfStack_428 = (float ****)0x47ccf3;
    __vbaAryUnlock();
    ppppfStack_428 = (float ****)0x410444;
    local_18c = (float ****)0x80020004;
    local_194 = (float ****)0xa;
    local_4c = (float ***)0x0;
    ppppfStack_42c = (float ****)0x47cd1b;
    ppppfStack_42c = (float ****)__vbaStrMove();
    ppppfStack_430 = (float ****)0x47cd24;
    __vbaStrCat();
    ppppfStack_430 = (float ****)0x47cd2b;
    ppppfStack_430 = (float ****)__vbaStrMove();
    ppppfStack_434 = (float ****)&DAT_00410460;
    ppppfStack_438 = (float ****)0x47cd33;
    local_8c = __vbaStrCat();
    local_94[0] = (float ***)0x8;
    pppppfVar8 = (float *****)*local_24c;
    ppppfStack_444 = local_194;
    ppppfStack_440 = local_190;
    ppppfStack_43c = local_18c;
    ppppfStack_44c = local_84;
    ppppfStack_438 = local_188;
    ppppfStack_448 = local_94;
    ppppfStack_450 = local_a4;
    ppppfStack_454 = (float ****)0x47cd87;
    ppppfStack_454 = (float ****)__vbaVarCat();
    ppppfStack_458 = &local_48;
    ppppfStack_45c = (float ****)0x47cd92;
    ppppfStack_45c = (float ****)__vbaStrVarVal();
    ppppfStack_460 = local_24c;
    ppppfStack_464 = (float ****)0x47cda0;
    ppppfStack_470 = (float ****)(*(code *)pppppfVar8[0x7b])();
    if ((int)ppppfStack_470 < 0) {
      ppppfStack_464 = (float ****)0x1ec;
      ppppfStack_468 = (float ****)&DAT_0040c8f8;
      ppppfStack_46c = local_24c;
      ppppfStack_474 = (float ****)0x47cdbe;
      __vbaHresultCheckObj();
    }
    ppppfStack_464 = &local_50;
    ppppfStack_468 = &local_4c;
    ppppfStack_46c = &local_48;
    ppppfStack_470 = &local_44;
    ppppfStack_474 = &local_40;
    ppppfStack_478 = &local_3c;
    ppppfStack_47c = (float ****)0x6;
    ppppfStack_480 = (float ****)0x47cdde;
    __vbaFreeStrList();
    ppppfStack_480 = local_a4;
    ppppfStack_484 = local_84;
    ppppfStack_488 = local_94;
    ppppfStack_48c = local_74;
    ppppfStack_490 = (float ****)0x4;
    ppppfStack_494 = (float ****)0x47cdfc;
    __vbaFreeVarList();
    ppppfVar12 = (float ****)(uint)(ushort)((short)local_20 + 1);
    if (SCARRY2((short)local_20,1)) break;
LAB_0047cc0e:
    local_20 = (float ***)ppppfVar12;
    if (sVar14 < (short)ppppfVar12) goto LAB_0047e957;
  }
  goto LAB_0047ea95;
  while( true ) {
    local_174 = (float ****)0x3;
    ppppfStack_410 = (float ****)0xa;
    ppppfStack_40c = (float ****)0x3;
    local_16c = (float ****)0x0;
    ppppfStack_408 = local_170;
    ppppfStack_414 = local_250;
    ppppfStack_404 = (float ****)0x0;
    ppppfStack_400 = local_168;
    ppppfStack_418 = (float ****)0x47a9f0;
    (*(code *)pppppfVar5)();
    ppppfStack_41c = (float ****)(int)(short)local_20;
    local_174 = (float ****)0x3;
    ppppfStack_428 = (float ****)0xb;
    ppppfStack_424 = (float ****)0x3;
    ppppfStack_420 = local_170;
    ppppfStack_42c = local_250;
    ppppfStack_418 = local_168;
    ppppfStack_430 = (float ****)0x47aa2c;
    local_16c = ppppfStack_41c;
    (*(code *)pppppfVar5)();
    local_174 = (float ****)0x2;
    ppppfStack_440 = (float ****)0x28;
    ppppfStack_43c = (float ****)0x2;
    local_16c = (float ****)0x1;
    ppppfStack_438 = local_170;
    ppppfStack_444 = local_250;
    ppppfStack_434 = (float ****)&DAT_00000001;
    ppppfStack_430 = local_168;
    ppppfStack_448 = (float ****)0x47aa69;
    (*(code *)pppppfVar5)();
    if (0 < (short)local_20) {
      ppppfStack_44c = (float ****)(DAT_0050b37c + 4);
      local_174 = (float ****)0x4008;
      ppppfStack_454 = (float ****)0x4008;
      ppppfStack_458 = (float ****)0x0;
      ppppfStack_450 = local_170;
      ppppfStack_45c = local_250;
      ppppfStack_448 = local_168;
      ppppfStack_460 = (float ****)0x47aab1;
      local_16c = ppppfStack_44c;
      (*(code *)pppppfVar5)();
    }
    local_174 = (float ****)0x3;
    ppppfStack_458 = (float ****)0xa;
    ppppfStack_454 = (float ****)0x3;
    local_16c = (float ****)0x1;
    ppppfStack_450 = local_170;
    ppppfStack_45c = local_250;
    ppppfStack_44c = (float ****)&DAT_00000001;
    ppppfStack_448 = local_168;
    ppppfStack_460 = (float ****)0x47aaee;
    (*(code *)pppppfVar5)();
    local_174 = (float ****)0x2;
    ppppfStack_470 = (float ****)0x28;
    ppppfStack_46c = (float ****)0x2;
    local_16c = (float ****)0x4;
    ppppfStack_468 = local_170;
    ppppfStack_474 = local_250;
    ppppfStack_464 = (float ****)0x4;
    ppppfStack_460 = local_168;
    ppppfStack_478 = (float ****)0x47ab2b;
    (*(code *)pppppfVar5)();
    local_174 = (float ****)0x3;
    ppppfStack_488 = (float ****)0x27;
    ppppfStack_484 = (float ****)0x3;
    local_16c = (float ****)0xff0000;
    ppppfStack_480 = local_170;
    ppppfStack_48c = local_250;
    ppppfStack_47c = (float ****)0xff0000;
    ppppfStack_478 = local_168;
    ppppfStack_490 = (float ****)0x47ab68;
    (*(code *)pppppfVar5)();
    local_174 = (float ****)0x3;
    ppppfStack_4a0 = (float ****)0x26;
    pppfStack_49c = (float ***)0x3;
    local_16c = (float ****)0xffff00;
    ppppfStack_498 = local_170;
    ppppfStack_4a4 = local_250;
    ppppfStack_494 = (float ****)0xffff00;
    ppppfStack_490 = local_168;
    pppfStack_4a8 = (float ***)0x47aba5;
    (*(code *)pppppfVar5)();
    ppppfStack_4ac = &local_30;
    pppfStack_4a8 = (float ***)DAT_0050b3bc;
    ppppfStack_4b0 = (float ****)0x47abb6;
    __vbaAryLock();
    if (((float ****)local_30 == (float ****)0x0) || (*(short *)local_30 != 1)) {
      ppppfStack_4b0 = (float ****)0x47abeb;
      iVar3 = __vbaGenerateBoundsError();
    }
    else {
      pppppfVar7 = (float *****)((int)(short)local_20 - (int)local_30[5]);
      if (local_30[4] <= pppppfVar7) {
        ppppfStack_4b0 = (float ****)0x47abd9;
        __vbaGenerateBoundsError();
      }
      iVar3 = (int)pppppfVar7 * 4;
    }
    ppppfStack_4b4 = (float ****)((int)local_30[3] + iVar3);
    local_174 = (float ****)0x4008;
    ppppfStack_4bc = (float ****)0x4008;
    ppppfStack_4c0 = (float ****)0x0;
    ppppfStack_4b8 = local_170;
    ppppfStack_4b0 = local_168;
    ppppfStack_4c4 = local_250;
    ppppfStack_4c8 = (float ****)0x47ac2b;
    local_16c = ppppfStack_4b4;
    (*(code *)pppppfVar5)();
    ppppfStack_4c8 = &local_30;
    ppppfStack_4cc = (float ****)0x47ac35;
    __vbaAryUnlock();
    ppppfVar12 = (float ****)(uint)(ushort)((short)local_20 + 1);
    if (SCARRY2((short)local_20,1)) break;
LAB_0047a9a5:
    local_20 = (float ***)ppppfVar12;
    if (5 < (short)ppppfVar12) {
      local_174 = (float ****)0x3;
      ppppfStack_410 = (float ****)0x30;
      ppppfStack_40c = (float ****)0x3;
      local_16c = (float ****)0x2;
      ppppfStack_408 = local_170;
      ppppfStack_414 = local_250;
      ppppfStack_404 = (float ****)0x2;
      ppppfStack_400 = local_168;
      ppppfStack_418 = (float ****)0x47ac86;
      (*(code *)pppppfVar5)();
      local_174 = (float ****)0x3;
      ppppfStack_424 = (float ****)0x3;
      local_16c = (float ****)0x0;
      ppppfStack_420 = local_170;
      ppppfStack_438 = (float ****)0x1;
      ppppfStack_41c = (float ****)0x0;
      local_18c = (float ****)0xffffffff;
      ppppfStack_43c = (float ****)0x3b;
      ppppfStack_418 = local_168;
      ppppfStack_434 = (float ****)0xb;
      local_194 = (float ****)0xb;
      ppppfStack_430 = local_190;
      ppppfStack_440 = local_250;
      ppppfStack_42c = (float ****)0xffffffff;
      ppppfStack_428 = local_188;
      ppppfStack_444 = (float ****)0x47acf2;
      (*(code *)pppppfVar8)();
      ppppfStack_41c = (float ****)&local_250;
      ppppfStack_418 = (float ****)0x0;
      ppppfStack_420 = (float ****)0x47ad06;
      __vbaObjSetAddref();
      ppppfStack_420 = (float ****)0x47ad0b;
      FUN_004f5480();
      if (DAT_0050b570 == (float *****)0x0) {
        ppppfStack_420 = (float ****)&DAT_0050b570;
        ppppfStack_424 = (float ****)&DAT_004048dc;
        ppppfStack_428 = (float ****)0x47ad24;
        __vbaNew2();
      }
      ppppfStack_424 = (float ****)&local_254;
      ppppfStack_420 = (float ****)DAT_0050b570;
      ppppfStack_428 = (float ****)0x47ad34;
      __vbaObjSetAddref();
      ppppfStack_428 = (float ****)0x0;
      ppppfStack_42c = (float ****)0x80010006;
      ppppfStack_430 = local_254;
      ppppfStack_434 = (float ****)0x47ad4a;
      ppppfStack_434 = (float ****)(*(code *)(*local_254)[0xd7])();
      pppppfVar5 = (float *****)__vbaObjSet_exref;
      ppppfStack_438 = (float ****)&local_58;
      ppppfStack_43c = (float ****)0x47ad57;
      ppppfStack_43c = (float ****)__vbaObjSet();
      ppppfStack_440 = local_74;
      ppppfStack_444 = (float ****)0x47ad62;
      __vbaLateIdCallLd();
      ppppfStack_434 = local_254;
      ppppfStack_438 = (float ****)0x47ad74;
      ppppfStack_438 = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_43c = &local_5c;
      ppppfStack_440 = (float ****)0x47ad7b;
      pppppfVar7 = (float *****)__vbaObjSet();
      ppppfStack_440 = local_74;
      ppppfVar12 = *pppppfVar7;
      ppppfStack_444 = (float ****)0x47ad89;
      fVar18 = (float10)__vbaR4Var();
      pppppfVar6 = extraout_ECX_01;
      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
      ppppfStack_3fc = (float ****)(float)(fVar18 * (float10)_DAT_00401fa0);
      ppppfStack_404 = (float ****)0x47adb0;
      ppppfStack_400 = (float ****)pppppfVar7;
      ppppfStack_410 = (float ****)(*(code *)ppppfVar12[0x23])();
      if ((int)ppppfStack_410 < 0) {
        ppppfStack_404 = (float ****)0x8c;
        ppppfStack_408 = (float ****)&DAT_0040c3dc;
        ppppfStack_414 = (float ****)0x47adca;
        ppppfStack_40c = (float ****)pppppfVar7;
        __vbaHresultCheckObj();
      }
      ppppfStack_404 = &local_5c;
      ppppfStack_408 = (float ****)&local_58;
      ppppfStack_40c = (float ****)0x2;
      ppppfStack_410 = (float ****)0x47ade2;
      __vbaFreeObjList();
      ppppfStack_404 = (float ****)0x47adee;
      __vbaFreeVar();
      ppppfStack_404 = local_254;
      ppppfStack_408 = (float ****)0x47adfd;
      ppppfStack_408 = (float ****)(*(code *)(*local_254)[0xd4])();
      ppppfStack_40c = &local_5c;
      ppppfStack_410 = (float ****)0x47ae04;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_410 = &local_21c;
      ppppfStack_418 = (float ****)0x47ae16;
      ppppfStack_414 = (float ****)pppppfVar6;
      pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
      if ((int)pppppfVar7 < 0) {
        ppppfStack_418 = (float ****)0x88;
        ppppfStack_41c = (float ****)&DAT_0040c908;
        ppppfStack_428 = (float ****)0x47ae2a;
        ppppfStack_424 = (float ****)pppppfVar7;
        ppppfStack_420 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_418 = local_254;
      ppppfStack_41c = (float ****)0x47ae39;
      ppppfStack_41c = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_420 = &local_60;
      ppppfStack_424 = (float ****)0x47ae40;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_424 = &local_220;
      ppppfStack_42c = (float ****)0x47ae52;
      ppppfStack_428 = (float ****)pppppfVar6;
      pppppfVar7 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
      if ((int)pppppfVar7 < 0) {
        ppppfStack_42c = (float ****)0x88;
        ppppfStack_430 = (float ****)&DAT_0040c3dc;
        ppppfStack_43c = (float ****)0x47ae66;
        ppppfStack_438 = (float ****)pppppfVar7;
        ppppfStack_434 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_42c = local_254;
      ppppfStack_430 = (float ****)0x47ae75;
      ppppfStack_430 = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_434 = &local_64;
      ppppfStack_438 = (float ****)0x47ae7c;
      pppppfVar7 = (float *****)__vbaObjSet();
      ppppfStack_438 = local_254;
      ppppfStack_43c = (float ****)0x47ae8d;
      ppppfStack_43c = (float ****)(*(code *)(*local_254)[0xd4])();
      ppppfStack_440 = (float ****)&local_58;
      ppppfStack_444 = (float ****)0x47ae94;
      pppppfVar8 = (float *****)__vbaObjSet();
      ppppfStack_444 = (float ****)&local_218;
      ppppfStack_44c = (float ****)0x47aea3;
      ppppfStack_448 = (float ****)pppppfVar8;
      pppppfVar9 = (float *****)(*(code *)(*pppppfVar8)[0x1e])();
      uVar17 = 0;
      pppppfVar6 = extraout_ECX_02;
      if ((int)pppppfVar9 < 0) {
        ppppfStack_3fc = (float ****)0x78;
        ppppfStack_400 = (float ****)&DAT_0040c908;
        ppppfStack_40c = (float ****)0x47aeb8;
        ppppfStack_408 = (float ****)pppppfVar9;
        ppppfStack_404 = (float ****)pppppfVar8;
        __vbaHresultCheckObj();
        pppppfVar6 = extraout_ECX_03;
      }
      ppppfStack_3fc = (float ****)(((float)local_21c + (float)local_218) - (float)local_220);
      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
      ppppfStack_404 = (float ****)0x47aede;
      ppppfStack_400 = (float ****)pppppfVar7;
      ppppfStack_410 = (float ****)(*(code *)(*pppppfVar7)[0x1f])();
      if ((int)ppppfStack_410 < 0) {
        ppppfStack_404 = (float ****)0x7c;
        ppppfStack_408 = (float ****)&DAT_0040c3dc;
        ppppfStack_414 = (float ****)0x47aef3;
        ppppfStack_40c = (float ****)pppppfVar7;
        __vbaHresultCheckObj();
      }
      ppppfStack_404 = &local_64;
      ppppfStack_408 = &local_60;
      ppppfStack_40c = &local_5c;
      ppppfStack_410 = (float ****)&local_58;
      ppppfStack_414 = (float ****)0x4;
      ppppfStack_418 = (float ****)0x47af0b;
      __vbaFreeObjList();
      ppppfStack_404 = local_254;
      ppppfStack_408 = (float ****)0x47af1d;
      ppppfStack_408 = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_40c = &local_5c;
      ppppfStack_410 = (float ****)0x47af24;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_410 = (float ****)0x0;
      ppppfStack_414 = (float ****)0x80010003;
      ppppfVar12 = *pppppfVar6;
      ppppfStack_418 = local_254;
      ppppfStack_41c = (float ****)0x47af3e;
      ppppfStack_41c = (float ****)(*(code *)(*local_254)[0xd7])();
      ppppfStack_420 = (float ****)&local_58;
      ppppfStack_424 = (float ****)0x47af45;
      ppppfStack_424 = (float ****)__vbaObjSet();
      ppppfStack_428 = local_74;
      ppppfStack_42c = (float ****)0x47af50;
      ppppfStack_41c = (float ****)__vbaLateIdCallLd();
      ppppfStack_420 = (float ****)0x47af5a;
      fVar18 = (float10)__vbaR4Var();
      ppppfStack_420 = (float ****)(float)fVar18;
      ppppfStack_428 = (float ****)0x47af62;
      ppppfStack_424 = (float ****)pppppfVar6;
      ppppfStack_434 = (float ****)(*(code *)ppppfVar12[0x1d])();
      if ((int)ppppfStack_434 < 0) {
        ppppfStack_428 = (float ****)0x74;
        ppppfStack_42c = (float ****)&DAT_0040c3dc;
        ppppfStack_438 = (float ****)0x47af77;
        ppppfStack_430 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_428 = &local_5c;
      ppppfStack_42c = (float ****)&local_58;
      ppppfStack_430 = (float ****)0x2;
      ppppfStack_434 = (float ****)0x47af87;
      __vbaFreeObjList();
      ppppfStack_428 = (float ****)0x47af93;
      __vbaFreeVar();
      ppppfStack_428 = local_254;
      ppppfStack_42c = (float ****)0x47afa2;
      ppppfStack_42c = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_430 = &local_5c;
      ppppfStack_434 = (float ****)0x47afa9;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_434 = (float ****)0x0;
      ppppfStack_438 = (float ****)0x80010005;
      ppppfVar12 = *pppppfVar6;
      ppppfStack_43c = local_254;
      ppppfStack_440 = (float ****)0x47afc3;
      ppppfStack_440 = (float ****)(*(code *)(*local_254)[0xd7])();
      ppppfStack_444 = (float ****)&local_58;
      ppppfStack_448 = (float ****)0x47afca;
      ppppfStack_448 = (float ****)__vbaObjSet();
      ppppfStack_44c = local_74;
      ppppfStack_450 = (float ****)0x47afd5;
      ppppfStack_440 = (float ****)__vbaLateIdCallLd();
      ppppfStack_444 = (float ****)0x47afdf;
      fVar18 = (float10)__vbaR4Var();
      ppppfStack_444 = (float ****)(float)fVar18;
      ppppfStack_44c = (float ****)0x47afea;
      ppppfStack_448 = (float ****)pppppfVar6;
      ppppfStack_458 = (float ****)(*(code *)ppppfVar12[0x21])();
      pppppfVar7 = (float *****)__vbaHresultCheckObj_exref;
      if ((int)ppppfStack_458 < 0) {
        ppppfStack_44c = (float ****)0x84;
        ppppfStack_450 = (float ****)&DAT_0040c3dc;
        ppppfStack_45c = (float ****)0x47b004;
        ppppfStack_454 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_44c = &local_5c;
      ppppfStack_450 = (float ****)&local_58;
      ppppfStack_454 = (float ****)0x2;
      ppppfStack_458 = (float ****)0x47b01c;
      __vbaFreeObjList();
      ppppfStack_44c = (float ****)0x47b028;
      __vbaFreeVar();
      ppppfStack_44c = local_254;
      ppppfStack_450 = (float ****)0x47b037;
      ppppfStack_450 = (float ****)(*(code *)(*local_254)[0xc5])();
      ppppfStack_454 = &local_5c;
      ppppfStack_458 = (float ****)0x47b03e;
      local_22c = (float ****)__vbaObjSet();
      ppppfStack_458 = local_254;
      ppppfStack_45c = (float ****)0x47b053;
      ppppfStack_45c = (float ****)(*(code *)(*local_254)[0xca])();
      ppppfStack_460 = (float ****)&local_58;
      ppppfStack_464 = (float ****)0x47b05a;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_464 = (float ****)&local_218;
      ppppfStack_46c = (float ****)0x47b069;
      ppppfStack_468 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x1c])();
      if ((int)pppppfVar8 < 0) {
        ppppfStack_46c = (float ****)0x70;
        ppppfStack_470 = (float ****)&DAT_0040ba5c;
        ppppfStack_47c = (float ****)0x47b07a;
        ppppfStack_478 = (float ****)pppppfVar8;
        ppppfStack_474 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfVar12 = local_22c;
      ppppfStack_46c = local_218;
      ppppfStack_470 = local_22c;
      ppppfStack_474 = (float ****)0x47b08d;
      ppppfStack_480 = (float ****)(*(code *)(*local_22c)[0x1b])();
      if ((int)ppppfStack_480 < 0) {
        ppppfStack_474 = (float ****)0x6c;
        ppppfStack_478 = (float ****)&DAT_0040c3cc;
        ppppfStack_47c = ppppfVar12;
        ppppfStack_484 = (float ****)0x47b09e;
        __vbaHresultCheckObj();
      }
      ppppfStack_474 = &local_5c;
      ppppfStack_478 = (float ****)&local_58;
      ppppfStack_47c = (float ****)0x2;
      ppppfStack_480 = (float ****)0x47b0ae;
      __vbaFreeObjList();
      ppppfStack_474 = local_254;
      ppppfStack_478 = (float ****)0x47b0c0;
      ppppfStack_478 = (float ****)(*(code *)(*local_254)[0xc6])();
      ppppfStack_47c = &local_5c;
      ppppfStack_480 = (float ****)0x47b0c7;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_480 = &local_21c;
      ppppfStack_488 = (float ****)0x47b0d9;
      ppppfStack_484 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
      if ((int)pppppfVar8 < 0) {
        ppppfStack_488 = (float ****)0x88;
        ppppfStack_48c = (float ****)&DAT_0040dc58;
        ppppfStack_498 = (float ****)0x47b0ed;
        ppppfStack_494 = (float ****)pppppfVar8;
        ppppfStack_490 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_488 = local_254;
      ppppfStack_48c = (float ****)0x47b0fc;
      ppppfStack_48c = (float ****)(*(code *)(*local_254)[0xc6])();
      ppppfStack_490 = (float ****)&local_58;
      ppppfStack_494 = (float ****)0x47b103;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_494 = (float ****)&local_218;
      pppfStack_49c = (float ***)0x47b112;
      ppppfStack_498 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
      uVar17 = 0;
      if ((int)pppppfVar8 < 0) {
        ppppfStack_400 = (float ****)0x78;
        ppppfStack_404 = (float ****)&DAT_0040dc58;
        ppppfStack_410 = (float ****)0x47b123;
        ppppfStack_40c = (float ****)pppppfVar8;
        ppppfStack_408 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      pppppfVar6 = (float *****)ppppfStack_3fc;
      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
      ppppfStack_400 = (float ****)0x47b145;
      local_1c = __vbaFpI4();
      ppppfStack_400 = &local_5c;
      ppppfStack_404 = (float ****)&local_58;
      ppppfStack_408 = (float ****)0x2;
      ppppfStack_40c = (float ****)0x47b158;
      __vbaFreeObjList();
      ppppfStack_400 = local_254;
      ppppfStack_404 = (float ****)0x47b16a;
      ppppfStack_404 = (float ****)(*(code *)(*local_254)[0xc5])();
      ppppfStack_408 = (float ****)&local_58;
      ppppfStack_40c = (float ****)0x47b171;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_40c = (float ****)(float)local_1c;
      ppppfStack_414 = (float ****)0x47b189;
      ppppfStack_410 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x1d])();
      if ((int)pppppfVar8 < 0) {
        ppppfStack_414 = (float ****)0x74;
        ppppfStack_418 = (float ****)&DAT_0040c3cc;
        ppppfStack_424 = (float ****)0x47b19a;
        ppppfStack_420 = (float ****)pppppfVar8;
        ppppfStack_41c = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_414 = (float ****)0x47b1a3;
      __vbaFreeObj();
      ppppfStack_414 = local_254;
      ppppfStack_418 = (float ****)0x47b1b2;
      ppppfStack_418 = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_41c = (float ****)&local_58;
      ppppfStack_420 = (float ****)0x47b1b9;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_420 = (float ****)&local_218;
      ppppfStack_428 = (float ****)0x47b1cb;
      ppppfStack_424 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x22])();
      uVar17 = 0;
      if ((int)pppppfVar8 < 0) {
        ppppfStack_428 = (float ****)0x88;
        ppppfStack_42c = (float ****)&DAT_0040c3dc;
        ppppfStack_438 = (float ****)0x47b1df;
        ppppfStack_434 = (float ****)pppppfVar8;
        ppppfStack_430 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_428 = local_254;
      ppppfStack_42c = (float ****)0x47b1ee;
      ppppfStack_42c = (float ****)(*(code *)(*local_254)[0xc5])();
      ppppfStack_430 = &local_5c;
      ppppfStack_434 = (float ****)0x47b1f5;
      pppppfVar8 = (float *****)__vbaObjSet();
      pppppfVar6 = (float *****)ppppfStack_3fc;
      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
      ppppfStack_408 = (float ****)0x47b226;
      ppppfStack_404 = (float ****)pppppfVar8;
      ppppfStack_400 = (float ****)((float)local_218 * (float)_DAT_00401f98);
      ppppfStack_414 = (float ****)(*(code *)(*pppppfVar8)[0x21])();
      if ((int)ppppfStack_414 < 0) {
        ppppfStack_408 = (float ****)0x84;
        ppppfStack_40c = (float ****)&DAT_0040c3cc;
        ppppfStack_418 = (float ****)0x47b23a;
        ppppfStack_410 = (float ****)pppppfVar8;
        __vbaHresultCheckObj();
      }
      ppppfStack_408 = &local_5c;
      ppppfStack_40c = (float ****)&local_58;
      ppppfStack_410 = (float ****)0x2;
      ppppfStack_414 = (float ****)0x47b24a;
      __vbaFreeObjList();
      ppppfStack_408 = local_254;
      ppppfStack_40c = (float ****)0x47b25c;
      ppppfStack_40c = (float ****)(*(code *)(*local_254)[0xc3])();
      ppppfStack_410 = (float ****)&local_58;
      ppppfStack_414 = (float ****)0x47b263;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_414 = (float ****)&local_218;
      ppppfStack_41c = (float ****)0x47b275;
      ppppfStack_418 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
      uVar17 = 0;
      if ((int)pppppfVar8 < 0) {
        ppppfStack_41c = (float ****)0x80;
        ppppfStack_420 = (float ****)&DAT_0040c3dc;
        ppppfStack_42c = (float ****)0x47b289;
        ppppfStack_428 = (float ****)pppppfVar8;
        ppppfStack_424 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_41c = local_254;
      ppppfStack_420 = (float ****)0x47b298;
      ppppfStack_420 = (float ****)(*(code *)(*local_254)[0xc5])();
      ppppfStack_424 = &local_5c;
      ppppfStack_428 = (float ****)0x47b29f;
      pppppfVar8 = (float *****)__vbaObjSet();
      pppppfVar6 = (float *****)ppppfStack_3fc;
      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
      ppppfStack_408 = (float ****)0x47b2cd;
      ppppfStack_404 = (float ****)pppppfVar8;
      ppppfStack_400 = (float ****)((float)local_218 * (float)_DAT_00401f90);
      ppppfStack_414 = (float ****)(*(code *)(*pppppfVar8)[0x1f])();
      if ((int)ppppfStack_414 < 0) {
        ppppfStack_408 = (float ****)0x7c;
        ppppfStack_40c = (float ****)&DAT_0040c3cc;
        ppppfStack_418 = (float ****)0x47b2de;
        ppppfStack_410 = (float ****)pppppfVar8;
        __vbaHresultCheckObj();
      }
      ppppfStack_408 = &local_5c;
      ppppfStack_40c = (float ****)&local_58;
      ppppfStack_410 = (float ****)0x2;
      ppppfStack_414 = (float ****)0x47b2ee;
      __vbaFreeObjList();
      ppppfStack_408 = local_254;
      ppppfStack_40c = (float ****)0x47b300;
      ppppfStack_40c = (float ****)(*(code *)(*local_254)[0xc5])();
      ppppfStack_410 = (float ****)&local_58;
      ppppfStack_414 = (float ****)0x47b307;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_414 = (float ****)&local_218;
      ppppfStack_41c = (float ****)0x47b319;
      ppppfStack_418 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x20])();
      uVar17 = 0;
      if ((int)pppppfVar8 < 0) {
        ppppfStack_41c = (float ****)0x80;
        ppppfStack_420 = (float ****)&DAT_0040c3cc;
        ppppfStack_42c = (float ****)0x47b32d;
        ppppfStack_428 = (float ****)pppppfVar8;
        ppppfStack_424 = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfStack_41c = local_254;
      ppppfStack_420 = (float ****)0x47b33c;
      ppppfStack_420 = (float ****)(*(code *)(*local_254)[0xc4])();
      ppppfStack_424 = &local_5c;
      ppppfStack_428 = (float ****)0x47b343;
      ppppfVar12 = (float ****)__vbaObjSet();
      ppppfStack_3fc = (float ****)((float)local_218 + (float)local_1c);
      pppppfVar6 = (float *****)*ppppfVar12;
      if ((uVar17 & 0xd) != 0) goto LAB_0047ea90;
      ppppfStack_404 = (float ****)0x47b37a;
      ppppfStack_400 = ppppfVar12;
      ppppfStack_410 = (float ****)(*(code *)(*ppppfVar12)[0x1d])();
      if ((int)ppppfStack_410 < 0) {
        ppppfStack_404 = (float ****)0x74;
        ppppfStack_408 = (float ****)&DAT_0040c3cc;
        ppppfStack_414 = (float ****)0x47b38b;
        ppppfStack_40c = ppppfVar12;
        __vbaHresultCheckObj();
      }
      ppppfStack_404 = &local_5c;
      ppppfStack_408 = (float ****)&local_58;
      ppppfStack_40c = (float ****)0x2;
      ppppfStack_410 = (float ****)0x47b39b;
      __vbaFreeObjList();
      ppppfStack_404 = local_254;
      ppppfStack_408 = (float ****)0x47b3ad;
      ppppfStack_408 = (float ****)(*(code *)(*local_254)[0xc4])();
      ppppfStack_40c = &local_5c;
      ppppfStack_410 = (float ****)0x47b3b4;
      local_22c = (float ****)__vbaObjSet();
      ppppfStack_410 = local_254;
      ppppfStack_414 = (float ****)0x47b3c9;
      ppppfStack_414 = (float ****)(*(code *)(*local_254)[0xc5])();
      ppppfStack_418 = (float ****)&local_58;
      ppppfStack_41c = (float ****)0x47b3d0;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_41c = (float ****)&local_218;
      ppppfStack_424 = (float ****)0x47b3df;
      ppppfStack_420 = (float ****)pppppfVar6;
      pppppfVar8 = (float *****)(*(code *)(*pppppfVar6)[0x1e])();
      if ((int)pppppfVar8 < 0) {
        ppppfStack_424 = (float ****)0x78;
        ppppfStack_428 = (float ****)&DAT_0040c3cc;
        ppppfStack_434 = (float ****)0x47b3f0;
        ppppfStack_430 = (float ****)pppppfVar8;
        ppppfStack_42c = (float ****)pppppfVar6;
        __vbaHresultCheckObj();
      }
      ppppfVar12 = local_22c;
      ppppfStack_424 = local_218;
      ppppfStack_428 = local_22c;
      ppppfStack_42c = (float ****)0x47b403;
      ppppfStack_438 = (float ****)(*(code *)(*local_22c)[0x1f])();
      if ((int)ppppfStack_438 < 0) {
        ppppfStack_42c = (float ****)0x7c;
        ppppfStack_430 = (float ****)&DAT_0040c3cc;
        ppppfStack_434 = ppppfVar12;
        ppppfStack_43c = (float ****)0x47b414;
        __vbaHresultCheckObj();
      }
      ppppfStack_42c = &local_5c;
      ppppfStack_430 = (float ****)&local_58;
      ppppfStack_434 = (float ****)0x2;
      ppppfStack_438 = (float ****)0x47b424;
      __vbaFreeObjList();
      uVar13 = DAT_0050b3c4;
      ppppfVar12 = (float ****)0x1;
      goto LAB_0047b437;
    }
  }
  goto LAB_0047ea95;
  while( true ) {
    ppppfStack_400 = local_254;
    ppppfStack_404 = (float ****)0x47b456;
    ppppfStack_404 = (float ****)(*(code *)(*local_254)[199])();
    ppppfStack_408 = (float ****)&local_58;
    ppppfStack_40c = (float ****)0x47b45d;
    pppppfVar8 = (float *****)__vbaObjSet();
    local_16c = (float ****)0x80020004;
    local_174 = (float ****)0xa;
    if ((DAT_0050b3d0 == (short *)0x0) || (*DAT_0050b3d0 != 1)) {
      ppppfStack_40c = (float ****)0x47b4b4;
      local_348 = __vbaGenerateBoundsError();
    }
    else {
      iVar11 = (int)(short)local_20;
      iVar3 = *(int *)(DAT_0050b3d0 + 10);
      if (*(uint *)(DAT_0050b3d0 + 8) <= (uint)(iVar11 - iVar3)) {
        ppppfStack_40c = (float ****)0x47b499;
        __vbaGenerateBoundsError();
      }
      local_348 = (iVar11 - iVar3) * 4;
    }
    ppppfStack_418 = local_174;
    ppppfStack_414 = local_170;
    ppppfStack_410 = local_16c;
    ppppfStack_40c = local_168;
    ppppfStack_41c = *(float *****)(*(int *)(DAT_0050b3d0 + 6) + local_348);
    ppppfStack_424 = (float ****)0x47b4fe;
    ppppfStack_420 = (float ****)pppppfVar8;
    pppppfVar6 = (float *****)(*(code *)(*pppppfVar8)[0x7b])();
    pppppfVar7 = (float *****)__vbaHresultCheckObj_exref;
    if ((int)pppppfVar6 < 0) {
      ppppfStack_424 = (float ****)0x1ec;
      ppppfStack_428 = (float ****)&DAT_0040dc58;
      ppppfStack_434 = (float ****)0x47b518;
      ppppfStack_430 = (float ****)pppppfVar6;
      ppppfStack_42c = (float ****)pppppfVar8;
      __vbaHresultCheckObj();
    }
    ppppfStack_424 = (float ****)0x47b529;
    __vbaFreeObj();
    ppppfVar12 = (float ****)(uint)(ushort)((short)local_20 + 1);
    if (SCARRY2((short)local_20,1)) break;
LAB_0047b437:
    local_294 = (short)uVar13;
    local_20 = (float ***)ppppfVar12;
    if (local_294 < (short)ppppfVar12) {
      ppppfStack_400 = local_254;
      ppppfStack_404 = (float ****)0x47b546;
      ppppfStack_404 = (float ****)(*(code *)(*local_254)[0xc6])();
      ppppfStack_408 = (float ****)&local_58;
      ppppfStack_40c = (float ****)0x47b54d;
      pppppfVar6 = (float *****)__vbaObjSet();
      ppppfStack_40c = (float ****)0x0;
      ppppfStack_414 = (float ****)0x47b55a;
      ppppfStack_410 = (float ****)pppppfVar6;
      pppppfVar5 = (float *****)(*(code *)(*pppppfVar6)[0x25])();
      if ((int)pppppfVar5 < 0) {
        ppppfStack_414 = (float ****)0x94;
        ppppfStack_418 = (float ****)&DAT_0040dc58;
        ppppfStack_424 = (float ****)0x47b56e;
        ppppfStack_420 = (float ****)pppppfVar5;
        ppppfStack_41c = (float ****)pppppfVar6;
        (*(code *)pppppfVar7)();
      }
      ppppfStack_414 = (float ****)0x47b577;
      __vbaFreeObj();
      ppppfStack_404 = (float ****)&local_254;
      goto LAB_0047e95f;
    }
  }
LAB_0047ea95:
  ppppfStack_400 = (float ****)0x47ea9b;
  __vbaErrorOverflow();
  ppppfStack_410 = (float ****)&DAT_00402706;
  ppppfStack_414 = ExceptionList;
  ppppfStack_40c = (float ****)&ppppfStack_4b0;
  ppppfStack_408 = (float ****)&DAT_00401fe0;
  ppppfStack_404 = (float ****)((uint)ppppfStack_3f8 & 1);
  ppppfStack_4b4 = (float ****)((uint)ppppfStack_3f8 & 0xfffffffe);
  ppppfStack_4b8 = (float ****)0x47eae2;
  ExceptionList = &ppppfStack_414;
  ppppfStack_4b0 = (float ****)pppppfVar7;
  ppppfStack_4ac = (float ****)pppppfVar8;
  pppfStack_4a8 = (float ***)pppppfVar5;
  ppppfStack_400 = (float ****)&stack0xfffffffc;
  ppppfStack_3f8 = ppppfStack_4b4;
  (**(code **)((int)*ppppfStack_4b4 + 4))();
  ppppfStack_428 = (float ****)0x0;
  ppppfStack_438 = (float ****)0x0;
  ppppfStack_448 = (float ****)0x0;
  ppppfStack_458 = (float ****)0x0;
  ppppfStack_468 = (float ****)0x0;
  ppppfStack_478 = (float ****)0x0;
  if (DAT_0050b238 == 3) {
    if (DAT_0050b27c == -0x56ce) {
      ppppfStack_450 = (float ****)0x80020004;
      ppppfStack_440 = (float ****)0x80020004;
      DAT_0050b27c = 0;
      ppppfStack_458 = (float ****)0xa;
      ppppfStack_448 = (float ****)0xa;
      ppppfStack_470 = (float ****)0x410680;
      ppppfStack_478 = (float ****)0x8;
      ppppfStack_4b8 = (float ****)0x47eb6d;
      __vbaVarDup();
      ppppfStack_460 = (float ****)0x4105c4;
      ppppfStack_468 = (float ****)0x8;
      ppppfStack_4b8 = (float ****)0x47eb7f;
      __vbaVarDup();
      ppppfStack_4b8 = (float ****)&ppppfStack_458;
      ppppfStack_4bc = (float ****)&ppppfStack_448;
      ppppfStack_4c0 = (float ****)&ppppfStack_438;
      ppppfStack_4c8 = (float ****)&ppppfStack_428;
      ppppfStack_4c4 = (float ****)0x10;
      ppppfStack_4cc = (float ****)0x47eb97;
      Ordinal_595();
      ppppfStack_4cc = (float ****)&ppppfStack_458;
      ppppfStack_4d0 = (float ****)&ppppfStack_448;
      ppppfStack_4d4 = (float ****)&ppppfStack_438;
      ppppfStack_4d8 = (float ****)&ppppfStack_428;
      pppfStack_4dc = (float ***)0x4;
      __vbaFreeVarList();
    }
    else {
      ppppfStack_4b8 = (float ****)0x47ebb9;
      FUN_004703b0();
    }
  }
  else if (DAT_0050b238 == 8) {
    ppppfStack_4b8 = (float ****)&DAT_0050b3d4;
    ppppfStack_4bc = (float ****)&DAT_0050b3d8;
    ppppfStack_4c0 = (float ****)&DAT_0050b3d4;
    ppppfStack_4c4 = (float ****)0x47eb1f;
    FUN_004f3330();
  }
  return;
}


