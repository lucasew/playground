/* entry 0042a330 name FUN_0042a330 size 1186 */
/* strings:
 * TRANSPORTATION MODEL
 * PROJECT PLANNING -- PERT/CPM
 * INVENTORY MODELS
 * SIMULATION
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0042a330(void)

{
  int *piVar1;
  undefined1 *puVar2;
  int iVar3;
  ushort uVar4;
  float10 fVar5;
  int *piVar6;
  int **ppiVar7;
  float local_64;
  float local_60 [3];
  undefined4 local_54;
  int *local_4c;
  int *local_48;
  undefined4 local_44;
  undefined4 local_34;
  undefined4 local_24;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined1 *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff68;
  local_8 = &LAB_00401678;
  _DAT_0050b028 = 0x3f800000;
  DAT_0050b024 = 0x3f800000;
  local_24 = 0;
  local_34 = 0;
  local_44 = 0;
  local_48 = (int *)0x0;
  local_4c = (int *)0x0;
  local_60[1] = 0.0;
  local_60[0] = 0.0;
  local_64 = 0.0;
  ExceptionList = &pvStack_14;
  puVar2 = &stack0xffffff68;
  if (DAT_0050c53c == (int *)0x0) {
    ExceptionList = &pvStack_14;
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    puVar2 = local_c;
  }
  local_c = puVar2;
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_48);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
  }
  piVar1 = local_48;
  iVar3 = (**(code **)(*local_48 + 0x98))(local_48,local_60);
  uVar4 = 0;
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x98);
  }
  if (DAT_0050b000 != 0) {
    adj_fdiv_m32(DAT_00401670);
  }
  if ((uVar4 & 0xd) == 0) {
    DAT_0050b1c6 = __vbaFpI2();
    __vbaFreeObj();
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar1 = DAT_0050c53c;
    piVar6 = DAT_0050c53c;
    iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_48);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
    }
    piVar1 = local_48;
    iVar3 = (**(code **)(*local_48 + 0x50))(local_48,local_60);
    uVar4 = 0;
    if (iVar3 < 0) {
      piVar6 = (int *)&DAT_0040bb5c;
      __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x50);
    }
    if (DAT_0050b000 != 0) {
      adj_fdiv_m64(piVar6,DAT_0040166c,DAT_00401668);
    }
    if ((uVar4 & 0xd) == 0) {
      DAT_0050b1c8 = __vbaFpI2();
      __vbaFreeObj();
      DAT_0050b1c4 = 0;
      DAT_0050b1fc = 0;
      _DAT_0050b2ba = 0;
      DAT_0050b29a = 0;
      DAT_0050b240 = 0;
      DAT_0050b274 = 0;
      DAT_0050b1ca = 0;
      local_54 = 0xffffffff;
      local_60[1] = 1.54143e-44;
      __vbaVarMove();
      if (DAT_0050c53c == (int *)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      piVar1 = DAT_0050c53c;
      ppiVar7 = &local_4c;
      iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,ppiVar7);
      if (iVar3 < 0) {
        __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
      }
      piVar1 = local_4c;
      iVar3 = (**(code **)(*local_4c + 0x50))(local_4c,&local_64);
      if (iVar3 < 0) {
        __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x50);
      }
      if (DAT_0050c53c == (int *)0x0) {
        __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
      }
      piVar1 = DAT_0050c53c;
      iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_48);
      if (iVar3 < 0) {
        __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
      }
      piVar1 = local_48;
      iVar3 = (**(code **)(*local_48 + 0x98))(local_48,local_60);
      uVar4 = 0;
      if (iVar3 < 0) {
        ppiVar7 = (int **)0x98;
        __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x98);
      }
      if (DAT_0050b000 == 0) {
        fVar5 = (float10)local_60[0] / (float10)local_64;
      }
      else {
        fVar5 = (float10)adj_fdiv_m32(ppiVar7,local_64);
      }
      _DAT_0050b16c = (double)fVar5;
      if ((uVar4 & 0xd) == 0) {
        __vbaFreeObjList(2,&local_48,&local_4c);
        DAT_0050b1ce = 0;
        DAT_0050b1d2 = 0;
        DAT_0050b208 = 0;
        DAT_0050b218 = 0;
        _DAT_0050b216 = 0;
        _DAT_0050b144 = 0;
        _DAT_0050b148 = 0;
        _DAT_0050b12c = 0xe2308c3a;
        _DAT_0050b130 = 0x3e45798e;
        DAT_0050b134 = 0;
        DAT_0050b138 = 0x412e847e;
        _DAT_0050b0e0 = 0;
        _DAT_0050b0e4 = 0x40590000;
        local_54 = 0;
        local_60[1] = 2.8026e-45;
        __vbaVarMove();
        local_54 = 0;
        local_60[1] = 2.8026e-45;
        __vbaVarMove();
        DAT_0050b220 = 0;
        DAT_0050b228 = 5;
        DAT_0050b22c = 5;
        _DAT_0050b222 = 0;
        DAT_0050b230._2_2_ = 0;
        DAT_0050b336 = 0;
        _DAT_0050b2dc = 0;
        DAT_0050b338 = 0;
        DAT_0050b304 = 0;
        DAT_0050b230._0_2_ = 2;
        DAT_0050b21e = 1;
        DAT_0050b22a = 2;
        DAT_0050b22e = 2;
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaStrCopy();
        __vbaFreeVar(&LAB_0042a7e1);
        __vbaFreeVar();
        __vbaFreeVar();
        return;
      }
    }
  }
  __vbaFPException();
  return;
}


