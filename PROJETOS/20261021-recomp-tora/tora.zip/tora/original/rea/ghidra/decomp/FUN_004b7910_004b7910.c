/* entry 004b7910 name FUN_004b7910 size 2963 */
/* strings:
 * (North-West Corner Method)
 * (Least Cost Method)
 * (Vogel's Method)
 * TRANSPORTATION TABLEAU - 
 * Steps for generating transportation tableaus:
 * 1.  (Optional step) Initialize ONE of the simplex multiplier (u1, u2, ..., v1, v2 ...) to zero value (default u1 = 0)
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004b7910(void)

{
  int *piVar1;
  undefined1 *puVar2;
  int iVar3;
  undefined4 uVar4;
  ushort uVar5;
  float *pfVar6;
  int *piVar7;
  int *local_84 [11];
  float *local_58;
  float local_54;
  float local_50 [6];
  undefined4 local_38;
  undefined4 local_30;
  int *local_2c;
  undefined4 local_28;
  undefined4 local_24 [2];
  undefined4 local_1c;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffff50;
  local_8 = &DAT_004022b8;
  local_1c = 0;
  local_24[0] = 0;
  local_28 = 0;
  local_2c = (int *)0x0;
  local_50[0] = 0.0;
  local_54 = 0.0;
  local_58 = (float *)0x0;
  local_84[0] = (int *)0x0;
  ExceptionList = &pvStack_14;
  puVar2 = &stack0xffffff50;
  if (DAT_0050b420 == (int *)0x0) {
    ExceptionList = &pvStack_14;
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    puVar2 = local_c;
  }
  local_c = puVar2;
  __vbaObjSetAddref(local_84,DAT_0050b420);
  iVar3 = (**(code **)(*local_84[0] + 0x248))(local_84[0],&local_2c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,local_84[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,0,8,local_38,L"arial",local_30);
  __vbaFreeObj();
  iVar3 = (**(code **)(*local_84[0] + 0x248))(local_84[0],&local_2c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,local_84[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,2,2,local_38,6,local_30);
  __vbaFreeObj();
  iVar3 = (**(code **)(*local_84[0] + 0x6c))(local_84[0],0xffffff);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,local_84[0],&DAT_0040b430,0x6c);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  __vbaObjSetAddref(&local_2c,DAT_0050b420);
  FUN_0048c990(&local_2c);
  uVar4 = __vbaCastObj(local_2c,&DAT_0040b85c);
  __vbaObjSet(&DAT_0050b420,uVar4);
  __vbaFreeObj();
  iVar3 = (**(code **)(*local_84[0] + 0x248))(local_84[0],&local_2c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,local_84[0],&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,3,0xb,local_38,0xffffffff,local_30);
  __vbaFreeObj();
  __vbaObjSetAddref(local_84,0);
  if (((DAT_0050b2c8 == 1) || (DAT_0050b2c8 == 2)) || (DAT_0050b2c8 == 3)) {
    __vbaStrCopy();
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar1 = DAT_0050b420;
  iVar3 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,2,2,local_38,10,local_30);
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar1 = DAT_0050b420;
  iVar3 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0x248);
  }
  __vbaLateIdSt(local_2c,3,0xb,local_38,0xffffffff,local_30);
  __vbaFreeObj();
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar1 = DAT_0050b420;
  piVar7 = DAT_0050b420;
  iVar3 = (**(code **)(*DAT_0050b420 + 300))(DAT_0050b420,1);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,300);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar1 = DAT_0050b420;
  pfVar6 = local_50;
  iVar3 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,pfVar6);
  uVar5 = 0;
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe8);
  }
  if (DAT_0050b420 == (int *)0x0) {
    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
  }
  piVar1 = DAT_0050b420;
  if ((uVar5 & 0xd) == 0) {
    iVar3 = (**(code **)(*DAT_0050b420 + 0xec))(DAT_0050b420,local_50[0] * (float)_DAT_004013f0);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xec);
    }
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar1 = DAT_0050c53c;
    iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
    }
    piVar1 = local_2c;
    iVar3 = (**(code **)(*local_2c + 0x98))(local_2c,local_50);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x98);
    }
    if (DAT_0050b420 == (int *)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    piVar1 = DAT_0050b420;
    iVar3 = *DAT_0050b420;
    __vbaStrCat(local_1c,L"TRANSPORTATION TABLEAU - ",&local_54);
    uVar4 = __vbaStrMove();
    iVar3 = (**(code **)(iVar3 + 0x2e4))(piVar1,uVar4);
    uVar5 = 0;
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0x2e4);
    }
    if (DAT_0050b420 == (int *)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    piVar1 = DAT_0050b420;
    if ((uVar5 & 0xd) == 0) {
      if ((uVar5 & 0xd) == 0) {
        iVar3 = (**(code **)(*DAT_0050b420 + 0xe4))
                          (DAT_0050b420,
                           DAT_0050b024 * (float)_DAT_00401268 * (local_50[0] - local_54));
        if (iVar3 < 0) {
          __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe4);
        }
        __vbaFreeStr();
        __vbaFreeObj();
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        __vbaStrCat(local_1c,L"TRANSPORTATION TABLEAU - ");
        uVar4 = __vbaStrMove();
        __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,uVar4);
        __vbaFreeStr();
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar1 = DAT_0050b420;
        iVar3 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44960000);
        if (iVar3 < 0) {
          __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe4);
        }
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        __vbaStrCat(*(undefined4 *)(DAT_0050b37c + 4),L"Title: ");
        uVar4 = __vbaStrMove();
        __vbaStrCat(L" --(minimum cost)",uVar4);
        uVar4 = __vbaStrMove();
        __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,uVar4);
        __vbaFreeStrList(2,local_24,&local_28);
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar1 = DAT_0050b420;
        iVar3 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,local_50);
        if (iVar3 < 0) {
          __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe8);
        }
        if (DAT_0050c53c == (int *)0x0) {
          __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
        }
        piVar1 = DAT_0050c53c;
        iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
        if (iVar3 < 0) {
          __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
        }
        piVar1 = local_2c;
        iVar3 = (**(code **)(*local_2c + 0x98))(local_2c,&local_54);
        if (iVar3 < 0) {
          __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x98);
        }
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar1 = DAT_0050b420;
        iVar3 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_58);
        uVar5 = 0;
        if (iVar3 < 0) {
          __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe8);
        }
        if (DAT_0050b420 == (int *)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        piVar1 = DAT_0050b420;
        piVar7 = (int *)0x0;
        pfVar6 = local_58;
        if ((uVar5 & 0xd) == 0) {
          iVar3 = (**(code **)(*DAT_0050b420 + 0x2c8))
                            (DAT_0050b420,4,0x44960000,local_50[0],local_54 - _DAT_004020e0,local_58
                             ,0);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0x2c8);
          }
          __vbaFreeObj();
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0x248))(DAT_0050b420,&local_2c);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0x248);
          }
          __vbaLateIdSt(local_2c,2,2,local_38,8,local_30);
          __vbaFreeObj();
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44960000);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe4);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,L"Steps for generating transportation tableaus:")
          ;
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44c80000);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe4);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                        L"1.  (Optional step) Initialize ONE of the simplex multiplier (u1, u2, ..., v1, v2 ...) to zero value (default u1 = 0)"
                       );
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44c80000);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe4);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                        L"2.  Click (in any order) the cells defining the change-of-basis loop (if corret, cell changes color)"
                       );
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0xe4))(DAT_0050b420,0x44c80000);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe4);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,
                        L"3.  Click command button NEXT ITERATION (or ALL ITERATIONS) -- This step may be executed without Step 2"
                       );
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,local_50);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe8);
          }
          if (DAT_0050c53c == (int *)0x0) {
            __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
          }
          piVar1 = DAT_0050c53c;
          iVar3 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&local_2c);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x18);
          }
          piVar1 = local_2c;
          iVar3 = (**(code **)(*local_2c + 0x98))(local_2c,&local_54);
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040bb5c,0x98);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          iVar3 = (**(code **)(*DAT_0050b420 + 0xe8))(DAT_0050b420,&local_58);
          uVar5 = 0;
          if (iVar3 < 0) {
            __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0xe8);
          }
          if (DAT_0050b420 == (int *)0x0) {
            __vbaNew2(&DAT_00408c88,&DAT_0050b420);
          }
          piVar1 = DAT_0050b420;
          piVar7 = (int *)0x0;
          pfVar6 = local_58;
          if ((uVar5 & 0xd) == 0) {
            iVar3 = (**(code **)(*DAT_0050b420 + 0x2c8))
                              (DAT_0050b420,4,0x44960000,local_50[0],local_54 - _DAT_004020e0);
            if (iVar3 < 0) {
              __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b430,0x2c8);
            }
            __vbaFreeObj();
            __vbaFreeObj(&LAB_004b84bb);
            __vbaFreeStr();
            return;
          }
        }
      }
    }
  }
  __vbaFPException(pfVar6,piVar7);
  return;
}


