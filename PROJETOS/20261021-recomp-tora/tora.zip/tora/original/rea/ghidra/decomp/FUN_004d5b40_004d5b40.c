/* entry 004d5b40 name FUN_004d5b40 size 397 */

void FUN_004d5b40(int *param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined1 *puVar2;
  int iVar3;
  int iVar4;
  undefined4 local_28;
  undefined4 local_20;
  undefined4 local_1c [2];
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined1 *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xffffffac;
  local_8 = &LAB_00402438;
  local_1c[0] = 0;
  iVar4 = *param_1;
  ExceptionList = &pvStack_14;
  puVar2 = &stack0xffffffac;
  if (DAT_0050c53c == (int *)0x0) {
    ExceptionList = &pvStack_14;
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    puVar2 = local_c;
  }
  local_c = puVar2;
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  __vbaLateIdSt(local_1c[0],0x1000a,4,local_28,(float)iVar4,local_20);
  __vbaFreeObj();
  iVar4 = *param_2;
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar1 = DAT_0050c53c;
  iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,local_1c);
  if (iVar3 < 0) {
    __vbaHresultCheckObj(iVar3,piVar1,&DAT_0040b410,0x20);
  }
  __vbaLateIdSt(local_1c[0],0x1000b,4,local_28,(float)iVar4,local_20);
  __vbaFreeObj();
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar1 = DAT_0050c53c;
  iVar4 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,local_1c);
  if (iVar4 < 0) {
    __vbaHresultCheckObj(iVar4,piVar1,&DAT_0040b410,0x20);
  }
  __vbaPrintObj(&DAT_0040bf08,local_1c[0],*param_3);
  __vbaFreeObj();
  return;
}


