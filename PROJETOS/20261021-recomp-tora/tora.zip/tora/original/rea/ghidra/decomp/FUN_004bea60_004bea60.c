/* entry 004bea60 name FUN_004bea60 size 3791 */
/* strings:
 * All arcs from from current node have infinite length. No spanning tree exists.
 */

/* WARNING: Removing unreachable block (ram,0x004bf99c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bea60(void)

{
  float fVar1;
  short sVar2;
  wchar_t *pwVar3;
  int ****ppppiVar4;
  uint uVar5;
  undefined1 *puVar6;
  short sVar7;
  undefined4 uVar8;
  int *piVar9;
  int iVar10;
  short *psVar11;
  undefined2 extraout_var;
  code *pcVar12;
  short sVar13;
  short sVar14;
  code *unaff_ESI;
  int iVar15;
  undefined2 uVar16;
  int *****pppppiVar17;
  bool bVar18;
  ushort uVar19;
  float10 fVar20;
  int ******ppppppiVar21;
  undefined4 *puVar22;
  int *****pppppiStack_220;
  code *pcStack_21c;
  int *****pppppiStack_218;
  int ****ppppiStack_214;
  int **ppiStack_210;
  int **ppiStack_20c;
  int *****pppppiStack_208;
  int *****pppppiStack_204;
  int *****pppppiStack_200;
  int *****pppppiStack_1fc;
  int *****pppppiStack_1f8;
  int *****pppppiStack_1f4;
  int *****pppppiStack_1f0;
  int *****pppppiStack_1ec;
  int *****pppppiStack_1e8;
  int ****ppppiStack_1e4;
  int ****ppppiStack_1e0;
  int ****ppppiStack_1dc;
  int *****pppppiStack_1d8;
  int ****ppppiStack_1d4;
  int *****pppppiStack_1d0;
  int *****pppppiStack_1cc;
  undefined *puStack_1c8;
  wchar_t *pwStack_1c4;
  int *****pppppiStack_1c0;
  int *****pppppiStack_1bc;
  int *****pppppiStack_1b8;
  int ****ppppiStack_1b4;
  int ****ppppiStack_1b0;
  int *****pppppiStack_1ac;
  int *****pppppiStack_1a8;
  wchar_t *pwStack_1a4;
  int *****pppppiStack_1a0;
  int *****pppppiStack_19c;
  int ****ppppiStack_198;
  int ****ppppiStack_194;
  int *****pppppiStack_190;
  int ****ppppiStack_18c;
  int *****pppppiStack_188;
  int *****pppppiStack_184;
  int ****ppppiStack_180;
  int *****pppppiStack_17c;
  int *****local_140;
  int ****local_13c;
  uint local_138;
  uint local_134;
  undefined4 local_110;
  int ****local_10c;
  float local_104;
  int ***local_100 [2];
  float *local_f8;
  int ****local_f0;
  int *****local_ec;
  undefined4 *local_e8;
  int *****local_e4;
  int ****local_e0 [2];
  wchar_t *local_d8;
  int ****local_d0;
  int *****local_cc;
  wchar_t *local_c8;
  int *****local_c4;
  int ***local_c0 [4];
  int ****local_b0;
  undefined *local_ac;
  wchar_t *local_a8;
  undefined4 local_a4;
  int ****local_a0 [2];
  undefined4 local_98;
  int ****local_90 [2];
  undefined4 local_88;
  int ****local_80;
  undefined4 local_7c;
  int ****local_78;
  undefined4 local_74;
  int ***local_70;
  undefined4 local_6c;
  undefined4 local_68;
  int ***local_64;
  int *local_60;
  int *local_5c;
  int *local_58;
  int *local_54;
  int *local_50;
  int *local_4c;
  int *local_48;
  int *local_44;
  int ****local_40;
  uint local_3c;
  float local_38;
  undefined4 local_34;
  int *****local_30;
  undefined4 local_28;
  int *****local_24;
  uint local_1c;
  uint local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffe88;
  local_8 = &DAT_00402320;
  local_24 = (int *****)0x0;
  local_30 = (int *****)0x0;
  local_34 = 0;
  local_38 = 0.0;
  local_3c = 0;
  local_40 = (int ****)0x0;
  local_44 = (int *)0x0;
  local_48 = (int *)0x0;
  local_4c = (int *)0x0;
  local_50 = (int *)0x0;
  local_54 = (int *)0x0;
  local_58 = (int *)0x0;
  local_5c = (int *)0x0;
  local_60 = (int *)0x0;
  local_64 = (int ***)0x0;
  local_68 = 0;
  local_6c = 0;
  local_70 = (int ***)0x0;
  local_80 = (int ****)0x0;
  local_90[0] = (int ****)0x0;
  local_a0[0] = (int ****)0x0;
  local_b0 = (int ****)0x0;
  local_c0[0] = (int ***)0x0;
  local_d0 = (int ****)0x0;
  local_e0[0] = (int ****)0x0;
  local_f0 = (int ****)0x0;
  local_100[0] = (int ***)0x0;
  local_110 = 0;
  local_13c = (int ****)0x0;
  local_140 = (int *****)0x0;
  pcVar12 = __vbaGenerateBoundsError_exref;
  pppppiVar17 = (int *****)__vbaStrMove_exref;
  ExceptionList = &pvStack_14;
  puVar6 = &stack0xfffffe88;
  if (DAT_0050b33a == 0) {
    ppppiStack_180 = (int ****)(int)DAT_0050b332;
    pppppiStack_17c = (int *****)0x0;
    pppppiStack_184 = (int *****)0x1;
    pppppiStack_188 = (int *****)0x2;
    ppppiStack_18c = (int ****)&DAT_0050b198;
    pppppiStack_190 = (int *****)0x2;
    ppppiStack_194 = (int ****)0x80;
    ppppiStack_198 = (int ****)0x4beb39;
    ExceptionList = &pvStack_14;
    __vbaRedim();
    pcVar12 = __vbaGenerateBoundsError_exref;
    DAT_0050b33a = 1;
    if ((DAT_0050b194 == (short *)0x0) || (*DAT_0050b194 != 1)) {
      pppppiStack_17c = (int *****)0x4beb79;
      iVar10 = __vbaGenerateBoundsError();
    }
    else {
      iVar10 = *(int *)(DAT_0050b194 + 10);
      if (*(uint *)(DAT_0050b194 + 8) <= 1U - iVar10) {
        pppppiStack_17c = (int *****)0x4beb66;
        __vbaGenerateBoundsError();
      }
      iVar10 = (1U - iVar10) * 2;
    }
    *(short *)(*(int *)(DAT_0050b194 + 6) + iVar10) = DAT_0050b33e;
    if ((DAT_0050b198 == (short *)0x0) || (*DAT_0050b198 != 1)) {
      pppppiStack_17c = (int *****)0x4bebbf;
      iVar10 = __vbaGenerateBoundsError();
    }
    else {
      iVar15 = (int)DAT_0050b33e;
      iVar10 = *(int *)(DAT_0050b198 + 10);
      if (*(uint *)(DAT_0050b198 + 8) <= (uint)(iVar15 - iVar10)) {
        pppppiStack_17c = (int *****)0x4bebb2;
        __vbaGenerateBoundsError();
      }
      iVar10 = (iVar15 - iVar10) * 2;
    }
    *(undefined2 *)(*(int *)(DAT_0050b198 + 6) + iVar10) = 1;
    if (DAT_0050b420 == (int ******)0x0) {
      pppppiStack_17c = (int *****)&DAT_0050b420;
      ppppiStack_180 = (int ****)&DAT_00408c88;
      pppppiStack_184 = (int *****)0x4bebe7;
      __vbaNew2();
    }
    pppppiStack_17c = (int *****)DAT_0050b420;
    ppppiStack_180 = (int ****)0x4bebf5;
    ppppiStack_180 = (int ****)(*(code *)(*DAT_0050b420)[0xea])();
    pppppiStack_184 = &local_13c;
    pppppiStack_188 = (int *****)0x4bec03;
    __vbaObjSet();
    unaff_ESI = __vbaLateIdSt_exref;
    local_d0 = (int ****)0x3;
    ppppiStack_194 = (int ****)0x3;
    local_c8 = (wchar_t *)0x1;
    ppppiStack_198 = (int ****)0x4;
    pppppiStack_190 = local_cc;
    pppppiStack_19c = (int *****)local_13c;
    ppppiStack_18c = (int ****)&DAT_00000001;
    pppppiStack_188 = local_c4;
    pppppiStack_1a0 = (int *****)0x4bec46;
    __vbaLateIdSt();
    local_d0 = (int ****)0x3;
    ppppiStack_1b0 = (int ****)0xa;
    pppppiStack_1ac = (int *****)0x3;
    local_c8 = (wchar_t *)0x0;
    pppppiStack_1a8 = local_cc;
    ppppiStack_1b4 = local_13c;
    pwStack_1a4 = (wchar_t *)0x0;
    pppppiStack_1a0 = local_c4;
    pppppiStack_1b8 = (int *****)0x4bec80;
    __vbaLateIdSt();
    local_d0 = (int ****)0x3;
    puStack_1c8 = (undefined *)0xb;
    pwStack_1c4 = (wchar_t *)0x3;
    local_c8 = (wchar_t *)0x0;
    pppppiStack_1c0 = local_cc;
    pppppiStack_1cc = (int *****)local_13c;
    pppppiStack_1bc = (int *****)0x0;
    pppppiStack_1b8 = local_c4;
    pppppiStack_1d0 = (int *****)0x4becba;
    __vbaLateIdSt();
    local_d0 = (int ****)0x3;
    ppppiStack_1e0 = (int ****)0x26;
    ppppiStack_1dc = (int ****)0x3;
    local_c8 = (wchar_t *)0xffff00;
    pppppiStack_1d8 = local_cc;
    ppppiStack_1e4 = local_13c;
    ppppiStack_1d4 = (int ****)0xffff00;
    pppppiStack_1d0 = local_c4;
    pppppiStack_1e8 = (int *****)0x4becf7;
    __vbaLateIdSt();
    local_d0 = (int ****)0x3;
    pppppiStack_1f4 = (int *****)0x3;
    local_c8 = (wchar_t *)0xff0000;
    pppppiStack_1f0 = local_cc;
    pppppiStack_1ec = (int *****)0xff0000;
    pppppiStack_1f8 = (int *****)0x27;
    pppppiStack_1fc = (int *****)local_13c;
    pppppiStack_1e8 = local_c4;
    pppppiStack_200 = (int *****)0x4bed34;
    __vbaLateIdSt();
    local_d0 = (int ****)0x3;
    ppiStack_210 = (int **)0x4;
    ppiStack_20c = (int **)0x3;
    local_c8 = (wchar_t *)0x2;
    pppppiStack_208 = local_cc;
    ppppiStack_214 = local_13c;
    pppppiStack_204 = (int *****)0x2;
    pppppiStack_200 = local_c4;
    pppppiStack_218 = (int *****)0x4bed71;
    __vbaLateIdSt();
    local_d0 = (int ****)0x3;
    local_c8 = (wchar_t *)0x1;
    pppppiStack_220 = local_cc;
    pcStack_21c = (code *)0x1;
    pppppiStack_218 = local_c4;
    __vbaLateIdSt(local_13c,10,3);
    __vbaStrI2(CONCAT22(extraout_var,DAT_0050b33e),L" 0.     Start at node N");
    pppppiVar17 = (int *****)__vbaStrMove_exref;
    uVar8 = __vbaStrMove();
    local_78 = (int ****)__vbaStrCat(uVar8);
    local_80 = (int ****)0x8;
    __vbaLateIdSt(local_13c,0,8,local_7c,local_78,local_74);
    __vbaFreeStr();
    __vbaFreeVar();
    __vbaObjSetAddref(&local_13c,0);
    puVar6 = local_c;
  }
  local_c = puVar6;
  sVar7 = DAT_0050b33a;
  local_38 = (float)_DAT_0050b134;
  local_18 = 1;
  psVar11 = DAT_0050b0e8;
  uVar5 = local_18;
  while (local_18 = uVar5, (short)local_18 <= sVar7) {
    if ((DAT_0050b194 == (short *)0x0) || (*DAT_0050b194 != 1)) {
      pppppiStack_17c = (int *****)0x4bee8e;
      iVar10 = (*pcVar12)();
      psVar11 = DAT_0050b0e8;
    }
    else {
      unaff_ESI = (code *)((int)(short)local_18 - *(int *)(DAT_0050b194 + 10));
      if (*(code **)(DAT_0050b194 + 8) <= unaff_ESI) {
        pppppiStack_17c = (int *****)0x4bee81;
        (*pcVar12)();
        psVar11 = DAT_0050b0e8;
      }
      iVar10 = (int)unaff_ESI * 2;
    }
    sVar2 = DAT_0050b332;
    local_28 = CONCAT22(local_28._2_2_,*(undefined2 *)(*(int *)(DAT_0050b194 + 6) + iVar10));
    local_1c = 1;
    uVar5 = local_1c;
    while (local_1c = uVar5, (short)local_1c <= sVar2) {
      if ((DAT_0050b198 == (short *)0x0) || (*DAT_0050b198 != 1)) {
        pppppiStack_17c = (int *****)0x4beef6;
        iVar10 = (*pcVar12)();
        psVar11 = DAT_0050b0e8;
      }
      else {
        unaff_ESI = (code *)((int)(short)local_1c - *(int *)(DAT_0050b198 + 10));
        if (*(code **)(DAT_0050b198 + 8) <= unaff_ESI) {
          pppppiStack_17c = (int *****)0x4beee9;
          (*pcVar12)();
          psVar11 = DAT_0050b0e8;
        }
        iVar10 = (int)unaff_ESI * 2;
      }
      if (*(short *)(*(int *)(DAT_0050b198 + 6) + iVar10) == 0) {
        uVar16 = (undefined2)((uint)unaff_ESI >> 0x10);
        unaff_ESI = (code *)CONCAT22(uVar16,(short)local_28 + -1);
        if (SBORROW2((short)local_28,1)) goto LAB_004bf9a1;
        iVar10 = (int)(short)((short)local_28 + -1) * (int)DAT_0050b332;
        sVar13 = (short)iVar10;
        unaff_ESI = (code *)CONCAT22(uVar16,sVar13);
        if (sVar13 != iVar10) goto LAB_004bf9a1;
        sVar14 = sVar13 + (short)local_1c;
        unaff_ESI = (code *)CONCAT22(uVar16,sVar14);
        if (SCARRY2(sVar13,(short)local_1c)) goto LAB_004bf9a1;
        if ((psVar11 == (short *)0x0) || (*psVar11 != 1)) {
          pppppiStack_17c = (int *****)0x4bef6a;
          iVar10 = __vbaGenerateBoundsError();
          psVar11 = DAT_0050b0e8;
        }
        else {
          iVar10 = *(int *)(psVar11 + 10);
          if (*(uint *)(psVar11 + 8) <= (uint)(sVar14 - iVar10)) {
            pppppiStack_17c = (int *****)0x4bef55;
            __vbaGenerateBoundsError();
            psVar11 = DAT_0050b0e8;
          }
          iVar10 = (sVar14 - iVar10) * 8;
        }
        pcVar12 = __vbaGenerateBoundsError_exref;
        if (*(double *)(*(int *)(psVar11 + 6) + iVar10) != _DAT_0050b134) {
          if ((psVar11 == (short *)0x0) || (*psVar11 != 1)) {
            pppppiStack_17c = (int *****)0x4befc3;
            __vbaGenerateBoundsError();
          }
          else if (*(uint *)(psVar11 + 8) <= (uint)((int)sVar14 - *(int *)(psVar11 + 10))) {
            pppppiStack_17c = (int *****)0x4befa6;
            __vbaGenerateBoundsError();
            pcVar12 = __vbaGenerateBoundsError_exref;
          }
          pppppiStack_17c = (int *****)0x4befe1;
          fVar20 = (float10)__vbaFpR4();
          psVar11 = DAT_0050b0e8;
          if (fVar20 <= (float10)local_38) {
            if ((DAT_0050b0e8 == (short *)0x0) || (*DAT_0050b0e8 != 1)) {
              pppppiStack_17c = (int *****)0x4bf01d;
              iVar10 = (*pcVar12)();
            }
            else {
              unaff_ESI = (code *)((int)sVar14 - *(int *)(DAT_0050b0e8 + 10));
              if (*(code **)(DAT_0050b0e8 + 8) <= unaff_ESI) {
                pppppiStack_17c = (int *****)0x4bf00c;
                (*pcVar12)();
              }
              iVar10 = (int)unaff_ESI * 8;
            }
            local_38 = (float)*(double *)(*(int *)(DAT_0050b0e8 + 6) + iVar10);
            local_34 = local_28;
            local_3c = local_1c;
            psVar11 = DAT_0050b0e8;
          }
        }
      }
      pcVar12 = __vbaGenerateBoundsError_exref;
      uVar5 = (uint)(ushort)((short)local_1c + 1);
      if (SCARRY2((short)local_1c,1)) goto LAB_004bf9a1;
    }
    uVar5 = (uint)(ushort)((short)local_18 + 1);
    if (SCARRY2((short)local_18,1)) goto LAB_004bf9a1;
  }
  pppppiStack_17c = (int *****)0x4bf086;
  fVar20 = (float10)__vbaFpR4();
  if ((float10)local_38 < fVar20) {
    _DAT_0050b14c = (double)(local_38 + (float)_DAT_0050b14c);
    pppppiStack_17c = (int *****)0x4bf0b2;
    FUN_0044fdc0();
    pppppiStack_17c = (int *****)0x4bf0b9;
    (*(code *)pppppiVar17)();
    local_78 = local_40;
    local_e0[0] = (int ****)0x8;
    local_80 = (int ****)0x8;
    pppppiStack_17c = (int *****)0x1;
    pppppiStack_184 = &local_80;
    ppppiStack_180 = (int ****)0x1;
    pppppiStack_188 = &local_d0;
    ppppiStack_18c = (int ****)local_90;
    pcVar12 = (code *)0x3;
    local_e8 = (undefined4 *)0x0;
    local_f0 = (int ****)0x3;
    local_d8 = L"Updated minimal tree length = ";
    local_40 = (int ****)0x0;
    local_c8 = (wchar_t *)&DAT_0050b14c;
    local_d0 = (int ****)0x4005;
    pppppiStack_190 = (int *****)0x4bf11d;
    Ordinal_660();
    pppppiStack_190 = local_e0;
    ppppiStack_194 = (int ****)local_90;
    ppppiStack_198 = (int ****)local_a0;
    pppppiStack_19c = (int *****)0x4bf138;
    pppppiStack_19c = (int *****)__vbaVarCat();
    pppppiStack_1a0 = (int *****)0x4bf13f;
    local_a8 = (wchar_t *)__vbaStrVarMove();
    local_b0 = (int ****)0x8;
    if (DAT_0050b420 == (int ******)0x0) {
      pppppiStack_1a0 = (int *****)&DAT_0050b420;
      pwStack_1a4 = L"\x01\aꙴ@";
      pppppiStack_1a8 = (int *****)0x4bf168;
      __vbaNew2();
    }
    pppppiStack_1ac = (int *****)local_f0;
    pppppiStack_1a8 = local_ec;
    pwStack_1a4 = (wchar_t *)local_e8;
    pppppiStack_1a0 = local_e4;
    pppppiStack_1bc = (int *****)0x3;
    pppppiStack_1b8 = (int *****)local_10c;
    ppppiStack_1b4 = (int ****)0x0;
    ppppiStack_1b0 = (int ****)local_104;
    pppppiStack_1d0 = (int *****)0x2;
    ppppiStack_1d4 = (int ****)0x41;
    pppppiStack_1d8 = (int *****)DAT_0050b420;
    pppppiStack_1cc = (int *****)local_b0;
    puStack_1c8 = local_ac;
    pwStack_1c4 = local_a8;
    pppppiStack_1c0 = (int *****)local_a4;
    ppppiStack_1dc = (int ****)0x4bf1e6;
    ppppiStack_1dc = (int ****)(*(code *)(*DAT_0050b420)[0xea])();
    ppppiStack_1e0 = &local_70;
    ppppiStack_1e4 = (int ****)0x4bf1f1;
    ppppiStack_1e4 = (int ****)__vbaObjSet();
    pppppiStack_1e8 = (int *****)0x4bf1f8;
    __vbaLateIdCallSt();
    pppppiStack_1ac = (int *****)0x4bf204;
    __vbaFreeStr();
    pppppiStack_1ac = (int *****)0x4bf20d;
    __vbaFreeObj();
    pppppiStack_1ac = &local_b0;
    ppppiStack_1b0 = (int ****)local_a0;
    ppppiStack_1b4 = (int ****)local_90;
    pppppiStack_1b8 = &local_80;
    pppppiStack_1bc = (int *****)0x4;
    pppppiStack_1c0 = (int *****)0x4bf22e;
    __vbaFreeVarList();
    sVar7 = DAT_0050b33a + 1;
    unaff_ESI = (code *)0x0;
    if (!SCARRY2(DAT_0050b33a,1)) {
      DAT_0050b33a = sVar7;
      if ((DAT_0050b194 == (short *)0x0) || (*DAT_0050b194 != 1)) {
        pppppiStack_17c = (int *****)0x4bf281;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        iVar10 = *(int *)(DAT_0050b194 + 10);
        if (*(uint *)(DAT_0050b194 + 8) <= (uint)(sVar7 - iVar10)) {
          pppppiStack_17c = (int *****)0x4bf26e;
          __vbaGenerateBoundsError();
        }
        iVar10 = (sVar7 - iVar10) * 2;
      }
      *(wchar_t *)(*(int *)(DAT_0050b194 + 6) + iVar10) = (wchar_t)local_3c;
      if ((DAT_0050b198 == (short *)0x0) || (*DAT_0050b198 != 1)) {
        pppppiStack_17c = (int *****)0x4bf2c1;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        iVar15 = (int)(wchar_t)local_3c;
        iVar10 = *(int *)(DAT_0050b198 + 10);
        if (*(uint *)(DAT_0050b198 + 8) <= (uint)(iVar15 - iVar10)) {
          pppppiStack_17c = (int *****)0x4bf2b4;
          __vbaGenerateBoundsError();
        }
        iVar10 = (iVar15 - iVar10) * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b198 + 6) + iVar10) = 1;
      if (DAT_0050b420 == (int ******)0x0) {
        pppppiStack_17c = (int *****)&DAT_0050b420;
        ppppiStack_180 = (int ****)&DAT_00408c88;
        pppppiStack_184 = (int *****)0x4bf2e9;
        __vbaNew2();
      }
      pppppiStack_17c = (int *****)DAT_0050b420;
      ppppiStack_180 = (int ****)0x4bf2f7;
      ppppiStack_180 = (int ****)(*(code *)(*DAT_0050b420)[0xea])();
      pppppiStack_184 = (int *****)&local_140;
      pppppiStack_188 = (int *****)0x4bf305;
      __vbaObjSet();
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppiStack_188 = (int *****)0x4bf337;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        iVar15 = (int)(wchar_t)local_3c;
        iVar10 = *(int *)(DAT_0050b394 + 10);
        if (*(uint *)(DAT_0050b394 + 8) <= (uint)(iVar15 - iVar10)) {
          pppppiStack_188 = (int *****)0x4bf327;
          __vbaGenerateBoundsError();
        }
        iVar10 = (iVar15 - iVar10) * 0x18;
      }
      pppppiStack_188 = (int *****)(*(int *)(DAT_0050b394 + 6) + iVar10);
      ppppiStack_18c = (int ****)0xc;
      pppppiStack_190 = (int *****)0x4bf34b;
      __vbaStrFixstr();
      pppppiStack_190 = (int *****)0x4bf352;
      pppppiStack_190 = (int *****)(*(code *)pppppiVar17)();
      pcVar12 = Ordinal_519_exref;
      ppppiStack_194 = (int ****)0x4bf35b;
      Ordinal_519();
      ppppiStack_194 = (int ****)0x4bf362;
      (*(code *)pppppiVar17)();
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        ppppiStack_194 = (int ****)0x4bf39c;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        iVar15 = (int)(wchar_t)local_3c;
        iVar10 = *(int *)(DAT_0050b394 + 10);
        if (*(uint *)(DAT_0050b394 + 8) <= (uint)(iVar15 - iVar10)) {
          ppppiStack_194 = (int ****)0x4bf388;
          __vbaGenerateBoundsError();
        }
        iVar10 = (iVar15 - iVar10) * 0x18;
      }
      ppppiStack_198 = (int ****)(*(int *)(DAT_0050b394 + 6) + iVar10);
      ppppiStack_194 = local_40;
      pppppiStack_19c = (int *****)0xc;
      pppppiStack_1a0 = (int *****)0x4bf3b4;
      __vbaLsetFixstr();
      local_44 = (int *)0x0;
      pppppiStack_1a0 = (int *****)0x4bf3c3;
      (*(code *)pppppiVar17)();
      unaff_ESI = __vbaFreeStr_exref;
      pppppiStack_1a0 = (int *****)0x4bf3ce;
      __vbaFreeStr();
      pppppiStack_1a0 = local_30;
      pwStack_1a4 = L"";
      pppppiStack_1a8 = (int *****)0x4bf3dd;
      iVar10 = __vbaStrCmp();
      if (iVar10 != 0) {
        pppppiStack_1a8 = (int *****)&DAT_00412d2c;
        pppppiStack_1ac = local_30;
        ppppiStack_1b0 = (int ****)0x4bf3f0;
        __vbaStrCat();
        ppppiStack_1b0 = (int ****)0x4bf3f7;
        ppppiStack_1b0 = (int ****)(*(code *)pppppiVar17)();
        ppppiStack_1b4 = (int ****)&DAT_00412d38;
        pppppiStack_1b8 = (int *****)0x4bf403;
        __vbaStrCat();
        pppppiStack_1b8 = (int *****)0x4bf40a;
        (*(code *)pppppiVar17)();
        pppppiStack_1b8 = (int *****)0x4bf40f;
        __vbaFreeStr();
      }
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        pppppiStack_1a8 = (int *****)0x4bf455;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        local_134 = (int)(short)local_34 - *(int *)(DAT_0050b394 + 10);
        if (*(uint *)(DAT_0050b394 + 8) <= local_134) {
          pppppiStack_1a8 = (int *****)0x4bf43b;
          __vbaGenerateBoundsError();
        }
        iVar10 = local_134 * 0x18;
      }
      pppppiStack_1a8 = (int *****)(*(int *)(DAT_0050b394 + 6) + iVar10);
      pppppiStack_1ac = (int *****)0xc;
      ppppiStack_1b0 = (int ****)0x4bf469;
      __vbaStrFixstr();
      ppppiStack_1b0 = (int ****)0x4bf470;
      ppppiStack_1b0 = (int ****)(*(code *)pppppiVar17)();
      ppppiStack_1b4 = (int ****)0x4bf473;
      Ordinal_519();
      ppppiStack_1b4 = (int ****)0x4bf47a;
      (*(code *)pppppiVar17)();
      if ((DAT_0050b394 == (short *)0x0) || (*DAT_0050b394 != 1)) {
        ppppiStack_1b4 = (int ****)0x4bf4c0;
        iVar10 = __vbaGenerateBoundsError();
      }
      else {
        local_138 = (int)(short)local_34 - *(int *)(DAT_0050b394 + 10);
        if (*(uint *)(DAT_0050b394 + 8) <= local_138) {
          ppppiStack_1b4 = (int ****)0x4bf4a6;
          __vbaGenerateBoundsError();
        }
        iVar10 = local_138 * 0x18;
      }
      pppppiStack_1b8 = (int *****)(*(int *)(DAT_0050b394 + 6) + iVar10);
      ppppiStack_1b4 = local_40;
      pppppiStack_1bc = (int *****)0xc;
      pppppiStack_1c0 = (int *****)0x4bf4d8;
      __vbaLsetFixstr();
      local_44 = (int *)0x0;
      pppppiStack_1c0 = (int *****)0x4bf4e7;
      (*(code *)pppppiVar17)();
      pppppiStack_1c0 = (int *****)0x4bf4ec;
      __vbaFreeStr();
      pppppiStack_1c0 = local_24;
      pwStack_1c4 = L"";
      puStack_1c8 = (undefined *)0x4bf4fb;
      iVar10 = __vbaStrCmp();
      if (iVar10 != 0) {
        puStack_1c8 = &DAT_00412d2c;
        pppppiStack_1cc = local_24;
        pppppiStack_1d0 = (int *****)0x4bf50e;
        __vbaStrCat();
        pppppiStack_1d0 = (int *****)0x4bf515;
        pppppiStack_1d0 = (int *****)(*(code *)pppppiVar17)();
        ppppiStack_1d4 = (int ****)&DAT_00412d38;
        pppppiStack_1d8 = (int *****)0x4bf521;
        __vbaStrCat();
        pppppiStack_1d8 = (int *****)0x4bf528;
        (*(code *)pppppiVar17)();
        pppppiStack_1d8 = (int *****)0x4bf52d;
        __vbaFreeStr();
      }
      puStack_1c8 = (undefined *)0x0;
      pppppiStack_1cc = (int *****)0x4;
      ppppiStack_1d4 = (int ****)&local_80;
      pppppiStack_1d0 = local_140;
      pppppiStack_1d8 = (int *****)0x4bf542;
      puStack_1c8 = (undefined *)__vbaLateIdCallLd();
      pppppiStack_1cc = (int *****)0x4bf54c;
      iVar10 = __vbaI4Var();
      if (!SCARRY4(iVar10,1)) {
        local_d0 = (int ****)0x3;
        ppppiStack_18c = (int ****)0x4;
        pppppiStack_188 = (int *****)0x3;
        pppppiStack_184 = local_cc;
        pppppiStack_190 = local_140;
        pppppiStack_17c = local_c4;
        ppppiStack_194 = (int ****)0x4bf591;
        ppppiStack_180 = (int ****)(iVar10 + 1);
        local_c8 = (wchar_t *)(iVar10 + 1);
        __vbaLateIdSt();
        ppppiStack_194 = (int ****)0x4bf59a;
        __vbaFreeVar();
        ppppiStack_194 = (int ****)0x4bf59f;
        FUN_0044fdc0();
        ppppiStack_194 = (int ****)0x4bf5a6;
        (*(code *)pppppiVar17)();
        unaff_ESI = Ordinal_536_exref;
        if (!SBORROW2(DAT_0050b33a,1)) {
          local_78 = (int ****)CONCAT22(local_78._2_2_,DAT_0050b33a + -1);
          pppppiStack_17c = &local_80;
          local_e8 = &local_34;
          local_80 = (int ****)0x2;
          local_e0[0] = (int ****)0x4002;
          local_f0 = (int ****)0x4002;
          ppppiStack_180 = (int ****)0x4bf5f1;
          local_d8 = (wchar_t *)&local_3c;
          Ordinal_536();
          ppppiStack_180 = (int ****)0x4bf5f8;
          ppppiStack_180 = (int ****)(*(code *)pppppiVar17)();
          pppppiStack_184 = (int *****)0x412d40;
          pppppiStack_188 = (int *****)0x4bf604;
          __vbaStrCat();
          pppppiStack_188 = (int *****)0x4bf60b;
          pppppiStack_188 = (int *****)(*(code *)pppppiVar17)();
          ppppiStack_18c = (int ****)local_e0;
          pppppiStack_190 = (int *****)0x4bf615;
          Ordinal_536();
          pppppiStack_190 = (int *****)0x4bf61c;
          pppppiStack_190 = (int *****)(*(code *)pppppiVar17)();
          ppppiStack_194 = (int ****)0x4bf61f;
          Ordinal_519();
          ppppiStack_194 = (int ****)0x4bf626;
          ppppiStack_194 = (int ****)(*(code *)pppppiVar17)();
          ppppiStack_198 = (int ****)0x4bf62d;
          __vbaStrCat();
          ppppiStack_198 = (int ****)0x4bf634;
          ppppiStack_198 = (int ****)(*(code *)pppppiVar17)();
          pppppiStack_19c = local_30;
          pppppiStack_1a0 = (int *****)0x4bf63f;
          __vbaStrCat();
          pppppiStack_1a0 = (int *****)0x4bf646;
          pppppiStack_1a0 = (int *****)(*(code *)pppppiVar17)();
          pwStack_1a4 = L"  to N";
          pppppiStack_1a8 = (int *****)0x4bf652;
          __vbaStrCat();
          pppppiStack_1a8 = (int *****)0x4bf659;
          pppppiStack_1a8 = (int *****)(*(code *)pppppiVar17)();
          pppppiStack_1ac = &local_f0;
          ppppiStack_1b0 = (int ****)0x4bf663;
          Ordinal_536();
          ppppiStack_1b0 = (int ****)0x4bf66a;
          ppppiStack_1b0 = (int ****)(*(code *)pppppiVar17)();
          ppppiStack_1b4 = (int ****)0x4bf66d;
          Ordinal_519();
          ppppiStack_1b4 = (int ****)0x4bf674;
          ppppiStack_1b4 = (int ****)(*(code *)pppppiVar17)();
          pppppiStack_1b8 = (int *****)0x4bf67d;
          __vbaStrCat();
          pppppiStack_1b8 = (int *****)0x4bf684;
          pppppiStack_1b8 = (int *****)(*(code *)pppppiVar17)();
          pppppiStack_1bc = local_24;
          pppppiStack_1c0 = (int *****)0x4bf68b;
          __vbaStrCat();
          pppppiStack_1c0 = (int *****)0x4bf692;
          pppppiStack_1c0 = (int *****)(*(code *)pppppiVar17)();
          pwStack_1c4 = L":  Length = ";
          puStack_1c8 = (undefined *)0x4bf69a;
          local_a8 = (wchar_t *)__vbaStrCat();
          local_b0 = (int ****)0x8;
          local_90[0] = (int ****)0x8;
          local_f8 = &local_38;
          local_88 = local_6c;
          puStack_1c8 = (undefined *)0x1;
          pppppiStack_1d0 = local_90;
          pppppiStack_1cc = (int *****)&DAT_00000001;
          ppppiStack_1d4 = local_100;
          pppppiStack_1d8 = local_a0;
          local_6c = 0;
          local_100[0] = (int ***)0x4004;
          ppppiStack_1dc = (int ****)0x4bf6f3;
          Ordinal_660();
          ppppiStack_1dc = (int ****)&local_b0;
          ppppiStack_1e0 = (int ****)local_a0;
          ppppiStack_1e4 = local_c0;
          pppppiStack_1e8 = (int *****)0x4bf70e;
          pppppiStack_1e8 = (int *****)__vbaVarCat();
          pppppiStack_1ec = (int *****)0x4bf715;
          __vbaStrVarMove();
          pppppiStack_1ec = (int *****)0x4bf71e;
          (*(code *)pppppiVar17)();
          pppppiStack_1ec = (int *****)&local_6c;
          pppppiStack_1f0 = (int *****)&local_68;
          pppppiStack_1f4 = (int *****)&local_64;
          pppppiStack_1f8 = (int *****)&local_60;
          pppppiStack_1fc = (int *****)&local_5c;
          pppppiStack_200 = (int *****)&local_58;
          pppppiStack_204 = (int *****)&local_54;
          pppppiStack_208 = (int *****)&local_50;
          ppiStack_20c = &local_4c;
          ppiStack_210 = &local_48;
          ppppiStack_214 = (int ****)&local_44;
          pppppiStack_218 = &local_40;
          pcStack_21c = (code *)0xc;
          pppppiStack_220 = (int *****)0x4bf756;
          __vbaFreeStrList();
          pppppiStack_220 = (int *****)local_c0;
          __vbaFreeVarList(5,&local_80,local_90,&local_b0,local_a0);
          pppppiStack_1f0 = (int *****)(int)DAT_0050b33a;
          local_d0 = (int ****)0x3;
          pppppiStack_1f8 = (int *****)0x3;
          pppppiStack_1f4 = local_cc;
          local_e8 = (undefined4 *)0x0;
          local_f0 = (int ****)0x3;
          pppppiStack_1ec = local_c4;
          pppppiStack_208 = (int *****)0x3;
          pppppiStack_204 = local_ec;
          pppppiStack_200 = (int *****)0x0;
          pppppiStack_1fc = local_e4;
          pcStack_21c = (code *)0x2;
          pppppiStack_220 = (int *****)0x41;
          pppppiStack_218 = (int *****)0x4008;
          ppppiStack_214 = local_10c;
          ppiStack_210 = (int **)&DAT_0050b34c;
          ppiStack_20c = (int **)local_104;
          local_c8 = (wchar_t *)pppppiStack_1f0;
          __vbaLateIdCallSt(local_140);
          pppppiStack_1f0 = (int *****)&local_140;
          pppppiStack_1ec = (int *****)0x0;
          pppppiStack_1f4 = (int *****)0x4bf82a;
          __vbaObjSetAddref();
          goto LAB_004bf961;
        }
      }
    }
LAB_004bf9a1:
    pppppiStack_17c = (int *****)0x4bf9a7;
    __vbaErrorOverflow();
    pppppiStack_188 = (int *****)&DAT_00402706;
    ppppiStack_18c = ExceptionList;
    pppppiStack_184 = (int *****)&pppppiStack_220;
    ppppiStack_180 = (int ****)&DAT_00402330;
    ppppiStack_198 = (int ****)0x0;
    pppppiStack_19c = (int *****)0x0;
    pppppiStack_1a0 = (int *****)0x0;
    pwStack_1c4 = (wchar_t *)0x0;
    puStack_1c8 = (undefined *)0x0;
    pppppiStack_1cc = (int *****)0x0;
    pppppiStack_1d0 = (int *****)0x0;
    pppppiStack_1f4 = (int *****)0x0;
    ExceptionList = &ppppiStack_18c;
    pppppiStack_220 = pppppiVar17;
    pcStack_21c = unaff_ESI;
    pppppiStack_218 = (int *****)pcVar12;
    ppppppiVar21 = &pppppiStack_220;
    pppppiStack_17c = (int *****)&stack0xfffffffc;
    if (DAT_0050b420 == (int ******)0x0) {
      ExceptionList = &ppppiStack_18c;
      pppppiStack_17c = (int *****)&stack0xfffffffc;
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
      ppppppiVar21 = (int ******)pppppiStack_184;
    }
    pppppiStack_184 = (int *****)ppppppiVar21;
    __vbaObjSetAddref(&pppppiStack_1f4,DAT_0050b420);
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xdf])(pppppiStack_1f4);
    piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
    iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
    }
    __vbaFreeObj();
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xd9])(pppppiStack_1f4);
    piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
    iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0xffffffff);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
    }
    __vbaFreeObj();
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xdb])(pppppiStack_1f4);
    piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
    iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
    }
    __vbaFreeObj();
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xd3])(pppppiStack_1f4);
    piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
    iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
    }
    __vbaFreeObj();
    pwVar3 = pwStack_1a4;
    pppppiVar17 = pppppiStack_1ac;
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xea])
                      (pppppiStack_1f4,0x80010007,0xb,pppppiStack_1ac,0,pwStack_1a4);
    uVar8 = __vbaObjSet(&ppppiStack_198,uVar8);
    __vbaLateIdSt(uVar8);
    __vbaFreeObj();
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xda])(pppppiStack_1f4);
    piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
    iVar10 = (**(code **)(*piVar9 + 0xe8))(piVar9,&pwStack_1c4);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040dc58,0xe8);
    }
    bVar18 = (short)pwStack_1c4 == 0;
    __vbaFreeObj();
    if (bVar18) {
      uVar8 = (*(code *)(*pppppiStack_1f4)[0xda])(pppppiStack_1f4);
      piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
      iVar10 = (**(code **)(*piVar9 + 0x1ec))
                         (piVar9,L"Shortest routes",10,pppppiVar17,0x80020004,pwVar3);
      if (iVar10 < 0) {
        __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040dc58,0x1ec);
      }
      __vbaFreeObj();
      uVar8 = (*(code *)(*pppppiStack_1f4)[0xda])(pppppiStack_1f4);
      piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
      pppppiStack_1a8 = (int *****)0x80020004;
      iVar10 = (**(code **)(*piVar9 + 0x1ec))(piVar9,L"Iterations",10,pppppiVar17,0x80020004,pwVar3)
      ;
      if (iVar10 < 0) {
        __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040dc58,0x1ec);
      }
      __vbaFreeObj();
    }
    uVar8 = (*(code *)(*pppppiStack_1f4)[0xea])(pppppiStack_1f4,0x80010007,0xb,pppppiVar17,0,pwVar3)
    ;
    uVar8 = __vbaObjSet(&ppppiStack_198,uVar8);
    __vbaLateIdSt(uVar8);
    __vbaFreeObj();
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x92])(pppppiStack_1f4,&ppppiStack_198);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x248);
    }
    __vbaLateIdSt(ppppiStack_198,0,8,pppppiVar17,L"arial",pwVar3);
    __vbaFreeObj();
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x92])(pppppiStack_1f4,&ppppiStack_198);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x248);
    }
    __vbaLateIdSt(ppppiStack_198,2,2,pppppiVar17,6,pwVar3);
    __vbaFreeObj();
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x1b])(pppppiStack_1f4,0xffffff);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x6c);
    }
    if (DAT_0050b420 == (int ******)0x0) {
      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
    }
    __vbaObjSetAddref(&ppppiStack_198,DAT_0050b420);
    FUN_0048c990(&ppppiStack_198);
    uVar8 = __vbaCastObj(ppppiStack_198,&DAT_0040b85c);
    __vbaObjSet(&DAT_0050b420,uVar8);
    __vbaFreeObj();
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x92])(pppppiStack_1f4,&ppppiStack_198);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x248);
    }
    __vbaLateIdSt(ppppiStack_198,3,0xb,pppppiVar17,0xffffffff,pwVar3);
    __vbaFreeObj();
    pppppiStack_1a8 = (int *****)0xa;
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x92])(pppppiStack_1f4,&ppppiStack_198);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x248);
    }
    __vbaLateIdSt(ppppiStack_198,2,2,pppppiVar17,pppppiStack_1a8,pwVar3);
    __vbaFreeObj();
    ppppiStack_1b0 = (int ****)0xb;
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x92])(pppppiStack_1f4,&ppppiStack_198);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x248);
    }
    __vbaLateIdSt(ppppiStack_198,3,ppppiStack_1b0,pppppiVar17,0xffffffff,pwVar3);
    __vbaFreeObj();
    iVar10 = (*(code *)(*pppppiStack_1f4)[0x4b])(pppppiStack_1f4,1);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,300);
    }
    if ((DAT_0050b334 == 2) || (DAT_0050b334 == 3)) {
      __vbaStrCopy();
    }
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar9 = DAT_0050c53c;
    iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&ppppiStack_198);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040b410,0x18);
    }
    ppppiVar4 = ppppiStack_198;
    iVar10 = (*(code *)(*ppppiStack_198)[0x26])(ppppiStack_198,&puStack_1c8);
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,ppppiVar4,&DAT_0040bb5c,0x98);
    }
    iVar10 = (*(code *)(*pppppiStack_1f4)[0xb9])(pppppiStack_1f4,DAT_0050b34c,&pppppiStack_1cc);
    uVar19 = 0;
    if (iVar10 < 0) {
      __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0x2e4);
    }
    if ((uVar19 & 0xd) == 0) {
      fVar1 = ((float)puStack_1c8 - (float)pppppiStack_1cc) * (float)_DAT_00401268;
      if ((uVar19 & 0xd) == 0) {
        pppppiStack_204 = (int *****)fVar1;
        iVar10 = (*(code *)(*pppppiStack_1f4)[0x39])(pppppiStack_1f4,fVar1);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0xe4);
        }
        __vbaFreeObj();
        if (DAT_0050b420 == (int ******)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        __vbaPrintObj(&DAT_0040bf08,DAT_0050b420,DAT_0050b34c);
        iVar10 = (*(code *)(*pppppiStack_1f4)[0x3a])(pppppiStack_1f4,&puStack_1c8);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0xe8);
        }
        if (DAT_0050c53c == (int *)0x0) {
          __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
        }
        piVar9 = DAT_0050c53c;
        iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&ppppiStack_198);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040b410,0x18);
        }
        ppppiVar4 = ppppiStack_198;
        iVar10 = (*(code *)(*ppppiStack_198)[0x26])(ppppiStack_198,&pppppiStack_1cc);
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,ppppiVar4,&DAT_0040bb5c,0x98);
        }
        iVar10 = (*(code *)(*pppppiStack_1f4)[0x3a])(pppppiStack_1f4,&pppppiStack_1d0);
        uVar19 = 0;
        if (iVar10 < 0) {
          __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0xe8);
        }
        if (DAT_0050b420 == (int ******)0x0) {
          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
        }
        ppppppiVar21 = DAT_0050b420;
        if ((uVar19 & 0xd) == 0) {
          iVar10 = (*(code *)(*DAT_0050b420)[0xb2])
                             (DAT_0050b420,4,0x44960000,puStack_1c8,
                              (float)pppppiStack_1cc - _DAT_004020e0,pppppiStack_1d0,0);
          if (iVar10 < 0) {
            __vbaHresultCheckObj(iVar10,ppppppiVar21,&DAT_0040b430,0x2c8);
          }
          __vbaFreeObj();
          iVar10 = (*(code *)(*pppppiStack_1f4)[0x3a])(pppppiStack_1f4,&puStack_1c8);
          uVar19 = 0;
          if (iVar10 < 0) {
            __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0xe8);
          }
          uVar8 = (*(code *)(*pppppiStack_1f4)[0xd9])(pppppiStack_1f4);
          piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
          ppppppiVar21 = (int ******)((float)puStack_1c8 * (float)_DAT_00401280);
          if ((uVar19 & 0xd) == 0) {
            pppppiStack_208 = (int *****)ppppppiVar21;
            iVar10 = (**(code **)(*piVar9 + 0x7c))(piVar9,ppppppiVar21);
            if (iVar10 < 0) {
              __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x7c);
            }
            __vbaFreeObj();
            if (DAT_0050c53c == (int *)0x0) {
              __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
            }
            piVar9 = DAT_0050c53c;
            iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&ppppiStack_198);
            if (iVar10 < 0) {
              __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040b410,0x18);
            }
            ppppiVar4 = ppppiStack_198;
            iVar10 = (*(code *)(*ppppiStack_198)[0x26])(ppppiStack_198,&puStack_1c8);
            if (iVar10 < 0) {
              __vbaHresultCheckObj(iVar10,ppppiVar4,&DAT_0040bb5c,0x98);
            }
            uVar8 = (*(code *)(*pppppiStack_1f4)[0xd9])(pppppiStack_1f4);
            piVar9 = (int *)__vbaObjSet(&pppppiStack_19c,uVar8);
            iVar10 = (**(code **)(*piVar9 + 0x80))(piVar9,&pppppiStack_1cc);
            uVar19 = 0;
            if (iVar10 < 0) {
              __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x80);
            }
            uVar8 = (*(code *)(*pppppiStack_1f4)[0xd9])(pppppiStack_1f4);
            piVar9 = (int *)__vbaObjSet(&pppppiStack_1a0,uVar8);
            if ((uVar19 & 0xd) == 0) {
              fVar1 = ((float)puStack_1c8 - (float)pppppiStack_1cc) * (float)_DAT_00401268;
              if ((uVar19 & 0xd) == 0) {
                ppiStack_20c = (int **)fVar1;
                iVar10 = (**(code **)(*piVar9 + 0x74))(piVar9,ppppppiVar21,fVar1);
                if (iVar10 < 0) {
                  __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x74);
                }
                __vbaFreeObjList(3,&ppppiStack_198,&pppppiStack_19c,&pppppiStack_1a0);
                uVar8 = (*(code *)(*pppppiStack_1f4)[0xd9])(pppppiStack_1f4);
                piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
                iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0xffffffff);
                if (iVar10 < 0) {
                  __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
                }
                __vbaFreeObj();
                iVar10 = (*(code *)(*pppppiStack_1f4)[0x3a])(pppppiStack_1f4,&puStack_1c8);
                uVar19 = 0;
                if (iVar10 < 0) {
                  __vbaHresultCheckObj(iVar10,pppppiStack_1f4,&DAT_0040b430,0xe8);
                }
                if ((uVar19 & 0xd) == 0) {
                  DAT_0050b32e = __vbaFpI2();
                  if (DAT_0050c53c == (int *)0x0) {
                    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                  }
                  piVar9 = DAT_0050c53c;
                  iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&ppppiStack_198);
                  if (iVar10 < 0) {
                    __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040b410,0x18);
                  }
                  ppppiVar4 = ppppiStack_198;
                  iVar10 = (*(code *)(*ppppiStack_198)[0x14])(ppppiStack_198,&puStack_1c8);
                  uVar19 = 0;
                  if (iVar10 < 0) {
                    __vbaHresultCheckObj(iVar10,ppppiVar4,&DAT_0040bb5c,0x50);
                  }
                  if (DAT_0050b420 == (int ******)0x0) {
                    __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                  }
                  uVar8 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                  piVar9 = (int *)__vbaObjSet(&pppppiStack_19c,uVar8);
                  puVar22 = (undefined4 *)((float)puStack_1c8 * (float)_DAT_00401760);
                  if ((uVar19 & 0xd) == 0) {
                    ppiStack_210 = (int **)puVar22;
                    iVar10 = (**(code **)(*piVar9 + 0x7c))(piVar9,puVar22);
                    if (iVar10 < 0) {
                      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x7c);
                    }
                    __vbaFreeObjList(2,&ppppiStack_198,&pppppiStack_19c);
                    if (DAT_0050c53c == (int *)0x0) {
                      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
                    }
                    piVar9 = DAT_0050c53c;
                    iVar10 = (**(code **)(*DAT_0050c53c + 0x18))(DAT_0050c53c,&ppppiStack_198);
                    if (iVar10 < 0) {
                      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040b410,0x18);
                    }
                    ppppiVar4 = ppppiStack_198;
                    iVar10 = (*(code *)(*ppppiStack_198)[0x26])(ppppiStack_198,&puStack_1c8);
                    if (iVar10 < 0) {
                      __vbaHresultCheckObj(iVar10,ppppiVar4,&DAT_0040bb5c,0x98);
                    }
                    if (DAT_0050b420 == (int ******)0x0) {
                      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                    }
                    uVar8 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                    piVar9 = (int *)__vbaObjSet(&pppppiStack_19c,uVar8);
                    iVar10 = (**(code **)(*piVar9 + 0x80))(piVar9,&pppppiStack_1cc);
                    uVar19 = 0;
                    if (iVar10 < 0) {
                      __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x80);
                    }
                    if (DAT_0050b420 == (int ******)0x0) {
                      __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                    }
                    uVar8 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                    piVar9 = (int *)__vbaObjSet(&pppppiStack_1a0,uVar8);
                    if ((uVar19 & 0xd) == 0) {
                      fVar1 = ((float)puStack_1c8 - (float)pppppiStack_1cc) * (float)_DAT_00401268;
                      if ((uVar19 & 0xd) == 0) {
                        ppppiStack_214 = (int ****)fVar1;
                        iVar10 = (**(code **)(*piVar9 + 0x74))(piVar9,puVar22,fVar1);
                        if (iVar10 < 0) {
                          __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x74);
                        }
                        __vbaFreeObjList(3,&ppppiStack_198,&pppppiStack_19c,&pppppiStack_1a0);
                        if (DAT_0050b420 == (int ******)0x0) {
                          __vbaNew2(&DAT_00408c88,&DAT_0050b420);
                        }
                        uVar8 = (*(code *)(*DAT_0050b420)[0xdf])(DAT_0050b420);
                        piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
                        iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0xffffffff);
                        if (iVar10 < 0) {
                          __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
                        }
                        __vbaFreeObj();
                        if (DAT_0050b334 == 0x17) {
                          uVar8 = (*(code *)(*pppppiStack_1f4)[0xd9])(pppppiStack_1f4);
                          piVar9 = (int *)__vbaObjSet(&ppppiStack_198,uVar8);
                          iVar10 = (**(code **)(*piVar9 + 0x9c))(piVar9,0);
                          if (iVar10 < 0) {
                            __vbaHresultCheckObj(iVar10,piVar9,&DAT_0040c3dc,0x9c);
                          }
                          __vbaFreeObj();
                          DAT_0050b338 = 1;
                          DAT_0050b334 = 3;
                          FUN_004cd650();
                        }
                        __vbaObjSetAddref(&pppppiStack_1f4,0);
                        __vbaFreeObj(&LAB_004c06a5);
                        return;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    __vbaFPException();
    return;
  }
  local_b0 = (int ****)0xa;
  local_a0[0] = (int ****)0xa;
  local_a8 = (wchar_t *)0x80020004;
  local_98 = 0x80020004;
  local_d8 = L"Input data error";
  local_e0[0] = (int ****)0x8;
  pppppiStack_17c = (int *****)0x4bf880;
  __vbaVarDup();
  local_c8 = L"All arcs from from current node have infinite length. No spanning tree exists.";
  local_d0 = (int ****)0x8;
  pppppiStack_17c = (int *****)0x4bf89b;
  __vbaVarDup();
  pppppiStack_17c = &local_b0;
  ppppiStack_180 = (int ****)local_a0;
  pppppiStack_184 = local_90;
  ppppiStack_18c = (int ****)&local_80;
  pppppiStack_188 = (int *****)0x10;
  pppppiStack_190 = (int *****)0x4bf8bc;
  Ordinal_595();
  pppppiStack_190 = &local_b0;
  ppppiStack_194 = (int ****)local_a0;
  ppppiStack_198 = (int ****)local_90;
  pppppiStack_19c = &local_80;
  pppppiStack_1a0 = (int *****)0x4;
  pwStack_1a4 = L"쒃昔ׇ댺P";
  __vbaFreeVarList();
  DAT_0050b33a = 0;
LAB_004bf961:
  pppppiStack_1f4 = (int *****)&LAB_004bf98b;
  pppppiStack_1f8 = (int *****)&local_140;
  pppppiStack_1fc = &local_13c;
  pppppiStack_200 = (int *****)0x2;
  pppppiStack_204 = (int *****)0x4bf977;
  __vbaFreeObjList();
  pppppiStack_1f8 = (int *****)0x4bf985;
  __vbaFreeStr();
  pppppiStack_1f8 = (int *****)0x4bf98a;
  __vbaFreeStr();
  return;
}


