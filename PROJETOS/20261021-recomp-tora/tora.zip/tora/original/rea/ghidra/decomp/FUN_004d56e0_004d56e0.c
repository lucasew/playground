/* entry 004d56e0 name FUN_004d56e0 size 1046 */

void FUN_004d56e0(short *param_1)

{
  short sVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  ushort in_FPUStatusWord;
  float10 fVar6;
  float10 fVar7;
  undefined4 local_f0;
  undefined4 local_e8;
  undefined4 local_d0;
  undefined4 local_c8;
  undefined4 local_b0;
  undefined4 local_a8;
  undefined4 local_90;
  undefined4 local_88;
  undefined4 local_70;
  undefined4 local_68;
  undefined4 local_50;
  undefined4 local_48;
  undefined4 local_44 [4];
  undefined4 local_34 [4];
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  void *pvStack_14;
  undefined *puStack_10;
  undefined1 *local_c;
  undefined *local_8;
  
  puStack_10 = &DAT_00402706;
  pvStack_14 = ExceptionList;
  local_c = &stack0xfffffecc;
  local_8 = &DAT_00402428;
  if ((in_FPUStatusWord & 0xd) == 0) {
    local_1c = 0;
    local_20 = 0;
    local_24 = 0;
    local_34[0] = 0;
    local_44[0] = 0;
    ExceptionList = &pvStack_14;
    local_c = &stack0xfffffecc;
    local_18 = __vbaFpI2();
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar2 = DAT_0050c53c;
    iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar2,&DAT_0040b410,0x20);
    }
    __vbaLateIdSt(local_1c,0x10013,2,local_50,1,local_48);
    __vbaFreeObj();
    sVar1 = *param_1;
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar2 = DAT_0050c53c;
    iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar2,&DAT_0040b410,0x20);
    }
    __vbaLateIdSt(local_1c,0x1000b,4,local_50,(float)(int)sVar1,local_48);
    __vbaFreeObj();
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar2 = DAT_0050c53c;
    iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar2,&DAT_0040b410,0x20);
    }
    uVar4 = __vbaLateIdCallLd(local_34,local_1c,0x1000b,0);
    fVar6 = (float10)__vbaR4Var(uVar4);
    iVar3 = (int)(short)local_18;
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar2 = DAT_0050c53c;
    iVar5 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_20);
    if (iVar5 < 0) {
      __vbaHresultCheckObj(iVar5,piVar2,&DAT_0040b410,0x20);
    }
    uVar4 = __vbaLateIdCallLd(local_44,local_20,0x1000b,0);
    fVar7 = (float10)__vbaR4Var(uVar4);
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar2 = DAT_0050c53c;
    iVar5 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_24);
    if (iVar5 < 0) {
      __vbaHresultCheckObj(iVar5,piVar2,&DAT_0040b410,0x20);
    }
    __vbaLateIdCall(local_24,0x20004,6,3,local_f0,0,local_e8,4,local_d0,(float)fVar7,local_c8,4,
                    local_b0,(float)iVar3,local_a8,4,local_90,(float)fVar6,local_88,4,local_70,
                    0x44960000,local_68,2,local_50,4,local_48);
    __vbaFreeObjList(3,&local_1c,&local_20,&local_24);
    __vbaFreeVarList(2,local_34,local_44);
    if (DAT_0050c53c == (int *)0x0) {
      __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
    }
    piVar2 = DAT_0050c53c;
    iVar3 = (**(code **)(*DAT_0050c53c + 0x20))(DAT_0050c53c,&local_1c);
    if (iVar3 < 0) {
      __vbaHresultCheckObj(iVar3,piVar2,&DAT_0040b410,0x20);
    }
    uVar4 = __vbaLateIdCallLd(local_34,local_1c,0x1000b,0);
    __vbaR4Var(uVar4);
    DAT_0050b268 = __vbaFpI4();
    __vbaFreeObj();
    __vbaFreeVar();
    return;
  }
  ExceptionList = &pvStack_14;
  __vbaFPException();
  return;
}


