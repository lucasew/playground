/* entry 0043c540 name FUN_0043c540 size 8166 */
/* strings:
 * Last tableau shows solution is unbounded
 * Optimal Tableau
 * Last row completes minimal spanning tree
 * No more breakthroughs -- Algorithm ends at iteration 
 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0043c540(uint param_1)

{
  ushort uVar1;
  short sVar2;
  short sVar3;
  code ******ppppppcVar4;
  int iVar5;
  int iVar6;
  code *******pppppppcVar7;
  code ******ppppppcVar8;
  undefined2 extraout_var;
  int *piVar9;
  undefined4 uVar10;
  short sVar11;
  short sVar12;
  undefined2 extraout_var_00;
  undefined2 extraout_var_01;
  undefined2 extraout_var_02;
  undefined2 extraout_var_03;
  code *******pppppppcVar13;
  code *pcVar14;
  undefined2 uVar15;
  code *******unaff_ESI;
  code *******pppppppcVar16;
  code *******unaff_EDI;
  code *******pppppppcVar17;
  code *pcVar18;
  bool bVar19;
  ushort in_FPUStatusWord;
  code ******ppppppcStack_30c;
  code ******ppppppcStack_308;
  code ******ppppppcStack_304;
  code ******ppppppcStack_300;
  code ******ppppppcStack_2fc;
  code ******ppppppcStack_2f8;
  code ******ppppppcStack_2f4;
  code ******ppppppcStack_2f0;
  code ******ppppppcStack_2ec;
  code ******ppppppcStack_2e8;
  code ******ppppppcStack_2e4;
  code ******ppppppcStack_2e0;
  code ******ppppppcStack_2dc;
  code ******ppppppcStack_2d8;
  code ******ppppppcStack_2d4;
  code ******ppppppcStack_2d0;
  code ******ppppppcStack_2cc;
  code ******ppppppcStack_2c8;
  code ******ppppppcStack_2c4;
  code ******ppppppcStack_2c0;
  float fStack_2bc;
  int iStack_2b8;
  int iStack_2b4;
  float fStack_2b0;
  int iStack_2ac;
  float fStack_2a8;
  short sStack_27c;
  ushort uStack_26c;
  code ******ppppppcStack_248;
  code ******ppppppcStack_244;
  code ******appppppcStack_240 [3];
  uint uStack_234;
  code ****ppppcStack_230;
  undefined4 uStack_21c;
  code ******ppppppcStack_218;
  code ******ppppppcStack_210;
  undefined4 uStack_200;
  code ******ppppppcStack_1fc;
  code ******ppppppcStack_1f8;
  undefined4 uStack_1f4;
  code ******ppppppcStack_1f0;
  code ******ppppppcStack_1ec;
  int iStack_1e8;
  code ******ppppppcStack_1e4;
  undefined4 uStack_1e0;
  code ******ppppppcStack_1dc;
  code ******ppppppcStack_1d8;
  code ******ppppppcStack_1d4;
  code ******ppppppcStack_1d0;
  code ******ppppppcStack_1cc;
  code ******ppppppcStack_1c8;
  code ******ppppppcStack_1c4;
  code ******ppppppcStack_1c0;
  code *****pppppcStack_1bc;
  undefined4 uStack_1b8;
  code ******ppppppcStack_1b4;
  int iStack_1b0;
  code ******ppppppcStack_1ac;
  code ******ppppppcStack_1a8;
  undefined4 uStack_1a4;
  code ******ppppppcStack_1a0;
  code ******ppppppcStack_19c;
  code ******ppppppcStack_198;
  code ******ppppppcStack_194;
  code ******ppppppcStack_190;
  code *****pppppcStack_18c;
  code ******ppppppcStack_188;
  code ******ppppppcStack_184;
  code ******ppppppcStack_180;
  code ******ppppppcStack_17c;
  code ******ppppppcStack_178;
  code ******ppppppcStack_174;
  code ******ppppppcStack_170;
  code ******ppppppcStack_16c;
  code ******ppppppcStack_168;
  code ******ppppppcStack_164;
  code ******ppppppcStack_160;
  code ******ppppppcStack_15c;
  code ******ppppppcStack_158;
  code *****pppppcStack_154;
  code ******local_f0;
  code ******local_ec;
  code ******local_e8 [3];
  uint local_dc;
  uint local_d8;
  undefined4 local_c4;
  code ******local_c0;
  code ******local_b8;
  undefined4 local_a4;
  code ******local_a0;
  code ******local_98;
  undefined4 local_94;
  wchar_t *local_8c;
  code ******local_84;
  code ******local_80;
  code ******local_7c;
  code ******local_78;
  code *****local_74 [2];
  undefined4 local_6c;
  code *****local_64 [2];
  undefined4 local_5c;
  code *****local_54 [4];
  code *****local_44 [2];
  undefined4 local_3c;
  code *****local_34;
  undefined4 local_30;
  undefined4 local_2c;
  short *local_28 [4];
  void *pvStack_18;
  undefined *puStack_14;
  undefined1 *local_10;
  undefined *local_c;
  uint local_8;
  
  puStack_14 = &DAT_00402706;
  pvStack_18 = ExceptionList;
  local_10 = &stack0xfffffeb0;
  local_c = &DAT_00401bc8;
  local_8 = param_1 & 1;
  pppppcStack_154 = (code *****)(param_1 & 0xfffffffe);
  ppppppcStack_158 = (code ******)0x43c582;
  ExceptionList = &pvStack_18;
  (*(code *)(*pppppcStack_154)[1])();
  pppppppcVar13 = (code *******)0x0;
  local_28[0] = (short *)0x0;
  local_2c = 0;
  local_30 = 0;
  local_34 = (code *****)0x0;
  local_44[0] = (code *****)0x0;
  local_54[0] = (code *****)0x0;
  local_64[0] = (code *****)0x0;
  local_74[0] = (code *****)0x0;
  local_84 = (code ******)0x0;
  local_94 = 0;
  local_a4 = 0;
  local_c4 = 0;
  local_e8[0] = (code ******)0x0;
  local_ec = (code ******)0x0;
  local_f0 = (code ******)0x0;
  _DAT_0050b20e = 1;
  pppppppcVar17 = unaff_EDI;
  switch(DAT_0050b238) {
  case 3:
    sVar3 = DAT_0050b29a + 1;
    local_84 = (code ******)0x3;
    if (((!SCARRY2(DAT_0050b29a,1)) && (DAT_0050b29a = sVar3, !SCARRY2(DAT_0050b20c,7))) &&
       ((iVar6 = (int)(short)(DAT_0050b20c + 7) * (int)sVar3, sVar3 = (short)iVar6, sVar3 == iVar6
        && (DAT_0050b298 = sVar3, !SCARRY2(DAT_0050b276,sVar3))))) {
      local_7c = (code ******)(int)(short)(DAT_0050b276 + sVar3);
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_158 = (code ******)&DAT_0050b420;
        ppppppcStack_15c = (code ******)&DAT_00408c88;
        ppppppcStack_160 = (code ******)0x43c654;
        __vbaNew2();
      }
      ppppppcStack_168 = (code ******)0x4;
      ppppppcStack_16c = (code ******)DAT_0050b420;
      ppppppcStack_164 = local_84;
      ppppppcStack_160 = local_80;
      ppppppcStack_15c = local_7c;
      ppppppcStack_158 = local_78;
      ppppppcStack_170 = (code ******)0x43c680;
      ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      unaff_ESI = (code *******)__vbaObjSet_exref;
      ppppppcStack_174 = &local_34;
      ppppppcStack_178 = (code ******)0x43c68d;
      ppppppcStack_178 = (code ******)__vbaObjSet();
      pppppppcVar17 = (code *******)__vbaLateIdSt_exref;
      ppppppcStack_17c = (code ******)0x43c696;
      __vbaLateIdSt();
      ppppppcStack_17c = (code ******)0x43c69f;
      __vbaFreeObj();
      pcVar14 = __vbaI2Abs_exref;
      if (!SCARRY2(DAT_0050b244,1)) {
        _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
        if ((short)DAT_0050b260 == -0x56ce) {
          ppppppcStack_158 = (code ******)0x43c6c5;
          FUN_00481f60();
          if (0 < DAT_0050b1e0) {
            DAT_0050b25e = 0;
            DAT_0050b1e0 = -1;
          }
          goto switchD_0043c5df_caseD_5;
        }
        ppppppcStack_158 = (code ******)0x43c6f5;
        sVar3 = __vbaI2Abs();
        sVar2 = (short)((int)sVar3 * (int)DAT_0050b25e);
        pppppppcVar13 = (code *******)pcVar14;
        if ((int)sVar2 == (int)sVar3 * (int)DAT_0050b25e) {
          if ((0 < sVar2) || (DAT_0050b240 == -2)) {
            ppppppcStack_158 = (code ******)0x43cbed;
            DAT_0050b240 = __vbaI2Abs();
            if (DAT_0050b274 == 5) {
              ppppppcStack_158 = (code ******)0x43cc0c;
              FUN_00482b00();
            }
            else {
              ppppppcStack_158 = (code ******)0x43cc02;
              FUN_00481f60();
            }
LAB_0043c8a0:
            if (0 < DAT_0050b1e0) {
              DAT_0050b25e = 0;
              DAT_0050b1e0 = -1;
            }
            goto switchD_0043c5df_caseD_5;
          }
          if (DAT_0050b25e == 0) {
            local_74[0] = (code *****)0xa;
            local_64[0] = (code *****)0xa;
            unaff_ESI = (code *******)0x8;
            local_6c = 0x80020004;
            local_5c = 0x80020004;
            local_7c = (code ******)0x40df04;
            local_84 = (code ******)0x8;
            ppppppcStack_158 = (code ******)0x43c759;
            __vbaVarDup();
            pppppcStack_154 = (code *****)0x40decc;
            ppppppcStack_158 = (code ******)CONCAT22(extraout_var_02,DAT_0050b244 + 1);
            if (!SCARRY2(DAT_0050b244,1)) {
              ppppppcStack_15c = (code ******)0x43c776;
              __vbaStrI2();
              ppppppcStack_15c = (code ******)0x43c783;
              ppppppcStack_15c = (code ******)__vbaStrMove();
              ppppppcStack_160 = (code ******)0x43c78c;
              __vbaStrCat();
              ppppppcStack_160 = (code ******)0x43c793;
              ppppppcStack_160 = (code ******)__vbaStrMove();
              ppppppcStack_164 = (code ******)0x40dee8;
              ppppppcStack_168 = (code ******)0x43c79b;
              local_3c = __vbaStrCat();
              ppppppcStack_168 = local_74;
              ppppppcStack_16c = local_64;
              ppppppcStack_170 = local_54;
              ppppppcStack_178 = local_44;
              ppppppcStack_174 = (code ******)0x40;
              local_44[0] = (code *****)0x8;
              ppppppcStack_17c = (code ******)0x43c7b9;
              Ordinal_595();
              ppppppcStack_17c = (code ******)&local_30;
              ppppppcStack_180 = (code ******)&local_2c;
              ppppppcStack_184 = (code ******)0x2;
              ppppppcStack_188 = (code ******)0x43c7c9;
              __vbaFreeStrList();
              ppppppcStack_188 = local_74;
              pppppcStack_18c = (code *****)local_64;
              ppppppcStack_190 = local_54;
              ppppppcStack_194 = local_44;
              ppppppcStack_198 = (code ******)0x4;
              ppppppcStack_19c = (code ******)0x43c7e1;
              __vbaFreeVarList();
              if (DAT_0050b420 == (code *******)0x0) {
                ppppppcStack_17c = (code ******)&DAT_0050b420;
                ppppppcStack_180 = (code ******)&DAT_00408c88;
                ppppppcStack_184 = (code ******)0x43c7fd;
                __vbaNew2();
              }
              ppppppcStack_17c = (code ******)DAT_0050b420;
              ppppppcStack_180 = (code ******)0x43c80b;
              ppppppcStack_180 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
              ppppppcStack_184 = &local_34;
              ppppppcStack_188 = (code ******)0x43c818;
              ppppppcVar8 = (code ******)__vbaObjSet();
              ppppppcStack_188 = (code ******)0x0;
              ppppppcStack_190 = (code ******)0x43c825;
              pppppcStack_18c = (code *****)ppppppcVar8;
              ppppppcVar4 = (code ******)(*(code *)(*ppppppcVar8)[0x23])();
              if ((int)ppppppcVar4 < 0) {
                ppppppcStack_190 = (code ******)0x8c;
                ppppppcStack_194 = (code ******)&DAT_0040bb6c;
                ppppppcStack_1a0 = (code ******)0x43c83d;
                ppppppcStack_19c = ppppppcVar4;
                ppppppcStack_198 = ppppppcVar8;
                __vbaHresultCheckObj();
              }
              pcVar14 = __vbaFreeObj_exref;
              ppppppcStack_190 = (code ******)0x43c848;
              __vbaFreeObj();
              if (DAT_0050b420 == (code *******)0x0) {
                ppppppcStack_190 = (code ******)&DAT_0050b420;
                ppppppcStack_194 = (code ******)&DAT_00408c88;
                ppppppcStack_198 = (code ******)0x43c861;
                __vbaNew2();
              }
              ppppppcStack_190 = (code ******)DAT_0050b420;
              ppppppcStack_194 = (code ******)0x43c86f;
              ppppppcStack_194 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
              ppppppcStack_198 = &local_34;
              ppppppcStack_19c = (code ******)0x43c876;
              pppppppcVar13 = (code *******)__vbaObjSet();
              ppppppcStack_19c = (code ******)0x0;
              uStack_1a4 = 0x43c883;
              ppppppcStack_1a0 = (code ******)pppppppcVar13;
              iVar5 = (*(code *)(*pppppppcVar13)[0x23])();
              iVar6 = iStack_1b0;
              pppppppcVar17 = (code *******)ppppppcStack_1ac;
joined_r0x0043cbcf:
              iStack_1b0 = iVar5;
              ppppppcStack_1ac = (code ******)pppppppcVar13;
              if (iStack_1b0 < 0) {
                uStack_1a4 = 0x8c;
                ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
                ppppppcStack_1b4 = (code ******)0x43c89b;
                __vbaHresultCheckObj();
                iVar6 = iStack_1b0;
                pppppppcVar17 = (code *******)ppppppcStack_1ac;
              }
              ppppppcStack_1ac = (code ******)pppppppcVar17;
              iStack_1b0 = iVar6;
              uStack_1a4 = 0x43c8a0;
              (*pcVar14)();
              goto LAB_0043c8a0;
            }
          }
          else {
            if ((short)DAT_0050b260 != 0) goto LAB_0043c8a0;
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_158 = (code ******)&DAT_0050b420;
              ppppppcStack_15c = (code ******)&DAT_00408c88;
              ppppppcStack_160 = (code ******)0x43c8e8;
              __vbaNew2();
            }
            ppppppcStack_158 = (code ******)DAT_0050b420;
            ppppppcStack_15c = (code ******)0x43c8f6;
            ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
            ppppppcStack_160 = (code ******)local_e8;
            ppppppcStack_164 = (code ******)0x43c900;
            __vbaObjSet();
            ppppppcStack_164 = (code ******)0x43c909;
            sVar3 = __vbaI2Abs();
            local_84 = (code ******)0x3;
            ppppppcStack_168 = (code ******)(int)sVar3;
            ppppppcStack_170 = (code ******)0x3;
            ppppppcStack_174 = (code ******)0xb;
            ppppppcStack_16c = local_80;
            ppppppcStack_178 = local_e8[0];
            ppppppcStack_164 = local_78;
            ppppppcStack_17c = (code ******)0x43c938;
            local_7c = ppppppcStack_168;
            __vbaLateIdSt();
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_158 = (code ******)0x43c994;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              unaff_ESI = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
              if (*(code ********)(DAT_0050b1a4 + 0xc) <= unaff_ESI) {
                ppppppcStack_158 = (code ******)0x43c95f;
                __vbaGenerateBoundsError();
              }
              pcVar14 = (code *)(1 - *(int *)(DAT_0050b1a4 + 10));
              if (*(code **)(DAT_0050b1a4 + 8) <= pcVar14) {
                ppppppcStack_158 = (code ******)0x43c97c;
                __vbaGenerateBoundsError();
              }
              iVar6 = (int)((int)unaff_ESI + *(int *)(DAT_0050b1a4 + 0xc) * (int)pcVar14) * 2;
            }
            uVar15 = (undefined2)((uint)pcVar14 >> 0x10);
            sVar3 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6) + DAT_0050b20c;
            pppppppcVar13 = (code *******)CONCAT22(uVar15,sVar3);
            if (!SCARRY2(*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6),DAT_0050b20c)) {
              pppppppcVar13 = (code *******)CONCAT22(uVar15,sVar3 + 5);
              if (!SCARRY2(sVar3,5)) {
                if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
                  ppppppcStack_158 = (code ******)0x43ca18;
                  iVar6 = __vbaGenerateBoundsError();
                }
                else {
                  local_dc = 1 - *(int *)(DAT_0050b1a4 + 0xe);
                  if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_dc) {
                    ppppppcStack_158 = (code ******)0x43c9df;
                    __vbaGenerateBoundsError();
                  }
                  unaff_ESI = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
                  if (*(code ********)(DAT_0050b1a4 + 8) <= unaff_ESI) {
                    ppppppcStack_158 = (code ******)0x43c9fc;
                    __vbaGenerateBoundsError();
                  }
                  iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)unaff_ESI + local_dc) * 2;
                }
                pppppppcVar16 =
                     (code *******)
                     CONCAT22((short)((uint)unaff_ESI >> 0x10),
                              *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar6));
                do {
                  unaff_ESI = pppppppcVar16;
                  sVar2 = (short)unaff_ESI;
                  if ((short)(sVar3 + 5) < sVar2) {
                    ppppppcStack_15c = (code ******)local_e8;
                    ppppppcStack_158 = (code ******)0x0;
                    ppppppcStack_160 = (code ******)0x43caab;
                    __vbaObjSetAddref();
                    local_74[0] = (code *****)0xa;
                    local_64[0] = (code *****)0xa;
                    local_6c = 0x80020004;
                    local_5c = 0x80020004;
                    local_8c = L"Optimal Tableau";
                    local_94 = 8;
                    ppppppcStack_160 = (code ******)0x43cae7;
                    __vbaVarDup();
                    local_7c = (code ******)0x40dd2c;
                    local_84 = (code ******)0x8;
                    ppppppcStack_160 = (code ******)0x43caf9;
                    __vbaVarDup();
                    ppppppcStack_160 = local_74;
                    ppppppcStack_164 = local_64;
                    ppppppcStack_168 = local_54;
                    ppppppcStack_170 = local_44;
                    ppppppcStack_16c = (code ******)0x40;
                    ppppppcStack_174 = (code ******)0x43cb11;
                    Ordinal_595();
                    ppppppcStack_174 = local_74;
                    ppppppcStack_178 = local_64;
                    ppppppcStack_17c = local_54;
                    ppppppcStack_180 = local_44;
                    ppppppcStack_184 = (code ******)0x4;
                    ppppppcStack_188 = (code ******)0x43cb29;
                    __vbaFreeVarList();
                    if (DAT_0050b420 == (code *******)0x0) {
                      ppppppcStack_174 = (code ******)&DAT_0050b420;
                      ppppppcStack_178 = (code ******)&DAT_00408c88;
                      ppppppcStack_17c = (code ******)0x43cb45;
                      __vbaNew2();
                    }
                    ppppppcStack_174 = (code ******)DAT_0050b420;
                    ppppppcStack_178 = (code ******)0x43cb53;
                    ppppppcStack_178 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
                    ppppppcStack_17c = &local_34;
                    ppppppcStack_180 = (code ******)0x43cb60;
                    pppppppcVar17 = (code *******)__vbaObjSet();
                    ppppppcStack_180 = (code ******)0x0;
                    ppppppcStack_188 = (code ******)0x43cb6d;
                    ppppppcStack_184 = (code ******)pppppppcVar17;
                    pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
                    if ((int)pppppppcVar13 < 0) {
                      ppppppcStack_188 = (code ******)0x8c;
                      pppppcStack_18c = (code *****)&DAT_0040bb6c;
                      ppppppcStack_198 = (code ******)0x43cb85;
                      ppppppcStack_194 = (code ******)pppppppcVar13;
                      ppppppcStack_190 = (code ******)pppppppcVar17;
                      __vbaHresultCheckObj();
                    }
                    pcVar14 = __vbaFreeObj_exref;
                    ppppppcStack_188 = (code ******)0x43cb90;
                    __vbaFreeObj();
                    if (DAT_0050b420 == (code *******)0x0) {
                      ppppppcStack_188 = (code ******)&DAT_0050b420;
                      pppppcStack_18c = (code *****)&DAT_00408c88;
                      ppppppcStack_190 = (code ******)0x43cba9;
                      __vbaNew2();
                    }
                    ppppppcStack_188 = (code ******)DAT_0050b420;
                    pppppcStack_18c = (code *****)0x43cbb7;
                    pppppcStack_18c = (code *****)(*(code *)(*DAT_0050b420)[0xdd])();
                    ppppppcStack_190 = &local_34;
                    ppppppcStack_194 = (code ******)0x43cbbe;
                    pppppppcVar13 = (code *******)__vbaObjSet();
                    ppppppcStack_194 = (code ******)0x0;
                    ppppppcStack_19c = (code ******)0x43cbcb;
                    ppppppcStack_198 = (code ******)pppppppcVar13;
                    iVar5 = (*(code *)(*pppppppcVar13)[0x23])();
                    iVar6 = iStack_1b0;
                    pppppppcVar17 = (code *******)ppppppcStack_1ac;
                    goto joined_r0x0043cbcf;
                  }
                  local_84 = (code ******)0x3;
                  ppppppcStack_15c = (code ******)(int)sVar2;
                  ppppppcStack_164 = (code ******)0x3;
                  ppppppcStack_168 = (code ******)0xa;
                  ppppppcStack_160 = local_80;
                  ppppppcStack_16c = local_e8[0];
                  ppppppcStack_158 = local_78;
                  ppppppcStack_170 = (code ******)0x43ca59;
                  local_7c = ppppppcStack_15c;
                  __vbaLateIdSt();
                  local_84 = (code ******)0x3;
                  ppppppcStack_180 = (code ******)0x26;
                  ppppppcStack_17c = (code ******)0x3;
                  local_7c = (code ******)0xff00;
                  ppppppcStack_178 = local_80;
                  ppppppcStack_184 = local_e8[0];
                  ppppppcStack_174 = (code ******)0xff00;
                  ppppppcStack_170 = local_78;
                  ppppppcStack_188 = (code ******)0x43ca8a;
                  __vbaLateIdSt();
                  pppppppcVar16 = (code *******)(uint)(ushort)(sVar2 + 1);
                } while (!SCARRY2(sVar2,1));
              }
            }
          }
        }
      }
    }
    break;
  case 4:
    if (DAT_0050b420 == (code *******)0x0) {
      ppppppcStack_158 = (code ******)&DAT_0050b420;
      ppppppcStack_15c = (code ******)&DAT_00408c88;
      ppppppcStack_160 = (code ******)0x43cc2a;
      __vbaNew2();
    }
    ppppppcStack_158 = (code ******)DAT_0050b420;
    ppppppcStack_15c = (code ******)0x43cc38;
    ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xcf])();
    pppppppcVar13 = (code *******)__vbaObjSet_exref;
    ppppppcStack_160 = &local_34;
    ppppppcStack_164 = (code ******)0x43cc45;
    pppppppcVar17 = (code *******)__vbaObjSet();
    ppppppcStack_164 = (code ******)0x0;
    ppppppcStack_16c = (code ******)0x43cc52;
    ppppppcStack_168 = (code ******)pppppppcVar17;
    pppppppcVar16 = (code *******)(*(code *)(*pppppppcVar17)[0x25])();
    if ((int)pppppppcVar16 < 0) {
      ppppppcStack_16c = (code ******)0x94;
      ppppppcStack_170 = (code ******)&DAT_0040c3dc;
      ppppppcStack_17c = (code ******)0x43cc6a;
      ppppppcStack_178 = (code ******)pppppppcVar16;
      ppppppcStack_174 = (code ******)pppppppcVar17;
      __vbaHresultCheckObj();
    }
    unaff_ESI = (code *******)__vbaFreeObj_exref;
    ppppppcStack_16c = (code ******)0x43cc75;
    __vbaFreeObj();
    if (DAT_0050b420 == (code *******)0x0) {
      ppppppcStack_16c = (code ******)&DAT_0050b420;
      ppppppcStack_170 = (code ******)&DAT_00408c88;
      ppppppcStack_174 = (code ******)0x43cc8e;
      __vbaNew2();
    }
    ppppppcStack_16c = (code ******)DAT_0050b420;
    ppppppcStack_170 = (code ******)0x43cc9c;
    ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xd0])();
    ppppppcStack_174 = &local_34;
    ppppppcStack_178 = (code ******)0x43cca3;
    pppppppcVar17 = (code *******)__vbaObjSet();
    ppppppcStack_178 = (code ******)0x0;
    ppppppcStack_180 = (code ******)0x43ccb0;
    ppppppcStack_17c = (code ******)pppppppcVar17;
    ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x25])();
    in_FPUStatusWord = 0;
    if ((int)ppppppcVar8 < 0) {
      ppppppcStack_180 = (code ******)0x94;
      ppppppcStack_184 = (code ******)&DAT_0040dc58;
      ppppppcStack_190 = (code ******)0x43ccc8;
      pppppcStack_18c = (code *****)ppppppcVar8;
      ppppppcStack_188 = (code ******)pppppppcVar17;
      __vbaHresultCheckObj();
    }
    ppppppcStack_180 = (code ******)0x43cccd;
    __vbaFreeObj();
    sVar3 = DAT_0050b244;
    sVar2 = DAT_0050b244 + 1;
    if ((!SCARRY2(DAT_0050b244,1)) &&
       (sVar11 = (short)(DAT_0050b2c4 * 3), (int)sVar11 == DAT_0050b2c4 * 3)) {
      sVar12 = sVar11 + 4;
      _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,sVar2);
      if (!SCARRY2(sVar11,4)) {
        sVar11 = DAT_0050b298 + sVar12;
        local_84 = (code ******)0x3;
        if (((!SCARRY2(DAT_0050b298,sVar12)) && (DAT_0050b298 = sVar11, !SCARRY2(sVar2,1))) &&
           (iVar6 = (int)(short)(sVar3 + 2) * (int)sVar12, sVar3 = (short)iVar6, sVar3 == iVar6)) {
          local_7c = (code ******)(int)sVar3;
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_158 = (code ******)&DAT_0050b420;
            ppppppcStack_15c = (code ******)&DAT_00408c88;
            ppppppcStack_160 = (code ******)0x43cd4f;
            __vbaNew2();
          }
          ppppppcStack_168 = (code ******)0x4;
          ppppppcStack_16c = (code ******)DAT_0050b420;
          ppppppcStack_164 = local_84;
          ppppppcStack_160 = local_80;
          ppppppcStack_15c = local_7c;
          ppppppcStack_158 = local_78;
          ppppppcStack_170 = (code ******)0x43cd7b;
          ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
          ppppppcStack_174 = &local_34;
          ppppppcStack_178 = (code ******)0x43cd82;
          ppppppcStack_178 = (code ******)__vbaObjSet();
          ppppppcStack_17c = (code ******)0x43cd89;
          __vbaLateIdSt();
          ppppppcStack_17c = (code ******)0x43cd8e;
          __vbaFreeObj();
          ppppppcStack_158 = (code ******)0x43cd93;
          FUN_004b8890();
          goto switchD_0043c5df_caseD_5;
        }
      }
    }
    break;
  default:
    goto switchD_0043c5df_caseD_5;
  case 7:
    switch(DAT_0050b334) {
    case 1:
      ppppppcStack_158 = (code ******)0x43cdb5;
      FUN_004bea60();
      pcVar18 = __vbaObjSet_exref;
      pcVar14 = __vbaHresultCheckObj_exref;
      if (DAT_0050b33a == DAT_0050b332) {
        local_74[0] = (code *****)0xa;
        local_64[0] = (code *****)0xa;
        local_6c = 0x80020004;
        local_5c = 0x80020004;
        local_8c = L"Optimum";
        local_94 = 8;
        ppppppcStack_158 = (code ******)0x43ce04;
        __vbaVarDup();
        local_7c = (code ******)0x40df54;
        local_84 = (code ******)0x8;
        ppppppcStack_158 = (code ******)0x43ce16;
        __vbaVarDup();
        ppppppcStack_158 = local_74;
        ppppppcStack_15c = local_64;
        ppppppcStack_160 = local_54;
        ppppppcStack_168 = local_44;
        ppppppcStack_164 = (code ******)0x40;
        ppppppcStack_16c = (code ******)0x43ce2e;
        Ordinal_595();
        ppppppcStack_16c = local_74;
        ppppppcStack_170 = local_64;
        ppppppcStack_174 = local_54;
        ppppppcStack_178 = local_44;
        ppppppcStack_17c = (code ******)0x4;
        ppppppcStack_180 = (code ******)0x43ce46;
        __vbaFreeVarList();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_16c = (code ******)&DAT_0050b420;
          ppppppcStack_170 = (code ******)&DAT_00408c88;
          ppppppcStack_174 = (code ******)0x43ce62;
          __vbaNew2();
        }
        ppppppcStack_16c = (code ******)DAT_0050b420;
        ppppppcStack_170 = (code ******)0x43ce70;
        ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
        pcVar18 = __vbaObjSet_exref;
        ppppppcStack_174 = &local_34;
        ppppppcStack_178 = (code ******)0x43ce7d;
        pppppppcVar17 = (code *******)__vbaObjSet();
        ppppppcStack_178 = (code ******)0x0;
        ppppppcStack_180 = (code ******)0x43ce8a;
        ppppppcStack_17c = (code ******)pppppppcVar17;
        ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x23])();
        pcVar14 = __vbaHresultCheckObj_exref;
        if ((int)ppppppcVar8 < 0) {
          ppppppcStack_180 = (code ******)0x8c;
          ppppppcStack_184 = (code ******)&DAT_0040bb6c;
          ppppppcStack_190 = (code ******)0x43cea4;
          pppppcStack_18c = (code *****)ppppppcVar8;
          ppppppcStack_188 = (code ******)pppppppcVar17;
          __vbaHresultCheckObj();
        }
        ppppppcStack_180 = (code ******)0x43ceb5;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_180 = (code ******)&DAT_0050b420;
          ppppppcStack_184 = (code ******)&DAT_00408c88;
          ppppppcStack_188 = (code ******)0x43cece;
          __vbaNew2();
        }
        ppppppcStack_180 = (code ******)DAT_0050b420;
        ppppppcStack_184 = (code ******)0x43cedc;
        ppppppcStack_184 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
        ppppppcStack_188 = &local_34;
        pppppcStack_18c = (code *****)0x43cee3;
        pppppppcVar17 = (code *******)__vbaObjSet();
        pppppcStack_18c = (code *****)0x0;
        ppppppcStack_194 = (code ******)0x43cef0;
        ppppppcStack_190 = (code ******)pppppppcVar17;
        pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
        if ((int)pppppppcVar13 < 0) {
          ppppppcStack_194 = (code ******)0x8c;
          ppppppcStack_198 = (code ******)&DAT_0040bb6c;
          uStack_1a4 = 0x43cf04;
          ppppppcStack_1a0 = (code ******)pppppppcVar13;
          ppppppcStack_19c = (code ******)pppppppcVar17;
          __vbaHresultCheckObj();
        }
        ppppppcStack_194 = (code ******)0x43cf0d;
        __vbaFreeObj();
      }
      if (DAT_0050b33a == 0) {
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_158 = (code ******)&DAT_0050b420;
          ppppppcStack_15c = (code ******)&DAT_00408c88;
          ppppppcStack_160 = (code ******)0x43cf42;
          __vbaNew2();
        }
        ppppppcStack_158 = (code ******)DAT_0050b420;
        ppppppcStack_15c = (code ******)0x43cf50;
        ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
        ppppppcStack_160 = &local_34;
        ppppppcStack_164 = (code ******)0x43cf57;
        pppppppcVar17 = (code *******)(*pcVar18)();
        ppppppcStack_164 = (code ******)0x0;
        ppppppcStack_16c = (code ******)0x43cf64;
        ppppppcStack_168 = (code ******)pppppppcVar17;
        pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
        if ((int)pppppppcVar13 < 0) {
          ppppppcStack_16c = (code ******)0x8c;
          ppppppcStack_170 = (code ******)&DAT_0040bb6c;
          ppppppcStack_17c = (code ******)0x43cf78;
          ppppppcStack_178 = (code ******)pppppppcVar13;
          ppppppcStack_174 = (code ******)pppppppcVar17;
          (*pcVar14)();
        }
        ppppppcStack_16c = (code ******)0x43cf81;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_16c = (code ******)&DAT_0050b420;
          ppppppcStack_170 = (code ******)&DAT_00408c88;
          ppppppcStack_174 = (code ******)0x43cf9a;
          __vbaNew2();
        }
        ppppppcStack_16c = (code ******)DAT_0050b420;
        ppppppcStack_170 = (code ******)0x43cfa8;
        ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
        ppppppcStack_174 = &local_34;
        ppppppcStack_178 = (code ******)0x43cfaf;
        pppppppcVar17 = (code *******)(*pcVar18)();
        ppppppcStack_178 = (code ******)0x0;
        ppppppcStack_180 = (code ******)0x43cfbc;
        ppppppcStack_17c = (code ******)pppppppcVar17;
        ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x23])();
        if ((int)ppppppcVar8 < 0) {
          ppppppcStack_180 = (code ******)0x8c;
          ppppppcStack_184 = (code ******)&DAT_0040bb6c;
          ppppppcStack_190 = (code ******)0x43cfd0;
          pppppcStack_18c = (code *****)ppppppcVar8;
          ppppppcStack_188 = (code ******)pppppppcVar17;
          (*pcVar14)();
        }
        ppppppcStack_180 = (code ******)0x43cfd9;
        __vbaFreeObj();
      }
    default:
switchD_0043c5df_caseD_5:
      local_8 = 0;
      ppppppcStack_158 = (code ******)&LAB_0043e550;
      ppppppcStack_15c = (code ******)&local_f0;
      ppppppcStack_160 = (code ******)&local_ec;
      ppppppcStack_164 = (code ******)local_e8;
      ppppppcStack_168 = (code ******)0x3;
      ppppppcStack_16c = (code ******)0x43e54c;
      __vbaFreeObjList();
      return;
    case 2:
      ppppppcStack_158 = (code ******)0x43cfe3;
      FUN_004c5770();
      sVar3 = DAT_0050b244 + 1;
      if (!SCARRY2(DAT_0050b244,1)) {
        _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,sVar3);
        if (!SCARRY2(DAT_0050b332,1)) {
          if (sVar3 != (ushort)(DAT_0050b332 + 1)) goto switchD_0043c5df_caseD_5;
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_158 = (code ******)&DAT_0050b420;
            ppppppcStack_15c = (code ******)&DAT_00408c88;
            ppppppcStack_160 = (code ******)0x43d02c;
            __vbaNew2();
          }
          ppppppcStack_158 = (code ******)DAT_0050b420;
          ppppppcStack_15c = (code ******)0x43d03a;
          ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
          ppppppcStack_160 = &local_34;
          ppppppcStack_164 = (code ******)0x43d047;
          pppppppcVar17 = (code *******)__vbaObjSet();
          ppppppcStack_164 = (code ******)0x0;
          ppppppcStack_16c = (code ******)0x43d053;
          ppppppcStack_168 = (code ******)pppppppcVar17;
          pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
          if ((int)pppppppcVar13 < 0) {
            ppppppcStack_16c = (code ******)0x8c;
            ppppppcStack_170 = (code ******)&DAT_0040bb6c;
            ppppppcStack_17c = (code ******)0x43d06b;
            ppppppcStack_178 = (code ******)pppppppcVar13;
            ppppppcStack_174 = (code ******)pppppppcVar17;
            __vbaHresultCheckObj();
          }
          ppppppcStack_16c = (code ******)0x43d076;
          __vbaFreeObj();
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_16c = (code ******)&DAT_0050b420;
            ppppppcStack_170 = (code ******)&DAT_00408c88;
            ppppppcStack_174 = (code ******)0x43d08f;
            __vbaNew2();
          }
          ppppppcStack_16c = (code ******)DAT_0050b420;
          ppppppcStack_170 = (code ******)0x43d09d;
          ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
          ppppppcStack_174 = &local_34;
          ppppppcStack_178 = (code ******)0x43d0a4;
          pppppppcVar17 = (code *******)__vbaObjSet();
          ppppppcStack_178 = (code ******)0x0;
          ppppppcStack_180 = (code ******)0x43d0b1;
          ppppppcStack_17c = (code ******)pppppppcVar17;
          ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x23])();
          if ((int)ppppppcVar8 < 0) {
            ppppppcStack_180 = (code ******)0x8c;
            ppppppcStack_184 = (code ******)&DAT_0040bb6c;
            ppppppcStack_190 = (code ******)0x43d0c9;
            pppppcStack_18c = (code *****)ppppppcVar8;
            ppppppcStack_188 = (code ******)pppppppcVar17;
            __vbaHresultCheckObj();
          }
          ppppppcStack_180 = (code ******)0x43d0ce;
          __vbaFreeObj();
LAB_0043d0ce:
          local_74[0] = (code *****)0xa;
          local_64[0] = (code *****)0xa;
          local_6c = 0x80020004;
          local_5c = 0x80020004;
          local_8c = L"Optimum";
          local_94 = 8;
          ppppppcStack_180 = (code ******)0x43d10a;
          __vbaVarDup();
          local_7c = (code ******)0x40dfc0;
          local_84 = (code ******)0x8;
          ppppppcStack_180 = (code ******)0x43d11c;
          __vbaVarDup();
          ppppppcStack_180 = local_74;
          ppppppcStack_184 = local_64;
          ppppppcStack_188 = local_54;
          ppppppcStack_190 = local_44;
          pppppcStack_18c = (code *****)0x40;
          ppppppcStack_194 = (code ******)0x43d134;
          Ordinal_595();
LAB_0043d134:
          ppppppcStack_194 = local_74;
          ppppppcStack_198 = local_64;
          ppppppcStack_19c = local_54;
          ppppppcStack_1a0 = local_44;
          uStack_1a4 = 4;
          ppppppcStack_1a8 = (code ******)0x43d14c;
          __vbaFreeVarList();
          goto switchD_0043c5df_caseD_5;
        }
      }
      break;
    case 3:
      ppppppcStack_158 = (code ******)0x43d159;
      FUN_004c9e80();
      unaff_ESI = (code *******)__vbaGenerateBoundsError_exref;
      if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
        ppppppcStack_158 = (code ******)0x43d1b0;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        pppppppcVar13 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
        if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar13) {
          ppppppcStack_158 = (code ******)0x43d182;
          __vbaGenerateBoundsError();
        }
        pppppppcVar17 = (code *******)-*(int *)(DAT_0050b1a4 + 10);
        if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar17) {
          ppppppcStack_158 = (code ******)0x43d196;
          __vbaGenerateBoundsError();
        }
        iVar6 = (int)((int)pppppppcVar13 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar17) * 2;
      }
      if (*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6) < 1) {
LAB_0043d4a8:
        if (!SCARRY2(DAT_0050b244,1)) {
          _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
          ppppppcStack_158 = (code ******)0x43d4c3;
          FUN_004ca300();
          if (!SCARRY2(DAT_0050b332,1)) {
            if (DAT_0050b244 != (ushort)(DAT_0050b332 + 1)) goto switchD_0043c5df_caseD_5;
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_158 = (code ******)&DAT_0050b420;
              ppppppcStack_15c = (code ******)&DAT_00408c88;
              ppppppcStack_160 = (code ******)0x43d4fa;
              __vbaNew2();
            }
            ppppppcStack_158 = (code ******)DAT_0050b420;
            ppppppcStack_15c = (code ******)0x43d508;
            ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_160 = &local_34;
            ppppppcStack_164 = (code ******)0x43d515;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_164 = (code ******)0x0;
            ppppppcStack_16c = (code ******)0x43d522;
            ppppppcStack_168 = (code ******)pppppppcVar17;
            pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
            if ((int)pppppppcVar13 < 0) {
              ppppppcStack_16c = (code ******)0x8c;
              ppppppcStack_170 = (code ******)&DAT_0040bb6c;
              ppppppcStack_17c = (code ******)0x43d53a;
              ppppppcStack_178 = (code ******)pppppppcVar13;
              ppppppcStack_174 = (code ******)pppppppcVar17;
              __vbaHresultCheckObj();
            }
            ppppppcStack_16c = (code ******)0x43d545;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_16c = (code ******)&DAT_0050b420;
              ppppppcStack_170 = (code ******)&DAT_00408c88;
              ppppppcStack_174 = (code ******)0x43d55e;
              __vbaNew2();
            }
            ppppppcStack_16c = (code ******)DAT_0050b420;
            ppppppcStack_170 = (code ******)0x43d56c;
            ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_174 = &local_34;
            ppppppcStack_178 = (code ******)0x43d573;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_178 = (code ******)0x0;
            ppppppcStack_180 = (code ******)0x43d580;
            ppppppcStack_17c = (code ******)pppppppcVar17;
            ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x23])();
            if ((int)ppppppcVar8 < 0) {
              ppppppcStack_180 = (code ******)0x8c;
              ppppppcStack_184 = (code ******)&DAT_0040bb6c;
              ppppppcStack_190 = (code ******)0x43d598;
              pppppcStack_18c = (code *****)ppppppcVar8;
              ppppppcStack_188 = (code ******)pppppppcVar17;
              __vbaHresultCheckObj();
            }
            ppppppcStack_180 = (code ******)0x43d59d;
            __vbaFreeObj();
            goto LAB_0043d0ce;
          }
        }
      }
      else {
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_158 = (code ******)&DAT_0050b420;
          ppppppcStack_15c = (code ******)&DAT_00408c88;
          ppppppcStack_160 = (code ******)0x43d1dd;
          __vbaNew2();
        }
        ppppppcStack_158 = (code ******)DAT_0050b420;
        ppppppcStack_15c = (code ******)0x43d1eb;
        ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
        ppppppcStack_160 = (code ******)&local_ec;
        ppppppcStack_164 = (code ******)0x43d1f9;
        __vbaObjSet();
        pppppppcVar17 = (code *******)__vbaGenerateBoundsError_exref;
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          ppppppcStack_158 = (code ******)0x43d24a;
          iVar6 = __vbaGenerateBoundsError();
          pppppppcVar17 = (code *******)__vbaGenerateBoundsError_exref;
        }
        else {
          iVar6 = *(int *)(DAT_0050b1a4 + 0xe);
          if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar6) {
            ppppppcStack_158 = (code ******)0x43d222;
            __vbaGenerateBoundsError();
          }
          iVar5 = *(int *)(DAT_0050b1a4 + 10);
          if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)-iVar5) {
            ppppppcStack_158 = (code ******)0x43d236;
            __vbaGenerateBoundsError();
          }
          iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * -iVar5 + (1U - iVar6)) * 2;
        }
        unaff_ESI = (code *******)__vbaLateIdSt_exref;
        sVar3 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
        pppppppcVar16 = (code *******)&DAT_00000001;
        do {
          pppppppcVar13 = pppppppcVar16;
          sVar2 = (short)pppppppcVar13;
          if (sVar3 < sVar2) {
            ppppppcStack_15c = (code ******)&local_ec;
            ppppppcStack_158 = (code ******)0x0;
            ppppppcStack_160 = (code ******)0x43d4a8;
            __vbaObjSetAddref();
            goto LAB_0043d4a8;
          }
          if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
            ppppppcStack_158 = (code ******)0x43d2da;
            iVar6 = (*(code *)pppppppcVar17)();
          }
          else {
            local_dc = 1 - *(int *)(DAT_0050b1a4 + 0xe);
            if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_dc) {
              ppppppcStack_158 = (code ******)0x43d29f;
              (*(code *)pppppppcVar17)();
            }
            iVar6 = *(int *)(DAT_0050b1a4 + 10);
            if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(sVar2 - iVar6)) {
              ppppppcStack_158 = (code ******)0x43d2ba;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (sVar2 - iVar6) + local_dc) * 2;
            pppppppcVar17 = (code *******)__vbaGenerateBoundsError_exref;
          }
          ppppppcStack_15c = (code ******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
          local_84 = (code ******)0x3;
          ppppppcStack_164 = (code ******)0x3;
          ppppppcStack_168 = (code ******)0xa;
          ppppppcStack_160 = local_80;
          ppppppcStack_16c = local_ec;
          ppppppcStack_158 = local_78;
          ppppppcStack_170 = (code ******)0x43d313;
          local_7c = ppppppcStack_15c;
          __vbaLateIdSt();
          if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
            ppppppcStack_170 = (code ******)0x43d377;
            iVar6 = (*(code *)pppppppcVar17)();
          }
          else {
            local_dc = 2 - *(int *)(DAT_0050b1a4 + 0xe);
            if (*(uint *)(DAT_0050b1a4 + 0xc) <= local_dc) {
              ppppppcStack_170 = (code ******)0x43d33c;
              (*(code *)pppppppcVar17)();
            }
            iVar6 = *(int *)(DAT_0050b1a4 + 10);
            if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(sVar2 - iVar6)) {
              ppppppcStack_170 = (code ******)0x43d357;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (sVar2 - iVar6) + local_dc) * 2;
            pppppppcVar17 = (code *******)__vbaGenerateBoundsError_exref;
          }
          ppppppcStack_174 = (code ******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
          local_84 = (code ******)0x3;
          ppppppcStack_180 = (code ******)0xb;
          ppppppcStack_17c = (code ******)0x3;
          ppppppcStack_178 = local_80;
          ppppppcStack_184 = local_ec;
          ppppppcStack_170 = local_78;
          ppppppcStack_188 = (code ******)0x43d3b0;
          local_7c = ppppppcStack_174;
          __vbaLateIdSt();
          local_84 = (code ******)0x3;
          ppppppcStack_198 = (code ******)0x26;
          ppppppcStack_194 = (code ******)0x3;
          local_7c = (code ******)0xff00;
          ppppppcStack_190 = local_80;
          ppppppcStack_19c = local_ec;
          pppppcStack_18c = (code *****)0xff00;
          ppppppcStack_188 = local_78;
          ppppppcStack_1a0 = (code ******)0x43d3e1;
          __vbaLateIdSt();
          ppppppcStack_1a0 = (code ******)0x0;
          uStack_1a4 = 0xb;
          ppppppcStack_1ac = local_44;
          ppppppcStack_1a8 = local_ec;
          iStack_1b0 = 0x43d3f6;
          ppppppcStack_1a0 = (code ******)__vbaLateIdCallLd();
          uStack_1a4 = 0x43d400;
          iVar6 = __vbaI4Var();
          iVar5 = iVar6 + (short)DAT_0050b332;
          if (SCARRY4(iVar6,(int)(short)DAT_0050b332)) break;
          pppppppcVar16 = (code *******)(iVar5 + 1);
          local_84 = (code ******)0x3;
          if (SCARRY4(iVar5,1)) break;
          ppppppcStack_168 = (code ******)0xb;
          ppppppcStack_164 = (code ******)0x3;
          ppppppcStack_160 = local_80;
          ppppppcStack_16c = local_ec;
          ppppppcStack_158 = local_78;
          ppppppcStack_170 = (code ******)0x43d444;
          ppppppcStack_15c = (code ******)pppppppcVar16;
          local_7c = (code ******)pppppppcVar16;
          __vbaLateIdSt();
          ppppppcStack_170 = (code ******)0x43d44d;
          __vbaFreeVar();
          local_84 = (code ******)0x3;
          ppppppcStack_180 = (code ******)0x26;
          ppppppcStack_17c = (code ******)0x3;
          local_7c = (code ******)0xff00;
          ppppppcStack_178 = local_80;
          ppppppcStack_184 = local_ec;
          ppppppcStack_174 = (code ******)0xff00;
          ppppppcStack_170 = local_78;
          ppppppcStack_188 = (code ******)0x43d47e;
          __vbaLateIdSt();
          pppppppcVar16 = (code *******)(uint)(ushort)(sVar2 + 1);
        } while (!SCARRY2(sVar2,1));
      }
      break;
    case 4:
      ppppppcStack_158 = (code ******)0x43d5a7;
      FUN_004cf810();
      if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
        ppppppcStack_158 = (code ******)0x43d5fa;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        unaff_ESI = (code *******)-*(int *)(DAT_0050b19c + 0xe);
        if (*(code ********)(DAT_0050b19c + 0xc) <= unaff_ESI) {
          ppppppcStack_158 = (code ******)0x43d5c9;
          __vbaGenerateBoundsError();
        }
        pppppppcVar17 = (code *******)-*(int *)(DAT_0050b19c + 10);
        if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar17) {
          ppppppcStack_158 = (code ******)0x43d5e1;
          __vbaGenerateBoundsError();
        }
        iVar6 = (int)((int)unaff_ESI + *(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar17) * 4;
      }
      in_FPUStatusWord = 0;
      if (*(float *)(*(int *)(DAT_0050b19c + 6) + iVar6) <= _DAT_00401bc0) {
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_158 = (code ******)&DAT_0050b420;
          ppppppcStack_15c = (code ******)&DAT_00408c88;
          ppppppcStack_160 = (code ******)0x43d64e;
          __vbaNew2();
        }
        ppppppcStack_158 = (code ******)DAT_0050b420;
        ppppppcStack_15c = (code ******)0x43d65c;
        ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
        ppppppcStack_160 = &local_34;
        ppppppcStack_164 = (code ******)0x43d669;
        pppppppcVar17 = (code *******)__vbaObjSet();
        ppppppcStack_164 = (code ******)0x0;
        ppppppcStack_16c = (code ******)0x43d675;
        ppppppcStack_168 = (code ******)pppppppcVar17;
        pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
        if ((int)pppppppcVar13 < 0) {
          ppppppcStack_16c = (code ******)0x8c;
          ppppppcStack_170 = (code ******)&DAT_0040bb6c;
          ppppppcStack_17c = (code ******)0x43d68d;
          ppppppcStack_178 = (code ******)pppppppcVar13;
          ppppppcStack_174 = (code ******)pppppppcVar17;
          __vbaHresultCheckObj();
        }
        pppppppcVar13 = (code *******)__vbaFreeObj_exref;
        ppppppcStack_16c = (code ******)0x43d698;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_16c = (code ******)&DAT_0050b420;
          ppppppcStack_170 = (code ******)&DAT_00408c88;
          ppppppcStack_174 = (code ******)0x43d6b1;
          __vbaNew2();
        }
        ppppppcStack_16c = (code ******)DAT_0050b420;
        ppppppcStack_170 = (code ******)0x43d6bf;
        ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
        ppppppcStack_174 = &local_34;
        ppppppcStack_178 = (code ******)0x43d6c6;
        pppppppcVar17 = (code *******)__vbaObjSet();
        ppppppcStack_178 = (code ******)0x0;
        ppppppcStack_180 = (code ******)0x43d6d3;
        ppppppcStack_17c = (code ******)pppppppcVar17;
        ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x23])();
        in_FPUStatusWord = 0;
        if ((int)ppppppcVar8 < 0) {
          ppppppcStack_180 = (code ******)0x8c;
          ppppppcStack_184 = (code ******)&DAT_0040bb6c;
          ppppppcStack_190 = (code ******)0x43d6eb;
          pppppcStack_18c = (code *****)ppppppcVar8;
          ppppppcStack_188 = (code ******)pppppppcVar17;
          __vbaHresultCheckObj();
        }
        ppppppcStack_180 = (code ******)0x43d6f0;
        __vbaFreeObj();
        local_74[0] = (code *****)0xa;
        local_64[0] = (code *****)0xa;
        unaff_ESI = (code *******)0x8;
        local_6c = 0x80020004;
        local_5c = 0x80020004;
        local_7c = (code ******)0x40e084;
        local_84 = (code ******)0x8;
        ppppppcStack_180 = (code ******)0x43d721;
        __vbaVarDup();
        pppppcStack_154 = (code *****)0x40e014;
        ppppppcStack_158 = (code ******)CONCAT22(extraout_var_00,DAT_0050b244 + 1);
        if (!SCARRY2(DAT_0050b244,1)) {
          ppppppcStack_15c = (code ******)0x43d73e;
          __vbaStrI2();
          ppppppcStack_15c = (code ******)0x43d749;
          ppppppcStack_15c = (code ******)__vbaStrMove();
          ppppppcStack_160 = (code ******)0x43d750;
          local_3c = __vbaStrCat();
          ppppppcStack_160 = local_74;
          ppppppcStack_164 = local_64;
          ppppppcStack_168 = local_54;
          ppppppcStack_170 = local_44;
          ppppppcStack_16c = (code ******)0x40;
          local_44[0] = (code *****)0x8;
          ppppppcStack_174 = (code ******)0x43d76e;
          Ordinal_595();
          ppppppcStack_174 = (code ******)0x43d777;
          __vbaFreeStr();
          goto LAB_0043d134;
        }
      }
      else if (!SCARRY2(DAT_0050b244,1)) {
        _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
        ppppppcStack_158 = (code ******)0x43d630;
        FUN_004d02a0();
        goto switchD_0043c5df_caseD_5;
      }
    }
    break;
  case 8:
    if (!SCARRY2(DAT_0050b244,1)) {
      _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
      if (DAT_0050b3c0 != 1) goto switchD_0043c5df_caseD_5;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_158 = (code ******)&DAT_0050b420;
        ppppppcStack_15c = (code ******)&DAT_00408c88;
        ppppppcStack_160 = (code ******)0x43d7bb;
        __vbaNew2();
      }
      ppppppcStack_158 = (code ******)DAT_0050b420;
      ppppppcStack_15c = (code ******)0x43d7c9;
      ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      ppppppcStack_160 = (code ******)&local_f0;
      ppppppcStack_164 = (code ******)0x43d7d7;
      __vbaObjSet();
      pppppppcVar17 = _DAT_0050b244;
      if ((DAT_0050b3d4 == (short *)0x0) || (*DAT_0050b3d4 != 1)) {
        ppppppcStack_158 = (code ******)0x43d814;
        __vbaGenerateBoundsError();
      }
      else {
        unaff_ESI = (code *******)-*(int *)(DAT_0050b3d4 + 10);
        if (*(code ********)(DAT_0050b3d4 + 8) <= unaff_ESI) {
          ppppppcStack_158 = (code ******)0x43d7ff;
          __vbaGenerateBoundsError();
        }
      }
      if (!SCARRY2(DAT_0050b332,1)) {
        if ((in_FPUStatusWord & 0xd) != 0) {
          __vbaFPException();
          return;
        }
        ppppppcStack_158 = (code ******)0x43d85c;
        sVar3 = __vbaFpI2();
        if ((short)pppppppcVar17 <= sVar3) {
          ppppppcStack_158 = (code ******)0x43d866;
          FUN_004ebd90();
          goto switchD_0043c5df_caseD_5;
        }
        if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
          ppppppcStack_158 = (code ******)0x43d8a2;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          iVar6 = *(int *)(DAT_0050b3d8 + 10);
          pppppppcVar17 = (code *******)-iVar6;
          if (*(code ********)(DAT_0050b3d8 + 8) <= pppppppcVar17) {
            ppppppcStack_158 = (code ******)0x43d88d;
            __vbaGenerateBoundsError();
          }
          iVar6 = iVar6 * -4;
        }
        in_FPUStatusWord = 0;
        if (*(float *)(*(int *)(DAT_0050b3d8 + 6) + iVar6) == _DAT_00401bc0) {
          ppppppcStack_158 = (code ******)0x43d8c4;
          FUN_004ed5c0();
          pppppppcVar17 = (code *******)__vbaLateIdCallLd_exref;
          ppppppcStack_158 = (code ******)0x0;
          ppppppcStack_15c = (code ******)0x4;
          ppppppcStack_164 = local_54;
          ppppppcStack_160 = local_f0;
          ppppppcStack_168 = (code ******)0x43d8db;
          ppppppcStack_158 = (code ******)__vbaLateIdCallLd();
          pppppppcVar13 = (code *******)__vbaI4Var_exref;
          ppppppcStack_15c = (code ******)0x43d8e7;
          iVar6 = __vbaI4Var();
          pppppcStack_154 = (code *****)local_44;
          pppppppcVar16 = (code *******)(iVar6 + -2);
          unaff_ESI = pppppppcVar16;
          unaff_EDI = (code *******)local_f0;
          if (!SBORROW4(iVar6,2)) {
            ppppppcStack_158 = (code ******)0x43d903;
            __vbaLateIdCallLd();
            pppppppcVar7 = (code *******)__vbaI4Var();
            unaff_EDI = (code *******)local_44;
            pppppcStack_154 = (code *****)0x2;
            pppppppcVar17 =
                 (code *******)
                 CONCAT22((short)((uint)pppppppcVar17 >> 0x10),
                          -(ushort)(pppppppcVar7 == pppppppcVar16));
            ppppppcStack_158 = (code ******)0x43d925;
            __vbaFreeVarList();
            unaff_ESI = (code *******)__vbaLateIdSt_exref;
            if ((ushort)-(ushort)(pppppppcVar7 == pppppppcVar16) == 0) goto LAB_0043e0e9;
            ppppppcStack_158 = (code ******)0x0;
            ppppppcStack_15c = (code ******)0x4;
            ppppppcStack_164 = local_44;
            ppppppcStack_160 = local_f0;
            ppppppcStack_168 = (code ******)0x43d946;
            ppppppcStack_158 = (code ******)__vbaLateIdCallLd();
            ppppppcStack_15c = (code ******)0x43d94c;
            iVar6 = __vbaI4Var();
            pcVar14 = __vbaLateIdSt_exref;
            unaff_ESI = pppppppcVar16;
            if (!SBORROW4(iVar6,1)) {
              local_84 = (code ******)0x3;
              ppppppcStack_168 = (code ******)0xa;
              ppppppcStack_164 = (code ******)0x3;
              ppppppcStack_160 = local_80;
              ppppppcStack_16c = local_f0;
              ppppppcStack_158 = local_78;
              ppppppcStack_170 = (code ******)0x43d987;
              ppppppcStack_15c = (code ******)(iVar6 + -1);
              local_7c = (code ******)(iVar6 + -1);
              __vbaLateIdSt();
              ppppppcStack_170 = (code ******)0x43d990;
              __vbaFreeVar();
              pppppppcVar16 = (code *******)0x4;
              do {
                sVar3 = (short)pppppppcVar16;
                pppppppcVar17 = pppppppcVar16;
                unaff_ESI = (code *******)pcVar14;
                if (6 < sVar3) {
                  local_84 = (code ******)0x3;
                  ppppppcStack_168 = (code ******)0x30;
                  ppppppcStack_164 = (code ******)0x3;
                  local_7c = (code ******)0x2;
                  ppppppcStack_160 = local_80;
                  ppppppcStack_16c = local_f0;
                  ppppppcStack_15c = (code ******)0x2;
                  ppppppcStack_158 = local_78;
                  ppppppcStack_170 = (code ******)0x43dacb;
                  __vbaLateIdSt();
                  ppppppcStack_170 = (code ******)0x0;
                  ppppppcStack_174 = (code ******)0x4;
                  ppppppcStack_17c = local_44;
                  ppppppcStack_178 = local_f0;
                  ppppppcStack_180 = (code ******)0x43dae0;
                  ppppppcStack_170 = (code ******)__vbaLateIdCallLd();
                  ppppppcStack_174 = (code ******)0x43dae6;
                  iVar6 = (*(code *)pppppppcVar13)();
                  if (!SBORROW4(iVar6,1)) {
                    local_84 = (code ******)0x3;
                    ppppppcStack_164 = (code ******)0x3;
                    ppppppcStack_160 = local_80;
                    ppppppcStack_178 = (code ******)&DAT_00000001;
                    ppppppcStack_17c = (code ******)0x3b;
                    ppppppcStack_158 = local_78;
                    ppppppcStack_174 = (code ******)0xb;
                    ppppppcStack_170 = local_a0;
                    ppppppcStack_180 = local_f0;
                    ppppppcStack_16c = (code ******)0xffffffff;
                    ppppppcStack_168 = local_98;
                    ppppppcStack_184 = (code ******)0x43db45;
                    ppppppcStack_15c = (code ******)(iVar6 + -1);
                    local_7c = (code ******)(iVar6 + -1);
                    __vbaLateIdCallSt();
                    pppppppcVar17 = (code *******)__vbaFreeVar_exref;
                    ppppppcStack_158 = (code ******)0x43db53;
                    __vbaFreeVar();
                    if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
                      ppppppcStack_158 = (code ******)0x43db92;
                      iVar6 = __vbaGenerateBoundsError();
                    }
                    else {
                      local_d8 = -*(int *)(DAT_0050b3d8 + 10);
                      if (*(uint *)(DAT_0050b3d8 + 8) <= local_d8) {
                        ppppppcStack_158 = (code ******)0x43db7b;
                        __vbaGenerateBoundsError();
                      }
                      iVar6 = local_d8 << 2;
                    }
                    ppppppcStack_158 = (code ******)0x0;
                    ppppppcStack_15c = (code ******)0x4;
                    *(undefined4 *)(*(int *)(DAT_0050b3d8 + 6) + iVar6) = 0xc2c60000;
                    ppppppcStack_164 = local_44;
                    ppppppcStack_160 = local_f0;
                    ppppppcStack_168 = (code ******)0x43dbb7;
                    ppppppcStack_158 = (code ******)__vbaLateIdCallLd();
                    ppppppcStack_15c = (code ******)0x43dbbd;
                    iVar6 = (*(code *)pppppppcVar13)();
                    if (!SCARRY4(iVar6,1)) {
                      local_84 = (code ******)0x3;
                      ppppppcStack_168 = (code ******)0x4;
                      ppppppcStack_164 = (code ******)0x3;
                      ppppppcStack_160 = local_80;
                      ppppppcStack_16c = local_f0;
                      ppppppcStack_158 = local_78;
                      ppppppcStack_170 = (code ******)0x43dbf2;
                      ppppppcStack_15c = (code ******)(iVar6 + 1);
                      local_7c = (code ******)(iVar6 + 1);
                      __vbaLateIdSt();
                      ppppppcStack_170 = (code ******)0x43dbf7;
                      __vbaFreeVar();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43dc2e;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)-(int)DAT_0050b3bc[5];
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43dc19;
                          __vbaGenerateBoundsError();
                        }
                      }
                      pppppppcVar13 = (code *******)__vbaStrCopy_exref;
                      ppppppcStack_170 = (code ******)0x43dc46;
                      __vbaStrCopy();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43dc82;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)(1 - (int)DAT_0050b3bc[5]);
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43dc6d;
                          __vbaGenerateBoundsError();
                        }
                      }
                      ppppppcStack_170 = (code ******)0x43dc94;
                      __vbaStrCopy();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43dcd0;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)(2 - (int)DAT_0050b3bc[5]);
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43dcbb;
                          __vbaGenerateBoundsError();
                        }
                      }
                      ppppppcStack_170 = (code ******)0x43dce2;
                      __vbaStrCopy();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43dd1e;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)(3 - (int)DAT_0050b3bc[5]);
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43dd09;
                          __vbaGenerateBoundsError();
                        }
                      }
                      ppppppcStack_170 = (code ******)0x43dd30;
                      __vbaStrCopy();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43dd6c;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)(4 - (int)DAT_0050b3bc[5]);
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43dd57;
                          __vbaGenerateBoundsError();
                        }
                      }
                      ppppppcStack_170 = (code ******)0x43dd7e;
                      __vbaStrCopy();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43ddba;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)(5 - (int)DAT_0050b3bc[5]);
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43dda5;
                          __vbaGenerateBoundsError();
                        }
                      }
                      ppppppcStack_170 = (code ******)0x43ddcc;
                      __vbaStrCopy();
                      if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                        ppppppcStack_170 = (code ******)0x43de08;
                        __vbaGenerateBoundsError();
                      }
                      else {
                        pppppppcVar17 = (code *******)(6 - (int)DAT_0050b3bc[5]);
                        if (DAT_0050b3bc[4] <= pppppppcVar17) {
                          ppppppcStack_170 = (code ******)0x43ddf3;
                          __vbaGenerateBoundsError();
                        }
                      }
                      ppppppcStack_170 = (code ******)0x43de1a;
                      __vbaStrCopy();
                      ppppppcStack_170 = (code ******)0x0;
                      ppppppcStack_174 = (code ******)0x4;
                      ppppppcStack_17c = local_44;
                      ppppppcStack_178 = local_f0;
                      ppppppcStack_180 = (code ******)0x43de2f;
                      ppppppcStack_170 = (code ******)__vbaLateIdCallLd();
                      ppppppcStack_174 = (code ******)0x43de39;
                      iVar6 = __vbaI4Var();
                      if (!SBORROW4(iVar6,1)) {
                        local_84 = (code ******)0x3;
                        ppppppcStack_168 = (code ******)0xa;
                        ppppppcStack_164 = (code ******)0x3;
                        ppppppcStack_160 = local_80;
                        ppppppcStack_16c = local_f0;
                        ppppppcStack_158 = local_78;
                        ppppppcStack_170 = (code ******)0x43de6e;
                        ppppppcStack_15c = (code ******)(iVar6 + -1);
                        local_7c = (code ******)(iVar6 + -1);
                        __vbaLateIdSt();
                        ppppppcStack_170 = (code ******)0x43de77;
                        __vbaFreeVar();
                        pppppppcVar16 = (code *******)0x0;
                        goto LAB_0043de79;
                      }
                    }
                  }
                  break;
                }
                local_84 = (code ******)0x3;
                ppppppcStack_168 = (code ******)0xb;
                ppppppcStack_164 = (code ******)0x3;
                pppppppcVar13 = (code *******)(int)sVar3;
                ppppppcStack_160 = local_80;
                ppppppcStack_158 = local_78;
                ppppppcStack_16c = local_f0;
                ppppppcStack_170 = (code ******)0x43d9d2;
                ppppppcStack_15c = (code ******)pppppppcVar13;
                local_7c = (code ******)pppppppcVar13;
                __vbaLateIdSt();
                ppppppcStack_170 = (code ******)0x0;
                ppppppcStack_174 = (code ******)0x4;
                ppppppcStack_17c = local_44;
                ppppppcStack_178 = local_f0;
                ppppppcStack_180 = (code ******)0x43d9e7;
                ppppppcStack_170 = (code ******)__vbaLateIdCallLd();
                ppppppcStack_174 = (code ******)0x43d9f1;
                iVar6 = __vbaI4Var();
                if (SBORROW4(iVar6,1)) break;
                local_84 = (code ******)0x3;
                ppppppcStack_164 = (code ******)0x3;
                ppppppcStack_160 = local_80;
                ppppppcStack_158 = local_78;
                ppppppcStack_174 = (code ******)0x3;
                ppppppcStack_170 = local_a0;
                ppppppcStack_168 = local_98;
                ppppppcStack_188 = (code ******)0x2;
                ppppppcStack_184 = (code ******)0x8;
                pppppcStack_18c = (code *****)0x41;
                ppppppcStack_180 = local_c0;
                ppppppcStack_17c = (code ******)0x40e0a8;
                ppppppcStack_178 = local_b8;
                ppppppcStack_190 = local_f0;
                ppppppcStack_194 = (code ******)0x43da73;
                ppppppcStack_16c = (code ******)pppppppcVar13;
                ppppppcStack_15c = (code ******)(iVar6 + -1);
                local_7c = (code ******)(iVar6 + -1);
                __vbaLateIdCallSt();
                ppppppcStack_158 = (code ******)0x43da7f;
                __vbaFreeVar();
                pppppppcVar13 = (code *******)__vbaI4Var_exref;
                pppppppcVar16 = (code *******)(uint)(ushort)(sVar3 + 1);
              } while (!SCARRY2(sVar3,1));
            }
          }
        }
        else {
          ppppppcStack_158 = (code ******)0x43e0d5;
          FUN_004ede00();
          pppppppcVar13 = (code *******)__vbaI4Var_exref;
          unaff_ESI = (code *******)__vbaLateIdSt_exref;
LAB_0043e0e9:
          if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
            ppppppcStack_158 = (code ******)0x43e146;
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            local_dc = -*(int *)(DAT_0050b19c + 0xe);
            if (*(uint *)(DAT_0050b19c + 0xc) <= local_dc) {
              ppppppcStack_158 = (code ******)0x43e111;
              __vbaGenerateBoundsError();
            }
            pppppppcVar17 = (code *******)-*(int *)(DAT_0050b19c + 10);
            if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar17) {
              ppppppcStack_158 = (code ******)0x43e129;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar17 + local_dc) * 4;
          }
          in_FPUStatusWord = 0;
          if (*(float *)(*(int *)(DAT_0050b19c + 6) + iVar6) != (float)(int)(short)DAT_0050b3c4) {
LAB_0043e4cf:
            ppppppcStack_15c = (code ******)&local_f0;
            ppppppcStack_158 = (code ******)0x0;
            ppppppcStack_160 = (code ******)0x43e4de;
            __vbaObjSetAddref();
            goto switchD_0043c5df_caseD_5;
          }
          ppppppcStack_158 = (code ******)0x0;
          ppppppcStack_15c = (code ******)0x4;
          ppppppcStack_164 = local_44;
          ppppppcStack_160 = local_f0;
          ppppppcStack_168 = (code ******)0x43e191;
          ppppppcStack_158 = (code ******)__vbaLateIdCallLd();
          ppppppcStack_15c = (code ******)0x43e197;
          iVar6 = (*(code *)pppppppcVar13)();
          if (!SCARRY4(iVar6,1)) {
            local_84 = (code ******)0x3;
            ppppppcStack_168 = (code ******)0x4;
            ppppppcStack_164 = (code ******)0x3;
            ppppppcStack_160 = local_80;
            ppppppcStack_16c = local_f0;
            ppppppcStack_158 = local_78;
            ppppppcStack_170 = (code ******)0x43e1cc;
            ppppppcStack_15c = (code ******)(iVar6 + 1);
            local_7c = (code ******)(iVar6 + 1);
            (*(code *)unaff_ESI)();
            ppppppcStack_170 = (code ******)0x43e1d5;
            __vbaFreeVar();
            pppppppcVar16 = (code *******)0x0;
            do {
              sVar3 = (short)pppppppcVar16;
              pppppppcVar17 = pppppppcVar16;
              if (6 < sVar3) {
                local_84 = (code ******)0x3;
                ppppppcStack_168 = (code ******)0x30;
                ppppppcStack_164 = (code ******)0x3;
                local_7c = (code ******)0x2;
                ppppppcStack_160 = local_80;
                ppppppcStack_16c = local_f0;
                ppppppcStack_15c = (code ******)0x2;
                ppppppcStack_158 = local_78;
                ppppppcStack_170 = (code ******)0x43e2d7;
                (*(code *)unaff_ESI)();
                ppppppcStack_170 = (code ******)0x0;
                ppppppcStack_174 = (code ******)0x4;
                ppppppcStack_17c = local_44;
                ppppppcStack_178 = local_f0;
                ppppppcStack_180 = (code ******)0x43e2ec;
                ppppppcStack_170 = (code ******)__vbaLateIdCallLd();
                ppppppcStack_174 = (code ******)0x43e2f2;
                iVar6 = (*(code *)pppppppcVar13)();
                if (!SBORROW4(iVar6,1)) {
                  local_84 = (code ******)0x3;
                  ppppppcStack_164 = (code ******)0x3;
                  ppppppcStack_160 = local_80;
                  ppppppcStack_178 = (code ******)0x1;
                  ppppppcStack_17c = (code ******)0x3b;
                  ppppppcStack_158 = local_78;
                  ppppppcStack_174 = (code ******)0xb;
                  ppppppcStack_170 = local_a0;
                  ppppppcStack_180 = local_f0;
                  ppppppcStack_16c = (code ******)0xffffffff;
                  ppppppcStack_168 = local_98;
                  ppppppcStack_184 = (code ******)0x43e351;
                  ppppppcStack_15c = (code ******)(iVar6 + -1);
                  local_7c = (code ******)(iVar6 + -1);
                  __vbaLateIdCallSt();
                  ppppppcStack_158 = (code ******)0x43e35d;
                  __vbaFreeVar();
                  if (DAT_0050b420 == (code *******)0x0) {
                    ppppppcStack_158 = (code ******)&DAT_0050b420;
                    ppppppcStack_15c = (code ******)&DAT_00408c88;
                    ppppppcStack_160 = (code ******)0x43e376;
                    __vbaNew2();
                  }
                  ppppppcStack_158 = (code ******)DAT_0050b420;
                  ppppppcStack_15c = (code ******)0x43e384;
                  ppppppcStack_15c = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
                  ppppppcStack_160 = &local_34;
                  ppppppcStack_164 = (code ******)0x43e391;
                  pppppppcVar17 = (code *******)__vbaObjSet();
                  ppppppcStack_164 = (code ******)0x0;
                  ppppppcStack_16c = (code ******)0x43e39e;
                  ppppppcStack_168 = (code ******)pppppppcVar17;
                  iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
                  if (iVar6 < 0) {
                    ppppppcStack_16c = (code ******)0x8c;
                    ppppppcStack_170 = (code ******)&DAT_0040bb6c;
                    ppppppcStack_17c = (code ******)0x43e3b8;
                    ppppppcStack_178 = (code ******)iVar6;
                    ppppppcStack_174 = (code ******)pppppppcVar17;
                    __vbaHresultCheckObj();
                  }
                  ppppppcStack_16c = (code ******)0x43e3c9;
                  __vbaFreeObj();
                  if (DAT_0050b420 == (code *******)0x0) {
                    ppppppcStack_16c = (code ******)&DAT_0050b420;
                    ppppppcStack_170 = (code ******)&DAT_00408c88;
                    ppppppcStack_174 = (code ******)0x43e3e2;
                    __vbaNew2();
                  }
                  ppppppcStack_16c = (code ******)DAT_0050b420;
                  ppppppcStack_170 = (code ******)0x43e3f0;
                  ppppppcStack_170 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
                  ppppppcStack_174 = &local_34;
                  ppppppcStack_178 = (code ******)0x43e3f7;
                  pppppppcVar17 = (code *******)__vbaObjSet();
                  ppppppcStack_178 = (code ******)0x0;
                  ppppppcStack_180 = (code ******)0x43e404;
                  ppppppcStack_17c = (code ******)pppppppcVar17;
                  ppppppcVar8 = (code ******)(*(code *)(*pppppppcVar17)[0x23])();
                  if ((int)ppppppcVar8 < 0) {
                    ppppppcStack_180 = (code ******)0x8c;
                    ppppppcStack_184 = (code ******)&DAT_0040bb6c;
                    ppppppcStack_190 = (code ******)0x43e418;
                    pppppcStack_18c = (code *****)ppppppcVar8;
                    ppppppcStack_188 = (code ******)pppppppcVar17;
                    __vbaHresultCheckObj();
                  }
                  ppppppcStack_180 = (code ******)0x43e421;
                  __vbaFreeObj();
                  if (DAT_0050b420 == (code *******)0x0) {
                    ppppppcStack_180 = (code ******)&DAT_0050b420;
                    ppppppcStack_184 = (code ******)&DAT_00408c88;
                    ppppppcStack_188 = (code ******)0x43e43a;
                    __vbaNew2();
                  }
                  ppppppcStack_180 = (code ******)DAT_0050b420;
                  ppppppcStack_184 = (code ******)0x43e448;
                  ppppppcStack_184 = (code ******)(*(code *)(*DAT_0050b420)[0xde])();
                  ppppppcStack_188 = &local_34;
                  pppppcStack_18c = (code *****)0x43e44f;
                  pppppppcVar17 = (code *******)__vbaObjSet();
                  pppppcStack_18c = (code *****)0xffffffff;
                  ppppppcStack_194 = (code ******)0x43e45c;
                  ppppppcStack_190 = (code ******)pppppppcVar17;
                  pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
                  if ((int)pppppppcVar13 < 0) {
                    ppppppcStack_194 = (code ******)0x8c;
                    ppppppcStack_198 = (code ******)&DAT_0040bb6c;
                    uStack_1a4 = 0x43e470;
                    ppppppcStack_1a0 = (code ******)pppppppcVar13;
                    ppppppcStack_19c = (code ******)pppppppcVar17;
                    __vbaHresultCheckObj();
                  }
                  ppppppcStack_194 = (code ******)0x43e479;
                  __vbaFreeObj();
                  if (DAT_0050b420 == (code *******)0x0) {
                    ppppppcStack_194 = (code ******)&DAT_0050b420;
                    ppppppcStack_198 = (code ******)&DAT_00408c88;
                    ppppppcStack_19c = (code ******)0x43e492;
                    __vbaNew2();
                  }
                  ppppppcStack_194 = (code ******)DAT_0050b420;
                  ppppppcStack_198 = (code ******)0x43e4a0;
                  ppppppcStack_198 = (code ******)(*(code *)(*DAT_0050b420)[0xde])();
                  ppppppcStack_19c = &local_34;
                  ppppppcStack_1a0 = (code ******)0x43e4a7;
                  pppppppcVar17 = (code *******)__vbaObjSet();
                  uStack_1a4 = 0x43e4b2;
                  ppppppcStack_1a0 = (code ******)pppppppcVar17;
                  iVar6 = (*(code *)(*pppppppcVar17)[0x69])();
                  if (iVar6 < 0) {
                    uStack_1a4 = 0x1a4;
                    ppppppcStack_1a8 = (code ******)&DAT_0040bb6c;
                    ppppppcStack_1b4 = (code ******)0x43e4c6;
                    iStack_1b0 = iVar6;
                    ppppppcStack_1ac = (code ******)pppppppcVar17;
                    __vbaHresultCheckObj();
                  }
                  uStack_1a4 = 0x43e4cf;
                  __vbaFreeObj();
                  goto LAB_0043e4cf;
                }
                break;
              }
              ppppppcStack_158 = (code ******)0x0;
              ppppppcStack_15c = (code ******)0x4;
              ppppppcStack_164 = local_44;
              ppppppcStack_160 = local_f0;
              ppppppcStack_168 = (code ******)0x43e1fa;
              ppppppcStack_158 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_15c = (code ******)0x43e200;
              iVar6 = (*(code *)pppppppcVar13)();
              if (SBORROW4(iVar6,1)) break;
              local_84 = (code ******)0x3;
              ppppppcStack_164 = (code ******)0x3;
              ppppppcStack_160 = local_80;
              ppppppcStack_158 = local_78;
              ppppppcStack_174 = (code ******)0x3;
              ppppppcStack_16c = (code ******)(int)sVar3;
              ppppppcStack_170 = local_a0;
              ppppppcStack_168 = local_98;
              ppppppcStack_188 = (code ******)0x2;
              ppppppcStack_184 = (code ******)0x8;
              pppppcStack_18c = (code *****)0x41;
              ppppppcStack_180 = local_c0;
              ppppppcStack_17c = (code ******)0x40e168;
              ppppppcStack_178 = local_b8;
              ppppppcStack_190 = local_f0;
              ppppppcStack_194 = (code ******)0x43e285;
              ppppppcStack_15c = (code ******)(iVar6 + -1);
              local_7c = (code ******)(iVar6 + -1);
              __vbaLateIdCallSt();
              ppppppcStack_158 = (code ******)0x43e291;
              __vbaFreeVar();
              pppppppcVar16 = (code *******)(uint)(ushort)(sVar3 + 1);
            } while (!SCARRY2(sVar3,1));
          }
        }
      }
    }
  }
LAB_0043e59d:
  ppppppcStack_158 = (code ******)0x43e5a3;
  __vbaErrorOverflow();
  ppppppcStack_168 = (code ******)&DAT_00402706;
  ppppppcStack_16c = ExceptionList;
  ppppppcStack_164 = (code ******)&ppppppcStack_2c8;
  ppppppcStack_160 = (code ******)&DAT_00401bd8;
  ppppppcStack_15c = (code ******)((uint)unaff_EDI & 1);
  ppppppcStack_2cc = (code ******)((uint)unaff_EDI & 0xfffffffe);
  ppppppcStack_2d0 = (code ******)0x43e5f2;
  ExceptionList = &ppppppcStack_16c;
  ppppppcStack_2c8 = (code ******)pppppppcVar17;
  ppppppcStack_2c4 = (code ******)unaff_ESI;
  ppppppcStack_2c0 = (code ******)pppppppcVar13;
  ppppppcStack_158 = (code ******)&stack0xfffffffc;
  (*(code *)(*ppppppcStack_2cc)[1])();
  pcVar18 = __vbaFreeObj_exref;
  pppppppcVar7 = (code *******)__vbaLateIdSt_exref;
  pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
  pcVar14 = __vbaObjSet_exref;
  _DAT_0050b20e = 2;
  ppppppcStack_184 = (code ******)0x0;
  ppppppcStack_188 = (code ******)0x0;
  pppppcStack_18c = (code *****)0x0;
  ppppppcStack_19c = (code ******)0x0;
  ppppppcStack_1ac = (code ******)0x0;
  pppppcStack_1bc = (code *****)0x0;
  ppppppcStack_1cc = (code ******)0x0;
  ppppppcStack_1dc = (code ******)0x0;
  ppppppcStack_1ec = (code ******)0x0;
  ppppppcStack_1fc = (code ******)0x0;
  uStack_21c = 0;
  appppppcStack_240[0] = (code ******)0x0;
  ppppppcStack_244 = (code ******)0x0;
  ppppppcStack_248 = (code ******)0x0;
  switch(DAT_0050b238) {
  case 3:
    do {
      sVar3 = DAT_0050b29a + 1;
      ppppppcStack_1dc = (code ******)0x3;
      pppppppcVar16 = (code *******)pcVar14;
      pppppppcVar17 = (code *******)pcVar18;
      if (((SCARRY2(DAT_0050b29a,1)) || (DAT_0050b29a = sVar3, SCARRY2(DAT_0050b20c,7))) ||
         ((iVar6 = (int)(short)(DAT_0050b20c + 7) * (int)sVar3, sVar3 = (short)iVar6, sVar3 != iVar6
          || (DAT_0050b298 = sVar3, SCARRY2(DAT_0050b276,sVar3))))) goto LAB_00440949;
      ppppppcStack_1d4 = (code ******)(int)(short)(DAT_0050b276 + sVar3);
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2d0 = (code ******)&DAT_0050b420;
        ppppppcStack_2d4 = (code ******)&DAT_00408c88;
        ppppppcStack_2d8 = (code ******)0x43e6d9;
        __vbaNew2();
      }
      ppppppcStack_2e0 = (code ******)0x4;
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2dc = ppppppcStack_1dc;
      ppppppcStack_2d8 = ppppppcStack_1d8;
      ppppppcStack_2d4 = ppppppcStack_1d4;
      ppppppcStack_2d0 = ppppppcStack_1d0;
      ppppppcStack_2e8 = (code ******)0x43e708;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43e70f;
      ppppppcStack_2f0 = (code ******)__vbaObjSet();
      ppppppcStack_2f4 = (code ******)0x43e712;
      __vbaLateIdSt();
      ppppppcStack_2f4 = (code ******)0x43e717;
      __vbaFreeObj();
      if (SCARRY2(DAT_0050b244,1)) goto LAB_00440949;
      _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
      if ((short)DAT_0050b260 == -0x56ce) {
        ppppppcStack_2d0 = (code ******)0x43e73d;
        FUN_00481f60();
      }
      else {
        ppppppcStack_2d0 = (code ******)0x43e74b;
        sVar3 = __vbaI2Abs();
        sVar2 = (short)((int)sVar3 * (int)DAT_0050b25e);
        if ((int)sVar2 != (int)sVar3 * (int)DAT_0050b25e) goto LAB_00440949;
        if ((sVar2 < 1) && (DAT_0050b240 != -2)) {
          if (DAT_0050b25e == 0) {
            ppppppcStack_1cc = (code ******)0xa;
            pppppcStack_1bc = (code *****)0xa;
            ppppppcStack_1c4 = (code ******)0x80020004;
            ppppppcStack_1b4 = (code ******)0x80020004;
            ppppppcStack_1e4 = (code ******)0x40df04;
            ppppppcStack_1ec = (code ******)0x8;
            ppppppcStack_2d0 = (code ******)0x43e807;
            __vbaVarDup();
            ppppppcStack_1d4 = (code ******)0x40e1bc;
            ppppppcStack_1dc = (code ******)0x8;
            ppppppcStack_2d0 = (code ******)0x43e81f;
            __vbaVarDup();
            ppppppcStack_2d0 = (code ******)&ppppppcStack_1cc;
            ppppppcStack_2d4 = &pppppcStack_1bc;
            ppppppcStack_2d8 = (code ******)&ppppppcStack_1ac;
            ppppppcStack_2e0 = (code ******)&ppppppcStack_19c;
            ppppppcStack_2dc = (code ******)0x40;
            ppppppcStack_2e4 = (code ******)0x43e837;
            Ordinal_595();
            ppppppcStack_2e4 = (code ******)&ppppppcStack_1cc;
            ppppppcStack_2e8 = &pppppcStack_1bc;
            ppppppcStack_2ec = (code ******)&ppppppcStack_1ac;
            ppppppcStack_2f0 = (code ******)&ppppppcStack_19c;
            ppppppcStack_2f4 = (code ******)0x4;
            ppppppcStack_2f8 = (code ******)0x43e84f;
            __vbaFreeVarList();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2e4 = (code ******)&DAT_0050b420;
              ppppppcStack_2e8 = (code ******)&DAT_00408c88;
              ppppppcStack_2ec = (code ******)0x43e86b;
              __vbaNew2();
            }
            ppppppcStack_2e4 = (code ******)DAT_0050b420;
            ppppppcStack_2e8 = (code ******)0x43e879;
            ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_2ec = &pppppcStack_18c;
            ppppppcStack_2f0 = (code ******)0x43e880;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_2f0 = (code ******)0x0;
            ppppppcStack_2f8 = (code ******)0x43e88d;
            ppppppcStack_2f4 = (code ******)pppppppcVar17;
            iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
            if (iVar6 < 0) {
              ppppppcStack_2f8 = (code ******)0x8c;
              ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
              ppppppcStack_308 = (code ******)0x43e8a5;
              ppppppcStack_304 = (code ******)iVar6;
              ppppppcStack_300 = (code ******)pppppppcVar17;
              __vbaHresultCheckObj();
            }
            ppppppcStack_2f8 = (code ******)0x43e8b0;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2f8 = (code ******)&DAT_0050b420;
              ppppppcStack_2fc = (code ******)&DAT_00408c88;
              ppppppcStack_300 = (code ******)0x43e8c9;
              __vbaNew2();
            }
            ppppppcStack_2f8 = (code ******)DAT_0050b420;
            ppppppcStack_2fc = (code ******)0x43e8d7;
            ppppppcStack_2fc = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_300 = &pppppcStack_18c;
            ppppppcStack_304 = (code ******)0x43e8de;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_304 = (code ******)0x0;
            ppppppcStack_30c = (code ******)0x43e8eb;
            ppppppcStack_308 = (code ******)pppppppcVar17;
            iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
            if (iVar6 < 0) {
              ppppppcStack_30c = (code ******)0x8c;
              __vbaHresultCheckObj(iVar6,pppppppcVar17,&DAT_0040bb6c);
            }
            ppppppcStack_30c = (code ******)0x43e908;
            __vbaFreeObj();
            break;
          }
          if ((short)DAT_0050b260 == 0) {
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2d0 = (code ******)&DAT_0050b420;
              ppppppcStack_2d4 = (code ******)&DAT_00408c88;
              ppppppcStack_2d8 = (code ******)0x43e926;
              __vbaNew2();
            }
            ppppppcStack_2d0 = (code ******)DAT_0050b420;
            ppppppcStack_2d4 = (code ******)0x43e934;
            ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
            ppppppcStack_2d8 = (code ******)appppppcStack_240;
            ppppppcStack_2dc = (code ******)0x43e93e;
            __vbaObjSet();
            ppppppcStack_2dc = (code ******)0x43e94b;
            sVar3 = __vbaI2Abs();
            ppppppcStack_1dc = (code ******)0x3;
            ppppppcStack_2e0 = (code ******)(int)sVar3;
            ppppppcStack_2e8 = (code ******)0x3;
            ppppppcStack_2ec = (code ******)0xb;
            ppppppcStack_2e4 = ppppppcStack_1d8;
            ppppppcStack_2f0 = appppppcStack_240[0];
            ppppppcStack_2dc = ppppppcStack_1d0;
            ppppppcStack_2f4 = (code ******)0x43e97d;
            ppppppcStack_1d4 = ppppppcStack_2e0;
            __vbaLateIdSt();
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_2d0 = (code ******)0x43e9d9;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              pcVar18 = (code *)(1 - *(int *)(DAT_0050b1a4 + 0xe));
              if (*(code **)(DAT_0050b1a4 + 0xc) <= pcVar18) {
                ppppppcStack_2d0 = (code ******)0x43e9a4;
                __vbaGenerateBoundsError();
              }
              pppppppcVar7 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
              if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar7) {
                ppppppcStack_2d0 = (code ******)0x43e9c1;
                __vbaGenerateBoundsError();
              }
              iVar6 = (int)(pcVar18 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar7) * 2;
            }
            pppppppcVar16 = (code *******)&DAT_00000001;
            uVar15 = (undefined2)((uint)pcVar18 >> 0x10);
            sVar3 = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6) + DAT_0050b20c;
            pppppppcVar17 = (code *******)CONCAT22(uVar15,sVar3);
            if (SCARRY2(*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6),DAT_0050b20c))
            goto LAB_00440949;
            pppppppcVar17 = (code *******)CONCAT22(uVar15,sVar3 + 5);
            if (SCARRY2(sVar3,5)) goto LAB_00440949;
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_2d0 = (code ******)0x43ea5f;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              uStack_234 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= uStack_234) {
                ppppppcStack_2d0 = (code ******)0x43ea26;
                __vbaGenerateBoundsError();
              }
              pppppppcVar7 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 10));
              if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar7) {
                ppppppcStack_2d0 = (code ******)0x43ea43;
                __vbaGenerateBoundsError();
              }
              iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar7 + uStack_234) * 2;
            }
            pppppppcVar13 =
                 (code *******)
                 CONCAT22((short)((uint)pppppppcVar7 >> 0x10),
                          *(undefined2 *)(*(int *)(DAT_0050b1a4 + 6) + iVar6));
            goto LAB_0043ea6c;
          }
        }
        else {
          ppppppcStack_2d0 = (code ******)0x43e78e;
          DAT_0050b240 = __vbaI2Abs();
          if (DAT_0050b274 == 5) {
            ppppppcStack_2d0 = (code ******)0x43e7aa;
            FUN_00482b00();
          }
          else {
            ppppppcStack_2d0 = (code ******)0x43e7a3;
            FUN_00481f60();
          }
        }
      }
    } while ((DAT_0050b240 == -2) || (DAT_0050b25e != 0));
    break;
  case 4:
    if (DAT_0050b420 == (code *******)0x0) {
      ppppppcStack_2d0 = (code ******)&DAT_0050b420;
      ppppppcStack_2d4 = (code ******)&DAT_00408c88;
      ppppppcStack_2d8 = (code ******)0x43ecc1;
      __vbaNew2();
    }
    ppppppcStack_2d0 = (code ******)DAT_0050b420;
    ppppppcStack_2d4 = (code ******)0x43eccf;
    ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xcf])();
    pppppppcVar17 = (code *******)__vbaObjSet_exref;
    ppppppcStack_2d8 = &pppppcStack_18c;
    ppppppcStack_2dc = (code ******)0x43ecdc;
    pppppppcVar13 = (code *******)__vbaObjSet();
    ppppppcStack_2dc = (code ******)0x0;
    ppppppcStack_2e4 = (code ******)0x43ece9;
    ppppppcStack_2e0 = (code ******)pppppppcVar13;
    pppppppcVar16 = (code *******)(*(code *)(*pppppppcVar13)[0x25])();
    if ((int)pppppppcVar16 < 0) {
      ppppppcStack_2e4 = (code ******)0x94;
      ppppppcStack_2e8 = (code ******)&DAT_0040c3dc;
      ppppppcStack_2f4 = (code ******)0x43ed01;
      ppppppcStack_2f0 = (code ******)pppppppcVar16;
      ppppppcStack_2ec = (code ******)pppppppcVar13;
      __vbaHresultCheckObj();
    }
    pppppppcVar16 = (code *******)__vbaFreeObj_exref;
    ppppppcStack_2e4 = (code ******)0x43ed0c;
    __vbaFreeObj();
    if (DAT_0050b420 == (code *******)0x0) {
      ppppppcStack_2e4 = (code ******)&DAT_0050b420;
      ppppppcStack_2e8 = (code ******)&DAT_00408c88;
      ppppppcStack_2ec = (code ******)0x43ed25;
      __vbaNew2();
    }
    ppppppcStack_2e4 = (code ******)DAT_0050b420;
    ppppppcStack_2e8 = (code ******)0x43ed33;
    ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xd0])();
    ppppppcStack_2ec = &pppppcStack_18c;
    ppppppcStack_2f0 = (code ******)0x43ed3a;
    pppppppcVar13 = (code *******)__vbaObjSet();
    ppppppcStack_2f0 = (code ******)0x0;
    ppppppcStack_2f8 = (code ******)0x43ed47;
    ppppppcStack_2f4 = (code ******)pppppppcVar13;
    iVar6 = (*(code *)(*pppppppcVar13)[0x25])();
    if (iVar6 < 0) {
      ppppppcStack_2f8 = (code ******)0x94;
      ppppppcStack_2fc = (code ******)&DAT_0040dc58;
      ppppppcStack_308 = (code ******)0x43ed5f;
      ppppppcStack_304 = (code ******)iVar6;
      ppppppcStack_300 = (code ******)pppppppcVar13;
      __vbaHresultCheckObj();
    }
    ppppppcStack_2f8 = (code ******)0x43ed64;
    __vbaFreeObj();
    pppppppcVar7 = (code *******)__vbaLateIdSt_exref;
    do {
      sVar3 = DAT_0050b244;
      sVar2 = DAT_0050b244 + 1;
      if ((SCARRY2(DAT_0050b244,1)) ||
         (sVar11 = (short)(DAT_0050b2c4 * 3), (int)sVar11 != DAT_0050b2c4 * 3)) goto LAB_00440949;
      sVar12 = sVar11 + 4;
      _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,sVar2);
      if (SCARRY2(sVar11,4)) goto LAB_00440949;
      sVar11 = DAT_0050b298 + sVar12;
      ppppppcStack_1dc = (code ******)0x3;
      if (((SCARRY2(DAT_0050b298,sVar12)) || (DAT_0050b298 = sVar11, SCARRY2(sVar2,1))) ||
         (iVar6 = (int)(short)(sVar3 + 2) * (int)sVar12, sVar3 = (short)iVar6, sVar3 != iVar6))
      goto LAB_00440949;
      ppppppcStack_1d4 = (code ******)(int)sVar3;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2d0 = (code ******)&DAT_0050b420;
        ppppppcStack_2d4 = (code ******)&DAT_00408c88;
        ppppppcStack_2d8 = (code ******)0x43edef;
        __vbaNew2();
      }
      ppppppcStack_2e0 = (code ******)0x4;
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2dc = ppppppcStack_1dc;
      ppppppcStack_2d8 = ppppppcStack_1d8;
      ppppppcStack_2d4 = ppppppcStack_1d4;
      ppppppcStack_2d0 = ppppppcStack_1d0;
      ppppppcStack_2e8 = (code ******)0x43ee1e;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43ee25;
      ppppppcStack_2f0 = (code ******)__vbaObjSet();
      ppppppcStack_2f4 = (code ******)0x43ee28;
      __vbaLateIdSt();
      ppppppcStack_2f4 = (code ******)0x43ee2d;
      __vbaFreeObj();
      ppppppcStack_2d0 = (code ******)0x43ee32;
      FUN_004b8890();
    } while (DAT_0050b25e != 0);
    break;
  case 7:
    switch(DAT_0050b334) {
    case 1:
      pppppppcVar16 = (code *******)&DAT_00000001;
      sVar3 = DAT_0050b332 - 1;
      pppppppcVar7 = (code *******)CONCAT22((short)((uint)unaff_ESI >> 0x10),sVar3);
      DAT_0050b33a = 0;
      if (!SBORROW2(DAT_0050b332,1)) {
        pppppppcVar13 = (code *******)&DAT_00000001;
        do {
          pppppppcVar17 = pppppppcVar13;
          sVar2 = (short)pppppppcVar17;
          if (sVar3 < sVar2) {
            ppppppcStack_1cc = (code ******)0xa;
            pppppcStack_1bc = (code *****)0xa;
            ppppppcStack_1c4 = (code ******)0x80020004;
            ppppppcStack_1b4 = (code ******)0x80020004;
            ppppppcStack_1e4 = (code ******)0x40dfac;
            ppppppcStack_1ec = (code ******)0x8;
            ppppppcStack_2d0 = (code ******)0x43ef90;
            __vbaVarDup();
            ppppppcStack_1d4 = (code ******)0x40df54;
            ppppppcStack_1dc = (code ******)0x8;
            ppppppcStack_2d0 = (code ******)0x43efa8;
            __vbaVarDup();
            ppppppcStack_2d0 = (code ******)&ppppppcStack_1cc;
            ppppppcStack_2d4 = &pppppcStack_1bc;
            ppppppcStack_2d8 = (code ******)&ppppppcStack_1ac;
            ppppppcStack_2e0 = (code ******)&ppppppcStack_19c;
            ppppppcStack_2dc = (code ******)0x40;
            ppppppcStack_2e4 = (code ******)0x43efc0;
            Ordinal_595();
            ppppppcStack_2e4 = (code ******)&ppppppcStack_1cc;
            ppppppcStack_2e8 = &pppppcStack_1bc;
            ppppppcStack_2ec = (code ******)&ppppppcStack_1ac;
            ppppppcStack_2f0 = (code ******)&ppppppcStack_19c;
            ppppppcStack_2f4 = (code ******)0x4;
            ppppppcStack_2f8 = (code ******)0x43efd8;
            __vbaFreeVarList();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2e4 = (code ******)&DAT_0050b420;
              ppppppcStack_2e8 = (code ******)&DAT_00408c88;
              ppppppcStack_2ec = (code ******)0x43eff4;
              __vbaNew2();
            }
            ppppppcStack_2e4 = (code ******)DAT_0050b420;
            ppppppcStack_2e8 = (code ******)0x43f002;
            ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_2ec = &pppppcStack_18c;
            ppppppcStack_2f0 = (code ******)0x43f00f;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_2f0 = (code ******)0x0;
            ppppppcStack_2f8 = (code ******)0x43f01c;
            ppppppcStack_2f4 = (code ******)pppppppcVar17;
            iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
            if (iVar6 < 0) {
              ppppppcStack_2f8 = (code ******)0x8c;
              ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
              ppppppcStack_308 = (code ******)0x43f034;
              ppppppcStack_304 = (code ******)iVar6;
              ppppppcStack_300 = (code ******)pppppppcVar17;
              __vbaHresultCheckObj();
            }
            pcVar14 = __vbaFreeObj_exref;
            ppppppcStack_2f8 = (code ******)0x43f03f;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2f8 = (code ******)&DAT_0050b420;
              ppppppcStack_2fc = (code ******)&DAT_00408c88;
              ppppppcStack_300 = (code ******)0x43f058;
              __vbaNew2();
            }
            ppppppcStack_2f8 = (code ******)DAT_0050b420;
            ppppppcStack_2fc = (code ******)0x43f066;
            ppppppcStack_2fc = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_300 = &pppppcStack_18c;
            ppppppcStack_304 = (code ******)0x43f06d;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_304 = (code ******)0x0;
            ppppppcStack_30c = (code ******)0x43f07a;
            ppppppcStack_308 = (code ******)pppppppcVar17;
            iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
joined_r0x0043f430:
            if (iVar6 < 0) {
LAB_0043f080:
              ppppppcStack_2f8 = (code ******)0x8c;
              ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
              ppppppcStack_308 = (code ******)0x43f092;
              ppppppcStack_304 = (code ******)iVar6;
              ppppppcStack_300 = (code ******)pppppppcVar17;
              __vbaHresultCheckObj();
            }
LAB_0043f092:
            ppppppcStack_2f8 = (code ******)0x43f097;
            (*pcVar14)();
            goto switchD_0043e64f_caseD_5;
          }
          ppppppcStack_2d0 = (code ******)0x43ee8c;
          FUN_004bea60();
          if (DAT_0050b33a == 0) {
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2d0 = (code ******)&DAT_0050b420;
              ppppppcStack_2d4 = (code ******)&DAT_00408c88;
              ppppppcStack_2d8 = (code ******)0x43eebf;
              __vbaNew2();
            }
            ppppppcStack_2d0 = (code ******)DAT_0050b420;
            ppppppcStack_2d4 = (code ******)0x43eecd;
            ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
            ppppppcStack_2d8 = &pppppcStack_18c;
            ppppppcStack_2dc = (code ******)0x43eeda;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_2dc = (code ******)0x0;
            ppppppcStack_2e4 = (code ******)0x43eee7;
            ppppppcStack_2e0 = (code ******)pppppppcVar17;
            pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
            if ((int)pppppppcVar13 < 0) {
              ppppppcStack_2e4 = (code ******)0x8c;
              ppppppcStack_2e8 = (code ******)&DAT_0040bb6c;
              ppppppcStack_2f4 = (code ******)0x43eeff;
              ppppppcStack_2f0 = (code ******)pppppppcVar13;
              ppppppcStack_2ec = (code ******)pppppppcVar17;
              __vbaHresultCheckObj();
            }
            pcVar14 = __vbaFreeObj_exref;
            ppppppcStack_2e4 = (code ******)0x43ef0a;
            __vbaFreeObj();
            if (DAT_0050b420 == (code *******)0x0) {
              ppppppcStack_2e4 = (code ******)&DAT_0050b420;
              ppppppcStack_2e8 = (code ******)&DAT_00408c88;
              ppppppcStack_2ec = (code ******)0x43ef23;
              __vbaNew2();
            }
            ppppppcStack_2e4 = (code ******)DAT_0050b420;
            ppppppcStack_2e8 = (code ******)0x43ef31;
            ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
            ppppppcStack_2ec = &pppppcStack_18c;
            ppppppcStack_2f0 = (code ******)0x43ef38;
            pppppppcVar17 = (code *******)__vbaObjSet();
            ppppppcStack_2f0 = (code ******)0x0;
            ppppppcStack_2f8 = (code ******)0x43ef45;
            ppppppcStack_2f4 = (code ******)pppppppcVar17;
            iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
            if (-1 < iVar6) goto LAB_0043f092;
            goto LAB_0043f080;
          }
          pppppppcVar13 = (code *******)CONCAT22(extraout_var,sVar2 + 1);
        } while (!SCARRY2(sVar2,1));
      }
      break;
    case 2:
      ppppppcStack_1d4 = (code ******)&DAT_00000001;
      ppppppcStack_1dc = (code ******)0x3;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2d0 = (code ******)&DAT_0050b420;
        ppppppcStack_2d4 = (code ******)&DAT_00408c88;
        ppppppcStack_2d8 = (code ******)0x43f0c6;
        __vbaNew2();
      }
      ppppppcStack_2e0 = (code ******)0x4;
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2dc = ppppppcStack_1dc;
      ppppppcStack_2d8 = ppppppcStack_1d8;
      ppppppcStack_2d4 = ppppppcStack_1d4;
      ppppppcStack_2d0 = ppppppcStack_1d0;
      ppppppcStack_2e8 = (code ******)0x43f0f5;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      pppppppcVar17 = (code *******)__vbaObjSet_exref;
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43f102;
      ppppppcStack_2f0 = (code ******)__vbaObjSet();
      ppppppcStack_2f4 = (code ******)0x43f10b;
      __vbaLateIdSt();
      ppppppcStack_2f4 = (code ******)0x43f116;
      __vbaFreeObj();
      ppppppcStack_1d4 = (code ******)0x4;
      ppppppcStack_1dc = (code ******)0x3;
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2f4 = (code ******)&DAT_0050b420;
        ppppppcStack_2f8 = (code ******)&DAT_00408c88;
        ppppppcStack_2fc = (code ******)0x43f140;
        __vbaNew2();
      }
      ppppppcStack_304 = (code ******)0x5;
      ppppppcStack_308 = (code ******)DAT_0050b420;
      ppppppcStack_300 = ppppppcStack_1dc;
      ppppppcStack_2fc = ppppppcStack_1d8;
      ppppppcStack_2f8 = ppppppcStack_1d4;
      ppppppcStack_2f4 = ppppppcStack_1d0;
      ppppppcStack_30c = (code ******)0x43f16f;
      ppppppcStack_30c = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
      uVar10 = __vbaObjSet(&pppppcStack_18c);
      __vbaLateIdSt(uVar10);
      __vbaFreeObj();
      pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
      DAT_0050b33c = 1;
      if ((DAT_0050b1a8 == (short *)0x0) || (*DAT_0050b1a8 != 1)) {
        ppppppcStack_2d0 = (code ******)0x43f1c3;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        iVar6 = *(int *)(DAT_0050b1a8 + 10);
        if (*(uint *)(DAT_0050b1a8 + 8) <= 1U - iVar6) {
          ppppppcStack_2d0 = (code ******)0x43f1b0;
          __vbaGenerateBoundsError();
        }
        iVar6 = (1U - iVar6) * 2;
      }
      *(undefined2 *)(*(int *)(DAT_0050b1a8 + 6) + iVar6) = 0xffff;
      if ((DAT_0050b1ac == (short *)0x0) || (*DAT_0050b1ac != 1)) {
        ppppppcStack_2d0 = (code ******)0x43f206;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        iVar6 = *(int *)(DAT_0050b1ac + 10);
        if (*(uint *)(DAT_0050b1ac + 8) <= 1U - iVar6) {
          ppppppcStack_2d0 = (code ******)0x43f1f5;
          __vbaGenerateBoundsError();
        }
        iVar6 = (1U - iVar6) * 4;
      }
      *(undefined4 *)(*(int *)(DAT_0050b1ac + 6) + iVar6) = 0;
      uStack_26c = DAT_0050b332;
      pppppppcVar13 = (code *******)0x2;
      do {
        pppppppcVar7 = pppppppcVar13;
        uVar1 = DAT_0050b332;
        sVar3 = (short)pppppppcVar7;
        if ((short)uStack_26c < sVar3) {
          pppppppcVar7 = (code *******)(uint)DAT_0050b332;
          pppppppcVar17 = (code *******)&DAT_00000001;
          sVar3 = 1;
          goto LAB_0043f2e4;
        }
        if ((DAT_0050b1ac == (short *)0x0) || (*DAT_0050b1ac != 1)) {
          ppppppcStack_2d0 = (code ******)0x43f267;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar17 = (code *******)((int)sVar3 - *(int *)(DAT_0050b1ac + 10));
          if (*(code ********)(DAT_0050b1ac + 8) <= pppppppcVar17) {
            ppppppcStack_2d0 = (code ******)0x43f256;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)pppppppcVar17 * 4;
        }
        fStack_2a8 = (float)_DAT_0050b134;
        *(float *)(*(int *)(DAT_0050b1ac + 6) + iVar6) = fStack_2a8;
        if ((DAT_0050b1a8 == (short *)0x0) || (*DAT_0050b1a8 != 1)) {
          ppppppcStack_2d0 = (code ******)0x43f2b3;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar17 = (code *******)((int)sVar3 - *(int *)(DAT_0050b1a8 + 10));
          if (*(code ********)(DAT_0050b1a8 + 8) <= pppppppcVar17) {
            ppppppcStack_2d0 = (code ******)0x43f2a6;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)pppppppcVar17 * 2;
        }
        *(short *)(*(int *)(DAT_0050b1a8 + 6) + iVar6) = sVar3;
        pppppppcVar13 = (code *******)(uint)(ushort)(sVar3 + 1);
      } while (!SCARRY2(sVar3,1));
      break;
    case 3:
      pppppppcVar16 = pppppppcVar13;
      do {
        ppppppcStack_2d0 = (code ******)0x43f446;
        FUN_004c9e80();
        if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
          ppppppcStack_2d0 = (code ******)0x43f49d;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar17 = (code *******)(1 - *(int *)(DAT_0050b1a4 + 0xe));
          if (*(code ********)(DAT_0050b1a4 + 0xc) <= pppppppcVar17) {
            ppppppcStack_2d0 = (code ******)0x43f46d;
            __vbaGenerateBoundsError();
          }
          pppppppcVar16 = (code *******)-*(int *)(DAT_0050b1a4 + 10);
          if (*(code ********)(DAT_0050b1a4 + 8) <= pppppppcVar16) {
            ppppppcStack_2d0 = (code ******)0x43f485;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)((int)pppppppcVar17 + *(int *)(DAT_0050b1a4 + 0xc) * (int)pppppppcVar16) * 2;
        }
        if (0 < *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6)) {
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_2d0 = (code ******)&DAT_0050b420;
            ppppppcStack_2d4 = (code ******)&DAT_00408c88;
            ppppppcStack_2d8 = (code ******)0x43f4ca;
            __vbaNew2();
          }
          ppppppcStack_2d0 = (code ******)DAT_0050b420;
          ppppppcStack_2d4 = (code ******)0x43f4d8;
          ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
          ppppppcStack_2d8 = (code ******)&ppppppcStack_244;
          ppppppcStack_2dc = (code ******)0x43f4e6;
          __vbaObjSet();
          pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
          if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
            ppppppcStack_2d0 = (code ******)0x43f545;
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b1a4 + 0xe);
            if (*(uint *)(DAT_0050b1a4 + 0xc) <= 1U - iVar6) {
              ppppppcStack_2d0 = (code ******)0x43f50d;
              __vbaGenerateBoundsError();
            }
            iVar5 = *(int *)(DAT_0050b1a4 + 10);
            if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)-iVar5) {
              ppppppcStack_2d0 = (code ******)0x43f525;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * -iVar5 + (1U - iVar6)) * 2;
            pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
          }
          sStack_27c = *(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
          pppppppcVar13 = (code *******)&DAT_00000001;
          while (pppppppcVar17 = pppppppcVar13, sVar3 = (short)pppppppcVar17, sVar3 <= sStack_27c) {
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_2d0 = (code ******)0x43f5c9;
              iVar6 = (*(code *)pppppppcVar16)();
            }
            else {
              uStack_234 = 1 - *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= uStack_234) {
                ppppppcStack_2d0 = (code ******)0x43f58e;
                (*(code *)pppppppcVar16)();
              }
              iVar6 = *(int *)(DAT_0050b1a4 + 10);
              if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(sVar3 - iVar6)) {
                ppppppcStack_2d0 = (code ******)0x43f5a9;
                __vbaGenerateBoundsError();
              }
              iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (sVar3 - iVar6) + uStack_234) * 2;
              pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
            }
            ppppppcStack_2d4 = (code ******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
            ppppppcStack_1dc = (code ******)0x3;
            ppppppcStack_2dc = (code ******)0x3;
            ppppppcStack_2e0 = (code ******)0xa;
            ppppppcStack_2d8 = ppppppcStack_1d8;
            ppppppcStack_2e4 = ppppppcStack_244;
            ppppppcStack_2d0 = ppppppcStack_1d0;
            ppppppcStack_2e8 = (code ******)0x43f605;
            ppppppcStack_1d4 = ppppppcStack_2d4;
            __vbaLateIdSt();
            if ((DAT_0050b1a4 == (short *)0x0) || (*DAT_0050b1a4 != 2)) {
              ppppppcStack_2e8 = (code ******)0x43f669;
              iVar6 = (*(code *)pppppppcVar16)();
            }
            else {
              uStack_234 = 2 - *(int *)(DAT_0050b1a4 + 0xe);
              if (*(uint *)(DAT_0050b1a4 + 0xc) <= uStack_234) {
                ppppppcStack_2e8 = (code ******)0x43f62e;
                (*(code *)pppppppcVar16)();
              }
              iVar6 = *(int *)(DAT_0050b1a4 + 10);
              if (*(uint *)(DAT_0050b1a4 + 8) <= (uint)(sVar3 - iVar6)) {
                ppppppcStack_2e8 = (code ******)0x43f649;
                __vbaGenerateBoundsError();
              }
              iVar6 = (*(int *)(DAT_0050b1a4 + 0xc) * (sVar3 - iVar6) + uStack_234) * 2;
              pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
            }
            ppppppcStack_2ec = (code ******)(int)*(short *)(*(int *)(DAT_0050b1a4 + 6) + iVar6);
            ppppppcStack_1dc = (code ******)0x3;
            ppppppcStack_2f8 = (code ******)0xb;
            ppppppcStack_2f4 = (code ******)0x3;
            ppppppcStack_2f0 = ppppppcStack_1d8;
            ppppppcStack_2fc = ppppppcStack_244;
            ppppppcStack_2e8 = ppppppcStack_1d0;
            ppppppcStack_300 = (code ******)0x43f6a5;
            ppppppcStack_1d4 = ppppppcStack_2ec;
            __vbaLateIdSt();
            ppppppcStack_1dc = (code ******)0x3;
            ppppppcStack_30c = (code ******)0x3;
            ppppppcStack_1d4 = (code ******)0xff00;
            ppppppcStack_308 = ppppppcStack_1d8;
            ppppppcStack_304 = (code ******)0xff00;
            ppppppcStack_300 = ppppppcStack_1d0;
            __vbaLateIdSt(ppppppcStack_244,0x26);
            uVar10 = __vbaLateIdCallLd(&ppppppcStack_19c,ppppppcStack_244,0xb,0);
            iVar6 = __vbaI4Var(uVar10);
            iVar5 = iVar6 + (short)DAT_0050b332;
            if (SCARRY4(iVar6,(int)(short)DAT_0050b332)) goto LAB_00440949;
            pppppppcVar13 = (code *******)(iVar5 + 1);
            ppppppcStack_1dc = (code ******)0x3;
            if (SCARRY4(iVar5,1)) goto LAB_00440949;
            ppppppcStack_2e0 = (code ******)0xb;
            ppppppcStack_2dc = (code ******)0x3;
            ppppppcStack_2d8 = ppppppcStack_1d8;
            ppppppcStack_2e4 = ppppppcStack_244;
            ppppppcStack_2d0 = ppppppcStack_1d0;
            ppppppcStack_2e8 = (code ******)0x43f73f;
            ppppppcStack_2d4 = (code ******)pppppppcVar13;
            ppppppcStack_1d4 = (code ******)pppppppcVar13;
            __vbaLateIdSt();
            ppppppcStack_2e8 = (code ******)0x43f748;
            __vbaFreeVar();
            ppppppcStack_1dc = (code ******)0x3;
            ppppppcStack_2f8 = (code ******)0x26;
            ppppppcStack_2f4 = (code ******)0x3;
            ppppppcStack_1d4 = (code ******)0xff00;
            ppppppcStack_2f0 = ppppppcStack_1d8;
            ppppppcStack_2fc = ppppppcStack_244;
            ppppppcStack_2ec = (code ******)0xff00;
            ppppppcStack_2e8 = ppppppcStack_1d0;
            ppppppcStack_300 = (code ******)0x43f77c;
            __vbaLateIdSt();
            pppppppcVar13 = (code *******)(uint)(ushort)(sVar3 + 1);
            if (SCARRY2(sVar3,1)) goto LAB_00440949;
          }
          ppppppcStack_2d4 = (code ******)&ppppppcStack_244;
          ppppppcStack_2d0 = (code ******)0x0;
          ppppppcStack_2d8 = (code ******)0x43f7a6;
          __vbaObjSetAddref();
        }
        if (SCARRY2(DAT_0050b244,1)) goto LAB_00440949;
        _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
        ppppppcStack_2d0 = (code ******)0x43f7c1;
        FUN_004ca300();
        if (SCARRY2(DAT_0050b332,1)) goto LAB_00440949;
      } while (DAT_0050b244 != (ushort)(DAT_0050b332 + 1));
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2d0 = (code ******)&DAT_0050b420;
        ppppppcStack_2d4 = (code ******)&DAT_00408c88;
        ppppppcStack_2d8 = (code ******)0x43f7f8;
        __vbaNew2();
      }
      ppppppcStack_2d0 = (code ******)DAT_0050b420;
      ppppppcStack_2d4 = (code ******)0x43f806;
      ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      ppppppcStack_2d8 = &pppppcStack_18c;
      ppppppcStack_2dc = (code ******)0x43f813;
      pppppppcVar17 = (code *******)__vbaObjSet();
      ppppppcStack_2dc = (code ******)0x0;
      ppppppcStack_2e4 = (code ******)0x43f820;
      ppppppcStack_2e0 = (code ******)pppppppcVar17;
      pppppppcVar13 = (code *******)(*(code *)(*pppppppcVar17)[0x23])();
      if ((int)pppppppcVar13 < 0) {
        ppppppcStack_2e4 = (code ******)0x8c;
        ppppppcStack_2e8 = (code ******)&DAT_0040bb6c;
        ppppppcStack_2f4 = (code ******)0x43f838;
        ppppppcStack_2f0 = (code ******)pppppppcVar13;
        ppppppcStack_2ec = (code ******)pppppppcVar17;
        __vbaHresultCheckObj();
      }
      ppppppcStack_2e4 = (code ******)0x43f843;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2e4 = (code ******)&DAT_0050b420;
        ppppppcStack_2e8 = (code ******)&DAT_00408c88;
        ppppppcStack_2ec = (code ******)0x43f85c;
        __vbaNew2();
      }
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2e8 = (code ******)0x43f86a;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43f871;
      pppppppcVar17 = (code *******)__vbaObjSet();
      ppppppcStack_2f0 = (code ******)0x0;
      ppppppcStack_2f8 = (code ******)0x43f87e;
      ppppppcStack_2f4 = (code ******)pppppppcVar17;
      iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_2f8 = (code ******)0x8c;
        ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
        ppppppcStack_308 = (code ******)0x43f896;
        ppppppcStack_304 = (code ******)iVar6;
        ppppppcStack_300 = (code ******)pppppppcVar17;
        __vbaHresultCheckObj();
      }
      ppppppcStack_2f8 = (code ******)0x43f89b;
      __vbaFreeObj();
      ppppppcStack_1cc = (code ******)0xa;
      pppppcStack_1bc = (code *****)0xa;
      ppppppcStack_1c4 = (code ******)0x80020004;
      ppppppcStack_1b4 = (code ******)0x80020004;
      ppppppcStack_1e4 = (code ******)0x40dfac;
      ppppppcStack_1ec = (code ******)0x8;
      ppppppcStack_2f8 = (code ******)0x43f8d7;
      __vbaVarDup();
      ppppppcStack_1d4 = (code ******)0x40dfc0;
      ppppppcStack_1dc = (code ******)0x8;
      ppppppcStack_2f8 = (code ******)0x43f8ef;
      __vbaVarDup();
      ppppppcStack_2f8 = (code ******)&ppppppcStack_1cc;
      ppppppcStack_2fc = &pppppcStack_1bc;
      ppppppcStack_300 = (code ******)&ppppppcStack_1ac;
      ppppppcStack_308 = (code ******)&ppppppcStack_19c;
      ppppppcStack_304 = (code ******)0x40;
      ppppppcStack_30c = (code ******)0x43f907;
      Ordinal_595();
LAB_0043f907:
      ppppppcStack_30c = (code ******)&ppppppcStack_1cc;
      __vbaFreeVarList(4,&ppppppcStack_19c,&ppppppcStack_1ac,&pppppcStack_1bc);
      goto switchD_0043e64f_caseD_5;
    case 4:
      pppppppcVar7 = unaff_ESI;
      while( true ) {
        ppppppcStack_2d0 = (code ******)0x43f932;
        FUN_004cf810();
        if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
          ppppppcStack_2d0 = (code ******)0x43f979;
          iVar6 = __vbaGenerateBoundsError();
        }
        else {
          pppppppcVar17 = (code *******)-*(int *)(DAT_0050b19c + 0xe);
          if (*(code ********)(DAT_0050b19c + 0xc) <= pppppppcVar17) {
            ppppppcStack_2d0 = (code ******)0x43f950;
            __vbaGenerateBoundsError();
          }
          pppppppcVar7 = (code *******)-*(int *)(DAT_0050b19c + 10);
          if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar7) {
            ppppppcStack_2d0 = (code ******)0x43f964;
            __vbaGenerateBoundsError();
          }
          iVar6 = (int)((int)pppppppcVar17 + *(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar7) * 4;
        }
        if (*(float *)(*(int *)(DAT_0050b19c + 6) + iVar6) <= _DAT_00401bc0) break;
        if (SCARRY2(DAT_0050b244,1)) goto LAB_00440949;
        _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
        ppppppcStack_2d0 = (code ******)0x43f9af;
        FUN_004d02a0();
      }
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2d0 = (code ******)&DAT_0050b420;
        ppppppcStack_2d4 = (code ******)&DAT_00408c88;
        ppppppcStack_2d8 = (code ******)0x43f9cd;
        __vbaNew2();
      }
      ppppppcStack_2d0 = (code ******)DAT_0050b420;
      ppppppcStack_2d4 = (code ******)0x43f9db;
      ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      pppppppcVar17 = (code *******)__vbaObjSet_exref;
      ppppppcStack_2d8 = &pppppcStack_18c;
      ppppppcStack_2dc = (code ******)0x43f9e8;
      pppppppcVar13 = (code *******)__vbaObjSet();
      ppppppcStack_2dc = (code ******)0x0;
      ppppppcStack_2e4 = (code ******)0x43f9f5;
      ppppppcStack_2e0 = (code ******)pppppppcVar13;
      pppppppcVar16 = (code *******)(*(code *)(*pppppppcVar13)[0x23])();
      if ((int)pppppppcVar16 < 0) {
        ppppppcStack_2e4 = (code ******)0x8c;
        ppppppcStack_2e8 = (code ******)&DAT_0040bb6c;
        ppppppcStack_2f4 = (code ******)0x43fa0d;
        ppppppcStack_2f0 = (code ******)pppppppcVar16;
        ppppppcStack_2ec = (code ******)pppppppcVar13;
        __vbaHresultCheckObj();
      }
      pppppppcVar16 = (code *******)__vbaFreeObj_exref;
      ppppppcStack_2e4 = (code ******)0x43fa18;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2e4 = (code ******)&DAT_0050b420;
        ppppppcStack_2e8 = (code ******)&DAT_00408c88;
        ppppppcStack_2ec = (code ******)0x43fa31;
        __vbaNew2();
      }
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2e8 = (code ******)0x43fa3f;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43fa46;
      pppppppcVar13 = (code *******)__vbaObjSet();
      ppppppcStack_2f0 = (code ******)0x0;
      ppppppcStack_2f8 = (code ******)0x43fa53;
      ppppppcStack_2f4 = (code ******)pppppppcVar13;
      iVar6 = (*(code *)(*pppppppcVar13)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_2f8 = (code ******)0x8c;
        ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
        ppppppcStack_308 = (code ******)0x43fa6b;
        ppppppcStack_304 = (code ******)iVar6;
        ppppppcStack_300 = (code ******)pppppppcVar13;
        __vbaHresultCheckObj();
      }
      ppppppcStack_2f8 = (code ******)0x43fa70;
      __vbaFreeObj();
      ppppppcStack_1cc = (code ******)0xa;
      pppppcStack_1bc = (code *****)0xa;
      pppppppcVar7 = (code *******)0x8;
      ppppppcStack_1c4 = (code ******)0x80020004;
      ppppppcStack_1b4 = (code ******)0x80020004;
      ppppppcStack_1d4 = (code ******)0x40e260;
      ppppppcStack_1dc = (code ******)0x8;
      ppppppcStack_2f8 = (code ******)0x43faa7;
      __vbaVarDup();
      ppppppcStack_2cc = (code ******)0x40e1f0;
      ppppppcStack_2d0 = (code ******)CONCAT22(extraout_var_01,DAT_0050b244 + 1);
      if (!SCARRY2(DAT_0050b244,1)) {
        ppppppcStack_2d4 = (code ******)0x43fac4;
        __vbaStrI2();
        ppppppcStack_2d4 = (code ******)0x43facf;
        ppppppcStack_2d4 = (code ******)__vbaStrMove();
        ppppppcStack_2d8 = (code ******)0x43fad6;
        ppppppcStack_194 = (code ******)__vbaStrCat();
        ppppppcStack_2d8 = (code ******)&ppppppcStack_1cc;
        ppppppcStack_2dc = &pppppcStack_1bc;
        ppppppcStack_2e0 = (code ******)&ppppppcStack_1ac;
        ppppppcStack_2e8 = (code ******)&ppppppcStack_19c;
        ppppppcStack_2e4 = (code ******)0x0;
        ppppppcStack_19c = (code ******)0x8;
        ppppppcStack_2ec = (code ******)0x43faf4;
        Ordinal_595();
        ppppppcStack_2ec = (code ******)0x43fafd;
        __vbaFreeStr();
        goto LAB_0043f907;
      }
      break;
    default:
      goto switchD_0043e64f_caseD_5;
    }
    goto LAB_00440949;
  case 8:
    if ((DAT_0050b3d4 == (short *)0x0) || (*DAT_0050b3d4 != 1)) {
      ppppppcStack_2d0 = (code ******)0x43fb39;
      __vbaGenerateBoundsError();
      pppppppcVar7 = unaff_ESI;
    }
    else {
      pppppppcVar7 = (code *******)-*(int *)(DAT_0050b3d4 + 10);
      if (*(code ********)(DAT_0050b3d4 + 8) <= pppppppcVar7) {
        ppppppcStack_2d0 = (code ******)0x43fb24;
        __vbaGenerateBoundsError();
      }
    }
    pppppppcVar16 = pppppppcVar13;
    if (!SCARRY2(DAT_0050b332,1)) {
      iStack_2ac = (int)(short)(DAT_0050b332 + 1);
      fStack_2b0 = (float)iStack_2ac;
      if ((in_FPUStatusWord & 0xd) != 0) {
        __vbaFPException();
        return;
      }
      ppppppcStack_2d0 = (code ******)0x43fb81;
      ppppppcStack_17c = (code ******)__vbaFpI2();
      pppppppcVar7 = (code *******)__vbaLateIdSt_exref;
      while( true ) {
        pppppppcVar16 = (code *******)__vbaI4Var_exref;
        if (SCARRY2(DAT_0050b244,1)) break;
        _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,DAT_0050b244 + 1);
        if (DAT_0050b3c0 == 1) {
          if (DAT_0050b420 == (code *******)0x0) {
            ppppppcStack_2d0 = (code ******)&DAT_0050b420;
            ppppppcStack_2d4 = (code ******)&DAT_00408c88;
            ppppppcStack_2d8 = (code ******)0x43fbcb;
            __vbaNew2();
          }
          ppppppcStack_2d0 = (code ******)DAT_0050b420;
          ppppppcStack_2d4 = (code ******)0x43fbd9;
          ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xea])();
          ppppppcStack_2d8 = (code ******)&ppppppcStack_248;
          ppppppcStack_2dc = (code ******)0x43fbe7;
          __vbaObjSet();
          if ((short)ppppppcStack_17c < DAT_0050b244) {
            if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
              ppppppcStack_2d0 = (code ******)0x43fc43;
              iVar6 = __vbaGenerateBoundsError();
            }
            else {
              iVar6 = *(int *)(DAT_0050b3d8 + 10);
              pppppppcVar17 = (code *******)-iVar6;
              if (*(code ********)(DAT_0050b3d8 + 8) <= pppppppcVar17) {
                ppppppcStack_2d0 = (code ******)0x43fc2e;
                __vbaGenerateBoundsError();
              }
              iVar6 = iVar6 * -4;
            }
            if (*(float *)(*(int *)(DAT_0050b3d8 + 6) + iVar6) == _DAT_00401bc0) {
              ppppppcStack_2d0 = (code ******)0x43fc65;
              FUN_004ed5c0();
              pppppppcVar17 = (code *******)__vbaLateIdCallLd_exref;
              ppppppcStack_2d0 = (code ******)0x0;
              ppppppcStack_2d4 = (code ******)0x4;
              ppppppcStack_2dc = (code ******)&ppppppcStack_1ac;
              ppppppcStack_2d8 = ppppppcStack_248;
              ppppppcStack_2e0 = (code ******)0x43fc7c;
              ppppppcStack_2d0 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_2d4 = (code ******)0x43fc82;
              iVar6 = __vbaI4Var();
              ppppppcStack_2c0 = (code ******)0x0;
              ppppppcStack_2c4 = (code ******)0xa;
              ppppppcStack_2cc = (code ******)&ppppppcStack_19c;
              ppppppcStack_2c8 = ppppppcStack_248;
              if (SBORROW4(iVar6,2)) break;
              ppppppcStack_2d0 = (code ******)0x43fca4;
              iStack_2b4 = iVar6 + -2;
              ppppppcStack_2c0 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_2c4 = (code ******)0x43fcaa;
              iVar6 = __vbaI4Var();
              bVar19 = iVar6 == iStack_2b4;
              ppppppcStack_2c4 = (code ******)&ppppppcStack_1ac;
              pppppppcVar17 =
                   (code *******)CONCAT22((short)((uint)pppppppcVar17 >> 0x10),-(ushort)bVar19);
              ppppppcStack_2c8 = (code ******)&ppppppcStack_19c;
              ppppppcStack_2cc = (code ******)0x2;
              ppppppcStack_2d0 = (code ******)0x43fccc;
              __vbaFreeVarList();
              if ((ushort)-(ushort)bVar19 == 0) goto LAB_00440492;
              ppppppcStack_2d0 = (code ******)0x0;
              ppppppcStack_2d4 = (code ******)0x4;
              ppppppcStack_2dc = (code ******)&ppppppcStack_19c;
              ppppppcStack_2d8 = ppppppcStack_248;
              ppppppcStack_2e0 = (code ******)0x43fced;
              ppppppcStack_2d0 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_2d4 = (code ******)0x43fcf7;
              iVar6 = __vbaI4Var();
              if (SBORROW4(iVar6,1)) break;
              ppppppcStack_1dc = (code ******)0x3;
              ppppppcStack_2e0 = (code ******)0xa;
              ppppppcStack_2dc = (code ******)0x3;
              ppppppcStack_2d8 = ppppppcStack_1d8;
              ppppppcStack_2e4 = ppppppcStack_248;
              ppppppcStack_2d0 = ppppppcStack_1d0;
              ppppppcStack_2e8 = (code ******)0x43fd2f;
              ppppppcStack_2d4 = (code ******)(iVar6 + -1);
              ppppppcStack_1d4 = (code ******)(iVar6 + -1);
              __vbaLateIdSt();
              ppppppcStack_2e8 = (code ******)0x43fd38;
              __vbaFreeVar();
              pppppppcVar13 = (code *******)0x4;
              while (sVar3 = (short)pppppppcVar13, pppppppcVar17 = pppppppcVar13, sVar3 < 7) {
                ppppppcStack_1dc = (code ******)0x3;
                ppppppcStack_2e0 = (code ******)0xb;
                ppppppcStack_2dc = (code ******)0x3;
                pppppppcVar16 = (code *******)(int)sVar3;
                ppppppcStack_2d8 = ppppppcStack_1d8;
                ppppppcStack_2d0 = ppppppcStack_1d0;
                ppppppcStack_2e4 = ppppppcStack_248;
                ppppppcStack_2e8 = (code ******)0x43fd7d;
                ppppppcStack_2d4 = (code ******)pppppppcVar16;
                ppppppcStack_1d4 = (code ******)pppppppcVar16;
                __vbaLateIdSt();
                ppppppcStack_2e8 = (code ******)0x0;
                ppppppcStack_2ec = (code ******)0x4;
                ppppppcStack_2f4 = (code ******)&ppppppcStack_19c;
                ppppppcStack_2f0 = ppppppcStack_248;
                ppppppcStack_2f8 = (code ******)0x43fd92;
                ppppppcStack_2e8 = (code ******)__vbaLateIdCallLd();
                ppppppcStack_2ec = (code ******)0x43fd9c;
                iVar6 = __vbaI4Var();
                if (SBORROW4(iVar6,1)) goto LAB_00440949;
                ppppppcStack_1dc = (code ******)0x3;
                ppppppcStack_2dc = (code ******)0x3;
                ppppppcStack_2d8 = ppppppcStack_1d8;
                ppppppcStack_2d0 = ppppppcStack_1d0;
                ppppppcStack_2ec = (code ******)0x3;
                ppppppcStack_2e8 = ppppppcStack_1f8;
                ppppppcStack_2e0 = ppppppcStack_1f0;
                ppppppcStack_300 = (code ******)0x2;
                ppppppcStack_2fc = (code ******)0x8;
                ppppppcStack_304 = (code ******)0x41;
                ppppppcStack_2f8 = ppppppcStack_218;
                ppppppcStack_2f4 = (code ******)0x40e0a8;
                ppppppcStack_2f0 = ppppppcStack_210;
                ppppppcStack_308 = ppppppcStack_248;
                ppppppcStack_30c = (code ******)0x43fe21;
                ppppppcStack_2e4 = (code ******)pppppppcVar16;
                ppppppcStack_2d4 = (code ******)(iVar6 + -1);
                ppppppcStack_1d4 = (code ******)(iVar6 + -1);
                __vbaLateIdCallSt();
                ppppppcStack_2d0 = (code ******)0x43fe2d;
                __vbaFreeVar();
                pppppppcVar13 = (code *******)(uint)(ushort)(sVar3 + 1);
                if (SCARRY2(sVar3,1)) goto LAB_00440949;
              }
              ppppppcStack_1dc = (code ******)0x3;
              ppppppcStack_2e0 = (code ******)0x30;
              ppppppcStack_2dc = (code ******)0x3;
              ppppppcStack_1d4 = (code ******)0x2;
              ppppppcStack_2d8 = ppppppcStack_1d8;
              ppppppcStack_2e4 = ppppppcStack_248;
              ppppppcStack_2d4 = (code ******)0x2;
              ppppppcStack_2d0 = ppppppcStack_1d0;
              ppppppcStack_2e8 = (code ******)0x43fe76;
              __vbaLateIdSt();
              ppppppcStack_2e8 = (code ******)0x0;
              ppppppcStack_2ec = (code ******)0x4;
              ppppppcStack_2f4 = (code ******)&ppppppcStack_19c;
              ppppppcStack_2f0 = ppppppcStack_248;
              ppppppcStack_2f8 = (code ******)0x43fe8b;
              ppppppcStack_2e8 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_2ec = (code ******)0x43fe95;
              iVar6 = __vbaI4Var();
              if (SBORROW4(iVar6,1)) break;
              ppppppcStack_1dc = (code ******)0x3;
              ppppppcStack_2dc = (code ******)0x3;
              ppppppcStack_2d8 = ppppppcStack_1d8;
              ppppppcStack_2f0 = (code ******)&DAT_00000001;
              ppppppcStack_2f4 = (code ******)0x3b;
              ppppppcStack_2d0 = ppppppcStack_1d0;
              ppppppcStack_2ec = (code ******)0xb;
              ppppppcStack_2e8 = ppppppcStack_1f8;
              ppppppcStack_2f8 = ppppppcStack_248;
              ppppppcStack_2e4 = (code ******)0xffffffff;
              ppppppcStack_2e0 = ppppppcStack_1f0;
              ppppppcStack_2fc = (code ******)0x43fef7;
              ppppppcStack_2d4 = (code ******)(iVar6 + -1);
              ppppppcStack_1d4 = (code ******)(iVar6 + -1);
              __vbaLateIdCallSt();
              pppppppcVar17 = (code *******)__vbaFreeVar_exref;
              ppppppcStack_2d0 = (code ******)0x43ff05;
              __vbaFreeVar();
              pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
              if ((DAT_0050b3d8 == (short *)0x0) || (*DAT_0050b3d8 != 1)) {
                ppppppcStack_2d0 = (code ******)0x43ff44;
                iVar6 = __vbaGenerateBoundsError();
              }
              else {
                iVar6 = *(int *)(DAT_0050b3d8 + 10);
                if (*(uint *)(DAT_0050b3d8 + 8) <= (uint)-iVar6) {
                  ppppppcStack_2d0 = (code ******)0x43ff27;
                  __vbaGenerateBoundsError();
                }
                iVar6 = iVar6 * -4;
                pppppppcVar16 = (code *******)__vbaGenerateBoundsError_exref;
              }
              ppppppcStack_2d0 = (code ******)0x0;
              ppppppcStack_2d4 = (code ******)0x4;
              *(undefined4 *)(*(int *)(DAT_0050b3d8 + 6) + iVar6) = 0xc2c60000;
              ppppppcStack_2dc = (code ******)&ppppppcStack_19c;
              ppppppcStack_2d8 = ppppppcStack_248;
              ppppppcStack_2e0 = (code ******)0x43ff69;
              ppppppcStack_2d0 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_2d4 = (code ******)0x43ff73;
              iVar6 = __vbaI4Var();
              if (SCARRY4(iVar6,1)) break;
              ppppppcStack_1dc = (code ******)0x3;
              ppppppcStack_2e0 = (code ******)0x4;
              ppppppcStack_2dc = (code ******)0x3;
              ppppppcStack_2d8 = ppppppcStack_1d8;
              ppppppcStack_2e4 = ppppppcStack_248;
              ppppppcStack_2d0 = ppppppcStack_1d0;
              ppppppcStack_2e8 = (code ******)0x43ffab;
              ppppppcStack_2d4 = (code ******)(iVar6 + 1);
              ppppppcStack_1d4 = (code ******)(iVar6 + 1);
              __vbaLateIdSt();
              ppppppcStack_2e8 = (code ******)0x43ffb0;
              __vbaFreeVar();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x43ffdf;
                (*(code *)pppppppcVar16)();
              }
              else {
                pppppppcVar17 = (code *******)-(int)DAT_0050b3bc[5];
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x43ffce;
                  (*(code *)pppppppcVar16)();
                }
              }
              pppppppcVar16 = (code *******)__vbaStrCopy_exref;
              ppppppcStack_2e8 = (code ******)0x43fff7;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x440033;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar17 = (code *******)(1 - (int)DAT_0050b3bc[5]);
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x44001e;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_2e8 = (code ******)0x440045;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x440081;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar17 = (code *******)(2 - (int)DAT_0050b3bc[5]);
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x44006c;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_2e8 = (code ******)0x440093;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x4400cf;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar17 = (code *******)(3 - (int)DAT_0050b3bc[5]);
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x4400ba;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_2e8 = (code ******)0x4400e1;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x44011d;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar17 = (code *******)(4 - (int)DAT_0050b3bc[5]);
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x440108;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_2e8 = (code ******)0x44012f;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x44016b;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar17 = (code *******)(5 - (int)DAT_0050b3bc[5]);
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x440156;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_2e8 = (code ******)0x44017d;
              __vbaStrCopy();
              if ((DAT_0050b3bc == (code ******)0x0) || (*(short *)DAT_0050b3bc != 1)) {
                ppppppcStack_2e8 = (code ******)0x4401b9;
                __vbaGenerateBoundsError();
              }
              else {
                pppppppcVar17 = (code *******)(6 - (int)DAT_0050b3bc[5]);
                if (DAT_0050b3bc[4] <= pppppppcVar17) {
                  ppppppcStack_2e8 = (code ******)0x4401a4;
                  __vbaGenerateBoundsError();
                }
              }
              ppppppcStack_2e8 = (code ******)0x4401cf;
              __vbaStrCopy();
              ppppppcStack_2e8 = (code ******)0x0;
              ppppppcStack_2ec = (code ******)0x4;
              ppppppcStack_2f4 = (code ******)&ppppppcStack_19c;
              ppppppcStack_2f0 = ppppppcStack_248;
              ppppppcStack_2f8 = (code ******)0x4401e4;
              ppppppcStack_2e8 = (code ******)__vbaLateIdCallLd();
              ppppppcStack_2ec = (code ******)0x4401ee;
              iVar6 = __vbaI4Var();
              if (SBORROW4(iVar6,1)) break;
              ppppppcStack_1dc = (code ******)0x3;
              ppppppcStack_2e0 = (code ******)0xa;
              ppppppcStack_2dc = (code ******)0x3;
              ppppppcStack_2d8 = ppppppcStack_1d8;
              ppppppcStack_2e4 = ppppppcStack_248;
              ppppppcStack_2d0 = ppppppcStack_1d0;
              ppppppcStack_2e8 = (code ******)0x440226;
              ppppppcStack_2d4 = (code ******)(iVar6 + -1);
              ppppppcStack_1d4 = (code ******)(iVar6 + -1);
              __vbaLateIdSt();
              ppppppcStack_2e8 = (code ******)0x44022f;
              __vbaFreeVar();
              pppppppcVar13 = (code *******)0x0;
              while (pppppppcVar16 = pppppppcVar13, sVar3 = (short)pppppppcVar16, sVar3 < 7) {
                ppppppcStack_1dc = (code ******)0x3;
                ppppppcStack_2e0 = (code ******)0xb;
                ppppppcStack_2dc = (code ******)0x3;
                pppppppcVar17 = (code *******)(int)sVar3;
                ppppppcStack_2d8 = ppppppcStack_1d8;
                ppppppcStack_2d0 = ppppppcStack_1d0;
                ppppppcStack_2e4 = ppppppcStack_248;
                ppppppcStack_2e8 = (code ******)0x440271;
                ppppppcStack_2d4 = (code ******)pppppppcVar17;
                ppppppcStack_1d4 = (code ******)pppppppcVar17;
                __vbaLateIdSt();
                ppppppcStack_1dc = (code ******)0x2;
                ppppppcStack_2f8 = (code ******)0x28;
                ppppppcStack_2f4 = (code ******)0x2;
                ppppppcStack_1d4 = (code ******)0x4;
                ppppppcStack_2f0 = ppppppcStack_1d8;
                ppppppcStack_2fc = ppppppcStack_248;
                ppppppcStack_2ec = (code ******)0x4;
                ppppppcStack_2e8 = ppppppcStack_1d0;
                ppppppcStack_300 = (code ******)0x4402a5;
                __vbaLateIdSt();
                ppppppcStack_1dc = (code ******)0x3;
                ppppppcStack_30c = (code ******)0x3;
                ppppppcStack_1d4 = (code ******)0xffff;
                ppppppcStack_308 = ppppppcStack_1d8;
                ppppppcStack_304 = (code ******)0xffff;
                ppppppcStack_300 = ppppppcStack_1d0;
                __vbaLateIdSt(ppppppcStack_248,0x26);
                ppppppcStack_1dc = (code ******)0x3;
                ppppppcStack_1d4 = (code ******)0xff0000;
                __vbaLateIdSt(ppppppcStack_248,0x27,3,ppppppcStack_1d8,0xff0000,ppppppcStack_1d0);
                uVar10 = __vbaLateIdCallLd(&ppppppcStack_19c,ppppppcStack_248,10,0);
                ppppppcStack_1d4 = (code ******)__vbaI4Var(uVar10);
                ppppppcStack_1dc = (code ******)0x3;
                __vbaAryLock(&ppppppcStack_184,DAT_0050b3bc);
                if ((ppppppcStack_184 == (code ******)0x0) || (*(short *)ppppppcStack_184 != 1)) {
                  iVar6 = __vbaGenerateBoundsError();
                }
                else {
                  ppppcStack_230 = (code ****)((int)pppppppcVar17 - (int)ppppppcStack_184[5]);
                  if (ppppppcStack_184[4] <= ppppcStack_230) {
                    __vbaGenerateBoundsError();
                  }
                  iVar6 = (int)ppppcStack_230 << 2;
                }
                __vbaLateIdCallSt(ppppppcStack_248,0x41,2,0x4008,ppppppcStack_218,
                                  (int)ppppppcStack_184[3] + iVar6,ppppppcStack_210,3,
                                  ppppppcStack_1f8,pppppppcVar17,ppppppcStack_1f0,ppppppcStack_1dc,
                                  ppppppcStack_1d8,ppppppcStack_1d4,ppppppcStack_1d0);
                __vbaAryUnlock(&ppppppcStack_184);
                __vbaFreeVar();
                pppppppcVar13 = (code *******)(uint)(ushort)(sVar3 + 1);
                if (SCARRY2(sVar3,1)) goto LAB_00440949;
              }
              if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
                ppppppcStack_2d0 = (code ******)0x44047d;
                iVar6 = __vbaGenerateBoundsError();
              }
              else {
                iVar6 = *(int *)(DAT_0050b19c + 0xe);
                if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-iVar6) {
                  ppppppcStack_2d0 = (code ******)0x44044c;
                  __vbaGenerateBoundsError();
                }
                pppppppcVar17 = (code *******)-*(int *)(DAT_0050b19c + 10);
                if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar17) {
                  ppppppcStack_2d0 = (code ******)0x440464;
                  __vbaGenerateBoundsError();
                }
                iVar6 = (*(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar17 + -iVar6) * 4;
              }
              *(undefined4 *)(*(int *)(DAT_0050b19c + 6) + iVar6) = 0;
            }
            ppppppcStack_2d0 = (code ******)0x440492;
            FUN_004ede00();
          }
          else {
            ppppppcStack_2d0 = (code ******)0x43fbf9;
            FUN_004ebd90();
            if (DAT_0050b3c2 == 0) goto switchD_0043e64f_caseD_5;
          }
LAB_00440492:
          if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
            ppppppcStack_2d0 = (code ******)0x4404e5;
            iVar6 = __vbaGenerateBoundsError();
          }
          else {
            iVar6 = *(int *)(DAT_0050b19c + 0xe);
            if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-iVar6) {
              ppppppcStack_2d0 = (code ******)0x4404b4;
              __vbaGenerateBoundsError();
            }
            pppppppcVar17 = (code *******)-*(int *)(DAT_0050b19c + 10);
            if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar17) {
              ppppppcStack_2d0 = (code ******)0x4404cc;
              __vbaGenerateBoundsError();
            }
            iVar6 = (*(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar17 + -iVar6) * 4;
          }
          ppppppcStack_2d0 = (code ******)0x0;
          iStack_2b8 = (int)(short)DAT_0050b3c4;
          fStack_2bc = (float)iStack_2b8;
          if (*(float *)(*(int *)(DAT_0050b19c + 6) + iVar6) == fStack_2bc) {
            ppppppcStack_2d4 = (code ******)0x4;
            ppppppcStack_2dc = (code ******)&ppppppcStack_19c;
            ppppppcStack_2d8 = ppppppcStack_248;
            ppppppcStack_2e0 = (code ******)0x44053e;
            ppppppcStack_2d0 = (code ******)__vbaLateIdCallLd();
            pppppppcVar16 = (code *******)__vbaI4Var_exref;
            ppppppcStack_2d4 = (code ******)0x44054a;
            iVar6 = __vbaI4Var();
            if (!SCARRY4(iVar6,1)) {
              ppppppcStack_1dc = (code ******)0x3;
              ppppppcStack_2e0 = (code ******)0x4;
              ppppppcStack_2dc = (code ******)0x3;
              ppppppcStack_2d8 = ppppppcStack_1d8;
              ppppppcStack_2e4 = ppppppcStack_248;
              ppppppcStack_2d0 = ppppppcStack_1d0;
              ppppppcStack_2e8 = (code ******)0x440582;
              ppppppcStack_2d4 = (code ******)(iVar6 + 1);
              ppppppcStack_1d4 = (code ******)(iVar6 + 1);
              __vbaLateIdSt();
              ppppppcStack_2e8 = (code ******)0x44058b;
              __vbaFreeVar();
              pppppppcVar13 = (code *******)0x0;
              goto LAB_0044058d;
            }
            break;
          }
          ppppppcStack_2d4 = (code ******)&ppppppcStack_248;
          ppppppcStack_2d8 = (code ******)0x440526;
          __vbaObjSetAddref();
        }
      }
    }
    goto LAB_00440949;
  }
switchD_0043e64f_caseD_5:
  ppppppcStack_15c = (code ******)0x0;
  ppppppcStack_2d0 = (code ******)&LAB_004408fc;
  ppppppcStack_2d4 = (code ******)&ppppppcStack_248;
  ppppppcStack_2d8 = (code ******)&ppppppcStack_244;
  ppppppcStack_2dc = (code ******)appppppcStack_240;
  ppppppcStack_2e0 = (code ******)0x3;
  ppppppcStack_2e4 = (code ******)0x4408f8;
  __vbaFreeObjList();
  return;
  while( true ) {
    local_84 = (code ******)0x3;
    ppppppcStack_168 = (code ******)0xb;
    ppppppcStack_164 = (code ******)0x3;
    pppppppcVar17 = (code *******)(int)sVar3;
    ppppppcStack_160 = local_80;
    ppppppcStack_158 = local_78;
    ppppppcStack_16c = local_f0;
    ppppppcStack_170 = (code ******)0x43deb6;
    ppppppcStack_15c = (code ******)pppppppcVar17;
    local_7c = (code ******)pppppppcVar17;
    __vbaLateIdSt();
    local_84 = (code ******)0x2;
    ppppppcStack_180 = (code ******)0x28;
    ppppppcStack_17c = (code ******)0x2;
    local_7c = (code ******)0x4;
    ppppppcStack_178 = local_80;
    ppppppcStack_184 = local_f0;
    ppppppcStack_174 = (code ******)0x4;
    ppppppcStack_170 = local_78;
    ppppppcStack_188 = (code ******)0x43dee7;
    __vbaLateIdSt();
    local_84 = (code ******)0x3;
    ppppppcStack_198 = (code ******)0x26;
    ppppppcStack_194 = (code ******)0x3;
    local_7c = (code ******)0xffff;
    ppppppcStack_190 = local_80;
    ppppppcStack_19c = local_f0;
    pppppcStack_18c = (code *****)0xffff;
    ppppppcStack_188 = local_78;
    ppppppcStack_1a0 = (code ******)0x43df18;
    __vbaLateIdSt();
    local_84 = (code ******)0x3;
    iStack_1b0 = 0x27;
    ppppppcStack_1ac = (code ******)0x3;
    local_7c = (code ******)0xff0000;
    ppppppcStack_1a8 = local_80;
    ppppppcStack_1b4 = local_f0;
    uStack_1a4 = 0xff0000;
    ppppppcStack_1a0 = local_78;
    uStack_1b8 = 0x43df49;
    __vbaLateIdSt();
    uStack_1b8 = 0;
    pppppcStack_1bc = (code *****)0xa;
    ppppppcStack_1c4 = local_44;
    ppppppcStack_1c0 = local_f0;
    ppppppcStack_1c8 = (code ******)0x43df5e;
    uStack_1b8 = __vbaLateIdCallLd();
    pppppcStack_1bc = (code *****)0x43df68;
    local_7c = (code ******)__vbaI4Var();
    ppppppcStack_1c0 = (code ******)local_28;
    pppppcStack_1bc = (code *****)DAT_0050b3bc;
    local_84 = (code ******)0x3;
    ppppppcStack_1c4 = (code ******)0x43df83;
    __vbaAryLock();
    if ((local_28[0] == (short *)0x0) || (*local_28[0] != 1)) {
      ppppppcStack_1c4 = (code ******)0x43dfbe;
      iStack_1e8 = __vbaGenerateBoundsError();
    }
    else {
      local_d8 = (int)pppppppcVar17 - *(int *)(local_28[0] + 10);
      if (*(uint *)(local_28[0] + 8) <= local_d8) {
        ppppppcStack_1c4 = (code ******)0x43dfaa;
        __vbaGenerateBoundsError();
      }
      iStack_1e8 = local_d8 << 2;
    }
    iStack_1e8 = *(int *)(local_28[0] + 6) + iStack_1e8;
    ppppppcStack_1d0 = local_84;
    ppppppcStack_1cc = local_80;
    ppppppcStack_1c8 = local_7c;
    ppppppcStack_1c4 = local_78;
    uStack_1e0 = 3;
    ppppppcStack_1dc = local_a0;
    ppppppcStack_1d4 = local_98;
    uStack_1f4 = 2;
    ppppppcStack_1f0 = (code ******)0x4008;
    ppppppcStack_1f8 = (code ******)0x41;
    ppppppcStack_1ec = local_c0;
    ppppppcStack_1e4 = local_b8;
    ppppppcStack_1fc = local_f0;
    uStack_200 = 0x43e035;
    ppppppcStack_1d8 = (code ******)pppppppcVar17;
    __vbaLateIdCallSt();
    ppppppcStack_1c4 = (code ******)local_28;
    ppppppcStack_1c8 = (code ******)0x43e042;
    __vbaAryUnlock();
    ppppppcStack_1c8 = (code ******)0x43e04b;
    __vbaFreeVar();
    pppppppcVar16 = (code *******)(uint)(ushort)(sVar3 + 1);
    if (SCARRY2(sVar3,1)) break;
LAB_0043de79:
    pppppppcVar13 = pppppppcVar16;
    sVar3 = (short)pppppppcVar13;
    if (6 < sVar3) {
      if ((DAT_0050b19c == (short *)0x0) || (*DAT_0050b19c != 2)) {
        ppppppcStack_158 = (code ******)0x43e0b3;
        iVar6 = __vbaGenerateBoundsError();
      }
      else {
        iVar6 = *(int *)(DAT_0050b19c + 0xe);
        if (*(uint *)(DAT_0050b19c + 0xc) <= (uint)-iVar6) {
          ppppppcStack_158 = (code ******)0x43e082;
          __vbaGenerateBoundsError();
        }
        pppppppcVar17 = (code *******)-*(int *)(DAT_0050b19c + 10);
        if (*(code ********)(DAT_0050b19c + 8) <= pppppppcVar17) {
          ppppppcStack_158 = (code ******)0x43e09a;
          __vbaGenerateBoundsError();
        }
        iVar6 = (*(int *)(DAT_0050b19c + 0xc) * (int)pppppppcVar17 + -iVar6) * 4;
      }
      *(undefined4 *)(*(int *)(DAT_0050b19c + 6) + iVar6) = 0;
      ppppppcStack_158 = (code ******)0x43e0c8;
      FUN_004ede00();
      pppppppcVar13 = (code *******)__vbaI4Var_exref;
      goto LAB_0043e0e9;
    }
  }
  goto LAB_0043e59d;
  while( true ) {
    ppppppcStack_2d0 = (code ******)0x0;
    ppppppcStack_2d4 = (code ******)0x4;
    ppppppcStack_2dc = (code ******)&ppppppcStack_19c;
    ppppppcStack_2d8 = ppppppcStack_248;
    ppppppcStack_2e0 = (code ******)0x4405b0;
    ppppppcStack_2d0 = (code ******)__vbaLateIdCallLd();
    ppppppcStack_2d4 = (code ******)0x4405b6;
    iVar6 = (*(code *)pppppppcVar16)();
    if (SBORROW4(iVar6,1)) break;
    ppppppcStack_1dc = (code ******)0x3;
    ppppppcStack_2dc = (code ******)0x3;
    ppppppcStack_2e4 = (code ******)(int)sVar3;
    ppppppcStack_2d8 = ppppppcStack_1d8;
    ppppppcStack_2d0 = ppppppcStack_1d0;
    ppppppcStack_2ec = (code ******)0x3;
    ppppppcStack_2e8 = ppppppcStack_1f8;
    ppppppcStack_2e0 = ppppppcStack_1f0;
    ppppppcStack_300 = (code ******)0x2;
    ppppppcStack_304 = (code ******)0x41;
    ppppppcStack_2fc = (code ******)0x8;
    ppppppcStack_2f8 = ppppppcStack_218;
    ppppppcStack_2f4 = (code ******)0x40e168;
    ppppppcStack_2f0 = ppppppcStack_210;
    ppppppcStack_308 = ppppppcStack_248;
    ppppppcStack_30c = (code ******)0x44063e;
    ppppppcStack_2d4 = (code ******)(iVar6 + -1);
    ppppppcStack_1d4 = (code ******)(iVar6 + -1);
    __vbaLateIdCallSt();
    ppppppcStack_2d0 = (code ******)0x44064a;
    __vbaFreeVar();
    pppppppcVar16 = (code *******)__vbaI4Var_exref;
    pppppppcVar13 = (code *******)(uint)(ushort)(sVar3 + 1);
    if (SCARRY2(sVar3,1)) break;
LAB_0044058d:
    sVar3 = (short)pppppppcVar13;
    pppppppcVar17 = pppppppcVar13;
    if (6 < sVar3) {
      ppppppcStack_1dc = (code ******)0x3;
      ppppppcStack_2e0 = (code ******)0x30;
      ppppppcStack_2dc = (code ******)0x3;
      ppppppcStack_1d4 = (code ******)0x2;
      ppppppcStack_2d8 = ppppppcStack_1d8;
      ppppppcStack_2e4 = ppppppcStack_248;
      ppppppcStack_2d4 = (code ******)0x2;
      ppppppcStack_2d0 = ppppppcStack_1d0;
      ppppppcStack_2e8 = (code ******)0x440699;
      __vbaLateIdSt();
      ppppppcStack_2e8 = (code ******)0x0;
      ppppppcStack_2ec = (code ******)0x4;
      ppppppcStack_2f4 = (code ******)&ppppppcStack_19c;
      ppppppcStack_2f0 = ppppppcStack_248;
      ppppppcStack_2f8 = (code ******)0x4406ae;
      ppppppcStack_2e8 = (code ******)__vbaLateIdCallLd();
      ppppppcStack_2ec = (code ******)0x4406b4;
      iVar6 = (*(code *)pppppppcVar16)();
      if (!SBORROW4(iVar6,1)) {
        ppppppcStack_1dc = (code ******)0x3;
        ppppppcStack_2dc = (code ******)0x3;
        ppppppcStack_2d8 = ppppppcStack_1d8;
        ppppppcStack_2f0 = (code ******)0x1;
        ppppppcStack_2f4 = (code ******)0x3b;
        ppppppcStack_2d0 = ppppppcStack_1d0;
        ppppppcStack_2ec = (code ******)0xb;
        ppppppcStack_2e8 = ppppppcStack_1f8;
        ppppppcStack_2f8 = ppppppcStack_248;
        ppppppcStack_2e4 = (code ******)0xffffffff;
        ppppppcStack_2e0 = ppppppcStack_1f0;
        ppppppcStack_2fc = (code ******)0x440716;
        ppppppcStack_2d4 = (code ******)(iVar6 + -1);
        ppppppcStack_1d4 = (code ******)(iVar6 + -1);
        __vbaLateIdCallSt();
        ppppppcStack_2d0 = (code ******)0x440722;
        __vbaFreeVar();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_2d0 = (code ******)&DAT_0050b420;
          ppppppcStack_2d4 = (code ******)&DAT_00408c88;
          ppppppcStack_2d8 = (code ******)0x44073b;
          __vbaNew2();
        }
        ppppppcStack_2d0 = (code ******)DAT_0050b420;
        ppppppcStack_2d4 = (code ******)0x440749;
        ppppppcStack_2d4 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
        ppppppcStack_2d8 = &pppppcStack_18c;
        ppppppcStack_2dc = (code ******)0x440756;
        piVar9 = (int *)__vbaObjSet();
        ppppppcStack_2dc = (code ******)0x0;
        ppppppcStack_2e4 = (code ******)0x440763;
        ppppppcStack_2e0 = (code ******)piVar9;
        iVar6 = (**(code **)(*piVar9 + 0x8c))();
        if (iVar6 < 0) {
          ppppppcStack_2e4 = (code ******)0x8c;
          ppppppcStack_2e8 = (code ******)&DAT_0040bb6c;
          ppppppcStack_2f4 = (code ******)0x44077d;
          ppppppcStack_2f0 = (code ******)iVar6;
          ppppppcStack_2ec = (code ******)piVar9;
          __vbaHresultCheckObj();
        }
        ppppppcStack_2e4 = (code ******)0x44078e;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_2e4 = (code ******)&DAT_0050b420;
          ppppppcStack_2e8 = (code ******)&DAT_00408c88;
          ppppppcStack_2ec = (code ******)0x4407a7;
          __vbaNew2();
        }
        ppppppcStack_2e4 = (code ******)DAT_0050b420;
        ppppppcStack_2e8 = (code ******)0x4407b5;
        ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
        ppppppcStack_2ec = &pppppcStack_18c;
        ppppppcStack_2f0 = (code ******)0x4407bc;
        pppppppcVar17 = (code *******)__vbaObjSet();
        ppppppcStack_2f0 = (code ******)0x0;
        ppppppcStack_2f8 = (code ******)0x4407c9;
        ppppppcStack_2f4 = (code ******)pppppppcVar17;
        iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
        if (iVar6 < 0) {
          ppppppcStack_2f8 = (code ******)0x8c;
          ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
          ppppppcStack_308 = (code ******)0x4407dd;
          ppppppcStack_304 = (code ******)iVar6;
          ppppppcStack_300 = (code ******)pppppppcVar17;
          __vbaHresultCheckObj();
        }
        ppppppcStack_2f8 = (code ******)0x4407e6;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_2f8 = (code ******)&DAT_0050b420;
          ppppppcStack_2fc = (code ******)&DAT_00408c88;
          ppppppcStack_300 = (code ******)0x4407ff;
          __vbaNew2();
        }
        ppppppcStack_2f8 = (code ******)DAT_0050b420;
        ppppppcStack_2fc = (code ******)0x44080d;
        ppppppcStack_2fc = (code ******)(*(code *)(*DAT_0050b420)[0xde])();
        ppppppcStack_300 = &pppppcStack_18c;
        ppppppcStack_304 = (code ******)0x440814;
        pppppppcVar17 = (code *******)__vbaObjSet();
        ppppppcStack_304 = (code ******)0xffffffff;
        ppppppcStack_30c = (code ******)0x440821;
        ppppppcStack_308 = (code ******)pppppppcVar17;
        iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
        if (iVar6 < 0) {
          ppppppcStack_30c = (code ******)0x8c;
          __vbaHresultCheckObj(iVar6,pppppppcVar17,&DAT_0040bb6c);
        }
        ppppppcStack_30c = (code ******)0x44083e;
        __vbaFreeObj();
        if (DAT_0050b420 == (code *******)0x0) {
          ppppppcStack_30c = (code ******)&DAT_0050b420;
          __vbaNew2(&DAT_00408c88);
        }
        ppppppcStack_30c = (code ******)DAT_0050b420;
        uVar10 = (*(code *)(*DAT_0050b420)[0xde])();
        piVar9 = (int *)__vbaObjSet(&pppppcStack_18c,uVar10);
        iVar6 = (**(code **)(*piVar9 + 0x1a4))(piVar9);
        if (iVar6 < 0) {
          __vbaHresultCheckObj(iVar6,piVar9,&DAT_0040bb6c,0x1a4);
        }
        __vbaFreeObj();
        goto switchD_0043e64f_caseD_5;
      }
      break;
    }
  }
  goto LAB_00440949;
  while( true ) {
    ppppppcStack_2d0 = (code ******)0x43f2f4;
    FUN_004c5770();
    sVar3 = DAT_0050b244 + 1;
    if (SCARRY2(DAT_0050b244,1)) break;
LAB_0043f2e4:
    _DAT_0050b244 = (code *******)CONCAT22(DAT_0050b246,sVar3);
    if ((short)uVar1 < sVar3) {
      ppppppcStack_1cc = (code ******)0xa;
      pppppcStack_1bc = (code *****)0xa;
      ppppppcStack_1c4 = (code ******)0x80020004;
      ppppppcStack_1b4 = (code ******)0x80020004;
      ppppppcStack_1e4 = (code ******)0x40dfac;
      ppppppcStack_1ec = (code ******)0x8;
      ppppppcStack_2d0 = (code ******)0x43f342;
      __vbaVarDup();
      ppppppcStack_1d4 = (code ******)0x40dfc0;
      ppppppcStack_1dc = (code ******)0x8;
      ppppppcStack_2d0 = (code ******)0x43f35a;
      __vbaVarDup();
      ppppppcStack_2d0 = (code ******)&ppppppcStack_1cc;
      ppppppcStack_2d4 = &pppppcStack_1bc;
      ppppppcStack_2d8 = (code ******)&ppppppcStack_1ac;
      ppppppcStack_2e0 = (code ******)&ppppppcStack_19c;
      ppppppcStack_2dc = (code ******)0x40;
      ppppppcStack_2e4 = (code ******)0x43f372;
      Ordinal_595();
      ppppppcStack_2e4 = (code ******)&ppppppcStack_1cc;
      ppppppcStack_2e8 = &pppppcStack_1bc;
      ppppppcStack_2ec = (code ******)&ppppppcStack_1ac;
      ppppppcStack_2f0 = (code ******)&ppppppcStack_19c;
      ppppppcStack_2f4 = (code ******)0x4;
      ppppppcStack_2f8 = (code ******)0x43f38a;
      __vbaFreeVarList();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2e4 = (code ******)&DAT_0050b420;
        ppppppcStack_2e8 = (code ******)&DAT_00408c88;
        ppppppcStack_2ec = (code ******)0x43f3a6;
        __vbaNew2();
      }
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2e8 = (code ******)0x43f3b4;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43f3c1;
      pppppppcVar17 = (code *******)__vbaObjSet();
      ppppppcStack_2f0 = (code ******)0x0;
      ppppppcStack_2f8 = (code ******)0x43f3ce;
      ppppppcStack_2f4 = (code ******)pppppppcVar17;
      iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_2f8 = (code ******)0x8c;
        ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
        ppppppcStack_308 = (code ******)0x43f3e6;
        ppppppcStack_304 = (code ******)iVar6;
        ppppppcStack_300 = (code ******)pppppppcVar17;
        __vbaHresultCheckObj();
      }
      pcVar14 = __vbaFreeObj_exref;
      ppppppcStack_2f8 = (code ******)0x43f3f1;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2f8 = (code ******)&DAT_0050b420;
        ppppppcStack_2fc = (code ******)&DAT_00408c88;
        ppppppcStack_300 = (code ******)0x43f40a;
        __vbaNew2();
      }
      ppppppcStack_2f8 = (code ******)DAT_0050b420;
      ppppppcStack_2fc = (code ******)0x43f418;
      ppppppcStack_2fc = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_300 = &pppppcStack_18c;
      ppppppcStack_304 = (code ******)0x43f41f;
      pppppppcVar17 = (code *******)__vbaObjSet();
      ppppppcStack_304 = (code ******)0x0;
      ppppppcStack_30c = (code ******)0x43f42c;
      ppppppcStack_308 = (code ******)pppppppcVar17;
      iVar6 = (*(code *)(*pppppppcVar17)[0x23])();
      goto joined_r0x0043f430;
    }
  }
  goto LAB_00440949;
  while( true ) {
    ppppppcStack_1dc = (code ******)0x3;
    ppppppcStack_2d4 = (code ******)(int)sVar2;
    ppppppcStack_2dc = (code ******)0x3;
    ppppppcStack_2e0 = (code ******)0xa;
    ppppppcStack_2d8 = ppppppcStack_1d8;
    ppppppcStack_2e4 = appppppcStack_240[0];
    ppppppcStack_2d0 = ppppppcStack_1d0;
    ppppppcStack_2e8 = (code ******)0x43eaab;
    ppppppcStack_1d4 = ppppppcStack_2d4;
    __vbaLateIdSt();
    ppppppcStack_1dc = (code ******)0x3;
    ppppppcStack_2f8 = (code ******)0x26;
    ppppppcStack_2f4 = (code ******)0x3;
    ppppppcStack_1d4 = (code ******)0xff00;
    ppppppcStack_2f0 = ppppppcStack_1d8;
    ppppppcStack_2fc = appppppcStack_240[0];
    ppppppcStack_2ec = (code ******)0xff00;
    ppppppcStack_2e8 = ppppppcStack_1d0;
    ppppppcStack_300 = (code ******)0x43eae3;
    __vbaLateIdSt();
    pppppppcVar13 = (code *******)CONCAT22(extraout_var_03,sVar2 + 1);
    if (SCARRY2(sVar2,1)) break;
LAB_0043ea6c:
    pppppppcVar7 = pppppppcVar13;
    sVar2 = (short)pppppppcVar7;
    if ((short)(sVar3 + 5) < sVar2) {
      ppppppcStack_1cc = (code ******)0xa;
      pppppcStack_1bc = (code *****)0xa;
      ppppppcStack_1c4 = (code ******)0x80020004;
      ppppppcStack_1b4 = (code ******)0x80020004;
      ppppppcStack_1e4 = (code ******)0x40df04;
      ppppppcStack_1ec = (code ******)0x8;
      ppppppcStack_2d0 = (code ******)0x43eb32;
      __vbaVarDup();
      ppppppcStack_1d4 = (code ******)0x40dd2c;
      ppppppcStack_1dc = (code ******)0x8;
      ppppppcStack_2d0 = (code ******)0x43eb4a;
      __vbaVarDup();
      ppppppcStack_2d0 = (code ******)&ppppppcStack_1cc;
      ppppppcStack_2d4 = &pppppcStack_1bc;
      ppppppcStack_2d8 = (code ******)&ppppppcStack_1ac;
      ppppppcStack_2e0 = (code ******)&ppppppcStack_19c;
      ppppppcStack_2dc = (code ******)0x40;
      ppppppcStack_2e4 = (code ******)0x43eb62;
      Ordinal_595();
      ppppppcStack_2e4 = (code ******)&ppppppcStack_1cc;
      ppppppcStack_2e8 = &pppppcStack_1bc;
      ppppppcStack_2ec = (code ******)&ppppppcStack_1ac;
      ppppppcStack_2f0 = (code ******)&ppppppcStack_19c;
      ppppppcStack_2f4 = (code ******)0x4;
      ppppppcStack_2f8 = (code ******)0x43eb7a;
      __vbaFreeVarList();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2e4 = (code ******)&DAT_0050b420;
        ppppppcStack_2e8 = (code ******)&DAT_00408c88;
        ppppppcStack_2ec = (code ******)0x43eb96;
        __vbaNew2();
      }
      ppppppcStack_2e4 = (code ******)DAT_0050b420;
      ppppppcStack_2e8 = (code ******)0x43eba4;
      ppppppcStack_2e8 = (code ******)(*(code *)(*DAT_0050b420)[0xdc])();
      pppppppcVar17 = (code *******)__vbaObjSet_exref;
      ppppppcStack_2ec = &pppppcStack_18c;
      ppppppcStack_2f0 = (code ******)0x43ebb1;
      pppppppcVar13 = (code *******)__vbaObjSet();
      ppppppcStack_2f0 = (code ******)0x0;
      ppppppcStack_2f8 = (code ******)0x43ebbe;
      ppppppcStack_2f4 = (code ******)pppppppcVar13;
      iVar6 = (*(code *)(*pppppppcVar13)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_2f8 = (code ******)0x8c;
        ppppppcStack_2fc = (code ******)&DAT_0040bb6c;
        ppppppcStack_308 = (code ******)0x43ebd6;
        ppppppcStack_304 = (code ******)iVar6;
        ppppppcStack_300 = (code ******)pppppppcVar13;
        __vbaHresultCheckObj();
      }
      pppppppcVar16 = (code *******)__vbaFreeObj_exref;
      ppppppcStack_2f8 = (code ******)0x43ebe1;
      __vbaFreeObj();
      if (DAT_0050b420 == (code *******)0x0) {
        ppppppcStack_2f8 = (code ******)&DAT_0050b420;
        ppppppcStack_2fc = (code ******)&DAT_00408c88;
        ppppppcStack_300 = (code ******)0x43ebfa;
        __vbaNew2();
      }
      ppppppcStack_2f8 = (code ******)DAT_0050b420;
      ppppppcStack_2fc = (code ******)0x43ec08;
      ppppppcStack_2fc = (code ******)(*(code *)(*DAT_0050b420)[0xdd])();
      ppppppcStack_300 = &pppppcStack_18c;
      ppppppcStack_304 = (code ******)0x43ec0f;
      pppppppcVar7 = (code *******)__vbaObjSet();
      ppppppcStack_304 = (code ******)0x0;
      ppppppcStack_30c = (code ******)0x43ec1c;
      ppppppcStack_308 = (code ******)pppppppcVar7;
      iVar6 = (*(code *)(*pppppppcVar7)[0x23])();
      if (iVar6 < 0) {
        ppppppcStack_30c = (code ******)0x8c;
        __vbaHresultCheckObj(iVar6,pppppppcVar7,&DAT_0040bb6c);
      }
      ppppppcStack_30c = (code ******)0x43ec39;
      __vbaFreeObj();
      ppppppcStack_30c = (code ******)0x0;
      ppppppcStack_30c = (code ******)__vbaLateIdCallLd(&ppppppcStack_19c,appppppcStack_240[0],4);
      iVar6 = __vbaI4Var();
      pppppppcVar13 = (code *******)(iVar6 - DAT_0050b276);
      if (!SBORROW4(iVar6,(int)DAT_0050b276)) {
        ppppppcStack_1dc = (code ******)0x3;
        ppppppcStack_2e0 = (code ******)0x4;
        ppppppcStack_2dc = (code ******)0x3;
        ppppppcStack_2d8 = ppppppcStack_1d8;
        ppppppcStack_2e4 = appppppcStack_240[0];
        ppppppcStack_2d0 = ppppppcStack_1d0;
        ppppppcStack_2e8 = (code ******)0x43ec9a;
        ppppppcStack_2d4 = (code ******)pppppppcVar13;
        ppppppcStack_1d4 = (code ******)pppppppcVar13;
        __vbaLateIdSt();
        ppppppcStack_2e8 = (code ******)0x43eca3;
        __vbaFreeVar();
        goto switchD_0043e64f_caseD_5;
      }
      break;
    }
  }
LAB_00440949:
  ppppppcStack_2d0 = (code ******)0x44094f;
  __vbaErrorOverflow();
  ppppppcStack_2e0 = (code ******)&DAT_00402706;
  ppppppcStack_2e4 = ExceptionList;
  ppppppcStack_2dc = (code ******)&ppppppcStack_30c;
  ppppppcStack_2d8 = (code ******)&DAT_00401be8;
  ppppppcStack_2d4 = (code ******)((uint)ppppppcStack_2c8 & 1);
  ppppppcVar8 = (code ******)((uint)ppppppcStack_2c8 & 0xfffffffe);
  ExceptionList = &ppppppcStack_2e4;
  ppppppcStack_30c = (code ******)pppppppcVar17;
  ppppppcStack_308 = (code ******)pppppppcVar7;
  ppppppcStack_304 = (code ******)pppppppcVar16;
  ppppppcStack_2d0 = (code ******)&ppppppcStack_158;
  ppppppcStack_2c8 = ppppppcVar8;
  (*(code *)(*ppppppcVar8)[1])(ppppppcVar8);
  ppppppcStack_2e8 = (code ******)0x0;
  if (DAT_0050c53c == (int *)0x0) {
    __vbaNew2(&DAT_0040b420,&DAT_0050c53c);
  }
  piVar9 = DAT_0050c53c;
  ppppppcStack_300 = (code ******)*DAT_0050c53c;
  uVar10 = __vbaObjSetAddref(&ppppppcStack_2e8,ppppppcVar8);
  iVar6 = (**(code **)((int)ppppppcStack_300 + 0x10))(piVar9,uVar10);
  if (iVar6 < 0) {
    __vbaHresultCheckObj(iVar6,piVar9,&DAT_0040b410,0x10);
  }
  __vbaFreeObj();
  DAT_0050b210 = 0;
  DAT_0050b1e0 = 0;
  FUN_00444530();
  if ((DAT_0050b238 == 4) || (DAT_0050b238 == 7)) {
    DAT_0050b206 = 2;
  }
  else {
    DAT_0050b206 = 1;
  }
  DAT_0050b204 = 1;
  FUN_0044a9d0(&DAT_0050b204,&DAT_0050b206);
  return;
}


