function unquote(line) {
  const t = String(line).trim();
  if (t.startsWith('"') && t.endsWith('"')) return t.slice(1, -1);
  return t;
}

function tokensOf(text) {
  return String(text).replace(/^\uFEFF/, "").split(/\r?\n/).filter((line, idx, arr) => !(idx === arr.length - 1 && line === ""));
}

/**
 * TORA LP text layout, matched to the Reddy Mikks sample shipped with version 2.00.
 * Header integers, a title, n, m, sense, then n names / objective / bounds
 * with the file's blank padding quotes skipped after each of those rows.
 */
export function parseToraLP(text) {
  const lines = tokensOf(text);
  let i = 0;
  const next = () => {
    if (i >= lines.length) throw new Error("Target file does not match format of elected TORA module.");
    return lines[i++];
  };
  const magic = Number(next());
  if (magic !== 3000) throw new Error("Target file does not match format of elected TORA module.");
  next();
  next();
  next();
  const title = unquote(next());
  const nVars = Number(next());
  const nCons = Number(next());
  if (!Number.isInteger(nVars) || !Number.isInteger(nCons) || nVars < 1 || nCons < 1) {
    throw new Error("Meaningless or missing project data.");
  }
  const senseWord = unquote(next());
  const sense = /min/i.test(senseWord) ? "min" : "max";
  const readRow = () => {
    const vals = [];
    for (let k = 0; k < nVars; k++) vals.push(unquote(next()));
    while (i < lines.length && unquote(lines[i]) === "") i += 1;
    return vals;
  };
  const names = readRow();
  const obj = readRow();
  const constraints = [];
  for (let r = 0; r < nCons; r++) {
    const coef = [];
    for (let k = 0; k < nVars; k++) coef.push(unquote(next()));
    const rel = unquote(next()).trim() || "<=";
    const b = unquote(next());
    constraints.push({ name: `Constr ${r + 1}`, a: coef, rel, b });
  }
  const lb = readRow();
  const ub = readRow();
  const flags = readRow();
  const variables = names.map((name, k) => {
    const flag = (flags[k] || "n").trim().toLowerCase();
    const lower = lb[k] === "" ? "0" : lb[k];
    const unrestricted = /^-?inf/.test(String(lower).toLowerCase());
    return {
      name: name || `x${k + 1}`,
      c: obj[k] || "0",
      lb: lower,
      ub: ub[k] === "" ? "infinity" : ub[k],
      unrestricted,
      integer: flag === "y" || flag === "yes",
    };
  });
  return { title, sense, variables, constraints };
}

export function writeToraLP(model) {
  const n = model.variables.length;
  const m = model.constraints.length;
  const q = (s) => `"${String(s ?? "").replaceAll('"', "'")}"`;
  const pad = ["", ""];
  const lines = [
    "3000",
    String(m + 1),
    String(n),
    "1",
    q(model.title || ""),
    String(n),
    String(m),
    q(model.sense === "min" ? "Minimize" : "Maximize"),
  ];
  const pushRow = (vals) => {
    vals.forEach((v) => lines.push(q(v)));
    pad.forEach(() => lines.push(q("")));
  };
  pushRow(model.variables.map((v) => v.name || ""));
  pushRow(model.variables.map((v) => v.c ?? "0"));
  model.constraints.forEach((c) => {
    for (let k = 0; k < n; k++) lines.push(q(c.a[k] ?? "0"));
    const rel = c.rel === ">=" ? "        >=" : c.rel === "=" ? "        =" : "        <=";
    lines.push(q(rel));
    lines.push(q(c.b ?? "0"));
  });
  pushRow(model.variables.map((v) => (v.unrestricted ? "-infinity" : v.lb ?? "0")));
  pushRow(model.variables.map((v) => v.ub ?? "infinity"));
  pushRow(model.variables.map((v) => (v.integer ? "y" : "n")));
  return lines.join("\r\n") + "\r\n";
}
