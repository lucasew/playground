function num(v, label) {
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error(`${label} must be numeric.`);
  if (n < 0) throw new Error(`${label} cannot be negative.`);
  return n;
}

function prepare(activities, pert) {
  const acts = activities.map((a, i) => {
    const symbol = (a.symbol || String.fromCharCode(65 + i)).trim() || `A${i + 1}`;
    const from = Number(a.from);
    const to = Number(a.to);
    if (!Number.isInteger(from) || !Number.isInteger(to) || from < 1 || to < 1) {
      throw new Error("Node number must be >= 1.");
    }
    if (from === to) throw new Error("FROM and TO nodes must be assigned distinct numbers.");
    let duration;
    let optimistic;
    let likely;
    let pessimistic;
    let variance = 0;
    if (pert) {
      optimistic = num(a.a, "Minimum duration a");
      likely = num(a.m, "Most likely duration m");
      pessimistic = num(a.b, "Maximum duration b");
      if (!(optimistic <= likely && likely <= pessimistic)) {
        throw new Error("Duration data must satisfy a <= m <= b.");
      }
      duration = (optimistic + 4 * likely + pessimistic) / 6;
      variance = ((pessimistic - optimistic) / 6) ** 2;
    } else {
      duration = num(a.duration, "Duration");
    }
    return { symbol, from, to, duration, optimistic, likely, pessimistic, variance };
  });
  const seen = new Set();
  acts.forEach((a) => {
    const k = `${a.from}-${a.to}`;
    if (seen.has(k)) throw new Error(`Nodes defining ${a.symbol} have already been assigned to another activity.`);
    seen.add(k);
  });
  const nodes = new Set();
  acts.forEach((a) => {
    nodes.add(a.from);
    nodes.add(a.to);
  });
  return { acts, nodes: [...nodes].sort((a, b) => a - b) };
}

export function solveProject(activities, mode) {
  const pert = mode === "pert";
  const { acts, nodes } = prepare(activities, pert);
  const preds = new Map(nodes.map((n) => [n, []]));
  const succs = new Map(nodes.map((n) => [n, []]));
  acts.forEach((a) => {
    preds.get(a.to).push(a);
    succs.get(a.from).push(a);
  });
  const starts = nodes.filter((n) => preds.get(n).length === 0);
  const finishes = nodes.filter((n) => succs.get(n).length === 0);
  if (starts.length !== 1) {
    throw new Error(`MULTIPLE START detected at nodes (${starts.join(", ")}).`);
  }
  if (finishes.length !== 1) {
    throw new Error(`MULTIPLE FINISH detected at nodes (${finishes.join(", ")}).`);
  }
  const te = new Map(nodes.map((n) => [n, 0]));
  const order = topo(nodes, acts);
  order.forEach((n) => {
    preds.get(n).forEach((a) => {
      te.set(n, Math.max(te.get(n), te.get(a.from) + a.duration));
    });
  });
  const tl = new Map(nodes.map((n) => [n, te.get(finishes[0])]));
  [...order].reverse().forEach((n) => {
    const out = succs.get(n);
    if (!out.length) {
      tl.set(n, te.get(n));
      return;
    }
    let best = Infinity;
    out.forEach((a) => {
      best = Math.min(best, tl.get(a.to) - a.duration);
    });
    tl.set(n, best);
  });
  const rows = acts.map((a) => {
    const es = te.get(a.from);
    const ef = es + a.duration;
    const lf = tl.get(a.to);
    const ls = lf - a.duration;
    const tf = ls - es;
    const ff = te.get(a.to) - ef;
    return {
      symbol: a.symbol,
      from: a.from,
      to: a.to,
      duration: round(a.duration),
      mean: pert ? round(a.duration) : null,
      variance: pert ? round(a.variance) : null,
      a: pert ? round(a.optimistic) : null,
      m: pert ? round(a.likely) : null,
      b: pert ? round(a.pessimistic) : null,
      es: round(es),
      ef: round(ef),
      ls: round(ls),
      lf: round(lf),
      tf: round(tf),
      ff: round(ff),
      critical: Math.abs(tf) < 1e-6,
    };
  });
  const criticalEdges = acts.filter((a) => Math.abs((tl.get(a.to) - a.duration - te.get(a.from))) < 1e-6);
  const path = criticalPath(starts[0], finishes[0], criticalEdges);
  const pathMean = path.duration;
  const pathVar = path.edges.reduce((s, e) => s + e.variance, 0);
  return {
    mode,
    rows,
    nodes: nodes.map((n) => ({
      node: n,
      earliest: round(te.get(n)),
      latest: round(tl.get(n)),
    })),
    projectLength: round(te.get(finishes[0])),
    path: path.nodes.join(" → "),
    pathMean: round(pathMean),
    pathStd: round(Math.sqrt(pathVar)),
    start: starts[0],
    finish: finishes[0],
  };
}

function topo(nodes, acts) {
  const indeg = new Map(nodes.map((n) => [n, 0]));
  acts.forEach((a) => indeg.set(a.to, indeg.get(a.to) + 1));
  const q = nodes.filter((n) => indeg.get(n) === 0);
  const out = [];
  const fwd = new Map(nodes.map((n) => [n, []]));
  acts.forEach((a) => fwd.get(a.from).push(a.to));
  while (q.length) {
    const n = q.shift();
    out.push(n);
    fwd.get(n).forEach((m) => {
      indeg.set(m, indeg.get(m) - 1);
      if (indeg.get(m) === 0) q.push(m);
    });
  }
  if (out.length !== nodes.length) {
    throw new Error("Loop detected. Forward pass cannot proceed.");
  }
  return out;
}

function criticalPath(start, finish, edges) {
  const succ = new Map();
  edges.forEach((e) => {
    if (!succ.has(e.from)) succ.set(e.from, []);
    succ.get(e.from).push(e);
  });
  let best = { nodes: [start], edges: [], duration: 0 };
  function dfs(node, nodes, acc, dur) {
    if (node === finish) {
      best = { nodes: nodes.slice(), edges: acc.slice(), duration: dur };
      return;
    }
    (succ.get(node) || []).forEach((e) => {
      nodes.push(e.to);
      acc.push(e);
      dfs(e.to, nodes, acc, dur + e.duration);
      nodes.pop();
      acc.pop();
    });
  }
  dfs(start, [start], [], 0);
  return best;
}

function round(x) {
  if (!Number.isFinite(x)) return "—";
  return String(Math.round(x * 1e6) / 1e6);
}
