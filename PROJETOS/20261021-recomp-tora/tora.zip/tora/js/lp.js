import { BM, BM0, R0, R1, Rat, fmtBM, fmtRat, parseBound, rat } from "./rational.js";

const MAX_ITERS = 400;

function bm(real, big = 0) {
  return new BM(real, big);
}

function cloneModel(model) {
  return {
    sense: model.sense === "min" ? "min" : "max",
    title: model.title || "Untitled",
    variables: model.variables.map((v) => ({ ...v, c: v.c })),
    constraints: model.constraints.map((c) => ({ ...c, a: c.a.slice() })),
  };
}

function numOrZero(v) {
  if (v == null || v === "") return R0;
  if (v instanceof Rat) return v;
  return rat(v);
}

/**
 * Build a maximization problem in = form with nonnegative columns.
 * Upper bounds become extra <= rows. Unrestricted variables are split.
 */
function buildStandard(model) {
  const sense = model.sense === "min" ? "min" : "max";
  const sign = sense === "max" ? 1 : -1;
  const cols = [];
  const messages = [];
  let zOffset = R0;

  model.variables.forEach((v, idx) => {
    const name = (v.name || `x${idx + 1}`).trim() || `x${idx + 1}`;
    const cUser = numOrZero(v.c);
    const lbInfo = v.unrestricted ? { inf: -1, rat: null } : parseBound(v.lb == null || v.lb === "" ? "0" : v.lb);
    const ubInfo = parseBound(v.ub == null || v.ub === "" ? "infinity" : v.ub);
    let lb = lbInfo.inf === -1 ? null : lbInfo.inf === 1 ? null : lbInfo.rat;
    if (lbInfo.inf === 1) throw new Error(`Lower bound of ${name} cannot be +infinity.`);
    const ub = ubInfo.inf === 1 ? null : ubInfo.inf === -1 ? null : ubInfo.rat;
    if (ubInfo.inf === -1) throw new Error(`Upper bound of ${name} cannot be -infinity.`);
    if (lb && ub && lb.cmp(ub) > 0) {
      throw new Error(`Lower bound exceeds upper bound for variable ${name}. Reenter correct bounds.`);
    }
    const cInt = cUser.mul(rat(sign));
    if (lb == null && ub == null) {
      cols.push({ name: `${name}+`, key: name, c: cInt, part: "+" });
      cols.push({ name: `${name}-`, key: name, c: cInt.neg(), part: "-" });
      return;
    }
    if (lb == null && ub) {
      zOffset = zOffset.add(cInt.mul(ub));
      cols.push({ name, key: name, c: cInt.neg(), part: "flip", ub0: ub });
      return;
    }
    const L = lb || R0;
    zOffset = zOffset.add(cInt.mul(L));
    const upper = ub ? ub.sub(L) : null;
    cols.push({ name, key: name, c: cInt, part: "shift", lb0: L, upper });
  });

  const rows = [];
  model.constraints.forEach((con, idx) => {
    const name = con.name || `Constr ${idx + 1}`;
    let rel = String(con.rel || "<=").replace(/\s/g, "");
    if (rel === "<") rel = "<=";
    if (rel === ">") rel = ">=";
    if (!["<=", ">=", "="].includes(rel)) {
      throw new Error(`Constraint ${name}: enter <, >, or =.`);
    }
    let b = numOrZero(con.b);
    const coefs = cols.map(() => R0);
    let allZero = true;
    model.variables.forEach((v, vi) => {
      const a = numOrZero(con.a[vi] ?? 0);
      if (!a.isZero()) allZero = false;
      const targets = cols.filter((c) => c.key === (v.name || `x${vi + 1}`).trim() || c.key === `x${vi + 1}`);
      // key was set from the same name rule
    });
    // Fill coefficients by walking original variables in order.
    let cursor = 0;
    model.variables.forEach((v, vi) => {
      const aUser = numOrZero(con.a[vi] ?? 0);
      const col = cols[cursor];
      if (col.part === "+") {
        coefs[cursor] = aUser;
        coefs[cursor + 1] = aUser.neg();
        cursor += 2;
      } else if (col.part === "flip") {
        coefs[cursor] = aUser.neg();
        b = b.sub(aUser.mul(col.ub0));
        cursor += 1;
      } else {
        coefs[cursor] = aUser;
        b = b.sub(aUser.mul(col.lb0 || R0));
        cursor += 1;
      }
    });
    if (allZero) {
      if ((rel === "<=" && b.isNeg()) || (rel === ">=" && b.isPos()) || (rel === "=" && !b.isZero())) {
        throw new Error(`All Left-hand side coefficients of Constraint ${name} are zero. Reenter or delete constraint.`);
      }
      return;
    }
    if (b.isNeg()) {
      b = b.neg();
      for (let j = 0; j < coefs.length; j++) coefs[j] = coefs[j].neg();
      if (rel === "<=") rel = ">=";
      else if (rel === ">=") rel = "<=";
    }
    rows.push({ name, rel, a: coefs, b, source: idx });
  });

  cols.forEach((col) => {
    if (col.upper && col.upper.isPos()) {
      const a = cols.map(() => R0);
      const j = cols.indexOf(col);
      a[j] = R1;
      rows.push({
        name: `${col.key} upper`,
        rel: "<=",
        a,
        b: col.upper,
        source: -1,
        boundFor: col.key,
      });
    } else if (col.upper && col.upper.isZero()) {
      const a = cols.map(() => R0);
      a[cols.indexOf(col)] = R1;
      rows.push({ name: `${col.key} upper`, rel: "<=", a, b: R0, source: -1, boundFor: col.key });
    }
  });

  const bounded = cols.some((c) => c.upper != null) || model.variables.some((v) => {
    const lb = parseBound(v.unrestricted ? "-infinity" : v.lb == null || v.lb === "" ? "0" : v.lb);
    const ub = parseBound(v.ub == null || v.ub === "" ? "infinity" : v.ub);
    return v.unrestricted || lb.inf === -1 || (lb.rat && !lb.rat.isZero()) || ub.inf === 0;
  });

  return { sense, sign, cols, rows, zOffset, messages, bounded, title: model.title || "" };
}

function assemble(std, method) {
  const { cols, rows } = std;
  const structural = cols.map((c, j) => ({
    name: c.name,
    kind: "var",
    key: c.key,
    part: c.part,
    c: bm(c.c, 0),
    j,
  }));
  const extras = [];
  const body = [];
  const rhs = [];
  const rowMeta = [];
  const basis = [];

  const needArtificial = rows.some((r) => r.rel !== "<=");
  let useMethod = method;
  if (useMethod === "auto") {
    useMethod = needArtificial ? "two-phase" : "all-slack";
  }
  if (!needArtificial && (method === "auto" || method === "all-slack" || useMethod === "all-slack")) {
    std.messages.push("Problem has all <= constraints.  All-Slack option will be used");
  }
  if (useMethod === "all-slack" && needArtificial) {
    std.messages.push("Problem has >= and/or = constraints, thus requiring M or Two-phase method.  Two-phase method will be used. Else click CANCEL to use M-method");
    useMethod = "two-phase";
  }
  if (useMethod === "dual" && needArtificial) {
    std.messages.push("Dual simplex not applicable directly.  Two-phase method will be used; else click CANCEL to use M-method");
    useMethod = "two-phase";
  }
  if (useMethod === "dual" && std.bounded) {
    std.messages.push("Dual simplex not applicable because a var has upper/lower bound or is unrestricted.  Two-phase method will be used; else click CANCEL to use M-method");
    useMethod = "two-phase";
  }

  rows.forEach((r) => {
    body.push(r.a.map((x) => x));
    rhs.push(r.b);
    rowMeta.push(r);
  });

  const nStruct = structural.length;
  const colOf = [];
  structural.forEach((c) => colOf.push(c));

  function addExtra(name, kind, coefRows, cValue) {
    const col = { name, kind, c: cValue, j: colOf.length };
    colOf.push(col);
    extras.push(col);
    body.forEach((row, i) => row.push(coefRows[i]));
    return col;
  }

  rows.forEach((r, i) => {
    if (r.rel === "<=") {
      const coef = body.map((_, k) => (k === i ? R1 : R0));
      const col = addExtra(slackName(i), "slack", coef, bm(0));
      col.forRow = i;
      basis[i] = col.j;
    } else if (r.rel === ">=") {
      const sCoef = body.map((_, k) => (k === i ? R1.neg() : R0));
      const scol = addExtra(`Sur${i + 1}`, "surplus", sCoef, bm(0));
      scol.forRow = i;
      const aCoef = body.map((_, k) => (k === i ? R1 : R0));
      const artC = useMethod === "m-method" ? bm(0, -1) : bm(0);
      const acol = addExtra(`A${i + 1}`, "artificial", aCoef, artC);
      acol.forRow = i;
      basis[i] = acol.j;
    } else {
      const aCoef = body.map((_, k) => (k === i ? R1 : R0));
      const artC = useMethod === "m-method" ? bm(0, -1) : bm(0);
      const acol = addExtra(`A${i + 1}`, "artificial", aCoef, artC);
      acol.forRow = i;
      basis[i] = acol.j;
    }
  });

  const m = body.length;
  const n = colOf.length;
  const A = body.map((row, i) => row.concat([rhs[i]]));
  return { useMethod, colOf, basis, A, m, n, nStruct, rowMeta };
}

function slackName(i) {
  return `S${i + 1}`;
}

function recomputeZ(session) {
  const { A, basis, colOf, m, n } = session;
  const z = [];
  for (let j = 0; j <= n; j++) {
    let sum = BM0;
    for (let i = 0; i < m; i++) {
      sum = sum.add(colOf[basis[i]].cPhase.mulRat(A[i][j]));
    }
    if (j < n) sum = sum.sub(colOf[j].cPhase);
    z.push(sum);
  }
  session.z = z;
}

function setPhaseCosts(session, phase) {
  const { colOf } = session;
  colOf.forEach((c) => {
    if (phase === 1) {
      // Maximize −(sum of artificials). Optimum is 0 exactly when a feasible basis exists.
      c.cPhase = c.kind === "artificial" ? bm(-1) : bm(0);
    } else {
      c.cPhase = c.c;
    }
  });
  session.phase = phase;
  recomputeZ(session);
}

function snapshot(session, note) {
  const { A, z, basis, colOf, m, n, phase, userSense, zOffset, sign } = session;
  const columns = colOf.map((c) => c.name);
  const rows = [];
  for (let i = 0; i < m; i++) {
    rows.push({
      basic: colOf[basis[i]].name,
      cells: A[i].slice(0, n).map(fmtRat),
      rhs: fmtRat(A[i][n]),
    });
  }
  let zShow = z.map((v) => v);
  if (phase !== 1 && userSense === "min") zShow = zShow.map((v) => v.neg());
  const zValueInternal = z[n];
  let shownObj = zValueInternal;
  if (phase !== 1) {
    shownObj = zValueInternal.add(bm(zOffset));
    if (userSense === "min") shownObj = shownObj.neg();
  }
  session.tableaus.push({
    title: note,
    phase: phase === 1 ? "Phase 1" : "Phase 2",
    iteration: session.iteration,
    columns,
    zj: zShow.slice(0, n).map(fmtBM),
    zrhs: fmtBM(phase === 1 ? zValueInternal : shownObj),
    rows,
    entering: null,
    leaving: null,
  });
  return session.tableaus[session.tableaus.length - 1];
}

function pickEntering(session, forced) {
  const { z, basis, m, n } = session;
  const basic = new Set(basis);
  if (forced != null) {
    if (basic.has(forced)) throw new Error("Selection must be nonbasic.");
    const improving = z[forced].isNeg();
    if (!improving) {
      throw new Error(
        "If there is a tie, TORA always selects left-most TIED col only. Else, your selection is not consistent with Optimality Condition. Re-select or click NEXT/ALL ITERATIONS button."
      );
    }
    return forced;
  }
  let best = -1;
  for (let j = 0; j < n; j++) {
    if (basic.has(j)) continue;
    if (session.phase === 2 && session.colOf[j].kind === "artificial") continue;
    if (!z[j].isNeg()) continue;
    if (best < 0 || z[j].cmp(z[best]) < 0) best = j;
  }
  return best;
}

function pickLeaving(session, enter, forced) {
  const { A, m, n } = session;
  if (forced != null) {
    if (A[forced][enter].cmp(R0) <= 0) {
      throw new Error(
        "If there is a tie, TORA always selects top-most TIED row only. Else, your selection is not consistent with Feasiblity Condition. Reselect or clik NEXT/ALL ITERATIONS button."
      );
    }
    return forced;
  }
  let best = -1;
  let bestRatio = null;
  for (let i = 0; i < m; i++) {
    if (A[i][enter].cmp(R0) <= 0) continue;
    const ratio = A[i][n].div(A[i][enter]);
    if (best < 0 || ratio.cmp(bestRatio) < 0) {
      best = i;
      bestRatio = ratio;
    }
  }
  return best;
}

function pivot(session, enter, leave) {
  const { A, z, m, n } = session;
  const piv = A[leave][enter];
  const newRow = A[leave].map((v) => v.div(piv));
  A[leave] = newRow;
  for (let i = 0; i < m; i++) {
    if (i === leave) continue;
    const f = A[i][enter];
    if (f.isZero()) continue;
    for (let j = 0; j <= n; j++) A[i][j] = A[i][j].sub(newRow[j].mul(f));
  }
  const fz = z[enter];
  if (!fz.isZero()) {
    for (let j = 0; j <= n; j++) z[j] = z[j].sub(newRow[j] instanceof Rat ? fz.mulRat(newRow[j]) : fz.mulRat(newRow[j]));
  }
  session.basis[leave] = enter;
  session.iteration += 1;
}

function artificialBasicPositive(session) {
  const { basis, colOf, A, m, n } = session;
  for (let i = 0; i < m; i++) {
    if (colOf[basis[i]].kind === "artificial" && A[i][n].isPos()) return true;
  }
  return false;
}

function driveOutArtificials(session) {
  const { basis, colOf, A, m, n } = session;
  for (let i = 0; i < m; i++) {
    if (colOf[basis[i]].kind !== "artificial") continue;
    if (!A[i][n].isZero()) continue;
    for (let j = 0; j < n; j++) {
      if (colOf[j].kind === "artificial") continue;
      if (basis.includes(j)) continue;
      if (!A[i][j].isZero()) {
        pivot(session, j, i);
        break;
      }
    }
  }
}

function finishSolution(session, status) {
  const { colOf, basis, A, m, n, std, userSense } = session;
  const valueOf = new Map();
  colOf.forEach((c, j) => {
    if (c.kind !== "var") return;
    const row = basis.indexOf(j);
    valueOf.set(j, row >= 0 ? A[row][n] : R0);
  });
  const byKey = new Map();
  std.cols.forEach((c, j) => {
    const y = valueOf.get(j) || R0;
    let x;
    if (c.part === "+") x = y;
    else if (c.part === "-") x = y.neg();
    else if (c.part === "flip") x = c.ub0.sub(y);
    else x = (c.lb0 || R0).add(y);
    if (!byKey.has(c.key)) byKey.set(c.key, R0);
    byKey.set(c.key, byKey.get(c.key).add(x));
  });

  const zInternal = session.z[n].r.add(std.zOffset);
  const objective = userSense === "min" ? zInternal.neg() : zInternal;

  const variables = std.modelVars.map((v) => {
    const value = byKey.get(v.name) || R0;
    return {
      name: v.name,
      value: fmtRat(value),
      valueRat: value,
      contrib: fmtRat(numOrZero(v.c).mul(value)),
    };
  });

  const constraints = std.rows
    .filter((r) => r.source >= 0)
    .map((r) => {
      const i = std.rows.indexOf(r);
      let slack = R0;
      session.colOf.forEach((c, j) => {
        if (c.forRow !== i) return;
        const brow = basis.indexOf(j);
        const val = brow >= 0 ? A[brow][n] : R0;
        if (c.kind === "slack" || c.kind === "surplus") slack = val;
      });
      let dual = BM0;
      session.colOf.forEach((c, j) => {
        if (c.forRow !== i) return;
        if (r.rel === "<=" && c.kind === "slack") dual = session.z[j];
        if (r.rel !== "<=" && c.kind === "artificial") dual = session.z[j];
      });
      let dualR = dual.r;
      if (userSense === "min") dualR = dualR.neg();
      const shownSlack = r.rel === ">=" ? slack.neg() : slack;
      return {
        name: r.name,
        slack: fmtRat(shownSlack),
        dual: fmtRat(dualR),
        rel: r.rel,
      };
    });

  const ranges = sensitivity(session, byKey);
  return { status, objective: fmtRat(objective), objectiveRat: objective, variables, constraints, ranges };
}

function sensitivity(session, byKey) {
  const { A, z, basis, colOf, m, n, std, userSense } = session;
  const basic = new Set(basis);
  const varRanges = [];
  std.modelVars.forEach((v) => {
    const cols = std.cols.map((c, j) => ({ c, j })).filter((x) => x.c.key === v.name);
    if (cols.length !== 1 || cols[0].c.part !== "shift") {
      varRanges.push({ name: v.name, min: "—", max: "—", reduced: "—" });
      return;
    }
    const j = cols[0].j;
    const rc = userSense === "min" ? z[j].neg() : z[j];
    if (!basic.has(j)) {
      const reduced = rc;
      if (userSense === "max") {
        varRanges.push({
          name: v.name,
          reduced: fmtBM(reduced),
          min: "-infinity",
          max: reduced.m.isZero() ? fmtRat(numOrZero(v.c).add(reduced.r)) : "—",
        });
      } else {
        varRanges.push({
          name: v.name,
          reduced: fmtBM(reduced),
          min: reduced.m.isZero() ? fmtRat(numOrZero(v.c).add(reduced.r)) : "—",
          max: "infinity",
        });
      }
      return;
    }
    const row = basis.indexOf(j);
    let inc = null;
    let dec = null;
    for (let k = 0; k < n; k++) {
      if (basic.has(k)) continue;
      const a = A[row][k];
      if (a.isZero()) continue;
      const limit = z[k].r.div(a).neg();
      if (z[k].m && !z[k].m.isZero()) continue;
      if (a.isPos()) {
        if (dec == null || limit.cmp(dec) > 0) dec = limit;
      } else if (inc == null || limit.cmp(inc) < 0) inc = limit;
    }
    const c0 = numOrZero(v.c);
    const adj = userSense === "min" ? -1 : 1;
    const minC = dec == null ? (userSense === "max" ? "-infinity" : "infinity") : fmtRat(c0.add(dec.mul(rat(adj))));
    const maxC = inc == null ? (userSense === "max" ? "infinity" : "-infinity") : fmtRat(c0.add(inc.mul(rat(adj))));
    varRanges.push({ name: v.name, reduced: "0", min: userSense === "max" ? minC : maxC, max: userSense === "max" ? maxC : minC });
  });

  const conRanges = [];
  std.rows.forEach((r) => {
    if (r.source < 0) return;
    const slackCol = session.colOf.find((c) => c.forRow === std.rows.indexOf(r) && (r.rel === "<=" ? c.kind === "slack" : c.kind === "artificial"));
    if (!slackCol) {
      conRanges.push({ name: r.name, min: "—", max: "—" });
      return;
    }
    const j = slackCol.j;
    let inc = null;
    let dec = null;
    for (let i = 0; i < m; i++) {
      const a = A[i][j];
      if (a.isZero()) continue;
      const limit = A[i][n].div(a).neg();
      if (a.isPos()) {
        if (dec == null || limit.cmp(dec) > 0) dec = limit;
      } else if (inc == null || limit.cmp(inc) < 0) inc = limit;
    }
    const b0 = numOrZero(std.originalB[r.source]);
    conRanges.push({
      name: r.name,
      min: dec == null ? "-infinity" : fmtRat(b0.add(dec)),
      max: inc == null ? "infinity" : fmtRat(b0.add(inc)),
    });
  });
  return { variables: varRanges, constraints: conRanges };
}

function methodLabel(method, std) {
  const bounded = std.bounded ? "Bounded " : "";
  const map = {
    "all-slack": `(${bounded}Starting All-Slack Method)`,
    "two-phase": `(${bounded}Two-Phase Method)`,
    "m-method": `(${bounded}M-Method)`,
    dual: `(${bounded}Dual Simplex Method)`,
  };
  return map[method] || `(${bounded}Simplex Method)`;
}

export function solveLP(model, options = {}) {
  const method = options.method || "auto";
  const clean = cloneModel(model);
  clean.variables = clean.variables.map((v, i) => ({
    name: (v.name || `x${i + 1}`).trim() || `x${i + 1}`,
    c: v.c,
    lb: v.lb,
    ub: v.ub,
    unrestricted: !!v.unrestricted,
    integer: !!v.integer,
  }));
  const std = buildStandard(clean);
  std.modelVars = clean.variables;
  std.originalB = clean.constraints.map((c) => numOrZero(c.b));
  const built = assemble(std, method);
  const session = {
    ...built,
    std,
    userSense: clean.sense,
    zOffset: std.zOffset,
    sign: std.sign,
    iteration: 0,
    tableaus: [],
    z: [],
    phase: 2,
  };

  const label = methodLabel(session.useMethod, std);
  if (session.useMethod === "two-phase") {
    setPhaseCosts(session, 1);
    snapshot(session, "SIMPLEX TABLEAU - " + label + " Phase 1");
    const p1 = runPrimal(session, options);
    if (p1 === "unbounded") {
      return pack(session, "infeasible", "Problem has no feasible solution");
    }
    if (artificialBasicPositive(session) || session.z[session.n].isNeg()) {
      snapshot(session, "Phase 2 nixed.  Phase1 shows the problem has no feasible solution");
      return pack(session, "infeasible", "Problem has no feasible solution");
    }
    driveOutArtificials(session);
    setPhaseCosts(session, 2);
    session.messagesNote = "End of Phase 1: Feasible solution found--initiating Phase 2";
    snapshot(session, "SIMPLEX TABLEAU - " + label + " Phase 2");
  } else if (session.useMethod === "dual") {
    setPhaseCosts(session, 2);
    snapshot(session, "SIMPLEX TABLEAU - " + label);
    if (session.z.slice(0, session.n).some((v) => v.isNeg())) {
      std.messages.push("Dual Simplex not applicable directly.  All-slack will be used");
      session.useMethod = "all-slack";
    } else {
      const d = runDual(session);
      if (d === "infeasible") return pack(session, "infeasible", "Problem has no feasible solution");
      return pack(session, "optimal");
    }
  }

  if (session.phase !== 2 || session.useMethod !== "two-phase") {
    setPhaseCosts(session, 2);
    if (session.useMethod !== "two-phase") snapshot(session, "SIMPLEX TABLEAU - " + methodLabel(session.useMethod, std));
  }
  const result = runPrimal(session, options);
  if (result === "unbounded") {
    snapshot(session, "Last tableau shows solution is unbounded");
    return pack(session, "unbounded", "Optimum solution is unbounded");
  }
  return pack(session, "optimal");
}

function runPrimal(session, options) {
  const cap = options.maxIterations || MAX_ITERS;
  while (session.iteration < cap) {
    const enter = pickEntering(session, null);
    if (enter < 0) return "optimal";
    const leave = pickLeaving(session, enter, null);
    if (leave < 0) return "unbounded";
    const shot = session.tableaus[session.tableaus.length - 1];
    if (shot) {
      shot.entering = session.colOf[enter].name;
      shot.leaving = session.colOf[session.basis[leave]].name;
    }
    pivot(session, enter, leave);
    const tag = session.phase === 1 ? "Phase 1" : session.userSense === "min" ? "(Minimize)" : "(Maximize)";
    snapshot(session, "SIMPLEX TABLEAU - " + tag + " (Iter " + session.iteration);
  }
  throw new Error("Module Capacity Exceeded!");
}

function runDual(session) {
  const { A, z, m, n } = session;
  let guard = 0;
  while (guard++ < MAX_ITERS) {
    let leave = -1;
    for (let i = 0; i < m; i++) {
      if (A[i][n].isNeg() && (leave < 0 || A[i][n].cmp(A[leave][n]) < 0)) leave = i;
    }
    if (leave < 0) return "optimal";
    let enter = -1;
    let bestRatio = null;
    const basic = new Set(session.basis);
    for (let j = 0; j < n; j++) {
      if (basic.has(j)) continue;
      if (A[leave][j].cmp(R0) >= 0) continue;
      const ratio = z[j].r.div(A[leave][j].neg());
      if (enter < 0 || ratio.cmp(bestRatio) < 0) {
        enter = j;
        bestRatio = ratio;
      }
    }
    if (enter < 0) return "infeasible";
    const shot = session.tableaus[session.tableaus.length - 1];
    if (shot) {
      shot.entering = session.colOf[enter].name;
      shot.leaving = session.colOf[session.basis[leave]].name;
    }
    pivot(session, enter, leave);
    snapshot(session, "SIMPLEX TABLEAU - (Dual Simplex Method) (Iter " + session.iteration);
  }
  throw new Error("Module Capacity Exceeded!");
}

function pack(session, status, message) {
  const solved = status === "optimal" ? finishSolution(session, status) : {
    status,
    objective: "—",
    variables: session.std.modelVars.map((v) => ({ name: v.name, value: "—", contrib: "—" })),
    constraints: [],
    ranges: { variables: [], constraints: [] },
  };
  const alt = status === "optimal" && session.z.slice(0, session.n).some((v, j) => {
    if (session.basis.includes(j)) return false;
    if (session.colOf[j].kind !== "var") return false;
    return v.isZero();
  });
  return {
    status,
    message: message || (status === "optimal" ? (alt ? "-- Alternative solution(s) detected (enter ITERATIONS mode to determine such solutions)" : "OPTIMAL SOLUTION:") : message),
    messages: session.std.messages,
    method: session.useMethod,
    sense: session.userSense,
    title: session.std.title,
    tableaus: session.tableaus,
    ...solved,
    alternative: !!alt,
  };
}

export function solveGraphical(model) {
  if (model.variables.length !== 2) {
    throw new Error("Graphical LP needs exactly two variables.");
  }
  for (const v of model.variables) {
    if (v.unrestricted) {
      throw new Error("LPs with unrestricted vars and/or explicit upper/lower bounds are not supported by graphical method.");
    }
    const lb = parseBound(v.lb == null || v.lb === "" ? "0" : v.lb);
    const ub = parseBound(v.ub == null || v.ub === "" ? "infinity" : v.ub);
    if (lb.inf || (lb.rat && !lb.rat.isZero()) || ub.inf === 0) {
      throw new Error("LPs with unrestricted vars and/or explicit upper/lower bounds are not supported by graphical method.");
    }
  }
  const xName = model.variables[0].name || "x1";
  const yName = model.variables[1].name || "x2";
  const lines = [];
  const ineqs = [];
  model.constraints.forEach((con, idx) => {
    let a = numOrZero(con.a[0] ?? 0);
    let b = numOrZero(con.a[1] ?? 0);
    let c = numOrZero(con.b);
    let rel = String(con.rel || "<=").replace(/\s/g, "");
    if (rel === "<") rel = "<=";
    if (rel === ">") rel = ">=";
    const name = con.name || `C${idx + 1}`;
    if (a.isZero() && b.isZero()) return;
    lines.push({ name, a: a.toNumber(), b: b.toNumber(), c: c.toNumber(), rel });
    const pushIneq = (aa, bb, cc) => ineqs.push({ a: aa, b: bb, c: cc });
    if (rel === "<=") pushIneq(a, b, c);
    else if (rel === ">=") pushIneq(a.neg(), b.neg(), c.neg());
    else {
      pushIneq(a, b, c);
      pushIneq(a.neg(), b.neg(), c.neg());
    }
  });
  ineqs.push({ a: R1.neg(), b: R0, c: R0 });
  ineqs.push({ a: R0, b: R1.neg(), c: R0 });
  const bounds = [
    { a: R1, b: R0, c: null },
    { a: R0, b: R1, c: null },
    ...model.constraints.map((con) => {
      let a = numOrZero(con.a[0] ?? 0);
      let b = numOrZero(con.a[1] ?? 0);
      let c = numOrZero(con.b);
      return { a, b, c };
    }),
  ];
  const vertices = [];
  for (let i = 0; i < bounds.length; i++) {
    for (let j = i + 1; j < bounds.length; j++) {
      const A = bounds[i];
      const B = bounds[j];
      if (A.c == null || B.c == null) {
        // axis handled below with explicit lines x=0,y=0 already in bounds as a=1,c=0? I added axes as ineq only.
      }
    }
  }
  const eqLines = [
    { a: R1, b: R0, c: R0, name: `${xName}=0` },
    { a: R0, b: R1, c: R0, name: `${yName}=0` },
    ...model.constraints.map((con, idx) => ({
      a: numOrZero(con.a[0] ?? 0),
      b: numOrZero(con.a[1] ?? 0),
      c: numOrZero(con.b),
      name: con.name || `C${idx + 1}`,
    })),
  ];
  for (let i = 0; i < eqLines.length; i++) {
    for (let j = i + 1; j < eqLines.length; j++) {
      const A = eqLines[i];
      const B = eqLines[j];
      const det = A.a.mul(B.b).sub(A.b.mul(B.a));
      if (det.isZero()) continue;
      const x = A.c.mul(B.b).sub(A.b.mul(B.c)).div(det);
      const y = A.a.mul(B.c).sub(A.c.mul(B.a)).div(det);
      if (x.isNeg() || y.isNeg()) continue;
      const feasible = ineqs.every((iq) => iq.a.mul(x).add(iq.b.mul(y)).cmp(iq.c) <= 0);
      if (!feasible) continue;
      const key = `${fmtRat(x, 8)},${fmtRat(y, 8)}`;
      if (vertices.some((v) => v.key === key)) continue;
      const c1 = numOrZero(model.variables[0].c);
      const c2 = numOrZero(model.variables[1].c);
      const z = c1.mul(x).add(c2.mul(y));
      vertices.push({ key, x, y, z, xN: x.toNumber(), yN: y.toNumber(), zN: z.toNumber() });
    }
  }
  if (!vertices.length) {
    return { status: "infeasible", message: "Problem has no feasible solution", vertices: [], lines, xName, yName };
  }
  let best = vertices[0];
  for (const v of vertices) {
    const cmp = v.z.cmp(best.z);
    if ((model.sense === "min" && cmp < 0) || (model.sense !== "min" && cmp > 0)) best = v;
  }
  const lp = solveLP(model, { method: "auto" });
  vertices.forEach((v) => {
    v.optimal = v === best && lp.status === "optimal";
    v.x = fmtRat(v.x);
    v.y = fmtRat(v.y);
    v.z = fmtRat(v.z);
  });
  return {
    status: lp.status,
    message: lp.status === "unbounded" ? "Optimum solution is UNBOUNDED" : lp.message,
    objective: lp.status === "optimal" ? best.z : lp.objective,
    vertices,
    lines,
    xName,
    yName,
    point: lp.status === "optimal" ? { x: best.x, y: best.y, z: best.z } : null,
    lp,
  };
}

export function solveIP(model, options = {}) {
  const ints = model.variables.map((v, i) => !!v.integer);
  if (!ints.some(Boolean)) {
    const lp = solveLP(model, { method: options.method || "auto" });
    return { ...lp, nodes: [] };
  }
  const nodes = [];
  let best = null;
  let counter = 0;
  const queue = [{ bounds: model.variables.map(() => ({})), parent: null, branch: "root", depth: 0 }];
  const cap = options.nodeCap || 4000;
  while (queue.length && nodes.length < cap) {
    queue.sort((a, b) => {
      if (!a._bound && !b._bound) return 0;
      return 0;
    });
    const node = queue.shift();
    counter += 1;
    const trial = cloneModel(model);
    trial.variables = trial.variables.map((v, i) => {
      const bnd = node.bounds[i] || {};
      let lb = v.lb;
      let ub = v.ub;
      if (bnd.lb != null) lb = bnd.lb;
      if (bnd.ub != null) ub = bnd.ub;
      return { ...v, lb, ub, integer: false };
    });
    let solved;
    try {
      solved = solveLP(trial, { method: "auto" });
    } catch (err) {
      nodes.push({ id: counter, branch: node.branch, status: "error", note: err.message, depth: node.depth });
      continue;
    }
    const record = {
      id: counter,
      branch: node.branch,
      depth: node.depth,
      status: solved.status,
      objective: solved.objective,
      values: solved.variables.map((v) => v.value),
      parent: node.parent,
    };
    if (solved.status !== "optimal") {
      record.fathomed = solved.status;
      nodes.push(record);
      continue;
    }
    const z = solved.objectiveRat;
    if (best && ((model.sense === "min" && z.cmp(best.z) >= 0) || (model.sense !== "min" && z.cmp(best.z) <= 0))) {
      record.fathomed = "bound";
      nodes.push(record);
      continue;
    }
    let frac = -1;
    let fracDist = rat(0);
    solved.variables.forEach((v, i) => {
      if (!ints[i]) return;
      const val = v.valueRat;
      const nearest = rat(Math.round(val.toNumber()));
      const dist = val.sub(nearest).abs();
      if (dist.cmp(rat("0.0000001")) > 0 && dist.cmp(fracDist) > 0) {
        frac = i;
        fracDist = dist;
      }
    });
    if (frac < 0) {
      record.integer = true;
      record.fathomed = "integer";
      best = { z, solved, id: counter };
      nodes.push(record);
      continue;
    }
    record.branchVar = model.variables[frac].name || `x${frac + 1}`;
    record.branchValue = solved.variables[frac].value;
    nodes.push(record);
    const val = solved.variables[frac].valueRat.toNumber();
    const lo = Math.floor(val);
    const hi = Math.ceil(val);
    const left = { bounds: node.bounds.map((b) => ({ ...b })), parent: counter, depth: node.depth + 1 };
    const right = { bounds: node.bounds.map((b) => ({ ...b })), parent: counter, depth: node.depth + 1 };
    const prevL = left.bounds[frac].ub;
    const prevR = right.bounds[frac].lb;
    const ubLeft = prevL == null || prevL === "" || String(prevL).toLowerCase() === "infinity" ? String(lo) : String(Math.min(lo, Number(prevL)));
    const lbRight = prevR == null || prevR === "" ? String(hi) : String(Math.max(hi, Number(prevR)));
    left.bounds[frac].ub = ubLeft;
    right.bounds[frac].lb = lbRight;
    left.branch = `${record.branchVar} <= ${ubLeft}`;
    right.branch = `${record.branchVar} >= ${lbRight}`;
    queue.push(left, right);
  }
  if (nodes.length >= cap) {
    throw new Error("Number of examined subproblems exceeds 32,000.  Execution aborted");
  }
  return {
    status: best ? "optimal" : "infeasible",
    message: best ? "Found at subproblem " + best.id : "No feasible solution encountered",
    objective: best ? best.solved.objective : "—",
    variables: best ? best.solved.variables : model.variables.map((v) => ({ name: v.name, value: "—" })),
    nodes,
    bestId: best ? best.id : null,
    sense: model.sense,
    examined: counter,
  };
}
