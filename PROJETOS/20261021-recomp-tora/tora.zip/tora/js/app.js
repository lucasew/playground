import { forms } from "./forms.js";
import { solveGraphical, solveIP, solveLP } from "./lp.js";
import { solveTransport } from "./transport.js";
import { dijkstra, floyd, maxFlow, prim } from "./net.js";
import { solveQueue } from "./queue.js";
import { solveProject } from "./project.js";
import { solveGame } from "./games.js";
import { invert, solveEquations } from "./extra.js";
import { parseToraLP, writeToraLP } from "./io.js";

const state = {
  form: "splash",
  view: "",
  popup: null,
  pending: null,
  out: null,
  outputMode: "summary",
  reveal: 1,
  showM: false,
  modeNew: true,
  decimal: true,
  ns: "",
  nd: "",
  bigM: "",
  symmetrical: false,
  dirty: false,
  dialog: null,
  winX: 36,
  winY: 28,
  winMode: "restored",
  zoom: 1,
  sel: null,
  clip: null,
  undo: null,
  gameView: "",
  lp: blankLp(false),
  ip: blankLp(true),
  algebraN: 2,
  algebra: [["0", "0"], ["0", "0"]],
  eqN: 2,
  eqA: [["0", "0"], ["0", "0"]],
  rhs: ["0", "0"],
  transport: {
    method: "vogel",
    sources: ["", ""],
    dests: ["", ""],
    supply: ["0", "0"],
    demand: ["0", "0"],
    cost: [["0", "0"], ["0", "0"]],
  },
  queue: [{ lambda: "", mu: "", servers: "", systemLimit: "", sourceLimit: "" }],
  net: { mode: "dijkstra", start: "1", sink: "", edges: [["", "", ""]] },
  project: { mode: "cpm", rows: [["", "", "", "", "", "", ""]] },
  game: [["0", "0"], ["0", "0"]],
};

function blankLp(integer) {
  return {
    title: "",
    sense: "max",
    method: "auto",
    names: ["x1", "x2"],
    c: ["0", "0"],
    lb: ["0", "0"],
    ub: ["infinity", "infinity"],
    unrestricted: [false, false],
    integer: [integer, integer],
    cons: [
      ["C1", "0", "0", "<=", "0"],
      ["C2", "0", "0", "<=", "0"],
    ],
  };
}

const app = document.getElementById("app");
const fileInput = document.createElement("input");
fileInput.type = "file";
fileInput.id = "file-open";
fileInput.accept = ".txt,text/plain";
fileInput.className = "hidden";
document.body.append(fileInput);
document.body.addEventListener("click", onClick);
document.body.addEventListener("dblclick", onCaptionDbl);
document.body.addEventListener("mousedown", onCaptionDown);
document.body.addEventListener("mousemove", onCaptionMove);
document.body.addEventListener("mouseup", onCaptionUp);
document.body.addEventListener("input", onInput);
document.body.addEventListener("change", onChange);
document.body.addEventListener("keydown", onKey);
fileInput.addEventListener("change", onFile);
render();

function onInput(event) {
  const el = event.target;
  if (el.dataset.yn) {
    writePath(el.dataset.yn, /^y/i.test(el.value));
    state.dirty = true;
    return;
  }
  if (el.dataset.path) {
    writePath(el.dataset.path, el.type === "checkbox" ? el.checked : el.value);
    state.dirty = true;
    return;
  }
  if (el.dataset.field === "BX1") {
    setTitle(el.value);
    state.dirty = true;
  }
  if (el.dataset.field === "Check1") state.dirty = true;
  if (el.dataset.field === "NsText" || el.dataset.field === "nbrNsText") state.ns = el.value;
  if (el.dataset.field === "DsText" || el.dataset.field === "nbrDsText") state.nd = el.value;
  if (el.dataset.field === "TextBigM") state.bigM = el.value;
  if (el.dataset.field === "Check1") state.symmetrical = el.checked;
}

function onChange(event) {
  const el = event.target;
  if (el.dataset.field === "BX2" || el.dataset.field === "BX3") {
    applyCounts();
    render();
    return;
  }
  if (el.dataset.path && el instanceof HTMLSelectElement) render();
}

function onKey(event) {
  const field = event.target.dataset?.field;
  if (!field) return;
  if (event.key !== "Enter" && event.key !== "Tab") return;
  if (field === "BX1") setTitle(event.target.value);
  if (field === "BX2" || field === "BX3") applyCounts();
  if (event.key === "Enter" && (field === "BX1" || field === "BX2" || field === "BX3")) {
    event.preventDefault();
    render();
  }
}

function onFile() {
  const file = fileInput.files?.[0];
  fileInput.value = "";
  if (!file) return;
  file.text().then((text) => {
    const model = parseToraLP(text);
    const key = state.view === "ip" ? "ip" : "lp";
    state.view = key;
    state[key] = {
      title: model.title,
      sense: model.sense,
      method: state[key].method || "auto",
      names: model.variables.map((v) => v.name),
      c: model.variables.map((v) => String(v.c)),
      lb: model.variables.map((v) => String(v.lb)),
      ub: model.variables.map((v) => String(v.ub)),
      unrestricted: model.variables.map((v) => v.unrestricted),
      integer: model.variables.map((v) => v.integer || key === "ip"),
      cons: model.constraints.map((c) => [c.name, ...c.a.map(String), c.rel, String(c.b)]),
    };
    state.form = "input";
    state.out = null;
    state.popup = null;
    state.dirty = false;
    render();
  }).catch((err) => {
    window.alert(err.message || String(err));
  });
}

function onClick(event) {
  const hit = event.target.closest("[data-act]");
  if (!hit) {
    if (state.popup && !event.target.closest(".vb-menu")) {
      state.popup = null;
      render();
      return;
    }
    if (state.form === "solve" && event.target.closest(".vb-form") && !event.target.closest("input, select, textarea")) {
      const stage = document.querySelector(".stage");
      const at = popupOrigin(stage, event.clientX, event.clientY);
      state.popup = { items: solveItems(), x: at.x, y: at.y, stack: [] };
      render();
    }
    return;
  }
  const act = hit.dataset.act;
  try {
    if (act === "dlg") answerSave(hit.dataset.val);
    else if (act === "sub") return;
    else if (act === "win") setWinMode(hit.dataset.val);
    else if (act === "caption") {
      if (state.winMode !== "min") return;
      state.winMode = "restored";
    } else if (act === "ctl") CTL[hit.dataset.name]?.();
    else if (act === "bar") openBar(hit);
    else if (act === "menu") applyEntry(menuEntry(hit));
    else if (act === "sense") toggleSense();
    else if (act === "sel") state.sel = { axis: hit.dataset.axis, index: Number(hit.dataset.index) };
    else if (act === "mode") state.modeNew = hit.dataset.val === "new";
    else if (act === "fmt") state.decimal = hit.dataset.val === "dec";
  } catch (err) {
    window.alert(err.message || String(err));
  }
  render();
  if (state.form === "lpgraf" && state.out?.kind === "graph") paintGraph();
}

const CTL = {
  cmdClickHere() {
    state.form = "setup";
    state.popup = null;
  },
  cmdExitTora() {
    if (askSave("exit")) return;
    state.form = "splash";
    state.out = null;
    state.popup = null;
    state.showM = false;
    state.dialog = null;
  },
  cmdMainMenu() {
    if (state.form === "setup") openMenuAt("cmdMainMenu", mainItems());
    else {
      if (askSave("main")) return;
      state.form = "setup";
      state.popup = null;
      state.out = null;
      state.showM = false;
      state.dialog = null;
    }
  },
  cmdDone() {
    if (state.form === "setup") goInput();
    else if (state.form === "input") {
      state.form = "solve";
      state.popup = null;
      state.showM = false;
    } else if (state.form === "solve") {
      state.form = "outfmt";
      state.popup = null;
    } else if (state.form === "outfmt") runPending();
  },
  cmdModifyInputData() {
    state.form = "input";
    state.popup = null;
  },
  cmdNextIter() {
    state.outputMode = "iterations";
    state.reveal = (state.reveal || 1) + 1;
  },
  cmdFinalIter() {
    state.outputMode = "iterations";
    state.reveal = 999;
  },
  cmdWriteToPrinter() { window.print(); },
  cmdPrintGraph() { window.print(); },
  cmdZoomIn() { state.zoom = Math.min(8, (state.zoom || 1) * 1.25); },
  cmdZoomOut() { state.zoom = Math.max(0.25, (state.zoom || 1) / 1.25); },
};

function goInput() {
  if (!state.view) return;
  state.popup = null;
  state.out = null;
  if (!state.modeNew && (state.view === "lp" || state.view === "ip")) {
    fileInput.click();
    return;
  }
  state.form = "input";
  state.dirty = false;
}

function askSave(action) {
  if (state.form === "input" && state.dirty && !state.dialog) {
    state.dialog = action;
    return true;
  }
  return false;
}

function answerSave(val) {
  const action = state.dialog;
  state.dialog = null;
  if (val === "cancel" || !action) return;
  if (val === "yes" && (state.view === "lp" || state.view === "ip")) {
    download("tora-lp.txt", writeToraLP(lpModel(state[state.view])));
  }
  state.dirty = false;
  if (action === "exit") CTL.cmdExitTora();
  if (action === "main") CTL.cmdMainMenu();
}

function popupOrigin(stage, clientX, clientY) {
  const sr = stage.getBoundingClientRect();
  return {
    x: clientX - sr.left - stage.clientLeft,
    y: clientY - sr.top - stage.clientTop,
  };
}

function openBar(hit) {
  const items = hit.dataset.menu === "file" ? fileItems() : editItems();
  const stage = document.querySelector(".stage");
  const at = popupOrigin(stage, hit.getBoundingClientRect().left, hit.getBoundingClientRect().bottom);
  state.popup = { items, x: at.x, y: at.y, stack: [] };
}

function openMenuAt(name, items) {
  const btn = document.querySelector(`[data-name="${name}"]`);
  const stage = document.querySelector(".stage");
  if (!btn || !stage) {
    state.popup = { items, x: 8, y: 8, stack: [] };
    return;
  }
  const br = btn.getBoundingClientRect();
  const at = popupOrigin(stage, br.left, br.bottom);
  state.popup = { items, x: at.x, y: at.y, stack: [] };
}

function menuEntry(hit) {
  const depth = Number(hit.dataset.level);
  const i = Number(hit.dataset.i);
  if (depth === 0) return state.popup.items[i];
  return state.popup.stack[depth - 1]?.items[i];
}

function applyEntry(entry) {
  if (!entry) return;
  if (entry.view) {
    state.view = entry.view;
    if (entry.net) state.net.mode = entry.net;
    if (entry.proj) state.project.mode = entry.proj;
    state.form = "setup";
    state.out = null;
    state.popup = null;
    return;
  }
  if (entry.act === "exit") return CTL.cmdExitTora();
  if (entry.act === "main") {
    state.form = "setup";
    state.out = null;
    state.popup = null;
    return;
  }
  if (entry.act === "modify") {
    state.form = "input";
    state.popup = null;
    return;
  }
  if (entry.act === "save" || entry.act === "saveas") {
    if (state.view === "lp" || state.view === "ip") {
      download("tora-lp.txt", writeToraLP(lpModel(state[state.view])));
    }
    state.popup = null;
    return;
  }
  if (entry.edit) {
    editModel(entry.edit);
    state.popup = null;
    return;
  }
  if (entry.solve) {
    state.pending = entry.solve;
    state.gameView = entry.solve.game || "";
    state.popup = null;
    if (entry.solve.method && state.view === "lp") state.lp.method = entry.solve.method;
    if (entry.solve.method && state.view === "transport") state.transport.method = entry.solve.method;
    if (entry.solve.net) state.net.mode = entry.solve.net;
    if (entry.solve.mmethod) {
      state.showM = true;
      state.form = "solve";
      return;
    }
    if (entry.solve.kind === "graph") {
      state.lp.method = "graphical";
      runPending();
      return;
    }
    state.showM = false;
    state.form = "outfmt";
  }
}

function runPending() {
  const pending = state.pending || { kind: "solve" };
  try {
    if (pending.kind === "graph" || state.lp.method === "graphical" && state.view === "lp" && pending.kind === "graph") {
      state.out = { kind: "graph", data: solveGraphical(lpModel(state.lp)) };
      state.form = "lpgraf";
      state.zoom = 1;
      return;
    }
    const out = solveCurrent();
    if (out?.kind === "graph") {
      state.out = out;
      state.form = "lpgraf";
      state.zoom = 1;
      return;
    }
    state.out = out;
    state.outputMode = pending.kind === "iterations" ? "iterations" : "summary";
    state.reveal = pending.kind === "iterations" ? 1 : 999;
    state.form = "iter";
  } catch (err) {
    window.alert(err.message || String(err));
  }
}

function writePath(path, value) {
  const bits = path.split(".");
  let cur = state;
  for (let i = 0; i < bits.length - 1; i++) {
    const key = /^\d+$/.test(bits[i]) ? Number(bits[i]) : bits[i];
    cur = cur[key];
  }
  const last = /^\d+$/.test(bits.at(-1)) ? Number(bits.at(-1)) : bits.at(-1);
  cur[last] = value;
}

function setTitle(value) {
  if (state.view === "lp") state.lp.title = value;
  if (state.view === "ip") state.ip.title = value;
}

function getTitle() {
  if (state.view === "lp") return state.lp.title;
  if (state.view === "ip") return state.ip.title;
  return "";
}

function toggleSense() {
  if (state.view !== "lp" && state.view !== "ip") return;
  const m = state[state.view];
  m.sense = m.sense === "min" ? "max" : "min";
}

function lpModel(src) {
  return {
    title: src.title,
    sense: src.sense,
    variables: src.names.map((name, i) => ({
      name,
      c: src.c[i] || "0",
      lb: src.unrestricted[i] ? "-infinity" : (src.lb[i] || "0"),
      ub: src.ub[i] || "infinity",
      unrestricted: !!src.unrestricted[i],
      integer: !!src.integer[i],
    })),
    constraints: src.cons.map((row) => ({
      name: row[0] || "C",
      a: row.slice(1, -2),
      rel: row.at(-2),
      b: row.at(-1),
    })),
  };
}

function solveCurrent() {
  if (state.view === "lp") {
    const model = lpModel(state.lp);
    if (state.lp.method === "graphical") return { kind: "graph", data: solveGraphical(model) };
    return { kind: "lp", data: solveLP(model, { method: state.lp.method }) };
  }
  if (state.view === "ip") return { kind: "ip", data: solveIP(lpModel(state.ip)) };
  if (state.view === "inverse") return { kind: "inverse", data: invert(state.algebra) };
  if (state.view === "equations") return { kind: "equations", data: solveEquations(state.eqA, state.rhs) };
  if (state.view === "transport") {
    return {
      kind: "transport",
      data: solveTransport({
        cost: state.transport.cost,
        supply: state.transport.supply,
        demand: state.transport.demand,
      }, state.transport.method),
    };
  }
  if (state.view === "queue") return { kind: "queue", data: solveQueue(state.queue) };
  if (state.view === "network") return { kind: "network", data: solveNet() };
  if (state.view === "project") return { kind: "project", data: solveProj() };
  if (state.view === "games") return { kind: "game", data: solveGame(state.game) };
  return null;
}

function solveNet() {
  const edges = state.net.edges
    .filter((e) => e[0] && e[1] && e[2] !== "")
    .map(([from, to, weight]) => ({ from, to, weight }));
  if (state.net.mode === "dijkstra") return { mode: "dijkstra", ...dijkstra(edges, state.net.start) };
  if (state.net.mode === "floyd") return { mode: "floyd", ...floyd(edges) };
  if (state.net.mode === "flow") return { mode: "flow", ...maxFlow(edges, state.net.start, state.net.sink) };
  return { mode: "mst", ...prim(edges, state.net.start) };
}

function solveProj() {
  const rows = state.project.rows.filter((r) => r[1] && r[2]);
  const activities = rows.map((r) => ({
    symbol: r[0], from: r[1], to: r[2], duration: r[3], a: r[4], m: r[5], b: r[6],
  }));
  return solveProject(activities, state.project.mode);
}

function bag() {
  return {
    lp: state.lp, ip: state.ip, algebraN: state.algebraN, algebra: state.algebra,
    eqN: state.eqN, eqA: state.eqA, rhs: state.rhs, transport: state.transport,
    queue: state.queue, net: state.net, project: state.project, game: state.game,
  };
}

function snapshot() {
  state.undo = JSON.stringify(bag());
}

function editModel(kind) {
  if (kind === "undo") {
    if (!state.undo) return;
    Object.assign(state, JSON.parse(state.undo));
    state.undo = null;
    return;
  }
  snapshot();
  if (kind === "copy") copySel();
  else if (kind === "paste") pasteSel();
  else if (kind === "insert") insertSel();
  else if (kind === "delete") deleteSel();
}

function insertSel() {
  const axis = state.sel?.axis || "col";
  const v = state.view;
  if (v === "lp" || v === "ip") {
    if (axis === "row") insertCons(v, state.sel?.index);
    else insertVar(v, state.sel?.axis === "col" ? state.sel.index : null);
  } else if (v === "transport") {
    mutateTransport(axis === "row" ? "sources" : "dests", 1);
  } else if (v === "games") {
    if (axis === "row") state.game.push(state.game[0].map(() => "0"));
    else state.game.forEach((row) => row.push("0"));
  } else if (v === "queue") {
    state.queue.push({ lambda: "", mu: "", servers: "", systemLimit: "", sourceLimit: "" });
  } else if (v === "network") state.net.edges.push(["", "", ""]);
  else if (v === "project") state.project.rows.push(["", "", "", "", "", "", ""]);
  else if (v === "inverse") setAlg("inverse", state.algebraN + 1);
  else if (v === "equations") setAlg("equations", state.eqN + 1);
}

function deleteSel() {
  const axis = state.sel?.axis || "col";
  const v = state.view;
  if (v === "lp" || v === "ip") {
    if (axis === "row") deleteCons(v, state.sel?.index);
    else deleteVar(v, state.sel?.axis === "col" ? state.sel.index : state[v].names.length - 1);
  } else if (v === "transport") {
    mutateTransport(axis === "row" ? "sources" : "dests", -1);
  } else if (v === "games") {
    if (axis === "row") { if (state.game.length > 1) state.game.pop(); }
    else if (state.game[0].length > 1) state.game.forEach((row) => row.pop());
  } else if (v === "queue") { if (state.queue.length > 1) state.queue.pop(); }
  else if (v === "network") { if (state.net.edges.length > 1) state.net.edges.pop(); }
  else if (v === "project") { if (state.project.rows.length > 1) state.project.rows.pop(); }
  else if (v === "inverse") setAlg("inverse", state.algebraN - 1);
  else if (v === "equations") setAlg("equations", state.eqN - 1);
}

function insertVar(key, index) {
  const m = state[key];
  if (m.names.length >= 12) return;
  const i = index == null ? m.names.length : Math.max(0, Math.min(index, m.names.length));
  m.names.splice(i, 0, "x" + (m.names.length + 1));
  m.c.splice(i, 0, "0");
  m.lb.splice(i, 0, "0");
  m.ub.splice(i, 0, "infinity");
  m.unrestricted.splice(i, 0, false);
  m.integer.splice(i, 0, key === "ip");
  m.cons.forEach((row) => row.splice(i + 1, 0, "0"));
}

function deleteVar(key, index) {
  const m = state[key];
  if (m.names.length <= 1) return;
  const i = Math.max(0, Math.min(index, m.names.length - 1));
  m.names.splice(i, 1);
  m.c.splice(i, 1);
  m.lb.splice(i, 1);
  m.ub.splice(i, 1);
  m.unrestricted.splice(i, 1);
  m.integer.splice(i, 1);
  m.cons.forEach((row) => row.splice(i + 1, 1));
}

function insertCons(key, index) {
  const m = state[key];
  if (m.cons.length >= 16) return;
  const i = index == null ? m.cons.length : Math.max(0, Math.min(index, m.cons.length));
  m.cons.splice(i, 0, ["C" + (m.cons.length + 1), ...m.names.map(() => "0"), "<=", "0"]);
}

function deleteCons(key, index) {
  const m = state[key];
  if (m.cons.length <= 1) return;
  const i = index == null ? m.cons.length - 1 : Math.max(0, Math.min(index, m.cons.length - 1));
  m.cons.splice(i, 1);
}

function mutateTransport(which, dir) {
  const t = state.transport;
  if (which === "sources") {
    if (dir > 0 && t.sources.length < 8) {
      t.sources.push("");
      t.supply.push("0");
      t.cost.push(t.dests.map(() => "0"));
    } else if (dir < 0 && t.sources.length > 1) {
      t.sources.pop();
      t.supply.pop();
      t.cost.pop();
    }
  } else if (dir > 0 && t.dests.length < 8) {
    t.dests.push("");
    t.demand.push("0");
    t.cost.forEach((row) => row.push("0"));
  } else if (dir < 0 && t.dests.length > 1) {
    t.dests.pop();
    t.demand.pop();
    t.cost.forEach((row) => row.pop());
  }
}

function setAlg(which, n) {
  n = Math.min(8, Math.max(1, n));
  if (which === "equations") {
    state.eqN = n;
    state.eqA = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => state.eqA[i]?.[j] ?? "0"));
    state.rhs = Array.from({ length: n }, (_, i) => state.rhs[i] ?? "0");
  } else {
    state.algebraN = n;
    state.algebra = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => state.algebra[i]?.[j] ?? "0"));
  }
}

function copySel() {
  const sel = state.sel;
  if (!sel) return;
  const v = state.view;
  if ((v === "lp" || v === "ip") && sel.axis === "col") {
    const m = state[v];
    const i = sel.index;
    state.clip = {
      view: v, axis: "col",
      name: m.names[i], c: m.c[i], lb: m.lb[i], ub: m.ub[i],
      unrestricted: m.unrestricted[i], integer: m.integer[i],
      coeffs: m.cons.map((row) => row[i + 1]),
    };
    return;
  }
  if ((v === "lp" || v === "ip") && sel.axis === "row") {
    state.clip = { view: v, axis: "row", row: state[v].cons[sel.index].slice() };
    return;
  }
  state.clip = { view: v, axis: sel.axis, index: sel.index, raw: JSON.stringify(bag()) };
}

function pasteSel() {
  const sel = state.sel;
  const clip = state.clip;
  if (!sel || !clip) return;
  if (clip.axis !== sel.axis) {
    window.alert("Mismatch: Copy of Row(column) cannot be pasted on column(row)");
    return;
  }
  const v = state.view;
  if ((v === "lp" || v === "ip") && clip.view === v && sel.axis === "col" && clip.coeffs) {
    const m = state[v];
    const i = sel.index;
    if (clip.coeffs.length !== m.cons.length) {
      window.alert("Mismatch: Copy of Row(column) cannot be pasted on column(row)");
      return;
    }
    m.names[i] = clip.name;
    m.c[i] = clip.c;
    m.lb[i] = clip.lb;
    m.ub[i] = clip.ub;
    m.unrestricted[i] = clip.unrestricted;
    m.integer[i] = clip.integer;
    m.cons.forEach((row, r) => { row[i + 1] = clip.coeffs[r]; });
    return;
  }
  if ((v === "lp" || v === "ip") && clip.view === v && sel.axis === "row" && clip.row) {
    const m = state[v];
    if (clip.row.length !== m.cons[sel.index].length) {
      window.alert("Mismatch: Copy of Row(column) cannot be pasted on column(row)");
      return;
    }
    m.cons[sel.index] = clip.row.slice();
  }
}

function counts() {
  const v = state.view;
  if (v === "lp" || v === "ip") return [state[v].names.length, state[v].cons.length];
  if (v === "inverse") return [state.algebraN, state.algebraN];
  if (v === "equations") return [state.eqN, state.eqN];
  if (v === "transport") return [state.transport.sources.length, state.transport.dests.length];
  if (v === "queue") return [state.queue.length, 1];
  if (v === "network") return [1, state.net.edges.length];
  if (v === "project") return [1, state.project.rows.length];
  if (v === "games") return [state.game[0].length, state.game.length];
  return [0, 0];
}

function clamp(text, lo, hi, fallback) {
  const n = Number.parseInt(String(text), 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, n));
}

function applyCounts() {
  const a = document.querySelector("[data-field='BX2']");
  const b = document.querySelector("[data-field='BX3']");
  if (!a || !b || !state.view) return;
  const now = counts();
  const n = clamp(a.value, 1, 12, now[0]);
  const m = clamp(b.value, 1, 16, now[1]);
  const v = state.view;
  if (v === "lp" || v === "ip") {
    while (state[v].names.length < n) insertVar(v, null);
    while (state[v].names.length > n) deleteVar(v, state[v].names.length - 1);
    while (state[v].cons.length < m) insertCons(v, null);
    while (state[v].cons.length > m) deleteCons(v, null);
  } else if (v === "inverse") setAlg("inverse", n);
  else if (v === "equations") setAlg("equations", n);
  else if (v === "transport") {
    while (state.transport.sources.length < n) mutateTransport("sources", 1);
    while (state.transport.sources.length > n) mutateTransport("sources", -1);
    while (state.transport.dests.length < m) mutateTransport("dests", 1);
    while (state.transport.dests.length > m) mutateTransport("dests", -1);
  } else if (v === "queue") {
    while (state.queue.length < n) state.queue.push({ lambda: "", mu: "", servers: "", systemLimit: "", sourceLimit: "" });
    while (state.queue.length > n && state.queue.length > 1) state.queue.pop();
    if (state.queue[0]) state.queue[0].servers = String(m);
  } else if (v === "network") {
    while (state.net.edges.length < m) state.net.edges.push(["", "", ""]);
    while (state.net.edges.length > m && state.net.edges.length > 1) state.net.edges.pop();
  } else if (v === "project") {
    while (state.project.rows.length < m) state.project.rows.push(["", "", "", "", "", "", ""]);
    while (state.project.rows.length > m && state.project.rows.length > 1) state.project.rows.pop();
  } else if (v === "games") {
    while (state.game.length < m) state.game.push(state.game[0].map(() => "0"));
    while (state.game.length > m && state.game.length > 1) state.game.pop();
    while (state.game[0].length < n) state.game.forEach((row) => row.push("0"));
    while (state.game[0].length > n && state.game[0].length > 1) state.game.forEach((row) => row.pop());
  }
}

function fileItems() {
  return [
    { cap: "&Save", act: "save" },
    { cap: "Save &As", act: "saveas" },
    { cap: "Main Menu", act: "main" },
    { cap: "E&xit TORA", act: "exit" },
  ];
}

function editItems() {
  return [
    { cap: "&Undo Last Insert, Paste, Or Delete", edit: "undo" },
    { cap: "&Copy Column or Row", edit: "copy" },
    { cap: "&Paste on Column or Row", edit: "paste" },
    { cap: "&Delete Column or Row", edit: "delete" },
    { cap: "&Insert column or Row", edit: "insert" },
  ];
}

function mainItems() {
  return [
    { cap: "             MAIN", dead: true },
    { sep: true },
    { cap: "Linear Equations", children: [
      { cap: "Matri&x Inversion", view: "inverse" },
      { cap: "&Linear Equations Solution", view: "equations" },
    ] },
    { cap: "&Linear Programming", view: "lp" },
    { cap: "&Transportation model", view: "transport" },
    { cap: "&Integer programming", view: "ip" },
    { cap: "Network models", children: [
      { cap: "&Minimal Spanning Tree", view: "network", net: "mst" },
      { cap: "Shortest Route ", view: "network", net: "dijkstra" },
      { cap: "Maximal &Flow", view: "network", net: "flow" },
    ] },
    { cap: "Project Planning", children: [
      { cap: "&CPM - Critical Path Method ", view: "project", proj: "cpm" },
      { cap: "&PERT - Program Evaluation &&  Review Technique", view: "project", proj: "pert" },
    ] },
    { cap: "&Queuing analysis", view: "queue" },
    { cap: "&Zero-Sum Games", view: "games" },
    { sep: true },
    { cap: "&EXIT TORA", act: "exit" },
  ];
}

function tailItems() {
  return [
    { cap: "&View/Modify Input Data", act: "modify" },
    { sep: true },
    { cap: "&MAIN Menu", act: "main" },
    { sep: true },
    { cap: "&Exit TORA", act: "exit" },
  ];
}

function solveItems() {
  const v = state.view;
  const head = [
    { cap: "   SOLVE/MODIFY", dead: true },
    { sep: true },
  ];
  let body;
  if (v === "lp") {
    body = [{
      cap: "Solve Problem",
      children: [
        { cap: "&Graphical", solve: { kind: "graph" } },
        {
          cap: "Algebraic",
          children: [
            { cap: "&Final solution", solve: { kind: "summary", method: "auto" } },
            {
              cap: "Iterations",
              children: [
                { cap: "&All-slack starting solution", solve: { kind: "iterations", method: "all-slack" } },
                { cap: "&M-method", solve: { kind: "iterations", method: "m-method", mmethod: true } },
                { cap: "&Two-phase method", solve: { kind: "iterations", method: "two-phase" } },
                { cap: "&Bounded simplex ", solve: { kind: "iterations", method: "all-slack" } },
                { cap: "&Dual simplex", solve: { kind: "iterations", method: "dual" } },
              ],
            },
          ],
        },
      ],
    }];
  } else if (v === "transport") {
    body = [{
      cap: "Solve Problem",
      children: [
        { cap: "&Final solution", solve: { kind: "summary" } },
        {
          cap: "Iterations",
          children: [
            { cap: "&North-west corner starting solution", solve: { kind: "iterations", method: "northwest" } },
            { cap: "&Least-cost starting solution", solve: { kind: "iterations", method: "least" } },
            { cap: "&Vogel's starting solution", solve: { kind: "iterations", method: "vogel" } },
          ],
        },
      ],
    }];
  } else if (v === "games") {
    body = [{
      cap: "Solve Problem",
      children: [
        { cap: "&Graphical", solve: { kind: "summary", game: "graph" } },
        { cap: "&LP-based", solve: { kind: "summary", game: "lp" } },
      ],
    }];
  } else if (v === "network" && (state.net.mode === "dijkstra" || state.net.mode === "floyd")) {
    body = [{
      cap: "Solve Problem",
      children: [
        { cap: "&Shortest routes", solve: { kind: "summary" } },
        {
          cap: "&Iterations",
          children: [
            { cap: "&Dijkstra's algorithm", solve: { kind: "iterations", net: "dijkstra" } },
            { cap: "&Floyd's algorithm", solve: { kind: "iterations", net: "floyd" } },
          ],
        },
      ],
    }];
  } else if (v === "ip") {
    body = [{ cap: "Solve Problem", solve: { kind: "solve" } }];
  } else {
    body = [{ cap: "&Solve Problem", solve: { kind: "solve" } }];
  }
  return head.concat(body, tailItems());
}

const ITER_IP = new Set(["Frame12", "Check2", "Label19", "Label18", "Label17", "Label16", "Frame10", "Label11", "Label10", "Label8", "Label7", "Frame3", "BBGrid"]);
const ITER_TRANS = new Set(["Frame6", "Combo5"]);
const ITER_SHORT = new Set(["Frame7", "Frame9", "Combo4", "Frame8", "Combo3", "Frame5", "Combo2", "Label2"]);
const ITER_STEPS = new Set(["Frame2", "cmdNextIter", "cmdFinalIter", "cmdWriteToPrinter"]);
const LPG_CPM = new Set(["Frame3", "Text2", "Text1", "Combo2", "Combo1", "Label3", "Label2", "Label1", "gridChart", "List1"]);
const LPG_LP = new Set(["Frame4", "Label7", "Label6", "Label5", "picLPgraph", "Frame1", "cmdPrintGraph", "cmdZoomOut", "cmdZoomIn"]);

function shown(form, item) {
  const n = item.name;
  if (form === "input") {
    if (n === "Frame2" || n === "Check1" || n === "Label4") return state.view === "network";
    if (n === "Label8") return state.view === "games";
    return true;
  }
  if (form === "solve") {
    if (n === "Frame3" || n === "cmdDone" || n === "TextBigM" || n === "Label10") return state.view === "lp" && state.showM;
    return true;
  }
  if (form === "lpgraf") {
    if (LPG_CPM.has(n)) return state.view === "project";
    if (LPG_LP.has(n)) return state.view === "lp";
    return true;
  }
  if (form === "iter") {
    if (ITER_IP.has(n)) return state.view === "ip";
    if (ITER_TRANS.has(n)) return state.view === "transport";
    if (ITER_SHORT.has(n)) return state.view === "network" && (state.net.mode === "dijkstra" || state.net.mode === "floyd");
    if (ITER_STEPS.has(n)) {
      return state.view === "lp" || state.view === "transport" || (state.view === "network" && (state.net.mode === "dijkstra" || state.net.mode === "floyd"));
    }
    return true;
  }
  return true;
}

let captionDrag = null;

function onCaptionDbl(event) {
  if (!event.target.closest(".caption") || event.target.closest("button")) return;
  state.winMode = state.winMode === "max" ? "restored" : "max";
  render();
}

function onCaptionDown(event) {
  if (event.button !== 0) return;
  const cap = event.target.closest(".caption");
  if (!cap || event.target.closest("button")) return;
  event.preventDefault();
  if (state.winMode !== "restored") return;
  const win = cap.closest(".win");
  const rect = win.getBoundingClientRect();
  captionDrag = { dx: event.clientX - rect.left, dy: event.clientY - rect.top, win };
}

function onCaptionMove(event) {
  if (!captionDrag) return;
  state.winX = event.clientX - captionDrag.dx;
  state.winY = Math.max(0, event.clientY - captionDrag.dy);
  captionDrag.win.style.left = state.winX + "px";
  captionDrag.win.style.top = state.winY + "px";
}

function onCaptionUp() {
  captionDrag = null;
}

function setWinMode(mode) {
  if (mode === "min") state.winMode = "min";
  else state.winMode = state.winMode === "max" ? "restored" : "max";
}

function windowShell(width) {
  const win = el("div", "win stage");
  if (state.winMode === "max") win.classList.add("max");
  else if (state.winMode === "min") win.classList.add("min");
  else {
    win.style.left = state.winX + "px";
    win.style.top = state.winY + "px";
    win.style.width = width + "px";
  }
  win.append(captionBar());
  return win;
}

function render() {
  app.replaceChildren();
  if (state.form === "input") {
    renderInput();
    return;
  }
  const spec = forms[state.form];
  if (!spec) return;
  const stage = windowShell(spec.w);
  const body = el("div", "win-body");
  const form = el("div", "vb-form");
  form.style.width = spec.w + "px";
  form.style.height = spec.h + "px";
  if (state.form === "iter" && state.out) {
    const host = el("div", "vb-print");
    host.id = "result";
    host.style.width = (spec.w - 8) + "px";
    host.style.height = "228px";
    host.style.left = "4px";
    host.style.top = "4px";
    host.innerHTML = renderOut(state.out);
    form.append(host);
  }
  spec.items.forEach((item) => {
    if (item.kind !== "ctl") return;
    if (!shown(state.form, item)) return;
    form.append(paintCtl(item));
  });
  body.append(form);
  stage.append(body);
  app.append(stage);
  appendPopup(stage);
  if (state.form === "lpgraf" && state.out?.kind === "graph") paintGraph();
}

function renderInput() {
  const stage = windowShell(980);
  stage.classList.add("input-win");
  const body = el("div", "win-body");
  body.append(menuBar());
  const client = el("div", "tora-client");
  const title = el("div", "mod-title");
  title.textContent = moduleTitle();
  client.append(title);
  client.append(el("div", "rule"));
  const head = el("div", "tora-head");
  const fields = el("div", "tora-fields");
  fields.append(fieldRow("Problem Title:", "BX1", true));
  const labels = countLabels();
  fields.append(fieldRow(labels[0], "BX2", false));
  fields.append(fieldRow(labels[1], "BX3", false));
  if (state.view === "network") {
    const row = el("div", "field-row");
    const box = document.createElement("input");
    box.type = "checkbox";
    box.className = "vb-chk";
    box.dataset.field = "Check1";
    box.checked = state.symmetrical;
    const lab = document.createElement("label");
    lab.textContent = "Check here if network is symmetrical";
    row.append(box, lab);
    fields.append(row);
  }
  if (state.view === "games") {
    const note = el("div", "pay-note");
    note.textContent = " (Payoff must be for Player A)";
    fields.append(note);
  }
  const help = el("div", "tora-help");
  help.textContent = helpText();
  head.append(fields, help);
  client.append(head);
  client.append(el("div", "rule"));
  const panel = el("div", "cyan-panel");
  const gridTitleEl = el("div", "grid-title");
  gridTitleEl.textContent = gridTitle();
  panel.append(gridTitleEl);
  const grid = el("div", "vb-grid runtime-grid");
  fillInputGrid(grid);
  panel.append(grid);
  client.append(panel);
  const buttons = el("div", "tora-buttons");
  buttons.append(cmdButton("SOLVE Menu", "cmdDone"));
  buttons.append(cmdButton("MAIN Menu", "cmdMainMenu"));
  buttons.append(cmdButton("Exit TORA", "cmdExitTora"));
  client.append(buttons);
  body.append(client);
  stage.append(body);
  if (state.dialog) stage.append(saveDialog());
  app.append(stage);
  appendPopup(stage);
}

function captionBar() {
  const bar = el("div", "caption");
  bar.dataset.act = "caption";
  const title = document.createElement("span");
  title.textContent = "TORA";
  const boxes = el("span", "caption-boxes");
  const glyphs = ["_", state.winMode === "max" ? "\u2750" : "\u25a1", "X"];
  const modes = ["min", "max", "close"];
  glyphs.forEach((glyph, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = glyph;
    if (modes[i] === "close") {
      b.dataset.act = "ctl";
      b.dataset.name = "cmdExitTora";
    } else {
      b.dataset.act = "win";
      b.dataset.val = modes[i];
    }
    boxes.append(b);
  });
  bar.append(title, boxes);
  return bar;
}

function fieldRow(label, field, wide) {
  const row = el("div", "field-row");
  const lab = document.createElement("label");
  lab.textContent = label;
  const input = document.createElement("input");
  input.className = wide ? "wide" : "short";
  input.dataset.field = field;
  input.value = textValue(field);
  row.append(lab, input);
  return row;
}

function cmdButton(cap, name) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "vb-btn";
  b.textContent = cap;
  b.dataset.act = "ctl";
  b.dataset.name = name;
  return b;
}

function moduleTitle() {
  const map = {
    inverse: "MATRIX INVERSION",
    equations: "SIMULTANOUS LINEAR EQUATIONS",
    lp: "LINEAR PROGRAMMING",
    transport: "TRANSPORTATION MODEL",
    ip: "INTEGER PROGRAMMING",
    queue: "QUEUEING MODELS",
    network: "NETWORK MODELS",
    project: "PROJECT PLANNING -- PERT/CPM",
    games: "DECISION ANALYSIS USING GAMES",
  };
  return map[state.view] || "";
}

function gridTitle() {
  const v = state.view;
  if (v === "network") {
    if (state.net.mode === "flow") return "INPUT GRID - MAXIMAL FLOW";
    if (state.net.mode === "mst") return "INPUT GRID - MINIMAL SPANNING TREE";
    return "INPUT GRID - SHORTEST ROUTE";
  }
  if (v === "project") {
    return state.project.mode === "pert"
      ? "INPUT GRID - PERT (PROGRAM EVALUATION & REVIEW TECHNIQUE)"
      : "INPUT GRID - CPM (CRITICAL PATH METHOD)";
  }
  const map = {
    inverse: "INPUT GRID - MATRIX INVERSE",
    equations: "INPUT GRID - SIMULTANEOUS EQUAITIONS",
    lp: "INPUT GRID - LINEAR PROGRAMMING",
    ip: "INPUT GRID - INTEGER PROGRAMMING",
    transport: "INPUT GRID - TRANSPORTATION",
    queue: "INPUT TABLE - M/M/c queues",
    games: "INPUT GRID - TWO-PERSON ZERO-SUM GAME",
  };
  return map[v] || "";
}

function countLabels() {
  const v = state.view;
  if (v === "transport") return ["No. of Sources", "No. of Dest'ns"];
  if (v === "queue") return ["No. of Scenarios", "Nbr. of Servers"];
  if (v === "network") return ["No. of Nodes", "Max. Node Nbr."];
  if (v === "games") return ["No. of Strategies B", "No. of Strategies A"];
  return ["No. of variables", "No. of Constraints:"];
}

function helpText() {
  const lines = ["Editing Grid:"];
  if (state.view === "lp" || state.view === "ip") {
    lines.push(">>Click Maximize(Minimize)-cell to change it to Minimize(Maximize)");
  }
  lines.push(">>To DELETE, INSERT, COPY, or PASTE a column(row), click heading");
  lines.push("cell of target column(row), then invoke pull-down EditGrid menu");
  lines.push(">>For INSERT mode, a single(double) click of target row/column will");
  lines.push("place new row/column after(before) target row/column.");
  return lines.join("\n");
}

function saveDialog() {
  const box = el("div", "msgbox");
  const cap = el("div", "cap");
  cap.textContent = "Save?";
  const body = el("div", "body");
  const mark = el("div", "q");
  mark.textContent = "?";
  const text = document.createElement("div");
  text.textContent = "Do you wish to save data?";
  body.append(mark, text);
  const btns = el("div", "btns");
  ["Yes", "No", "Cancel"].forEach((label) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "vb-btn";
    b.textContent = label;
    b.dataset.act = "dlg";
    b.dataset.val = label.toLowerCase();
    btns.append(b);
  });
  box.append(cap, body, btns);
  return box;
}

function appendPopup(stage) {
  if (!state.popup) return;
  const menus = [paintMenu(state.popup.items, state.popup.x, state.popup.y, 0)];
  stage.append(menus[0]);
  (state.popup.stack || []).forEach((frame, depth) => {
    const sub = paintMenu(frame.items, 0, 0, depth + 1);
    stage.append(sub);
    const parent = menus[depth];
    const item = parent.querySelector(`button[data-i="${frame.index}"]`);
    const stageBox = stage.getBoundingClientRect();
    const menuBox = parent.getBoundingClientRect();
    const itemBox = (item || parent).getBoundingClientRect();
    let left = menuBox.right - stageBox.left - stage.clientLeft - 2;
    const pageLeft = stageBox.left + stage.clientLeft + left;
    if (pageLeft + sub.offsetWidth > window.innerWidth - 4) {
      left = menuBox.left - stageBox.left - stage.clientLeft - sub.offsetWidth + 2;
    }
    sub.style.left = left + "px";
    sub.style.top = (itemBox.top - stageBox.top - stage.clientTop) + "px";
    menus.push(sub);
  });
}

function menuBar() {
  const bar = el("div", "vb-menubar");
  bar.append(barButton("&File", "file"));
  bar.append(barButton("&EditGrid", "edit"));
  return bar;
}

function barButton(cap, menu) {
  const b = document.createElement("button");
  b.type = "button";
  b.dataset.act = "bar";
  b.dataset.menu = menu;
  b.append(capFrag(cap));
  return b;
}

function paintMenu(items, x, y, level) {
  const box = el("div", "vb-menu");
  box.style.left = x + "px";
  box.style.top = y + "px";
  items.forEach((entry, i) => {
    if (entry.sep) {
      box.append(el("div", "sep"));
      return;
    }
    if (entry.dead) {
      const d = el("div", "dead");
      d.append(capFrag(entry.cap));
      box.append(d);
      return;
    }
    const b = document.createElement("button");
    b.type = "button";
    b.append(capFrag(entry.cap));
    b.dataset.i = String(i);
    b.dataset.level = level;
    if (entry.children) {
      b.append(" >");
      b.dataset.act = "sub";
      b.addEventListener("mouseenter", () => {
        const stack = (state.popup.stack || []).slice(0, level);
        stack.push({ items: entry.children, index: i });
        state.popup.stack = stack;
        render();
      });
    } else {
      b.dataset.act = "menu";
      b.addEventListener("mouseenter", () => {
        const stack = state.popup?.stack || [];
        if (stack.length <= level) return;
        state.popup.stack = stack.slice(0, level);
        render();
      });
    }
    box.append(b);
  });
  return box;
}

function capFrag(cap) {
  const frag = document.createDocumentFragment();
  for (let i = 0; i < cap.length; i++) {
    if (cap[i] === "&" && cap[i + 1] === "&") {
      frag.append("&");
      i += 1;
    } else if (cap[i] === "&" && i + 1 < cap.length) {
      const u = document.createElement("u");
      u.textContent = cap[i + 1];
      frag.append(u);
      i += 1;
    } else frag.append(cap[i]);
  }
  return frag;
}

function paintCtl(item) {
  const box = el("div", "vb-ctl");
  box.style.left = item.x + "px";
  box.style.top = item.y + "px";
  box.style.width = item.w + "px";
  box.style.height = item.h + "px";
  if (item.type === 3) {
    const frame = document.createElement("fieldset");
    frame.className = "vb-frame";
    if (item.cap) {
      const legend = document.createElement("legend");
      legend.textContent = item.cap;
      frame.append(legend);
    }
    box.append(frame);
    return box;
  }
  if (item.type === 4) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "vb-btn";
    b.textContent = item.cap;
    b.dataset.act = "ctl";
    b.dataset.name = item.name;
    box.append(b);
    return box;
  }
  if (item.type === 1) {
    const label = el("div", "vb-label");
    label.textContent = labelText(item);
    box.append(label);
    return box;
  }
  if (item.type === 2) {
    const input = item.h >= 40 ? document.createElement("textarea") : document.createElement("input");
    input.className = item.h >= 40 ? "vb-area" : "vb-text";
    input.value = textValue(item.name);
    input.dataset.field = item.name;
    box.append(input);
    return box;
  }
  if (item.type === 6) {
    box.append(paintRadio(item));
    return box;
  }
  if (item.type === 5) {
    const input = document.createElement("input");
    input.type = "checkbox";
    input.className = "vb-chk";
    input.dataset.field = item.name;
    input.checked = item.name === "Check1" ? state.symmetrical : false;
    box.append(input);
    return box;
  }
  if (item.type === 7) {
    const select = document.createElement("select");
    select.className = "vb-text";
    fillCombo(select, item.name);
    box.append(select);
    return box;
  }
  if (item.type === 8) {
    const select = document.createElement("select");
    select.className = "vb-list";
    select.size = 3;
    box.append(select);
    return box;
  }
  if (item.type === 0 || item.type === 255) {
    if (item.name === "picLPgraph") {
      box.classList.add("vb-pic");
      const canvas = document.createElement("canvas");
      canvas.id = "lp-graph";
      canvas.width = item.w;
      canvas.height = item.h;
      box.append(canvas);
      return box;
    }
    box.classList.add("vb-grid");
    if (item.name === "Grid1") fillInputGrid(box);
    if (item.name === "BBGrid") fillBranchGrid(box);
    return box;
  }
  return box;
}

function paintRadio(item) {
  const input = document.createElement("input");
  input.type = "radio";
  input.className = "vb-opt";
  if (item.name === "newProblemOption" || item.name === "existingFileOption") {
    input.name = "input-mode";
    input.dataset.act = "mode";
    input.dataset.val = item.name === "newProblemOption" ? "new" : "file";
    input.checked = item.name === "newProblemOption" ? state.modeNew : !state.modeNew;
  } else {
    input.name = "notation-" + (item.name.startsWith("n") ? "setup" : "out");
    input.dataset.act = "fmt";
    const decimal = item.name === "nDecimalOption" || item.name === "decimalOption";
    input.dataset.val = decimal ? "dec" : "sci";
    input.checked = decimal ? state.decimal : !state.decimal;
  }
  return input;
}

function labelText(item) {
  if (state.form === "lpgraf" && state.out?.kind === "graph") {
    const data = state.out.data || {};
    if (item.name === "Label5") {
      if (data.point) return data.xName + " = " + data.point.x;
      if (data.status === "unbounded") return "Optimum solution is UNBOUNDED";
      return "Problem has no feasible solution";
    }
    if (item.name === "Label6" && data.point) return data.yName + " = " + data.point.y;
    if (item.name === "Label7" && data.point) return "Objective value = " + data.point.z;
  }
  return item.cap || "";
}

function textValue(name) {
  if (name === "BX1") return getTitle();
  if (name === "BX2") return state.view ? String(counts()[0]) : "";
  if (name === "BX3") {
    if (state.view === "queue") return state.queue[0]?.servers || "";
    return state.view ? String(counts()[1]) : "";
  }
  if (name === "NsText" || name === "nbrNsText") return state.ns;
  if (name === "DsText" || name === "nbrDsText") return state.nd;
  if (name === "TextBigM") return state.bigM;
  return "";
}

function fillCombo(select, name) {
  const add = (text) => {
    const opt = document.createElement("option");
    opt.textContent = text;
    select.append(opt);
  };
  if (name === "Combo5") {
    state.transport.sources.forEach((_, i) => add("u" + (i + 1) + "=0"));
    state.transport.dests.forEach((_, i) => add("v" + (i + 1) + "=0"));
  }
  if (name === "Combo2" || name === "Combo3" || name === "Combo4") {
    const nodes = new Set();
    state.net.edges.forEach((e) => {
      if (e[0]) nodes.add(e[0]);
      if (e[1]) nodes.add(e[1]);
    });
    if (state.net.start) nodes.add(state.net.start);
    Array.from(nodes).forEach(add);
  }
  if (name === "Combo1" && state.form === "lpgraf") {
    state.project.rows.forEach((row) => { if (row[0]) add(row[0]); });
  }
}

function fillInputGrid(host) {
  const v = state.view;
  if (v === "lp" || v === "ip") fillLp(host, v);
  else if (v === "inverse" || v === "equations") fillAlgebra(host);
  else if (v === "transport") fillTransport(host);
  else if (v === "queue") fillQueue(host);
  else if (v === "network") fillNet(host);
  else if (v === "project") fillProject(host);
  else if (v === "games") fillGame(host);
}

function fillLp(host, key) {
  const m = state[key];
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  headSel(hr, "Var. Name", "corner", -1);
  m.names.forEach((name, i) => {
    const th = document.createElement("th");
    th.append(numIn(key + ".names." + i, name));
    markSel(th, "col", i);
    hr.append(th);
  });
  thText(hr, "Enter <, >, or =");
  thText(hr, "R.H.S.");
  table.append(hr);
  const obj = document.createElement("tr");
  const sense = document.createElement("th");
  sense.textContent = m.sense === "min" ? "(Minimize)" : "(Maximize)";
  sense.dataset.act = "sense";
  obj.append(sense);
  m.c.forEach((v, i) => cell(obj, numIn(key + ".c." + i, v)));
  cell(obj);
  cell(obj);
  table.append(obj);
  m.cons.forEach((row, r) => {
    const tr = document.createElement("tr");
    const th = document.createElement("th");
    th.append(numIn(key + ".cons." + r + ".0", row[0]));
    markSel(th, "row", r);
    tr.append(th);
    m.names.forEach((_, c) => cell(tr, numIn(key + ".cons." + r + "." + (c + 1), row[c + 1])));
    const rel = document.createElement("select");
    rel.dataset.path = key + ".cons." + r + "." + (m.names.length + 1);
    ["<=", ">=", "="].forEach((op) => {
      const o = document.createElement("option");
      o.value = op;
      o.textContent = op;
      if (row.at(-2) === op) o.selected = true;
      rel.append(o);
    });
    cell(tr, rel);
    cell(tr, numIn(key + ".cons." + r + "." + (m.names.length + 2), row.at(-1)));
    table.append(tr);
  });
  boundRow(table, "Lower Bound", key, "lb", m);
  boundRow(table, "Upper Bound", key, "ub", m);
  ynRow(table, "Unrestr'd (y/n)?", key, "unrestricted", m);
  if (key === "ip") ynRow(table, "Integer (y/n)?", key, "integer", m);
  host.append(table);
}

function fillAlgebra(host) {
  const equations = state.view === "equations";
  const n = equations ? state.eqN : state.algebraN;
  const grid = equations ? state.eqA : state.algebra;
  const path = equations ? "eqA" : "algebra";
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  thText(hr, "");
  for (let j = 0; j < n; j++) thText(hr, "x" + (j + 1));
  if (equations) thText(hr, "R.H.S.");
  table.append(hr);
  grid.forEach((row, i) => {
    const tr = document.createElement("tr");
    thText(tr, "");
    row.forEach((v, j) => cell(tr, numIn(path + "." + i + "." + j, v)));
    if (equations) cell(tr, numIn("rhs." + i, state.rhs[i] ?? "0"));
    table.append(tr);
  });
  host.append(table);
}

function fillTransport(host) {
  const t = state.transport;
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  thText(hr, "S/D Name");
  t.dests.forEach((name, j) => {
    const th = document.createElement("th");
    th.append(numIn("transport.dests." + j, name));
    markSel(th, "col", j);
    hr.append(th);
  });
  thText(hr, "Supply");
  table.append(hr);
  t.sources.forEach((name, i) => {
    const tr = document.createElement("tr");
    const th = document.createElement("th");
    th.append(numIn("transport.sources." + i, name));
    markSel(th, "row", i);
    tr.append(th);
    t.cost[i].forEach((v, j) => cell(tr, numIn("transport.cost." + i + "." + j, v)));
    cell(tr, numIn("transport.supply." + i, t.supply[i]));
    table.append(tr);
  });
  const demand = document.createElement("tr");
  thText(demand, "Demand");
  t.demand.forEach((v, j) => cell(demand, numIn("transport.demand." + j, v)));
  cell(demand);
  table.append(demand);
  host.append(table);
}

function fillQueue(host) {
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  ["Scenario", "Lambda", "Mu", "Nbr. of Servers", "System Limit", "Source Limit"].forEach((text) => thText(hr, text));
  table.append(hr);
  state.queue.forEach((q, i) => {
    const tr = document.createElement("tr");
    thText(tr, String(i + 1));
    ["lambda", "mu", "servers", "systemLimit", "sourceLimit"].forEach((k) => cell(tr, numIn("queue." + i + "." + k, q[k])));
    table.append(tr);
  });
  host.append(table);
}

function fillNet(host) {
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  thText(hr, "From Node");
  thText(hr, "To Node");
  thText(hr, state.net.mode === "flow" ? "" : "Distance");
  table.append(hr);
  state.net.edges.forEach((e, i) => {
    const tr = document.createElement("tr");
    e.forEach((v, j) => cell(tr, numIn("net.edges." + i + "." + j, v)));
    table.append(tr);
  });
  host.append(table);
}

function fillProject(host) {
  const pert = state.project.mode === "pert";
  const headers = pert
    ? ["Symbol", "From Node", "To Node", "Minimum Dur., a", "Most-Likely Dur., m", "Maximum Dur., b"]
    : ["Symbol", "From Node", "To Node", "Duration"];
  const cols = pert ? [0, 1, 2, 4, 5, 6] : [0, 1, 2, 3];
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  headers.forEach((text) => thText(hr, text));
  table.append(hr);
  state.project.rows.forEach((row, i) => {
    const tr = document.createElement("tr");
    cols.forEach((j) => cell(tr, numIn("project.rows." + i + "." + j, row[j])));
    table.append(tr);
  });
  host.append(table);
}

function fillGame(host) {
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  thText(hr, "");
  state.game[0].forEach((_, j) => {
    const th = document.createElement("th");
    th.textContent = "Strategy B";
    markSel(th, "col", j);
    hr.append(th);
  });
  table.append(hr);
  state.game.forEach((row, i) => {
    const tr = document.createElement("tr");
    const th = document.createElement("th");
    th.textContent = "Strategy A";
    markSel(th, "row", i);
    tr.append(th);
    row.forEach((v, j) => cell(tr, numIn("game." + i + "." + j, v)));
    table.append(tr);
  });
  host.append(table);
}

function fillBranchGrid(host) {
  const m = state.ip;
  const table = document.createElement("table");
  const hr = document.createElement("tr");
  thText(hr, "Var. Name");
  thText(hr, "Integer (y/n)?");
  table.append(hr);
  m.names.forEach((name, i) => {
    const tr = document.createElement("tr");
    thText(tr, name);
    thText(tr, m.integer[i] ? "y" : "n");
    table.append(tr);
  });
  host.append(table);
}

function boundRow(table, label, key, field, m) {
  const tr = document.createElement("tr");
  thText(tr, label);
  m[field].forEach((v, i) => cell(tr, numIn(key + "." + field + "." + i, v)));
  cell(tr);
  cell(tr);
  table.append(tr);
}

function ynRow(table, label, key, field, m) {
  const tr = document.createElement("tr");
  thText(tr, label);
  m[field].forEach((v, i) => {
    const input = document.createElement("input");
    input.value = v ? "y" : "n";
    input.dataset.yn = key + "." + field + "." + i;
    cell(tr, input);
  });
  cell(tr);
  cell(tr);
  table.append(tr);
}

function headSel(tr, text, axis, index) {
  const th = document.createElement("th");
  th.textContent = text;
  markSel(th, axis, index);
  tr.append(th);
  return th;
}

function markSel(th, axis, index) {
  th.dataset.act = "sel";
  th.dataset.axis = axis;
  th.dataset.index = String(index);
  if (state.sel && state.sel.axis === axis && state.sel.index === index) th.className = "sel";
}

function thText(tr, text) {
  const th = document.createElement("th");
  th.textContent = text;
  tr.append(th);
  return th;
}

function cell(tr, child) {
  const td = document.createElement("td");
  if (child) td.append(child);
  tr.append(td);
  return td;
}

function numIn(path, value) {
  const input = document.createElement("input");
  input.dataset.path = path;
  input.value = value ?? "";
  return input;
}

function el(tag, className) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  return node;
}

function renderOut(out) {
  try {
    if (!out) return "";
    if (out.kind === "lp") return lpOut(out.data);
    if (out.kind === "ip") return ipOut(out.data);
    if (out.kind === "inverse") return inverseOut(out.data);
    if (out.kind === "equations") return eqOut(out.data);
    if (out.kind === "transport") return transOut(out.data);
    if (out.kind === "queue") return queueOut(out.data);
    if (out.kind === "network") return netOut(out.data);
    if (out.kind === "project") return projOut(out.data);
    if (out.kind === "game") return gameOut(out.data);
    return "";
  } catch (err) {
    return "<p>" + esc(err.message) + "</p>";
  }
}

function lpOut(data) {
  const msgs = (data.messages || []).map((m) => "<p>" + esc(m) + "</p>").join("");
  const vars = data.variables.map((v, i) => {
    const range = data.ranges?.variables?.[i];
    return "<tr><td>" + esc(v.name) + "</td><td>" + esc(v.value) + "</td><td>" + esc(v.contrib || "") + "</td><td>" + esc(range?.reduced || "") + "</td><td>" + esc(range?.min || "") + "</td><td>" + esc(range?.max || "") + "</td></tr>";
  }).join("");
  const cons = (data.constraints || []).map((c, i) => {
    const range = data.ranges?.constraints?.[i];
    return "<tr><td>" + esc(c.name) + "</td><td>" + esc(c.slack || "") + "</td><td>" + esc(c.dual || "") + "</td><td>" + esc(range?.min || "") + "</td><td>" + esc(range?.max || "") + "</td></tr>";
  }).join("");
  const showTabs = state.outputMode === "iterations";
  const tabs = showTabs
    ? (data.tableaus || []).slice(0, state.reveal || 1).map((t, idx, all) => tableauHtml(t, idx === all.length - 1)).join("")
    : "";
  return "<h3>LINEAR PROGRAMMING OUTPUT SUMMARY</h3>"
    + "<p>" + esc(data.message || "") + "</p>"
    + msgs
    + "<p>Objective Value = " + esc(data.objective) + "</p>"
    + "<div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Variable</th><th>Value</th><th>Obj Val Contrib</th><th>Reduced Cost</th><th>Min Obj Coeff</th><th>Max Obj Coeff</th></tr></thead><tbody>"
    + vars + "</tbody></table></div>"
    + (cons ? "<h3>***Sensitivity Analysis***</h3><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Constraint</th><th>Slack-/Surplus+</th><th>Dual Price</th><th>Min RHS</th><th>Max RHS</th></tr></thead><tbody>" + cons + "</tbody></table></div>" : "")
    + (showTabs ? "<h3>SIMPLEX TABLEAUS --</h3>" + tabs : "");
}

function tableauHtml(t, open) {
  const zName = state.lp.sense === "min" ? "z (min)" : "z (max)";
  const enterAt = t.columns.indexOf(t.entering);
  const heads = t.columns.map((c, j) => `<th class="${j === enterAt ? "entering" : ""}">${esc(c)}</th>`).join("");
  const rows = t.rows.map((r) => `<tr class="${r.basic === t.leaving ? "leaving" : ""}"><td class="basic">${esc(r.basic)}</td>${r.cells.map((c, j) => `<td class="${j === enterAt ? "entering" : ""}">${esc(c)}</td>`).join("")}<td>${esc(r.rhs)}</td></tr>`).join("");
  const zj = t.zj.map((c, j) => `<td class="${j === enterAt ? "entering" : ""}">${esc(c)}</td>`).join("");
  return `<details ${open ? "open" : ""}>
    <summary>${esc(t.title)}</summary>
    <div class="grid-wrap"><table class="data"><thead><tr><th>Basic</th>${heads}<th>Solution</th></tr></thead>
      <tbody>${rows}<tr><th>${zName}</th>${zj}<td>${esc(t.zrhs)}</td></tr></tbody></table></div>
  </details>`;
}

function ipOut(data) {
  const rows = (data.variables || []).map((v) => "<tr><td>" + esc(v.name) + "</td><td>" + esc(v.value) + "</td></tr>").join("");
  const nodes = (data.nodes || []).map((n) => "<p>Subproblem " + esc(n.id) + " ObjVal, z = " + esc(n.objective) + " " + esc(n.branch || "") + " " + esc(n.fathomed || n.status || "") + "</p>").join("");
  return "<h3>INTEGER PROGRAMMING B&amp;B OUTPUT SUMMARY</h3><p>" + esc(data.message || "") + "</p><p>Objective Value = " + esc(data.objective) + "</p><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Variable</th><th>Value</th></tr></thead><tbody>" + rows + "</tbody></table></div><h3>INTEGER PROGRAMMING B&amp;B TREE</h3>" + nodes;
}

function inverseOut(data) {
  if (data.singular) return "<p>" + esc(data.message || "Matrix is singular -- No inverse") + "</p>";
  return "<h3>INVERSE MATRIX</h3><p>Determinant = " + esc(data.determinant) + "</p>" + matrixTable(data.inverse);
}

function eqOut(data) {
  if (data.singular) return "<p>" + esc(data.message || "No Solution") + "</p>";
  const rows = data.solution.map((v, i) => "<tr><td>x" + (i + 1) + "</td><td>" + esc(v) + "</td></tr>").join("");
  return "<h3>SOLUTION OF SIMULTANEOUS EQUATIONS</h3><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Variable</th><th>Value</th></tr></thead><tbody>" + rows + "</tbody></table></div>";
}

function matrixTable(rows) {
  return "<div class=\"grid-wrap\"><table class=\"data\"><tbody>" + rows.map((r) => "<tr>" + r.map((v) => "<td>" + esc(v) + "</td>").join("") + "</tr>").join("") + "</tbody></table></div>";
}

function transMethod(method) {
  if (method === "northwest") return "(North-West Corner Method)";
  if (method === "least") return "(Least Cost Method)";
  return "(Vogel's Method)";
}

function transOut(data) {
  const ship = data.shipments.map((s) => "<tr><td>" + esc(state.transport.sources[s.from] || s.from + 1) + "</td><td>" + esc(s.qty) + "</td><td>" + esc(s.contrib) + "</td></tr>").join("");
  const limit = state.outputMode === "iterations" ? (state.reveal || 1) : data.steps.length;
  const steps = data.steps.slice(0, limit).map((step, idx) => "<details " + (idx === limit - 1 ? "open" : "") + "><summary>Iter " + (idx + 1) + "</summary>" + matrixTable(step.alloc) + "<p>ObjVal  = " + esc(step.cost) + "</p></details>").join("");
  const notes = (data.notes || []).map((n) => "<p>" + esc(n) + "</p>").join("");
  return "<h3>TRANSPORTATION MODEL OUTPUT SUMMARY</h3><p>" + esc(transMethod(data.method)) + "</p>" + notes + "<p>Objective Value (minimum cost) = " + esc(data.objective) + "</p><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>From</th><th>Amt Shipped</th><th>Obj Contrib</th></tr></thead><tbody>" + ship + "</tbody></table></div><h3>TRANSPORTATION TABLEAU -</h3>" + steps;
}

function queueOut(rows) {
  return "<h3>QUEUEING OUTPUT ANALYSIS</h3>" + rows.map((r) => {
    if (r.error) return "<p>" + esc(r.error) + "</p>";
    const pn = (r.pn || []).map((p) => "<tr><td>" + p.n + "</td><td>" + esc(p.p) + "</td><td>" + esc(p.cum) + "</td></tr>").join("");
    return "<h3>" + esc(r.model) + "</h3><p>Ls = " + esc(r.Ls) + "</p><p>Lq = " + esc(r.Lq) + "</p><p>Ws = " + esc(r.Ws) + "</p><p>Wq = " + esc(r.Wq) + "</p><p>Lambda eff = " + esc(r.lambdaEff) + "</p><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>n</th><th>Probability, pn</th><th>Cumulative, Pn</th></tr></thead><tbody>" + pn + "</tbody></table></div>";
  }).join("");
}

function netOut(data) {
  if (data.mode === "dijkstra") {
    const routes = data.routes.map((r) => "<tr><td>" + r.node + "</td><td>" + esc(r.distance) + "</td><td>" + esc(r.route) + "</td></tr>").join("");
    return "<h3>SHORTEST ROUTES -- DIJKSTRA'S OUTPUT SUMMARY</h3><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Node</th><th>Distance</th><th>Route</th></tr></thead><tbody>" + routes + "</tbody></table></div>";
  }
  if (data.mode === "floyd") {
    const routes = data.routes.map((r) => "<tr><td>" + r.from + "</td><td>" + r.to + "</td><td>" + esc(r.distance) + "</td><td>" + esc(r.route) + "</td></tr>").join("");
    return "<h3>SHORTEST ROUTES -- FLOYD'S OUTPUT SUMMARY</h3><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>From Node</th><th>To Node</th><th>Distance</th><th>Route</th></tr></thead><tbody>" + routes + "</tbody></table></div>";
  }
  if (data.mode === "flow") {
    const steps = data.steps.map((s) => "<tr><td>" + s.iteration + "</td><td>" + esc(s.path) + "</td><td>" + esc(s.breakthrough) + "</td><td>" + esc(s.total) + "</td></tr>").join("");
    const flows = data.flows.map((f) => "<tr><td>" + f.from + "</td><td>" + f.to + "</td><td>" + esc(f.flow) + "</td><td>" + esc(f.cap) + "</td></tr>").join("");
    return "<h3>MAXIMUM FLOW -- OUTPUT SUMMARY</h3><p>" + esc(data.message || "") + "</p><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Iter</th><th>Path</th><th>Breakthrough</th><th>Total</th></tr></thead><tbody>" + steps + "</tbody></table></div><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>From Node</th><th>To Node</th><th>Maximum flows</th><th></th></tr></thead><tbody>" + flows + "</tbody></table></div>";
  }
  const steps = (data.steps || []).map((s) => "<p>" + esc(s.text) + " :  Length = " + esc(s.length) + "</p>").join("");
  return "<h3>MINIMAL SPANNING TREE OUTPUT SUMMARY</h3><p>Minimal Spanning Tree Length = " + esc(data.length) + "</p>" + steps;
}

function projOut(data) {
  const rows = data.rows.map((r) => "<tr><td>" + esc(r.symbol) + "</td><td>" + r.from + "</td><td>" + r.to + "</td><td>" + esc(r.duration) + "</td><td>" + esc(r.es) + "</td><td>" + esc(r.ef) + "</td><td>" + esc(r.ls) + "</td><td>" + esc(r.lf) + "</td><td>" + esc(r.tf) + "</td><td>" + esc(r.ff) + "</td></tr>").join("");
  const title = data.mode === "pert" ? "PROJECT PLANNING - PERT" : "CRITICAL PATH METHOD SCHEDULE";
  return "<h3>" + title + "</h3><p>Project length " + esc(data.projectLength) + "</p><p>" + esc(data.path) + "</p>"
    + (data.mode === "pert" ? "<p>Path Mean " + esc(data.pathMean) + "</p><p>Path Std. Dev. " + esc(data.pathStd) + "</p>" : "")
    + "<div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Activity</th><th>From Node</th><th>To Node</th><th>Duration</th><th>Earliest Start</th><th>Earliest Time</th><th>Latest Time</th><th>Latest Finish</th><th>Total Float</th><th>Free Float</th></tr></thead><tbody>" + rows + "</tbody></table></div>";
}

function gameOut(data) {
  const mix = (arr) => (arr || []).map((p, i) => "<tr><td>Strategy " + (i + 1) + "</td><td>" + esc(p) + "</td></tr>").join("");
  let html = "<h3>TWO-PERSON ZERO-SUM GANE OUTPUT SUMMARY</h3><p>Value of the Game to Player A = " + esc(data.value) + "</p>";
  if (state.gameView !== "graph") {
    html += "<p>Player A's Optimal Strategies:</p><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Strategy</th><th>Probability</th></tr></thead><tbody>" + mix(data.pA) + "</tbody></table></div>";
    html += "<p>Player B's Optimal Strategies:</p><div class=\"grid-wrap\"><table class=\"data\"><thead><tr><th>Strategy</th><th>Probability</th></tr></thead><tbody>" + mix(data.pB) + "</tbody></table></div>";
  }
  if (data.graphic && state.gameView === "graph") {
    html += "<h3>GRAPHICAL TWO-PERSON ZERO-SUM GAME SOLUTION</h3><p>Value of the game  = " + esc(data.graphic.value) + "</p><p>Player A's mix: " + esc(data.graphic.p) + "</p>";
  }
  return html;
}

function paintGraph() {
  const canvas = document.getElementById("lp-graph");
  const data = state.out?.data;
  if (!canvas || !data) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, w, h);
  const pts = data.vertices || [];
  const xs = pts.map((p) => p.xN);
  const ys = pts.map((p) => p.yN);
  (data.lines || []).forEach((ln) => {
    if (Math.abs(ln.a) > 1e-9) xs.push(ln.c / ln.a);
    if (Math.abs(ln.b) > 1e-9) ys.push(ln.c / ln.b);
  });
  const zoom = state.zoom || 1;
  const maxX = Math.max(1, ...xs.filter((v) => v > 0 && v < 1e5)) * 1.15 / zoom;
  const maxY = Math.max(1, ...ys.filter((v) => v > 0 && v < 1e5)) * 1.15 / zoom;
  const X = (x) => 14 + (x / maxX) * (w - 18);
  const Y = (y) => h - 10 - (y / maxY) * (h - 16);
  ctx.strokeStyle = "#000";
  ctx.fillStyle = "#000";
  ctx.lineWidth = 1;
  ctx.font = "8px 'MS Sans Serif', Tahoma, sans-serif";
  ctx.beginPath();
  ctx.moveTo(X(0), Y(0));
  ctx.lineTo(X(maxX), Y(0));
  ctx.moveTo(X(0), Y(0));
  ctx.lineTo(X(0), Y(maxY));
  ctx.stroke();
  (data.lines || []).forEach((ln) => {
    ctx.beginPath();
    clipLine(ctx, ln, maxX, maxY, X, Y);
    ctx.stroke();
  });
  pts.forEach((p) => {
    ctx.beginPath();
    ctx.arc(X(p.xN), Y(p.yN), p.optimal ? 2 : 1, 0, Math.PI * 2);
    if (p.optimal) ctx.fill();
    else ctx.stroke();
  });
}

function clipLine(ctx, ln, maxX, maxY, X, Y) {
  const pts = [];
  const push = (x, y) => {
    if (x >= -1e-6 && y >= -1e-6 && x <= maxX + 1e-6 && y <= maxY + 1e-6) pts.push([x, y]);
  };
  if (Math.abs(ln.b) > 1e-9) push(0, ln.c / ln.b);
  if (Math.abs(ln.a) > 1e-9) push(ln.c / ln.a, 0);
  if (Math.abs(ln.b) > 1e-9) push(maxX, (ln.c - ln.a * maxX) / ln.b);
  if (Math.abs(ln.a) > 1e-9) push((ln.c - ln.b * maxY) / ln.a, maxY);
  if (pts.length < 2) return;
  ctx.moveTo(X(pts[0][0]), Y(pts[0][1]));
  ctx.lineTo(X(pts[1][0]), Y(pts[1][1]));
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

function download(name, text) {
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}
