function num(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error("Network data must be numeric.");
  return n;
}

function normalizeEdges(edges) {
  const clean = [];
  let max = 0;
  edges.forEach((e) => {
    const from = Number(e.from);
    const to = Number(e.to);
    const w = num(e.weight);
    if (!Number.isInteger(from) || !Number.isInteger(to) || from < 1 || to < 1) {
      throw new Error("Node number must be >= 1.");
    }
    if (from === to) throw new Error("FROM and TO nodes must be assigned distinct numbers.");
    if (w < 0) throw new Error("Negative arc length or capacity is not permitted.");
    max = Math.max(max, from, to);
    clean.push({ from, to, weight: w });
  });
  return { edges: clean, max };
}

export function dijkstra(edges, source) {
  const { edges: E, max } = normalizeEdges(edges);
  const src = Number(source) || 1;
  const dist = Array(max + 1).fill(Infinity);
  const prev = Array(max + 1).fill(null);
  const perm = Array(max + 1).fill(false);
  dist[src] = 0;
  const steps = [];
  for (let k = 1; k <= max; k++) {
    let u = -1;
    for (let i = 1; i <= max; i++) {
      if (!perm[i] && (u < 0 || dist[i] < dist[u])) u = i;
    }
    if (u < 0 || !Number.isFinite(dist[u])) break;
    perm[u] = true;
    E.forEach((e) => {
      if (e.from !== u) return;
      const nd = dist[u] + e.weight;
      if (nd < dist[e.to]) {
        dist[e.to] = nd;
        prev[e.to] = u;
      }
    });
    steps.push({
      iteration: k,
      permanent: u,
      labels: Array.from({ length: max }, (_, i) => ({
        node: i + 1,
        distance: Number.isFinite(dist[i + 1]) ? round(dist[i + 1]) : "∞",
        status: perm[i + 1] ? "permanent" : "temporary",
      })),
    });
  }
  const routes = [];
  for (let t = 1; t <= max; t++) {
    if (t === src) continue;
    const path = [];
    let cur = t;
    const guard = new Set();
    while (cur && cur !== src && !guard.has(cur)) {
      guard.add(cur);
      path.push(cur);
      cur = prev[cur];
    }
    if (cur === src) path.push(src);
    path.reverse();
    routes.push({
      node: t,
      distance: Number.isFinite(dist[t]) ? round(dist[t]) : "∞",
      route: path.length && path[0] === src ? path.join(" → ") : "—",
    });
  }
  return { source: src, steps, routes, nodes: max };
}

export function floyd(edges) {
  const { edges: E, max } = normalizeEdges(edges);
  const D = Array.from({ length: max + 1 }, () => Array(max + 1).fill(Infinity));
  const S = Array.from({ length: max + 1 }, () => Array(max + 1).fill(0));
  for (let i = 1; i <= max; i++) D[i][i] = 0;
  E.forEach((e) => {
    if (e.weight < D[e.from][e.to]) {
      D[e.from][e.to] = e.weight;
      S[e.from][e.to] = e.to;
    }
  });
  const steps = [];
  for (let k = 1; k <= max; k++) {
    for (let i = 1; i <= max; i++) {
      for (let j = 1; j <= max; j++) {
        if (D[i][k] + D[k][j] < D[i][j]) {
          D[i][j] = D[i][k] + D[k][j];
          S[i][j] = S[i][k];
        }
      }
    }
    steps.push({ k, D: show(D, max), S: show(S, max) });
  }
  const routes = [];
  for (let i = 1; i <= max; i++) {
    for (let j = 1; j <= max; j++) {
      if (i === j) continue;
      routes.push({
        from: i,
        to: j,
        distance: Number.isFinite(D[i][j]) ? round(D[i][j]) : "∞",
        route: Number.isFinite(D[i][j]) ? pathFrom(S, i, j).join(" → ") : "—",
      });
    }
  }
  return { steps, routes, nodes: max };
}

function pathFrom(S, i, j) {
  const path = [i];
  let guard = 0;
  while (i !== j && guard++ < S.length + 2) {
    i = S[i][j];
    if (!i) return path.concat(["?"]);
    path.push(i);
  }
  return path;
}

function show(M, n) {
  return Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => {
    const v = M[i + 1][j + 1];
    return Number.isFinite(v) ? round(v) : "∞";
  }));
}

export function prim(edges, start) {
  const { edges: E, max } = normalizeEdges(edges);
  const src = Number(start) || 1;
  const inn = new Set([src]);
  const steps = [{ text: `Start at node ${src}`, length: "0" }];
  let total = 0;
  const used = [];
  while (inn.size < max) {
    let best = null;
    E.forEach((e) => {
      const aIn = inn.has(e.from);
      const bIn = inn.has(e.to);
      if (aIn === bIn) return;
      const from = aIn ? e.from : e.to;
      const to = aIn ? e.to : e.from;
      if (!best || e.weight < best.weight) best = { from, to, weight: e.weight };
    });
    if (!best) {
      return {
        status: "error",
        message: "All arcs from the current tree have infinite length. No spanning tree exists.",
        steps,
        length: round(total),
      };
    }
    inn.add(best.to);
    total += best.weight;
    used.push(best);
    steps.push({
      text: `Connect N${best.from} to N${best.to}: length = ${round(best.weight)}`,
      length: round(total),
    });
  }
  steps.push({ text: "Last row completes minimal spanning tree", length: round(total) });
  return { status: "optimal", steps, length: round(total), edges: used, start: src };
}

export function maxFlow(edges, source, sink) {
  const { edges: E, max } = normalizeEdges(edges);
  const s = Number(source) || 1;
  const t = Number(sink) || max;
  if (s === t) throw new Error("FROM and TO nodes must be assigned distinct numbers.");
  const cap = new Map();
  const add = (a, b, w) => {
    const k = `${a},${b}`;
    cap.set(k, (cap.get(k) || 0) + w);
  };
  E.forEach((e) => add(e.from, e.to, e.weight));
  const residual = new Map(cap);
  const get = (a, b) => residual.get(`${a},${b}`) || 0;
  const steps = [];
  let flow = 0;
  let guard = 0;
  while (guard++ < 10000) {
    const prev = Array(max + 1).fill(null);
    const q = [s];
    const seen = new Set([s]);
    while (q.length) {
      const u = q.shift();
      for (let v = 1; v <= max; v++) {
        if (seen.has(v)) continue;
        if (get(u, v) > 1e-9) {
          seen.add(v);
          prev[v] = u;
          q.push(v);
        }
      }
    }
    if (!seen.has(t)) break;
    let bottleneck = Infinity;
    const path = [];
    for (let v = t; v !== s; v = prev[v]) {
      path.push(v);
      bottleneck = Math.min(bottleneck, get(prev[v], v));
    }
    path.push(s);
    path.reverse();
    for (let i = 0; i < path.length - 1; i++) {
      const a = path[i];
      const b = path[i + 1];
      residual.set(`${a},${b}`, get(a, b) - bottleneck);
      residual.set(`${b},${a}`, get(b, a) + bottleneck);
    }
    flow += bottleneck;
    steps.push({
      iteration: steps.length + 1,
      path: path.join(" → "),
      breakthrough: round(bottleneck),
      total: round(flow),
    });
  }
  const flows = [];
  E.forEach((e) => {
    const sent = e.weight - get(e.from, e.to);
    if (sent > 1e-6) flows.push({ from: e.from, to: e.to, flow: round(sent), cap: round(e.weight) });
  });
  return {
    status: "optimal",
    value: round(flow),
    steps,
    flows,
    source: s,
    sink: t,
    message: steps.length
      ? `No more breakthroughs — algorithm ends at iteration ${steps.length}`
      : "Maximum flow is 0.",
  };
}

function round(x) {
  return String(Math.round(x * 1e6) / 1e6);
}
