import { R0, fmtRat, rat } from "./rational.js";

function clone(grid) {
  return grid.map((row) => row.map((v) => rat(v)));
}

function balance(cost, supply, demand) {
  const c = clone(cost);
  const s = supply.map((v) => rat(v));
  const d = demand.map((v) => rat(v));
  const notes = [];
  let S = s.reduce((a, b) => a.add(b), R0);
  let D = d.reduce((a, b) => a.add(b), R0);
  if (S.cmp(D) > 0) {
    c.forEach((row) => row.push(R0));
    d.push(S.sub(D));
    notes.push("DummyD");
  } else if (D.cmp(S) > 0) {
    c.push(d.map(() => R0));
    s.push(D.sub(S));
    notes.push("DummyS");
  }
  return { cost: c, supply: s, demand: d, notes };
}

function mPlusN(s, d) {
  return s.length + d.length - 1;
}

// Cross-out order from FUN_004ad9b0 (tora.exe, method word 0x50b2c8):
// one open row closes the column; one open column closes the row;
// otherwise a zero remaining supply closes the row and any other case closes the column.
function crossOut(rowOpen, colOpen, i, j, supplyLeft) {
  const openRows = rowOpen.filter(Boolean).length;
  const openCols = colOpen.filter(Boolean).length;
  if (openRows === 1) colOpen[j] = false;
  else if (openCols === 1) rowOpen[i] = false;
  else if (supplyLeft.isZero()) rowOpen[i] = false;
  else colOpen[j] = false;
}

function northwest(cost, supply, demand) {
  const m = supply.length;
  const n = demand.length;
  const ss = supply.map((v) => rat(v));
  const dd = demand.map((v) => rat(v));
  const alloc = cost.map(() => cost[0].map(() => null));
  const basic = [];
  const rowOpen = Array(m).fill(true);
  const colOpen = Array(n).fill(true);
  let i = 0;
  let j = 0;
  while (i < m && j < n && rowOpen[i] && colOpen[j]) {
    const q = ss[i].cmp(dd[j]) < 0 ? ss[i] : dd[j];
    alloc[i][j] = q;
    basic.push([i, j]);
    ss[i] = ss[i].sub(q);
    dd[j] = dd[j].sub(q);
    crossOut(rowOpen, colOpen, i, j, ss[i]);
    if (!rowOpen[i]) i += 1;
    if (!colOpen[j]) j += 1;
  }
  fillBasic(alloc, basic, m, n);
  return { alloc, basic };
}

function leastCost(cost, supply, demand) {
  const m = supply.length;
  const n = demand.length;
  const ss = supply.map((v) => rat(v));
  const dd = demand.map((v) => rat(v));
  const alloc = cost.map(() => cost[0].map(() => null));
  const basic = [];
  const rowOpen = Array(m).fill(true);
  const colOpen = Array(n).fill(true);
  let guard = 0;
  while (guard++ < m * n + 2) {
    let bi = -1;
    let bj = -1;
    let best = null;
    for (let i = 0; i < m; i++) {
      if (!rowOpen[i]) continue;
      for (let j = 0; j < n; j++) {
        if (!colOpen[j]) continue;
        if (bi < 0 || cost[i][j].cmp(best) < 0) {
          bi = i;
          bj = j;
          best = cost[i][j];
        }
      }
    }
    if (bi < 0) break;
    const q = ss[bi].cmp(dd[bj]) < 0 ? ss[bi] : dd[bj];
    alloc[bi][bj] = q;
    basic.push([bi, bj]);
    ss[bi] = ss[bi].sub(q);
    dd[bj] = dd[bj].sub(q);
    crossOut(rowOpen, colOpen, bi, bj, ss[bi]);
  }
  fillBasic(alloc, basic, m, n);
  return { alloc, basic };
}

// FUN_004ad9b0 seeds each penalty scan from the double at 0x50b134 (999999).
// One open cell leaves the second-smallest scan empty, so its penalty is 999999 minus that cost.
const VOGEL_SEED = rat(999999);

function linePenalty(costs) {
  const sorted = costs.map((c, k) => ({ c, k })).sort((a, b) => a.c.cmp(b.c) || a.k - b.k);
  const pen = sorted.length === 1 ? VOGEL_SEED.sub(sorted[0].c) : sorted[1].c.sub(sorted[0].c);
  return { pen, at: sorted[0].k };
}

function vogel(cost, supply, demand) {
  const m = supply.length;
  const n = demand.length;
  const ss = supply.map((v) => rat(v));
  const dd = demand.map((v) => rat(v));
  const alloc = cost.map(() => cost[0].map(() => null));
  const basic = [];
  const rowOpen = Array(m).fill(true);
  const colOpen = Array(n).fill(true);
  const openCount = () => rowOpen.filter(Boolean).length + colOpen.filter(Boolean).length;
  while (rowOpen.some(Boolean) && colOpen.some(Boolean) && openCount() > 1) {
    let bestPen = null;
    let pick = null;
    for (let i = 0; i < m; i++) {
      if (!rowOpen[i]) continue;
      const costs = [];
      const map = [];
      for (let j = 0; j < n; j++) if (colOpen[j]) {
        costs.push(cost[i][j]);
        map.push(j);
      }
      if (!costs.length) continue;
      const { pen, at } = linePenalty(costs);
      if (bestPen == null || pen.cmp(bestPen) > 0) {
        bestPen = pen;
        pick = { i, j: map[at] };
      }
    }
    for (let j = 0; j < n; j++) {
      if (!colOpen[j]) continue;
      const costs = [];
      const map = [];
      for (let i = 0; i < m; i++) if (rowOpen[i]) {
        costs.push(cost[i][j]);
        map.push(i);
      }
      if (!costs.length) continue;
      const { pen, at } = linePenalty(costs);
      if (bestPen == null || pen.cmp(bestPen) > 0) {
        bestPen = pen;
        pick = { i: map[at], j };
      }
    }
    if (!pick) break;
    const { i, j } = pick;
    const q = ss[i].cmp(dd[j]) < 0 ? ss[i] : dd[j];
    alloc[i][j] = q;
    basic.push([i, j]);
    ss[i] = ss[i].sub(q);
    dd[j] = dd[j].sub(q);
    crossOut(rowOpen, colOpen, i, j, ss[i]);
  }
  fillBasic(alloc, basic, m, n);
  return { alloc, basic };
}

function fillBasic(alloc, basic, m, n) {
  const need = m + n - 1;
  const has = (i, j) => basic.some(([a, b]) => a === i && b === j);
  let guard = 0;
  while (basic.length < need && guard++ < m * n) {
    let placed = false;
    for (let i = 0; i < m && !placed; i++) {
      for (let j = 0; j < n && !placed; j++) {
        if (has(i, j)) continue;
        alloc[i][j] = R0;
        basic.push([i, j]);
        placed = true;
      }
    }
    if (!placed) break;
  }
}

function findCycle(basic, enter) {
  const cells = basic.concat([enter]);
  const adj = new Map();
  const key = (i, j) => `${i},${j}`;
  cells.forEach(([i, j]) => adj.set(key(i, j), [i, j]));
  function dfs(path, horiz) {
    const [i, j] = path[path.length - 1];
    if (path.length > 3 && i === enter[0] && j === enter[1]) return path.slice(0, -1);
    for (const [a, b] of cells) {
      if (horiz && a !== i) continue;
      if (!horiz && b !== j) continue;
      if (a === i && b === j) continue;
      if (path.length >= 2) {
        const prev = path[path.length - 2];
        if (prev[0] === a && prev[1] === b) continue;
      }
      if (path.slice(1).some(([x, y]) => x === a && y === b)) continue;
      const hit = dfs(path.concat([[a, b]]), !horiz);
      if (hit) return hit;
    }
    return null;
  }
  return dfs([enter], true) || dfs([enter], false);
}

// FUN_004b00e0 (called from the iteration driver FUN_004b1170):
// flat cell index k (1-based, row-major) maps to
//   row = Int((k - 0.1) / nCols) + 1
//   rem = k mod nCols
// rem == 0 is the last column, and that dual is omitted, so v_last = 0.
// Reduced cost stored at 0x50b0f0 is dual[row] - cost, plus dual[nRows+rem] when rem > 0.
// The entering cell is the strictly largest reduced cost above 0; an equal value keeps the earlier cell.
function modiStep(cost, alloc, basic) {
  const m = cost.length;
  const n = cost[0].length;
  const u = Array(m).fill(null);
  const v = Array(n).fill(null);
  v[n - 1] = R0;
  let guard = 0;
  while (guard++ < m + n + 2) {
    let progress = false;
    for (const [i, j] of basic) {
      if (u[i] != null && v[j] == null) {
        v[j] = cost[i][j].sub(u[i]);
        progress = true;
      } else if (v[j] != null && u[i] == null) {
        u[i] = cost[i][j].sub(v[j]);
        progress = true;
      }
    }
    if (!progress) break;
    if (u.every((x) => x != null) && v.every((x) => x != null)) break;
  }
  for (let i = 0; i < m; i++) if (u[i] == null) u[i] = R0;
  for (let j = 0; j < n; j++) if (v[j] == null) v[j] = R0;
  const delta = cost.map((row, i) => row.map((c, j) => u[i].add(v[j]).sub(c)));
  let ei = -1;
  let ej = -1;
  let best = R0;
  const isBasic = (i, j) => basic.some(([a, b]) => a === i && b === j);
  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (isBasic(i, j)) continue;
      if (delta[i][j].cmp(best) > 0) {
        best = delta[i][j];
        ei = i;
        ej = j;
      }
    }
  }
  return { u, v, delta, enter: ei < 0 ? null : [ei, ej] };
}

function totalCost(cost, alloc) {
  let z = R0;
  alloc.forEach((row, i) => row.forEach((q, j) => {
    if (q) z = z.add(cost[i][j].mul(q));
  }));
  return z;
}

export function solveTransport(input, method = "vogel") {
  const balanced = balance(input.cost, input.supply, input.demand);
  const { cost, supply, demand } = balanced;
  const starter = method === "northwest" ? northwest : method === "least" ? leastCost : vogel;
  let { alloc, basic } = starter(cost, supply, demand);
  const steps = [];
  let guard = 0;
  while (guard++ < 200) {
    const info = modiStep(cost, alloc, basic);
    const z = totalCost(cost, alloc);
    steps.push({
      alloc: alloc.map((row) => row.map((q) => (q == null ? "" : fmtRat(q)))),
      u: info.u.map(fmtRat),
      v: info.v.map(fmtRat),
      delta: info.delta.map((row) => row.map(fmtRat)),
      cost: fmtRat(z),
      enter: info.enter,
      basic: basic.map(([i, j]) => [i, j]),
    });
    if (!info.enter) {
      const shipments = [];
      alloc.forEach((row, i) => row.forEach((q, j) => {
        if (q && q.isPos()) {
          shipments.push({
            from: i,
            to: j,
            qty: fmtRat(q),
            contrib: fmtRat(cost[i][j].mul(q)),
          });
        }
      }));
      return {
        status: "optimal",
        objective: fmtRat(z),
        steps,
        shipments,
        notes: balanced.notes,
        method,
        sources: supply.length,
        dests: demand.length,
      };
    }
    // Quantity update below is a closed loop. tora.exe instead ratio-tests the
    // basis column in FUN_004b06e0 (entries above the 1e-8 at 0x50b12c, compared
    // after a single-precision round) and solves that column with FUN_00435420.
    const cycle = findCycle(basic, info.enter);
    if (!cycle) throw new Error("Closed loop could not be built for the entering cell.");
    let theta = null;
    const leaveAt = [];
    cycle.forEach(([i, j], idx) => {
      if (idx % 2 === 1) {
        const q = alloc[i][j] || R0;
        if (theta == null || q.cmp(theta) < 0) {
          theta = q;
          leaveAt.length = 0;
          leaveAt.push([i, j]);
        } else if (q.cmp(theta) === 0) leaveAt.push([i, j]);
      }
    });
    theta = theta || R0;
    cycle.forEach(([i, j], idx) => {
      const sign = idx % 2 === 0 ? 1 : -1;
      const cur = alloc[i][j] || R0;
      alloc[i][j] = cur.add(theta.mul(rat(sign)));
    });
    const leave = leaveAt[0];
    basic = basic.filter(([i, j]) => !(i === leave[0] && j === leave[1]));
    basic.push(info.enter);
    if (!alloc[info.enter[0]][info.enter[1]]) alloc[info.enter[0]][info.enter[1]] = R0;
  }
  throw new Error("Module Capacity Exceeded!");
}

export function methodName(method) {
  if (method === "northwest") return "North-West Corner Method";
  if (method === "least") return "Least-Cost Method";
  return "Vogel's Method";
}
