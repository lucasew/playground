function fact(n) {
  let x = 1;
  for (let i = 2; i <= n; i++) x *= i;
  return x;
}

function pow(a, n) {
  return a ** n;
}

/**
 * Steady-state birth-death queues used by TORA's M/M/c screen.
 * scenario: { lambda, mu, servers, systemLimit, sourceLimit }
 * Empty system/source limit means infinity.
 */
export function solveQueue(scenarios) {
  return scenarios.map((sc, i) => {
    try {
      return { index: i + 1, ...one(sc) };
    } catch (err) {
      return { index: i + 1, error: err.message };
    }
  });
}

function one(sc) {
  const lambda = num(sc.lambda, "Lambda");
  const mu = num(sc.mu, "Mu");
  const c = Math.round(num(sc.servers, "Nbr. of Servers"));
  const K = blankInf(sc.systemLimit);
  const N = blankInf(sc.sourceLimit);
  if (lambda < 0 || mu < 0 || c < 0) throw new Error("Negative entries are not allowed.");
  if (lambda === 0 && mu === 0) throw new Error("Both Lambda and Mu = 0.");
  if (K != null && N != null && K > N) throw new Error("System Limit exceeds Source Limit.");
  if (mu === 0 && lambda > 0) {
    if (N == null && K == null) {
      throw new Error("Pure birth model has no steady state. Set a system limit N, or a positive Mu.");
    }
    return pureBirth(lambda, K ?? N);
  }
  if (lambda === 0 && mu > 0) {
    const n0 = N ?? K;
    if (n0 == null) throw new Error("Missing or zero N in a pure death model.");
    return pureDeath(mu, n0);
  }
  if (c < 1) throw new Error("Nbr. of Servers must be at least 1 when Mu is positive.");
  if (K == null && N == null) return infinite(lambda, mu, c);
  return finite(lambda, mu, c, K, N);
}

function infinite(lambda, mu, c) {
  const rhoUnit = lambda / mu;
  const rho = lambda / (c * mu);
  if (rho >= 1) throw new Error("Lambda >= mu*c in an infinite queue.");
  let sum = 0;
  for (let k = 0; k < c; k++) sum += pow(rhoUnit, k) / fact(k);
  const tail = pow(rhoUnit, c) / (fact(c) * (1 - rho));
  const P0 = 1 / (sum + tail);
  const Lq = P0 * pow(rhoUnit, c) * rho / (fact(c) * (1 - rho) ** 2);
  const Ls = Lq + rhoUnit;
  const Wq = Lq / lambda;
  const Ws = Wq + 1 / mu;
  const pn = [];
  let cum = 0;
  for (let n = 0; n <= c + 12; n++) {
    const p = n < c ? P0 * pow(rhoUnit, n) / fact(n) : P0 * pow(rhoUnit, n) / (fact(c) * pow(c, n - c));
    cum += p;
    pn.push({ n, p: fmt(p), cum: fmt(cum) });
    if (cum > 0.999) break;
  }
  return {
    model: `(M/M/${c}):(GD/∞/∞)`,
    lambda, mu, c,
    lambdaEff: fmt(lambda),
    rho: fmt(rho),
    P0: fmt(P0),
    Ls: fmt(Ls), Lq: fmt(Lq), Ws: fmt(Ws), Wq: fmt(Wq),
    pn,
  };
}

function finite(lambda, mu, c, K, N) {
  const limit = K == null ? N : K;
  const rates = [];
  for (let n = 0; n < limit; n++) {
    const birth = N == null ? lambda : lambda * Math.max(N - n, 0);
    const death = Math.min(n + 1, c) * mu;
    rates.push({ birth, death });
  }
  const p = [1];
  for (let n = 0; n < limit; n++) {
    const next = rates[n].death === 0 ? 0 : p[n] * rates[n].birth / rates[n].death;
    p.push(next);
  }
  const scale = p.reduce((a, b) => a + b, 0);
  if (scale === 0) throw new Error("Queue balance has no solution.");
  for (let i = 0; i < p.length; i++) p[i] /= scale;
  let Ls = 0;
  p.forEach((pi, n) => { Ls += n * pi; });
  const lambdaEff = N == null
    ? lambda * (1 - p[limit])
    : p.reduce((acc, pi, n) => acc + lambda * Math.max(N - n, 0) * pi, 0);
  const Lq = Math.max(0, Ls - lambdaEff / mu);
  const Wq = lambdaEff > 1e-12 ? Lq / lambdaEff : 0;
  const Ws = lambdaEff > 1e-12 ? Ls / lambdaEff : 0;
  let cum = 0;
  const pn = p.map((pi, n) => {
    cum += pi;
    return { n, p: fmt(pi), cum: fmt(cum) };
  });
  const kLabel = K == null ? "∞" : K;
  const nLabel = N == null ? "∞" : N;
  return {
    model: `(M/M/${c}):(GD/${kLabel}/${nLabel})`,
    lambda, mu, c,
    lambdaEff: fmt(lambdaEff),
    rho: fmt(lambda / (c * mu)),
    P0: fmt(p[0]),
    Ls: fmt(Ls), Lq: fmt(Lq), Ws: fmt(Ws), Wq: fmt(Wq),
    pn,
  };
}

function pureDeath(mu, N) {
  return {
    model: `Pure Death Model (N = ${N})`,
    note: "With Lambda = 0 every customer eventually departs. Steady state is an empty system.",
    lambdaEff: "0",
    rho: "0",
    P0: "1",
    Ls: "0", Lq: "0", Ws: "—", Wq: "—",
    pn: [{ n: 0, p: "1", cum: "1" }],
    mu,
  };
}

function pureBirth(lambda, N) {
  return {
    model: `Pure Birth Model (N = ${N})`,
    note: "With Mu = 0 the system fills and stays at the limit. There is no interior steady state.",
    lambdaEff: "0",
    rho: "—",
    P0: "0",
    Ls: String(N), Lq: String(N), Ws: "—", Wq: "—",
    pn: [{ n: N, p: "1", cum: "1" }],
    lambda,
  };
}

function num(v, label) {
  if (v == null || String(v).trim() === "") throw new Error(`${label} is missing.`);
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error(`${label} is not a number.`);
  return n;
}

function blankInf(v) {
  if (v == null || String(v).trim() === "" || String(v).trim() === "∞") return null;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) throw new Error("Limits must be blank (infinity) or a nonnegative number.");
  return Math.round(n);
}

function fmt(x) {
  if (!Number.isFinite(x)) return "—";
  const s = (Math.round(x * 1e6) / 1e6).toString();
  return s;
}
