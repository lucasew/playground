import { solveLP } from "./lp.js";
import { fmtRat, rat } from "./rational.js";

function num(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Error("Payoffs must be numeric.");
  return n;
}

export function solveGame(matrix) {
  const A = matrix.map((row) => row.map(num));
  const m = A.length;
  const n = A[0]?.length || 0;
  if (m < 2 || n < 2) throw new Error("A game needs at least two strategies for each player.");
  const saddle = findSaddle(A);
  const lp = gameLP(A);
  const graphic = m === 2 || n === 2 ? graphical(A) : null;
  return {
    matrix: A,
    saddle,
    value: lp.value,
    pA: lp.pA,
    pB: lp.pB,
    lpStatus: lp.status,
    graphic,
    rows: m,
    cols: n,
  };
}

function findSaddle(A) {
  const rowMin = A.map((row) => Math.min(...row));
  const maximin = Math.max(...rowMin);
  const colMax = A[0].map((_, j) => Math.max(...A.map((row) => row[j])));
  const minimax = Math.min(...colMax);
  if (Math.abs(maximin - minimax) > 1e-9) return null;
  const i = rowMin.findIndex((v) => Math.abs(v - maximin) < 1e-9);
  const j = colMax.findIndex((v) => Math.abs(v - minimax) < 1e-9);
  return { value: round(maximin), row: i + 1, col: j + 1 };
}

function gameLP(A) {
  const m = A.length;
  const n = A[0].length;
  const shift = Math.min(0, ...A.flat()) < 0 ? Math.abs(Math.min(...A.flat())) + 1 : 0;
  const M = A.map((row) => row.map((v) => v + shift));
  const variables = M.map((_, i) => ({
    name: `x${i + 1}`,
    c: 1,
    lb: "0",
    ub: "infinity",
  }));
  const constraints = [];
  for (let j = 0; j < n; j++) {
    constraints.push({
      name: `B${j + 1}`,
      a: M.map((row) => row[j]),
      rel: ">=",
      b: 1,
    });
  }
  const solved = solveLP({ sense: "min", title: "Game", variables, constraints }, { method: "two-phase" });
  if (solved.status !== "optimal") {
    return { status: solved.status, value: "—", pA: [], pB: [] };
  }
  const xs = solved.variables.map((v) => v.valueRat || rat(v.value));
  const sum = xs.reduce((a, b) => a.add(b), rat(0));
  const valueShifted = sum.isZero() ? rat(0) : rat(1).div(sum);
  const pA = xs.map((x) => fmtRat(sum.isZero() ? rat(0) : x.div(sum)));
  const value = valueShifted.sub(rat(shift));
  const pB = columnMix(M);
  return { status: "optimal", value: fmtRat(value), pA, pB };
}

function columnMix(M) {
  const n = M[0].length;
  const m = M.length;
  const variables = M[0].map((_, j) => ({ name: `y${j + 1}`, c: 1, lb: "0", ub: "infinity" }));
  const constraints = [];
  for (let i = 0; i < m; i++) {
    constraints.push({
      name: `A${i + 1}`,
      a: M.map((row) => row[i]).slice(0, n).map((_, j) => M[i][j]),
      rel: "<=",
      b: 1,
    });
  }
  const solved = solveLP({ sense: "max", title: "Game B", variables, constraints }, { method: "auto" });
  if (solved.status !== "optimal") return M[0].map(() => "—");
  const ys = solved.variables.map((v) => v.valueRat || rat(v.value));
  const sum = ys.reduce((a, b) => a.add(b), rat(0));
  return ys.map((y) => fmtRat(sum.isZero() ? rat(0) : y.div(sum)));
}

function graphical(A) {
  const m = A.length;
  const n = A[0].length;
  if (m === 2) {
    const lines = [];
    for (let j = 0; j < n; j++) {
      lines.push({
        name: `B${j + 1}`,
        // payoff = A[1][j] + p * (A[0][j]-A[1][j]) where p = P(strategy 1)
        intercept: A[1][j],
        slope: A[0][j] - A[1][j],
      });
    }
    const candidates = [0, 1];
    for (let i = 0; i < lines.length; i++) {
      for (let k = i + 1; k < lines.length; k++) {
        const ds = lines[i].slope - lines[k].slope;
        if (Math.abs(ds) < 1e-12) continue;
        const p = (lines[k].intercept - lines[i].intercept) / ds;
        if (p >= -1e-9 && p <= 1 + 1e-9) candidates.push(Math.min(1, Math.max(0, p)));
      }
    }
    let best = null;
    candidates.forEach((p) => {
      const vals = lines.map((ln) => ln.intercept + ln.slope * p);
      const security = Math.min(...vals);
      if (!best || security > best.security) best = { p, security, vals };
    });
    return {
      player: "A",
      p: round(best.p),
      value: round(best.security),
      lines: lines.map((ln) => ({ name: ln.name, at0: round(ln.intercept), at1: round(ln.intercept + ln.slope) })),
    };
  }
  const lines = [];
  for (let i = 0; i < m; i++) {
    lines.push({
      name: `A${i + 1}`,
      intercept: A[i][1],
      slope: A[i][0] - A[i][1],
    });
  }
  const candidates = [0, 1];
  for (let i = 0; i < lines.length; i++) {
    for (let k = i + 1; k < lines.length; k++) {
      const ds = lines[i].slope - lines[k].slope;
      if (Math.abs(ds) < 1e-12) continue;
      const q = (lines[k].intercept - lines[i].intercept) / ds;
      if (q >= -1e-9 && q <= 1 + 1e-9) candidates.push(Math.min(1, Math.max(0, q)));
    }
  }
  let best = null;
  candidates.forEach((q) => {
    const vals = lines.map((ln) => ln.intercept + ln.slope * q);
    const security = Math.max(...vals);
    if (!best || security < best.security) best = { q, security, vals };
  });
  return {
    player: "B",
    p: round(best.q),
    value: round(best.security),
    lines: lines.map((ln) => ({ name: ln.name, at0: round(ln.intercept), at1: round(ln.intercept + ln.slope) })),
  };
}

function round(x) {
  if (!Number.isFinite(Number(x))) return "—";
  return String(Math.round(Number(x) * 1e6) / 1e6);
}
