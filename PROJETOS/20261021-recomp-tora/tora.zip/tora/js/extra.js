import { R0, R1, fmtRat, rat } from "./rational.js";

function mat(rows) {
  return rows.map((row) => row.map((v) => rat(v)));
}

export function invert(matrix) {
  const A = mat(matrix);
  const n = A.length;
  if (!n || A.some((row) => row.length !== n)) throw new Error("Matrix inversion expects a square matrix.");
  const M = A.map((row, i) => row.concat(Array.from({ length: n }, (_, j) => (i === j ? R1 : R0))));
  let det = R1;
  let sign = 1;
  for (let k = 0; k < n; k++) {
    let piv = k;
    for (let i = k + 1; i < n; i++) if (M[i][k].abs().cmp(M[piv][k].abs()) > 0) piv = i;
    if (M[piv][k].isZero()) {
      return { singular: true, message: "Matrix is singular -- No inverse", determinant: "0" };
    }
    if (piv !== k) {
      [M[k], M[piv]] = [M[piv], M[k]];
      sign *= -1;
    }
    const pivV = M[k][k];
    det = det.mul(pivV);
    for (let j = k; j < 2 * n; j++) M[k][j] = M[k][j].div(pivV);
    for (let i = 0; i < n; i++) {
      if (i === k) continue;
      const f = M[i][k];
      if (f.isZero()) continue;
      for (let j = k; j < 2 * n; j++) M[i][j] = M[i][j].sub(M[k][j].mul(f));
    }
  }
  const inverse = M.map((row) => row.slice(n).map((v) => fmtRat(v)));
  const determinant = fmtRat(det.mul(rat(sign)));
  return { singular: false, inverse, determinant, message: "" };
}

export function solveEquations(matrix, rhs) {
  const A = mat(matrix);
  const b = rhs.map((v) => rat(v));
  const n = A.length;
  if (b.length !== n || A.some((row) => row.length !== n)) {
    throw new Error("Enter a square coefficient matrix and one right-hand side per equation.");
  }
  const M = A.map((row, i) => row.concat([b[i]]));
  for (let k = 0; k < n; k++) {
    let piv = k;
    for (let i = k + 1; i < n; i++) if (M[i][k].abs().cmp(M[piv][k].abs()) > 0) piv = i;
    if (M[piv][k].isZero()) return { singular: true, message: "No Solution" };
    if (piv !== k) [M[k], M[piv]] = [M[piv], M[k]];
    const pivV = M[k][k];
    for (let j = k; j <= n; j++) M[k][j] = M[k][j].div(pivV);
    for (let i = 0; i < n; i++) {
      if (i === k) continue;
      const f = M[i][k];
      for (let j = k; j <= n; j++) M[i][j] = M[i][j].sub(M[k][j].mul(f));
    }
  }
  return {
    singular: false,
    solution: M.map((row) => fmtRat(row[n])),
    message: "",
  };
}

export function captionOnly(title) {
  return {
    title,
    message: "tora.exe draws this title on the main menu. The executable has no procedure, input grid, or formula for it.",
  };
}
