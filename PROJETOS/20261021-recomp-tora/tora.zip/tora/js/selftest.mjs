import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { solveLP, solveIP } from "./lp.js";
import { parseToraLP } from "./io.js";
import { solveTransport } from "./transport.js";
import { dijkstra, floyd, prim, maxFlow } from "./net.js";
import { solveQueue } from "./queue.js";
import { solveProject } from "./project.js";
import { solveGame } from "./games.js";
import { invert, solveEquations } from "./extra.js";

const reddy = parseToraLP(readFileSync(new URL("../samples/reddy-mikks.txt", import.meta.url), "utf8"));
assert.equal(reddy.title, "Reddy Mikks");
assert.equal(reddy.sense, "max");
assert.equal(reddy.variables.length, 2);
assert.equal(reddy.variables[0].name, "Exterior");
assert.equal(reddy.constraints.length, 4);

const lp = solveLP(reddy, { method: "auto" });
assert.equal(lp.status, "optimal", JSON.stringify(lp.messages));
assert.equal(lp.objective, "21");
assert.equal(lp.variables[0].value, "3");
assert.equal(lp.variables[1].value, "1.5");
assert.equal(lp.constraints[0].dual, "0.75");
assert.equal(lp.constraints[1].dual, "0.5");
assert.equal(lp.constraints[2].dual, "0");
assert.equal(lp.constraints[3].dual, "0");

const two = solveLP({
  sense: "min",
  variables: [{ name: "x", c: "1", lb: "0", ub: "infinity" }],
  constraints: [{ name: "c", a: ["1"], rel: ">=", b: "3" }],
}, { method: "two-phase" });
assert.equal(two.status, "optimal", two.message);
assert.equal(two.objective, "3");

const mm = solveLP({
  sense: "max",
  variables: [
    { name: "x1", c: "3", lb: "0", ub: "infinity" },
    { name: "x2", c: "2", lb: "0", ub: "infinity" },
  ],
  constraints: [
    { name: "c1", a: ["1", "1"], rel: "<=", b: "4" },
    { name: "c2", a: ["2", "1"], rel: ">=", b: "2" },
  ],
}, { method: "m-method" });
assert.equal(mm.status, "optimal");
assert.equal(mm.objective, "12");

const dual = solveLP({
  sense: "max",
  variables: [
    { name: "x1", c: "-2", lb: "0", ub: "infinity" },
    { name: "x2", c: "-1", lb: "0", ub: "infinity" },
  ],
  constraints: [
    { name: "c1", a: ["-1", "-1"], rel: "<=", b: "-5" },
    { name: "c2", a: ["-1", "0"], rel: "<=", b: "-2" },
  ],
}, { method: "dual" });
const primal = solveLP({
  sense: "max",
  variables: [
    { name: "x1", c: "-2", lb: "0", ub: "infinity" },
    { name: "x2", c: "-1", lb: "0", ub: "infinity" },
  ],
  constraints: [
    { name: "c1", a: ["-1", "-1"], rel: "<=", b: "-5" },
    { name: "c2", a: ["-1", "0"], rel: "<=", b: "-2" },
  ],
}, { method: "two-phase" });
assert.equal(dual.status, "optimal", dual.message + " " + (dual.messages || []).join(";"));
assert.equal(primal.status, "optimal");
assert.equal(dual.objective, primal.objective);

const ip = solveIP({
  sense: "max",
  variables: [
    { name: "Exterior", c: "5", lb: "0", ub: "infinity", integer: true },
    { name: "Interior", c: "4", lb: "0", ub: "infinity", integer: true },
  ],
  constraints: reddy.constraints,
});
assert.equal(ip.status, "optimal");
assert.equal(ip.objective, "20");

const cost = [
  [2, 3, 4],
  [5, 1, 2],
];
let best = Infinity;
function brute(i, remS, remD, acc) {
  if (i === 2) {
    if (remD.every((d) => d === 0)) best = Math.min(best, acc);
    return;
  }
  function rec(j, left, rd, a) {
    if (j === 3) {
      if (left === 0) brute(i + 1, remS, rd, a);
      return;
    }
    for (let q = 0; q <= Math.min(left, rd[j]); q++) {
      rd[j] -= q;
      rec(j + 1, left - q, rd, a + q * cost[i][j]);
      rd[j] += q;
    }
  }
  rec(0, remS[i], remD.slice(), acc);
}
brute(0, [8, 7], [5, 6, 4], 0);
for (const method of ["vogel", "northwest", "least"]) {
  const t = solveTransport({ cost, supply: [8, 7], demand: [5, 6, 4] }, method);
  assert.equal(t.status, "optimal", method);
  assert.equal(Number(t.objective), best, `${method} got ${t.objective} want ${best}`);
}

const d = dijkstra([
  { from: 1, to: 2, weight: 2 },
  { from: 1, to: 3, weight: 5 },
  { from: 2, to: 3, weight: 1 },
  { from: 2, to: 4, weight: 4 },
  { from: 3, to: 4, weight: 1 },
], 1);
assert.equal(d.routes.find((r) => r.node === 4).distance, "4");
const fl = floyd([
  { from: 1, to: 2, weight: 2 },
  { from: 1, to: 3, weight: 5 },
  { from: 2, to: 3, weight: 1 },
  { from: 2, to: 4, weight: 4 },
  { from: 3, to: 4, weight: 1 },
]);
assert.equal(fl.routes.find((r) => r.from === 1 && r.to === 4).distance, "4");
const tree = prim([
  { from: 1, to: 2, weight: 1 },
  { from: 2, to: 3, weight: 2 },
  { from: 1, to: 3, weight: 4 },
], 1);
assert.equal(tree.length, "3");
const flow = maxFlow([
  { from: 1, to: 2, weight: 10 },
  { from: 1, to: 3, weight: 10 },
  { from: 2, to: 3, weight: 1 },
  { from: 2, to: 4, weight: 10 },
  { from: 3, to: 4, weight: 10 },
], 1, 4);
assert.equal(flow.value, "20");

const q = solveQueue([{ lambda: 4, mu: 8, servers: 1, systemLimit: "", sourceLimit: "" }])[0];
assert.equal(q.Ls, "1");
assert.equal(q.Lq, "0.5");
assert.equal(q.Ws, "0.25");

const cpm = solveProject([
  { symbol: "A", from: 1, to: 2, duration: 3 },
  { symbol: "B", from: 2, to: 3, duration: 4 },
  { symbol: "C", from: 1, to: 3, duration: 10 },
], "cpm");
assert.equal(cpm.projectLength, "10");
assert.equal(cpm.rows.find((r) => r.symbol === "C").critical, true);

const pert = solveProject([
  { symbol: "A", from: 1, to: 2, a: 3, m: 4, b: 5 },
], "pert");
assert.equal(pert.rows[0].mean, "4");
assert.equal(pert.pathStd, "0.333333");

const game = solveGame([
  [1, -1],
  [-1, 1],
]);
assert.equal(game.value, "0");
assert.equal(game.pA[0], "0.5");

const saddle = solveGame([
  [1, 2],
  [0, -1],
]);
assert.equal(saddle.saddle.value, "1");
assert.equal(saddle.value, "1");

const inv = invert([
  [1, 2],
  [3, 4],
]);
assert.equal(inv.determinant, "-2");
assert.deepEqual(inv.inverse, [["-2", "1"], ["1.5", "-0.5"]]);
const eq = solveEquations([[1, 1], [1, -1]], [3, 1]);
assert.deepEqual(eq.solution, ["2", "1"]);

console.log("selftest ok");
