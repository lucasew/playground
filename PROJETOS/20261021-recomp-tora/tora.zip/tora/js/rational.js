function gcd(a, b) {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b) {
    const t = a % b;
    a = b;
    b = t;
  }
  return a || 1n;
}

export class Rat {
  constructor(n, d = 1n) {
    if (typeof n === "bigint" && typeof d === "bigint") {
      if (d === 0n) throw new Error("division by zero");
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      const g = gcd(n, d);
      this.n = n / g;
      this.d = d / g;
      return;
    }
    return Rat.parse(n);
  }

  static fromBig(n, d = 1n) {
    return new Rat(n, d);
  }

  static parse(value) {
    if (value instanceof Rat) return value;
    if (typeof value === "number") {
      if (!Number.isFinite(value)) {
        throw new Error("non-finite");
      }
      return Rat.parse(String(value));
    }
    let t = String(value).trim().replace(/,/g, "");
    if (t === "") return Rat.fromBig(0n);
    const neg = t.startsWith("-");
    if (neg || t.startsWith("+")) t = t.slice(1);
    let n;
    let d;
    if (t.includes("/")) {
      const [a, b] = t.split("/");
      n = BigInt(a);
      d = BigInt(b);
    } else if (t.includes(".")) {
      const [w, f = ""] = t.split(".");
      const frac = f.replace(/[^0-9]/g, "");
      d = 10n ** BigInt(frac.length);
      n = BigInt(w || "0") * d + BigInt(frac || "0");
    } else {
      n = BigInt(t);
      d = 1n;
    }
    if (neg) n = -n;
    return Rat.fromBig(n, d);
  }

  add(o) {
    o = Rat.parse(o);
    return Rat.fromBig(this.n * o.d + o.n * this.d, this.d * o.d);
  }

  sub(o) {
    o = Rat.parse(o);
    return Rat.fromBig(this.n * o.d - o.n * this.d, this.d * o.d);
  }

  mul(o) {
    o = Rat.parse(o);
    return Rat.fromBig(this.n * o.n, this.d * o.d);
  }

  div(o) {
    o = Rat.parse(o);
    return Rat.fromBig(this.n * o.d, this.d * o.n);
  }

  neg() {
    return Rat.fromBig(-this.n, this.d);
  }

  abs() {
    return Rat.fromBig(this.n < 0n ? -this.n : this.n, this.d);
  }

  inv() {
    return Rat.fromBig(this.d, this.n);
  }

  cmp(o) {
    o = Rat.parse(o);
    const left = this.n * o.d;
    const right = o.n * this.d;
    return left < right ? -1 : left > right ? 1 : 0;
  }

  isZero() {
    return this.n === 0n;
  }

  isNeg() {
    return this.n < 0n;
  }

  isPos() {
    return this.n > 0n;
  }

  toNumber() {
    return Number(this.n) / Number(this.d);
  }
}

export function rat(value) {
  if (value instanceof Rat) return value;
  return Rat.parse(value);
}

export const R0 = Rat.fromBig(0n);
export const R1 = Rat.fromBig(1n);

/** a + b·M, with M larger than every real coefficient. */
export class BM {
  constructor(real, big = 0) {
    this.r = real instanceof Rat ? real : rat(real);
    this.m = big instanceof Rat ? big : rat(big);
  }

  add(o) {
    return new BM(this.r.add(o.r), this.m.add(o.m));
  }

  sub(o) {
    return new BM(this.r.sub(o.r), this.m.sub(o.m));
  }

  mulRat(k) {
    k = k instanceof Rat ? k : rat(k);
    return new BM(this.r.mul(k), this.m.mul(k));
  }

  divRat(k) {
    k = k instanceof Rat ? k : rat(k);
    return new BM(this.r.div(k), this.m.div(k));
  }

  neg() {
    return new BM(this.r.neg(), this.m.neg());
  }

  cmp(o) {
    const c = this.m.cmp(o.m);
    return c || this.r.cmp(o.r);
  }

  isZero() {
    return this.r.isZero() && this.m.isZero();
  }

  isNeg() {
    return this.cmp(BM0) < 0;
  }

  isPos() {
    return this.cmp(BM0) > 0;
  }
}

export const BM0 = new BM(0, 0);

export function fmtRat(r, digits = 6) {
  r = r instanceof Rat ? r : rat(r);
  const x = r.toNumber();
  if (!Number.isFinite(x)) return "—";
  if (Math.abs(x) >= 1e8) return x.toExponential(4);
  let s = x.toFixed(digits).replace(/\.?0+$/, "");
  if (s === "-0") s = "0";
  return s;
}

export function fmtBM(b) {
  if (!(b instanceof BM)) return fmtRat(b);
  if (b.m.isZero()) return fmtRat(b.r);
  let ms;
  if (b.m.cmp(R1) === 0) ms = "M";
  else if (b.m.cmp(rat(-1)) === 0) ms = "-M";
  else ms = `${fmtRat(b.m)}M`;
  if (b.r.isZero()) return ms;
  const rs = fmtRat(b.r);
  return b.r.isNeg() ? ms + rs : `${ms}+${rs}`;
}

export function parseBound(text) {
  const t = String(text ?? "").trim().toLowerCase();
  if (t === "" || t === "inf" || t === "infinity" || t === "+inf" || t === "+infinity") {
    return { inf: 1, rat: null };
  }
  if (t === "-inf" || t === "-infinity") return { inf: -1, rat: null };
  return { inf: 0, rat: rat(t) };
}
